﻿#$%^&* scraper_email.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 29 09:48:14 2021

@author: thzhang
"""

### get emails from inox /China broker folder


import win32com.client

outlook = win32com.client.Dispatch('outlook.application') # connect to outlook
mapi = outlook.GetNamespace("MAPI") 
    
inbox = mapi.GetDefaultFolder(6) # access inbox
# doc: https://docs.microsoft.com/en-us/office/vba/api/outlook.oldefaultfolders

china_folder = inbox.Folders['China broker'] # access the "China broker" folder under inbox

msg = china_folder.Items # get all emails
msg = msg.Restrict("[SenderEmailAddress] = 'Sherman.Guo@us.htisec.com'") # filter emails

# for each email ...
# https://docs.microsoft.com/en-us/dotnet/api/microsoft.office.interop.outlook.mailitem?redirectedfrom=MSDN&view=outlook-pia#properties_
for m in msg:
    str(m.sender)
    str(m.subject)
    str(m.body)
    str(m.creationtime)
    str(m.htmlbody) # event data is structured in a MS-Office-like table object (MsoNormal)




