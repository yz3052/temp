﻿#$%^&* pFlow_cn__etl_ths.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 16 06:54:35 2023

@author: thzhang
"""

import pandas as pd
import numpy as np

import os

import util as yu



### THS
# 1 ticker_click 2 ticker_click by asset 3 news_click 4 zixuan 5 zixuan by asset
# 6 zixuan_add 7 zixuan_del

root = '/dat/mdwarehouse/public/Hithink/DATA-15691/thsindex/'

#------------------------------------------------------------------------------
t_data = pd.read_csv(root+'thsindex1.gz')
t_data['T-1d'] = pd.to_datetime(t_data['index_date'])
t_data['Ticker'] = t_data['index_code'].astype(str).str.zfill(6)
t_data = t_data.rename(columns = {'index_value': 'tickerClickIdx'})
t_data = t_data[['Ticker', 'T-1d', 'tickerClickIdx']]
t_data.to_parquet('/export/datadev/cache/ths_index_1.parquet')


#------------------------------------------------------------------------------
t_data = pd.read_csv(root+'thsindex2.gz')
t_data['T-1d'] = pd.to_datetime(t_data['index_date'])
t_data['Ticker'] = t_data['index_code'].astype(str).str.zfill(6)
t_data = t_data.rename(columns = {'index_value_a': 'tickerClickByAssetIdx_a',
                                  'index_value_b': 'tickerClickByAssetIdx_b',
                                  'index_value_c': 'tickerClickByAssetIdx_c'})
t_data = t_data[['Ticker', 'T-1d', 'tickerClickByAssetIdx_a',
                 'tickerClickByAssetIdx_b', 'tickerClickByAssetIdx_c']]
t_data.to_parquet('/export/datadev/cache/ths_index_2.parquet')


#------------------------------------------------------------------------------
t_data = pd.read_csv(root+'thsindex3.gz')
t_data['T-1d'] = pd.to_datetime(t_data['index_date'])
t_data['Ticker'] = t_data['index_code'].astype(str).str.zfill(6)
t_data = t_data.rename(columns = {'index_value': 'newsClickIdx'})
t_data = t_data[['Ticker', 'T-1d', 'newsClickIdx']]
t_data.to_parquet('/export/datadev/cache/ths_index_3.parquet')


#------------------------------------------------------------------------------
t_data = pd.read_csv(root+'thsindex4.gz')
t_data['T-1d'] = pd.to_datetime(t_data['index_date'])
t_data['Ticker'] = t_data['index_code'].astype(str).str.zfill(6)
t_data = t_data.rename(columns = {'index_value': 'zixuanIdx'})
t_data = t_data[['Ticker', 'T-1d', 'zixuanIdx']]
t_data.to_parquet('/export/datadev/cache/ths_index_4.parquet')


#------------------------------------------------------------------------------
t_data = pd.read_csv(root+'thsindex5.gz')
t_data['T-1d'] = pd.to_datetime(t_d
ata['index_date'])
t_data['Ticker'] = t_data['index_code'].astype(str).str.zfill(6)
t_data = t_data.rename(columns = {'index_value_a': 'zixuanByAsset_a',
                                  'index_value_b': 'zixuanByAsset_b',
                                  'index_value_c': 'zixuanByAsset_c'})
t_data = t_data[['Ticker', 'T-1d', 'zixuanByAsset_a',
                 'zixuanByAsset_b', 'zixuanByAsset_c']]
t_data.to_parquet('/export/datadev/cache/ths_index_5.parquet')


#------------------------------------------------------------------------------
t_data = pd.read_csv(root+'thsindex6.gz')
t_data['T-1d'] = pd.to_datetime(t_data['index_date'])
t_data['Ticker'] = t_data['index_code'].astype(str).str.zfill(6)
t_data = t_data.rename(columns = {'index_value': 'zixuanAddIdx'})
t_data = t_data[['Ticker', 'T-1d', 'zixuanAddIdx']]
t_data.to_parquet('/export/datadev/cache/ths_index_6.parquet')



#------------------------------------------------------------------------------
t_data = pd.read_csv(root+'thsindex7.gz')
t_data['T-1d'] = pd.to_datetime(t_data['index_date'])
t_data['Ticker'] = t_data['index_code'].astype(str).str.zfill(6)
t_data = t_data.rename(columns = {'index_value': 'zixuanDelIdx'})
t_data = t_data[['Ticker', 'T-1d', 'zixuanDelIdx']]
t_data.to_parquet('/export/datadev/cache/ths_index_7.parquet')



