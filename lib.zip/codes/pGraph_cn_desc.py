﻿#$%^&* pGraph_cn_desc.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu May 12 10:26:48 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import zipfile
import csv

import jieba
import itertools


# 



### get baidu stop words
i_stopword = open(r"S:\Infrastructure\nlp\baidu_stopwords.txt", encoding="utf-8").read()
i_stopword = i_stopword.split('\n')


### get sd
i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values('datadate')

i_sd_dd = i_sd['datadate'].drop_duplicates()


### get company description data

i_p = yu.get_sql('''
                 select s_info_windcode as ticker, ann_dt, backtime, 
                        s_info_chineseintroduction, s_info_businessscope, s_info_main_business
                 from wind.dbo.ASHAREINTRODUCTIONBT 
                 ''') 
i_p['backtime'] = i_p['backtime'].fillna(pd.to_datetime('2050-12-31'))
i_p = i_p.sort_values(['ticker', 'backtime'])

i_p['backtime'] = pd.to_datetime(i_p['backtime'].dt.date)
i_p = i_p.drop_duplicates(subset = ['ticker', 'ann_dt'], keep = 'last')

i_p = i_p[i_p['ticker'].str[-2:].isin(['SH', 'SZ'])]
i_p = i_p[i_p['ticker'].str[0].isin(['0','3','6'])]

i_p = i_p[i_p['s_info_businessscope'].notnull()]
i_p['scope_clean'] = i_p['s_info_businessscope'].\
                     str.replace('（|）|,|，|\.|。|:|：|;|；|\(|\)|\*|~|`|!|@|#|$|&|-|—|\+|\/|、|\?',' ').\
                     str.upper()
i_p['scope_seg'] = i_p['scope_clean'].apply(lambda x: list(jieba.cut(x)))

scope_seg_list = list(set(itertools.chain(*i_p['scope_seg'])))
scope_seg_id = list(range(len(scope_seg_list)))
scope_seg_dict = {scope_seg_list[i]:i for i in scope_seg_id}

i_p['scopeID_seg'] = i_p['scope_seg'].apply(lambda x: set([scope_seg_dict[i] for i in x]))



### loop 
# get trailing 1 year jd segments
# calculate pairwise % overlapped segments

o_pct_overlap = []

for dt in pd.date_range(start = '2016-06-01', end = '2021-06-01', freq = 'W'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    yu.tic()
    t_sd = i_sd[i_sd['datadate']==i_sd_dd[i_sd_dd<=dt].max()]
    t_p = i_p[(i_p['backtime']>dt) & (i_p['ticker'].isin(t_sd['ticker'].tolist()))]
    t_p = t_p.drop_duplicates(subset = 'ticker', keep = 'first')
    

    t_intersection_len = pd.DataFrame((t_p['scopeID_seg'].values[:,None] & t_p['scopeID_seg'].values))
    t_intersection_len = np.vectorize(len)(t_intersection_len.values)
    
    t_union_len = pd.DataFrame((t_p['scopeID_seg'].valu
es[:,None] | t_p['scopeID_seg'].values))
    t_union_len = np.vectorize(len)(t_union_len.values)
    
    t_pct_overlap = t_intersection_len/t_union_len
    t_pct_overlap = pd.DataFrame(t_pct_overlap, index = t_p['ticker'].values, columns = t_p['ticker'].values)
    t_pct_overlap.values[[np.arange(t_pct_overlap.shape[0])]*2] = np.nan
    
    t_sum1 = t_pct_overlap.mean(axis = 1)
    t_sum1 = t_sum1.reset_index()
    t_sum1.columns = ['ticker','pct_overlap']
    
    t_sum = t_sum1.copy()
    t_sum['datadate'] = dt
    
    yu.toc()
    o_pct_overlap.append(t_sum)
    
o_pct_overlap = pd.concat(o_pct_overlap, axis = 0)
o_pct_overlap.to_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_desc_pct_overlap.parquet')




### combine 


icom = pd.merge_asof(i_sd, o_pct_overlap, by='ticker', on='datadate')

icom = icom.sort_values(['ticker','datadate'])

icom['pct_overlap_bk'] = icom.groupby('datadate')['pct_overlap'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['pct_overlap_rk'] = icom.groupby('datadate')['pct_overlap'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['pct_overlap_bk'], 'pct_overlap') # random

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['pct_overlap_orth'] = icom.groupby('datadate')[COLS+['pct_overlap']].apply(lambda x: yu.orthogonalize_cn(x['pct_overlap'], x[COLS])).values
icom['pct_overlap_orth_bk'] = icom.groupby('datadate')['pct_overlap_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['pct_overlap_orth_rk'] = icom.groupby('datadate')['pct_overlap_orth'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['pct_overlap_orth_bk'], 'pct_overlap_orth') # random

    
icom['orth_neg_sgnl'] = np.nan
icom.loc[icom['pct_overlap_orth_rk']<-0.8, 'orth_neg_sgnl']  = -1
icom['orth_neg_sgnl'] = icom.groupby('ticker')['orth_neg_sgnl'].ffill(limit=5)


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['orth_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'orth_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['csi300_flag']==1)].\
            dropna(subset=['orth_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'orth_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

