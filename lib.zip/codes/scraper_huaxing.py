﻿#$%^&* scraper_huaxing.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Jul  1 20:21:03 2021

@author: thzhang
"""
import pandas as pd
import numpy as np

import time

import selenium
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC





from seleniumwire import webdriver as webdriver2

options = {'proxy': {'http': 'http://thzhang:Citadel190430!@proxy.mlp.com:3128', 
                     'https': 'https://thzhang:Citadel190430!@proxy.mlp.com:3128'}}
proxies = {'http': 'http://thzhang:Citadel190430!@proxy.mlp.com:3128', 
          'https': 'https://thzhang:Citadel190430!@proxy.mlp.com:3128'}

CHROMEOPTIONS = webdriver2.ChromeOptions()
CHROMEOPTIONS.add_experimental_option("prefs", {"download.default_directory":"/home/ubuntu/Downloads/rrc_temp",
                                                "download.prompt_for_download": False,
                                                "download.directory_upgrade": True,
                                                "safebrowsing.enabled": True})
#CHROMEOPTIONS.add_argument('headless')
CHROMEOPTIONS.add_argument('--proxy-server=%s' % 'http://thzhang:Citadel190430!@proxy.mlp.com:3128')
CHROME_PATH=r"N:\python_scripts\chromedriver.exe"
CAPABILITIES={'chromeOptions':{'useAutomationExtension': False}}


driver2 = webdriver2.Chrome(CHROME_PATH, seleniumwire_options=options, desired_capabilities=CAPABILITIES, options=CHROMEOPTIONS)


### login

driver2.get('https://corporate-access.huaxing.com/welcome')

element = WebDriverWait(driver2, 90).until(
        EC.presence_of_element_located((By.XPATH , '//input[@placeholder="Please enter your email"]'))
    )

elem = driver2.find_element_by_xpath('//input[@placeholder="Please enter your email"]')
elem.send_keys('thomas.zhang@mlp.com')
elem = driver2.find_element_by_xpath('//input[@placeholder="Please enter your password"]')
elem.send_keys('Citadel190430!')
elem = driver2.find_element_by_xpath('//button[@type="submit"]')
elem.click()

time.sleep(60)


### scrape meetings

o_huaxing = pd.DataFrame()



for i in range(1, 2520):
    if i < 2402:
        continue
    
    
    driver2.get('https://corporate-access.huaxing.com/event/' + str(i))
    
    if 'Sorry, the page you visited does not exist.' in driver2.page_source:
        continue
    
    try:
        status_date = ''
   
     element = WebDriverWait(driver2, 10).until(
            EC.presence_of_element_located((By.XPATH , '//div[@class="antd-pro-pages-event-popular-events-detail-style-con"]//div[@class="ant-tabs-nav-container"]//div[@role="tab"]'))
        )
        status_date = 'container'
    except:
        if 'Sorry, the page you visited does not exist.' in driver2.page_source:
            continue
        else:
            element = WebDriverWait(driver2, 5).until(
                EC.presence_of_element_located((By.XPATH , '//div[@class="antd-pro-pages-event-popular-events-detail-style-con"]//div[@class="ant-tabs-nav ant-tabs-nav-animated"]//div[@role="tab"]'))
            )
            status_date = 'animated'
        
    if status_date == 'container':
        elem = driver2.find_elements_by_xpath('//div[@class="antd-pro-pages-event-popular-events-detail-style-con"]//div[@class="ant-tabs-nav-container"]//div[@role="tab"]')
        t_date = [e.text for e in elem]
        t_len = len(t_date)
    elif status_date == 'animated':
        elem = driver2.find_elements_by_xpath('//div[@class="antd-pro-pages-event-popular-events-detail-style-con"]//div[@class="ant-tabs-nav ant-tabs-nav-animated"]//div[@role="tab"]')
        t_date = [e.text for e in elem]
        t_len = len(t_date)
    elem = driver2.find_elements_by_xpath('//div[@class="antd-pro-pages-event-popular-events-detail-style-title"]')
    t_title = ['|@|'.join([e.text for e in elem if e.text != ''])] * t_len
    elem = driver2.find_elements_by_xpath('//div[@class="antd-pro-pages-event-popular-events-detail-style-Organizer"]')
    t_organizer = ['|@|'.join([e.text for e in elem if e.text != ''])] * t_len
    elem = driver2.find_elements_by_xpath('//span[@class="antd-pro-pages-event-popular-events-detail-style-eventType"]')
    t_event_type = ['|@|'.join([e.text for e in elem if e.text != ''])] * t_len

    elem = driver2.find_elements_by_xpath('//div[@class="antd-pro-pages-event-popular-events-detail-style-meetingdetail"]//div[@class="ant-row"]//div[@class="antd-pro-components-show-info-index-value undefined "]')
    t_address = [elem[0].text] * t_len
    try:
        t_meet_method = [elem[1].text] * t_len
    except IndexError:
        t_meet_method = [np.nan] * t_len
    elem = driver2.find_elements_by_xpath('//div[@class="fund-paragraph"]')
    try:
        t_desc = [elem[0].text] * t_len
    except IndexError:
        t_desc = [np.nan] * t_len
    
    t_url = ['https://corporate-access.huaxing.com/event/' +
 str(i)] * t_len
    
    o_huaxing = o_huaxing.append(pd.DataFrame(
                                             {'title': t_title,
                                              'organizer': t_organizer,
                                              'event_type': t_event_type,
                                              'event_date_str': t_date,
                                              'address': t_address,
                                              'meet_method': t_meet_method,
                                              'desc': t_desc}
                                             ), 
                                ignore_index = True)
    
    print (len(o_huaxing), end=',')

driver2.quit()

o_huaxing.to_parquet(r'S:\Data\China Data Hunt\Huaxing_meetings_history.parquet')


