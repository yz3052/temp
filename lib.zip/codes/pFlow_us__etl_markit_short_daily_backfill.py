﻿#$%^&* pFlow_us__etl_markit_short_daily_backfill.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr  7 10:35:49 2023

@author: thzhang
"""



import pandas as pd

from datetime import datetime

import os
import gc




from sqlalchemy import create_engine
import urllib
engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=TZDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))







            
### get daily - us early
# ['DataDate', 'DXL Identifier', 'ISIN', 'SEDOL', 'CUSIP', 'Quick', 'Stock Description', 
# 'Market Area (Country level)', 'Dvd Req', 'Record Type', 'Total Demand Value', 
# 'Total Demand Quantity', 'BO Inventory Value', 'BO Inventory Quantity', 
# 'BO On Loan Value', 'BO On Loan Quantity', 'Utilisation', 'Broker Demand Value', 
# 'Broker Demand Quantity', 'SL Tenure', 'Open Loan Transactions', 'Inventory Rows', 
# 'Active Agents', 'Inactive Agents', 'Active Brokers', 'BO Inventory Value Add', 
# 'BO Inventory Quantity Add', 'BO Inventory Value New', 'BO Inventory Quantity New', 
# 'BO Inventory Value Removed', 'BO Inventory Quantity Removed', 
# 'BO Inventory Value Increase', 'BO Inventory Quantity Increase', 
# 'BO Inventory Value Decrease', 'BO Inventory Quantity Decrease', 
# 'BO On Loan Value Add', 'BO On Loan Quantity Add', 'BO On Loan Value New', 
# 'BO On Loan Quantity New', 'BO On Loan Value Removed', 'BO On Loan Quantity Removed', 
# 'BO On Loan Value Increase', 'BO On Loan Quantity Increase', 
# 'BO On Loan Value Decrease', 'BO On Loan Quantity Decrease', 'Broker Demand Value Add', 
# 'Broker Demand Quantity Add', 'Broker Demand Value New', 'Broker Demand Quantity New', 
# 'Broker Demand Value Removed', 'Broker Demand Quantity Removed', 
# 'Broker Demand Value Increase', 'Broker Demand Quantity Increase', 
# 'Broker Demand Value Decrease', 'Broker Demand Quantity Decrease', 'VWAF Score 1 Day', 
# 'VWAF 1 Day Change', 'VWAF Score 7 Day', 'VWAF 7 Day Change', 'VWAF Score 30 Day', 
# 'VWAF 30 Day Change', 'VWAF Score 60 Day', 'VWAF 60 Day Change', 'VWAF Score All', 
# 'VWAF All Change', 'Active BO Inventory Value', 'Active BO Inventory Quantity', 
# 'Active Available BO Inventory Value', 'Active Available BO Inventory Quantity', 
# 'Active Utilisation', 'Active Utilisation by Quantity', 
# 'Active Available BO Inventory Ratio', 'Utilisation by Quantity', 'SAF', 'SAR', 
# 'DCBS', 'DNS', 'DIPS', 'DIMV', 'DPS'
, 'DSS', 'BO Inventory Value Concentration Ratio', 
# 'BO Inventory Value Rank 1 Market Share', 'BO Inventory Value Rank 2 Market Share', 
# 'BO On Loan Value Concentration Ratio', 'BO On Loan Value Rank 1 Market Share', 
# 'BO On Loan Value Rank 2 Market Share', 'Broker Demand Value Concentration Ratio', 
# 'Broker Demand Value Rank 1 Market Share', 'Broker Demand Value Rank 2 Market Share', 
# 'BBGID', 'BB_TICKER', 'Short Loan Quantity', 'Short Loan Value', 
# 'Indicative Fee', 'Indicative Rebate', '1 Day Indicative Fee', 
# '1 Day Indicative Rebate', '7 Day Indicative Fee', '7 Day Indicative Rebate']



t_early_us = []
root = '/dat/mdwarehouse/public/Markit/ShortData'
for yyyy in ['2011', '2012', '2013','2014','2015','2016', '2017', '2018', 
             '2019', '2020', '2021', '2022', '2023']:
    print(yyyy)
    for mon in os.listdir(os.path.join(root, yyyy)):
        for day in os.listdir(os.path.join(root, yyyy, mon)):
            for f in os.listdir(os.path.join(root, yyyy, mon, day)):
                if 'AmerEqty' in f and 'Early' in f and f.endswith('zip'):
                    t_data = pd.read_csv(os.path.join(root, yyyy, mon, day, f),sep='\t')
                    t_cols = t_data.columns.tolist()
                    t_data['DataDate'] = pd.to_datetime(yyyy+'-'+mon+'-'+day)
                    t_data = t_data[['DataDate']+t_cols]
                    print('.',end='')
                    t_early_us.append(t_data)
t_early_us = pd.concat(t_early_us, axis = 0)


t_early_us['CUSIP'] = t_early_us['CUSIP'].astype(str)
cols_early = t_early_us.columns.tolist()
t1 = t_early_us.head(0)
t1.to_sql('markit_shortdata_us_early', con = engine, index = False)

t_early_us.to_csv('/export/datadev/cache/markit_shortdate_eod_us_early.csv', index = False, sep = '|', header=False)


# then freebcp
# freebcp [TZDBDEV].[dbo].[markit_shortdata_us_early] in /export/datadev/cache/markit_shortdate_eod_us_early.csv -S summitsqldb -U svc_tz_dbo -P 1wutRe2tidripri -c -t '|'






### get daily - us final


t_final_us = []
root = '/dat/mdwarehouse/public/Markit/ShortData'
for yyyy in ['2011', '2012', '2013','2014','2015','2016', '2017', '2018', 
             '2019', '2020', '2021', '2022', '2023']:
    print(yyyy)
    for mon in os.listdir(os.path.join(root, yyyy)):
        for day in os.listdir(os.path.join(root, yyyy, mon)):
            for f in os.listdir(os.path.join(root, yyyy, mon, day)):
                if 'AmerEqty' in f and 'Final' in f and f.endswith('zip'):
            
        t_data = pd.read_csv(os.path.join(root, yyyy, mon, day, f),sep='\t')
                    t_cols = t_data.columns.tolist()
                    t_data['DataDate'] = pd.to_datetime(yyyy+'-'+mon+'-'+day)
                    t_data = t_data[['DataDate']+t_cols]
                    print('.',end='')
                    t_final_us.append(t_data)
t_final_us = pd.concat(t_final_us, axis = 0)


t_final_us['CUSIP'] = t_final_us['CUSIP'].astype(str)
cols_final = t_final_us.columns.tolist()
t1 = t_final_us.head(0)
t1.to_sql('markit_shortdata_us_final', con = engine, index = False)
t_final_us.to_csv('/export/datadev/cache/markit_shortdate_eod_us_final.csv', index = False, sep = '|',header=False)

# then freebcp
# freebcp [TZDBDEV].[dbo].[markit_shortdata_us_final] in /export/datadev/cache/markit_shortdate_eod_us_final.csv -S summitsqldb -U svc_tz_dbo -P 1wutRe2tidripri -c -t '|'









### get intraday before 1545 EST
# DataDate = folder date on mdw

root = '/dat/mdwarehouse/public/Markit/DATA-12355/ShortInterest_Intraday/'

zfiles = []
for year in ['2023/']:    
    for month in os.listdir(root + year):
        for day in os.listdir(root + year + month):
            root_f = root + year + month + '/' + day
            for f in os.listdir(root_f):
                if f.endswith('zip'):
                    zfiles.append([root_f, f])

root2 = '/dat/mdwarehouse/public/Markit/DATA-12355/ShortInterest_Intraday/History/Unzipped_History/'

for fd in os.listdir(root2):
    for f in os.listdir(root2 + fd):
        if f.endswith('zip'):
            zfiles.append([root2 + fd, f])

zfiles = pd.DataFrame(zfiles, columns = ['p', 'f'])
zfiles['ts'] = zfiles['f'].str.split('_').str[-2] + ' ' + zfiles['f'].str.split('_').str[-1]
zfiles['ts'] = pd.to_datetime(zfiles['ts'], format = '%Y%m%d %H%M%S.zip')
zfiles['ts'] = zfiles['ts'].dt.tz_localize('UTC').dt.tz_convert('US/Eastern').dt.tz_localize(None)
zfiles['DataDate'] = pd.to_datetime(zfiles['ts'].dt.date)

zfiles = zfiles[zfiles['ts'].dt.strftime('%H%M%S')<='150000']
zfiles = zfiles.sort_values('ts').reset_index(drop = True)
zfiles = zfiles.drop_duplicates(subset = ['DataDate'], keep = 'last')


o_markit_intraday = []
for i, r in zfiles.iterrows():
    print('.', end='')    
    tdata = pd.read_csv(r['p']+'/'+r['f'], sep = '\t')
    tdata['DataDate'] = r['DataDate']    
    o_markit_intraday.append(tdata)
    
o_markit_intraday = pd.concat(o_markit_intraday, axis = 0)


o_markit_intraday = o_markit_intraday[['DataDate', 'DXLID'
, 'ISIN', 'SEDOL', 
                    'CUSIP', 'QUICK', 'InstrumentName', 'MarketArea', 'BBGID', 
                    'BB_TICKER', 'TradeQuantity', 'TradeValue', 'ReturnQuantity', 
                    'ReturnValue', 'IntradayIndicativeFee', 'IntradayIndicativeRebate']]
o_markit_intraday.to_csv('/export/datadev/cache/markit_shortdata_us_intraday.csv', index = False, sep = '|',header=False)


'''
create table market_shortdata_us_intraday (DataDate datetime, DXLID varchar(max),
ISIN varchar(max), SEDOL varchar(max), CUSIP varchar(max), QUICK float,
InstrumentName varchar(max), MarketArea varchar(max), BBGID varchar(max),
BB_TICKER varchar(max), TradeQuantity float, TradeValue float, 
ReturnQuantity float, ReturnValue float, IntradayIndicativeFee float,
IntradayIndicativeRebate float)
'''

# then freebcp
# freebcp [TZDBDEV].[dbo].[market_shortdata_us_intraday] in /export/datadev/cache/markit_shortdata_us_intraday.csv -S summitsqldb -U svc_tz_dbo -P 1wutRe2tidripri -c -t '|'




