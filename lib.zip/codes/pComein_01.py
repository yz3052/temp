﻿#$%^&* pComein_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 26 06:17:33 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os


# this tests my scraped data


### sd



i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values('datadate')
i_sd['T-1d'] = i_sd['datadate']
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d',
                 'isin_hk_uni', 'csi300_flag', 
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d',
                 'EARNYILD','GROWTH']]


### HK calendar

i_hc_cal = yu.get_sql('''select distinct tradedate_last as tdate from [CNDBPROD].[dbo].[Calendar_Dates_HC]''')
i_hc_cal = i_hc_cal.sort_values(['tdate']).reset_index(drop=True)
i_hc_cal['tdate'] = i_hc_cal['tdate'].dt.strftime('%Y%m%d')
dict_hk_cal = {}
for i,r in i_hc_cal.iterrows():
    dict_hk_cal[r['tdate']] = i
    
i_hc_next_tdate = yu.get_sql('''select datadate as datadate_p1d, tradedate_next from [CNDBPROD].[dbo].[Calendar_Dates_HC]''')


### jihuibao

f_jhb = os.listdir(r'\\vfudat04\udat04\thzhang\Downloads\jihuibao')
i_jhb = pd.concat([pd.read_parquet(os.path.join(r'\\vfudat04\udat04\thzhang\Downloads\jihuibao',f)) for f in f_jhb], sort = False)

i_jhb = i_jhb[i_jhb['ticker'].notnull()]
i_jhb = i_jhb[i_jhb['ticker'].str.contains('\d{6}')]
c_sh = i_jhb['ticker'].str[0].isin(['6'])
c_sz = i_jhb['ticker'].str[0].isin(['0','3'])
i_jhb.loc[c_sh, 'ticker'] = i_jhb.loc[c_sh, 'ticker'] + '.SH'
i_jhb.loc[c_sz, 'ticker'] = i_jhb.loc[c_sz, 'ticker'] + '.SZ'


i_jhb['start_date'] = pd.to_datetime(i_jhb['start_datetime'].dt.date)
i_jhb['T-1d'] = pd.to_datetime(i_jhb['list_scraper_ts'].dt.date)

i_jhb = i_jhb[i_jhb['list_stateName']=='预约中']

i_jhb = i_jhb.sort_values('T-1d')
i_jhb = i_jhb[['T-1d','ticker','start_date','list_stateName','showActivityTypeName','list_title']]


### wind: name mapping

i_names = yu.get_sql('''select s_info_windcode, S_INFO_NAME as name from wind.dbo.ASharePreviousName
                     union
                     select s_info_windcode, S_INFO_NAME as name from wind.dbo.AShareDescription''')
i_names = i_names.drop_duplicates()
dict_names = {}
for i,r in i_names.iterrows():
    dict_names[r['name']] = r['s_info_windcode']
list_names = list(dict_names.keys())

def match_ticker(i_str):
    if i_str[:4] 
in list_names:
        return dict_names[i_str[:4]]
    elif i_str[:3] in list_names:
        return dict_names[i_str[:3]]
    else:
        return np.nan
def match_ticker2(i_str, sep):
    if i_str.split(sep)[1].strip()[:4] in list_names:
        return dict_names[i_str.split(sep)[1].strip()[:4]]
    elif i_str.split(sep)[1].strip()[:3] in list_names:
        return dict_names[i_str.split(sep)[1].strip()[:3]]
    elif i_str.split(sep)[0].strip()[:4] in list_names:
        return dict_names[i_str.split(sep)[0].strip()[:4]]
    elif i_str.split(sep)[0].strip()[:3] in list_names:
        return dict_names[i_str.split(sep)[0].strip()[:3]]
    elif '-' in i_str:
        if i_str.split('-')[1].strip()[:4] in list_names:
            return dict_names[i_str.split('-')[1].strip()[:4]]
        elif i_str.split('-')[1].strip()[:3] in list_names:
            return dict_names[i_str.split('-')[1].strip()[:3]]
    else:
        return np.nan

### comein
# pagestart: page number
# id: main event id
# stime -> start_time_utc -> start_time_cn
# browsecount: no. of views
# membercount: number of people attending the meeting (in the "play" window)
# status 3: already happened; 210 not happened 
        
    
i_comein = yu.get_sql('''select * FROM [CNDBPROD].[dbo].[comein_events]''')
i_comein['datadate_p1d'] = pd.to_datetime(i_comein['scraper_ts_cn'].dt.date)
i_comein['start_date'] = pd.to_datetime(i_comein['start_time_cn'].dt.date)

i_comein = i_comein.drop(columns = ['logo','logowall','logoweb',
                                    'creator_sign','creator_remark','creator_occupation','creator_uname',
                                    'creator_last_visit_time','creator_fans','creator_avatar_url',
                                    'presenturl','start_time_utc','stime'])

# delete broker name from title
i_comein['creator_company'] = i_comein['creator_company'].fillna('')
i_comein['creator_company'] = i_comein['creator_company'].replace('中国国际金融股份有限公司','中金公司')


i_comein['title_x'] = i_comein.apply(lambda x: x['title'].replace(x['creator_company'][:4],''), axis=1)


# tagged tickers
i_comein['ticker'] = i_comein['title_x'].str.extract('[^0-9]([036]\d{5})[^0-9]')
c_sh = (i_comein['ticker'].notnull())&(i_comein['ticker'].str[0].isin(['6']))
c_sz = (i_comein['ticker'].notnull())&(i_comein['ticker'].str[0].isin(['0','3']))
i_comein.loc[c_sh, 'ticker'] = i_comein.loc[c_sh, 'ticker'] + '.SH'
i_comein.loc[c_sz, 'ticker'] = i_comein.loc[c_sz, 'ticker'] + '.SZ'


# no |
c_nol = (~i_c
omein['title_x'].str.contains('|', regex=False))&(~i_comein['title_x'].str.contains('｜'))&(i_comein['ticker'].isnull())

i_comein.loc[c_nol, 'ticker_nol'] = i_comein.loc[c_nol, 'title_x'].str.strip().apply(match_ticker)

# with standard |
c_withl = (i_comein['title_x'].str.contains('|', regex=False)) & (i_comein['ticker'].isnull())

i_comein.loc[c_withl, 'ticker_wstdl'] = i_comein.loc[c_withl, 'title_x'].apply(lambda x: match_ticker2(x, '|'))

# with special |
c_withl2 = (i_comein['title_x'].str.contains('｜', regex=False)) & (i_comein['ticker'].isnull())

i_comein.loc[c_withl2, 'ticker_wspl'] = i_comein.loc[c_withl2, 'title_x'].apply(lambda x: match_ticker2(x,'｜'))

# combine tickers
i_comein.loc[i_comein['ticker'].isnull(),'ticker'] = i_comein.loc[i_comein['ticker'].isnull(),'ticker_wstdl']
i_comein.loc[i_comein['ticker'].isnull(),'ticker'] = i_comein.loc[i_comein['ticker'].isnull(),'ticker_nol']
i_comein.loc[i_comein['ticker'].isnull(),'ticker'] = i_comein.loc[i_comein['ticker'].isnull(),'ticker_wspl']
#i_comein[['id','title','ticker']].to_csv(r'S:\Data\China Data Hunt\cache\comein_ticker_tagging.csv') ###!!!
#i_comein = pd.read_csv(r'S:\Data\China Data Hunt\cache\comein_ticker_tagging.csv') ###!!!

# select tagged rows
i_comein = i_comein[i_comein['ticker'].notnull()]





### combine (jihuibao)


icom = pd.merge_asof(i_sd, i_jhb, by = 'ticker', on = 'T-1d')
icom = icom.sort_values(['ticker','datadate'])

icom['jhb_sgnl'] = np.nan
c1 = (icom['start_date'] - icom['datadate']).dt.days.between(0, 14)
icom.loc[c1, 'jhb_sgnl'] = 1

icom['jhb_sgnl'] = icom.groupby('ticker')['jhb_sgnl'].ffill(limit=10)

#yu.create_cn_decay(icom, 'jhb_sgnl')
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2022-01-01')].\
            dropna(subset=['jhb_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jhb_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # -1.35 / -1.57


### combine (comein)

icom = i_comein.merge(i_hc_next_tdate, on = ['datadate_p1d'], how = 'left')
icom = icom.rename(columns={'tradedate_next':'datadate_next_tdate'})
icom = icom.merge(i_hc_next_tdate.rename(columns={'datadate_p1d':'start_date'}), 
                  left_on = ['start_date'], right_on = ['start_date'], how = 'left')
icom = icom.rename(columns={'tradedate_next':'start_date_next_tdate'})

icom['td2m'] = icom.apply(lambda x: dict_hk_cal[x['start_date_next_tdate'].strftime('%Y%m%d')]-\
                          dict_hk_cal[x['datadate_next_tdate'].strftime('%Y%m%d'
)], axis = 1)
icom = icom[icom['td2m']>=2]


icom2 = i_sd.merge(icom, on = ['datadate_p1d','ticker'], how = 'left')
icom2 = icom2.sort_values(['ticker','datadate'])


### naive: long before events

icom2['naive_sgnl'] = np.nan
icom2.loc[icom2['td2m']>2, 'naive_sgnl'] = 1

icom2['naive_sgnl'] = icom2.groupby('ticker')['naive_sgnl'].ffill(limit=10)


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2021-12-31')].\
            dropna(subset=['naive_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'naive_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #3.28/2.36, 6.69bp/d, 2.8e6

#2.87/1.99,5.84bp,2m between 2021.7 and 2021.11

