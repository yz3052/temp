﻿#$%^&* pCNINFO_unlock_sina.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 10 20:34:47 2022

@author: thzhang
"""

import requests
from bs4 import BeautifulSoup

import pandas as pd
import numpy as np
import pWIND_util as pw
import yz.util as yu

### scrape data

proxies = {'http':'http://thzhang:Citadel580227!@proxy.mlp.com:3128','https':'https://thzhang:Citadel580227!@proxy.mlp.com:3128'} 

COOKIES = 'UOR=www.google.com,vip.stock.finance.sina.com.cn,; SINAGLOBAL=174.138.224.248_1614112715.34860; visited_uss=gb_ocft; __gads=ID=134a1028a21a571e-22e07990c0c600da:T=1614913106:RT=1614913106:S=ALNI_MY5NC9W6D3sC2vkiW5JChr0R63XUw; U_TRS1=000000f8.acde7ee7.6047c976.1adadb4f; SGUID=1620841599622_17018594; UM_distinctid=17c3bc35af39f8-01e9ee2b3d7ad-73e356b-1fa400-17c3bc35af4a27; SR_SEL=1_511; MONEY-FINANCE-SINA-COM-CN-WEB5=; Apache=204.212.175.30_1638005823.773362; ULV=1638005838618:26:2:2:204.212.175.30_1638005823.773362:1637608603624; BCSI-CS-a936f1a83c02d08a=2; U_TRS2=0000001e.74629a3a.61e35fc4.e3fddc92; visited_funds=159863; FIN_ALL_VISITED=sz399986%2Csh000919; FINA_V_S_2=sh000300,sz399986,sh000919,sz399441,sz399987,sz980017,sz399995,sh000860,sz399976,sh000688,sz399975,sz399997; _s_upa=26; close_farmgamepop=1'
headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'zh-CN,zh;q=0.9',
    'Cache-Control': 'max-age=0',
    'Cookie': COOKIES,
    'Host': 'vip.stock.finance.sina.com.cn',
    'Proxy-Connection': 'keep-alive',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.90 Safari/537.36',
}

o_unlock = []

for i in range(150, 738):
    print (i)

    url = 'http://vip.stock.finance.sina.com.cn/q/go.php/vInvestConsult/kind/xsjj/index.phtml?bdate=2022-01-27&edate=2022-02-26&showall=%CF%D4%CA%BE%C8%AB%B2%BF&p=' + str(i)
    resp = requests.get(url, headers=headers, proxies=proxies, verify = False)
    if resp.status_code != 200:
        print('获取uniqid失败')
        break
    
    soup = BeautifulSoup(resp.text, 'html.parser')
    t_data = pd.read_html( str(soup.find('table', class_='list_table')) )[0]
    t_data['page'] = i
    o_unlock.append(t_data)

o_unlock = pd.concat(o_unlock, axis = 0)
o_unlock.to_parquet(r'S:\TZ\China Data Hunt\cache\pCNINFO_unlock_sina_o_unlock.parquet')

o_unlock = pd.read_parquet(r'S:\TZ\C
hina Data Hunt\cache\pCNINFO_unlock_sina_o_unlock.parquet')
o_unlock.columns = ['ticker','name','frcst_date','unlock_shares','unlock_rmb','batch','datadate','page']
o_unlock['ticker'] = o_unlock['ticker'].astype(str).str.zfill(6)
c_sh = o_unlock['ticker'].str[0].isin(['6'])
c_sz = o_unlock['ticker'].str[0].isin(['0','3'])
o_unlock.loc[c_sh, 'ticker'] = o_unlock.loc[c_sh, 'ticker'] + '.SH'
o_unlock.loc[c_sz, 'ticker'] = o_unlock.loc[c_sz, 'ticker'] + '.SZ'
o_unlock['frcst_date'] = pd.to_datetime(o_unlock['frcst_date'])
o_unlock['datadate'] = pd.to_datetime(o_unlock['datadate'])
o_unlock['unlock_shares'] = o_unlock['unlock_shares'] * 10000




### calculate metrics

o_sum = []

for dt in pd.date_range(start='2016-01-01', end='2021-12-31'):
    print(dt.strftime('%Y%m%d'), end = ' ')
        
    t_frcst_unlock = o_unlock[(o_unlock['datadate']<=dt) & (o_unlock['frcst_date']>dt+pd.to_timedelta('3 days'))]
    t_frcst_unlock = t_frcst_unlock.sort_values(['ticker','frcst_date'])
    t_frcst_unlock['datadate'] = dt

    # get data for the next unlock 
    # days to the next unlock
    # unlock shares of the next unlock 
    t_frcst_unlock_n1 = t_frcst_unlock.groupby('ticker').head(1)
    t_frcst_unlock_n1['flag_n1'] = 1
    t_frcst_unlock_n1['days2n1'] = (t_frcst_unlock_n1['frcst_date']-t_frcst_unlock_n1['datadate']).dt.days
    t_frcst_unlock_n1['unlock_shares_n1'] = t_frcst_unlock_n1['unlock_shares']
    
    s_n1 = t_frcst_unlock_n1[['ticker','unlock_shares_n1','days2n1']]
    
    # get data for the 2nd next unlock 
    # days to the 2nd next unlock 
    # unlock shares of the 2nd next unlock 
    t_frcst_unlock_n2 = t_frcst_unlock.groupby('ticker').head(2)
    t_frcst_unlock_n2_cnt = t_frcst_unlock_n2.groupby('ticker')['frcst_date'].nunique().reset_index()
    t_frcst_unlock_n2_cnt = t_frcst_unlock_n2_cnt[t_frcst_unlock_n2_cnt['frcst_date']==2]
    t_frcst_unlock_n2 = t_frcst_unlock_n2[t_frcst_unlock_n2['ticker'].isin(t_frcst_unlock_n2_cnt['ticker'].tolist())]
    t_frcst_unlock_n2 = t_frcst_unlock_n2.drop_duplicates(subset='ticker', keep = 'last')
    t_frcst_unlock_n2['flag_n2'] = 1
    t_frcst_unlock_n2['days2n2'] = (t_frcst_unlock_n2['frcst_date']-t_frcst_unlock_n2['datadate']).dt.days
    t_frcst_unlock_n2['unlock_shares_n2'] = t_frcst_unlock_n2['unlock_shares']
    
    s_n2 = t_frcst_unlock_n2[['ticker','unlock_shares_n2','days2n2']]
    
    # output
    t_sum = s_n1.merge(s_n2, on = 'ticker', how = 'outer')
    t_sum['datadate'] = dt
    o_sum.appen
d(t_sum)
    
o_sum = pd.concat(o_sum, axis = 0)



### get longer-term adv

i_adv = pw.get_wind_adv()

### get sd


i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['ticker', 'datadate'])





#-------------------------------------------------------------------------
### combine

icom = i_sd.merge(o_sum, on = ['datadate','ticker'], how = 'left')
icom = icom.merge(i_adv, on = ['datadate','ticker'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])



### n1 n2 unlock, unlock/adv

icom['unlock1_dv_adv'] = icom['unlock_shares_n1'].divide(icom['adv_t130d'])
icom.loc[icom['unlock1_dv_adv'].abs()>1, 'unlock1_dv_adv'] = 1
icom['unlock2_dv_adv'] = icom['unlock_shares_n2'].divide(icom['adv_t130d'])
icom.loc[icom['unlock2_dv_adv'].abs()>1, 'unlock2_dv_adv'] = 1

c1 = icom['days2n1'].between(3, 60)
icom['unlock1_dv_v_sgnl'] = np.nan
icom.loc[c1, 'unlock1_dv_v_sgnl'] = - icom.loc[c1, 'unlock1_dv_adv']

c1 = icom['days2n2'].between(3, 60)
icom['unlock2_dv_v_sgnl'] = np.nan
icom.loc[c1, 'unlock2_dv_v_sgnl'] = - icom.loc[c1, 'unlock2_dv_adv']

icom['unlock12_dv_v_sgnl'] = icom[['unlock1_dv_v_sgnl','unlock2_dv_v_sgnl']].min(axis=1)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['unlock12_dv_v_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'unlock12_dv_v_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #sd 3.07 /2.47, 1.2m, 21m gmv
