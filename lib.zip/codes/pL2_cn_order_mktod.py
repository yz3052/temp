﻿#$%^&* pL2_cn_order_mktod.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Apr  1 05:31:06 2022

@author: thzhang
"""





import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine




### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])



### mkt order

i_mkt_od = yu.get_q("get `:/export/datadev/Data/SHSZ/ORDER_metrics/sz_mkt_order_metrics")

i_mkt_od['code'] = i_mkt_od['code'].str.decode('utf8')
c_sh = i_mkt_od['code'].str[0].isin(['6'])
c_sz = i_mkt_od['code'].str[0].isin(['0','3'])
i_mkt_od.loc[c_sh, 'ticker'] = i_mkt_od.loc[c_sh, 'code'] + '.SH'
i_mkt_od.loc[c_sz, 'ticker'] = i_mkt_od.loc[c_sz, 'code'] + '.SZ'
i_mkt_od['datadate'] = pd.to_datetime(i_mkt_od['date'])
i_mkt_od = i_mkt_od.sort_values(['ticker', 'datadate'])

i_mkt_od['mkt_odB1_pct'] = i_mkt_od['vB_mkt1_tot'].divide(i_mkt_od['vB_tot'])
i_mkt_od['mkt_odB1_pct_t20d'] = i_mkt_od.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['mkt_odB1_pct'].mean().values
i_mkt_od['mkt_odN1_pct'] = (i_mkt_od['vB_mkt1_tot']-i_mkt_od['vS_mkt1_tot']).divide(i_mkt_od['vB_tot']+i_mkt_od['vS_tot'])
i_mkt_od['mkt_odN1_pct_t20d'] = i_mkt_od.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['mkt_odN1_pct'].mean().values

i_mkt_od['mkt_odBU_pct'] = i_mkt_od['vB_mktU_tot'].divide(i_mkt_od['vB_tot'])

i_mkt_od['mkt_odB1U_pct'] = (i_mkt_od['vB_mkt1_tot']+i_mkt_od['vB_mktU_tot']).divide(i_mkt_od['vB_tot'])
i_mkt_od['mkt_odB1U_pct_t20d'] = i_mkt_od.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['mkt_odB1U_pct'].mean().values
i_mkt_od['mkt_odS1U_pct'] = (i_mkt_od['vS_mkt1_tot']+i_mkt_od['vS_mktU_tot']).divide(i_mkt_od['vS_tot'])
i_mkt_od['mkt_odBS1U_pct'] = (i_mkt_od['vB_mkt1_tot']+i_mkt_od['vB_mktU_tot']+i_mkt_od['vS_mkt1_tot']+i_mkt_od['vS_mktU_tot']).divide(i_mkt_od['vB_tot']+i_mkt_od['vS_tot'])

i_mkt_od['mkt_odB1U_mktO_pct'] = (i_mkt_od['vB_mkt1_mktO_tot']+i_mkt_od['vB_mktU_mktO_tot']).divide(i_mkt_od['vB_mktO_tot'])
i_mkt_od['mkt_odB1U_mktO_pct_t20d'] = i_mkt_od.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['mkt_odB1U_mktO_pct'].mean().values
i_mkt_od['mkt_odN1U_mktO_pct'] = (i_mkt_od['vB_mkt1_mktO_tot']+i_mkt_od['vB_mktU_mktO_tot']-i_mkt_od['vS_mkt1_mktO_tot']-i_mkt_od['vS_mktU_mktO_tot']).divide(i_mkt_od['vB_mktO_tot']+i_mkt_od['vS_mktO_tot'])




### combine

icom = i_sd.merge(i_mkt_od, on = ['ticker', '
datadate'], how = 'left')
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']

icom['SIZE_5bk'] = icom.groupby('datadate')['SIZE'].apply(lambda x: yu.pdqcut(x,bins=10)).values

# B-S doesn't work. Higher B lower return?

icom['mkt_odB1_pct_bk'] = icom.groupby('datadate')['mkt_odB1_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['mkt_odB1_pct_bk'], 'mkt_odB1_pct') # less mono: +3 -4 +1

icom['mkt_odB1_pct_orth'] = icom.groupby('datadate')[COLS+['mkt_odB1_pct']].apply(lambda x: yu.orthogonalize_cn(x['mkt_odB1_pct'], x[COLS])).values
icom['mkt_odB1_pct_orth_bk'] = icom.groupby('datadate')['mkt_odB1_pct_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['mkt_odB1_pct_orth_bk'], 'mkt_odB1_pct_orth') # mono: +3 -2
icom['mkt_odB1_pct_mcbk'] = icom.groupby(['datadate', 'SIZE_5bk'])['mkt_odB1_pct'].apply(lambda x: yu.pdqcut(x,bins=5)).values
yu.create_cn_3x3(icom, ['mkt_odB1_pct_mcbk'], 'mkt_odB1_pct') # mono: +3 -2

icom['mkt_odN1_pct_bk'] = icom.groupby('datadate')['mkt_odN1_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['mkt_odN1_pct_bk'], 'mkt_odN1_pct') # random
icom['mkt_odB1U_pct_bk'] = icom.groupby('datadate')['mkt_odB1U_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['mkt_odB1U_pct_bk'], 'mkt_odB1U_pct') # less mono: +2 -4 +0.5
icom['mkt_odB1U_pct_mcbk'] = icom.groupby(['datadate', 'SIZE_5bk'])['mkt_odB1U_pct'].apply(lambda x: yu.pdqcut(x,bins=5)).values
yu.create_cn_3x3(icom, ['mkt_odB1U_pct_mcbk'], 'mkt_odB1U_pct') # mono: +3 -2

icom['mkt_odN1U_pct_bk'] = icom.groupby('datadate')['mkt_odN1U_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['mkt_odN1U_pct_bk'], 'mkt_odN1U_pct') # random
icom['mkt_odB1U_mktO_pct_bk'] = icom.groupby('datadate')['mkt_odB1U_mktO_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['mkt_odB1U_mktO_pct_bk'], 'mkt_odB1U_mktO_pct') # less mono: +2 -5 +2

icom['mkt_odB1U_mktO_pct_mcbk'] = icom.groupby(['datadate', 'SIZE_5bk'])['mkt_odB1U_mktO_pct'].apply(lambda x: yu.pdqcut(x,bins=5)).values
yu.create_cn_3x3(icom, ['mkt_odB1U_mktO_pct_mcbk'], 'mkt_odB1U_mktO_pct') # mono: +2 -1.5

icom['mkt_odN1U_mktO_pct_bk'] = icom.groupby('datadate')['mkt_odN1U_mktO_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['mkt_odN1U_mktO_pct_bk'], 'mkt_odN1U_mktO_pct') # random
icom['mkt_odS1U_pct_bk'] = icom.groupby('
datadate')['mkt_odS1U_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['mkt_odS1U_pct_bk'], 'mkt_odS1U_pct') # less mono: +2 -2.5 0
icom['mkt_odBU_pct_bk'] = icom.groupby('datadate')['mkt_odBU_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom[icom['mkt_odBU_pct_bk']!=1], ['mkt_odBU_pct_bk'], 'mkt_odBU_pct') # mono, but low sample

icom['mkt_odBU_x0_pct'] = icom['mkt_odBU_pct'].replace(0, np.nan)
icom['mkt_odBU_x0_pct_bk'] = icom.groupby('datadate')['mkt_odBU_x0_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['mkt_odBU_x0_pct_bk'], 'mkt_odBU_x0_pct') # less mono with low t: +2 -4 0 -5
icom['mkt_odBS1U_pct_bk'] = icom.groupby('datadate')['mkt_odBS1U_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['mkt_odBS1U_pct_bk'], 'mkt_odBS1U_pct') # less mono: +1 +4 -2 +1

icom['mkt_odBS1U_pct_orth'] = icom.groupby('datadate')[COLS+['mkt_odBS1U_pct']].apply(lambda x: yu.orthogonalize_cn(x['mkt_odBS1U_pct'], x[COLS])).values
icom['mkt_odBS1U_pct_orth_bk'] = icom.groupby('datadate')['mkt_odB1_pct_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['mkt_odBS1U_pct_orth_bk'], 'mkt_odBS1U_pct_orth') # mono: +3 -2


icom['mkt_odB1U_pct_mcbk'] = icom.groupby(['datadate', 'SIZE_5bk'])['mkt_odB1U_pct'].apply(lambda x: yu.pdqcut(x,bins=5)).values
yu.create_cn_3x3(icom, ['mkt_odB1U_pct_mcbk'], 'mkt_odB1U_pct') # mono: +3 -2

icom['mkt_odB1U_pct_sgnl'] = -icom.groupby(['datadate', 'SIZE_5bk'])['mkt_odB1U_pct'].apply(yu.uniformed_rank).values
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['mkt_odB1U_pct_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mkt_odB1U_pct_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.71 / -11

icom['mkt_odB1U_pct_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['mkt_odB1U_pct'].mean().values
icom['mkt_odB1U_pct_t20d_sgnl'] = -icom.groupby(['datadate','SIZE_5bk'])['mkt_odB1U_pct_t20d'].apply(yu.uniformed_rank).values
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['mkt_odB1U_pct_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mkt_odB1U_pct_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # -0.19 / -28

