﻿#$%^&* pWIND_investormeeting_yuediaoyan.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue May 18 21:50:45 2021

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu


# this script includes data scraped from jihuibao


### get yuediaoyan data

i_yuediaoyan = pd.read_parquet(r"S:\Data\China Data Hunt\yuediaoyan_history_20210516.parquet")


i_yuediaoyan.columns = ['id', 'scraper_ts', 'public_comp', 'no_outof', 'planned_time', 
                        'deadline', 'location', 'add', 'host', 'contact', 'fee', 'dinner', 'url', 'ind' ]
i_yuediaoyan = i_yuediaoyan[(i_yuediaoyan['public_comp']!='()') & (i_yuediaoyan['public_comp'].notnull())]
i_yuediaoyan['ticker'] = i_yuediaoyan['public_comp'].str.extract('(\d{6})')
i_yuediaoyan = i_yuediaoyan[i_yuediaoyan['ticker'].notnull()]
c_sz = i_yuediaoyan['ticker'].str[0].isin(['0','3'])
c_sh = i_yuediaoyan['ticker'].str[0].isin(['6'])
i_yuediaoyan.loc[c_sz, 'ticker'] = i_yuediaoyan.loc[c_sz, 'ticker'] + '.SZ'
i_yuediaoyan.loc[c_sh, 'ticker'] = i_yuediaoyan.loc[c_sh, 'ticker'] + '.SH'
i_yuediaoyan = i_yuediaoyan[c_sz | c_sh]
i_yuediaoyan['comp_name'] = i_yuediaoyan['public_comp'].str.split('(').str[0]
i_yuediaoyan['planned_date'] = pd.to_datetime(i_yuediaoyan['planned_time'].str[:10])
i_yuediaoyan['deadline_date'] = pd.to_datetime(i_yuediaoyan['deadline'].str[:10])
i_yuediaoyan['participant_no'] = pd.to_numeric(i_yuediaoyan['no_outof'].str.split('/').str[0])
i_yuediaoyan['quota_no'] = pd.to_numeric(i_yuediaoyan['no_outof'].str.split('/').str[1])
i_yuediaoyan['datadate_3'] = i_yuediaoyan['deadline_date'] - pd.to_timedelta('3 days')
i_yuediaoyan['flag_3'] = 1
i_yuediaoyan['datadate_5'] = i_yuediaoyan['deadline_date'] - pd.to_timedelta('5 days')
i_yuediaoyan['flag_5'] = 1
i_yuediaoyan['datadate_10'] = i_yuediaoyan['deadline_date'] - pd.to_timedelta('10 days')
i_yuediaoyan['flag_10'] = 1
c_is_gaoguan = i_yuediaoyan['host'].str.contains('')
c_excl_list = i_yuediaoyan['host'].str.contains('')
i_yuediaoyan.loc[c_excl_list, 'is_gaoguan'] = 0
i_yuediaoyan.loc[c_is_gaoguan, 'is_gaoguan'] = 1

i_yuediaoyan = i_yuediaoyan[['ticker', 'comp_name', 'planned_date', 'deadline_date', 
                             'quota_no', 'participant_no', 'datadate_3', 'datadate_5',
                             'datadate_10', 'flag_3', 'flag_5', 'flag_10','is_gaoguan']]
i_yuediaoyan = i_yuediaoyan.sort_values('deadline_date')


### get yuediaoyan dianhua huiyi data
i_yuediaoyan2 = pd.read_parque
t(r"S:\Data\China Data Hunt\yuediaoyan_history2_20210519.parquet")
i_yuediaoyan2.columns = ['id', 'scraper_ts', 'meeting_name', 'host', 'planned_time','phone_number','pw','participants','public_company','url']
i_yuediaoyan2 = i_yuediaoyan2[i_yuediaoyan2['planned_time'].notnull()]
i_yuediaoyan2 = i_yuediaoyan2[i_yuediaoyan2['public_company'].notnull()]
i_yuediaoyan2['ticker'] = i_yuediaoyan2['public_company'].str.extract('\((\d{6})\)')
i_yuediaoyan2 = i_yuediaoyan2[i_yuediaoyan2['ticker'].notnull()]
c_sz = i_yuediaoyan2['ticker'].str[0].isin(['0','3'])
c_sh = i_yuediaoyan2['ticker'].str[0].isin(['6'])
i_yuediaoyan2.loc[c_sz, 'ticker'] = i_yuediaoyan2.loc[c_sz, 'ticker'] + '.SZ'
i_yuediaoyan2.loc[c_sh, 'ticker'] = i_yuediaoyan2.loc[c_sh, 'ticker'] + '.SH'
i_yuediaoyan2['planned_time'] = i_yuediaoyan2['planned_time'].str.replace('\t','').str.replace('\r','').str.strip()
i_yuediaoyan2['planned_date'] = pd.to_datetime(i_yuediaoyan2['planned_time'].str[:10])
i_yuediaoyan2['ym'] = i_yuediaoyan2['planned_date'].dt.year*100 + i_yuediaoyan2['planned_date'].dt.month
i_yuediaoyan2['ym'] = i_yuediaoyan2['ym'].astype(str)
c_earning = i_yuediaoyan2['meeting_name'].str.contains('')
i_yuediaoyan2 = i_yuediaoyan2[~c_earning]
c_irrlevant = i_yuediaoyan2['meeting_name'].str.contains('')
i_yuediaoyan2 = i_yuediaoyan2[~c_irrlevant]
i_yuediaoyan2.groupby('ym')['ticker'].count().plot()
i_yuediaoyan2['datadate_3'] = i_yuediaoyan2['planned_date'] - pd.to_timedelta('3 days')
i_yuediaoyan2['flag_3'] = 1
i_yuediaoyan2 = i_yuediaoyan2[['ticker', 'planned_date', 'datadate_3', 'flag_3', 'ym', 'meeting_name', 'participants']]
i_yuediaoyan2 = i_yuediaoyan2.sort_values(['datadate_3'])

###


### sd

i_sd_fx = pw.get_china_sd(fx_adj = True)
i_sd_map_fx = i_sd_fx[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP+1d','BarrRet_SRISK+1d','RawRet+1d','fxRet_SRISK+1d','fxRet_CLIP+1d','isin_hk_uni']]
i_sd_map_fx = i_sd_map_fx.sort_values('datadate')

i_sd = pw.get_china_sd()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP+1d','BarrRet_SRISK+1d','RawRet+1d','fxRet_SRISK+1d','fxRet_CLIP+1d','isin_hk_uni']]
i_sd_map = i_sd_map.sort_values('datadate')


### verify if yuediaoyan data can be verified in published diaoyan data


### combine

icom = pd.merge_asof(i_sd_map, i_yuediaoyan[['ticker','datadate_3','flag_3', 'participant_no']].rename(columns={'participant_no':'participant_no_3'}), 
    
                 by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_3'], tolerance = pd.to_timedelta('3 days') )

icom = pd.merge_asof(icom, i_yuediaoyan[['ticker','datadate_5','flag_5', 'participant_no']].rename(columns={'participant_no':'participant_no_5'}), 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_5'], tolerance = pd.to_timedelta('3 days') )

icom = pd.merge_asof(icom, i_yuediaoyan[['ticker','datadate_10','flag_10', 'participant_no']].rename(columns={'participant_no':'participant_no_10'}), 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_10'], tolerance = pd.to_timedelta('3 days') )

icom = icom.sort_values(['ticker', 'datadate'])

### combine fx

icomfx = pd.merge_asof(i_sd_map_fx, i_yuediaoyan[['ticker','datadate_3','flag_3', 'participant_no']].rename(columns={'participant_no':'participant_no_3'}), 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_3'], tolerance = pd.to_timedelta('3 days') )

icomfx = pd.merge_asof(icomfx, i_yuediaoyan[['ticker','datadate_5','flag_5', 'participant_no']].rename(columns={'participant_no':'participant_no_5'}), 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_5'], tolerance = pd.to_timedelta('3 days') )

icomfx = pd.merge_asof(icomfx, i_yuediaoyan[['ticker','datadate_10','flag_10', 'participant_no']].rename(columns={'participant_no':'participant_no_10'}), 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_10'], tolerance = pd.to_timedelta('3 days') )

icomfx = icomfx.sort_values(['ticker', 'datadate'])


### combine phone call

icomfx_call = pd.merge_asof(i_sd_map_fx, i_yuediaoyan2[['ticker','datadate_3','flag_3']].rename(columns={'participant_no':'participant_no_3'}), 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_3'], tolerance = pd.to_timedelta('3 days') )

icomfx_call = icomfx_call.sort_values(['ticker', 'datadate'])

#------------------------------------------------------------------------------
### Idea 1: test in-person meetings
#------------------------------------------------------------------------------



### long 3 days before, hold 3 days
icom2 = icom.copy()
icom2['flag_3'] = icom2.groupby('ticker')['flag_3'].ffill(limit = 3)

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['flag_3','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),

        'flag_3','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 0.1 / -0.29

### long 3 days before, hold 6 days
icom2 = icom.copy()
icom2['flag_3'] = icom2.groupby('ticker')['flag_3'].ffill(limit = 6)

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['flag_3','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'flag_3','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 0.28 / -0.01

### long 5 days before, hold 3 days
icom2 = icom.copy()
icom2['flag_5'] = icom2.groupby('ticker')['flag_5'].ffill(limit = 3)

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['flag_5','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'flag_5','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 1.11 / 0.69

### long 5 days before, hold 3 days - fx adjusted
icom2 = icomfx.copy()
icom2['flag_5'] = icom2.groupby('ticker')['flag_5'].ffill(limit = 3)

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['flag_5','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'flag_5','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 1.96 / 1.4




### long 5 days before, hold 5 days
# this tells us that ... once meeting happens, minimize holding period! try to get our before meeting happens
icom2 = icom.copy()
icom2['flag_5'] = icom2.groupby('ticker')['flag_5'].ffill(limit = 5)

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['flag_5','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'flag_5','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 0.76 / 0.43




### long 10 cdays before, hold 10 tdays
icom2 = icom.copy()
icom2['flag_10'] = icom2.groupby('ticker')['flag_10'].ffill(limit = 10)

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['flag_10','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'flag_10','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 1.95 / 1.74


### long 10 cdays before, hold 6 tdays
icom2 = icom.copy()
icom2['flag_10'] = icom2.groupby('ticker')['flag_10'].ffill(limit = 6)

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['flag_10','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'flag_10','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 2.48 / 2.2


### long 10 cdays before, hol
d 6 tdays, using fx-adj returns ###???
icom2 = icomfx.copy()
icom2['flag_10'] = icom2.groupby('ticker')['flag_10'].ffill(limit = 6)

o_1 = yu.bt_cn_2(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['flag_10','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'flag_10','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 3.09 / 2.84




### another way tp enter pst 5 days before meeting, hold 5 days
icom2 = i_sd_map.merge(i_yuediaoyan, left_on = ['datadate', 'ticker'], right_on = ['datadate_5','ticker'], how = 'left')
icom2.loc[icom2['planned_date'].notnull(), 'sgnl'] = 1
icom2['sgnl'] = icom2.groupby('ticker')['sgnl'].ffill(limit = 5)

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #1.52 / 1.2


### long 10 cdays before, hold 6 tdays, participants > 0
# excluding meetings with no partipants -> actually negative effects, we lose ~50% of the sample, that's why
icom2 = icom.copy()
icom2.loc[icom2['participant_no_10']>0, 'flag_10'] = np.nan
icom2['flag_10'] = icom2.groupby('ticker')['flag_10'].ffill(limit = 6)

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['flag_10','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'flag_10','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 2.0 / 1.75


### long 10 cdays before, hold 6 tdays, shenzhen only
# shenzhen only ->
icom2 = icom.copy()
icom2.loc[icom2['ticker'].str.contains('.SH'), 'flag_10'] = np.nan
icom2['flag_10'] = icom2.groupby('ticker')['flag_10'].ffill(limit = 6)

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['flag_10','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'flag_10','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 2.26 / 2.01, 7m / yr, 36m gmv



### long 10 cdays before, hold 6 tdays, shanghai only
# shanghai only -> shanghai drawdown heavier actually ... 
icom2 = icom.copy()
icom2.loc[icom2['ticker'].str.contains('.SZ'), 'flag_10'] = np.nan
icom2['flag_10'] = icom2.groupby('ticker')['flag_10'].ffill(limit = 6)

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['flag_10','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'flag_10','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = 
i_sd) # 1.8 / 1.59, 3m / yr, 19m gmv




#------------------------------------------------------------------------------
### Idea 2: test phone calls
#------------------------------------------------------------------------------


### long 3 cdays before, hold 3 tdays, using fx-adj returns
icom2 = icomfx_call.copy()

o_1 = yu.bt_cn_2(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['flag_3','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'flag_3','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 0.25/ 0.16


o_1[(o_1.datadate>='2018-05-01')&(o_1.datadate<='2018-12-31')].groupby('ticker')['pnl_tcost'].sum().sort_values(ascending=True).head(5)

### long 3 cdays before, hold 8 tdays, using fx-adj returns
icom2 = icomfx_call.copy()
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['flag_3'] = icom2.groupby('ticker')['flag_3'].ffill(5)
o_1 = yu.bt_cn_2(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['flag_3','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'flag_3','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 0.69 / 0.62


#------------------------------------------------------------------------------
### Idea 1: combine in-person meetings into the original WIND data
#------------------------------------------------------------------------------

