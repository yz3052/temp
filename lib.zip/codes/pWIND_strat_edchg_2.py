﻿#$%^&* pWIND_strat_edchg_2.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 22 14:31:24 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu



# earning date scheduled date and actual date changes -> signals too sparse 

### get PIT calendar
i_ed = yu.get_sql('''select * from wind.dbo.ashareissuingdatepredictBT''')
i_ed = i_ed.sort_values(['S_INFO_WINDCODE','REPORT_PERIOD','ANN_DT','BACKTIME'])
i_ed = i_ed[i_ed['REPORT_PERIOD']>='20141231']
i_ed = i_ed.rename(columns={'S_INFO_WINDCODE': 'ticker'})
i_ed['S_STM_PREDICT_ISSUINGDATE'] = i_ed.groupby(['ticker', 'REPORT_PERIOD'])['S_STM_PREDICT_ISSUINGDATE'].ffill().values
i_ed = i_ed.reset_index(drop = True)

#t1 = i_ed[(i_ed['REPORT_PERIOD']==i_ed['REPORT_PERIOD'].shift())&(i_ed['ticker']==i_ed['ticker'].shift())&(i_ed['S_STM_PREDICT_ISSUINGDATE']!=i_ed['S_STM_PREDICT_ISSUINGDATE'].shift())]
# 41, 61, 73, 75, 76, 80, 82

# calculate signals - change of scheduled dates


o_sgnl = []

for i, r in i_ed.iterrows():
    if i == 0:
        continue
    
    if (i_ed.loc[i-1, 'ticker'] == r['ticker']) &\
       (i_ed.loc[i-1, 'REPORT_PERIOD'] == r['REPORT_PERIOD']) &\
       (i_ed.loc[i-1, 'ANN_DT'] != r['ANN_DT']) &\
       (i_ed.loc[i-1, 'S_STM_PREDICT_ISSUINGDATE']!=r['S_STM_PREDICT_ISSUINGDATE']):
        if i_ed.loc[i-1, 'S_STM_PREDICT_ISSUINGDATE'] > r['S_STM_PREDICT_ISSUINGDATE']:
            o_sgnl.append({'ticker': r['ticker'],
                           'datadate': r['ANN_DT'],
                           'ed_chg': 1})
        elif i_ed.loc[i-1, 'S_STM_PREDICT_ISSUINGDATE'] < r['S_STM_PREDICT_ISSUINGDATE']:
            o_sgnl.append({'ticker': r['ticker'],
                           'datadate': r['ANN_DT'],
                           'ed_chg': -1})

o_sgnl_df = pd.DataFrame(o_sgnl)
o_sgnl_df = o_sgnl_df[o_sgnl_df['datadate'].notnull()]
o_sgnl_df['datadate'] = pd.to_datetime(o_sgnl_df['datadate'], format = '%Y%m%d')

# calculate signals - early / late actual earning dates

i_ed_final = i_ed.groupby(['ticker', 'REPORT_PERIOD'])['S_STM_PREDICT_ISSUINGDATE', 'S_STM_ACTUAL_ISSUINGDATE'].last().reset_index()
i_ed_final = i_ed_final[i_ed_final['S_STM_ACTUAL_ISSUINGDATE'].notnull()]
i_ed_final = i_ed_final[i_ed_final['S_STM_PREDICT_ISSUINGDATE'].notnull()]
i_ed_final = i_ed_final[i_ed_final['S_STM_ACTUAL_ISSUINGDATE']!=i_ed_final['S_STM_PREDICT_ISSUINGDATE']]
i_ed_final['datadate'] = pd.to_datetime(i_ed_final['S_STM_ACTUAL_ISSUINGDATE'], format='%Y
%m%d')
i_ed_final.loc[i_ed_final['S_STM_ACTUAL_ISSUINGDATE']>i_ed_final['S_STM_PREDICT_ISSUINGDATE'], 'act_chg']  = 1
i_ed_final.loc[i_ed_final['S_STM_ACTUAL_ISSUINGDATE']<i_ed_final['S_STM_PREDICT_ISSUINGDATE'], 'act_chg']  = -1




### sd

i_sd = pw.get_ashare_hk_sd_v2()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','volatility','spread','BarrRet_SRISK_USD+1d','FX_LAST']]


### ed calendar
i_ed_cal = pw.get_wind_ed_calendar()
i_ed_cal = i_ed_cal[['ticker', 'datadate', 'bdae']]

### combine

icom = i_sd_map.merge(o_sgnl_df, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])
icom = icom.merge(i_ed_cal, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_ed_final, on = ['ticker', 'datadate'], how = 'left')

#------------------------------------------------------------------------------

### ed chg
icom2 = icom.copy()

icom2.loc[icom2['bdae']==2, 'sgnl'] = 0
icom2['sgnl'] = icom2.groupby(['ticker'])['ed_chg'].ffill().values

o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31') &\
                  (icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs  0.69 / 0.39

o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31') & (icom2['sgnl']>0)&\
                  (icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.57 / 1.34

o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31') & (icom2['sgnl']<0)&\
                  (icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs -0.52 / -0.71


### ed chg,  ffill(60)

icom2 = icom.copy()
icom2.loc[icom2['bdae']==2, 'sgnl2'] = 0
icom2['sgnl2'] = icom2.groupby(['ticker'])['ed_chg'].ffill(limit=60).values

o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31') & (icom2['sgnl2']>0)&\
                  (icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            's
gnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.88 / 0.58


### act chg

icom2 = icom.copy()
icom2['sgnl1'] = icom2.groupby(['ticker'])['act_chg'].ffill(limit=60).values


o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31') &\
                  (icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs -0.24 / -0.32

o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31') & (icom2['sgnl1']>0)&\
                  (icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.17 / 2.15 (too sparce)
