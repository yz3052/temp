﻿#$%^&* pVA_03b.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun May 31 17:52:07 2020

@author: thzhang
"""

import pandas as pd


# This script aggregate symbology ID 

va = pd.read_parquet(r'S:\Data\VA\US\ref\va_standardized_full_file_dir.parquet')
va2 = pd.read_parquet(r'S:\Data\VA\US\ref\va_normalized_full_file_dir.parquet')

va_sym = va[va.meta_data == 'symbology' ]
va_sym2 = va2[va2.meta_data == 'symbology' ]


def fetch_files(f):
    i_data = pd.read_csv(f, encoding = 'latin1')
    i_data['loaddate'] = f.split('.csv')[0].split('_')[-1]
    return i_data

o_std_sym = pd.concat([fetch_files(f) for f in va_sym.raw_dir_file_name], sort = False)
o_std_sym = o_std_sym.drop_duplicates(subset = ['Bloomberg Ticker', 'FIGI', 'PERM ID', 'Reuters Code', 'Symbology ID',
                                                'VA Ticker', 'VA companyid'])
o_std_sym.to_parquet(r'S:\Data\VA\US\std_Symbology\std_agg_symbology.parquet')
o_std_sym['source'] = 'std'

o_nme_sym = pd.concat([fetch_files(f) for f in va_sym2.raw_dir_file_name], sort = False)
o_nme_sym = o_nme_sym.drop_duplicates(subset = ['Bloomberg Ticker', 'FIGI', 'PERM ID', 'Reuters Code', 'Symbology ID',
                                                'VA Ticker', 'VA companyid'])
o_nme_sym.to_parquet(r'S:\Data\VA\US\nme_symb\nme_agg_symbology.parquet')
o_nme_sym['source'] = 'nme'

o_agg = pd.concat([o_std_sym, o_nme_sym], sort = False)
o_agg = o_agg.sort_values('VA Ticker')

o_agg.to_parquet(r'S:\Data\VA\US\ref\va_symbology.parquet')

