﻿#$%^&* pSuntime_sue_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 22 08:53:36 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime

### get consensus



i_con = yu.get_sql('''select stock_code as ticker, create_date, entrytime, report_year, report_quarter,
                   forecast_or as con_or, forecast_np as con_np, forecast_eps as con_eps,
                   report_type, organ_id, author_name 
                   from cndbdev.dbo.rpt_forecast_stk ''')

c_sh = i_con['ticker'].str[0].isin(['6'])
c_sz = i_con['ticker'].str[0].isin(['0', '3'])
i_con.loc[c_sh, 'ticker'] = i_con.loc[c_sh, 'ticker'] + '.SH'
i_con.loc[c_sz, 'ticker'] = i_con.loc[c_sz, 'ticker'] + '.SZ'

i_con['datadate'] = pd.to_datetime(i_con['entrytime'].dt.date)
i_con['create_date'] = pd.to_datetime(i_con['create_date'])

i_con = i_con[i_con['report_type']!=21]

i_con = i_con.sort_values(['ticker','report_year','report_quarter','organ_id','author_name','create_date','datadate'])
i_con = i_con.reset_index(drop = True)

### get forecast

i_frcst = yu.get_sql('''select stock_code as ticker, declare_date as datadate,
                     report_year, report_period, 
                     tor_ceiling, tor_floor, np_ceiling, np_floor, eps_ceiling, eps_floor 
                     from [CNDBDEV].[dbo].[fin_performance_forecast] ''')
i_frcst['data_type'] = 'forecast'
c_sh = i_frcst['ticker'].str[0].isin(['6'])
c_sz = i_frcst['ticker'].str[0].isin(['0','3'])
i_frcst.loc[c_sh, 'ticker'] = i_frcst.loc[c_sh, 'ticker'] + '.SH'
i_frcst.loc[c_sz, 'ticker'] = i_frcst.loc[c_sz, 'ticker'] + '.SZ'

i_frcst['tor'] = i_frcst[['tor_ceiling','tor_floor']].mean(axis=1, skipna=True)
i_frcst['np'] = i_frcst[['np_ceiling','np_floor']].mean(axis=1, skipna=True)
i_frcst['eps'] = i_frcst[['eps_ceiling','eps_floor']].mean(axis=1, skipna=True)


### get express

i_exp = yu.get_sql('''select stock_code as ticker, declare_date as datadate,
                   report_year, report_period, tor, np, eps  
                   from [CNDBDEV].[dbo].[fin_performance_express] ''')
i_exp['data_type'] = 'express'
c_sh = i_exp['ticker'].str[0].isin(['6'])
c_sz = i_exp['ticker'].str[0].isin(['0','3'])
i_exp.loc[c_sh, 'ticker'] = i_exp.loc[c_sh, 'ticker'] + '.SH'
i_exp.loc[c_sz, 'ticker'] = i_exp.loc[c_sz, 'ticker'] + '.SZ'



### loop over each frcst/express datadate

i_frcst_exp = i_frcst[['ticker','datadate','report_year','report_period','tor','np',
'eps']].\
              append(i_exp[['ticker','datadate','report_year','report_period','tor','np','eps']], sort=False)
i_frcst_exp = i_frcst_exp[i_frcst_exp['datadate']>='2016-01-01']
i_frcst_exp = i_frcst_exp.rename(columns={'report_period': 'report_quarter'})


o_sum = []

for dt in i_frcst_exp['datadate'].sort_values().drop_duplicates().tolist():
    print(dt.strftime('%Y%m%d'),end=' ')
    
    t_frcst_exp = i_frcst_exp[i_frcst_exp['datadate']==dt]
    t_frcst_exp_tk = t_frcst_exp['ticker'].unique().tolist()
    
    t_con = i_con[(i_con['datadate']<=dt)&\
                  (i_con['create_date']>=dt-pd.to_timedelta('91 days'))&\
                  (i_con['ticker'].isin(t_frcst_exp_tk))]
    
    t_data =  t_con.merge(t_frcst_exp, 
                                on = ['ticker','report_year','report_quarter'], 
                                how = 'inner', 
                                suffixes = ['_frsct_exp','_con'])
    t_data = t_data.drop_duplicates(subset = ['ticker','report_year','report_quarter','organ_id','author_name'], 
                                    keep = 'last')
    t_np = t_data.groupby(['ticker','report_year','report_quarter'])['con_or'].agg(['mean','median','count','std'])
    t_np.columns = ['con_np_'+c for c in t_np.columns.tolist()]
    
    t_eps = t_data.groupby(['ticker','report_year','report_quarter'])['con_eps'].agg(['mean','median','count','std'])
    t_eps.columns = ['con_eps_'+c for c in t_eps.columns.tolist()]
    
    t_sum = t_np.join(t_eps, how = 'outer')
    t_sum = t_sum.reset_index()
    t_sum = t_sum.merge(t_frcst_exp, on = ['ticker','report_year','report_quarter'], how = 'left')
    
    o_sum.append(t_sum)
    
o_sum = pd.concat(o_sum, axis = 0)
o_sum = o_sum.sort_values('datadate')

### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values('datadate')


### combine 
icom = pd.merge_asof(i_sd, o_sum, by = 'ticker', on = 'datadate', tolerance = pd.to_timedelta('91 days'))
icom = icom.sort_values(['ticker','datadate'])

icom['eps_bm_zscore'] = (icom['eps']-icom['con_eps_mean']).divide(icom['con_eps_std'])
c_inst = icom['con_eps_count']<3
icom.loc[c_inst, 'eps_bm_zscore'] = np.nan

icom.loc[icom['eps_bm_zscore']>1, 'flag_eps_beat'] = 1
icom.loc[icom['eps_bm_zscore']<-1, 'flag_eps_miss'] = -1

icom['np_bm_zscore'] = (icom['np']-icom['con_np_mean']).divide(icom['con_np_std'])
c_inst = icom['con_np_count']<3
icom.loc[c_inst, 'np_bm_zscore'] = np.nan

icom.loc[icom['np_bm_zscore']>1, 'flag_np_be
at'] = 1
icom.loc[icom['np_bm_zscore']<-1, 'flag_np_miss'] = -1

icom['eps_bm_zscore_rk'] = icom.groupby('datadate')['eps_bm_zscore'].apply(yu.uniformed_rank).values
icom['eps_bm_zscore_bk'] = icom.groupby('datadate')['eps_bm_zscore'].apply(lambda x: yu.pdqcut(x,bins=10)).values


### summary stats

icom.groupby('datadate')['eps_bm_zscore'].count().plot()
icom['flag_np_miss'].sum() #36164
icom['flag_np_beat'].sum() # 56

yu.create_cn_decay(icom, 'flag_np_miss')
yu.create_cn_decay(icom, 'flag_np_beat')

yu.create_cn_3x3(icom, ['eps_bm_zscore_bk'], 'eps_bm_zscore')

### SUE after forecast/express
# no alpha if we short those bearish signals

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['flag_np_miss','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flag_np_miss','BarrRet_CLIP_USD+1d', static_data = i_sd)
