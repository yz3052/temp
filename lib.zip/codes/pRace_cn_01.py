﻿#$%^&* pRace_cn_01.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 10 15:21:45 2023

@author: thzhang
"""

import pandas as pd
import numpy as np
import util as yu


i_sd = yu.get_sd_cn_1800()


i_race = pd.read_csv('/dat/mdwarehouse/public/RaceDataLab/DATA-16478/consumer_transaction_trial_20230803/rdl_mlp_total_listed_d.csv')
i_race = i_race[i_race['code'].str.len()==9]
i_race['Ticker'] = i_race['code'].str[:6]
i_race['date'] = pd.to_datetime(i_race['date'],format='%Y%m%d')

s_race = []
for d in pd.date_range(start='2022-01-01',end='2022-12-31'):
    print('.',end='')
    
    tm2w = d - pd.to_timedelta('14 days')
    tm2wm1q = tm2w - pd.to_timedelta('91 days')
    tm2wm1y = tm2w - pd.to_timedelta('365 days')
    tm2wm1ym1q = tm2wm1y - pd.to_timedelta('91 days')
    
    t_race_curr = i_race[i_race['date'].between(tm2wm1q, tm2w)]
    t_race_prev = i_race[i_race['date'].between(tm2wm1ym1q, tm2wm1y)]
    
    s_race_curr = t_race_curr.groupby(['Ticker','brand'])['amt','trans_num'].sum().reset_index()
    s_race_curr.columns = ['Ticker','brand','amt_t1q_curr','num_t1q_curr']
    s_race_prev = t_race_prev.groupby(['Ticker','brand'])['amt','trans_num'].sum().reset_index()
    s_race_prev.columns = ['Ticker','brand','amt_t1q_prev','num_t1q_prev']
    
    s = s_race_prev.merge(s_race_curr, on = ['Ticker','brand'], how='inner')
    s2 = s.groupby('Ticker')['amt_t1q_curr','num_t1q_curr','amt_t1q_prev','num_t1q_prev'].sum()
    s2 = s2.reset_index()
    s2['DataDate']=d
    
    s_race.append(s2)

s_race = pd.concat(s_race, axis=0)
#s_race = s_race[s_race['num_t1q_curr']>1e5] doesn't work

### combine

icom = i_sd.merge(s_race,on=['Ticker','DataDate'], how = 'left')
icom = icom.sort_values(['Ticker','DataDate'])


icom['amt_yoy'] = icom['amt_t1q_curr'] / icom['amt_t1q_prev']
icom['amt_yoy_bk'] = icom.groupby('DataDate')['amt_yoy'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom, ['amt_yoy_bk'], 'amt_yoy') # random
icom['num_yoy'] = icom['num_t1q_curr'] / icom['num_t1q_prev']
icom['num_yoy_bk'] = icom.groupby('DataDate')['num_yoy'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom, ['num_yoy_bk'], 'num_yoy') # random

icom['amt_t1q_curr_bk'] = icom.groupby('DataDate')['amt_t1q_curr'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom, ['amt_t1q_curr_bk'], 'amt_t1q_curr') # random
