﻿#$%^&* pWIND_strat_concepts_4.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 15 06:41:19 2022

@author: thzhang
"""


import pandas as pd
import numpy as np
import datetime as dd
import time

import yz.util as yu
import pWIND_util as pw

import os
import gzip
from bs4 import BeautifulSoup as bs

from io import StringIO


# this studies reversals inside concepts


### sd 

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['ticker', 'datadate'])


i_sd_ss = pw.get_china_ss_sd()
i_sd_ss = i_sd_ss.sort_values(['ticker', 'datadate'])



### c

i_c = yu.get_sql('''select a.s_info_windcode as ticker, a.trade_dt as datadate,
                 a.s_dq_adjclose / a.s_dq_adjpreclose - 1 as r, 
                 b.S_DQ_MV as mv 
                 from wind_prod.dbo.ashareeodprices a
                 left join wind_prod.dbo.AShareEODDerivativeIndicator b
                 on a.s_info_windcode=b.s_info_windcode
                 and a.trade_dt=b.trade_dt
                 where a.trade_dt >= '20180101' ''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format = '%Y%m%d')



### reversal

i_pastret = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet',
                            columns = ['ticker', 'datadate', 'twap1000_2c_bret', 'twap1000_2c_bret_t4w'])
i_pastret['twap1000_2c_bret_t1w'] = i_pastret.groupby('ticker').rolling(5)['twap1000_2c_bret'].mean().values
i_pastret = i_pastret.sort_values(['ticker','datadate'])



### get wind concept raw data

i_w = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_strat_concepts_backup_raw_20211122.parquet')

# cleanse 
i_w = i_w[i_w['s_info_windcode'].notnull()]
i_w = i_w[i_w['wind_sec_code'].notnull()]
i_w = i_w[~i_w['wind_sec_name'].str.contains('lugangtong|lugutong|zhangting|dieting')]
i_w['modified_time_cn'] = pd.to_datetime(i_w['modified_time_est']).dt.tz_localize('US/Eastern').dt.tz_convert('Asia/Shanghai').dt.tz_localize(None)
i_w['mopdate'] = pd.to_datetime(i_w['mopdate'].str.split('+').str[0])
i_w['opdate'] = pd.to_datetime(i_w['opdate'].str.split('+').str[0])
i_w['plan_date'] = pd.to_datetime(i_w['plan_date'])
i_w.loc[i_w['entry_dt'].notnull(), 'entry_dt'] = pd.to_datetime(i_w.loc[i_w['entry_dt'].notnull(), 'entry_dt'], format = '%Y%m%d', errors = 'coerce')
i_w['entry_dt'] = i_w['entry_dt'].fillna(pd.NaT)
i_w['entry_dt'] = pd.to_datetime(i_w['entry_dt'])
i_w.loc[i_w['remove_dt'].notnull(), 'remove_dt'] = pd.to_datetime(i_w.loc[i_w['remove_dt'].notnull(), 'remove_
dt'], format = '%Y%m%d', errors = 'coerce')
i_w['remove_dt'] = i_w['remove_dt'].fillna(pd.NaT)
i_w['remove_dt'] = pd.to_datetime(i_w['remove_dt'])


### 

s_cpt_ret = []
for dt in pd.date_range(start = '2018-01-01', end = '2019-12-31'):   
    print (dt.strftime('%Y%m%d'), end = ' ')
    d_str = dt.strftime('%Y-%m-%d')
    d_str = d_str + ' 23:59:59'
    t_data = i_w[i_w['modified_time_cn']<=d_str]
    t_data = t_data.rename(columns={'s_info_windcode':'ticker'})
    c_within_range = (t_data['entry_dt']<=dt)&(t_data['remove_dt']>=dt)
    c_after_entry = (t_data['entry_dt']<=dt)&(t_data['remove_dt'].isnull())
    c_unknown_start = (t_data['entry_dt'].isnull())&(t_data['remove_dt']>=dt)
    c_unkown = (t_data['entry_dt'].isnull())&(t_data['remove_dt'].isnull())
    c_curr_sign = t_data['cur_sign']=='1'
    t_concept = t_data[c_within_range | c_after_entry | c_unknown_start | c_unkown | c_curr_sign]
            
    # calculate concept t1m return
    t_c = i_c[(i_c['datadate']<=dt)&(i_c['datadate']>=dt-pd.to_timedelta('30 days'))]
    t_c = t_c.groupby('ticker')[['r','mv']].mean().reset_index()
    t_cpt_ret = t_concept[['ticker','wind_sec_code']]
    t_cpt_ret = t_cpt_ret.merge(t_c, on = 'ticker', how = 'left')
    t_cpt_ret = t_cpt_ret.groupby('wind_sec_code')[['r','mv']].apply(lambda x: (x['r']*x['mv']).sum() / x['mv'].sum() )
    t_cpt_ret = t_cpt_ret.reset_index()
    t_cpt_ret.columns = ['wind_sec_code','cpt_t1m_ret']
        
    # calculate ticker t1m o2c ret inside concpet
    t_pastret = i_pastret[i_pastret['datadate']==dt][['ticker','twap1000_2c_bret_t1w']]    
    t_stk_ret = t_concept[['ticker','wind_sec_code']].merge(t_pastret,on='ticker',how='left')
    t_stk_ret['bret_rk'] = t_stk_ret.groupby('wind_sec_code')['twap1000_2c_bret_t1w'].apply(yu.uniformed_rank)
    t_stk_ret = t_stk_ret.reset_index()
    t_stk_ret = t_stk_ret[['ticker','wind_sec_code','bret_rk']]
    
    # output
    s = t_stk_ret.merge(t_cpt_ret,on='wind_sec_code',how='left')
    s0 = s.groupby('ticker')['bret_rk'].mean()
    s0.name = 'bret_rk_allavg'
    s0 = s0.to_frame()
    s1 = s[s['cpt_t1m_ret']>0].groupby('ticker')['bret_rk'].mean()
    s1.name = 'bret_rk_gt0avg'
    s1 = s1.to_frame()
    s2 = s[s['cpt_t1m_ret']>0.002].groupby('ticker')['bret_rk'].mean()
    s2.name = 'bret_rk_gt5avg'
    s2 = s2.to_frame()
    s3 = s[s['cpt_t1m_ret']<0].groupby('ticker')['bret_rk'].mean()
    s3.name = 'bret_rk_lt0avg'
    s3 = s3.to_frame()
    s4 = s[s['cpt_t1m_ret']<-.002].groupby('t
icker')['bret_rk'].mean()
    s4.name = 'bret_rk_lt5avg'
    s4 = s4.to_frame()
    
    s = s0.join(s1,how='outer').join(s2,how='outer').join(s3,how='outer').join(s4,how='outer')
    s = s.reset_index()
    s['datadate'] = dt
    s_cpt_ret.append(s)
    
s_cpt_ret = pd.concat(s_cpt_ret, axis = 0)
    


### combine

icom = i_sd.merge(s_cpt_ret, on = ['datadate', 'ticker'], how = 'left')
icom = icom.merge(i_pastret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate']) 

icom['twap1000_2c_bret_t4w_bk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['twap1000_2c_bret_t4w_bk'], 'twap1000_2c_bret_t4w') #7.5 -11 (ss: 3.5 -7.5)

icom['bret_rk_allavg_bk'] = icom.groupby('datadate')['bret_rk_allavg'].apply(lambda x: yu.pdqcut(x,bins=20)).values
icom['bret_rk_gt0avg_bk'] = icom.groupby('datadate')['bret_rk_gt0avg'].apply(lambda x: yu.pdqcut(x,bins=20)).values
icom['bret_rk_gt5avg_bk'] = icom.groupby('datadate')['bret_rk_gt5avg'].apply(lambda x: yu.pdqcut(x,bins=20)).values
icom['bret_rk_lt0avg_bk'] = icom.groupby('datadate')['bret_rk_lt0avg'].apply(lambda x: yu.pdqcut(x,bins=20)).values
icom['bret_rk_lt5avg_bk'] = icom.groupby('datadate')['bret_rk_lt5avg'].apply(lambda x: yu.pdqcut(x,bins=20)).values
yu.create_cn_3x3(icom, ['bret_rk_allavg_bk'], 'bret_rk_allavg')# 6.5 -14 (ss: -1 +6 -8)
yu.create_cn_3x3(icom, ['bret_rk_gt0avg_bk'], 'bret_rk_gt0avg')# 6.5 -15 (ss: 0 +5 -6)
yu.create_cn_3x3(icom, ['bret_rk_gt5avg_bk'], 'bret_rk_gt5avg')# 7 -15 (ss: 0 +7 -10)
yu.create_cn_3x3(icom, ['bret_rk_lt0avg_bk'], 'bret_rk_lt0avg')# 7.5 -12 (ss: -2 +5.5 -3.5)
yu.create_cn_3x3(icom, ['bret_rk_lt5avg_bk'], 'bret_rk_lt5avg')# +5.5 -10 (ss: -2 +4.5 -5)
# 1w inside concepts is worse than 4w inside concepts


icom['sgnl1'] = np.nan
icom.loc[(icom['twap1000_2c_bret_t4w_bk']==0)&(icom['bret_rk_gt5avg_bk']==0), 'sgnl1'] = 1
icom['sgnl1'] = icom.groupby('ticker')['sgnl1'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2019-12-31'))].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) 
# 2k: 2.97 / 1.96. 7.9% 
# ss: 0.32 / -0.37
