﻿#$%^&* pFlow_cn_nb_ed.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 27 10:59:59 2023

@author: thzhang
"""


import pandas as pd
import numpy as np

import datetime
import util as yu
import os

# hk flow data is a very short term alpha 
# for flow on ed signal, precost > 2.5, but small sample, high cost


# todo
# how to adjust holdings w.r.t. dividend shares?
    
# ideas:    
# hold large number but not in uni ... sell only
# after hong gu, hk holding will increase
# 


### sd 

i_sd = yu.get_sd_cn_1800()


### ed
# 'DataDate', 'Ticker', 'last_ped', 'last_ed', 'next_ped', 'next_ed', 'EDTrdDate_last', 'EDTrdDate_next', 'd2preed', 'd2nexted'
i_ed = yu.get_sql('''select * from cndbprod.dbo.CNINFO_ED_FORMAT''')


### hk uni 
### adj
# i_adj = yu.get_sql_wind('''
#                    select substring(s_info_windcode,1,6) as Ticker, trade_dt as [T-1d],
#                    s_dq_adjfactor as adj 
#                    from wind_prod.dbo.ashareeodprices
#                    ''')


### hk
# 'Ticker', 'hk_b_shares', 'hk_c_shares', 'hk_bb_shares', 'craw', 'float', 'flg_cndb_hk', 'DataDate'
root_hk = '/dat/summit_capital/TZ/tmp/temp_hk_v2/'
files_hk = os.listdir(root_hk)
i_nb = pd.concat([pd.read_parquet(root_hk + f) for f in files_hk], axis = 0)
i_nb = i_nb.sort_values(['Ticker', 'DataDate']).reset_index(drop = True)
i_nb['hk_bb_diff'] = i_nb['hk_bb_shares'] - i_nb.groupby('Ticker')['hk_bb_shares'].shift()
i_nb['hk_bb_diff_dv_so'] = i_nb['hk_bb_diff'] / i_nb['float']


### combine
# some positive alpha - like 1-2 precost sharpe.
# but decay quickly
# yes nb is better than return, but still not good enough

icom = i_sd.merge(i_nb, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom.merge(i_ed, on = ['Ticker', 'DataDate'], how = 'left')
#icom = icom[icom['DataDate'].le('2021-12-31')]


icom['hk_bb_diff_dv_pv'] = icom['hk_bb_diff'] / icom['avgVadj']###??? wrong
icom['hk_bb_diff_dv_so_rk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so'].apply(yu.uniformed_rank)
icom['BarrRet_CLIP_USD-1d_rk'] = icom.groupby('DataDate')['BarrRet_CLIP_USD-1d'].apply(yu.uniformed_rank)
icom['RawRet-1d_rk'] = icom.groupby('DataDate')['RawRet-1d'].apply(yu.uniformed_rank)

icom = icom.sort_values(['Ticker', 'DataDate'])
icom['bret_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=30),on='DataDate')['BarrRet_CLIP_USD-1d'].mean().values
icom['bret_t20d_rk'] = icom.groupby('DataDate')['bret_t20d'].apply(yu.uniformed_rank)
icom['bret_rk'] = icom.g
roupby('DataDate')['BarrRet_CLIP_USD-1d'].apply(yu.uniformed_rank)




icom['sgnl'] = np.nan
c1 = icom['hk_bb_diff_dv_so_rk'].gt(0.98) & icom['d2preed'].eq(0)
c2 = icom['bret_t20d_rk']<-0.5
icom.loc[c1 & c2, 'sgnl'] = 1
icom['sgnl'] = icom.groupby('Ticker')['sgnl'].ffill(limit=20)

yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd)

    
    
icom['sgnl2'] = np.nan
c1 = icom['hk_bb_diff_dv_so_rk'].gt(0.98) & icom['d2nexted'].eq(1)
c2 = icom['hk_bb_diff_dv_so_rk'].gt(0.98) & icom['d2preed'].eq(0)
icom.loc[ c2, 'sgnl2'] = 1
icom['sgnl2'] = icom.groupby('Ticker')['sgnl2'].ffill(limit=1)

yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd)



icom['sgnl3'] = np.nan
c1 = icom['d2preed'].eq(0) & icom['BarrRet_CLIP_USD-1d_rk'].gt(0.8)
icom.loc[c1, 'sgnl3'] = 1
icom['sgnl3'] = icom.groupby('Ticker')['sgnl3'].ffill(limit=1)

yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.5 / -2, both for rawret and barrret


icom['sgnl4'] = np.nan
c1 = icom['d2preed'].eq(0) & icom['BarrRet_CLIP_USD-1d_rk'].gt(0.8)
c2 = icom['bret_t20d_rk']<-0.5
icom.loc[c1 & c2, 'sgnl4'] = 1
icom['sgnl4'] = icom.groupby('Ticker')['sgnl4'].ffill(limit=1)

yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl4','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl4','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

    
    
icom['sgnl5'] = np.nan
c1 = icom['d2preed'].eq(0) & icom['hk_bb_diff_dv_so_rk'].gt(0.8)
#icom['BarrRet_CLIP_USD-1d_rk'].gt(0.8)
c2 = icom['bret_rk']<0.5
icom.loc[c1 & c2, 'sgnl5'] = 1
icom['sgnl5'] = icom.groupby('Ticker')['sgnl5'].ffill(limit=1)

yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl5','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl5','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.71 / 0.
4

    
    
icom['sgnl5'] = np.nan
c1 = icom['d2preed'].eq(0) & icom['hk_bb_diff_dv_so_rk'].gt(0.98)
#icom['BarrRet_CLIP_USD-1d_rk'].gt(0.8)
c2 = icom['bret_rk']<0.5
icom.loc[c1 & c2, 'sgnl5'] = 1
icom['sgnl5'] = icom.groupby('Ticker')['sgnl5'].ffill(limit=1)

yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl5','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl5','BarrRet_CLIP_USD+1d', static_data = i_sd) # even for 0.98, the sgnl is short term
