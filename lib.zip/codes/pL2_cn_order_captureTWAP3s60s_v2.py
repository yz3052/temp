﻿#$%^&* pL2_cn_order_captureTWAP3s60s_v2.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue May 31 09:46:37 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime






### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()




i_sd_300 = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pStaticData_cn_csi300.parquet')
i_sd_300 = i_sd_300.sort_values('datadate')




i_sd_ss = yu.get_sql('''select * from [CNDBPROD].[dbo].[Static_Data_SS_GEM3L] ''')
i_sd_ss = i_sd_ss.rename(columns = {'DataDate':'datadate_p1d', 'T-1d':'datadate', 'Ticker':'ticker', 'gk_vol_21d':'volatility'})

c_sh = i_sd_ss['ticker'].str[0].isin(['6'])
c_sz = i_sd_ss['ticker'].str[0].isin(['0', '3'])
i_sd_ss.loc[c_sh, 'ticker'] = i_sd_ss.loc[c_sh, 'ticker'] + '.SH'
i_sd_ss.loc[c_sz, 'ticker'] = i_sd_ss.loc[c_sz, 'ticker'] + '.SZ'

i_sd_ss = i_sd_ss.sort_values('datadate')




### o2c ret

i_past_ret = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet')
i_past_ret = i_past_ret.sort_values(['ticker', 'datadate']).reset_index(drop = True)








### q


i_twap_v2 = yu.get_q('''get `$":/export/datadev/Data/SHSZ/ORDER_metrics/twap_shsz" ''')

i_twap_v2['code'] = i_twap_v2['code'].str.decode('utf8')
c_sh = i_twap_v2['code'].str[0].isin(['6'])
c_sz = i_twap_v2['code'].str[0].isin(['0','3'])
i_twap_v2.loc[c_sh, 'ticker'] = i_twap_v2.loc[c_sh, 'code'] + '.SH'
i_twap_v2.loc[c_sz, 'ticker'] = i_twap_v2.loc[c_sz, 'code'] + '.SZ'
i_twap_v2['datadate'] = pd.to_datetime(i_twap_v2['date'])
i_twap_v2 = i_twap_v2.sort_values(['ticker', 'datadate'])

i_twap_v2['twap_cnt_prd3s60s_pct'] = i_twap_v2['twap_cnt_prd3s_pct'].add(i_twap_v2['twap_cnt_prd60s_pct'], fill_value=0)
i_twap_v2['twap_cnt_prd3s60s_pct_t20d'] = i_twap_v2.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['twap_cnt_prd3s60s_pct'].mean().values







#------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------


### combine
# must include tickers with low or no twap trades, so we have short-side returns

icom = i_sd.merge(i_twap_v2, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_past_ret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.s
ort_values(['ticker', 'datadate'])
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']





### tstat
# tstat and b-s are not superior
icom['tstat'] = icom['tstat_3s'] + icom['tstat_60s']
icom['tstat_bk'] = icom.groupby('datadate')['tstat'].apply(lambda x: yu.pdqcut(x,bins=10))
yu.create_cn_3x3(icom, ['tstat_bk'], 'tstat') # 2K mono: -14 +7

icom['tstat_b_3s_bk'] = icom.groupby('datadate')['tstat_b_3s'].apply(lambda x: yu.pdqcut(x,bins=10))
yu.create_cn_3x3(icom, ['tstat_b_3s_bk'], 'tstat_b_3s') # 2K mono: -6 +8

icom['tstat_bs_3s'] = icom['tstat_b_3s'] - icom['tstat_s_3s']
icom['tstat_bs_3s_bk'] = icom.groupby('datadate')['tstat_bs_3s'].apply(lambda x: yu.pdqcut(x,bins=10))
yu.create_cn_3x3(icom, ['tstat_bs_3s_bk'], 'tstat_bs_3s') # v-shaped




### full spectrum signal

icom['twap_cnt_prd3s_pct_bk'] = icom.groupby('datadate')['twap_cnt_prd3s_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['twap_cnt_prd3s_pct_orth'] = icom.groupby('datadate')[['twap_cnt_prd3s_pct']+COLS].apply(lambda x: yu.orthogonalize_cn(x['twap_cnt_prd3s_pct'], x[COLS])).values
icom['twap_cnt_prd3s_pct_orth_bk'] = icom.groupby('datadate')['twap_cnt_prd3s_pct_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['twap_cnt_prd60s_pct_bk'] = icom.groupby('datadate')['twap_cnt_prd60s_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['twap_cnt_prd60s_pct_orth'] = icom.groupby('datadate')[['twap_cnt_prd60s_pct']+COLS].apply(lambda x: yu.orthogonalize_cn(x['twap_cnt_prd60s_pct'], x[COLS])).values
icom['twap_cnt_prd60s_pct_orth_bk'] = icom.groupby('datadate')['twap_cnt_prd60s_pct_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['twap_cnt_prd3s60s_pct_bk'] = icom.groupby('datadate')['twap_cnt_prd3s60s_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['twap_cnt_prd3s60s_pct_t20d_rk'] = icom.groupby('datadate')['twap_cnt_prd3s60s_pct_t20d'].apply(yu.uniformed_rank)
icom['twap_cnt_prd3s60s_pct_t20d_orth'] = icom.groupby('datadate')[['twap_cnt_prd3s60s_pct_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['twap_cnt_prd3s60s_pct_t20d'], x[COLS])).values
icom['twap_cnt_prd3s60s_pct_t20d_orth_rk'] = icom.groupby('datadate')['twap_cnt_prd3s60s_pct_t20d_orth'].apply(yu.uniformed_rank)


yu.create_cn_3x3(icom, ['twap_cnt_prd3s_pct_bk'], 'twap_cnt_prd3s_pct') # 2K: mono -10 +8
yu.create_cn_3x3(icom[icom['twap1030_2c_t4w_bk']==9], ['twap_cnt_prd3s_pct_bk'], 'twap_cnt_prd3s_pct')
yu.create_cn_3x3(icom[icom['twap1030_2
c_t4w_bk']==0], ['twap_cnt_prd3s_pct_bk'], 'twap_cnt_prd3s_pct')
yu.create_cn_3x3(icom[icom['twap1030_2c_t9w_bk']==0], ['twap_cnt_prd3s_pct_bk'], 'twap_cnt_prd3s_pct')
yu.create_cn_3x3(icom[icom['twap1000_2c_t9w_bk']==0], ['twap_cnt_prd3s_pct_bk'], 'twap_cnt_prd3s_pct')

yu.create_cn_3x3(icom, ['twap_cnt_prd3s_pct_bk'], 'twap_cnt_prd3s_pct') # mono: -6.5 +6.5
yu.create_cn_3x3(icom, ['twap_cnt_prd3s_pct_orth_bk'], 'twap_cnt_prd3s_pct_orth') # mono -9 6.5
yu.create_cn_3x3(icom, ['twap_cnt_prd60s_pct_bk'], 'twap_cnt_prd60s_pct') # mono -7 +4.5
yu.create_cn_3x3(icom, ['twap_cnt_prd60s_pct_orth_bk'], 'twap_cnt_prd60s_pct_orth') # mono -11 +6
yu.create_cn_3x3(icom, ['twap_cnt_prd3s60s_pct_bk'], 'twap_cnt_prd3s60s_pct') # 2K mono: -12 +8.5



o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['twap_cnt_prd3s60s_pct_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'twap_cnt_prd3s60s_pct_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.66/3.56 5.4e7

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['twap_cnt_prd3s60s_pct_t20d_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'twap_cnt_prd3s60s_pct_t20d_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.8/3.64 6.5e7


# gf test
gf_sd = yu.get_sql('''SELECT * FROM [CNDBPROD].[dbo].[Static_Data_T2000_GEM3L]''')
gf_sd = gf_sd.rename(columns={'gk_vol_21d':'volatility'})
s =  icom[['datadate_p1d','ticker', 'twap_cnt_prd3s60s_pct_t20d_orth_rk','avgPVadj_USD']].rename(columns={'datadate_p1d':'DataDate','ticker':'Ticker'})
s['Ticker'] = s['Ticker'].str[:6]
s['clip'] = s['avgPVadj_USD']*0.01
s.loc[s['clip']>1e6, 'clip'] = 1e6
s['pos'] = s['clip'] * s['twap_cnt_prd3s60s_pct_t20d_orth_rk']
yu.bt_cn_gf(s,gf_sd,mode='hedge300') # hedge300, hedge300, barra
# 300 is the worst, 800 contaminated by 300; barra looks great 






### extrm value signal

icom['sgnl_1'] = np.nan
icom.loc[icom['twap_cnt_prd3s60s_pct_t20d_orth_rk']>0.8, 'sgnl_1'] = 1
icom.loc[icom['twap_cnt_prd3s60s_pct_t20d_orth_rk']<-0.8, 'sgnl_1'] = -1
icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.33/2.56, 11.4%
o_1 = yu.bt_cn_15(icom[(icom['datadate']<
='2020-12-31')&(icom['sgnl_1']>0)].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd) # 


# gf test
# gf_sd = yu.get_sql('''SELECT * FROM [CNDBPROD].[dbo].[Static_Data_T2000_GEM3L]''')
# gf_sd = gf_sd.rename(columns={'gk_vol_21d':'volatility'})
s =  icom[['datadate_p1d','ticker', 'sgnl_1','avgPVadj_USD']].rename(columns={'datadate_p1d':'DataDate','ticker':'Ticker'})
s['Ticker'] = s['Ticker'].str[:6]
s['clip'] = s['avgPVadj_USD']*0.01
s.loc[s['clip']>1e6, 'clip'] = 1e6
s['pos'] = s['clip'] * s['sgnl_1']
yu.bt_cn_gf(s,gf_sd,mode='barra') # 300 is the worst, 800 contaminated by 300; barra looks great 






### extrm value signal + o2c


icom['twap1000_2c_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_t4w'].apply(yu.uniformed_rank).values
icom['sgnl_2'] = np.nan
icom.loc[(icom['twap_cnt_prd3s60s_pct_t20d_orth_rk']>0.8)&(icom['twap1000_2c_t4w_rk']<-0.8), 'sgnl_2'] = 1
icom.loc[(icom['twap_cnt_prd3s60s_pct_t20d_orth_rk']<-0.8)&(icom['twap1000_2c_t4w_rk']>0.8), 'sgnl_2'] = -1
icom['sgnl_2'] = icom.groupby('ticker')['sgnl_2'].ffill(limit=10)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.36 / 3.52, 3.5e7 thru 2020
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['sgnl_2']>0)].\
            dropna(subset=['sgnl_2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.2e7 thru 2020


s =  icom[['datadate_p1d','ticker', 'sgnl_2','avgPVadj_USD']].rename(columns={'datadate_p1d':'DataDate','ticker':'Ticker'})
s['Ticker'] = s['Ticker'].str[:6]
s['clip'] = s['avgPVadj_USD']*0.01
s.loc[s['clip']>1e6, 'clip'] = 1e6
s['pos'] = s['clip'] * s['sgnl_2']
yu.bt_cn_gf(s,gf_sd,mode='hedge800') # bc pnl close to long-only part above 






#------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------


### loop: o2c and twap in extrm buckets
###!!! This is the productionized method



icom = i_sd.merge(i_twap_v2, on = ['ticker', 'datadate'], how = 'left') 
icom = icom.merge(i_past_ret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])
COLS 
= ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']

icom['twap_cnt_prd3s60s_pct_t20d_orth'] = icom.groupby('datadate')[['twap_cnt_prd3s60s_pct_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['twap_cnt_prd3s60s_pct_t20d'], x[COLS])).values
icom['twap_cnt_prd3s60s_pct_t20d_orth_rk'] = icom.groupby('datadate')['twap_cnt_prd3s60s_pct_t20d_orth'].apply(yu.uniformed_rank)

icom['twap1000_2c_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_t4w'].apply(yu.uniformed_rank).values


icom['sgnl_2'] = np.nan
icom.loc[(icom['twap_cnt_prd3s60s_pct_t20d_orth_rk']>0.8)&(icom['twap1000_2c_t4w_rk']<-0.8), 'sgnl_2'] = 1
icom.loc[(icom['twap_cnt_prd3s60s_pct_t20d_orth_rk']<-0.8)&(icom['twap1000_2c_t4w_rk']>0.8), 'sgnl_2'] = -1
icom['sgnl_2'] = icom.groupby('ticker')['sgnl_2'].ffill(limit=10)



# loop

o_sgnl = []

for dt in i_sd_dd:
    print(dt.strftime('%Y%m%d'), end=' ')
    
    tcom = icom[(icom['datadate']<=dt) & (icom['datadate']>=dt-pd.to_timedelta('28 days'))]
    tcom = tcom.reset_index(drop = True)
    tcom['idx'] = tcom.index.values
    
    c_long = (tcom['twap_cnt_prd3s60s_pct_t20d_orth_rk']>0.3) &\
             (tcom['twap1000_2c_t4w_rk']<-0.8)
    c_short = (tcom['twap_cnt_prd3s60s_pct_t20d_orth_rk']<-0.8) &\
              (tcom['twap1000_2c_t4w_rk']>0.8)
    tcom.loc[c_long, 'sgnl_1'] = tcom.loc[c_long, 'twap_cnt_prd3s60s_pct_t20d_orth_rk']
    tcom.loc[c_short, 'sgnl_1'] = tcom.loc[c_short, 'twap_cnt_prd3s60s_pct_t20d_orth_rk']
    
    tcom_w_sgnl = tcom[tcom['sgnl_1'].notnull()]
    tcom_w_sgnl = tcom_w_sgnl.groupby('ticker').tail(1)
    tcom_w_sgnl = tcom_w_sgnl[['ticker', 'idx', 'sgnl_1']]
    tcom_w_sgnl = tcom_w_sgnl.rename(columns={'idx':'idx_latest_sgnl'})
    
    tcom = tcom.merge(tcom_w_sgnl[['ticker', 'idx_latest_sgnl']], on = 'ticker', how = 'left')
    tcom['sgnl_1'] = tcom.groupby('ticker')['sgnl_1'].ffill()
    tcom = tcom[tcom['idx'] >= tcom['idx_latest_sgnl']]
    
    tcom_o2c_t4w = tcom.groupby('ticker')['twap1000_2c_t4w_rk'].agg([min,max])
    tcom_o2c_t4w.columns = ['o2c_t4w_rk_min', 'o2c_t4w_rk_max']
    tcom_o2c_t4w = tcom_o2c_t4w.reset_index()
    
    tcom_output = tcom_o2c_t4w.merge(tcom_w_sgnl, on='ticker', how='outer')
    tcom_output = tcom_output[((tcom_output['sgnl_1']>0)&(tcom_output['o2c_t4w_rk_max']<0.8))|\
                              ((tcom_output['sgnl_1']<0)&(tcom_output['o2c_t4w_rk_min']>-0.8))]
    tcom_output['datadate'] = dt
    o_sgnl.append(tcom_output)
    

o_sgnl = pd.concat(o_sgnl, axis=0)
    

# test loop

icom2 = i_sd_ss.merge(o_sgnl, on = ['ticker', 'datadate'], how = 'left')


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).\
            drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.75/3.94/3.0, 19.6%

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-12-31')&(icom2['sgnl_1']>0)].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).\
            drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.81/3.05, 14%

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).\
            drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd_ss) # ss 1.12 / 0.56 / 0.42




o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_1','HedgeRet_CSI300_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','HedgeRet_CSI300_USD+1d', static_data = i_sd) 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-12-31')&(icom2['sgnl_1']>0)].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd) #3.26/2.63/2.63









#------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------


### loop: twap in extrm buckets, o2c for exits



icom = i_sd.merge(i_twap_v2, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_past_ret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']

icom['twap_cnt_prd3s60s_pct_t20d_orth'] = icom.groupby('datadate')[['twap_cnt_prd3s60s_pct_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['twap_cnt_prd3s60s_pct_t20d'], x[COLS])).values
icom['twap_cnt_prd3s60s_pct_t20d_orth_rk'] = icom.groupby('datadate')['twap_cnt_prd3s60s_pct_t20d_orth'].apply(yu.uniformed_rank)
icom['twap_cnt_prd3s60s_pct_t20d_rk'] = icom.groupby('datadate')['twap_cnt_prd3s60s_pct_t20d'].apply(yu.uniformed_rank)

icom['twap1000_2c_t4w_rk'] = icom.groupby('datadate')['twap1000_
2c_t4w'].apply(yu.uniformed_rank).values


icom['sgnl_2'] = np.nan
icom.loc[(icom['twap_cnt_prd3s60s_pct_t20d_orth_rk']>0.8)&(icom['twap1000_2c_t4w_rk']<-0.8), 'sgnl_2'] = 1
icom.loc[(icom['twap_cnt_prd3s60s_pct_t20d_orth_rk']<-0.8)&(icom['twap1000_2c_t4w_rk']>0.8), 'sgnl_2'] = -1
icom['sgnl_2'] = icom.groupby('ticker')['sgnl_2'].ffill(limit=10)



# loop

o_sgnl = []

for dt in i_sd_dd:
    print(dt.strftime('%Y%m%d'), end=' ')
    
    tcom = icom[(icom['datadate']<=dt) & (icom['datadate']>=dt-pd.to_timedelta('28 days'))]
    tcom = tcom.reset_index(drop = True)
    tcom['idx'] = tcom.index.values
    
    c_long = (tcom['twap_cnt_prd3s60s_pct_t20d_orth_rk']>0.8) &\
             (tcom['twap1000_2c_t4w_rk']<0)
    c_short = (tcom['twap_cnt_prd3s60s_pct_t20d_orth_rk']<-0.8) &\
              (tcom['twap1000_2c_t4w_rk']>0)
    tcom.loc[c_long, 'sgnl_1'] = 1
    tcom.loc[c_short, 'sgnl_1'] = -1
    
    tcom_w_sgnl = tcom[tcom['sgnl_1'].notnull()]
    tcom_w_sgnl = tcom_w_sgnl.groupby('ticker').tail(1)
    tcom_w_sgnl = tcom_w_sgnl[['ticker', 'idx', 'sgnl_1']]
    tcom_w_sgnl = tcom_w_sgnl.rename(columns={'idx':'idx_latest_sgnl'})
    
    tcom = tcom.merge(tcom_w_sgnl[['ticker', 'idx_latest_sgnl']], on = 'ticker', how = 'left')
    tcom['sgnl_1'] = tcom.groupby('ticker')['sgnl_1'].ffill()
    tcom = tcom[tcom['idx'] >= tcom['idx_latest_sgnl']]
    
    tcom_o2c_t4w = tcom.groupby('ticker')['twap1000_2c_t4w_rk'].agg([min,max])
    tcom_o2c_t4w.columns = ['o2c_t4w_rk_min', 'o2c_t4w_rk_max']
    tcom_o2c_t4w = tcom_o2c_t4w.reset_index()
    
    tcom_output = tcom_o2c_t4w.merge(tcom_w_sgnl, on='ticker', how='outer')
    tcom_output = tcom_output[((tcom_output['sgnl_1']==1)&(tcom_output['o2c_t4w_rk_max']<0.8))|\
                              ((tcom_output['sgnl_1']==-1)&(tcom_output['o2c_t4w_rk_min']>-0.8))]
    tcom_output['datadate'] = dt
    o_sgnl.append(tcom_output)
    
o_sgnl = pd.concat(o_sgnl, axis=0)
    

# test loop

icom2 = i_sd.merge(o_sgnl, on = ['ticker', 'datadate'], how = 'left')
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.63/3.86/2.73
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-12-31')&(icom2['sgnl_1']>0)].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_U
SD+1d', static_data = i_sd) #3.26/2.63/2.63


s =  icom2[['datadate_p1d','ticker', 'sgnl_1','avgPVadj_USD']].rename(columns={'datadate_p1d':'DataDate','ticker':'Ticker'})
s = s[s['DataDate']<='2020-12-31']
s['Ticker'] = s['Ticker'].str[:6]
s['clip'] = s['avgPVadj_USD']*0.01
s.loc[s['clip']>1e6, 'clip'] = 1e6
s['pos'] = s['clip'] * s['sgnl_1']
yu.bt_cn_gf(s,gf_sd,mode='barra') # bc pnl close to long-only part above, 4.63/2.8



t1 = icom2[(icom2['datadate']=='2020-12-09') & (icom2['sgnl_1'].notnull())]
t2 = yu.get_sql("select * from cndbdev.dbo.SMTCN_CHILDALPHA_F001_TWAP3S60S_LS where DataDate = '2020-12-10' ")
t2['alpha'].hist(bins=30)

