﻿#$%^&* pFlow_us__etl_hzt.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May  2 11:52:00 2023

@author: thzhang
"""

import os

import pandas as pd



### get PIT
# each date might have multiple delivery

root = '/dat/mdwarehouse/public/Markit/2713/Data_Insights_v1/'

lst_data_files = []
for year in ['2019', '2020', '2021', '2022', '2023']:
    for month in os.listdir(root + year):
        for day in os.listdir(root + year + '/' + month):
            t_root = root + year + '/' + month + '/' + day + '/'
            for f in os.listdir(t_root):
                if ('_Consistency_Checks_' in f) and f.endswith('.csv'):
                    datadate = t_root.split('/')[-4] + t_root.split('/')[-3] + t_root.split('/')[-2]
                    lst_data_files.append([t_root, t_root+f, datadate])
lst_data_files = pd.DataFrame(lst_data_files, columns = ['fd', 'p', 'DataDate'])


o_data = []
for i, r in lst_data_files.iterrows():
    tdata = pd.read_csv(r['p'])
    tdata['DataDate'] = pd.to_datetime(r['DataDate'])
    tdata['p'] = r['p']
    o_data.append(tdata)
o_data = pd.concat(o_data, axis = 0)
o_data['Position Date'] = pd.to_datetime(o_data['Position Date'])



### get history 

root_his = '/dat/mdwarehouse/public/Markit/2713/Data_Insights_v1/Backhistory/Consistency Check History/'
i_files = os.listdir(root_his)
i_hist = []
for f in os.listdir(root_his):
    tdata = pd.read_csv(root_his + f)
    i_hist.append(tdata)
i_hist = pd.concat(i_hist, axis = 0)

i_hist['Position Date'] = pd.to_datetime(i_hist['Position Date'])
i_hist['DataDate'] = i_hist['Position Date'] + pd.to_timedelta('1 day')
c1 = pd.to_datetime(i_hist['Position Date']).dt.weekday==4
i_hist.loc[c1, 'DataDate'] = i_hist.loc[c1, 'DataDate'] + pd.to_timedelta('2 days')


o_data = pd.concat([o_data, i_hist], axis = 0)
o_data.to_parquet('/dat/summit_capital/TZ/Markit - Hazeltree/cache/consistency_check_parquet')

