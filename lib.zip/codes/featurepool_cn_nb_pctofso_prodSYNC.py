﻿#$%^&* featurepool_cn_nb_pctofso_prodSYNC.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  7 12:40:29 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import os

import datetime

from sqlalchemy import create_engine
import urllib
import pyodbc

from multiprocessing import Pool


# to be scheduled on crontab at 5 am



#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------

save_path = '/dat/summit_capital/TZ/PROD_FEATURES/featurepool_cn_desc_nb_pctofso'

conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
conn_wind = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_wind_dbo;PWD=DusONA3Habredl;''TDS_Version=8.0;')))

today = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
today = pd.to_datetime(today.date())
today_str = today.strftime('%Y%m%d')




#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------


i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()



#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------



dates_to_query = i_cal['DataDate'].dt.strftime('%Y%m%d.parquet').drop_duplicates().tolist()
dates_to_query = [d for d in dates_to_query if (d>'20180710.parquet') and (d<today.strftime('%Y%m%d.parquet'))]

existing_dates = os.listdir(save_path)

dates_to_query = [d for d in dates_to_query if d not in existing_dates]






#------------------------------------------------------------------------------
### helper functions
#------------------------------------------------------------------------------


def calculate_nb_pctofso(i):
    
    
    #--------------------------------------------------------------------------

    # step 1 - dates and timestamps
    #--------------------------------------------------------------------------
    t_1d = pd.to_datetime(i, format='%Y%m%d.parquet')
    t_1d_str = t_1d.strftime('%Y%m%d')
    t_0d_str = i_cal.loc[i_cal['T-1d']==t_1d, 'DataDate'].dt.strftime('%Y-%m-%d').iloc[0]
    t_0d = pd.to_datetime(t_0d_str)
    
        
    
    #---- hk
    # 'Ticker', 'hk_b_shares', 'hk_c_shares', 'hk_bb_shares', 'craw', 'float', 'flg_cndb_hk', 'DataDate'
    root_hk = '/dat/summit_capital/PROD/TZ/hk_holding/'
    i_nb = pd.read_parquet(root_hk + t_0d_str.replace('-','')+'.parquet')    
    
    i_nb['hk_bb_dv_so'] = i_nb['hk_bb_shares'] / i_nb['float']
    i_nb['hk_b_dv_so'] = i_nb['hk_b_shares'] / i_nb['float']
    i_nb['hk_c_dv_so'] = i_nb['hk_c_shares'] / i_nb['float']
    
    i_nb[['DataDate', 'Ticker', 'hk_bb_dv_so', 'hk_b_dv_so', 'hk_c_dv_so']].to_parquet(os.path.join(save_path, i))
    

    
    
    







if __name__ == '__main__':
    
    with Pool(20) as p:
        p.map(calculate_nb_pctofso, dates_to_query)
        
