﻿#$%^&* pTrend_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 24 22:31:11 2020

@author: thzhang
"""

import pandas as pd
import numpy as np

import time, datetime
import sys

from yz import tic, toc, get_sql, bt

import random

from sklearn import linear_model
from sklearn.linear_model import LogisticRegression
import statsmodels.tsa.stattools as ts

from numba import njit

# this script is similar to 06, but runs cointegration test after correlation studies


#--------------------------------------------------------------------------
### get bbg mkt data from sql
#--------------------------------------------------------------------------

# tk uni
i_tk = get_sql("select distinct ticker from [BackTest].[dbo].[Static_Data_Daily] ")['ticker'].unique().tolist()

# get bbg data
i_bbg = get_sql(''' select ticker, id_bb_unique as bbgid, datadate, [INDUSTRY_GROUP] as gsector, 
                    px_last as c, px_open as o, px_high as h, px_low as l, px_volume as v,
                    case when adjret is null then px_last/px_yest_close-1 else adjret end as ret_c_c, 
                    px_last/px_open-1 as ret_o_c, [CUR_MKT_CAP] as mkt_cap 
                    from [BackTest].[dbo].[BBG_MktData_Hist]
                    where ticker in ('{0}') and 
                    (px_last is not null) and (px_open is not null) '''.format("','".join(i_tk)  ))

# process nans - ohlcv
i_bbg = i_bbg[i_bbg.o.notnull() & i_bbg.h.notnull() & i_bbg.l.notnull() & i_bbg.c.notnull() & i_bbg.v.notnull()]

# process nans - ret_c_c
i_bbg = i_bbg.sort_values(['ticker','bbgid', 'datadate']) 
c_nan = i_bbg['ret_c_c'].isnull()
i_bbg.loc[c_nan, 'ret_c_c'] = i_bbg.groupby(['ticker','bbgid'])['c'].apply(lambda x: x.divide(x.shift())-1).values[c_nan]
i_bbg = i_bbg[i_bbg['ret_c_c'].notnull()]

# calc sector membership per datadate
i_bbg = i_bbg.sort_values(['datadate','gsector']).reset_index(drop = True)
i_index = i_bbg.groupby(['datadate','gsector']).apply(lambda x: pd.Series([x.index.min(), x.index.max()], index= ['s','e']))
o_sector_dic = {}
for d in pd.to_datetime(i_bbg.datadate.unique()):
    o_sector_dic[d.strftime('%Y%m%d')] = {}
for i in range(len(i_index)):
    t_ticker = i_bbg['ticker'].iloc[i_index.iloc[i]['s']:i_index.iloc[i]['e']+1].tolist()
    o_sector_dic[i_index.index[i][0].strftime('%Y%m%d')][i_index.index[i][1]] = t_ticker


# get barrret data
i_sd = get_sql(''' select ticker, datadate, [BarrRet_srisk+0d] as bret, [BarrRet_srisk+1d] as bret_p1d,
               [Raw
Ret+1d] as ret_p1d, 
               srisk, beta, btop, divyild, earnyild, growth,leverage,liquidty, momentum, resvol,size, spread 
               from [BackTest].[dbo].[Static_Data_Daily] ''')



#--------------------------------------------------------------------------
### Calculate deviation 
#--------------------------------------------------------------------------


pv_bbg = i_bbg.pivot_table(index = 'datadate', columns = 'ticker', values = 'c')


LOOKBACK = 120
o_sgnl = []
tic()
for i in range(1300, len(pv_bbg)-1):
    tic()
    for sector in list(o_sector_dic[pv_bbg.index[i].strftime('%Y%m%d')].keys()):
    
        t_tk_list = o_sector_dic[pv_bbg.index[i].strftime('%Y%m%d')][sector] # get all tk for a sector
        t_pv_bbg = pv_bbg[t_tk_list] # get pv_bbg for a sector
        t_sliced1 = t_pv_bbg.iloc[i-LOOKBACK:i+1] # get-date-sliced pv_bbg #0.01s
        
        t_sliced1 = t_sliced1[t_sliced1.columns[t_sliced1.count()>int(LOOKBACK*0.8)]] # 80% of lookback have data
        t_tk_list2 = t_sliced1.columns.tolist()
        
        if len(t_tk_list2) == 0:
            continue
    
        t_corr = t_sliced1.corr() # corr matrix of all tk under a sector
        t_corr_melt = t_corr.reset_index().\
                      melt(id_vars='ticker', value_vars=t_tk_list2, var_name = 'ticker2', value_name = 'corr')
        t_corr_melt = t_corr_melt[(t_corr_melt['corr']>0.9)] # select stock pairs with corr > ###???
        t_corr_melt = t_corr_melt[(t_corr_melt['ticker']!=t_corr_melt['ticker2'])]
        t_corr_melt = t_corr_melt.sort_values(['ticker', 'corr'], ascending = False) # melt corr matrix - 0.08s
    
        t_tk_list_cnt = t_corr_melt.groupby('ticker')[['ticker2','corr']].\
                        apply(lambda x: pd.DataFrame([[x['ticker2'].tolist()[:10],
                                                       x['ticker2'].iloc[:10].count(),
                                                       x['corr'].iloc[:10].mean()]], 
                                                     columns= ['tk_lst','tk_cnt','mean_corr'])) # descriptive stats
        if len(t_tk_list_cnt)==0:
            continue
        #t_tk_list_cnt = t_tk_list_cnt[t_tk_list_cnt['tk_cnt']>=1] 
        t_tk_list_cnt = t_tk_list_cnt.reset_index().set_index('ticker') #0.2s        
    
        t_data_cnt = t_sliced1.count() # calc not-null data point count per ticker
        t_last_not_nan = t_pv_bbg.iloc[i].notnull() # last row not nan #0.03s
    
        t_filter = pd.concat([t
_tk_list_cnt, t_data_cnt, t_last_not_nan], axis = 1, sort = False) # combine stats
        t_filter.columns = ['level_1','tk_lst', 'tk_cnt', 'mean_corr','cnt', 'last_not_null']
        t_filter = t_filter[(t_filter['cnt'] > int(LOOKBACK*0.8) ) &\
                            (t_filter['last_not_null']) &\
                            t_filter['tk_lst'].notnull()] # at least 100 data points #0.004s
        
        
        # loop over tickers (2.5s for 550 tickers) and predict + sgnl
        for num in range(len(t_filter)):
        
            tgt_tk = t_filter.index[num] # target tk
            t_tk_lst = t_filter.iloc[num]['tk_lst'] # independent vars
    
            x = pv_bbg[t_tk_lst].iloc[i-LOOKBACK:i+1] # x and y
            y = pv_bbg[tgt_tk].iloc[i-LOOKBACK:i+1] #0.01s
    
            cond_notnull = x.notnull().all(axis=1) & y.notnull() # not null condition
            x = x[cond_notnull]
            y = y[cond_notnull].values #0.005
            
            if (len(x) == 0) | (len(y) == 0):
                continue
            
            X = np.c_[x, np.ones(x.shape[0])] # add constant term
            
            beta_hat = np.linalg.lstsq(X[:], y, rcond=None)[0] # estimate beta (incl. constant term)
            
            t_pred_ts = np.dot(X,beta_hat) # predicted time series
            t_pred_today = t_pred_ts[-1] # prediction for today
            t_actual = y[-1] # actual for today
            
            t_resid = t_pred_ts - y # resid
            t_adf = ts.adfuller(t_resid,regression="c", autolag=None) # cointegration test # 0.04s
            
            o_sgnl.append([pv_bbg.index[i], # datadate
                           tgt_tk, # ticker
                           (t_pred_today - t_actual) / t_actual, # sgnl
                           t_pred_today, # prediction of price
                           t_filter.mean_corr[num], # mean corr
                           len(t_tk_lst), # independent var number
                           t_adf[0], # adf test score
                           t_adf[4]['1%'], # critical value
                           t_adf[4]['5%'],
                           (t_resid[-1]-np.mean(t_resid))/np.std(t_resid), # deviations from mean resid
                           ])
    toc(str(i)+', ')

    
toc() #5600 seconds for 800 tickers

df_sgnl = pd.DataFrame(o_sgnl, columns = ['datadate', 'ticker', 'sgnl', 'prediction', 'mean_corr','x_cnt',
                                          'adf_score', 'adf_crvalue1', 'adf_c
rvalue5', 'resid_deviation'])
df_sgnl = df_sgnl.merge(i_sd[['ticker', 'datadate', 'bret', 'bret_p1d', 'ret_p1d', 'srisk', 'beta', 'btop', 'divyild',
                              'earnyild', 'growth', 'leverage', 'liquidty', 'momentum', 'resvol',
                              'size', 'spread']], on = ['datadate','ticker'], how = 'left')



# cache data
#df_sgnl.to_parquet(r'S:\Data\test\pMReverse_05_10tk_corr8.parquet')
#df_sgnl.to_parquet(r'S:\Data\test\pMReverse_05_40tk_corr8.parquet') # not getting better
#df_sgnl.to_parquet(r'S:\Data\test\pMReverse_05_10tk_corr9.parquet')
df_sgnl.to_parquet(r'S:\Data\test\pMReverse_09_10tk_corr9_120d.parquet')

df_sgnl = pd.read_parquet(r'S:\Data\test\pMReverse_09_10tk_corr9_120d.parquet')



# merge bbg mkt data to sgnl
df_sgnl_mktdata = i_bbg.merge(df_sgnl, on = ['datadate', 'ticker'], how = 'left')

# get trailing sharpe 
df_sgnl_mktdata = df_sgnl_mktdata.sort_values(['ticker', 'datadate'])
df_sgnl_mktdata = df_sgnl_mktdata.merge(i_sd[['datadate','ticker','bret']], on = ['datadate','ticker'], how ='left')
def trailing_sharpe(x):
    return x.mean()/x.std()*np.sqrt(251)
df_sgnl_mktdata['trailing_sharpe'] = df_sgnl_mktdata.groupby('ticker')['bret'].rolling(120).apply(trailing_sharpe).values

# same ticker tag
df_sgnl_mktdata = df_sgnl_mktdata.sort_values(['ticker','datadate'])
df_sgnl_mktdata['tk_same'] = df_sgnl_mktdata['ticker'] == df_sgnl_mktdata['ticker'].shift()

# factor exposure
df_sgnl_mktdata['momen_1h'] = df_sgnl_mktdata[(df_sgnl_mktdata.datadate>='20150303')&(df_sgnl_mktdata.datadate<='20200728')].groupby('datadate')['momentum'].apply(lambda x: pd.qcut(x, q=2, labels=[1,2]))



###############################################################################
### signals 
###############################################################################



t_pst = np.zeros(len(df_sgnl_mktdata))

for i in range(1,len(df_sgnl_mktdata)):
    
    # hold pst
    if (t_pst[i-1]>0) and (df_sgnl_mktdata['tk_same'].values[i]):
        t_pst[i] = max(t_pst[i-1], -df_sgnl_mktdata['resid_deviation'].values[i]/20)
    
    if (t_pst[i-1]<0) and (df_sgnl_mktdata['tk_same'].values[i]):
        t_pst[i] = min(t_pst[i-1], -df_sgnl_mktdata['resid_deviation'].values[i]/20)
    
    # stop loss
    if (df_sgnl_mktdata['trailing_sharpe'].values[i]< 0.5) and (t_pst[i]>0) and (df_sgnl_mktdata['tk_same'].values[i]):
        t_pst[i] = 0
    elif (df_sgnl_mktdata['trailing_sharpe'].values[i] >-0.5) and (t_pst[i]<0) and (df_sgnl_mktdata[
'tk_same'].values[i]):
        t_pst[i] = 0
    
    # stop win
    if (df_sgnl_mktdata['resid_deviation'].values[i] > 1.5) and (t_pst[i]>0) and (df_sgnl_mktdata['tk_same'].values[i]):
        t_pst[i] = 0
    elif (df_sgnl_mktdata['resid_deviation'].values[i] < -1.5) and (t_pst[i]<0) and (df_sgnl_mktdata['tk_same'].values[i]):
        t_pst[i] = 0
        
    # open pst
    if (df_sgnl_mktdata['resid_deviation'].values[i]<-0.5) and\
        (t_pst[i]<=0) and df_sgnl_mktdata['trailing_sharpe'].values[i]>2:
        t_pst[i] = df_sgnl_mktdata['resid_deviation'].values[i]/20
    elif (df_sgnl_mktdata['resid_deviation'].values[i]>0.5)  and\
        (t_pst[i]>=0) and df_sgnl_mktdata['trailing_sharpe'].values[i]<-2:
        t_pst[i] = df_sgnl_mktdata['resid_deviation'].values[i]/20
    
    


# bt without cointegration, considering clip
df_sgnl_mktdata['pst'] = t_pst
df_sgnl_mktdata.loc[df_sgnl_mktdata['pst']>0.3,'pst']=0.3
df_sgnl_mktdata.loc[df_sgnl_mktdata['pst']<-0.3,'pst']=-0.3



o2 = bt(df_sgnl_mktdata[(df_sgnl_mktdata.datadate<'2020-10-01')].dropna(subset=['pst','bret_p1d']).drop_duplicates(subset=['ticker','datadate']),
        'pst','bret_p1d')



# factor performance
    
o_analysis = pd.DataFrame()
for fc in ['srisk', 'beta', 'btop', 'divyild', 'earnyild', 'growth', 'leverage', 
           'liquidty', 'momentum', 'resvol', 'size', 'spread']:
    o2[fc+'_bk'] = pd.qcut(o2[fc], q = 10, labels = range(1,11))
    o_analysis = pd.concat([o_analysis, o2[(o2.datadate<='20200201')&(o2.pnl!=0)].groupby(fc+'_bk')['pnl_tcost'].median().reset_index()], axis = 1)





#df_sgnl_mktdata.loc[df_sgnl_mktdata['sgnl'].abs()<0.01,'sgnl'] = 0 # this makes little difference to pnl


# before pnl, decide if we need the signal 
df_sgnl_mktdata['keep_cointegration'] = 0
df_sgnl_mktdata.loc[df_sgnl_mktdata.adf_score<df_sgnl_mktdata.adf_crvalue1,'keep_cointegration'] = 1



# pnl for all
df_sgnl_mktdata['pnl'] = df_sgnl_mktdata['pst'].multiply(df_sgnl_mktdata['bret_p1d'])
df_sgnl_mktdata.groupby('datadate')['pnl'].sum().cumsum().plot() 
o2 = bt(df_sgnl_mktdata[(df_sgnl_mktdata.datadate<'2020-09-01')].dropna(subset=['pst','bret_p1d']).drop_duplicates(subset=['ticker','datadate']), 'pst','bret_p1d')

#------------------------------------------------------------------------------
# pnl for cointegrated pairs -> ??? why cointegrated stocks are worse?
df_sgnl_mktdata['pnl'] = df_sgnl_mktdata['pst'].multiply(df_sgnl_mktdata['bret_p1d']).multiply(df_sgnl_mktdata['keep_cointegration
'])
df_sgnl_mktdata.groupby('datadate')['pnl'].sum().cumsum().plot()

df_sgnl_mktdata_d = df_sgnl_mktdata.groupby('datadate')['pnl'].sum()
df_sgnl_mktdata_d.mean()/df_sgnl_mktdata_d.std()*np.sqrt(252)

#------------------------------------------------------------------------------
# pnl for lower momentum pairs - this worked - s1.36

df_sgnl_mktdata['pst_bt'] = df_sgnl_mktdata['pst'].multiply(df_sgnl_mktdata['momentum'].abs()<1)
df_sgnl_mktdata['pnl'] = df_sgnl_mktdata['pst_bt'].multiply(df_sgnl_mktdata['bret_p1d'])
df_sgnl_mktdata.groupby('datadate')['pnl'].sum().cumsum().plot()

o2 = bt(df_sgnl_mktdata[(df_sgnl_mktdata.datadate<'2020-09-01')].dropna(subset=['pst_bt','bret_p1d']).drop_duplicates(subset=['ticker','datadate']), 'pst_bt','bret_p1d')

#------------------------------------------------------------------------------
# pnl for lower momentum pairs and non-cointegration - s1.44
df_sgnl_mktdata['pst_bt'] = df_sgnl_mktdata['pst'].multiply(df_sgnl_mktdata['momentum'].abs()<1).multiply(1-df_sgnl_mktdata['keep_cointegration'])
df_sgnl_mktdata['pnl'] = df_sgnl_mktdata['pst_bt'].multiply(df_sgnl_mktdata['bret_p1d'])
df_sgnl_mktdata.groupby('datadate')['pnl'].sum().cumsum().plot()

o2 = bt(df_sgnl_mktdata[(df_sgnl_mktdata.datadate<'2020-09-01')].dropna(subset=['pst_bt','bret_p1d']).drop_duplicates(subset=['ticker','datadate']), 'pst_bt','bret_p1d')





# another definition of pnl

df_sgnl_mktdata['pnl_2'] = df_sgnl_mktdata['sgnl'].multiply(df_sgnl_mktdata['ret_c_c'])
df_sgnl_mktdata.groupby('datadate')['pnl_2'].sum().cumsum().plot() # it looks good so far

# a more formal backtest
###!!!
# its result is different from the above because the sgnl (or pst) is assumed to be % of a slip
df_sgnl_bt = i_bbg.merge(df_sgnl, on = ['datadate', 'ticker'], how = 'left')
df_sgnl_bt = df_sgnl_bt.sort_values(['ticker','datadate'])
df_sgnl_bt['sgnl_1d'] = df_sgnl_bt.groupby('ticker')['sgnl'].shift(1)
df_sgnl_bt.loc[df_sgnl_bt['sgnl_1d'].abs()>0.05,'sgnl_1d'] = \
    np.sign(df_sgnl_bt.loc[df_sgnl_bt['sgnl_1d'].abs()>0.05,'sgnl_1d'])*0.05

o2 = bt(df_sgnl_bt[(df_sgnl_bt.datadate<'2020-09-01')].dropna(subset=['sgnl_1d','bret']),'sgnl_1d','bret')


###!!!
# dynamic subuniverse


t_valid_dates = df_sgnl_mktdata.loc[df_sgnl_mktdata['sgnl'].notnull(), 'datadate'].unique()
df_sgnl_mktdata.loc[df_sgnl_mktdata['pnl']>0,'pnl_1_0'] = 1
df_sgnl_mktdata.loc[df_sgnl_mktdata['pnl']<=0,'pnl_1_0'] = 0

t_factor_cols = ['srisk', 'beta', 'btop', 'divyild', 'earnyild', 'growth', 'leverage',
 
                 'liquidty', 'momentum', 'resvol', 'size', 'spread']
o_subuni = pd.DataFrame()

for i in range(122, len(t_valid_dates)):
    
    t_df = df_sgnl_mktdata[df_sgnl_mktdata.datadate.between(t_valid_dates[i-121],t_valid_dates[i-1])]
    
    t_df_last_day = df_sgnl_mktdata[df_sgnl_mktdata.datadate==t_valid_dates[i]]
    

    x = t_df[t_factor_cols]
    y = t_df['pnl_1_0']
    
    cond_notnull = x.notnull().all(axis=1) & y.notnull()
    x = x[cond_notnull]
    y = y[cond_notnull] #0.005
            
    if (len(x) == 0) | (len(y) == 0):
        continue
    
    
    clf = LogisticRegression(random_state=0, solver='lbfgs').fit(x, y)
    cond_factor_notnull = t_df_last_day[t_factor_cols].notnull().all(axis = 1)
    
    if cond_factor_notnull.sum() == 0:
        continue
    
    t_o1 = pd.DataFrame({'ticker': t_df_last_day.loc[cond_factor_notnull, 'ticker'].values,
                         'prediction': clf.predict(t_df_last_day[cond_factor_notnull][t_factor_cols])})
    t_o1['datadate'] = t_valid_dates[i]
    
    o_subuni = o_subuni.append(t_o1, sort = False)
    
    print (i, end = ',')

# pnl for the "dynamic subuni" idea

o_subuni.columns

df_sgnl_subuni = df_sgnl_mktdata.merge(o_subuni, on = ['ticker', 'datadate'], how = 'left')
df_sgnl_subuni['pnl_selected'] = np.nan
df_sgnl_subuni.loc[df_sgnl_subuni['prediction_y']==1,'pnl_selected'] = df_sgnl_subuni.loc[df_sgnl_subuni['prediction_y']==1,'pnl']
    
df_sgnl_subuni.groupby('datadate')['pnl_selected'].sum().cumsum().plot()

# sharpe for the "dynamic subuni" idea
df_sgnl_subuni_s = df_sgnl_subuni[df_sgnl_subuni['pnl'].notnull()]
df_sgnl_subuni_s = df_sgnl_subuni_s.groupby('datadate')['pnl'].sum()
df_sgnl_subuni_s = df_sgnl_subuni_s.reset_index()
df_sgnl_subuni_s['pnl'].mean()/df_sgnl_subuni_s['pnl'].std()*np.sqrt(252)



#------------------------------------------------------------------------------
# attribution - ticker
pnl_tk = df_sgnl_mktdata.groupby('ticker')['pnl'].sum()

# attribution - sector
pnl_sector = df_sgnl_mktdata.groupby('gsector')['pnl'].sum()


# sharpe
df_sgnl_mktdata_s = df_sgnl_mktdata[df_sgnl_mktdata['pnl'].notnull()]
df_sgnl_mktdata_s = df_sgnl_mktdata_s.groupby('datadate')['pnl'].sum()
df_sgnl_mktdata_s = df_sgnl_mktdata_s.reset_index()
df_sgnl_mktdata_s['pnl'].mean()/df_sgnl_mktdata_s['pnl'].std()*np.sqrt(252)

# decile
df_sgnl_mktdata['decile'] = pd.cut(df_sgnl_mktdata['sgnl'], bins = 10, labels = range(1,11))
df_sgnl_mktdata.groupby('decile')['ret_c_c'].mean()

df_sgnl_mktdata.groupby('decile')['bret'].mean()



# check single ticker
t1 = df_sgnl_mktdata[df_sgnl_mktdata.ticker=='LC']
t1= t1.sort_values('datadate')
t1['cum_pnl'] = t1['pnl'].cumsum()
t1.set_index('datadate')['cum_pnl'].plot()
t1.set_index('datadate')[['c','prediction']].plot()




#------------------------------------------------------------------------------
# table2

# b0 and b1 data
df_sgnl_mktdata = df_sgnl_mktdata.sort_values(['ticker','datadate'])
df_sgnl_mktdata = df_sgnl_mktdata.rename(columns={'sgnl':'sgnl_1d'})
df_sgnl_mktdata['sgnl_0d'] = df_sgnl_mktdata.groupby('ticker')['sgnl_1d'].shift(-1)

df_sgnl_mktdata = df_sgnl_mktdata[df_sgnl_mktdata['sgnl_1d'].notnull() & df_sgnl_mktdata['sgnl_0d'].notnull()]

# size_bk

df_sgnl_mktdata['size_bk'] = df_sgnl_mktdata.groupby('datadate')['size'].apply(lambda x: pd.qcut(x,q=5,labels=range(1,6)))

# for each ticker, estimate b0 and b1
o_table2=[]
df_sgnl_mktdata = df_sgnl_mktdata.reset_index(drop = True)
i_index = df_sgnl_mktdata.groupby('ticker').apply(lambda x: pd.Series([x.index.min(), x.index.max()], index= ['s','e']))
for tk in df_sgnl_mktdata.ticker.unique():
    
    #t_data = df_sgnl_mktdata[df_sgnl_mktdata.ticker==tk]
    t_data = df_sgnl_mktdata.loc[i_index.loc[tk]['s']:i_index.loc[tk]['e']]
    t_data = t_data[t_data['size_bk'].notnull()]
    
    if len(t_data) <= 100:
        continue
    
    # multiple regression, profit and other metrics
    regr_all = linear_model.LinearRegression()
    regr_all.fit(t_data[['sgnl_0d','sgnl_1d']], t_data['ret_c_c'])
    t_data_e = t_data['ret_c_c'] - regr_all.predict(t_data[['sgnl_0d','sgnl_1d']])
    o_table2.append([tk, 
                     t_data['size_bk'].mode().iloc[0], 
                     regr_all.intercept_, 
                     regr_all.coef_[0], 
                     regr_all.coef_[1],
                     np.sum(np.multiply(t_data_e.iloc[:-1].values-t_data_e.iloc[:-1].mean(),t_data_e.iloc[1:].values-t_data_e.iloc[1:].mean()))/(len(t_data)-2)
                     ])


o_table2 = pd.DataFrame(o_table2, columns = ['ticker', 'size_bk','mu', 'b0', 'b1', 'e_autocov'])

# output: table 2
o1 = o_table2.groupby('size_bk')[['b0','b1']].apply(lambda x: pd.Series([x['b0'].mean(), 
                                                                    x['b0'].mean()/(x['b0'].std())*np.sqrt(len(x)),
                                                                    x['b1'].mean(),
                                                                    x[
'b1'].mean()/(x['b1'].std())*np.sqrt(len(x)),
                                                                    (x['b0']-x['b0'].mean()).multiply(x['b1']-x['b1'].mean()).sum()/len(x),
                                                                    (x['b0']-x['b0'].mean()).multiply(x['b1']-x['b1'].mean()).mean() / ((x['b0']-x['b0'].mean()).multiply(x['b1']-x['b1'].mean()).std()) * np.sqrt(len(x)),
                                                                    len(x)
                                                                    ], index = ['b0','b0_tstat','b1','b1_tstat','delta','delta_tstat','sample_size']))


