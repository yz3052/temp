﻿#$%^&* pVA_01b.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat May 30 13:12:00 2020

@author: thzhang
"""

import pandas as pd
import numpy as np
import os 

from yz.util import tic, toc, get_sd

import time

import gc

# this script feteches normalized data from Z drive 
#  ... and save sumamry estiamte data to parquet per ticker
#  ... and save detailed estimate data to parquet per ticker


# get all normalized file names 

filelist = []
t1 = time.time()
for root, dirs, files in os.walk(r'Z:\VisibleAlpha\Normalized'):
	for file in files:
		filelist.append(os.path.join(root,file))
print (time.time()-t1) # 1200s



# process and classify the file names

va = pd.DataFrame(filelist, columns = ['raw_dir_file_name'])

va['raw_file_name'] = va['raw_dir_file_name'].str.split('\\').str[-1]
va['raw_file_name'] = va['raw_file_name'].str.extract('(.*?).csv')

va['meta_data'] = ''
va.loc[va['raw_file_name'].str[:4].str.lower()=='meta','meta_data'] = 'm'
va.loc[va['raw_file_name'].str[:4].str.lower()=='data','meta_data'] = 'd'
va.loc[va['raw_file_name'].str[:4].str.lower()=='symb','meta_data'] = 'symbology'
va.loc[va['raw_file_name'].str[:4].str.lower()=='view','meta_data'] = 'viewname'

cond_not_s_v = (va['meta_data']!='symbology') & (va['meta_data']!='viewname')

va['id'] = ''
va.loc[cond_not_s_v,'id'] = va.loc[cond_not_s_v,'raw_file_name'].str.split('_').str[1]

va['ticker'] = ''
va.loc[cond_not_s_v,'ticker'] = va.loc[cond_not_s_v,'raw_file_name'].str.split('_').str[2]

va['std_nme'] = ''
va.loc[cond_not_s_v,'std_nme'] = va.loc[cond_not_s_v,'raw_file_name'].str.split('_').str[-3].str[0]

va['broker'] = ''
va.loc[cond_not_s_v,'broker'] = va.loc[cond_not_s_v,'raw_file_name'].str.split('_').str[-2]

va['loaddate'] = pd.to_datetime(va['raw_file_name'].str.split('_').str[-1].str.split('.').str[0], format = '%Y%m%dT%H%M%S%f')

va.to_parquet(r'S:\Data\VA\ref\va_normalized_full_file_dir.parquet',allow_truncated_timestamps=True)


# Just focus on aggregated data for now

# consensus data
va_con = va[(va['broker']=='CONSENSUS') & (va['meta_data']=='d')]
va_con['loaddatestr'] = va_con['raw_file_name'].str.split('_').str[-1]
va_con = va_con[va_con['raw_dir_file_name'].str.endswith('.csv')]

# ticker universe
i_sd = get_sd(column_type = 'backtest', extra_column_lst=['hedge','BarrRet+1d'])
i_sd_tk = i_sd.ticker.unique()
i1 = pd.read_csv(r"Z:\1010Data\2787\2787\3DayLagConsumerData\2021\01\06\pub.consumer_data.card_us_v201803.portal.panel1.reports.combined.sales_tracker.fisca
l.daily_3day.csv")
i1 = i1[i1.ticker.isin(i_sd_tk)]
tk_uni = i1.ticker.unique().tolist()

###############################################################################
# fetch US consensus data save it as parquets
###############################################################################


def fetch_files(i, r):
    f = r['raw_dir_file_name']
    try:
        d1 = pd.read_csv(f, encoding = 'latin1')
        d1 = d1[d1['Datapoint type']!='Actual']
        d1['asofdatetime'] = r['loaddate']
    except pd.io.common.EmptyDataError:
        d1 = pd.DataFrame([], columns = ['Parameter ID','Period','Revision Date','Value','Datapoint type',
                          'Number of Brokers','Min','Max','Median','Standard Deviation','Mode','asofdatetime'])
    
    try:
        m1 = pd.read_csv(f.replace('data_','meta_'), encoding = 'latin1')
    except FileNotFoundError:
        m1 = pd.read_csv(f.replace('data_','meta_').split('.csv')[0]+'.csv', encoding = 'latin1')
    a1 = d1.merge(m1, on = 'Parameter ID', how = 'left')
    return a1
    


va_con_us = va_con[~(va_con['raw_file_name'].str.contains('_UK_') | va_con['raw_file_name'].str.contains('_CN_'))]
va_con_us = va_con_us[va_con_us.ticker.isin(tk_uni)]


for symb in va_con_us['id'].unique().tolist():
    
    if os.path.exists(os.path.join(r'S:\Data\VA\US\nme_e',symb + '.parquet')):
        continue
    
    tic()
    
    file_lists = va_con_us[va_con_us['id']==symb]

    stock_data = pd.concat((fetch_files(i,r) for i, r in file_lists.iterrows()), ignore_index = True, sort = False)
    stock_data['announce_date'] = pd.to_datetime(stock_data['Revision Date'], format='%Y%m%dT%H%M%S%f', errors = 'coerce')
    stock_data = stock_data.drop(columns = ['Revision Date'])
    stock_data = stock_data.drop_duplicates()
    stock_data['Symbology_ID'] = symb
    stock_data.to_parquet(os.path.join(r'S:\Data\VA\US\nme_e',symb + '.parquet' ),allow_truncated_timestamps=True)
    
    del stock_data
    gc.collect()
    
    toc(' ' +symb+ ', ')






###############################################################################
# actual data - US
###############################################################################

va_a = va[(va['broker']=='VAACTUALS') & (va['meta_data']=='d')]
va_a['loaddatestr'] = va_a['raw_file_name'].str.split('_').str[-1]
va_a = va_a[~(va_a['raw_file_name'].str.contains('_UK_') | va_a['raw_file_name'].str.contains('_CN_'))]
va_a = va_a[va_a.ticker.isin(tk_uni)]

def fetch_files2(i, r):
  
  f = r['raw_dir_file_name']

    try:
        d1 = pd.read_csv(f, encoding = 'latin1')
        d1 = d1[d1['Datapoint type']=='Actual']
        d1['asofdatetime'] = r['loaddate']
    except pd.io.common.EmptyDataError:
        d1 = pd.DataFrame([], columns = ['Parameter ID','Period','Revision Date','Value','Datapoint type','Mode of Calculation','asofdatetime'])
    try:
        m1 = pd.read_csv(f.replace('data_','meta_'), encoding = 'latin1')
    except FileNotFoundError:
        m1 = pd.read_csv(f.replace('data_','meta_').split('.csv')[0]+'.csv', encoding = 'latin1')
    a1 = d1.merge(m1, on = 'Parameter ID', how = 'left')
    return a1
    

for symb in va_a['id'].unique().tolist():
    if os.path.exists(os.path.join(r'S:\Data\VA\US\nme_a',symb + '.parquet')):
        continue    
    tic()
    
    file_lists = va_a[va_a['id']==symb]

    stock_data = pd.concat((fetch_files2(i,r) for i, r in file_lists.iterrows()), ignore_index = True, sort = False)
    stock_data['annouce_date'] = pd.to_datetime(stock_data['Revision Date'], format='%Y%m%dT%H%M%S%f', errors = 'coerce')
    stock_data = stock_data.drop(columns = ['Revision Date'])
    stock_data = stock_data.drop_duplicates()
    stock_data['Symbology_ID'] = symb
    stock_data.to_parquet(os.path.join(r'S:\Data\VA\US\nme_a',symb + '.parquet' ),allow_truncated_timestamps=True)
    
    del stock_data
    gc.collect()
    
    toc(' ' +symb+ ', ')





###############################################################################
# filing data
###############################################################################

va_f = va[(va['broker']=='Filings') & (va['meta_data']=='d')]
va_f['loaddatestr'] = va_f['raw_file_name'].str.split('_').str[-1]
va_f = va_f[~(va_f['raw_file_name'].str.contains('_US_') | va_f['raw_file_name'].str.contains('_CN_'))]
va_f = va_f[va_f.ticker.isin(tk_uni)]

def fetch_files3(i, r):
    f = r['raw_dir_file_name']
    d1 = pd.read_csv(f, encoding = 'latin1')
    d1 = d1[d1['Datapoint type']=='Actual']
    d1['asofdatetime'] = r['loaddate']
    try:
        m1 = pd.read_csv(f.replace('data_','meta_'), encoding = 'latin1')
    except FileNotFoundError:
        m1 = pd.read_csv(f.replace('data_','meta_').split('.csv')[0]+'.csv', encoding = 'latin1')
    a1 = d1.merge(m1, on = 'Parameter ID', how = 'left')
    return a1
    

for symb in va_f['id'].unique().tolist():
    if os.path.exists(os.path.join(r'S:\Data\VA\US\nme_filing',symb + '.parquet')):
        continue       
    ti
c()
    
    file_lists = va_f[va_f['id']==symb]

    stock_data = pd.concat((fetch_files3(i,r) for i, r in file_lists.iterrows()), ignore_index = True, sort = False)
    stock_data['announce_date'] = pd.to_datetime(stock_data['Revision Date'], format='%Y%m%dT%H%M%S%f', errors = 'coerce')
    stock_data = stock_data.drop(columns = ['Revision Date'])
    stock_data = stock_data.drop_duplicates()
    stock_data ['Effective End'] = pd.to_datetime(stock_data ['Effective End'])
    stock_data['Symbology_ID'] = symb
    stock_data.to_parquet(os.path.join(r'S:\Data\VA\US\nme_filing',symb + '.parquet' ),allow_truncated_timestamps=True)
    
    del stock_data
    gc.collect()
    
    toc(' ' +symb+ ', ')


