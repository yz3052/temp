﻿#$%^&* pDataYes_recruit_sCache_2.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 31 10:19:20 2021

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import zipfile
import csv

import jieba

from snownlp import SnowNLP

from multiprocessing import Pool

# this calculates cached data for string-level analysis
# this works with multiprocessing, so we have better speed 


def f(x):
    return x*x


def jd_segment_cut(x):
    return '@'.join( list(set(jieba.cut(x))) )

def jd_sentiment(x):
    return SnowNLP(x).sentiments if x!='' else np.nan





if __name__ == '__main__':
    
    
    
    
    
    
    #--------------------------------------------------
    ### calculate all jd seg
    
    
    i_files = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\txt_w_tk')
    COLS=['id','ticker','job_desc','datadate']
    i_str = pd.concat(pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\txt_w_tk',f), columns=COLS) for f in i_files)
    i_str = i_str[i_str['ticker'].notnull()]
    
    i_str['job_desc'] = i_str['job_desc'].fillna('')
#    i_str['jd_clean'] = i_str['job_desc'].str.replace('\(.*\)','').str.replace('（.*）','').\
#                         str.replace('\d+、',' ').str.replace('\d+\.',' ').\
#                         str.replace('\r', ' ').str.replace('\n', ' ').\
#                         str.replace('\[.*\]','').str.replace('\【.*\】','').\
#                         str.replace('（|）|,|，|\.|。|:|：|;|；|\(|\)|\*|~|`|!|@|#|$|&|-|—|\+|\/|、|\?',' ').\
#                         str.strip().str.replace('[ ]+', ' ').\
#                         str.upper()
#    i_str['jd_len'] = i_str['jd_clean'].str.len()

#    with Pool(24) as p_24:
#        i_str['jd_seg'] = p_24.map(jd_segment_cut, i_str['jd_clean'].tolist()) # 5min
        
    with Pool(24) as p_24:        
        i_str['jd_raw_senti'] = p_24.map(jd_sentiment, i_str['job_desc'].tolist()) # 
    
#    with Pool(24) as p_24:
#        i_str['jd_clean_senti'] = p_24.map(jd_sentiment, i_str['jd_clean'].tolist()) # 4hours, 5m rows
#    
    
    
    '''
    # get main post data
    i_files2 = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet')
    i_post = pd.concat(pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet',f),columns=['id','source','ticker_symbol']) for f in i_files2)
    i_post = i_post[i_post['ticker_symbol'].notnull()]
    i_post = i_post[i_pos
t['ticker_symbol'].str.contains('\d{6}')]
    
    # merge source into txt
    i_str = i_str.merge(i_post[['id','source']], on = ['id'], how = 'left')
    
    i_str[['id','ticker','datadate','jd_seg','jd_len','source','jd_clean_senti']].to_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_jd_segs.parquet')
    
    '''
    
    
    
    
    
    
    '''
    ### monthly, ttm, jd seg set, per tk
    
    i_str = pd.read_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_jd_segs.parquet')
    
    
    i_t1y_segset = pd.DataFrame()
    for dt in pd.date_range(start = '2017-01-01', end = '2020-05-31'):
        if dt.day != 1:
            continue
        print('.', end='')
        t_str = i_str[i_str['datadate'].between(dt-pd.to_timedelta('365 days'), dt)]
        t_segs = t_str.groupby('ticker')['jd_seg'].apply(lambda x:  '@'.join(list(set('@'.join(x.tolist()).split('@')))) ).reset_index()
        t_segs = t_segs.rename(columns={'jd_seg': 'jd_seg_set'})
        t_segs['datadate'] = dt
        
        i_t1y_segset = i_t1y_segset.append(t_segs, sort = False)
        t_str = None
        t_segs = None
    
    
    
    i_t1y_segset.to_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_monthly_ttm_jdSegSet_per_tk.parquet')
    
    
    
    
    ### monthly, ttm, jd seg set, per tk, source=51job
    
    i_str = pd.read_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_jd_segs.parquet')
    i_str = i_str[i_str['source']=='51job']
    
    i_t1y_segset = pd.DataFrame()
    for dt in pd.date_range(start = '2017-01-01', end = '2020-05-31'):
        if dt.day != 1:
            continue
        print('.', end='')
        t_str = i_str[i_str['datadate'].between(dt-pd.to_timedelta('365 days'), dt)]
        t_segs = t_str.groupby('ticker')['jd_seg'].apply(lambda x:  '@'.join(list(set('@'.join(x.tolist()).split('@')))) ).reset_index()
        t_segs = t_segs.rename(columns={'jd_seg': 'jd_seg_set'})
        t_segs['datadate'] = dt
        
        i_t1y_segset = i_t1y_segset.append(t_segs, sort = False)
        t_str = None
        t_segs = None
        
    
    i_t1y_segset.to_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_monthly_ttm_jdSegSet_per_tk_51job.parquet')
    
    
    
    
    #--------------------------------------------------
    ### calculate all title seg
    
    
    i_p = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet')
    
    i_tk_str = pd.DataFrame()
    for p in i_p:
        t_data = pd.read_parquet(o
s.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet', p),
                                 columns = ['id','ticker_symbol','source','title','published_at'])
        t_data = t_data[t_data['ticker_symbol'].notnull()]
        t_data = t_data[t_data['ticker_symbol'].str.contains('\d{6}')]
        
        
        t_data['datadate'] = pd.to_datetime(pd.to_datetime(t_data['published_at']) + pd.to_timedelta('1 day'))
        
        
        t_data['title3'] = t_data['title'].str.replace('\(.*\)','').str.replace('（.*）','').\
                     str.replace('\[.*\]','').str.replace('\【.*\】','').\
                     str.replace('\d[K|k|W|w|千|万]','').str.replace('\d','').\
                     str.replace('（|）|,|，|\.|。|:|：|;|；|\(|\)|\*|~|`|!|@|#|$|&|-|—|\+|\/|、|\?',' ').\
                     str.replace('职位编号','').\
                     str.strip().str.replace('[ ]+', ' ').\
                     str.upper()
        t_data = t_data[t_data['title3'].notnull() & (t_data['title3']!='')]
        t_data['title_seg'] = t_data['title3'].apply(lambda x: '@'.join(jieba.cut(x)))
    
        
        c_sz = t_data['ticker_symbol'].str[0].isin(['0', '3'])
        c_sh = t_data['ticker_symbol'].str[0].isin(['6'])
        t_data.loc[c_sz, 'ticker'] = t_data.loc[c_sz, 'ticker_symbol'] + '.SZ'
        t_data.loc[c_sh, 'ticker'] = t_data.loc[c_sh, 'ticker_symbol'] + '.SH'
        t_data = t_data.drop(columns=['ticker_symbol'])
        
        i_tk_str = i_tk_str.append(t_data, sort = False)
    
    
    i_tk_str[['id', 'source', 'datadate', 'title_seg', 'ticker']].to_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_title_segs_alltk.parquet')
    
    
    
    
    
    ### daily, ttm, title seg set, per tk, all sources
    
    
    i_tk_str = pd.read_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_title_segs_alltk.parquet')
    
    i_tk_t1y_seg = pd.DataFrame()
    for dt in pd.date_range(start = '2017-01-01', end = '2021-06-30'):
        print('.', end='')
        t_str = i_tk_str[(i_tk_str['datadate']<=dt) & (i_tk_str['datadate']>=dt-pd.to_timedelta('365 days'))]
    
        t_seg = t_str.groupby('ticker')['title_seg'].\
                apply(lambda x: '@'.join(list(set(('@'.join(x.tolist())).split('@'))))).reset_index()
        t_seg['datadate'] = dt
        
        i_tk_t1y_seg = i_tk_t1y_seg.append(t_seg, sort = False)
    
    i_tk_t1y_seg.to_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_daily_ttm_titleSegSet_per_tk.parquet')
    

    
    
    
    ### daily, ttm, title seg set, per tk, source = 51job
    
    
    i_tk_str = pd.read_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_title_segs_alltk.parquet')
    i_tk_str = i_tk_str[i_tk_str['source']=='51job']
    
    i_tk_t1y_seg = pd.DataFrame()
    for dt in pd.date_range(start = '2017-01-01', end = '2021-06-30'):
        print('.', end='')
        t_str = i_tk_str[(i_tk_str['datadate']<=dt) & (i_tk_str['datadate']>=dt-pd.to_timedelta('365 days'))]
    
        t_seg = t_str.groupby('ticker')['title_seg'].\
                apply(lambda x: '@'.join(list(set(('@'.join(x.tolist())).split('@'))))).reset_index()
        t_seg['datadate'] = dt
        
        i_tk_t1y_seg = i_tk_t1y_seg.append(t_seg, sort = False)
    
    i_tk_t1y_seg.to_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_daily_ttm_titleSegSet_per_tk_51job.parquet')
    
    
    import ray
    ray.init()
    
    @ray.remote
    def f(x):
        return x * x
    
    futures = [f.remote(i) for i in range(4)]
    print(ray.get(futures)) # [0, 1, 4, 9]
    
    '''
