﻿#$%^&* featurepool_cn_earn_exp_prod2.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  7 17:08:04 2022

@author: thzhang
"""


import pandas as pd
import numpy as np


import datetime

from sqlalchemy import create_engine
import urllib
import pyodbc

import scipy.stats as ss

# to be scheduled on crontab at 5 am


# create table F008_ERNEXP_FORMAT (DataDate datetime, Ticker varchar(max), descriptor float)


#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------

#save_path = '/export/dataprod/Feature_Pool_CN/featurepool_desc_earn_exp'

conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
conn_wind = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=WIND_PROD;UID=svc_wind_dbo;PWD=DusONA3Habredl;TDS_Version=8.0;')
today = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
today = pd.to_datetime(today.date())
today_str = today.strftime('%Y%m%d')




#------------------------------------------------------------------------------
### rerank
#------------------------------------------------------------------------------


def rerank(r):
    rindex = r.index
    res = np.zeros(len(r))
    res = res + float('nan')
    x2 = np.array(r)
    x2 = x2[~np.isnan(x2)]
    x3 = list(x2)    
    x3.reverse()
    x3 = list(ss.rankdata(x3)-1)
    x3.reverse()
    if len(x2) > 0:
        res2 = -1 + 1/len(x2) *(ss.rankdata(x2) - 1  + np.array(x3))
        res[~np.isnan(np.array(r))] = res2
    rdf = pd.DataFrame(res)
    rdf = rdf.set_index(rindex)
    return(rdf)


#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------

i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()




#------------------------------------------------------------------------------
### get Datadates to query
#------------------------------------------------------------------------------



dates_all = i_cal.loc[i_cal['DataDate'].ge('2017-01-01')&i_cal['DataDate'].le(today), 'DataDate'].dt.strftime('%Y-%m-%d').tolist()
dates_all = set(dates_all)

existing_dates = pd.read_sql('''select distinct DataDate from CNDBDEV.dbo.F008_ERNEXP_FORMAT''', conn)
if len(existing_dates) > 0:
    existing_dates['DataDate'] = existing_dates['DataDate'].dt.strftime('%Y-%m-%d')
    max_existing_dates = max(existing_dates['DataDate'].tolist())
    existing_dates = set(existing_dates['DataDate'].tolist())
else: 
    max_existing_dates = '0000-00-00'
    existing_dates = {}

query_dates = list(dates_all.difference(existing_dates))
query_dates = [i for i in query_dates if i>max_existing_dates]










#------------------------------------------------------------------------------
### metrics
#------------------------------------------------------------------------------

for i in sorted(query_dates):
    
    #print(i)
    
    
    ### get date string
    
    t_1d_str = i_cal.loc[i_cal['DataDate']==i, 'T-1d'].dt.strftime('%Y-%m-%d').iloc[0]
    t_28d_str = (pd.to_datetime(i) - pd.to_timedelta('28 days')).strftime('%Y-%m-%d')
    t_91d_str = (pd.to_datetime(i) - pd.to_timedelta('91 days')).strftime('%Y-%m-%d')
    t_182d_str = (pd.to_datetime(i) - pd.to_timedelta('182 days')).strftime('%Y-%m-%d')
    
    today0400str = i + ' 04:00:00'
    
    ### get ed
    
    i_ed_cal2 = pd.read_sql('''with maxdd as (
                                    select max(datadate) as datadate
                                    from [CNDBPROD].[dbo].[CNINFO_ED_format] 
                                    where datadate <= '{0}')
                               select ticker, last_ed, next_ed, d2nexted as bd2e, next_ped
                               FROM [CNDBPROD].[dbo].[CNINFO_ED_format] 
                               WITH (NOLOCK)
                               where datadate = (select datadate from maxdd) 
                               order by ticker, d2nexted 
                               '''.format(i), conn)
    
    i_ed_cal2 = i_ed_cal2.drop_duplicates(subset = ['ticker'], keep = 'first')
    i_ed_cal2['next_ed'] = pd.to_datetime(i_ed_cal2['next_ed'])
    try:
        i_ed_cal2['q_n1q'] = i_ed_cal2['next_ped'].dt.year*10 + i_ed_cal2['next_ped'].dt.quarter
    except AttributeError:
        i_ed_cal2['q_n1q'] = np.nan
    i_ed_cal2['tdy'] = today
    
    
    ### get IPO dates
        
    i_ipo = pd.read_sql('''select s_info_windcode as ticker, S_INFO_LISTDATE as ipo
_date
                        from wind_prod.dbo.AshareDescription
                        WITH (NOLOCK)
                        where (s_info_windcode like '%SH') or (s_info_windcode like '%SZ')  
                        ''', conn_wind)
                        
    i_ipo['ipo_date'] = pd.to_datetime(i_ipo['ipo_date'], format='%Y%m%d')
    i_ipo = i_ipo[i_ipo['ticker'].str[0].isin(['0','3','6'])]
    i_ipo['ticker'] = i_ipo['ticker'].str[:6]    
    i_ipo = i_ipo[(today - i_ipo['ipo_date']).dt.days > 365]
    
    
    ### get abnormal trades
        
    i_ab = pd.read_sql('''select s_info_windcode as ticker, end_dt as datadate 
                       from wind_prod.dbo.AShareStrangeTradedetail 
                       WITH (NOLOCK)
                       where end_dt >= '{0}' and end_dt <= '{1}'  
                       '''.format(t_91d_str, t_1d_str), conn_wind )
    i_ab['datadate'] = pd.to_datetime(i_ab['datadate'], format='%Y%m%d')
    i_ab['ticker'] = i_ab['ticker'].str[:6]
    
    i_ab = i_ab.groupby('ticker')['datadate'].count().reset_index()
    i_ab.columns = ['ticker', 'abnml_cnt_t1q']
    i_ab = i_ab[i_ab['abnml_cnt_t1q']>=5]
    
    
    ### get sellside consensus for np
        
    # per data dict, unit of con_np is 10k RMB, same as the fin_performance_express table
    i_con = pd.read_sql('''select stock_code as ticker, create_date, entrytime, 
                       report_year * 10 + report_quarter as report_period,
                       forecast_np as con_np,
                       report_type, organ_id, author_name 
                       from suntime_prod.dbo.rpt_forecast_stk 
                       with (nolock)
                       where entrytime<='{0}' and create_date>='{1}' 
                       and report_type != 21
                       order by create_date, entrytime
                       '''.format(t_1d_str, t_182d_str), conn)
    
    i_con = i_con[i_con['con_np'].notnull()]
    i_con = i_con.drop_duplicates(subset = ['ticker','report_period','organ_id','author_name'], keep = 'last')
    
    
    s_con = i_con.groupby(['ticker','report_period'])['con_np'].agg(['count', 'mean', 'median', 'std'])
    s_con.columns = ['np_num_t6m','np_mean_t6m','np_median_t6m','np_std_t6m']
    s_con = s_con.reset_index()
    



    
    ### get earning express
    
    
    if t_1d_str > '20190601':
        i_xpress_st = pd.read_sql('''select stock_code as ticker, 
                                 report_year*10+report_period as repo
rt_period, 
                                 np
                                 from suntime_prod.dbo.fin_performance_express
                                 where entrytime <= '{0}' and declare_date >= '{1}'
                                 order by declare_date, entrytime
                                 '''.format(today0400str, t_182d_str), conn )
    if t_1d_str <= '20190601':
        i_xpress_st = pd.read_sql('''select stock_code as ticker, 
                                 report_year*10+report_period as report_period, 
                                 np
                                 from suntime_prod.dbo.fin_performance_express
                                 where declare_date <= '{0}' and declare_date >= '{1}'
                                 order by declare_date, entrytime
                                 '''.format(t_1d_str, t_182d_str), conn )
        
    i_xpress_st = i_xpress_st.drop_duplicates(subset=['ticker','report_period'],keep = 'last')
    
        
    
    
    # select xpress for n1q 
    
    i_xpress_st = i_xpress_st.merge(i_ed_cal2[['ticker', 'q_n1q']], on = 'ticker', how = 'left')
    i_xpress_st = i_xpress_st[i_xpress_st['report_period']==i_xpress_st['q_n1q']]
    
    # merge con_np 
    
    i_xpress_st = i_xpress_st.merge(s_con, on = ['ticker', 'report_period'], how = 'inner')
    
    
    
    # select good forecasts
    
    c1 = i_xpress_st['np_num_t6m']>=3
    i_xpress_st.loc[c1, 'np_z'] = (i_xpress_st.loc[c1,'np']-i_xpress_st.loc[c1,'np_median_t6m']).divide(i_xpress_st.loc[c1,'np_std_t6m'])
    i_xpress_st['np_z'] = i_xpress_st['np_z'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
    i_xpress_st = i_xpress_st[i_xpress_st['np_z']>0]
    

    ### merge datasets
    
    tk_good_forecast = i_xpress_st['ticker'].tolist() 
    tk_lt10d = i_ed_cal2[i_ed_cal2['bd2e'].between(1,11)]['ticker'].tolist()
    tk_not_recent_ipo = i_ipo['ticker'].tolist()
    tk_abnormal = i_ab['ticker'].tolist()
    
    tk_output = set(tk_good_forecast).intersection(set(tk_lt10d)).intersection(set(tk_not_recent_ipo)).difference(set(tk_abnormal))
            
    tcom_output = pd.DataFrame({'Ticker': list(tk_output), 'earn_exp_sgnl': 1})
    tcom_output['T-1d'] = pd.to_datetime(t_1d_str)
    
    
    
                    
    # combine
                       
    icom = tcom_output.merge(i_cal, on = 'T-1d', how = 'left')    
    icom = icom.assign(descriptor = icom['earn_exp_sgnl'])
    icom = icom.dropna(subset = ['descriptor', 'DataD
ate', 'Ticker'])
        
    
    icom[['DataDate', 'Ticker', 'descriptor']].to_sql('F008_ERNEXP_FORMAT',if_exists='append',index=False,con=conn)
    #print(icom.shape)
    #print(icom['DataDate'].unique())



