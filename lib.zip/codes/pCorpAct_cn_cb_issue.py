﻿#$%^&* pCorpAct_cn_cb_issue.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 19 06:28:44 2021

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu





### sd


i_sd = pw.get_ashare_t2000_sd()







### cb

i_cb = yu.get_sql('''select a.s_info_windcode, a.ann_dt, 
                  a.cb_info_preplandate as preplan_dt, 
                  a.s_info_compcode,
                  a.cb_list_passdate as fashengwei_ann,
                  a.cb_list_permitdate as zjh_ann,
                  a.cb_list_rationchkindate as record_dt,
                  b.s_info_windcode as ticker 
 from wind.dbo.CCBondIssuance a
 left join (select * from wind.dbo.WindCustomCode where S_INFO_SECURITIESTYPES='A') b
 on a.s_info_compcode = b.s_info_compcode
''')

i_cb = i_cb[i_cb['ticker'].notnull()]
i_cb['datadate'] = pd.to_datetime(i_cb['ann_dt'], format='%Y%m%d')
i_cb['preplan_dt'] = pd.to_datetime(i_cb['preplan_dt'].fillna('NaN'), format='%Y%m%d')
i_cb['record_dt'] = pd.to_datetime(i_cb['record_dt'].fillna('NaN'), format='%Y%m%d')
i_cb['zjh_ann'] = pd.to_datetime(i_cb['zjh_ann'].fillna('NaN'), format='%Y%m%d')
i_cb['fashengwei_ann'] = pd.to_datetime(i_cb['fashengwei_ann'].fillna('NaN'), format='%Y%m%d')


i_cb['issue_flag'] = 1





### after preplan date
# not much alpha

icom = i_sd.merge(i_cb[['ticker', 'preplan_dt']], left_on = ['ticker', 'datadate'],
                  right_on = ['ticker', 'preplan_dt'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['flg_preplan'] = np.nan
icom.loc[icom['preplan_dt'].notnull(), 'flg_preplan'] = 1
icom['sgnl_preplan'] = icom.groupby('ticker')['flg_preplan'].ffill(limit=3)

yu.create_cn_decay(icom, 'flg_preplan')

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['sgnl_preplan','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_preplan','BarrRet_CLIP_USD+1d', static_data = i_sd)






### after issue
# after issuance, we need to short the stocks 
# sharpe ~0.8

icom = i_sd.merge(i_cb, on = ['ticker','datadate'], how='left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['issue_sgnl'] = icom.groupby('ticker')['issue_flag'].ffill(limit=200)
icom['issue_sgnl'] = - icom['issue_sgnl']

yu.create_cn_decay(icom, 'issue_flag')
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['issue_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
 
           'issue_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.85/0.67


### before issue
# we need to long well before cb issuance 

icom = i_sd.merge(i_cb, on = ['ticker','datadate'], how='left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['issue_bfr_sgnl'] = icom.groupby('ticker')['issue_flag'].bfill(limit=40)

#yu.create_cn_decay(icom, 'issue_flag')
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['issue_bfr_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'issue_bfr_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #






### fasheng wei pass date
# not much alpha, sharpe <1

icom = i_sd.merge(i_cb[['ticker', 'fashengwei_ann']], left_on = ['ticker', 'datadate'],
                  right_on = ['ticker', 'fashengwei_ann'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['flg_fashengwei'] = np.nan
icom.loc[icom['fashengwei_ann'].notnull(), 'flg_fashengwei'] = 1
icom['sgnl_fashengwei'] = icom.groupby('ticker')['flg_fashengwei'].ffill(limit=3)

yu.create_cn_decay(icom, 'flg_fashengwei')

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['sgnl_fashengwei','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_fashengwei','BarrRet_CLIP_USD+1d', static_data = i_sd)



### zjh pass date
# no alpha


icom = i_sd.merge(i_cb[['ticker', 'zjh_ann']], left_on = ['ticker', 'datadate'],
                  right_on = ['ticker', 'zjh_ann'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['flg_zjh'] = np.nan
icom.loc[icom['zjh_ann'].notnull(), 'flg_zjh'] = 1
icom['sgnl_zjh'] = icom.groupby('ticker')['flg_zjh'].ffill(limit=3)

yu.create_cn_decay(icom, 'flg_zjh')

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['sgnl_zjh','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_zjh','BarrRet_CLIP_USD+1d', static_data = i_sd)



### existing shareholder record date
# sharpe ~ 1

icom = i_sd.merge(i_cb[['ticker', 'record_dt','preplan_dt', 'fashengwei_ann']], 
                  on = 'ticker', how = 'left')

icom['flg_within2w_record'] = np.nan
c1 = (icom['record_dt'] - icom['datadate']).dt.days.between(1, 10)
icom.loc[c1, 'flg_within2w_record'] = 1


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['flg_within2w_record','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=[
'ticker','datadate']),
            'flg_within2w_record','BarrRet_CLIP_USD+1d', static_data = i_sd) #



icom['flg_preplan_record'] = np.nan
c1 = (icom['record_dt'] - icom['datadate']).dt.days >= 2
c2 = icom['datadate'] > icom['preplan_dt']
c3 = (icom['record_dt'] - icom['datadate']).dt.days <= 20
icom.loc[c1 & c2 & c3, 'flg_preplan_record'] = 1

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2019-06-01', '2021-12-31')].\
            dropna(subset=['flg_preplan_record','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_preplan_record','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.42 / 1.11



###??? need to study the losers here ... am I trading them strictly following the strategy?

t1 = o_1.groupby('ticker')['pnl_ac'].sum().sort_values()

002460
603486
300568
002916




icom['flg_fashengwei_record'] = np.nan
c1 = (icom['record_dt'] - icom['datadate']).dt.days >= 2
c2 = icom['datadate'] > icom['fashengwei_ann']
c3 = (icom['record_dt'] - icom['datadate']).dt.days <= 20
icom.loc[c1 & c2 & c3, 'flg_fashengwei_record'] = 1

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2019-06-01', '2021-12-31')].\
            dropna(subset=['flg_fashengwei_record','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_fashengwei_record','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.44 / 1.1

