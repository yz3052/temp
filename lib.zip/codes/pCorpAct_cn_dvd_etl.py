﻿#$%^&* pCorpAct_cn_dvd_etl.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri May 13 11:01:20 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import os
import gzip
import datetime
import zipfile



std_cols = ['ticker', 'ID_BB_COMPANY', 'ID_BB_SECURITY', 'RCODE', 'ACTION_ID', 
            'CAX_Mnemonic', 'Flag', 'CompanyName', 'SecIDType', 'SecID', 'Currency', 
            'MarketSectorDesc', 'BBG_unique_id','ann_dt','eff_dt','amd_dt',
            'BBG_global_id', 'BBG_global_company_id', 'BBG_sec_id_desc', 
            'feed_source', 'nfields']


### get bbgbo DVD v2 (2019 onwards)

fs_v2 = []
for yr in [i for i in os.listdir(r'Z:\BloombergBackOffice\CorpActionsV2\Asia') if len(i)==4]:
    dir_yr = os.path.join(r'Z:\BloombergBackOffice\CorpActionsV2\Asia', yr)
    for r,p,fs in os.walk(dir_yr):
        for f in fs:
            if ('equityAsia2CorporateActionsV2.cax.' in f ) and f.endswith('.gz'):
                fs_v2.append([r, f, os.path.join(r, f), 'afterMkt', os.path.getmtime(os.path.join(r, f))])
            if ('premarketEquityAsia2CorporateActionsV2.cax.' in f ) and f.endswith('.gz'):
                fs_v2.append([r, f, os.path.join(r, f), 'preMkt', os.path.getmtime(os.path.join(r, f))])
fs_v2 = pd.DataFrame(fs_v2, columns = ['r', 'f', 'p', 'type', 'mtime_est'])
fs_v2['date'] = fs_v2['p'].str.extract('(\d{8})')
fs_v2['date'] = pd.to_datetime(fs_v2['date'], format = '%Y%m%d')
fs_v2['mtime_est'] = pd.to_datetime(fs_v2['mtime_est'], unit='s')
fs_v2['mtime_cn'] = fs_v2['mtime_est'].dt.tz_localize('US/Eastern').dt.tz_convert('Asia/Shanghai').dt.tz_localize(None)

i_cash_v2 = []
i_stock_v2 = []
i_split_v2 = []
for i, r in fs_v2.iterrows():
    print('.', end='')
    t_data = gzip.open(r['p'],"r").read().decode('utf8')
    t_data = t_data.split('\n')
    t_data = t_data[ t_data.index('START-OF-DATA')+1 : t_data.index('END-OF-DATA') ]
    t_data = [l for l in t_data if not ((l.split('|')[-2]=='300')&(l.count('|')==4)) ]
    t_data = [l for l in t_data if 'CH Equity' in l.split('|')[0]]
    for l in t_data:
        l_list = l.split('|')[:-1]
        l_dict = {i2: i1 for i1, i2 in zip(l_list[:21], std_cols)}
        l_dict['datadate'] = pd.to_datetime(r['f'][-11:-3], format='%Y%m%d')
        l_dict['mtime_cn'] = r['mtime_cn']
        l_list_others = l_list[21:]
        if len(l_list_others)%2!=0:
            raise Exception()
        l_others_dict = {l_list_others[n*2]:l_list_others[n*2+1]
 for n in range(len(l_list_others)//2)}
        l_dict.update(l_others_dict)
        if l_dict['CAX_Mnemonic']=='DVD_CASH':
            i_cash_v2.append(l_dict)
        elif l_dict['CAX_Mnemonic']=='DVD_STOCK':
            i_stock_v2.append(l_dict)
        elif l_dict['CAX_Mnemonic']=='STOCK_SPLIT':
            i_split_v2.append(l_dict)
        
i_cash_v2 = pd.DataFrame(i_cash_v2)
i_cash_v2 = i_cash_v2[['ticker','datadate','mtime_cn','ACTION_ID',
                       'CP_ADJ', 'CP_ADJ_DT','CP_GROSS_AMT',
                       'CP_PAY_DT','CP_RECORD_DT','Flag',
                       'amd_dt', 'ann_dt', 'eff_dt']]
i_cash_v2['ticker'] = i_cash_v2['ticker'].str.split(' ').str[0]

i_stock_v2 = pd.DataFrame(i_stock_v2)
i_stock_v2 = i_stock_v2[['ticker','datadate','mtime_cn','ACTION_ID',
                         'CP_ADJ', 'CP_ADJ_DT', 'CP_AMT', 'CP_DIST_AMT_STATUS',
                         'CP_DVD_STOCK_TYP', 
                         'CP_INDICATOR', 'CP_PAY_DT', 'CP_RECORD_DT', 
                         'Flag', 'amd_dt', 'ann_dt', 'eff_dt']]
i_stock_v2['ticker'] = i_stock_v2['ticker'].str.split(' ').str[0]




###  get bbgbo equity DVD thru 2019.08.12


fs_v1 = []
for yr in ['2013','2014','2015','2016','2017','2018','2019']:
    dir_yr = os.path.join(r'Z:\BloombergBackOffice\Equity\Asia', yr)
    for r,p,fs in os.walk(dir_yr):
        for f in fs:
            if ('equity_asia2.cax.' in f ) and f.endswith('.gz'):
                fs_v1.append([r, f, os.path.join(r, f), 'v1'])
fs_v1 = pd.DataFrame(fs_v1, columns = ['r', 'f', 'p', 'type'])
fs_v1['date'] = fs_v1['p'].str.extract('(\d{8})')
fs_v1['date'] = pd.to_datetime(fs_v1['date'], format = '%Y%m%d')
fs_v1 = fs_v1[fs_v1['date']<='2019-08-12']


i_cash_v1 = []
i_stock_v1 = []
i_split_v1 = []
for i, r in fs_v1.iterrows():
    print('.', end='')
    t_data = gzip.open(r['p'],"r").read().decode('utf8')
    t_data = t_data.split('\n')
    t_data = t_data[ t_data.index('START-OF-DATA')+1 : t_data.index('END-OF-DATA') ]
    t_data = [l for l in t_data if not ((l.split('|')[-2]=='300')&(l.count('|')==4)) ]
    t_data = [l for l in t_data if 'CH Equity' in l.split('|')[0]]
    for l in t_data:
        l_list = l.split('|')[:-1]
        l_dict = {i2: i1 for i1, i2 in zip(l_list[:21], std_cols)}
        l_dict['datadate'] = pd.to_datetime(r['f'][-11:-3], format='%Y%m%d')
        l_list_others = l_list[21:]
        if len(l_list_others)%2!=0:
            raise Exception()
        l_others_dict = {l_list_others[n*2]:l_lis
t_others[n*2+1] for n in range(len(l_list_others)//2)}
        l_dict.update(l_others_dict)
        if l_dict['CAX_Mnemonic']=='DVD_CASH':
            i_cash_v1.append(l_dict)
        elif l_dict['CAX_Mnemonic']=='DVD_STOCK':
            i_stock_v1.append(l_dict)
        elif l_dict['CAX_Mnemonic']=='STOCK_SPLIT':
            i_split_v1.append(l_dict)
    

i_cash_v1 = pd.DataFrame(i_cash_v1)
i_cash_v1 = i_cash_v1[['ticker','datadate','ACTION_ID',
                       'CP_ADJ', 'CP_ADJ_DT','CP_GROSS_AMT',
                       'CP_PAY_DT','CP_RECORD_DT','Flag',
                       'amd_dt', 'ann_dt', 'eff_dt']]
i_cash_v1['ticker'] = i_cash_v1['ticker'].str.split(' ').str[0]

i_stock_v1 = pd.DataFrame(i_stock_v1)
i_stock_v1 = i_stock_v1[['ticker','datadate','ACTION_ID',
                         'CP_ADJ', 'CP_ADJ_DT', 'CP_AMT', 'CP_DIST_AMT_STATUS',
                         'CP_DVD_STOCK_TYP', 
                         'CP_INDICATOR', 'CP_PAY_DT', 'CP_RECORD_DT', 
                         'Flag', 'amd_dt', 'ann_dt', 'eff_dt']]
i_stock_v1['ticker'] = i_stock_v1['ticker'].str.split(' ').str[0]




### get bbgbo Shareholder Meeting v2 

fs_v2 = []
for yr in [i for i in os.listdir(r'Z:\BloombergBackOffice\CorpActionsV2\Asia') if len(i)==4]:
    dir_yr = os.path.join(r'Z:\BloombergBackOffice\CorpActionsV2\Asia', yr)
    for r,p,fs in os.walk(dir_yr):
        for f in fs:
            if ('equityAsia2CorporateActionsV2.cax.' in f ) and f.endswith('.gz'):
                fs_v2.append([r, f, os.path.join(r, f), 'afterMkt', os.path.getmtime(os.path.join(r, f))])
            if ('premarketEquityAsia2CorporateActionsV2.cax.' in f ) and f.endswith('.gz'):
                fs_v2.append([r, f, os.path.join(r, f), 'preMkt', os.path.getmtime(os.path.join(r, f))])
fs_v2 = pd.DataFrame(fs_v2, columns = ['r', 'f', 'p', 'type', 'mtime_est'])
fs_v2['date'] = fs_v2['p'].str.extract('(\d{8})')
fs_v2['date'] = pd.to_datetime(fs_v2['date'], format = '%Y%m%d')
fs_v2['mtime_est'] = pd.to_datetime(fs_v2['mtime_est'], unit='s')
fs_v2['mtime_cn'] = fs_v2['mtime_est'].dt.tz_localize('US/Eastern').dt.tz_convert('Asia/Shanghai').dt.tz_localize(None)

i_meet_v2 = []
for i, r in fs_v2.iterrows():
    print('.', end='')
    t_data = gzip.open(r['p'],"r").read().decode('utf8')
    t_data = t_data.split('\n')
    t_data = t_data[ t_data.index('START-OF-DATA')+1 : t_data.index('END-OF-DATA') ]
    t_data = [l for l in t_data if not ((l.split('|')[-2]=='300')&(l.count('|')==4)) ]
    t_data = 
[l for l in t_data if 'CH Equity' in l.split('|')[0]]
    for l in t_data:
        l_list = l.split('|')[:-1]
        l_dict = {i2: i1 for i1, i2 in zip(l_list[:21], std_cols)}
        l_dict['datadate'] = pd.to_datetime(r['f'][-11:-3], format='%Y%m%d')
        l_dict['mtime_cn'] = r['mtime_cn']
        l_list_others = l_list[21:]
        if len(l_list_others)%2!=0:
            raise Exception()
        l_others_dict = {l_list_others[n*2]:l_list_others[n*2+1] for n in range(len(l_list_others)//2)}
        l_dict.update(l_others_dict)
        if l_dict['CAX_Mnemonic']=='SH_HOLDER_MEET':
            i_meet_v2.append(l_dict)
i_meet_v2 = pd.DataFrame(i_meet_v2)
i_meet_v2 = i_meet_v2[['ticker','datadate', 'mtime_cn', 'CP_RECORD_DT', 'CP_MEET_TYP',
                       'amd_dt', 'ann_dt', 'eff_dt']]
i_meet_v2['ticker'] = i_meet_v2['ticker'].str.split(' ').str[0]






###  get bbgbo equity DVD thru 2019.08.12


fs_v1 = []
for yr in ['2013','2014','2015','2016','2017','2018','2019']:
    dir_yr = os.path.join(r'Z:\BloombergBackOffice\Equity\Asia', yr)
    for r,p,fs in os.walk(dir_yr):
        for f in fs:
            if ('equity_asia2.cax.' in f ) and f.endswith('.gz'):
                fs_v1.append([r, f, os.path.join(r, f), 'v1'])
fs_v1 = pd.DataFrame(fs_v1, columns = ['r', 'f', 'p', 'type'])
fs_v1['date'] = fs_v1['p'].str.extract('(\d{8})')
fs_v1['date'] = pd.to_datetime(fs_v1['date'], format = '%Y%m%d')
fs_v1 = fs_v1[fs_v1['date']<='2019-08-12']


i_meet_v1 = []
for i, r in fs_v1.iterrows():
    print('.', end='')
    t_data = gzip.open(r['p'],"r").read().decode('utf8')
    t_data = t_data.split('\n')
    t_data = t_data[ t_data.index('START-OF-DATA')+1 : t_data.index('END-OF-DATA') ]
    t_data = [l for l in t_data if not ((l.split('|')[-2]=='300')&(l.count('|')==4)) ]
    t_data = [l for l in t_data if 'CH Equity' in l.split('|')[0]]
    for l in t_data:
        l_list = l.split('|')[:-1]
        l_dict = {i2: i1 for i1, i2 in zip(l_list[:21], std_cols)}
        l_dict['datadate'] = pd.to_datetime(r['f'][-11:-3], format='%Y%m%d')
        l_list_others = l_list[21:]
        if len(l_list_others)%2!=0:
            raise Exception()
        l_others_dict = {l_list_others[n*2]:l_list_others[n*2+1] for n in range(len(l_list_others)//2)}
        l_dict.update(l_others_dict)
        if l_dict['CAX_Mnemonic']=='SH_HOLDER_MEET':
            i_meet_v1.append(l_dict)
        
i_meet_v1 = pd.DataFrame(i_meet_v1)
i_meet_v1 = i_meet_v1[['ticker','datadate', 'CP_RECORD_
DT', 'CP_MEET_TYP',
                       'amd_dt', 'ann_dt', 'eff_dt']]
i_meet_v1['ticker'] = i_meet_v1['ticker'].str.split(' ').str[0]




### output of bbgbo dvd

i_cash_v1.to_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_cash_v1.parquet')
i_cash_v2.to_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_cash_v2.parquet')
i_stock_v1.to_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_stock_v1.parquet')
i_stock_v2.to_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_stock_v2.parquet')

i_meet_v1.to_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_meet_v1.parquet')
i_meet_v2.to_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_meet_v2.parquet')




#-----

#-----
### get markit dvd forecast (OLD format thru 2021.04)

import io


# part 1

market_dvd_frcst_pre20190427 = []

for yr in [2016, 2017, 2018, 2019]:
    for r,p,fs in os.walk(os.path.join(r'Z:\Markit\DividendForecast', str(yr))):
        for f in fs:
            if ('_APAC_' in f) and f.endswith('.zip'):
                
                dt = r.split('\\')[-3]+'-'+r.split('\\')[-2]+'-'+r.split('\\')[-1]
                if dt >= '2019-04-27':
                    continue
                
                t_name = [i for i in zipfile.ZipFile(os.path.join(r,f), 'r').namelist() if 'MRKT_Div_StockLevel_APAC' in i][0]
                t_data = zipfile.ZipFile(os.path.join(r,f), 'r').read(t_name)
                
                t_df = pd.read_csv(io.StringIO(t_data.decode('utf8')), sep = '\t')
                t_df = t_df[t_df['ExchangeCode'].isin(['XSHG', 'XSHE'])]
                
                c_sh = t_df['ExchangeCode']=='XSHG'
                t_df.loc[c_sh,'ticker'] = t_df.loc[c_sh,'Ticker'] + '.SH'
                c_sz = t_df['ExchangeCode']=='XSHE'
                t_df.loc[c_sz,'ticker'] = t_df.loc[c_sz,'Ticker'] + '.SZ'
                t_df = t_df[t_df['ticker'].str[0].isin(['0','3','6'])]
                
                t_df = t_df.rename(columns = {'DataDate': 'datadate'})
                t_df = t_df.drop(columns = ['MarkitAssetID', 'ISIN', 'ExchangeCode',
                                            'SEDOL', 'Ticker', 'AssetName'])
                t_df['r'] = r
                t_df['f'] = f
                market_dvd_frcst_pre20190427.append(t_df)
                print('.', end='')
                
market_dvd_frcst_pre20190427 = pd.concat(market_dvd_frcst_pre20190427, axis = 0)                
market_dvd_frcst_pre20190427.to_parque
t(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_markit_dvd_frcst_pre20190427.parquet')


# part 2

market_dvd_frcst_20190427_20210430 = []

for yr in [2019, 2020, 2021]:
    for r,p,fs in os.walk(os.path.join(r'Z:\Markit\DividendForecast', str(yr))):
        for f in fs:
            if ('_APAC_' in f) and f.endswith('.zip'):
                
                dt = r.split('\\')[-3]+'-'+r.split('\\')[-2]+'-'+r.split('\\')[-1]
                if dt in ['2019-04-27','2019-04-28']:
                    continue
                if dt < '2019-04-27':
                    continue
                
                t_name = [i for i in zipfile.ZipFile(os.path.join(r,f), 'r').namelist() if 'MRKT_Div_StockLevel_APAC' in i][0]
                t_data = zipfile.ZipFile(os.path.join(r,f), 'r').read(t_name)
                
                t_df = pd.read_csv(io.StringIO(t_data.decode('utf8')), sep = '\t')
                t_df = t_df[t_df['ExchangeCode'].isin(['XSHG', 'XSHE'])]
                
                c_sh = t_df['ExchangeCode']=='XSHG'
                t_df.loc[c_sh,'ticker'] = t_df.loc[c_sh,'Ticker'] + '.SH'
                c_sz = t_df['ExchangeCode']=='XSHE'
                t_df.loc[c_sz,'ticker'] = t_df.loc[c_sz,'Ticker'] + '.SZ'
                t_df = t_df[t_df['ticker'].str[0].isin(['0','3','6'])]
                
                t_df = t_df.rename(columns = {'DataDate': 'datadate'})
                t_df = t_df.drop(columns = ['MarkitAssetID', 'ISIN', 'ExchangeCode',
                                            'SEDOL', 'Ticker', 'AssetName'])
                t_df['r'] = r
                t_df['f'] = f
                market_dvd_frcst_20190427_20210430.append(t_df)
                print('.', end='')

market_dvd_frcst_20190427_20210430 = pd.concat(market_dvd_frcst_20190427_20210430, axis = 0)                
market_dvd_frcst_20190427_20210430.to_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_market_dvd_frcst_20190427_20210430.parquet')

# part 3





### get bbg dvd forecast (OLD format thru 2021.04)

bbg_files = []
for yr in [2019, 2020, 2021]:
    for r,p,fs in os.walk(os.path.join(r'Z:\BloombergBackOffice\DividendForecast-BDVD\Asia',str(yr))):
        for f in fs:
            if 'equity_bdvd_asia2.out.' in f and f.endswith('gz'):
                bbg_files.append([r,f,r.split('\\')[-3]+'-'+r.split('\\')[-2]+'-'+r.split('\\')[-1]])
bbg_files = pd.DataFrame(bbg_files, columns = ['r','f','datadate'])
bbg_files['datadate'] = pd.to_datetime(bbg_file
s['datadate'])
bbg_files['p'] = bbg_files.apply(lambda x: os.path.join(x['r'],x['f']), axis = 1)


bbg_frcst = []
for i, r in bbg_files.iterrows():
    t_data = gzip.open(r['p'],"r").read().decode('utf8')
    t_data = t_data.split('\n')
    t_cols =  t_data[ t_data.index('START-OF-FIELDS')+1 : t_data.index('END-OF-FIELDS') ]
    t_data = t_data[ t_data.index('START-OF-DATA')+1 : t_data.index('END-OF-DATA') ]
    t_data = [l for l in t_data if 'CH Equity' in l.split('|')[0]]    
    for l in t_data:
        l_list = l.split('|')[3:-1]
        l_dict = {i2: i1 for i1, i2 in zip(l_list, t_cols)}
        l_dict['datadate'] = r['datadate']
        bbg_frcst.append(l_dict)
bbg_frcst = pd.DataFrame(bbg_frcst)
bbg_frcst.to_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_bbg_dvd_frcst.parquet')



### get woodseer api


