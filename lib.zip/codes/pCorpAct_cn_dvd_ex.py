﻿#$%^&* pCorpAct_cn_dvd_ex.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon May 23 14:19:17 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime




### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])


### get close price

i_c = yu.get_sql('''select s_info_windcode as ticker, s_dq_preclose as prec, trade_dt as datadate
                 from wind_prod.dbo.ashareeodprices where trade_dt >= '20160101'  ''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'],  format = '%Y%m%d')
i_c = i_c.sort_values('datadate')


### dividend

i_xd = yu.get_sql("select * from wind.dbo.AShareEXRightDividendRecord")
i_xd['EX_DATE'] = pd.to_datetime(i_xd['EX_DATE'], format='%Y%m%d')
i_xd = i_xd[i_xd['EX_DATE']>='2016-06-01']
i_xd = i_xd.rename(columns={'S_INFO_WINDCODE':'ticker', 'EX_DATE':'datadate'})
i_xd['flg_ex'] = 1
i_xd['flg_ex_1w'] = 1
i_xd['flg_ex_2w'] = 1
i_xd['flg_ex_4w'] = 1
i_xd['flg_ex_13w'] = 1
i_xd = i_xd.sort_values('datadate')

i_xd = pd.merge_asof(i_xd, i_c, by='ticker', on ='datadate')
i_xd['cash_dvd_ret'] = i_xd['CASH_DIVIDEND_RATIO'].divide(i_xd['prec'])
i_xd['shr_dvd_ratio'] = i_xd['BONUS_SHARE_RATIO']+i_xd['CONVERSED_RATIO']


### combine - 1W
cols = ['cash_dvd_ret','shr_dvd_ratio']
icom_1w = pd.merge_asof(i_sd, i_xd[['ticker','datadate','flg_ex']+cols], by='ticker', on='datadate', tolerance=pd.to_timedelta('7 days'))
o_1 = yu.bt_cn_15(icom_1w[(icom_1w['datadate']<='2021-12-31') ].\
            dropna(subset=['flg_ex','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_ex','BarrRet_CLIP_USD+1d', static_data = i_sd) # -0.16 / -2.09
t1 = yu.explore(icom_1w, 'flg_ex')


### combine - 4W
cols = ['cash_dvd_ret','shr_dvd_ratio']
icom_4w = pd.merge_asof(i_sd, i_xd[['ticker','datadate','flg_ex']+cols], by='ticker', on='datadate', tolerance=pd.to_timedelta('28 days'))
o_1 = yu.bt_cn_15(icom_4w[(icom_4w['datadate']<='2021-12-31') ].\
            dropna(subset=['flg_ex','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_ex','BarrRet_CLIP_USD+1d', static_data = i_sd) # -0.16 / -2.09
t1 = yu.explore(icom_4w, 'flg_ex')


### combine - 13W
cols = ['cash_dvd_ret','shr_dvd_ratio']
icom_13w = pd.merge_asof(i_sd, i_xd[['ticker','datadate','flg_ex']+cols], by='ticker', on='datadate', tolerance=pd.to_timedelta('91 days'))
o_1 = yu.bt_cn_15(icom_13w[(icom_13w['datadate']<='2021-12-31') ].\

            dropna(subset=['flg_ex','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_ex','BarrRet_CLIP_USD+1d', static_data = i_sd) # -0.16 / -2.09
t1 = yu.explore(icom_13w, 'flg_ex')


### combine - 13W, shr only
cols = ['cash_dvd_ret','shr_dvd_ratio']
icom_13w = pd.merge_asof(i_sd, i_xd[['ticker','datadate','flg_ex']+cols], by='ticker', on='datadate', tolerance=pd.to_timedelta('91 days'))
icom_13w = icom_13w[icom_13w['shr_dvd_ratio']>0]
o_1 = yu.bt_cn_15(icom_13w[(icom_13w['datadate']<='2021-12-31') ].\
            dropna(subset=['flg_ex','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_ex','BarrRet_CLIP_USD+1d', static_data = i_sd) # -0.16 / -2.09
t1 = yu.explore(icom_13w, 'flg_ex_2w')


