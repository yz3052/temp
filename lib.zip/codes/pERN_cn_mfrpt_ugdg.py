﻿#$%^&* pERN_cn_mfrpt_ugdg.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 12 07:55:43 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime


### sd 

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])


### sd stable shortable 

i_sd_ss = pw.get_china_ss_sd()


### mfrpt

i_mfrpt = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWNID_util_prepare_wind_mfrpt_calendar.parquet')


### mf holding


i_maturity = yu.get_sql('''select a.f_info_windcode as ticker_fund, a.f_info_name, a.f_info_setupdate, 
                     a.f_info_maturitydate, b.s_info_compcode  
                     from wind.dbo.ChinaMutualFundDescription a 
                     left join wind.dbo.WINDCUSTOMCODE b 
                     on a.f_info_windcode = b.S_INFO_WINDCODE''')
i_maturity['f_info_maturitydate'] = i_maturity['f_info_maturitydate'].fillna('20501231')
i_maturity = i_maturity.groupby('s_info_compcode')['f_info_maturitydate'].max().reset_index()
i_maturity['f_info_maturitydate'] = pd.to_datetime(i_maturity['f_info_maturitydate'], format='%Y%m%d')
    


i_fund_type = yu.get_sql('''select distinct a.f_info_setupdate as start_date, a.f_info_maturitydate as end_date, 
                          a.f_info_firstinvesttype as style, b.s_info_compcode
                         from wind.dbo.ChinaMutualFundDescription a 
                         left join wind.dbo.WINDCUSTOMCODE b 
                         on a.f_info_windcode = b.S_INFO_WINDCODE''')
i_fund_type['start_date'] = i_fund_type['start_date'].fillna('19900101')
i_fund_type['start_date'] = pd.to_datetime(i_fund_type['start_date'], format='%Y%m%d')
i_fund_type['end_date'] = i_fund_type['end_date'].fillna('20500101')
i_fund_type['end_date'] = pd.to_datetime(i_fund_type['end_date'], format='%Y%m%d')
i_fund_type.loc[i_fund_type['style'].isin(['股票型','混合型','另类投资型']), 'flag_isactive'] = 1


i_h = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_wind_holding_mf_q_est.parquet')



### mf asset

i_asset = yu.get_sql('''select b.s_info_compcode, F_ANN_DATE as datadate,
                     F_PRT_STOCKVALUE
                     from wind_prod.dbo.ChinaMutualFundAssetPortfolio a 
                     left join wind.dbo.WINDCUSTOMCODE b 
                     on a.s_info_windcode = b.S_INFO_WINDCODE''')
i_asset = i_asset.sort_values(['s_info_compcode', 'datadate'])
i_asset = i_asset.reset_index(drop = True)

i_asset['data
date'] = pd.to_datetime(i_asset['datadate'], format='%Y%m%d')



### ugdg
# report type



i_ugdg = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_st_ugdg_per_report.parquet')

i_ugdg = i_ugdg[~i_ugdg['report_type'].isin([21, 28, 98])]

i_ugdg = i_ugdg.sort_values(['ticker','report_period','organ_id','datadate'])




### loop (t1q ugdg)
# selecting tickers with lower rank in a mutual fund is indeed better


o_mfrpt = []

for dt in pd.date_range(start = '2017-01-01', end = '2021-12-31'):
    print(dt.strftime('%Y%m%d'), end=',')
    
    # get operating funds
    t_operating_compcode = i_maturity.loc[i_maturity['f_info_maturitydate']>=dt,'s_info_compcode'].tolist()
    
    # get active funds
    t_active_compcode = i_fund_type[(i_fund_type['end_date']>=dt)&\
                                    (i_fund_type['start_date']<=dt)&\
                                    (i_fund_type['flag_isactive']==1)]['s_info_compcode'].tolist()
    
    # get mfrpt calendar 
    t_mfrpt = i_mfrpt[i_mfrpt['datadate']==dt]
    t_mfrpt = t_mfrpt[t_mfrpt['s_info_compcode'].isin(t_operating_compcode)]
    t_mfrpt = t_mfrpt[t_mfrpt['s_info_compcode'].isin(t_active_compcode)]
    t_mfrpt = t_mfrpt[(t_mfrpt['bd2n1rpt']<=20) & (t_mfrpt['bd2n1rpt']>=-5)] # 20 / -5
    
    # select recent 180 day holding data
    t_est_holding = i_h[(i_h['datadate'] >= dt-pd.to_timedelta('180 days'))&\
                        (i_h['datadate'] <= dt)&\
                        (i_h['s_info_compcode'].isin(t_mfrpt['s_info_compcode'].tolist()))]
    
    # select the most recent holding of each fund 
    t_est_holding_maxdd = t_est_holding.groupby('s_info_compcode')['datadate'].max().reset_index()
    t_est_holding_maxdd = t_est_holding_maxdd[t_est_holding_maxdd['s_info_compcode'].isin(t_operating_compcode)]    
    t_est_holding_maxdd = t_est_holding_maxdd[t_est_holding_maxdd['s_info_compcode'].isin(t_active_compcode)]    
    t_est_holding = t_est_holding_maxdd.merge(t_est_holding, on = ['datadate', 's_info_compcode'], how = 'inner')
    
    # rank held_dollar and pctOFSO within each fund
    t_est_holding['held_dollar_01rk'] = t_est_holding.groupby('s_info_compcode')['held_dollar'].apply(lambda x: x.rank(ascending=True)/x.count()).values
    t_est_holding['pctOfSO_01rk'] = t_est_holding.groupby('s_info_compcode')['pctOfSO'].apply(lambda x: x.rank(ascending=True)/x.count()).values
    
    # calculate mf crodedness 
    s_est_holding_1 = t_est_holding.groupby('ticker')['s_info_compcod
e'].nunique().reset_index()
    s_est_holding_1 = s_est_holding_1.rename(columns={'s_info_compcode':'inst_cnt'})
    
    s_est_holding_2 = t_est_holding.groupby('ticker')['pctOfMFSTK'].apply(lambda x: sum(np.power(x/x.sum(),2)))
    s_est_holding_2 = s_est_holding_2.reset_index()
    s_est_holding_2 = s_est_holding_2.rename(columns = {'pctOfMFSTK':'concentration'})
    s_est_holding_2 = s_est_holding_2[['ticker', 'concentration']]
    
    # get mf's stock asset    
    t_asset = i_asset[(i_asset['datadate']<=dt)&\
                      (i_asset['s_info_compcode'].isin(t_mfrpt['s_info_compcode'].tolist()))]
    t_asset = t_asset.drop_duplicates(subset = ['s_info_compcode'], keep = 'last')
    t_asset = t_asset[['s_info_compcode', 'F_PRT_STOCKVALUE']]

        
    # get ugdg
    
    t_ugdg = i_ugdg[(i_ugdg['datadate']<=dt)&(i_ugdg['datadate']>=dt-pd.to_timedelta('91 days'))]
    t_ugdg_tk_maxdd = t_ugdg.groupby(['ticker','organ_id'])['create_date'].max().reset_index()
    if len(t_ugdg_tk_maxdd)==0:
        print('_',end=',')
        continue
    t_ugdg_tk_maxdd = t_ugdg_tk_maxdd.merge(t_ugdg,on=['ticker','organ_id','create_date'],how='inner')
    
    t_ugdg_tk_maxdd['flg_or_up'] = np.sign(t_ugdg_tk_maxdd['frcst_or'] - t_ugdg_tk_maxdd['frcst_or_prev'])
    t_ugdg_tk_maxdd['flg_np_up'] = np.sign(t_ugdg_tk_maxdd['frcst_np'] - t_ugdg_tk_maxdd['frcst_np_prev'])
    t_ugdg_tk_maxdd['flg_eps_up'] = np.sign(t_ugdg_tk_maxdd['frcst_eps'] - t_ugdg_tk_maxdd['frcst_eps_prev'])
    t_ugdg_tk_maxdd['flg_gg_up'] = np.sign(t_ugdg_tk_maxdd['ggrate'] - t_ugdg_tk_maxdd['ggrate_prev'])
    t_ugdg_tk_maxdd['sgn_flg_up'] = np.sign(t_ugdg_tk_maxdd[['flg_or_up','flg_np_up','flg_eps_up','flg_gg_up']].sum(axis=1))
    
    s_up_ratio = t_ugdg_tk_maxdd.groupby('ticker')['sgn_flg_up'].apply(lambda x: x.sum()/x.count())
    s_up_ratio = s_up_ratio.reset_index()
    s_up_ratio = s_up_ratio.rename(columns={'sgn_flg_up':'ratio_flg_up_t1q'})
    s_up_ratio = s_up_ratio[['ticker', 'ratio_flg_up_t1q']]
    
    # estimate flow for already-held tickers
    t_est_holding_s2 = t_est_holding.merge(s_up_ratio, on = 'ticker', how = 'left')
    t_est_holding_s2 = t_est_holding_s2.merge(t_asset, on = 's_info_compcode', how = 'left')  
    t_est_holding_s2 = t_est_holding_s2.merge(s_est_holding_1, on = 'ticker', how = 'left')  
    t_est_holding_s2 = t_est_holding_s2.merge(s_est_holding_2, on = 'ticker', how = 'left')  
    t_est_holding_s2['inst_cnt_01rk'] = t_est_holding_s2['inst_cnt'].rank(asc
ending=True)/len(t_est_holding_s2)
    t_est_holding_s2['concentration_01rk'] = t_est_holding_s2['concentration'].rank(ascending=True)/len(t_est_holding_s2)
        
    t_est_holding_s2['flow_est_v1'] = 0.2*t_est_holding_s2['held_dollar'].multiply(t_est_holding_s2['ratio_flg_up_t1q'])
    c1 = (t_est_holding_s2['held_dollar_01rk']<0.5)&(t_est_holding_s2['ratio_flg_up_t1q']>0.3)
    t_est_holding_s2.loc[c1, 'flow_est_v1_lowH_ug'] = t_est_holding_s2.loc[c1, 'flow_est_v1']
    c1 = (t_est_holding_s2['held_dollar_01rk']>0.5)&(t_est_holding_s2['ratio_flg_up_t1q']<-0.3)
    t_est_holding_s2.loc[c1, 'flow_est_v1_highH_dg'] = t_est_holding_s2.loc[c1, 'flow_est_v1']
    c1 = (t_est_holding_s2['pctOfSO_01rk']<0.5)&(t_est_holding_s2['ratio_flg_up_t1q']>0.3)
    t_est_holding_s2.loc[c1, 'flow_est_v1b_lowH_ug'] = t_est_holding_s2.loc[c1, 'flow_est_v1']
    
    c1 = ((t_est_holding_s2['pctOfSO_01rk']>0.5)|(t_est_holding_s2['held_dollar_01rk']>0.5))&(t_est_holding_s2['ratio_flg_up_t1q']>0.3)
    t_est_holding_s2.loc[c1, 'flow_est_v1b_highH_ug'] = t_est_holding_s2.loc[c1, 'flow_est_v1']
    c1 = ((t_est_holding_s2['pctOfSO_01rk']>0.5)&(t_est_holding_s2['held_dollar_01rk']>0.5))&(t_est_holding_s2['ratio_flg_up_t1q']>0.3)
    t_est_holding_s2.loc[c1, 'flow_est_v1b_high2H_ug'] = t_est_holding_s2.loc[c1, 'flow_est_v1']
    
    c1 = (t_est_holding_s2['pctOfSO_01rk']<0.5)&(t_est_holding_s2['held_dollar_01rk']<0.5)&(t_est_holding_s2['ratio_flg_up_t1q']>0.3)
    t_est_holding_s2.loc[c1, 'flow_est_v1c_lowH_ug'] = t_est_holding_s2.loc[c1, 'flow_est_v1']
    c1 = (t_est_holding_s2['pctOfSO_01rk']>0.5)&(t_est_holding_s2['held_dollar_01rk']>0.5)&(t_est_holding_s2['ratio_flg_up_t1q']<-0.3)
    t_est_holding_s2.loc[c1, 'flow_est_v1c_highH_dg'] = t_est_holding_s2.loc[c1, 'flow_est_v1']
        
    c1 = (t_est_holding_s2['pctOfSO_01rk']>0.5)&(t_est_holding_s2['held_dollar_01rk']<0.5)&(t_est_holding_s2['ratio_flg_up_t1q']>0.3)
    t_est_holding_s2.loc[c1, 'flow_est_ug_b2_a'] = t_est_holding_s2.loc[c1, 'flow_est_v1']
    c1 = (t_est_holding_s2['pctOfSO_01rk']>0.5)&(t_est_holding_s2['held_dollar_01rk']>0.5)&(t_est_holding_s2['ratio_flg_up_t1q']>0.3)
    t_est_holding_s2.loc[c1, 'flow_est_ug_b2_b'] = t_est_holding_s2.loc[c1, 'flow_est_v1']
    c1 = (t_est_holding_s2['pctOfSO_01rk']<0.5)&(t_est_holding_s2['held_dollar_01rk']<0.5)&(t_est_holding_s2['ratio_flg_up_t1q']>0.3)
    t_est_holding_s2.loc[c1, 'flow_est_ug_b2_c'] = t_est_holding_s2.loc[c1, 'flow_est_v1']
    c1 = (t_est_holding_s2['
pctOfSO_01rk']<0.5)&(t_est_holding_s2['held_dollar_01rk']>0.5)&(t_est_holding_s2['ratio_flg_up_t1q']>0.3)
    t_est_holding_s2.loc[c1, 'flow_est_ug_b2_d'] = t_est_holding_s2.loc[c1, 'flow_est_v1']
    
    c1 = (t_est_holding_s2['inst_cnt_01rk']>0.5)&(t_est_holding_s2['concentration_01rk']<0.5)&(t_est_holding_s2['ratio_flg_up_t1q']>0.3)
    t_est_holding_s2.loc[c1, 'flow_est_ug_b1_a'] = t_est_holding_s2.loc[c1, 'flow_est_v1']
    c1 = (t_est_holding_s2['inst_cnt_01rk']>0.5)&(t_est_holding_s2['concentration_01rk']>0.5)&(t_est_holding_s2['ratio_flg_up_t1q']>0.3)
    t_est_holding_s2.loc[c1, 'flow_est_ug_b1_b'] = t_est_holding_s2.loc[c1, 'flow_est_v1']
    c1 = (t_est_holding_s2['inst_cnt_01rk']<0.5)&(t_est_holding_s2['concentration_01rk']<0.5)&(t_est_holding_s2['ratio_flg_up_t1q']>0.3)
    t_est_holding_s2.loc[c1, 'flow_est_ug_b1_c'] = t_est_holding_s2.loc[c1, 'flow_est_v1']
    c1 = (t_est_holding_s2['inst_cnt_01rk']<0.5)&(t_est_holding_s2['concentration_01rk']>0.5)&(t_est_holding_s2['ratio_flg_up_t1q']>0.3)
    t_est_holding_s2.loc[c1, 'flow_est_ug_b1_d'] = t_est_holding_s2.loc[c1, 'flow_est_v1']
        
    
    # output
    cols = ['flow_est_v1','flow_est_v1_lowH_ug','flow_est_v1_highH_dg',
            'flow_est_v1b_lowH_ug','flow_est_v1b_highH_ug', 'flow_est_v1b_high2H_ug',
            'flow_est_v1c_lowH_ug','flow_est_v1c_highH_dg',
            'flow_est_ug_b1_a','flow_est_ug_b1_b','flow_est_ug_b1_c','flow_est_ug_b1_d',
            'flow_est_ug_b2_a','flow_est_ug_b2_b','flow_est_ug_b2_c','flow_est_ug_b2_d']
    s_flow_est = t_est_holding_s2.groupby('ticker')[cols].sum().reset_index()
    s_flow_est['datadate'] = dt
    
    o_mfrpt.append(s_flow_est)
    
o_mfrpt = pd.concat(o_mfrpt, axis = 0)
    
    
#o_mfrpt.to_parquet(r'S:\Data\China Data Hunt\cache\pERN_cn_mfrpt_ugdg_20bd2e.parquet')
#o_mfrpt = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pERN_cn_mfrpt_ugdg_20bd2e.parquet')
#o_mfrpt.to_parquet(r'S:\Data\China Data Hunt\cache\pERN_cn_mfrpt_ugdg_100bd2e.parquet')
#o_mfrpt2.to_parquet(r'S:\Data\China Data Hunt\cache\pERN_cn_mfrpt_ugdg_20bd2e_not_held.parquet')






### loop (t1q ugdg) - gf's benchmark test

o_gf_bchmk = []

for dt in pd.date_range(start = '2017-01-01', end = '2021-12-31'):
    print(dt.strftime('%Y%m%d'), end=',')    

    t_ugdg = i_ugdg[(i_ugdg['datadate']<=dt)&(i_ugdg['datadate']>=dt-pd.to_timedelta('91 days'))]
    t_ugdg_tk_maxdd = t_ugdg.groupby(['ticker','organ_id'])['create_date'].max().reset_index()
    if len(t_ugdg_tk
_maxdd)==0:
        print('_',end=',')
        continue
    t_ugdg_tk_maxdd = t_ugdg_tk_maxdd.merge(t_ugdg,on=['ticker','organ_id','create_date'],how='inner')
    
    t_ugdg_tk_maxdd['flg_or_up'] = np.sign(t_ugdg_tk_maxdd['frcst_or'] - t_ugdg_tk_maxdd['frcst_or_prev'])
    t_ugdg_tk_maxdd['flg_np_up'] = np.sign(t_ugdg_tk_maxdd['frcst_np'] - t_ugdg_tk_maxdd['frcst_np_prev'])
    t_ugdg_tk_maxdd['flg_eps_up'] = np.sign(t_ugdg_tk_maxdd['frcst_eps'] - t_ugdg_tk_maxdd['frcst_eps_prev'])
    t_ugdg_tk_maxdd['flg_gg_up'] = np.sign(t_ugdg_tk_maxdd['ggrate'] - t_ugdg_tk_maxdd['ggrate_prev'])
    t_ugdg_tk_maxdd['sgn_flg_up'] = np.sign(t_ugdg_tk_maxdd[['flg_or_up','flg_np_up','flg_eps_up','flg_gg_up']].sum(axis=1))
    t_ugdg_tk_maxdd['sum_flg_up'] = t_ugdg_tk_maxdd[['flg_or_up','flg_np_up','flg_eps_up','flg_gg_up']].sum(axis=1)
    
    s_up_ratio = t_ugdg_tk_maxdd.groupby('ticker')['sgn_flg_up'].apply(lambda x: x.sum()/x.count())
    s_up_ratio = s_up_ratio.reset_index()
    s_up_ratio = s_up_ratio.rename(columns={'sgn_flg_up':'ratio_flg_up_t1q'})
    s_up_ratio = s_up_ratio[['ticker', 'ratio_flg_up_t1q']]
    s_up_ratio['datadate'] = dt
    
    o_gf_bchmk.append(s_up_ratio)

o_gf_bchmk = pd.concat(o_gf_bchmk, axis = 0)


### agg holding - gf's benchmark test 

i_h_agg = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_wind_holding_mf_q_est_step2.parquet',
                          columns = ['ticker','datadate','held_dollar_active','pctOfSO_active'])
i_h_agg['held_dollar_active_rk_gf'] = i_h_agg.groupby('datadate')['held_dollar_active'].apply(yu.uniformed_rank)
i_h_agg['pctOfSO_active_rk_gf'] = i_h_agg.groupby('datadate')['pctOfSO_active'].apply(yu.uniformed_rank)
i_h_agg = i_h_agg[['ticker','datadate','held_dollar_active_rk_gf','pctOfSO_active_rk_gf']]




#------------------------------------------------------------------------------
### combine 2K
#------------------------------------------------------------------------------


icom = i_sd.merge(o_mfrpt, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(o_gf_bchmk, on = ['ticker', 'datadate'], how = 'left')


icom = icom.merge(i_h_agg, on = ['ticker', 'datadate'], how = 'left') # this line is wrong. we need merge_asof

icom = icom.sort_values(['ticker', 'datadate'])



# naive
# short positions (high mf holding, dg) do not work. Still positive return due to high mf holding.
# rank(flow/pv) generates more drawdown
# v1 (based on held dollar) is slightly better than v2 (based on pc
tOfSO)
# selecting both low dollar_held and low pctOfSO works, but we lose sharpe is the criteria is too strict
# ugdg > 0.3 is better than ugdg > 0
# very long holding periods do not work. PNL more concentrated near reporting ( or earning)

icom['flow_est_v1_dv_pv'] = icom['flow_est_v1'].divide(icom['avgPVadj'])
icom.loc[icom['flow_est_v1_dv_pv']>0.5, 'flow_est_v1_dv_pv'] = np.nan
icom.loc[icom['flow_est_v1_dv_pv']<-0.5, 'flow_est_v1_dv_pv'] = np.nan

icom['sgnl_est_v1_long'] = np.nan
c1 = icom['flow_est_v1_dv_pv'] > 0
icom.loc[c1, 'sgnl_est_v1_long'] = icom.loc[c1, 'flow_est_v1_dv_pv']



icom['flow_est_v1_lowH_ug_dv_pv'] = icom['flow_est_v1_lowH_ug'].divide(icom['avgPVadj'])
icom['flow_est_v1_lowH_ug_dv_pv'] = icom['flow_est_v1_lowH_ug_dv_pv'].replace(0,np.nan)

icom['sgnl_est_v1_lowH_ug_dv_pv'] = icom['flow_est_v1_lowH_ug_dv_pv']*10
icom.loc[icom['sgnl_est_v1_lowH_ug_dv_pv']>1, 'sgnl_est_v1_lowH_ug_dv_pv'] = 1


icom['flow_est_v1b_lowH_ug_dv_pv'] = icom['flow_est_v1b_lowH_ug'].divide(icom['avgPVadj'])
icom['flow_est_v1b_lowH_ug_dv_pv'] = icom['flow_est_v1b_lowH_ug_dv_pv'].replace(0,np.nan)

icom['sgnl_est_v1b_lowH_ug_dv_pv'] = icom['flow_est_v1b_lowH_ug_dv_pv']*10
icom.loc[icom['sgnl_est_v1b_lowH_ug_dv_pv']>1, 'sgnl_est_v1b_lowH_ug_dv_pv'] = 1

icom['flow_est_v1b_lowH_ug_dv_pv_gt0p01'] = icom['flow_est_v1b_lowH_ug_dv_pv']
icom['flow_est_v1b_lowH_ug_dv_pv_01rk'] = icom.groupby('datadate')['flow_est_v1b_lowH_ug_dv_pv'].apply(lambda x: x.rank()/x.count()).values




o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_est_v1_long','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_est_v1_long','BarrRet_CLIP_USD+1d', static_data = i_sd) # 


o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_est_v1_lowH_ug_dv_pv','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_est_v1_lowH_ug_dv_pv','BarrRet_CLIP_USD+1d', static_data = i_sd)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_est_v1b_lowH_ug_dv_pv','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_est_v1b_lowH_ug_dv_pv','BarrRet_CLIP_USD+1d', static_data = i_sd)




# holding low, rating high ###!!!

icom['flow_est_v1c_lowH_ug_dv_pv'] = icom['flow_est_v1c_lowH_ug'].divide(icom['avgPVadj'])
icom['flow_est_v1c_lo
wH_ug_dv_pv'] = icom['flow_est_v1c_lowH_ug_dv_pv'].replace(0,np.nan)

icom['sgnl_est_v1c_lowH_ug_dv_pv'] = icom['flow_est_v1c_lowH_ug_dv_pv']*10
icom.loc[icom['sgnl_est_v1c_lowH_ug_dv_pv']>1, 'sgnl_est_v1c_lowH_ug_dv_pv'] = 1

icom['sgnl_est_v1c_lowH_ug_dv_pv_2'] = icom['flow_est_v1c_lowH_ug_dv_pv']*100
icom.loc[icom['sgnl_est_v1c_lowH_ug_dv_pv_2']>1, 'sgnl_est_v1c_lowH_ug_dv_pv_2'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_est_v1c_lowH_ug_dv_pv_2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_est_v1c_lowH_ug_dv_pv_2','BarrRet_CLIP_USD+1d', static_data = i_sd)

# sgnl 1
# 20 ~ -5, 3.79 / 2.96, 17%, 3.25m
# 10 ~ -5, 3.75 / 2.69, 18.6%, 1.75m
# 100 ~ -5, 2.51 / 1.98, 10%, 5m
# sgnl 2
# 20 ~ -5, 4.22 / 3.11, 16%, 1.25e7




icom['flow_est_ug_b2_a_dv_pv'] = icom['flow_est_ug_b2_a'].divide(icom['avgPVadj'])
icom['flow_est_ug_b2_a_dv_pv'] = icom['flow_est_ug_b2_a_dv_pv'].replace(0,np.nan)
icom['sgnl_est_ug_b2_a_dv_pv_2'] = icom['flow_est_ug_b2_a_dv_pv']*100
icom.loc[icom['sgnl_est_ug_b2_a_dv_pv_2']>1, 'sgnl_est_ug_b2_a_dv_pv_2'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_est_ug_b2_a_dv_pv_2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_est_ug_b2_a_dv_pv_2','BarrRet_CLIP_USD+1d', static_data = i_sd)



icom['flow_est_ug_b2_b_dv_pv'] = icom['flow_est_ug_b2_b'].divide(icom['avgPVadj'])
icom['flow_est_ug_b2_b_dv_pv'] = icom['flow_est_ug_b2_b_dv_pv'].replace(0,np.nan)
icom['sgnl_est_ug_b2_b_dv_pv_2'] = icom['flow_est_ug_b2_b_dv_pv']*100
icom.loc[icom['sgnl_est_ug_b2_b_dv_pv_2']>1, 'sgnl_est_ug_b2_b_dv_pv_2'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_est_ug_b2_b_dv_pv_2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_est_ug_b2_b_dv_pv_2','BarrRet_CLIP_USD+1d', static_data = i_sd)



icom['flow_est_ug_b2_c_dv_pv'] = icom['flow_est_ug_b2_c'].divide(icom['avgPVadj'])
icom['flow_est_ug_b2_c_dv_pv'] = icom['flow_est_ug_b2_c_dv_pv'].replace(0,np.nan)
icom['sgnl_est_ug_b2_c_dv_pv_2'] = icom['flow_est_ug_b2_c_dv_pv']*100
icom.loc[icom['sgnl_est_ug_b2_c_dv_pv_2']>1, 'sgnl_est_ug_b2_c_dv_pv_2'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_est_ug_b2_c_dv_pv_
2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_est_ug_b2_c_dv_pv_2','BarrRet_CLIP_USD+1d', static_data = i_sd)



icom['flow_est_ug_b2_d_dv_pv'] = icom['flow_est_ug_b2_d'].divide(icom['avgPVadj'])
icom['flow_est_ug_b2_d_dv_pv'] = icom['flow_est_ug_b2_d_dv_pv'].replace(0,np.nan)
icom['sgnl_est_ug_b2_d_dv_pv_2'] = icom['flow_est_ug_b2_d_dv_pv']*100
icom.loc[icom['sgnl_est_ug_b2_d_dv_pv_2']>1, 'sgnl_est_ug_b2_d_dv_pv_2'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_est_ug_b2_d_dv_pv_2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_est_ug_b2_d_dv_pv_2','BarrRet_CLIP_USD+1d', static_data = i_sd)






icom['flow_est_ug_b1_a_dv_pv'] = icom['flow_est_ug_b1_a'].divide(icom['avgPVadj'])
icom['flow_est_ug_b1_a_dv_pv'] = icom['flow_est_ug_b1_a_dv_pv'].replace(0,np.nan)
icom['sgnl_est_ug_b1_a_dv_pv_2'] = icom['flow_est_ug_b1_a_dv_pv']*100
icom.loc[icom['sgnl_est_ug_b1_a_dv_pv_2']>1, 'sgnl_est_ug_b1_a_dv_pv_2'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_est_ug_b1_a_dv_pv_2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_est_ug_b1_a_dv_pv_2','BarrRet_CLIP_USD+1d', static_data = i_sd)



icom['flow_est_ug_b1_b_dv_pv'] = icom['flow_est_ug_b1_b'].divide(icom['avgPVadj'])
icom['flow_est_ug_b1_b_dv_pv'] = icom['flow_est_ug_b1_b_dv_pv'].replace(0,np.nan)
icom['sgnl_est_ug_b1_b_dv_pv_2'] = icom['flow_est_ug_b1_b_dv_pv']*100
icom.loc[icom['sgnl_est_ug_b1_b_dv_pv_2']>1, 'sgnl_est_ug_b1_b_dv_pv_2'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_est_ug_b1_b_dv_pv_2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_est_ug_b1_b_dv_pv_2','BarrRet_CLIP_USD+1d', static_data = i_sd)



icom['flow_est_ug_b1_c_dv_pv'] = icom['flow_est_ug_b1_c'].divide(icom['avgPVadj'])
icom['flow_est_ug_b1_c_dv_pv'] = icom['flow_est_ug_b1_c_dv_pv'].replace(0,np.nan)
icom['sgnl_est_ug_b1_c_dv_pv_2'] = icom['flow_est_ug_b1_c_dv_pv']*100
icom.loc[icom['sgnl_est_ug_b1_c_dv_pv_2']>1, 'sgnl_est_ug_b1_c_dv_pv_2'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_est_ug_b1_c_dv_pv_2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
           
 'sgnl_est_ug_b1_c_dv_pv_2','BarrRet_CLIP_USD+1d', static_data = i_sd)



icom['flow_est_ug_b1_d_dv_pv'] = icom['flow_est_ug_b1_d'].divide(icom['avgPVadj'])
icom['flow_est_ug_b1_d_dv_pv'] = icom['flow_est_ug_b1_d_dv_pv'].replace(0,np.nan)
icom['sgnl_est_ug_b1_d_dv_pv_2'] = icom['flow_est_ug_b1_d_dv_pv']*100
icom.loc[icom['sgnl_est_ug_b1_d_dv_pv_2']>1, 'sgnl_est_ug_b1_d_dv_pv_2'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_est_ug_b1_d_dv_pv_2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_est_ug_b1_d_dv_pv_2','BarrRet_CLIP_USD+1d', static_data = i_sd)













        

# not-held tickers
# not working at all

icom['sgnl_not_held'] = np.nan
icom.loc[icom['mf_num']>0, 'sgnl_not_held'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_not_held','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_not_held','BarrRet_CLIP_USD+1d', static_data = i_sd) #




# benchmark


icom['cond'] = (icom['held_dollar_active_rk_gf']<0) & (icom['pctOfSO_active_rk_gf']<0)

icom['ratio_flg_up_t1q'] = icom['ratio_flg_up_t1q'].replace(0, np.nan)

c1 = icom['ratio_flg_up_t1q']>0.3
icom['sgnl_benchmark'] = np.nan
icom.loc[c1, 'sgnl_benchmark'] = icom.loc[c1, 'ratio_flg_up_t1q']

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_benchmark','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_benchmark','BarrRet_CLIP_USD+1d', static_data = i_sd)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))&(~icom['cond'])].\
            dropna(subset=['sgnl_benchmark','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_benchmark','BarrRet_CLIP_USD+1d', static_data = i_sd)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))&icom['cond']].\
            dropna(subset=['sgnl_benchmark','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_benchmark','BarrRet_CLIP_USD+1d', static_data = i_sd)


COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['ratio_flg_up_t1q_orth'] = icom.groupby('datadate')[COLS+['ratio_flg_up_t1q']].apply(lambda x: yu.orthogonalize_cn(x['ratio_flg_up_t1q'], x[COLS])).values
i
com['ratio_flg_up_t1q_orth_bk'] = icom.groupby('datadate')['ratio_flg_up_t1q_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ratio_flg_up_t1q_orth_rk'] = icom.groupby('datadate')['ratio_flg_up_t1q_orth'].apply(yu.uniformed_rank)
yu.create_cn_3x3(icom, ['ratio_flg_up_t1q_orth_bk'], 'ratio_flg_up_t1q_orth')

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['ratio_flg_up_t1q_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ratio_flg_up_t1q_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))&(icom['ratio_flg_up_t1q_orth_rk']>0.2)].\
            dropna(subset=['ratio_flg_up_t1q_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ratio_flg_up_t1q_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)


icom['held_dollar_active_rk_gf_bk'] = icom.groupby('datadate')['held_dollar_active_rk_gf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['pctOfSO_active_rk_gf_bk'] = icom.groupby('datadate')['pctOfSO_active_rk_gf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ratio_flg_up_t1q_bk'] = icom.groupby('datadate')['ratio_flg_up_t1q'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom[icom['ratio_flg_up_t1q']>=0.3], ['held_dollar_active_rk_gf_bk'], 'held_dollar_active_rk_gf')
yu.create_cn_3x3(icom[icom['ratio_flg_up_t1q']>=0.3], ['pctOfSO_active_rk_gf_bk'], 'pctOfSO_active_rk_gf')



# 3.04 / 2.4, 9.6%, 2.2e7




# test v1 c d e
# test longer/shorter holding periods
# test more extreme cases: low holding + UG


# when there is ug, trade low-holding tickers immediately
# there is big ug, trade low-holding and zero-holding tickers immediately





#------------------------------------------------------------------------------
### combine SS
#------------------------------------------------------------------------------


icom = i_sd_ss.merge(o_mfrpt, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])



icom['flow_est_v1c_lowH_ug_dv_pv'] = icom['flow_est_v1c_lowH_ug'].divide(icom['avgPVadj'])
icom['flow_est_v1c_lowH_ug_dv_pv'] = icom['flow_est_v1c_lowH_ug_dv_pv'].replace(0,np.nan)

icom['sgnl_est_v1c_lowH_ug_dv_pv'] = icom['flow_est_v1c_lowH_ug_dv_pv']*10
icom.loc[icom['sgnl_est_v1c_lowH_ug_dv_pv']>1, 'sgnl_est_v1c_lowH_ug_dv_pv'] = 1


o_1 = yu.bt_cn_15(icom[(icom['datadate'].between(
'2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_est_v1c_lowH_ug_dv_pv','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_est_v1c_lowH_ug_dv_pv','BarrRet_CLIP_USD+1d', static_data = i_sd)

# 1.84 / 1.17
