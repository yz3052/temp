﻿#$%^&* prodWIND_ticker_index_mapping.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 26 10:25:45 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import datetime

import urllib
from sqlalchemy import create_engine



### helper functions


def get_sql_wind(query):    
    engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_wind_dbo;PWD=DusONA3Habredl;''TDS_Version=8.0;')))
    # gf's version: conn2 = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=WIND;UID=svc_wind_dbo;PWD=DusONA3Habredl;TDS_Version=8.0;')
    return pd.read_sql_query(query, con=engine)

engine_cndbprod = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;DATABASE=CNDBPROD;;UID=svc_tz_dbo;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))




### get time

NOW = datetime.datetime.now()



### get daily snapshot of active index-fund mapping

i_data = get_sql_wind('''select S_INFO_WINDCODE, S_INFO_INDEXWINDCODE, ENTRY_DT, REMOVE_DT 
                         from WIND_PROD.dbo.CHINAMUTUALFUNDTRACKINGINDEX 
                         where remove_dt is null''')
                    
i_data['scraper_ts_est'] = NOW
i_data['scraper_ts_cn'] = pd.to_datetime(NOW).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
i_data['DataDate_cn'] = pd.to_datetime(i_data['scraper_ts_cn'].dt.date)
i_data['T-1d_cn'] = i_data['DataDate_cn'] - pd.to_timedelta('1 day')



### upload 

i_data.to_sql('[CNDB].[dbo].[snapshot_WIND_index_fund_mapping]', con = engine_cndbprod, if_exists = 'append', index = False)

