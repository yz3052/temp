﻿#$%^&* pFlow_cn_mf_etl_v2.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 24 05:55:19 2023

@author: thzhang
"""


import pandas as pd
import numpy as np

import os
import util as yu
import datetime

from multiprocessing import Pool
from sqlalchemy import create_engine
import urllib

#engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
    


###??? delta metrics still not right ... how to differentiate between nan and 0?
# there are tickers whose curr and prev holding are both nan ... ? why?


### reminder:
# if a fund only allocate 10% to equity, then its equity holding is not important
# for now if there is no prev / curr holding of a ticker, all holding columns are nan, not zero

### Caveat
# sometimes shares_held / pctOfMFSTK are all none -> held_dollar is the most reliable column to guess pst
# Jun and Dec data is reported twice

### database maintanance
# if we want to start a ticker from scratch, we need to delete both data and progress files

'''
LINUX cmd
rm /dat/summit_capital/PROD/TZ/mf_holding_details/data/*
rm /dat/summit_capital/PROD/TZ/mf_holding_details/progress/*
'''

#--------------------------------------------------------------------------
### ---Part 1--- update data progress
#--------------------------------------------------------------------------


### get all the compcode+date available in SQL

today_cn = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None).date()
date_compcode_all = yu.get_sql_wind('''
                                    select distinct b.s_info_compcode, a.ann_date as [T-1d] 
                                    from wind_prod.dbo.ChinaMutualFundStockPortfolio a
                                    left join wind_prod.dbo.windcustomcode b
                                    on a.s_info_windcode = b.s_info_windcode 
                                        and a.ann_date < '{0}' and a.ann_date > '20150601'
                                    where b.s_info_compcode is not null 
                                    order by b.s_info_compcode, a.ann_date
                                    '''.format(today_cn.strftime('%Y%m%d')))
                                    
### if there is a new compcode, add its folder to datadev

root_data = '/dat/summit_capital/PROD/TZ/mf_holding
_details/data/'
compcode_existing = [f.split('.')[0] for f in os.listdir(root_data)]
compcode_all = date_compcode_all['s_info_compcode'].unique().tolist()
compcode_add = [c for c in compcode_all if c not in compcode_existing]
for c in compcode_add:    
    tdata = pd.DataFrame({'ticker_fund': '260117.OF', 'T-1d': pd.to_datetime('2015-07-18'), 'report_period': '20150630',
     'ticker': '000958.SZ', 'held_dollar': 0.0, 'held_shares': 0.0, 'pctOfMFNAV': 0.0,
     'pctOfMFSTK': 0.0, 'pctOfSO': 0.0, 's_info_compcode': '00aL5kP7d9', 'flg_is_act': 1,
     'ann_date_prev': pd.to_datetime('2015-01-01'), 'report_period_prev': '20150630', 'held_dollar_prev': 0.0, 'held_shares_prev': 0.0,
     'pctOfMFNAV_prev': 0.0, 'pctOfMFSTK_prev': 0.0, 'pctOfSO_prev': 0.0, 'flg_is_act_prev': 0.0},index=[0])
    tdata = tdata[[False]]
    tdata.to_parquet(root_data + c + '.parquet')
    
root_progress = '/dat/summit_capital/PROD/TZ/mf_holding_details/progress/'
compcode_existing = [f.split('.')[0] for f in os.listdir(root_progress)]
compcode_all = date_compcode_all['s_info_compcode'].unique().tolist()
compcode_add = [c for c in compcode_all if c not in compcode_existing]
for c in compcode_add:
    tdata = pd.DataFrame({'s_info_compcode': [c], 'most_recent_t1d': ['19900101']})
    tdata.to_parquet(root_progress + c + '.parquet')


### get the query progress

root_progress = '/dat/summit_capital/PROD/TZ/mf_holding_details/progress/'
files_progress = os.listdir(root_progress)
date_comp_queried = pd.concat([pd.read_parquet(root_progress+f) for f in files_progress], axis = 0)


### get all the compcode+date that will be queried today

date_compcode_to_query = date_compcode_all.merge(date_comp_queried, on = 's_info_compcode', 
                                                 how = 'left')
c1 = date_compcode_to_query['most_recent_t1d'].notnull() \
     & date_compcode_to_query['T-1d'].gt(date_compcode_to_query['most_recent_t1d'])
date_compcode_to_query = date_compcode_to_query[ c1]
date_compcode_to_query['param'] = date_compcode_to_query['s_info_compcode']+'@@'+date_compcode_to_query['T-1d']
date_compcode_to_query = date_compcode_to_query.sort_values(['s_info_compcode', 'T-1d'])
date_compcode_to_query = date_compcode_to_query.reset_index(drop = True)



### helper that processes 1 fund 1 date

def process_fund_date_upon_disclose( compcode_aa_t1dstr ):
    
    
    compcode = compcode_aa_t1dstr.split('@@')[0]
    t1d_str = compcode_aa_t1dstr.split('@@')[1]
    t1d = pd.to_datetime(t1d_s
tr, format='%Y%m%d')
    t7d = pd.to_datetime(t1d, format='%Y%m%d') - pd.to_timedelta('7 days')
    t7d_str = t7d.strftime('%Y%m%d')
    
    
    ### get report_period / compcode / ann_date mapping
    # the max ann_date is always t1d
    i_core_map = yu.get_sql_wind('''select distinct  a.f_prt_enddate as report_period, 
                                             b.s_info_compcode, 
                                             a.ann_date as [T-1d]
                         from wind_prod.dbo.ChinaMutualFundStockPortfolio a 
                         left join wind_prod.dbo.windcustomcode b 
                         on a.s_info_windcode = b.s_info_windcode
                            and  b.s_info_compcode = '{0}'
                            and a.ann_date <= '{1}'
                         where b.s_info_compcode is not null 
                         order by b.s_info_compcode, a.f_prt_enddate, a.ann_date
                         '''.format(compcode, t1d_str))
    i_core_map['flg_is_full'] = np.nan
    i_core_map.loc[i_core_map['report_period'].str[4:6].isin(['06','12']), 'flg_is_full'] = 1 #wrong
    i_core_map.loc[i_core_map.index==0, 'flg_is_full'] = 1
    
    MAX_REPORT_PERIOD = i_core_map['report_period'].max()
    #SECOND_REPORT_PERIOD = i_core_map.loc[i_core_map['report_period']<MAX_REPORT_PERIOD, 'report_period'].max()
    SECOND_FULL_REPORT_PERIOD = i_core_map.loc[i_core_map['report_period'].lt(MAX_REPORT_PERIOD) & i_core_map['flg_is_full'].eq(1), 'report_period'].max()
    
    
    ### get actual / estimated full holding for the prev report period
    
    i_prev = pd.read_parquet('/dat/summit_capital/PROD/TZ/mf_holding_details/data/'+compcode+'.parquet')
    i_prev = i_prev[i_prev['T-1d'] == i_prev['T-1d'].max()]    
    i_prev = i_prev.drop(columns = [c for c in i_prev.columns.tolist() if c.endswith('_prev')])
    
    i_prev = i_prev[i_prev['held_dollar'].ne(0) & i_prev['held_dollar'].notnull()] ###!!! this get rid of nans
    i_prev = i_prev.fillna(np.nan)
                        
    if (len(i_prev) == 0) & (pd.notnull(SECOND_FULL_REPORT_PERIOD)) :
        i_prev = yu.get_sql_wind('''select a.s_info_windcode as ticker_fund, 
                                   a.ann_date as [T-1d],
                                   a.f_prt_enddate as report_period, 
                                   a.s_info_stockwindcode as ticker,
                                   a.f_prt_stkvalue as held_dollar, 
                                   a.f_prt_stkquantity 
as held_shares,
                                   a.f_prt_stkvaluetonav/100 as pctOfMFNAV, 
                                   a.stock_per/100 as pctOfMFSTK,
                                   a.float_shr_per/100 as pctOfSO,
                                   b.s_info_compcode 
                          from wind_prod.dbo.ChinaMutualFundStockPortfolio a
                          left join wind_prod.dbo.windcustomcode b
                          on a.s_info_windcode = b.s_info_windcode 
                              and b.s_info_compcode = '{0}' and a.ann_date <= '{1}'
                              and a.f_prt_enddate = '{2}'
                          where b.s_info_compcode is not null
                          '''.format(compcode, t1d_str, SECOND_FULL_REPORT_PERIOD))
        i_prev = i_prev.sort_values(['s_info_compcode','report_period','T-1d','ticker','ticker_fund'])
        i_prev = i_prev.drop_duplicates(subset = ['s_info_compcode','report_period', 'T-1d','ticker'], keep = 'first')
        i_prev = i_prev.drop_duplicates(subset = ['s_info_compcode','report_period', 'ticker'], keep = 'first')
        i_prev = i_prev.sort_values(['s_info_compcode','report_period','T-1d'])
        i_prev['T-1d'] = pd.to_datetime(i_prev['T-1d'], format='%Y%m%d')        
        i_prev['flg_is_act'] = 1
        if i_prev['pctOfMFSTK'].sum()<=0.98:
            i_prev = pd.DataFrame(columns = i_prev.columns.tolist())
        
    if i_prev['ticker_fund'].nunique() > 1:
        raise Exception('more than 1 ticker fund in i_prev.')
    
    
    
    ### get all disclosures for the curr report_period
    i_disclosure_t1d = yu.get_sql_wind('''select a.s_info_windcode as ticker_fund, 
                                   a.ann_date as [T-1d],
                                   a.f_prt_enddate as report_period, 
                                   a.s_info_stockwindcode as ticker,
                                   a.f_prt_stkvalue as held_dollar, 
                                   a.f_prt_stkquantity as held_shares,
                                   a.f_prt_stkvaluetonav/100 as pctOfMFNAV, 
                                   a.stock_per/100 as pctOfMFSTK,
                                   a.float_shr_per/100 as pctOfSO,
                                   b.s_info_compcode 
                          from wind_prod.dbo.ChinaMutualFundStockPortfolio a
                          left join wind_prod.dbo.windcustomcode b
                          on a.s_info_windcode = b.s_info_windcod
e 
                              and b.s_info_compcode = '{0}' and a.ann_date <= '{1}'
                              and a.f_prt_enddate = '{2}'
                          where b.s_info_compcode is not null
                          '''.format(compcode, t1d_str, MAX_REPORT_PERIOD))
    i_disclosure_t1d = i_disclosure_t1d[i_disclosure_t1d['ticker_fund'].isin(i_prev['ticker_fund'].ffill().bfill().tolist())]
    i_disclosure_t1d['T-1d'] = pd.to_datetime(i_disclosure_t1d['T-1d'], format = '%Y%m%d')
    i_disclosure_t1d = i_disclosure_t1d.sort_values(['s_info_compcode','report_period','T-1d','ticker','ticker_fund'])
    i_disclosure_t1d = i_disclosure_t1d.drop_duplicates(subset = ['s_info_compcode','report_period', 'T-1d','ticker'], keep = 'first')
    i_disclosure_t1d = i_disclosure_t1d.sort_values(['s_info_compcode','report_period','T-1d'])
    i_disclosure_t1d ['flg_is_act'] = 1
    # i_disclosure_t1d['search_key'] = i_disclosure_t1d['s_info_compcode']+i_disclosure_t1d['report_period']
    # i_disclosure_t1d = i_disclosure_t1d.reset_index(drop = True)
    # i_disclosure_t1d['id'] = i_disclosure_t1d.index.values
    # i_mf_holding_index = i_disclosure_t1d.groupby('search_key')['id'].agg(['min','max'])
    
    
    ### 1: curr is full -> output
    if (i_disclosure_t1d['pctOfMFSTK'].sum() > 0.98):
        
        i_prev_s2 = i_prev[['ticker','T-1d','report_period','held_dollar', 'held_shares',
                            'pctOfMFNAV', 'pctOfMFSTK', 'pctOfSO', 'flg_is_act']]
        i_prev_s2 = i_prev_s2.rename(columns = {'T-1d':'ann_date_prev'})              
        
        i_disclosure_t1d_s2 = i_disclosure_t1d.merge(i_prev_s2, on = 'ticker', how = 'outer', suffixes = ['','_prev'])
        i_disclosure_t1d_s2['T-1d'] = t1d
        i_disclosure_t1d_s2['report_period'] = i_disclosure_t1d_s2['report_period'].ffill().bfill()
        i_disclosure_t1d_s2['ticker_fund'] = i_disclosure_t1d_s2['ticker_fund'].ffill().bfill()
        i_disclosure_t1d_s2['s_info_compcode'] = i_disclosure_t1d_s2['s_info_compcode'].ffill().bfill()
        
        o_parq = pd.read_parquet('/dat/summit_capital/PROD/TZ/mf_holding_details/data/'+compcode+'.parquet')
        o_parq = pd.concat([o_parq, i_disclosure_t1d_s2], axis = 0)
        try:
            o_parq.to_parquet('/dat/summit_capital/PROD/TZ/mf_holding_details/data/'+compcode+'.parquet')
        except:
            print(i_disclosure_t1d_s2.dtypes)
            print(o_parq.dtypes)
        
        o_status = pd.DataFrame({'s_i
nfo_compcode': [compcode], 'most_recent_t1d': [t1d_str]})
        o_status.to_parquet('/dat/summit_capital/PROD/TZ/mf_holding_details/progress/'+compcode+'.parquet')
                
        return 'full'
    
        
    ### 2: curr not full -> guess 
        
    ### 2.1 - curr not full, no prev full -> skip 
                            
    if (i_disclosure_t1d['pctOfMFSTK'].sum()<=0.98) & (len(i_prev) == 0):
        return 'insuff'
    
    if (i_disclosure_t1d['pctOfMFSTK'].sum()<=0.98) & (i_prev['pctOfMFSTK'].sum()<=0.98):
        return 'insuff'
    
    
    ### 2.2 - guess current positions
    
    if (i_disclosure_t1d['pctOfMFSTK'].sum()<=0.98) & (len(i_prev) > 0):
        
        t_curr = i_disclosure_t1d.copy()
            
        # undisclosed total held dollar 
        t_curr_pctOdMFSTK_valid = (t_curr['pctOfMFSTK']>0) & t_curr['pctOfMFSTK'].notnull()
        c_curr_stk = t_curr.loc[t_curr_pctOdMFSTK_valid, 'held_dollar'].divide(t_curr.loc[t_curr_pctOdMFSTK_valid, 'pctOfMFSTK']).mean()
        t_curr_pctOdMFNAV_valid = (t_curr['pctOfMFNAV']>0) & t_curr['pctOfMFNAV'].notnull()
        c_curr_nav = t_curr.loc[t_curr_pctOdMFNAV_valid, 'held_dollar'].divide(t_curr.loc[t_curr_pctOdMFNAV_valid, 'pctOfMFNAV']).mean()
        c_curr_unreported_MFSTK = c_curr_stk - t_curr['held_dollar'].sum()
        
        # the smallest disclosed held dollar 
        #     (smallest of top 10, some ETFs also disclose top 5 active holding)
        c_curr_min_held_dollar = t_curr['held_dollar'].nlargest(10).min()
        
        # only fetch relevant tickers from previous holding data
        t_prev = i_prev[~i_prev['ticker'].isin(t_curr['ticker'].tolist())]
        
        
        # estimate undisclosed holding
        # there is still a glitch here ... if held dollar is set to be c_curr_min_held_dollar-1,
        # total held dollar doesn't add up to the actual total held dollar
        t_prev = t_prev.rename(columns = {'held_dollar': 'held_dollar_old'})
        t_prev['held_dollar'] = t_prev['held_dollar_old'].divide(t_prev['held_dollar_old'].sum()) * c_curr_unreported_MFSTK
        t_prev.loc[t_prev['held_dollar']>c_curr_min_held_dollar, 'held_dollar'] = c_curr_min_held_dollar-1
    
        
        # estimate pcfOdMFSTK
        t_prev = t_prev.rename(columns={'pctOfMFSTK':'pctOfMFSTK_old'})
        t_prev['pctOfMFSTK'] = t_prev['held_dollar'].divide(c_curr_stk)
        
                
        # get most recent close price as of report_period 
        
t_c = yu.get_sql_wind('''with maxdd as (
                                select s_info_windcode, max(trade_dt) as maxdd
                                from wind_prod.dbo.ashareeodprices
                                where trade_dt <= '{0}' and trade_dt >= '{1}'
                                group by s_info_windcode, s_info_windcode
                                )
                                select a.s_info_windcode as ticker, a.s_dq_close as c
                                from wind_prod.dbo.ashareeodprices a
                                inner join maxdd b
                                on a.trade_dt <= '{0}' and a.trade_dt >= '{1}'
                                and a.trade_dt = b.maxdd and a.s_info_windcode = b.s_info_windcode                                 
                                where a.s_info_windcode in ('{2}')
                              '''.format(t1d_str,t7d_str, "','".join(t_prev['ticker'].unique().tolist()) ))
        t_prev = t_prev.merge(t_c, on = ['ticker'], how = 'left')
        
        
        # estimate held_shares and pctOdSO
        t_prev['held_shares_old'] = t_prev['held_shares']
        t_prev['held_shares'] = t_prev['held_dollar'].divide(t_prev['c'])
        try:
            t_prev['pctOfSO'] = t_prev['pctOfSO'].divide(t_prev['held_dollar_old']).multiply(t_prev['held_dollar'])
        except TypeError:
            print('type error')
            print(len(t_prev))
            raise Exception()
        
        # estimate curr NAV and pctOfNAV
        t_prev['pctOfMFNAV'] = t_prev['held_dollar'].divide(c_curr_nav)
        
        # format
        t_prev['T-1d'] = t1d
        t_prev['report_period'] = MAX_REPORT_PERIOD
        t_prev['flg_is_act'] = 0
        t_prev=  t_prev.drop(columns = ['c','held_shares_old','held_dollar_old','pctOfMFSTK_old'])
        
        # append prev holding
        t_o_est_holding = pd.concat([t_curr, t_prev], axis = 0)
        
        
        i_prev_s2 = i_prev[['ticker','T-1d','report_period','held_dollar', 'held_shares',
                            'pctOfMFNAV', 'pctOfMFSTK', 'pctOfSO', 'flg_is_act']]
        i_prev_s2 = i_prev_s2.rename(columns = {'T-1d':'ann_date_prev'})
        i_prev_s2 = i_prev_s2[i_prev_s2[['held_dollar', 'held_shares', 'pctOfMFNAV', 
                                         'pctOfMFSTK', 'pctOfSO']].notnull().any(axis=1)]
        
        t_o_est_holding = t_o_est_holding.merge(i_prev_s2, on = 'ticker', how = 'outer', suffixes = ['','_prev'])
  
      
        
               
                    
        
        # output
        
        if t_o_est_holding.duplicated(subset = ['ticker']).sum() > 0:
            raise Exception('est. pst ticker dup: '+compcode_aa_t1dstr)
        
        t_o_est_holding['T-1d'] = t1d
        t_o_est_holding['report_period'] = t_o_est_holding['report_period'].ffill().bfill()
        t_o_est_holding['ticker_fund'] = t_o_est_holding['ticker_fund'].ffill().bfill()
        t_o_est_holding['s_info_compcode'] = t_o_est_holding['s_info_compcode'].ffill().bfill()
                
        o_parq = pd.read_parquet('/dat/summit_capital/PROD/TZ/mf_holding_details/data/'+compcode+'.parquet')
        o_parq = pd.concat([o_parq, t_o_est_holding], axis = 0) 
        try:
            o_parq.to_parquet('/dat/summit_capital/PROD/TZ/mf_holding_details/data/'+compcode+'.parquet')        
        except:
            print(i_disclosure_t1d_s2.dtypes)
            print(o_parq.dtypes)
            raise Exception('write to parquet error') 
        
        o_status = pd.DataFrame({'s_info_compcode': [compcode], 'most_recent_t1d': [t1d_str]})
        o_status.to_parquet('/dat/summit_capital/PROD/TZ/mf_holding_details/progress/'+compcode+'.parquet')
        
        return 'est'



### helper that processes 1 fund and its history, if any history
def process_fund_upon_disclosure(compcode):
    #print(compcode,end=',')
    
    compcode_to_query = date_compcode_to_query[date_compcode_to_query['s_info_compcode']==compcode]
    
    for c in compcode_to_query['param'].tolist():
        process_fund_date_upon_disclose(c)
        

# if __name__ == '__main__':
#     with Pool(3) as p:
#         p.map(process_fund_upon_disclosure, date_compcode_to_query['s_info_compcode'].unique().tolist())

for j in date_compcode_to_query['s_info_compcode'].unique().tolist():
    print(j, end = ',')
    process_fund_upon_disclosure(j)


# for compcode in date_compcode_to_query['s_info_compcode'].unique().tolist():
#     process_fund_upon_disclosure(compcode




'''

t1 = pd.read_parquet('/dat/summit_capital/PROD/TZ/mf_holding_details/data/00aL5kP7d9.parquet')
t1 = pd.DataFrame(columns = t1.columns.tolist())
t1.to_parquet('/dat/summit_capital/PROD/TZ/mf_holding_details/data/00aL5kP7d9.parquet')

t2 = pd.read_parquet('/dat/summit_capital/PROD/TZ/mf_holding_details/progress/00aL5kP7d9.parquet')
t2 = pd.DataFrame({'s_info_compcode': ['00aL5kP7d9'], 'most_recent_t1d': ['19900101']})
t2.to_parquet('/dat/summit_capital/PR
OD/TZ/mf_holding_details/progress/00aL5kP7d9.parquet')
'''
