﻿#$%^&* pFlow_cn_mscihp_etl.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 24 13:31:04 2022

@author: thzhang
"""


import pandas as pd

import os
from zipfile import ZipFile
from datetime import datetime






### get PIT MSCI HP

o_metrics = []
o_weights = []

for yyyy in ['2020','2021','2022']:
    for r, p, fs in os.walk(os.path.join(r'Z:\MSCI\3713\Hedge_Fund_Crowding', yyyy)):
        for f in fs:
            if 'Intel_' in f and 'Intel_ID_' not in f:
                print('.',end='')
                ts_mdw = datetime.fromtimestamp(os.path.getmtime(os.path.join(r, f))).strftime('%Y-%m-%d %H:%M:%S')
                for zf in ZipFile(os.path.join(r, f)).infolist():                    
                    if 'Metrics' in zf.filename:
                        t_metrics = pd.read_csv(ZipFile(os.path.join(r, f)).open(zf.filename),skiprows=1,sep='|')
                        t_metrics = t_metrics[t_metrics['!Barrid']!='[End of File]']
                        t_metrics['ts_mdw'] = ts_mdw
                        o_metrics.append(t_metrics)
                    if 'Weights' in zf.filename:
                        t_weights = pd.read_csv(ZipFile(os.path.join(r, f)).open(zf.filename),skiprows=1,sep='|')
                        t_weights = t_weights[t_weights['!Barrid']!='[End of File]']
                        t_weights['ts_mdw'] = ts_mdw
                        o_weights.append(t_weights)
o_metrics = pd.concat(o_metrics, axis = 0)
o_metrics.to_parquet(r'S:\TZ\MSCI_HP\metrics_pit.parquet')
o_weights = pd.concat(o_weights, axis = 0)
o_weights.to_parquet(r'S:\TZ\MSCI_HP\weights_pit.parquet')
                

### get history MSCI HP

o_metrics_hist = []
o_weights_hist = []

for f in os.listdir(r'Z:\MSCI\3713\Hedge_Fund_Crowding\history'):
    t_zip_p = os.path.join(r'Z:\MSCI\3713\Hedge_Fund_Crowding\history', f)
    for zf in ZipFile(t_zip_p).infolist():
        print('.',end='')
        if 'Intel_Metrics' in zf.filename:
            t_metrics = pd.read_csv(ZipFile(t_zip_p).open(zf.filename),skiprows=1,sep='|')
            t_metrics = t_metrics[t_metrics['!Barrid']!='[End of File]']            
            ym = int(zf.filename[-8:-2])+1
            if str(ym)[-2:]=='13':
                ym+=88
            t_ts_mdw = pd.to_datetime(str(ym)+'22',format='%Y%m%d')            
            t_metrics['ts_mdw'] = t_ts_mdw
            o_metrics_hist.append(t_metrics)
        if 'Intel_Weights' in zf.filename:
            t_weights = pd.read_csv(ZipFile(t_zip_p).open(z
f.filename),skiprows=1,sep='|')
            t_weights = t_weights[t_weights['!Barrid']!='[End of File]']            
            ym = int(zf.filename[-8:-2])+1
            if str(ym)[-2:]=='13':
                ym+=88
            t_ts_mdw = pd.to_datetime(str(ym)+'22',format='%Y%m%d')            
            t_weights['ts_mdw'] = t_ts_mdw
            o_weights_hist.append(t_weights)
        
o_metrics_hist = pd.concat(o_metrics_hist, axis = 0)
o_metrics_hist.to_parquet(r'S:\TZ\MSCI_HP\metrics_hist.parquet')
o_weights_hist = pd.concat(o_weights_hist, axis = 0)
o_weights_hist.to_parquet(r'S:\TZ\MSCI_HP\weights_hist.parquet')
                

        
                


