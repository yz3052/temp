﻿#$%^&* pL2_cn_trade_kyReversal.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Apr  7 15:26:00 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine



### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])



### get data

i_kyr = yu.get_q('''get `:/export/datadev/Data/SHSZ/TRADE_metrics/trade_mean_trade_size''')

i_kyr['code'] = i_kyr['code'].str.decode('utf8')
c_sh = i_kyr['code'].str[0].isin(['6'])
c_sz = i_kyr['code'].str[0].isin(['0','3'])
i_kyr.loc[c_sh, 'ticker'] = i_kyr.loc[c_sh, 'code'] + '.SH'
i_kyr.loc[c_sz, 'ticker'] = i_kyr.loc[c_sz, 'code'] + '.SZ'
i_kyr['datadate'] = pd.to_datetime(i_kyr['date'])
i_kyr = i_kyr.sort_values(['ticker', 'datadate'])


### get o2c 

i_oc_c_ret = pw.get_wind_mkt_data(col_list = ['ticker', 'datadate', 'adjret_o_c', 'adjret_c_c','adjret'])
i_oc_c_ret = i_oc_c_ret.sort_values(['ticker', 'datadate'])
i_oc_c_ret['adjret_o_c_t20d'] = i_oc_c_ret.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['adjret_o_c'].sum().values
i_oc_c_ret['adjret_o_c_t40d'] = i_oc_c_ret.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['adjret_o_c'].sum().values
i_oc_c_ret['adjret_c_c_t20d'] = i_oc_c_ret.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['adjret'].sum().values
i_oc_c_ret['adjret_c_c_t40d'] = i_oc_c_ret.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['adjret'].sum().values




### combine

icom = i_sd.merge(i_kyr, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_oc_c_ret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']



### buy sell trade size

icom['avgSize_b_bk'] = icom.groupby('datadate')['avgSize_b'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['avgSize_b_bk'], 'avgSize_b') # random
icom['avgSize_b_dv_s'] = icom['avgSize_b'].divide(icom['avgSize_s'])
icom['avgSize_b_dv_s_bk'] = icom.groupby('datadate')['avgSize_b_dv_s'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['avgSize_b_dv_s_bk'], 'avgSize_b_dv_s') # random, top decile 4bp with good t
icom['avgSize_b_dv_s_orth'] = icom.groupby('datadate')[COLS+['avgSize_b_dv_s']].apply(lambda x: yu.orthogonalize_cn(x['avgSize_b_dv_s'
], x[COLS])).values
icom['avgSize_b_dv_s_orth_bk'] = icom.groupby('datadate')['avgSize_b_dv_s_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['avgSize_b_dv_s_orth_bk'], 'avgSize_b_dv_s_orth') # -1.5 +0.5 +1 +3.5
icom['avgSize_b_rk'] = icom.groupby('datadate')['avgSize_b'].apply(yu.uniformed_rank).values
icom['avgSize_s_rk'] = icom.groupby('datadate')['avgSize_s'].apply(yu.uniformed_rank).values
icom['avgSize_bs_rkdf'] = icom['avgSize_b_rk'] - icom['avgSize_s_rk']
icom['avgSize_bs_rkdf_bk'] = icom.groupby('datadate')['avgSize_bs_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['avgSize_bs_rkdf_orth'] = icom.groupby('datadate')[COLS+['avgSize_bs_rkdf']].apply(lambda x: yu.orthogonalize_cn(x['avgSize_bs_rkdf'], x[COLS])).values
icom['avgSize_bs_rkdf_orth_bk'] = icom.groupby('datadate')['avgSize_bs_rkdf_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['avgSize_bs_rkdf_bk'], 'avgSize_bs_rkdf') # random 
# yu.create_cn_3x3(icom, ['avgSize_bs_rkdf_bk'], 'avgSize_bs_rkdf') # random


icom['avgSize_b_m_s_dv_pv'] = (icom['avgSize_b']-icom['avgSize_s']).divide(icom['PV_l1d'])
icom['avgSize_b_m_s_dv_pv_bk'] = icom.groupby('datadate')['avgSize_b_m_s_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['avgSize_b_m_s_dv_pv_bk'], 'avgSize_b_m_s_dv_pv') # random, top decile 6.5bp with good t
icom['avgSize_b_m_s_dv_avgpv'] = (icom['avgSize_b']-icom['avgSize_s']).divide(icom['avgPVadj'])
icom['avgSize_b_m_s_dv_avgpv_bk']  = icom.groupby('datadate')['avgSize_b_m_s_dv_avgpv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['avgSize_b_m_s_dv_avgpv_bk'], 'avgSize_b_m_s_dv_avgpv') # less mono: -2 +7
icom['avgSize_b_m_s_dv_mc'] = (icom['avgSize_b']-icom['avgSize_s']).divide(icom['MC_l1d'])
icom['avgSize_b_m_s_dv_mc_bk'] = icom.groupby('datadate')['avgSize_b_m_s_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['avgSize_b_m_s_dv_mc_orth'] = icom.groupby('datadate')[COLS+['avgSize_b_m_s_dv_mc']].apply(lambda x: yu.orthogonalize_cn(x['avgSize_b_m_s_dv_mc'], x[COLS])).values
icom['avgSize_b_m_s_dv_mc_orth_bk'] = icom.groupby('datadate')['avgSize_b_m_s_dv_mc_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['avgSize_b_m_s_dv_mc_bk'], 'avgSize_b_m_s_dv_mc') # less mono: -2 +5
# yu.create_cn_3x3(icom, ['avgSize_b_m_s_dv_mc_orth_bk'], 'avgSize_b_m_s_dv_mc_orth') # mono: -4 +3.5


icom['avgSize_b_m_s_dv_avgpv'] = (icom['avgSize_b']-icom['a
vgSize_s']).divide(icom['avgPVadj'])
icom['avgSize_b_m_s_dv_avgpv_orth'] = icom.groupby('datadate')[COLS+['avgSize_b_m_s_dv_avgpv']].apply(lambda x: yu.orthogonalize_cn(x['avgSize_b_m_s_dv_avgpv'], x[COLS])).values
icom['avgSize_b_m_s_dv_avgpv_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['avgSize_b_m_s_dv_avgpv_orth'].mean().values
icom['avgSize_b_m_s_dv_avgpv_orth_t20d_sgnl'] = icom.groupby('datadate')['avgSize_b_m_s_dv_avgpv_orth_t20d'].apply(yu.uniformed_rank).values
icom['avgSize_b_m_s_dv_avgpv_sgnl']  = icom.groupby('datadate')['avgSize_b_m_s_dv_avgpv'].apply(yu.uniformed_rank).values
icom['avgSize_b_m_s_dv_avgpv_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['avgSize_b_m_s_dv_avgpv'].mean().values
icom['avgSize_b_m_s_dv_avgpv_t20d_sgnl'] = icom.groupby('datadate')['avgSize_b_m_s_dv_avgpv_t20d'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['avgSize_b_m_s_dv_avgpv_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'avgSize_b_m_s_dv_avgpv_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #1.97 / 1.18



### buy sell trade size - auction
# auction is better than O C and others

icom['avgSize_auc_b_m_s_dv_avgpv'] = (icom['avgSize_b_auc']-icom['avgSize_s_auc']).divide(icom['avgPVadj'])
icom['avgSize_auc_b_m_s_dv_avgpv_bk']  = icom.groupby('datadate')['avgSize_auc_b_m_s_dv_avgpv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['avgSize_auc_b_m_s_dv_avgpv_orth'] = icom.groupby('datadate')[COLS+['avgSize_auc_b_m_s_dv_avgpv']].apply(lambda x: yu.orthogonalize_cn(x['avgSize_auc_b_m_s_dv_avgpv'], x[COLS])).values
icom['avgSize_auc_b_m_s_dv_avgpv_orth_bk'] = icom.groupby('datadate')['avgSize_auc_b_m_s_dv_avgpv_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

#yu.create_cn_3x3(icom, ['avgSize_auc_b_m_s_dv_avgpv_bk'], 'avgSize_auc_b_m_s_dv_avgpv') # less mono: -3 +8
#yu.create_cn_3x3(icom, ['avgSize_auc_b_m_s_dv_avgpv_orth_bk'], 'avgSize_auc_b_m_s_dv_avgpv_orth') # less mono: -2 +6.5

icom['avgSize_auc_b_m_s_dv_mc'] = (icom['avgSize_b_auc']-icom['avgSize_s_auc']).divide(icom['MC_l1d'])
icom['avgSize_auc_b_m_s_dv_mc_bk']  = icom.groupby('datadate')['avgSize_auc_b_m_s_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['avgSize_auc_b_m_s_dv_mc_orth'] = icom.groupby('datadate')[COLS+['avgSize_auc_b_m_s_dv_mc']].apply(lambda x: yu.orthogonalize_cn(x[
'avgSize_auc_b_m_s_dv_mc'], x[COLS])).values
icom['avgSize_auc_b_m_s_dv_mc_orth_sgnl'] = icom.groupby('datadate')['avgSize_auc_b_m_s_dv_mc_orth'].apply(yu.uniformed_rank).values
icom['avgSize_auc_b_m_s_dv_mc_orth_bk'] = icom.groupby('datadate')['avgSize_auc_b_m_s_dv_mc_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['avgSize_auc_b_m_s_dv_mc_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=20),on='datadate')['avgSize_auc_b_m_s_dv_mc_orth_sgnl'].mean().values
icom['avgSize_auc_b_m_s_dv_mc_orth_t20d_sgnl'] = icom.groupby('datadate')['avgSize_auc_b_m_s_dv_mc_orth_t20d'].apply(yu.uniformed_rank).values

#yu.create_cn_3x3(icom, ['avgSize_auc_b_m_s_dv_mc_bk'], 'avgSize_auc_b_m_s_dv_mc') # mono: -3 +6
#yu.create_cn_3x3(icom, ['avgSize_auc_b_m_s_dv_mc_orth_bk'], 'avgSize_auc_b_m_s_dv_mc_orth') #mono: -4 +6

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['avgSize_auc_b_m_s_dv_mc_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'avgSize_auc_b_m_s_dv_mc_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.21 / -21

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['avgSize_auc_b_m_s_dv_mc_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'avgSize_auc_b_m_s_dv_mc_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.61 / -1.66



### buy sell trade size - auction & o2c

icom['avgSize_auc_b_m_s_dv_mc'] = (icom['avgSize_b_auc']-icom['avgSize_s_auc']).divide(icom['MC_l1d'])
icom['avgSize_auc_b_m_s_dv_mc_orth'] = icom.groupby('datadate')[COLS+['avgSize_auc_b_m_s_dv_mc']].apply(lambda x: yu.orthogonalize_cn(x['avgSize_auc_b_m_s_dv_mc'], x[COLS])).values
icom['avgSize_auc_b_m_s_dv_mc_orth_sgnl'] = icom.groupby('datadate')['avgSize_auc_b_m_s_dv_mc_orth'].apply(yu.uniformed_rank).values
icom['avgSize_auc_b_m_s_dv_mc_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['avgSize_auc_b_m_s_dv_mc_orth_sgnl'].mean().values
icom['avgSize_auc_b_m_s_dv_mc_orth_t20d_sgnl'] = icom.groupby('datadate')['avgSize_auc_b_m_s_dv_mc_orth_t20d'].apply(yu.uniformed_rank).values

icom['adjret_o_c_t40d_rk'] = icom.groupby('datadate')['adjret_o_c_t40d'].apply(yu.uniformed_rank).values

icom['size_o2c_rkdf'] = icom['avgSize_auc_b_m_s_dv_mc_orth_t40d_sgnl'] - icom['adjret_o_c_t40d_rk']
icom['size_o2c_rkdf_bk'] = icom.groupby('datadate')['size_o2c_rkdf'].apply
(lambda x: yu.pdqcut(x,bins=10)).values
icom['size_o2c_rkdf_sgnl'] = icom.groupby('datadate')['size_o2c_rkdf'].apply(yu.uniformed_rank).values
icom['size_o2c_rkdf_sgnl_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['size_o2c_rkdf_sgnl'].mean().values
#yu.create_cn_3x3(icom, ['size_o2c_rkdf_bk'], 'size_o2c_rkdf') # mono: -6 +4

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['size_o2c_rkdf_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'size_o2c_rkdf_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.13/0.02

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['size_o2c_rkdf_sgnl_t20d','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'size_o2c_rkdf_sgnl_t20d','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.73/1.85


icom['size_o2c_sgnl2'] = np.nan
c1 = (icom['avgSize_auc_b_m_s_dv_mc_orth_t40d_sgnl']>0.8) & (icom['adjret_o_c_t40d_rk']<-0.8)
icom.loc[c1, 'size_o2c_sgnl2'] = 1
icom['size_o2c_sgnl2'] = icom.groupby('ticker')['size_o2c_sgnl2'].ffill(limit = 40)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['size_o2c_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'size_o2c_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.74 / 0.34


### the KY idea

s_ky = []

for dt in pd.date_range(start='2017-05-01', end = '2020-12-31'):
    print(dt.strftime('%Y%m%d'),end=',')
    
    tcom = icom[(icom['datadate']<=dt) & (icom['datadate']>=dt-pd.to_timedelta('60 days'))]
    tcom_data_cnt = tcom.groupby('ticker')['V_l1d'].apply(lambda x: x.notnull().sum())
    tcom_data_cnt = tcom_data_cnt[tcom_data_cnt>=20]
    
    tcom = tcom[tcom['ticker'].isin(tcom_data_cnt.index.tolist())]
    tcom = tcom.sort_values(['ticker', 'datadate'])
    tcom = tcom.groupby('ticker').tail(20)
    tcom['daily_rank'] = tcom.groupby('ticker')['avgSize_b_auc'].rank().values
    tcom.loc[tcom['daily_rank']<=10, 'daily_binary_rank'] = 1
    tcom.loc[tcom['daily_rank']>10, 'daily_binary_rank'] = 2
    
    s_com = tcom.groupby(['ticker', 'daily_binary_rank'])['adjret_o_c'].mean().reset_index()
    s_com = s_com.pivot_table(index='ticker', columns = 'daily_binary_rank', values = ['adjret_o_c'])
    s_com = s_com.reset_index()
    s_com.columns = ['ticker', 'ret_low_b_size', 'ret_high_b_size']
    s_com['datadate'] = dt
    
    s_ky.a
ppend(s_com)
    
s_ky = pd.concat(s_ky, axis = 0)

icom2 = i_sd.merge(s_ky, on = ['ticker', 'datadate'], how = 'left')
icom2['ret_df'] = icom2['ret_high_b_size'] - icom2['ret_low_b_size'] 
icom2['ret_df_bk'] = icom2.groupby('datadate')['ret_df'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom2, ['ret_df_bk'], 'ret_df')
    

