﻿#$%^&* pFDMTL_cn_ciq_ni.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 24 06:58:32 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw




### sd

i_sd_ss = pw.get_china_ss_sd()

i_sd = pw.get_ashare_t2000_sd()



### get ciq data 



str_sql = ['''((a.ni_ttm - a.ni_ttm_l1q) / a.ta_qtr_l1q) / 
                ( nullif( abs ((a.ni_ttm_l1q - a.ni_ttm_l2q) / a.{0}_l2q) +  
                          abs ((a.ni_ttm_l2q - a.ni_ttm_l3q) / a.{0}_l3q) +  
                          abs ((a.ni_ttm_l3q - a.ni_ttm_l4q) / a.{0}_l4q) + 
                          abs ((a.ni_ttm_l4q - a.ni_ttm_l5q) / a.{0}_l5q) +  
                          abs ((a.ni_ttm_l5q - a.ni_ttm_l6q) / a.{0}_l6q) +  
                          abs ((a.ni_ttm_l6q - a.ni_ttm_l7q) / a.{0}_l7q) +  
                          abs ((a.ni_ttm_l7q - a.ni_ttm_l8q) / a.{0}_l8q) +  
                          abs ((a.ni_ttm_l8q - a.ni_ttm_l9q) / a.{0}_l9q) ,0 ) / 8) 
              as ni_0qoq_dv_{0}_nm'''.format(base) for base in ['ta_qtr', 'ni_ttm']]
              
str_sql = ",".join(str_sql)


### daily metrics 

i_ciq = []

for dt in pd.date_range(start = '2017-01-01', end = '2021-06-01'):
    print(dt.strftime('%Y%m%d'), end = ',')
        
    dt_cn_0900 = dt + pd.to_timedelta('9 hours')
    dt_utc_0900 = pd.to_datetime(dt_cn_0900).tz_localize('Asia/Shanghai').tz_convert('UTC').tz_localize(None)
    dt_utc_0900_str = dt_utc_0900.strftime('%Y-%m-%d %H:%M:%S')
    
    tdata = yu.get_sql('''                       
                       with maxdd as (
                               select Ticker, max(sourceDate) as maxdate
                               from [CNDBPROD].[dbo].[CIQ_CN]
                               where sourceDate <= '{0}'
                               group by Ticker
                       )
                       select a.Ticker, {1}
                       from [CNDBPROD].[dbo].[CIQ_CN] a
                       inner join maxdd
                       on a.Ticker = maxdd.Ticker and a.sourceDate = maxdd.maxdate
                       '''.format(dt_utc_0900_str, str_sql))
    tdata['DataDate'] = dt
    i_ciq.append(tdata)
    
    
i_ciq = pd.concat(i_ciq, axis = 0)
c_sh = i_ciq['Ticker'].str[0].isin(['6'])
c_sz = i_ciq['Ticker'].str[0].isin(['0', '3'])
i_ciq.loc[c_sh, 'ticker'] = i_ciq.loc[c_sh, 'Ticker'] + '.SH'
i_ciq.loc[c_sz, 'ticker'] = i_ciq.loc[c_sz, 'Ticker'] + '.SZ'
i_ciq = i_ciq.drop(columns = 'Ticker')
i_ciq = 
i_ciq.rename(columns = {'DataDate': 'datadate_p1d'})


# output



### combine

icom = i_sd.merge(i_ciq, on = ['ticker', 'datadate_p1d'], how = 'left')

cols = [c for c in i_ciq.columns.tolist() if not c in ['ticker', 'datadate_p1d']]
for c in cols:
    icom[c+'_bk'] = icom.groupby('datadate')[c].apply(lambda x: yu.pdqcut(x,bins=10)).values
    print(c)
    yu.create_cn_3x3(icom, [c+'_bk'], c)
    

icom['ni_0qoq_dv_ta_nm_rk'] = icom.groupby('datadate')['ni_0qoq_dv_ta_nm'].apply(yu.uniformed_rank)
icom['ni_0qoq_dv_ni_ttm_nm_rk'] = icom.groupby('datadate')['ni_0qoq_dv_ni_ttm_nm'].apply(yu.uniformed_rank)



o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-01-01','2021-12-30'))].\
            dropna(subset=['ni_0qoq_dv_ta_nm_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ni_0qoq_dv_ta_nm_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-01-01','2021-12-30'))].\
            dropna(subset=['ni_0qoq_dv_ni_ttm_nm_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ni_0qoq_dv_ni_ttm_nm_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)
