﻿#$%^&* featurepool_enrich_cn_SYNC_1p8k_inspection_daily_agg.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Apr 29 06:02:01 2023

@author: thzhang
"""

import pandas as pd
import os



### identify dates

root = '/dat/summit_capital/TZ/PROD_FEATURES_ENRICH/1p8K_inspection/'
feats = os.listdir(root)

files = []
for feat in feats:
    t_files = os.listdir(root + feat)
    files.extend(t_files)
files = pd.Series(files).unique().tolist()


### identify dates to query

existing_dates = os.listdir('/dat/summit_capital/TZ/PROD_FEATURES_ENRICH/1p8K_inspection_daily_agg/')
dates_to_query = [i for i in files if i not in existing_dates]

### get data

for dt in dates_to_query:
    t_daily_data = pd.DataFrame(columns = ['Ticker', 'DataDate', 'T-1d'])
    t_daily_data['DataDate'] = pd.to_datetime(t_daily_data['DataDate'])
    t_daily_data['T-1d'] = pd.to_datetime(t_daily_data['T-1d'])
    for ft in feats:
        try:
            t_data = pd.read_parquet(root + ft + '/' + dt)    
            t_daily_data = t_daily_data.merge(t_data, on = ['Ticker', 'DataDate', 'T-1d'], how = 'outer')            
        except:
            if '_nb_' in ft:
                continue
            else:
                raise Exception('missing date: '+ ft + ' ' + dt)
    
    #print(dt, end=': ')
    #print(t_daily_data.shape[1], end=',')
    root2 = '/dat/summit_capital/TZ/PROD_FEATURES_ENRICH/1p8K_inspection_daily_agg/'
    t_daily_data.to_parquet(root2 + dt)
        
        
        
    
