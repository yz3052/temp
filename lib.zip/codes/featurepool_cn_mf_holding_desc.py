﻿#$%^&* featurepool_cn_mf_holding_desc.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  7 10:00:55 2022

@author: thzhang
"""




import pandas as pd
import numpy as np

import os

import datetime

from sqlalchemy import create_engine
import urllib
import pyodbc


# to be scheduled on crontab at 5 am



#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------

save_path = '/export/dataprod/Feature_Pool_CN/featurepool_desc_mf_holding'

conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
conn_wind = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=WIND_PROD;UID=svc_wind_dbo;PWD=DusONA3Habredl;TDS_Version=8.0;')

today = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
today = pd.to_datetime(today.date())
today_str = today.strftime('%Y%m%d')




#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------

i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()



#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------

dates_existing = os.listdir(save_path)
dates_existing = [i.replace('.parquet','').replace('.','') for i in dates_existing]

dates_avail = i_cal[i_cal['T-1d'].lt(today) & i_cal['T-1d'].ge('2017-01-01')]
dates_avail['yyyymmdd'] = dates_avail['T-1d'].dt.strftime('%Y%m%d')

dates_to_query = dates_avail[~dates_avail['yyyymmdd'].isin(dates_existing)]
dates_to_query = dates_to_query.sort_values('T-1d')









#------------------------------------------------------------------------------
### query and calculate metrics
#------------------------------------------------------------------------------


for i, r in dates_to_query.iterrows():
    
    t_1d_str = r['T-1d'].strftime('%Y%m%d')


    # =====================
========================================================
    # get MF desc
    # =============================================================================
    
    sql = '''select a.f_info_windcode as ticker_fund, 
                    a.f_info_setupdate as start_date, 
                    a.f_info_maturitydate as end_date, 
                    b.s_info_compcode,
                    a.f_info_firstinvesttype as style 
             from wind.dbo.ChinaMutualFundDescription a
             left join wind.dbo.WINDCUSTOMCODE b 
             on a.f_info_windcode = b.S_INFO_WINDCODE
          '''
    i_mf_desc = pd.read_sql(sql, conn_wind)
    
    # format    
    
    i_mf_desc['start_date'] = i_mf_desc['start_date'].fillna('19900101')
    i_mf_desc['start_date'] = pd.to_datetime(i_mf_desc['start_date'], format='%Y%m%d')
    i_mf_desc['end_date'] = i_mf_desc['end_date'].fillna('20500101')
    i_mf_desc['end_date'] = pd.to_datetime(i_mf_desc['end_date'], format='%Y%m%d')
    i_mf_desc.loc[i_mf_desc['style'].isin(['股票型','混合型','另类投资型']), 'flag_isactive'] = 1
    
    # select operating active funds
    
    i_mf_desc = i_mf_desc[(i_mf_desc['start_date']<=r['T-1d'])&(i_mf_desc['end_date']>=r['T-1d'])]
    i_mf_desc = i_mf_desc[i_mf_desc['flag_isactive']==1]
    
    lst_active_op_comp = i_mf_desc['s_info_compcode'].dropna().unique().tolist()
    


    # =============================================================================
    # get SO
    # =============================================================================
    
    
    sql = '''select s_info_windcode as ticker, FLOAT_A_SHR_TODAY*10000 as so 
             from WIND_PROD.dbo.AShareEODDerivativeIndicator
    		 where ((s_info_windcode like '%SH') or (s_info_windcode like '%SZ'))
             and trade_dt = '{0}'  '''.format(t_1d_str)
    i_so = pd.read_sql(sql,conn_wind)
           
    

    # =============================================================================
    # estimate MF holding
    # =============================================================================
    
    # sometimes 2Q/4Q full holding is disclosed in 2 ann dates
        
    
    # get most recent full disclosure, per compcode
    
    sql = '''with t1y_full_compcode_tickerfund as (
                  select b.s_info_compcode, 
                          a.s_info_windcode, 
                          a.F_PRT_ENDDATE
                  from wind_prod.dbo.ChinaMutualFundStockPortfolio a
                  inner join win
d_prod.dbo.windcustomcode b
                  on a.s_info_windcode = b.s_info_windcode
                  where a.ann_date <= '{0}' and a.ann_date >= '{1}'
                        and b.s_info_compcode in ('{2}') 
                  group by b.s_info_compcode, a.s_info_windcode, a.F_PRT_ENDDATE
                  having sum(a.stock_per)>98.0 ),
              latest_reportperiod_compcode as (
                  select s_info_compcode, max(f_prt_enddate) as f_prt_enddate
                  from t1y_full_compcode_tickerfund
                  group by s_info_compcode),
              latest_full_compcode_tickerfund as (
                  select a.s_info_compcode, a.f_prt_enddate, max(a.s_info_windcode) as s_info_windcode 
                  from t1y_full_compcode_tickerfund a 
                  inner join latest_reportperiod_compcode b
                  on a.s_info_compcode = b.s_info_compcode
                      and a.f_prt_enddate = b.f_prt_enddate
                  group by a.s_info_compcode, a.f_prt_enddate )
              select b.s_info_compcode,
                    a.s_info_windcode as ticker_fund, 
                    a.s_info_stockwindcode as ticker,
                    a.f_prt_enddate as report_period,
                    a.f_prt_stkvalue as held_dollar,
                    a.f_prt_stkquantity as held_shares,
                    a.stock_per 
              from wind_prod.dbo.ChinaMutualFundStockPortfolio a             
              inner join latest_full_compcode_tickerfund b
              on a.F_PRT_ENDDATE = b.F_PRT_ENDDATE
                and a.s_info_windcode = b.s_info_windcode
              where a.ann_date <= '{0}'
            '''.format(t_1d_str, 
                       (r['T-1d']-pd.to_timedelta('365 days')).strftime('%Y%m%d'), 
                       "','".join(lst_active_op_comp))
    
    i_h_full = pd.read_sql(sql, conn_wind)
    i_h_full['flg'] = 'full'
    
    i_h_full_keys = i_h_full[['s_info_compcode','report_period']].drop_duplicates()
    i_h_full_keys.columns = ['s_info_compcode', 'report_period_full']
    
    # get most recent disclosure, per compcode
    
    sql = '''with lastest_reportperiod_compcode_tickerfund as ( 
                  select b.s_info_compcode, 
                        a.s_info_windcode, 
                        max(a.F_PRT_ENDDATE) as report_period
                  from wind_prod.dbo.ChinaMutualFundStockPortfolio a
                  inner join wind_prod.dbo.windcustomcode b
                  on a.s_info_windcode
 = b.s_info_windcode
                  where a.ann_date <= '{0}' and a.ann_date >= '{1}'
                      and b.s_info_compcode in ('{2}')
                  group by b.s_info_compcode, a.s_info_windcode),
              lastest_reportperiod_compcode as (
                  select s_info_compcode, max(report_period) as report_period
                  from lastest_reportperiod_compcode_tickerfund
                  group by s_info_compcode),
              latest_reportperiod_tickerfund as (
                  select a.s_info_compcode, a.report_period, max(a.s_info_windcode) as s_info_windcode
                  from lastest_reportperiod_compcode_tickerfund a
                  inner join lastest_reportperiod_compcode b
                  on a.s_info_compcode = b.s_info_compcode
                    and a.report_period = b.report_period 
                  group by a.s_info_compcode, a.report_period)
              select b.s_info_compcode, 
                    a.s_info_windcode as ticker_fund,
                    a.s_info_stockwindcode as ticker,
                    a.f_prt_enddate as report_period,
                    a.f_prt_stkvalue as held_dollar,
                    a.f_prt_stkquantity as held_shares,
                    a.stock_per 
              from wind_prod.dbo.ChinaMutualFundStockPortfolio a
              inner join latest_reportperiod_tickerfund b
              on a.s_info_windcode = b.s_info_windcode
                  and a.f_prt_enddate = b.report_period     
              where a.ann_date <= '{0}'
              '''.format(t_1d_str, 
                       (r['T-1d']-pd.to_timedelta('365 days')).strftime('%Y%m%d'), 
                       "','".join(lst_active_op_comp))
    
    i_h_latest = pd.read_sql(sql, conn_wind)    
    i_h_latest['flg'] = 'latest'
    
    i_h_latest = i_h_latest.merge(i_h_full_keys, on = 's_info_compcode', how = 'left')
    i_h_latest = i_h_latest[i_h_latest['report_period']>i_h_latest['report_period_full']]
    i_h_latest = i_h_latest.drop(columns = ['report_period_full'])
    
    
    # combine full and latest
    
    i_h_com = i_h_full.append(i_h_latest, ignore_index=True)
    i_h_com = i_h_com.sort_values(['s_info_compcode','ticker','report_period'])
    i_h_com = i_h_com.drop_duplicates(subset = ['s_info_compcode','ticker'], keep = 'last')
    
    # merge so 
    
    i_h_com = i_h_com.merge(i_so, on = 'ticker', how = 'left')
    i_h_com['mf_active_pctOfSO'] = i_h_com['held_shares'].divide(i_h_com['so'])
    i_h_com
['Ticker'] = i_h_com['ticker'].str[:6]
    
    s_h_com = i_h_com.groupby('Ticker')['mf_active_pctOfSO'].sum().reset_index()
    
    
    
    
    # =============================================================================
    # output
    # =============================================================================
    
    i_dtk = pd.read_sql('''select datadate as [T-1d], ticker as Ticker
                        from cndbprod.dbo.universe_all_cn_gem3l 
                        with (nolock)
                        where datadate = '{0}' 
                        '''.format(t_1d_str), conn)
    i_dtk = i_dtk.drop_duplicates(subset = ['T-1d', 'Ticker'], keep = 'last')
    
    
    icom = i_dtk.merge(s_h_com, on = ['Ticker'], how = 'left')
    icom['mf_active_pctOfSO'] = icom['mf_active_pctOfSO'].fillna(0)
    icom = icom.merge(i_cal, on = 'T-1d', how = 'left')
    
    file_name = r['T-1d'].strftime('%Y.%m.%d.parquet')
    icom[['T-1d', 'DataDate', 'Ticker', 'mf_active_pctOfSO']].to_parquet(os.path.join(save_path, file_name))
    
    os.system("chgrp summit_thzhang "+os.path.join(save_path, file_name)+";")
    os.system("chmod 770 "+os.path.join(save_path, file_name)+";")
    

    
        

