﻿#$%^&* pFlow_cn_epfr_etl.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 31 16:17:19 2022

@author: thzhang
"""


import pandas as pd

from datetime import datetime

import os
import gc



### Security Menu (ticker mapping)

root_sm = '/dat/mdwarehouse/public/EPFR/Stock_Flow_20220701/history/SecurityMenu/Daily'

o_sm = []
for f in os.listdir(root_sm):
    if f >= 'SecurityMenuDaily201701.txt':
        tdata = pd.read_csv(os.path.join(root_sm, f), sep = '\t')        
        tdata = tdata[tdata['Ticker'].notnull() & tdata['Ticker'].str.contains(':CS|:CG|:C1|:C2')]        
        tdata = tdata[['ReportDate', 'Ticker', 'HSecurityId']]
        print('.',end='')
        o_sm.append(tdata)
        
o_sm = pd.concat(o_sm, axis=0)
o_sm['ReportDate'] = pd.to_datetime(o_sm['ReportDate'])
o_sm.to_parquet('/dat/summit_capital/TZ/EPFR/security_menu_daily.parquet')



### Fund Count - Active

root_fund_cnt_active = '/dat/mdwarehouse/public/EPFR/Stock_Flow_20220701/history/FundCount/Daily/Active'

o_fundcnt_active = []
for f in os.listdir(root_fund_cnt_active):
    if f >= 'FundCountBySecurityDailyAllActive201701.txt':
        tdata = pd.read_csv(os.path.join(root_fund_cnt_active, f), sep = '\t')      
        tdata['ReportDate'] = pd.to_datetime(tdata['ReportDate'])
        tdata = tdata.merge(o_sm, on = ['HSecurityId','ReportDate'], how = 'inner')        
        print('.',end='')
        o_fundcnt_active.append(tdata)
        
o_fundcnt_active = pd.concat(o_fundcnt_active, axis=0)
o_fundcnt_active.to_parquet('/dat/summit_capital/TZ/EPFR/fundcnt_active.parquet')



### Fund Count - Agg

root_fund_cnt_agg = '/dat/mdwarehouse/public/EPFR/Stock_Flow_20220701/history/FundCount/Daily/Aggregate'

o_fundcnt_agg = []
for f in os.listdir(root_fund_cnt_agg):
    if f >= 'FFundCountBySecurityDaily201701.txt':
        tdata = pd.read_csv(os.path.join(root_fund_cnt_agg, f), sep = '\t')    
        tdata['ReportDate'] = pd.to_datetime(tdata['ReportDate'])
        tdata = tdata.merge(o_sm, on = ['HSecurityId','ReportDate'], how = 'inner')        
        print('.',end='')
        o_fundcnt_agg.append(tdata)
        
o_fundcnt_agg = pd.concat(o_fundcnt_agg, axis=0)
o_fundcnt_agg.to_parquet('/dat/summit_capital/TZ/EPFR/fundcnt_agg.parquet')



### Fund Count - etf

root_fund_cnt_etf = '/dat/mdwarehouse/public/EPFR/Stock_Flow_20220701/history/FundCount/Daily/ETF'

o_fundcnt_etf = []
for f in os.listdir(root_fund_cnt_etf):
    if f >= 'FundCountBySecurityDailyAllETF201701.txt':

        tdata = pd.read_csv(os.path.join(root_fund_cnt_etf, f), sep = '\t')    
        tdata['ReportDate'] = pd.to_datetime(tdata['ReportDate'])
        tdata = tdata.merge(o_sm, on = ['HSecurityId','ReportDate'], how = 'inner')        
        print('.',end='')
        o_fundcnt_etf.append(tdata)
        
o_fundcnt_etf = pd.concat(o_fundcnt_etf, axis=0)
o_fundcnt_etf.to_parquet('/dat/summit_capital/TZ/EPFR/fundcnt_etf.parquet')




### Fund Count - mutual

root_fund_cnt_mutual = '/dat/mdwarehouse/public/EPFR/Stock_Flow_20220701/history/FundCount/Daily/Mutual'

o_fundcnt_mutual = []
for f in os.listdir(root_fund_cnt_mutual):
    if f >= 'FundCountBySecurityDailyAllMF201701.txt':
        tdata = pd.read_csv(os.path.join(root_fund_cnt_mutual, f), sep = '\t')      
        tdata['ReportDate'] = pd.to_datetime(tdata['ReportDate'])
        tdata = tdata.merge(o_sm, on = ['HSecurityId','ReportDate'], how = 'inner')        
        print('.',end='')
        o_fundcnt_mutual.append(tdata)
        
o_fundcnt_mutual = pd.concat(o_fundcnt_mutual, axis=0)
o_fundcnt_mutual.to_parquet('/dat/summit_capital/TZ/EPFR/fundcnt_mutual.parquet')




### Fund Count - passive

root_fund_cnt_passive = '/dat/mdwarehouse/public/EPFR/Stock_Flow_20220701/history/FundCount/Daily/Passive'

o_fundcnt_passive = []
for f in os.listdir(root_fund_cnt_passive):
    if f >= 'FundCountBySecurityDailyAllPassive201701.txt':
        tdata = pd.read_csv(os.path.join(root_fund_cnt_passive, f), sep = '\t')      
        tdata['ReportDate'] = pd.to_datetime(tdata['ReportDate'])
        tdata = tdata.merge(o_sm, on = ['HSecurityId','ReportDate'], how = 'inner')        
        print('.',end='')
        o_fundcnt_passive.append(tdata)
        
o_fundcnt_passive = pd.concat(o_fundcnt_passive, axis=0)
o_fundcnt_passive.to_parquet('/dat/summit_capital/TZ/EPFR/fundcnt_passive.parquet')




### Stock Flow - Active

root_stockflow_active = '/dat/mdwarehouse/public/EPFR/Stock_Flow_20220701/history/StockFlows/Daily/Active'

o_stockflow_active = []
for f in os.listdir(root_stockflow_active):
    if f >= 'Daily - StockFlowsDollar - SumProductAllActive - 201701.txt':
        tdata = pd.read_csv(os.path.join(root_stockflow_active, f), sep = '\t')      
        tdata['ReportDate'] = pd.to_datetime(tdata['ReportDate'])
        tdata = tdata.merge(o_sm, on = ['HSecurityId','ReportDate'], how = 'inner')        
        tdata = tdata.drop(columns = 'GeoIdSecurityId')
        print('.',end='')
        o_stockflow_activ
e.append(tdata)
        
o_stockflow_active = pd.concat(o_stockflow_active, axis=0)
o_stockflow_active.to_parquet('/dat/summit_capital/TZ/EPFR/stockflow_active.parquet')





### Stock Flow - agg

root_stockflow_agg = '/dat/mdwarehouse/public/EPFR/Stock_Flow_20220701/history/StockFlows/Daily/Aggregate'

o_stockflow_agg = []
for f in os.listdir(root_stockflow_agg):
    if f >= 'Daily - StockFlowsDollar - SumProduct - 201701.txt':
        tdata = pd.read_csv(os.path.join(root_stockflow_agg, f), sep = '\t')      
        tdata['ReportDate'] = pd.to_datetime(tdata['ReportDate'])
        tdata = tdata.merge(o_sm, on = ['HSecurityId','ReportDate'], how = 'inner')        
        print('.',end='')
        o_stockflow_agg.append(tdata)
        
o_stockflow_agg = pd.concat(o_stockflow_agg, axis=0)
o_stockflow_agg.to_parquet('/dat/summit_capital/TZ/EPFR/stockflow_agg.parquet')



### Stock Flow - etf

root_stockflow_etf = '/dat/mdwarehouse/public/EPFR/Stock_Flow_20220701/history/StockFlows/Daily/ETF'

o_stockflow_etf = []
for f in os.listdir(root_stockflow_etf):
    if f >= 'Daily - StockFlowsDollar - SumProductAllETF - 201701.txt':
        tdata = pd.read_csv(os.path.join(root_stockflow_etf, f), sep = '\t')
        tdata['ReportDate'] = pd.to_datetime(tdata['ReportDate'])
        tdata = tdata.merge(o_sm, on = ['HSecurityId','ReportDate'], how = 'inner')        
        tdata = tdata.drop(columns = 'GeoIdSecurityId')
        print('.',end='')
        o_stockflow_etf.append(tdata)
        
o_stockflow_etf = pd.concat(o_stockflow_etf, axis=0)
o_stockflow_etf.to_parquet('/dat/summit_capital/TZ/EPFR/stockflow_etf.parquet')



### Stock Flow - mutual

root_stockflow_mutual = '/dat/mdwarehouse/public/EPFR/Stock_Flow_20220701/history/StockFlows/Daily/Mutual'

o_stockflow_mutual = []
for f in os.listdir(root_stockflow_mutual):
    if f >= 'Daily - StockFlowsDollar - SumProductAllMF - 201701.txt':
        tdata = pd.read_csv(os.path.join(root_stockflow_mutual, f), sep = '\t')
        tdata['ReportDate'] = pd.to_datetime(tdata['ReportDate'])
        tdata = tdata.merge(o_sm, on = ['HSecurityId','ReportDate'], how = 'inner')        
        tdata = tdata.drop(columns = 'GeoIdSecurityId')
        print('.',end='')
        o_stockflow_mutual.append(tdata)
        
o_stockflow_mutual = pd.concat(o_stockflow_mutual, axis=0)
o_stockflow_mutual.to_parquet('/dat/summit_capital/TZ/EPFR/stockflow_mutual.parquet')



### Stock Flow - passive

root_stockflow_passive = '/dat/mdwarehouse/
public/EPFR/Stock_Flow_20220701/history/StockFlows/Daily/Passive'

o_stockflow_passive = []
for f in os.listdir(root_stockflow_passive):
    if f >= 'Daily - StockFlowsDollar - SumProductAllPassive - 201701.txt':
        tdata = pd.read_csv(os.path.join(root_stockflow_passive, f), sep = '\t')
        tdata['ReportDate'] = pd.to_datetime(tdata['ReportDate'])
        tdata = tdata.merge(o_sm, on = ['HSecurityId','ReportDate'], how = 'inner')        
        tdata = tdata.drop(columns = 'GeoIdSecurityId')
        print('.',end='')
        o_stockflow_passive.append(tdata)
        
o_stockflow_passive = pd.concat(o_stockflow_passive, axis=0)
o_stockflow_passive.to_parquet('/dat/summit_capital/TZ/EPFR/stockflow_passive.parquet')



