﻿#$%^&* pDataYes_recruit_sCache_3.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 31 10:19:20 2021

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import zipfile
import csv

import jieba

from snownlp import SnowNLP

from multiprocessing import Pool


# this is for ttm 51job title string data
# the goal is find jobs at T and jobs at t-12m, that are comparable to each other in terms of titles



### step 1: fetch title data

i_p = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet')

i_tk_str = pd.DataFrame()
for p in i_p:
    print(p)
    t_data = pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet', p),
                             columns = ['id','ticker_symbol','source','title','published_at'])
    
    t_data = t_data[t_data['source']=='51job']
    
    t_data = t_data[t_data['ticker_symbol'].notnull()]
    t_data = t_data[t_data['ticker_symbol'].str.contains('\d{6}')]
    c_sz = t_data['ticker_symbol'].str[0].isin(['0', '3'])
    c_sh = t_data['ticker_symbol'].str[0].isin(['6'])
    t_data.loc[c_sz, 'ticker'] = t_data.loc[c_sz, 'ticker_symbol'] + '.SZ'
    t_data.loc[c_sh, 'ticker'] = t_data.loc[c_sh, 'ticker_symbol'] + '.SH'
    t_data = t_data.drop(columns=['ticker_symbol'])
    
    
    t_data['datadate'] = pd.to_datetime(pd.to_datetime(t_data['published_at']) + pd.to_timedelta('1 day'))
    
    
    t_data['title2'] = t_data['title'].str.replace('\(.*\)','').str.replace('（.*）','').\
                 str.replace('\[.*\]','').str.replace('\【.*\】','').\
                 str.replace('\d[K|k|W|w|千|万]','').str.replace('\d','').\
                 str.replace('（|）|,|，|\.|。|:|：|;|；|\(|\)|\*|~|`|!|@|#|$|&|-|—|\+|\/|、|\?',' ').\
                 str.replace('职位编号','').\
                 str.strip().str.replace('[ ]+', ' ').\
                 str.upper()
    t_data = t_data[t_data['title2'].notnull() & (t_data['title2']!='')]
    t_data['title_seg'] = t_data['title2'].apply(lambda x: '@'.join(jieba.cut(x)))

    
    i_tk_str = i_tk_str.append(t_data, sort = False)

i_tk_str['title_seg'] = i_tk_str['title_seg'].apply(lambda x: set(x.split('@')))
i_tk_str[['id', 'source', 'datadate', 'title_seg', 'ticker']]


### step 2: calculate ttm title str segments
print('calculate ttm title str segments')

i_tk_t1y_seg = []
for dt in pd.date_range(start = '2017-01-01', end = '2021-06-30'):
    print('.', end='')
    t_str = i_tk_str[(i_tk_str['da
tadate']<=dt) & (i_tk_str['datadate']>=dt-pd.to_timedelta('365 days'))]

    t_seg = t_str.groupby('ticker')['title_seg'].\
            apply(lambda x: set(('@'.join(x.tolist())).split('@'))).reset_index()
    t_seg['datadate'] = dt
    
    i_tk_t1y_seg.append(t_seg)

i_tk_t1y_seg = pd.concat(i_tk_t1y_seg, axis=0)
i_tk_t1y_seg = i_tk_t1y_seg.rename(columns={'title_seg':'tite_segSet_51job'})


### step 3: determine the comparable jobs @T and @T-1y
print('determine the comparable jobs @T and @T-1y')


def helper8(title_seg_set, all51job_seg_set):
    if pd.isnull(all51job_seg_set):
        return np.nan
    else:
        if title_seg_set.issubset(all51job_seg_set):
            return 1
        else:
            return 0
    
o_compJobs_cnt = []


for dt in pd.date_range(start = '2017-01-01', end = '2021-06-30'):
    print('.', end='')
    
    # get raw data for T and T-1y
    t_tk_str_0 = i_tk_str[(i_tk_str['datadate']<=dt) & (i_tk_str['datadate']>=dt-pd.to_timedelta('365 days'))]
    t_tk_str_1 = i_tk_str[(i_tk_str['datadate']<(dt-pd.to_timedelta('365 days'))) & (i_tk_str['datadate']>=dt-pd.to_timedelta('730 days'))]
    
    # get ttm segSet from T-1y
    t_tk_t1y_seg_1 = i_tk_t1y_seg[i_tk_t1y_seg['datadate']==(dt-pd.to_timedelta('366 days'))]
    t_tk_t1y_seg_1 = t_tk_t1y_seg_1.drop(columns=['datadate'])
    
    if (len(t_tk_str_1)==0) or (len(t_tk_t1y_seg_1)==0):
        continue
    
    # merge segSet@T-1 into raw_data@T
    t_tk_str_0 = t_tk_str_0.merge(t_tk_t1y_seg_1.rename(columns={'tite_segSet_51job':'tite_segSet_51job_1y'}), on = 'ticker', how = 'left')
    
    # determine if jobs@T can be matched to jobs@T-1
    t_tk_str_0['flag_sameTile_toPast_51job'] = t_tk_str_0[['title_seg', 'tite_segSet_51job_1y']].\
                                        apply(lambda x: helper8(x['title_seg'],x['tite_segSet_51job_1y']), axis=1)
    
    t_tk_str_0_matchedTitleSeg = t_tk_str_0[t_tk_str_0['flag_sameTile_toPast_51job']==1].groupby('ticker')['title_seg'].\
                                 apply(lambda x: set.union(*x)).reset_index()
    t_tk_str_0_matchedTitleSeg = t_tk_str_0_matchedTitleSeg.rename(columns={'title_seg':'matchedTitleSeg_str'})
    
    # determine if jobs@T-1y can be matched to matchedJobs@T
    t_tk_str_1 = t_tk_str_1.merge(t_tk_str_0_matchedTitleSeg, on = 'ticker', how = 'left')
    t_tk_str_1['flag_sameTile_toFuture_51job'] = t_tk_str_1[['title_seg', 'matchedTitleSeg_str']].\
                                                 apply(lambda 
x: helper8(x['title_seg'],x['matchedTitleSeg_str']), axis=1)
    
    # summary stats
    o_sum = pd.concat([
            t_tk_str_0.groupby('ticker')['flag_sameTile_toPast_51job'].sum().rename(columns={'flag_sameTile_toPast_51job':'compJobCnt'}),
            t_tk_str_1.groupby('ticker')['flag_sameTile_toFuture_51job'].sum().rename(columns={'flag_sameTile_toFuture_51job':'compJobCnt_1y'})],
            axis=1).reset_index()
    o_sum['datadate'] = dt
    
    o_compJobs_cnt.append(o_sum)
    
o_compJobs_cnt = pd.concat(o_compJobs_cnt, axis=0)
o_compJobs_cnt = o_compJobs_cnt.rename(columns={0:'compJob_cnt_0y', 1:'compJob_cnt_1y','index':'ticker'})

o_compJobs_cnt.to_parquet(r'S:\Data\China Data Hunt\cache\pDataYes_recruit_sCache_3_comp_job_count.parquet')


### other data


### get sd
i_sd = pw.get_ashare_hk_sd_v2()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','a50_300_flag','a50_flag',
                 'GROWTH','LEVERAGE']]

i_sd_map_300 =i_sd_map[i_sd_map['a50_300_flag']==1]
i_sd_datadate_sr = i_sd_map_300['datadate'].drop_duplicates()
i_sd_map_hk  = i_sd_map[i_sd_map['isin_hk_uni']==1]

### mc

i_mc = yu.get_sql('''select ticker, datadate, mc from [CNDB].[dbo].[UNIVERSE_ALL_CN] 
                    where ticker in ('{0}') '''.format("','".join( i_sd_map['ticker'].str[:6].unique().tolist() )))
i_mc['datadate_1y'] = i_mc['datadate'] - pd.to_timedelta('365 days')
i_mc['datadate_1q'] = i_mc['datadate'] - pd.to_timedelta('91 days')


i_mc = i_mc.sort_values('datadate')

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1q', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1q'})

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1y', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1y'})
i_mc = i_mc.drop(columns = ['datadate_1q', 'datadate_1y'])


c_sh = i_mc['ticker'].str[0].isin(['6'])
c_sz = i_mc['ticker'].str[0].isin(['0', '3'])
i_mc.loc[c_sz, 'ticker'] = i_mc.loc[c_
sz, 'ticker'] + '.SZ'
i_mc.loc[c_sh, 'ticker'] = i_mc.loc[c_sh, 'ticker'] + '.SH'

###
icom = i_sd_map_300.merge(i_mc, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(o_compJobs_cnt, on = ['ticker','datadate'], how = 'left')

icom['compJob_df_dv_mc'] = (icom['compJob_cnt_0y'] - icom['compJob_cnt_1y']).divide(icom['mc_1y'])
icom['compJob_df_dv_mc_rk'] = icom.groupby('datadate')['compJob_df_dv_mc'].apply(yu.uniformed_rank).values

icom['growth_rk'] = -icom.groupby('datadate')['GROWTH'].apply(yu.uniformed_rank).values # higher = worse
icom['leverage_rk'] = icom.groupby('datadate')['LEVERAGE'].apply(yu.uniformed_rank).values # higher = worse

icom['sgnl'] = np.nan
icom.loc[icom['compJob_df_dv_mc_rk']>0.6, 'sgnl'] = 1
icom['sgnl2'] = icom.groupby('ticker')['sgnl'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-05-31')].\
            dropna(subset=['compJob_df_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'compJob_df_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.05/-0.47 // 0.59 / -0.31

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-05-31')].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.55 / 1.1 // 1.76 / 1.02


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-05-31')&(icom['growth_rk']<0) & (icom['leverage_rk']<0)].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.99/0.7 // 2.1 / 1.51 # this is worse than FINAL

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-05-31')].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # ?/? // 1.57 / 1.19
