﻿#$%^&* tr_06.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat May  9 16:06:10 2020
@author: tomyi
"""
import os
import inspect
from yz import get_sql, print_progress
from yz.util import pickle_bz_dump, pickle_bz_load

import pandas as pd
import numpy as np
from numba import njit, jit
from datetime import date, datetime

import statsmodels.api as sm
import cvxpy as cp

import pickle

import matplotlib.pyplot as plt

from bokeh.io import show
from bokeh.layouts import column, gridplot
from bokeh.models import ColumnDataSource, RangeTool, HoverTool, CustomJS, CrosshairTool, LinearAxis, Range1d
from bokeh.plotting import figure


class Backtest(object):
    
    def __init__(self, list_data_types, signals, str_from_ymd, str_to_ymd, bar_cache, uni = ''):
        
        #----------------------------------------------------------------------
        ### Format
        #----------------------------------------------------------------------
        # list_data_types ['raw','beta','barra','hedged','ed','pdufa','ta_macd','ta_reg','ta_boll']
        # str_from_ymd, str_to_ymd 'YYYY-MM-DD'
        
        print (str(datetime.now()) + ' - __init__ starts.')
        
        #----------------------------------------------------------------------
        ### dates and ticker
        #----------------------------------------------------------------------        
        
        # cdates
        if isinstance(str_from_ymd, str) & isinstance(str_to_ymd, str) &\
                        (len(str_from_ymd)==10) & (len(str_to_ymd)==10) &\
                        ('-' in str_from_ymd) & ('-' in str_to_ymd):
            self.cdates = pd.date_range(start=str_from_ymd, end=str_to_ymd).tolist()
        elif str_from_ymd == '' or str_from_ymd is None or str_to_ymd == '' or str_to_ymd is None:
            self.cdates = pd.date_range(start='2010-06-01', end='2019-11-10').tolist()
        else:
            raise Exception('Date format incorrect.')
        print ('cdates', end = ' ')
                
        # tk uni
        if uni == '':
            self.tk = ['ISRG','EW','NVRO','ABMD','PODD','NVCR','CDNA','DXCM','EXAS','XENT','GKOS','TCMD','TNDM','UTHR']
            SPY = pd.read_csv(r"N:\projects\backtester\PRODUCTION\SPX.csv")
            self.tk = SPY['Ticker'].str.split(' ').str[0].tolist()
            self.tk = ['EW','GKOS','NVRO','AGN','BMY','ABMD','PODD','NVCR','TCMD','TNDM','EXAS','XENT','UTHR','PCRX','ABBV','JAZZ','OMER','EXEL','AMAG']
            self.tk = ['AGN','BMY'
,'UTHR','PCRX','ABBV','JAZZ','OMER','EXEL','AMAG']
            self.tk = ['BMY','UTHR','PCRX','ABBV','EXEL','AMAG']
            self.tk = ['DXCM','CDNA','IRTC','ENTA','AMRN','ISRG','EW','GKOS','NVRO','AGN','BMY','ABMD','PODD','NVCR','TCMD','TNDM','EXAS','XENT','UTHR','PCRX','ABBV','JAZZ','OMER','EXEL','AMAG','BIIB']
            
            self.tk = ['ENTA','AMRN','AGN','BMY','UTHR','PCRX','ABBV','JAZZ','OMER','EXEL','AMAG','BIIB'] # pharma
            self.tk = ['DXCM','CDNA','IRTC','ENTA','AMRN','ISRG','EW','GKOS','NVRO','AGN','BMY','ABMD','PODD','NVCR','TCMD','TNDM','EXAS','XENT','UTHR','PCRX','ABBV','JAZZ','OMER','EXEL','AMAG','BIIB']
            self.tk = ['DXCM','ISRG','EW','NVCR','PODD','NVRO','BSX','XENT','ABMD','INCY'] # Modus  'IRTC','CDNA', 'TNDM' (tnmd makes too much money)
            
        else:
            self.tk = get_sql("select distinct ticker FROM [BackTest].[dbo].[F019_FUND]")['ticker'].tolist()
            
        
        print ('tk', end = ' ')
        #----------------------------------------------------------------------
        ### market data
        #----------------------------------------------------------------------
        
        # market data: cc, co
        if 'beta' in list_data_types:
            pass
        
        elif 'raw' in list_data_types:
            self.arr_cc_ret = self.ret_raw_c_c()
            self.arr_co_ret = self.ret_raw_c_o()
            
        elif 'barra' in list_data_types:
            self.arr_cc_ret = self.ret_barra_c_c()
            self.arr_co_ret = self.ret_barra_c_o()
        
        elif 'hedged' in list_data_types:
            pass
            
        print ('ret', end = ' ')
        
        # volume
        self.arr_vD = self.vD()
        if self.arr_vD.shape != self.arr_cc_ret.shape:
            raise Exception('Volume shape different from ret shape.')
        
        # price data
        self.pv_tdates_tk_p, self.pv_tdates_tk_h, self.pv_tdates_tk_l = self.p()
        
        self.arr_p = self.pv_tdates_tk_p.reindex(index = self.cdates, columns = self.tk).fillna(method = 'ffill').values
        self.arr_h = self.pv_tdates_tk_h.reindex(index = self.cdates, columns = self.tk).fillna(method = 'ffill').values
        self.arr_l = self.pv_tdates_tk_l.reindex(index = self.cdates, columns = self.tk).fillna(method = 'ffill').values
        
        print('v p', end = ' ')
        
        # barra price 
        self.pv_barra_p = pd.DataFrame(self.arr_cc_ret, index = self.cdates, co
lumns = self.tk).\
                        reindex(index = self.pv_tdates_tk_p.index)
        self.pv_barra_p = (self.pv_barra_p+1).cumprod()
        
        
        #----------------------------------------------------------------------
        ### technical indicator
        #----------------------------------------------------------------------
        
        if 'ta_macd' in list_data_types:
            self.arr_macd,self.arr_sig, self.arr_diff = self.ta_macd(self.pv_barra_p)
            print('macd', end = ' ')
        
        if 'ta_boll' in list_data_types:
            self.arr_boll_u, self.arr_boll_l, self.arr_boll_index = self.ta_boll(self.pv_barra_p)
            print('boll', end = ' ')
        
        if 'ta_reg' in list_data_types:
            self.arr_reg_param, self.arr_reg_r2 = self.ta_strong_trend(self.pv_barra_p)
            print('reg', end = ' ')
            
        #----------------------------------------------------------------------
        ### first bar
        #----------------------------------------------------------------------        

        if bar_cache is None or bar_cache == '':
            self.first_bar = 30
        elif not isinstance(bar_cache, int):
            raise Exception('bar_cache must be an int.')
        else:
            self.first_bar = bar_cache

        #----------------------------------------------------------------------
        ### signals
        #----------------------------------------------------------------------

        if isinstance(signals, pd.DataFrame):
            self.pv_signals = signals.copy()
        elif isinstance(signals, str):
            self.pv_signals = pd.read_parquet(signals)
        else:
            raise Exception('Signal type error.')
            
        if 'score' in '@'.join(signals.columns.tolist()):
            t_date_col = [i for i in self.pv_signals.columns.tolist() if 'date' in i.lower()][0]
            t_tk_col = [i for i in self.pv_signals.columns.tolist() if 'ticker' in i.lower()][0]
            t_score_col = [i for i in self.pv_signals.columns.tolist() if 'score' in i.lower()][0]
            self.pv_signals[t_date_col] = pd.to_datetime(self.pv_signals[t_date_col])
            self.pv_signals = self.pv_signals.pivot_table(index = t_date_col, columns = t_tk_col, values = t_score_col)
        else:
            pass
        
        self.arr_signals = self.pv_signals.reindex(index = self.cdates, columns = self.tk).values
        self.arr_signals = np.nan_to_n
um(self.arr_signals)
        self.arr_signals = np.where(self.arr_signals>3,3,self.arr_signals)
        self.arr_signals = np.where(self.arr_signals<-3,-3,self.arr_signals)
        print('signals', end = ' ')
        
        #----------------------------------------------------------------------
        ### business days to earnings
        #----------------------------------------------------------------------
        if 'ed' in list_data_types:
            self.arr_bd2e = self.ed_bd_2_earning()
            print('bd2e', end = ' ')
       
        #----------------------------------------------------------------------
        ### earning result
        #----------------------------------------------------------------------
        if 'edresult' in list_data_types:
            self.arr_ed_result = self.ed_result()
            print('edresult', end = ' ')
       
        
        
        #----------------------------------------------------------------------
        ### pdufa
        #----------------------------------------------------------------------
        if 'pdufa' in list_data_types:
            self.arr_pdufa = self.pdufa()
            print('pdufa', end = ' ')        
        
        #----------------------------------------------------------------------
        ### strategy
        #----------------------------------------------------------------------


        # strat variables        
        self.arr_pstD_bo = self.h_create_zero_arr()
        self.arr_pstD_bc = self.h_create_zero_arr()
        self.pv_pstS_bo = self.h_create_zero_arr()
        self.pv_pstS_bc = self.h_create_zero_arr()
        
        self.arr_ordD_unfilled = self.h_create_zero_arr()
        
        self.arr_ordD_bo = self.h_create_zero_arr()
        self.arr_ordD_bc = self.h_create_zero_arr()
        self.pv_ordS_bo = self.h_create_zero_arr()
        self.pv_ordS_bc = self.h_create_zero_arr()
        self.pv_ordPct_bo = self.h_create_zero_arr()
        self.pv_ordPct_bc = self.h_create_zero_arr()
        
        self.arr_pnlD = self.h_create_zero_arr()
        
        self.arr_barsheld_since_pst_open = self.h_create_zero_arr() - 1
        self.arr_tbarsheld_since_pst_open = self.h_create_zero_arr() - 1
        
        self.arr_tbar_unfilled_ord = self.h_create_zero_arr()
        self.arr_cbar_unfilled_ord = self.h_create_zero_arr()
        
        self.arr_curr_pst_pnlD = self.h_create_zero_arr()
        
        self.vc_vD_quota = self.h_create_zero_vc()
        s
elf.vc_ones = self.h_create_zero_vc() + 1
        
        # state matrix
        self.dic_state = {}
        
        #----------------------------------------------------------------------
        ### reporting
        #----------------------------------------------------------------------  
        
        self.dic_report = {}
        
        print ('\n' + str(datetime.now()) + ' - Initiation done.')
        
    def h_create_zero_pv(self):
        t0 = np.zeros([len(self.cdates),len(self.tk)])
        return pd.DataFrame(t0, index = self.cdates, columns = self.tk)
    def h_create_zero_arr(self):
        return np.zeros([len(self.cdates),len(self.tk)])
    def h_create_zero_vc(self):
        t0 = np.zeros(len(self.tk))
        return t0
    
    @staticmethod
    @jit(forceobj=True)
    def h_last_nonzero(arr, axis, invalid_val):
        mask = arr!=0
        val = arr.shape[axis] - np.flip(mask, axis=axis).argmax(axis=axis) - 1
        pst = np.where(mask.any(axis=axis), val, invalid_val)
        return arr[pst,list(range(arr.shape[1-axis]))]
    
    def ret_barra_c_c(self):
        if os.path.exists(r"S:\Infrastructure\backtester\PRODUCTION\ret_barra_c_c.parquet"):
            ibarra_pivot = pd.read_parquet(r"S:\Infrastructure\backtester\PRODUCTION\ret_barra_c_c.parquet", columns = self.tk)
        else:
            ibarra = get_sql("select datadate, Ticker, ret_barra_omega_adj from [BackTest].[dbo].[BARRA_Ret_Daily] where Ticker in {0}".\
                             format(str(tuple(self.tk)) if len(self.tk)>1 else "('"+self.tk[0]+"')") )
            ibarra_pivot = ibarra.pivot_table(index='datadate', columns = 'Ticker', values = 'ret_barra_omega_adj')
        ibarra_pivot = ibarra_pivot.reindex(index = self.cdates).reindex(columns = self.tk)
        return ibarra_pivot.values
    
    def ret_barra_c_o(self):
        ibarra_c_c = self.ret_barra_c_c()
        i_raw_overnight = self.ret_raw_overnight()
        i_barra_c_o = np.subtract(ibarra_c_c, i_raw_overnight)
        return i_barra_c_o
    
    def ret_raw_overnight(self):
        if os.path.exists(r'S:\Infrastructure\backtester\PRODUCTION\ret_raw_overnight.parqeut'):
            iovernight_pivot = pd.read_parquet(r'S:\Infrastructure\backtester\PRODUCTION\ret_raw_overnight.parqeut', columns = self.tk)
        else:
            iovernight = get_sql('''select datadate, Ticker, (PX_OPEN - PX_YEST_CLOSE)/PX_YEST_CLOSE  as overnight_ret 
                                     FROM [BackTest].[dbo].
[BBG_MktData_Hist] where Ticker in {0}'''.\
                                     format(str(tuple(self.tk)) if len(self.tk)>1 else "('"+self.tk[0]+"')") )
            iovernight_pivot = iovernight.pivot_table(index='datadate', columns = 'Ticker', values = 'overnight_ret')
        iovernight_pivot = iovernight_pivot.reindex(index = self.cdates).reindex(columns = self.tk)
        return iovernight_pivot.values
    
    def ret_raw_c_c(self):
        if os.path.exists(r'S:\Infrastructure\backtester\PRODUCTION\ret_raw_c_c.parqeut'):
            i_ret_raw_c_c = pd.read_parquet(r'S:\Infrastructure\backtester\PRODUCTION\ret_raw_c_c.parqeut', columns = self.tk)
        else:
            i_ret_raw_c_c = get_sql('''select datadate, Ticker, PX_LAST/PX_YEST_CLOSE - 1 as ret_raw_c_c 
                                        FROM [BackTest].[dbo].[BBG_MktData_Hist] where Ticker in {0}'''.\
                                        format(str(tuple(self.tk)) if len(self.tk)>1 else "('"+self.tk[0]+"')") )
            i_ret_raw_c_c = i_ret_raw_c_c.pivot_table(index='datadate', columns = 'Ticker', values = 'ret_raw_c_c')
        i_ret_raw_c_c = i_ret_raw_c_c.reindex(index = self.cdates).reindex(columns = self.tk)
        return i_ret_raw_c_c.values
    
    def ret_raw_c_o(self):
        if os.path.exists(r'S:\Infrastructure\backtester\PRODUCTION\ret_raw_c_o.parqeut'):
            i_ret_raw_c_o = pd.read_parquet(r'S:\Infrastructure\backtester\PRODUCTION\ret_raw_c_o.parqeut', columns = self.tk)
        else:
            i_ret_raw_c_o = get_sql('''select datadate, Ticker, PX_CLOSE/PX_open - 1 as ret_raw_c_o 
                                        FROM [BackTest].[dbo].[BBG_MktData_Hist] where Ticker in {0}'''.\
                                        format(str(tuple(self.tk)) if len(self.tk)>1 else "('"+self.tk[0]+"')") )
            i_ret_raw_c_o = i_ret_raw_c_o.pivot_table(index='datadate', columns = 'Ticker', values = 'ret_raw_c_o')
        i_ret_raw_c_o = i_ret_raw_c_o.reindex(index = self.cdates).reindex(columns = self.tk)
        return i_ret_raw_c_o.values
    
    def vD(self):
        if os.path.exists(r'S:\Infrastructure\backtester\PRODUCTION\vD.parqeut'):
            i_vD = pd.read_parquet(r'S:\Infrastructure\backtester\PRODUCTION\vD.parqeut', columns = self.tk)
        else:
            i_vD = get_sql('''select datadate, ticker, PX_LOW*PX_VOLUME as vD 
                           FROM [BackTest].[dbo].[BBG_MktData_Hist] where ticker in {0}'''.\
                     
      format(str(tuple(self.tk)) if len(self.tk)>1 else "('"+self.tk[0]+"')") )
            i_vD = i_vD.pivot_table(index='datadate', columns = 'ticker', values = 'vD')
        i_vD = i_vD.reindex(index = self.cdates).reindex(columns = self.tk)
        return i_vD.values
    
    def p(self):
        # BBG price data is not adjusted
        i_p = get_sql("select datadate, Ticker, PX_LAST, PX_HIGH, PX_LOW, EQY_SH_OUT FROM [BackTest].[dbo].[BBG_MktData_Hist] where Ticker in {0} order by datadate asc".\
                             format(str(tuple(self.tk)) if len(self.tk)>1 else "('"+self.tk[0]+"')") )
        
        i_sh_out = i_p.pivot_table(index='datadate', columns = 'Ticker', values = 'EQY_SH_OUT')
        i_sh_out = i_sh_out.reindex(columns = self.tk)
        
        i_c = i_p.pivot_table(index='datadate', columns = 'Ticker', values = 'PX_LAST')
        i_c = i_c.reindex(columns = self.tk)        
        i_c = i_c.multiply(i_sh_out).divide(i_sh_out.values[-1], axis = 1)
        
        i_h = i_p.pivot_table(index='datadate', columns = 'Ticker', values = 'PX_HIGH')
        i_h = i_h.reindex(columns = self.tk)
        i_h = i_h.multiply(i_sh_out).divide(i_sh_out.values[-1], axis = 1)
        
        i_l = i_p.pivot_table(index='datadate', columns = 'Ticker', values = 'PX_LOW')
        i_l = i_l.reindex(columns = self.tk)
        i_l = i_l.multiply(i_sh_out).divide(i_sh_out.values[-1], axis = 1)
        
        return i_c, i_h, i_l
    
    def ta_macd(self,pv_p):

        o_ema_short = pv_p.ewm(span = 12, ignore_na = True, axis = 0).mean()
        o_ema_long = pv_p.ewm(span = 26, ignore_na = True, axis = 0).mean()
        
        o_macd = o_ema_short-o_ema_long # the faster line on MACD chart
        o_sig = o_macd.ewm(span=9, ignore_na = True, axis = 0).mean() # the slower line on MACD chart
        
        o_diff = o_macd - o_sig # the histogram on MACD chart 
        
        o_macd = o_macd.reindex(index = self.cdates).reindex(columns = self.tk).fillna(method = 'ffill')
        o_sig = o_sig.reindex(index = self.cdates).reindex(columns = self.tk).fillna(method = 'ffill')
        o_diff = o_diff.reindex(index = self.cdates).reindex(columns = self.tk).fillna(method = 'ffill')
        
        return o_macd.values, o_sig.values, o_diff.values
    
    def ta_boll(self, pv_p):
        
        o_boll_u = pv_p.ewm(span=20, ignore_na = True).mean() + 1.7 * pv_p.rolling(20,min_periods=5).std()
        o_boll_l = pv_p.ewm(span=20, ignore_na = True)
.mean() - 1.7 * pv_p.rolling(20,min_periods=5).std()
        o_boll_index = (pv_p - o_boll_l).divide(o_boll_u - o_boll_l)
        
        o_boll_u = o_boll_u.reindex(index = self.cdates).reindex(columns = self.tk).fillna(method = 'ffill')
        o_boll_l = o_boll_l.reindex(index = self.cdates).reindex(columns = self.tk).fillna(method = 'ffill')        
        o_boll_index = o_boll_index.reindex(index = self.cdates).reindex(columns = self.tk).fillna(method = 'ffill')
        
        return o_boll_u.values, o_boll_l.values, o_boll_index.values
    
    def ta_strong_trend(self, pv_p):
        
        @njit
        def regression(array):
            
            if np.any(np.isnan(array)):
                return np.nan, np.nan, np.nan
            
            y = array
            x = np.array(list(range(len(array))))
            
            y_mean = np.sum(y) / len(y)
            x_mean = np.sum(x) / len(x)
            
            y_variance = np.sum((y-y_mean)**2)
            x_variance = np.sum((x-x_mean)**2)
            
            xy_covariance = np.sum(np.array([(y[i]-y_mean)*(i-x_mean) for i in x]))
            
            b1 = xy_covariance/x_variance
            b0 = y_mean - b1 * x_mean
            
            prediction = b0 + b1 * x
            r2 = np.sum((prediction - y_mean)**2) / y_variance
            
            return b0,b1,r2
        
        @njit
        def rolling_reg(arr_tdates_tk, window):
            # This function calculated the rolling regression of a time series.
            # returns coef and r2
        
            o_b0 = np.zeros(tuple(arr_tdates_tk.shape))
            o_b0[:] = np.nan
            o_b1 = np.zeros(tuple(arr_tdates_tk.shape))
            o_b1[:] = np.nan
            o_r2 = np.zeros(tuple(arr_tdates_tk.shape))
            o_r2[:] = np.nan
            
            for col in range(arr_tdates_tk.shape[1]):
                for row in range(window-1, arr_tdates_tk.shape[0]):
                    array = arr_tdates_tk[row-window+1:row+1,col]
                    b0, b1, r2 = regression(array)
                    o_b0[row, col] = b0
                    o_b1[row, col] = b1
                    o_r2[row, col] = r2

            return o_b0, o_b1, o_r2
        
        _, o_param, o_r2 = rolling_reg(pv_p.values,20)
        
        o_param = pd.DataFrame(o_param, index = pv_p.index, columns = pv_p.columns)
        o_param = o_param.reindex(columns = self.tk).reindex(index = self.cdates)
        o_param = o_param.f
illna(method = 'ffill')
        
        o_r2 = pd.DataFrame(o_r2, index = pv_p.index, columns = pv_p.columns)
        o_r2 = o_r2.reindex(columns = self.tk).reindex(index = self.cdates)
        o_r2 = o_r2.fillna(method = 'ffill')
        
        return o_param.values, o_r2.values
    
    def ed_bd_2_earning(self):
        wh = get_sql('''
                     select datadate, stock_symbol, [next_ed_quarter], [fiscal_year],
                     case when time_of_day = 'After Market' then next_ed + 1 else next_ed end as first_earning_impact 
                     FROM [BackTest].[dbo].[WSH_ED_SNAP] 
                     where stock_symbol in {0} 
                     '''.format(str(tuple(self.tk)) if len(self.tk)>1 else "('"+self.tk[0]+"')") )
        wh = wh.drop_duplicates(subset = ['datadate','stock_symbol'],keep = 'first')
        wh = wh.pivot_table(index = 'datadate', columns = 'stock_symbol', values = 'first_earning_impact', aggfunc=lambda x: x )
        wh = wh.reindex(index = self.cdates).reindex(columns = self.tk)
        wh = wh.fillna(method = 'ffill')
        wh = wh.fillna(date(2888,8,8))
        
        wh_bd2e = pd.DataFrame(index = self.cdates, columns = self.tk)
        for col in wh_bd2e.columns:
            wh_bd2e[col] = np.busday_count(wh.index.values.astype('datetime64[D]'), wh[col].values.astype('datetime64[D]'))
        
        # == 1 means the next trading day will be the first day impacted by earnings.
        # Hence to get out right before earning, make sure wh_bd2e == 2
        # If earning date is uncertain, it will be a very large number > 30000
        
        return wh_bd2e.values
    
    def ed_result(self):
        
        # fetch data from database
        sp_result = get_sql('''
                          with maxdd as
                          ( select ticker, fiscalyear, fiscalmonth,  
                          max(datadate) as maxdatadate from [BackTest].[dbo].[IBES_ACTSALS]
                          where measure = 'SAL' and fiscalperiod = 'QTR' and ticker in {0}
                          group by ticker, fiscalyear, fiscalmonth )
                          select a.ticker, a.fiscalyear, a.fiscalmonth, a.surprisemean, a.surprisestd, 
                          a.actualvalue, maxdd.maxdatadate
                          from [BackTest].[dbo].[IBES_ACTSALS] a
                          right join maxdd 
                          on a.ticker = maxdd.ticker and a.fiscalyear = maxdd.fiscalyear 
                        
  and a.fiscalmonth = maxdd.fiscalmonth and a.datadate = maxdd.maxdatadate
                          where a.measure = 'SAL' and a.FiscalPeriod = 'QTR' and a.ticker in {0}
                          order by a.ticker, a.fiscalyear, a.fiscalmonth
                          '''.format(str(tuple(self.tk)) if len(self.tk)>1 else "('"+self.tk[0]+"')") )
        
        sp_result['ticker_1q'] = sp_result['ticker'].shift()
        sp_result['surprisemean_1q'] = sp_result['surprisemean'].shift()
        sp_result['surprisestd_1q'] = sp_result['surprisestd'].shift()
        sp_result['actualvalue_1q'] = sp_result['actualvalue'].shift()
        sp_result['ticker_2q'] = sp_result['ticker'].shift(2)
        sp_result['surprisemean_2q'] = sp_result['surprisemean'].shift(2)
        sp_result['surprisestd_2q'] = sp_result['surprisestd'].shift(2)
        sp_result['actualvalue_2q'] = sp_result['actualvalue'].shift(2)
                
        sp_result = sp_result[(sp_result.ticker == sp_result.ticker_1q) & (sp_result.ticker == sp_result.ticker_2q)]
        
        o1 = pd.DataFrame()
        o1['signal_date'] = sp_result['maxdatadate'] #+ pd.Timedelta(days = 1)
        o1['ticker'] = sp_result['ticker']
        o1['q_0'] = (sp_result['actualvalue'] - sp_result['surprisemean'])/sp_result['surprisemean']
        o1['q_1'] = (sp_result['actualvalue_1q'] - sp_result['surprisemean_1q'])/sp_result['surprisemean_1q']
        o1['q_2'] = (sp_result['actualvalue_2q'] - sp_result['surprisemean_2q'])/sp_result['surprisemean_2q']
        
        # signal: current quarter is a beat / miss 
        o1 = o1.pivot_table(index = 'signal_date', columns = 'ticker', values = 'q_0')
        o1 = o1.reindex(index = self.cdates).reindex(columns = self.tk)
        o1 = o1.fillna(method = 'ffill')
        
        return o1.values
    
    def pdufa(self):
        pdufa = pd.read_excel(r"S:\Data\CHC_research\PRODUCTION_TABLE\pdufa.xlsx")
                
        pdufa = pdufa[['ticker','start','created']]
        pdufa['start'] = pd.to_datetime(pdufa['start'])
        pdufa['created'] = pd.to_datetime(pdufa['created'].str[:10])
        pdufa = pdufa[pdufa.ticker.isin(self.tk)]
        pdufa = pdufa[pdufa.start > pdufa.created]
        
        o_pdufa = pd.DataFrame(np.ones((len(self.cdates),len(self.tk)))*1e6,
                               columns = self.tk, index = self.cdates)
        
        for num,row in pdufa.iterrows():
            try:
                o_pdufa[row['ticker']].\
        
            values[self.cdates.index(row['created'])+1 : self.cdates.index(row['start'])+1] = \
                    list(range( self.cdates.index(row['start']) - self.cdates.index(row['created']) ))[::-1]
            except:
                pass
        return o_pdufa.values
        
    def rpt_sharpe(self, daily_pnl_sr):
        return daily_pnl_sr.mean()/daily_pnl_sr.std()
    
    def rpt_plot(self, cum_pnl_sr, tdates_sr):
        fig, ax = plt.subplots(constrained_layout=True)
        ax.plot(tdates_sr, cum_pnl_sr)
    
    # ----- loop over strat -----
    
    @jit(forceobj=True)
    def start(self, strat_f, dict_param):
        
        #self.strat_func = strat_f
        #self.params = params
        
        for num in range(len(self.arr_cc_ret)):
            
            # skip over the first few bars
            if num < self.first_bar:
                continue

            #---------------------------------------------------------------------------------
            #                                                    Carry on pst + unfilled order
            #---------------------------------------------------------------------------------
            
            # carry on unfilled order from the previous bar
            self.arr_ordD_unfilled[num,:] = self.arr_ordD_unfilled[num-1,:]            
            
            # carry on pst from the previous bar
            self.arr_pstD_bo[num,:] = self.arr_pstD_bc[num-1,:]
            
            #---------------------------------------------------------------------------------
            #                                                        set up daily volume quota
            #---------------------------------------------------------------------------------
            
            # setup vD quota before filling orders            
            self.vc_vD_quota = np.nan_to_num(self.arr_vD[num,:]) * 0.02
            
            # vD quota is 0 if price is nan
            self.vc_vD_quota[np.isnan(self.arr_cc_ret[num,:])] = 0
            
            #---------------------------------------------------------------------------------
            #                                                                  fill order @ bo
            #---------------------------------------------------------------------------------
                       
            # allowed vD
            t_total_ord_bo = self.arr_ordD_bo[num-1,:] + self.arr_ordD_unfilled[num,:]
            t_abs_ord_bo = np.abs(t_to
tal_ord_bo)
            t_allowed_abs_ord_bo = np.minimum(t_abs_ord_bo, self.vc_vD_quota)
            t_allowed_ord_bo = np.multiply(t_allowed_abs_ord_bo,np.sign(t_total_ord_bo))
            
            # update pst @ bo: yerterday bc pst + unfilled order + new ord
            self.arr_pstD_bo[num,:] = self.arr_pstD_bo[num,:] + t_allowed_ord_bo
            
            # update unfilled orders after bo
            self.arr_ordD_unfilled[num,:] = t_total_ord_bo - t_allowed_ord_bo
            
            # update vD quota after bo ord
            self.vc_vD_quota = self.vc_vD_quota - t_allowed_abs_ord_bo
            
            #---------------------------------------------------------------------------------
            #                                                                  fill order @ bc
            #---------------------------------------------------------------------------------
                
            # allowed vD
            t_total_ord_bc = self.arr_ordD_bc[num-1,:]+self.arr_ordD_unfilled[num,:]
            t_abs_ord_bc = np.abs(t_total_ord_bc)
            t_allowed_abs_ord_bc = np.minimum(t_abs_ord_bc, self.vc_vD_quota)
            t_allowed_ord_bc = np.multiply(t_allowed_abs_ord_bc,np.sign(t_total_ord_bc))
            
            # updte pst @ bc: today bo pst + unfilled order + new ord
            self.arr_pstD_bc[num,:] = self.arr_pstD_bo[num,:] + t_allowed_ord_bc
            
            # update unfilled orders after bc
            self.arr_ordD_unfilled[num,:] = t_total_ord_bc - t_allowed_ord_bc
            
            # update vD quota after bo ord
            self.vc_vD_quota = self.vc_vD_quota - t_allowed_ord_bc
            
            #---------------------------------------------------------------------------------
            #                                                                         pnl @ bc
            #---------------------------------------------------------------------------------            
            
            # calc pnl for the pst opened @ bo
            self.arr_pnlD[num,:] = self.arr_pnlD[num,:] +\
                np.multiply(self.arr_pstD_bo[num,:] - self.arr_pstD_bc[num-1,:],\
                            self.arr_co_ret[num,:])
                                            
            # calc pnl for the pst from yesterday
            self.arr_pnlD[num,:] = self.arr_pnlD[num,:] +\
                np.multiply(self.arr_pstD_bc[num-1,:], self.arr_cc_ret[num,:])
            
            #
---------------------------------------------------------------------------------
            #                                                                curr pst pnl @ bc
            #---------------------------------------------------------------------------------            
            
            # new or held pst / update curr pst pnl
            cond_new_or_held_pst = (self.arr_pstD_bc[num,:]!=0)
            self.arr_curr_pst_pnlD[num, cond_new_or_held_pst ] = \
                                        self.arr_curr_pst_pnlD[num-1, cond_new_or_held_pst] +\
                                        np.where(np.isnan(self.arr_pnlD[num, cond_new_or_held_pst ]), 0 , self.arr_pnlD[num, cond_new_or_held_pst ])
            
            # closed pst / clear curr pst pnl
            cond_closed_pst = (self.arr_pstD_bc[num-1,:]!=0) & (self.arr_pstD_bc[num,:]==0)
            self.arr_curr_pst_pnlD[num, cond_closed_pst] = 0
            
            # convert nan to zero
            self.arr_curr_pst_pnlD = np.nan_to_num(self.arr_curr_pst_pnlD)
            
            #---------------------------------------------------------------------------------
            #                                                             cbars since pst open
            #---------------------------------------------------------------------------------            
            
            # new pst: initiate
            cond_new_pst = (self.arr_pstD_bc[num,:]!=0) & (self.arr_pstD_bc[num-1,:]== 0)
            cond_new_pst = cond_new_pst  | (np.multiply(self.arr_pstD_bc[num,:], self.arr_pstD_bc[num-1,:])<0)
            self.arr_barsheld_since_pst_open[num, cond_new_pst]  = 1
            
            # existing pst: update
            cond_existing_pst = (np.multiply(self.arr_pstD_bc[num,:], self.arr_pstD_bc[num-1,:])>0)
            self.arr_barsheld_since_pst_open[num, cond_existing_pst] = \
                                        self.arr_barsheld_since_pst_open[num, cond_existing_pst] +1
            
            #---------------------------------------------------------------------------------
            #                                                             tbars since pst open
            #---------------------------------------------------------------------------------            
                        
            # new pst: initiate
            self.arr_tbarsheld_since_pst_open[num, cond_new_pst] = 1
            
            # if it has been a tdate today ...

            cond_existing_pst_and_v_p_notnan = cond_existing_pst & (~np.isnan(self.arr_vD[num,:])) &\
                                                (~np.isnan(self.arr_cc_ret[num,:]))
            self.arr_tbarsheld_since_pst_open[num, cond_existing_pst_and_v_p_notnan ] = \
                        self.arr_tbarsheld_since_pst_open[num-1, cond_existing_pst_and_v_p_notnan] + 1
            
            # if it hasn't been a tdate today ...
            cond_existing_pst_and_v_p_isnan = cond_existing_pst & \
                                            (np.isnan(self.arr_vD[num,:]) | np.isnan(self.arr_cc_ret[num,:]))
            self.arr_tbarsheld_since_pst_open[num, cond_existing_pst_and_v_p_isnan ] = \
                        self.arr_tbarsheld_since_pst_open[num-1, cond_existing_pst_and_v_p_isnan]
            

            #---------------------------------------------------------------------------------
            #                                                            cdays of unfilled ord
            #---------------------------------------------------------------------------------            
            
            # cond: new unfilled ord 
            cond_new_unfilled_new_ord = (self.arr_ordD_unfilled[num-1,:] == 0) & (self.arr_ordD_unfilled[num,:] != 0)
            cond_new_unfilled_oppo_ord = (np.multiply(self.arr_ordD_unfilled[num-1,:], self.arr_ordD_unfilled[num,:]) < 0)
            cond_new_unfilled_ord = cond_new_unfilled_new_ord | cond_new_unfilled_oppo_ord
            
            # cond: unfilled ord is for ADDING pst ONLY
            cond_existing_unfilled = (np.multiply(self.arr_ordD_unfilled[num,:], self.arr_ordD_unfilled[num-1,:])>0)    
            cond_unfilled_curr_pst_same_dir = (np.multiply(self.arr_ordD_unfilled[num, :], self.arr_pstD_bc[num,:])>=0)
            cond_unfilled_prev_pst_same_dir = (np.multiply(self.arr_ordD_unfilled[num, :], self.arr_pstD_bc[num-1,:])>=0)
            cond_unfilled_existing_and_not_pst_exit = cond_existing_unfilled & \
                                                        cond_unfilled_curr_pst_same_dir & \
                                                        cond_unfilled_prev_pst_same_dir
            
            # new: unfilled ord
            self.arr_cbar_unfilled_ord[num, cond_new_unfilled_ord] = 1
            
            # update: unfilled ord
            self.arr_cbar_unfilled_ord[num, cond_unfilled_existing_and_not_pst_exit] = \
                            self.arr_cbar_unfilled_or
d[num-1, cond_unfilled_existing_and_not_pst_exit] + 1
            
            # If the order cannot be filled with 6 cdays, cancel ord 
            cond_cancel_unfilled_ord2 = cond_unfilled_existing_and_not_pst_exit & (self.arr_cbar_unfilled_ord[num,:] > 5)
                                        
            self.arr_ordD_unfilled[num, cond_cancel_unfilled_ord2 ] = 0
            
            # unfilled trading bar = 0 if order has been filled
            self.arr_cbar_unfilled_ord[num, self.arr_ordD_unfilled[num,:]==0] = 0
            
            #---------------------------------------------------------------------------------
            #                                                            tdays of unfilled ord
            # no. of trading bars ending up with unfilled ord
            # it shows the EXTRA number of bars taken to fill an order  
            # (e.g. 3 means it takes 1 + 3 days to fill a position)
            #---------------------------------------------------------------------------------            
            
            # unfilled tbar initiated 

            cond_tdate_today = (~np.isnan(self.arr_cc_ret[num,:])) & (~np.isnan(self.arr_vD[num,:]))
            self.arr_tbar_unfilled_ord[num, cond_new_unfilled_ord & cond_tdate_today] = 1

            # unfilled tbar + 1 if ord is not filled  and if it is a tdate today
            cond_existing_unfilled_ord_tdate = cond_unfilled_existing_and_not_pst_exit & cond_tdate_today
                                                
            self.arr_tbar_unfilled_ord[num, cond_existing_unfilled_ord_tdate] = \
                                                self.arr_tbar_unfilled_ord[num-1, cond_existing_unfilled_ord_tdate] + 1
            
            # unfilled tbar = prev if ord is not filled  and if it is NOT a tdate today
            cond_existing_unfilled_ord_non_tdate = cond_unfilled_existing_and_not_pst_exit & (~cond_tdate_today)
                                                
            self.arr_tbar_unfilled_ord[num, cond_existing_unfilled_ord_non_tdate] = \
                                                self.arr_tbar_unfilled_ord[num-1, cond_existing_unfilled_ord_non_tdate]  
            
            # If the "add pst" order cannot be filled within 4 tdays, cancel the order  
            cond_cancel_unfilled_ord =  cond_unfilled_existing_and_not_pst_exit & (self.arr_tbar_unfilled_ord[num,:] > 3)
            self.arr_ordD_unfilled[num, cond_cancel_unfilled_ord ] = 0
       
     self.arr_tbar_unfilled_ord[num, self.arr_ordD_unfilled[num,:]==0] = 0            
            
            #---------------------------------------------------------------------------------
            #                                                                         STRATEGY
            #---------------------------------------------------------------------------------     
            
            strat_f(self, num, dict_param)
            
            
            #print progress
            #print_progress(num, len(self.cdates))
    
    def reporting_save(self, obj):
        
        pickle_bz_dump(os.path.join(r'S:\Data\CHC_research\Backtest Results', 
                                 datetime.now().strftime('%Y%m%d_%H%M_') +\
                                 's_'+str(round(obj['sharpe_ptf'],2)) +\
                                 '_p_{:.2e}'.format(obj['cumpnl_ptf'].tolist()[-1]).replace('+','') +\
                                 '_u_'+str(len(self.tk))+'.p'), obj)
    @staticmethod
    def reporting_read(path):        
        return pickle_bz_load(path)
        
    def reporting(self):
        
        # get rid of weekends and holidays (where vD is nan)
        self.arr_pnlD_present = self.arr_pnlD[pd.notnull(self.arr_vD).any(axis = 1),:]
        self.tdates = np.array(self.cdates)[pd.notnull(self.arr_vD).any(axis = 1)]
        self.arr_pnlD_present = np.nan_to_num(self.arr_pnlD_present)
        self.pv_pnlD_present = pd.DataFrame(self.arr_pnlD_present, index = self.tdates, columns = self.tk)
        
        # strat source code
        #self.dic_report['sourcecode'] = inspect.getsource(self.strat_func)
        self.dic_report['params'] = locals()
        
        # pnl
        self.dic_report['pnl_tk'] = self.pv_pnlD_present
        self.dic_report['pnl_ptf'] = self.pv_pnlD_present.sum(axis = 1)
        
        self.dic_report['cumpnl_tk'] = self.pv_pnlD_present.cumsum(axis = 0)
        self.dic_report['cumpnl_ptf'] = self.pv_pnlD_present.cumsum(axis = 0).sum(axis = 1)
        
        # pst
        self.dic_report['pst_bo'] = pd.DataFrame(self.arr_pstD_bo, index = self.cdates, columns = self.tk) 
        self.dic_report['pst_bc'] = pd.DataFrame(self.arr_pstD_bc, index = self.cdates, columns = self.tk) 
        
        # sharpe
        
        try:
            self.dic_report['sharpe_tk'] = self.pv_pnlD_present.mean(axis = 0) / self.pv_pnlD_present.std(axis = 0) * np.sqrt(250)
            self.dic_report['sharpe_ptf'] = self.pv_
pnlD_present[self.pv_pnlD_present.sum(axis = 1)!=0].sum(axis = 1).mean(axis = 0) /\
                                            self.pv_pnlD_present[self.pv_pnlD_present.sum(axis = 1)!=0].sum(axis = 1).std(axis = 0) * np.sqrt(250)
        except ZeroDivisionError:
            self.dic_report['sharpe_ptf'] = 'pnlD zero std.'
        
        # plot
        self.dic_report['cumpnl_ptf'].plot()
        
        # print key results
        print(self.dic_report['sharpe_ptf'])
        
        # print each ticker 
#        for i in bt.tk:
#            bt.dic_report['cumpnl_tk'][[i]].plot()
#            plt.show()
        
        
        # save results as bz'ed pickles
        self.reporting_save(self.dic_report)
        print (str(datetime.now()) + ' - reporting done.')
        
        return self.dic_report
    
    def report_tk(self,ticker):
        self.dic_report['cumpnl_tk'][ticker].plot()
        print(self.dic_report['sharpe_tk'][ticker])
        
        t_tk_index = self.tk.index(ticker)
        pv_tk_data = pd.DataFrame({'pst':self.arr_pstD_bc[:, t_tk_index],
                                    'ordD_bo': self.arr_ordD_bo[:, t_tk_index],
                                    'ordD_bc': self.arr_ordD_bc[:, t_tk_index],
                                    'pnlD': self.arr_pnlD[:, t_tk_index],
                                    'bd2e': self.arr_bd2e[:, t_tk_index],
                                    'signals': self.arr_signals[:, t_tk_index],
                                    'barra_ret': self.arr_cc_ret[:, t_tk_index] + 1},
                                    index = self.cdates)
        pv_tk_data['cumpnlD'] = pv_tk_data['pnlD'].cumsum()
        pv_tk_data['barra_p'] = pv_tk_data['barra_ret'].cumprod()
        return pv_tk_data
    
    def report_sector(self):
        
        tk_sector = get_sql("select ticker, gsector, ggrop FROM [BackTest].[dbo].[Static_Data_Daily] where datadate = '2020-03-02'")

        tk_sector = tk_sector[tk_sector.ticker.isin(self.tk)]
        
        o_sector = pd.DataFrame()
        
        sector = {50: 'TMT', 10: 'Energy', 60: 'Real Estate', 40: 'Financials', 45: 'Business Services',15: 'Industrials',
                  35: 'Healthcare', 55: 'Utility', 25: 'Retail', 30: 'Consumer Staples', 20: 'Transportation'}
        
        for i in tk_sector.gsector.unique():
            o_sector[i] = o1['cumpnl_tk'][tk_sector[tk_sector.gsector==i]['ticker'].unique().tolist()].sum(axis=1)
            o_sector[i].plot()
    
  
  def addLinkedCrosshairs(self, plots):
        js_move = '''   start = fig.x_range.start, end = fig.x_range.end
                        if(cb_obj.x>=start && cb_obj.x<=end && cb_obj.y>=start && cb_obj.y<=end)
                            { cross.spans.height.computed_location=cb_obj.sx }
                        else { cross.spans.height.computed_location = null }
                  '''
        js_leave = '''cross.spans.height.computed_location=null'''
    
        figures = plots[:]
        for plot in plots:
            crosshair = CrosshairTool(dimensions = 'both', line_alpha = 0.5, line_color = 'grey', line_width = 2)
            plot.add_tools(crosshair)
            for fg in figures:
                if fg != plot:
                    args = {'cross': crosshair, 'fig': fg}
                    fg.js_on_event('mousemove', CustomJS(args = args, code = js_move))
                    fg.js_on_event('mouseleave', CustomJS(args = args, code = js_leave))

    
    def viz(self, ticker):        
        
        i_data = pd.DataFrame(self.arr_cc_ret, columns = self.tk, index = self.cdates)[ticker]
        i_data = (i_data.fillna(0)+1).cumprod()
        dates = self.cdates
        
        i_boll_u = pd.DataFrame(self.arr_boll_u, columns = self.tk, index = self.cdates)[ticker]
        i_boll_l = pd.DataFrame(self.arr_boll_l, columns = self.tk, index = self.cdates)[ticker]
        
        i_pst = pd.DataFrame(self.arr_pstD_bc, columns = self.tk, index = self.cdates)[ticker]
        
        i_bd2e = pd.DataFrame(self.arr_bd2e, columns = self.tk, index = self.cdates)[ticker]
        i_bd2e[i_bd2e<=1] = 1
        i_bd2e[i_bd2e> 1] = 0
        
        i_pnl = pd.DataFrame(self.arr_pnlD, columns = self.tk, index = self.cdates)[ticker]
        i_pnl = i_pnl.cumsum()
        
        # main chart: main price
        
        p_main = figure(plot_height=400, plot_width=1600, tools="pan,wheel_zoom,reset", toolbar_location='right',
                   x_axis_type="datetime", x_axis_location="below",
                   background_fill_color="#ffffff",x_range=(dates[0], dates[-1]))
                   
        barra_price = ColumnDataSource(data=dict(date=dates, barra_p = i_data))
        p_main.circle('date', 'barra_p', source=barra_price, fill_color = 'indigo', size = 4)
        p_main.yaxis.axis_label = 'Barra Price'
        p_main.xaxis[0].ticker.desired_num_ticks = 40
        
        # main chart: boll        
        
        boll_u = ColumnDataSource(data=dict(date=da
tes, bollu=i_boll_u))
        p_main.line('date', 'bollu', source=boll_u, line_color = 'coral', line_width = 0.8, line_alpha = 0.7)
        
        boll_l = ColumnDataSource(data=dict(date=dates, bolll=i_boll_l))
        p_main.line('date', 'bolll', source=boll_l, line_color = 'coral', line_width = 0.8, line_alpha = 0.7)
        
        # main chart: mouse hovering tool
        p_main.add_tools(HoverTool(tooltips=[('date','@date{%F}'),('barra_p','@{barra_p}{0.3f}')],formatters ={'date':'datetime'}))
        
        
        # 2nd chart: MACD / EMA 
        p_2 = figure(plot_height=130, plot_width=1600, tools="xpan", toolbar_location='right',
                   x_axis_type="datetime", x_axis_location="below",
                   background_fill_color="#ffffff", x_range = p_main.x_range)
        
        
                   
        # 3rd chart: signal / position 
        p_3 = figure(plot_height=130, plot_width=1600, tools="xpan", toolbar_location='right',
                   x_axis_type="datetime", x_axis_location="below",
                   background_fill_color="#ffffff", x_range = p_main.x_range)
        p_3.ygrid.grid_line_color = None
        p_3.xgrid.grid_line_color = None
        p_3.xaxis[0].ticker.desired_num_ticks = 40
        
        pstD_bc = ColumnDataSource(data=dict(date=dates, pstD=i_pst))
        p_3.step(x='date', y='pstD', line_alpha = 0.8,source = pstD_bc, color = '#cab2d6')
        p_3.ray(x=dates, y=[0] * len(dates), angle=0, length = 0, line_width=0.5, color = '#a0b0fa', line_alpha = 0.3, line_dash='dashed')
        
        p_3.extra_y_ranges = {"ed_axis": Range1d(start=0, end=1)}
        p_3.step(dates, i_bd2e, color="orange", y_range_name="ed_axis", line_alpha = 0.6)
        p_3.add_layout(LinearAxis(y_range_name="ed_axis"), 'right')
        
        
        p_3.add_tools(HoverTool(tooltips=[('date','@date{%F}'),('pstD','@{pstD}{0.1f}')],formatters ={'date':'datetime'}))
        
        # slider
        slider = figure(plot_height=40, plot_width=1600, #y_range=p_main.y_range,
                        x_axis_type="datetime", y_axis_type=None,
                        tools="", toolbar_location=None, background_fill_color="#efefef")        
        slider_range_tool = RangeTool(x_range=p_main.x_range)
        slider_range_tool.overlay.fill_color = "navy"
        slider_range_tool.overlay.fill_alpha = 0.2
        pnl = ColumnDataSource(data=dict(date=dates, pnl=i_pnl))
        slider.line('date', 'pnl', source=pnl, line_color = 'b
lue', line_width = 1)
        slider.ygrid.grid_line_color = None
        slider.add_tools(slider_range_tool)
        slider.toolbar.active_multi = slider_range_tool
        slider.axis.visible = False
        
        bt.addLinkedCrosshairs([p_main, p_3]) ####????
        
        # show
        #show(column(p_main, slider, p_3))
        show(gridplot([[p_main], [slider], [p_3]]))
        
    
    def debug(self, arr):
        return pd.DataFrame(arr, index = bt.cdates, columns = bt.tk)
    def debug_alpha_signal(self, ticker):
        
        tk_index = bt.tk.index(ticker)
        
        debug_alpha_signal = pd.DataFrame({'barra_ret': self.arr_cc_ret[:,tk_index], 
                                           'signal': self.arr_pstD_bc[:, tk_index] / 2e6,
                                           'earnings': np.where(self.arr_bd2e[:,tk_index]<=2, 1, 0)},
                                        index = bt.cdates)
        
        debug_alpha_signal.loc[debug_alpha_signal['signal'] == 0,'signal'] = np.nan
        debug_alpha_signal = debug_alpha_signal.fillna(method = 'ffill')
        debug_alpha_signal = debug_alpha_signal.reindex(bt.tdates)
        debug_alpha_signal['cumret'] = (debug_alpha_signal['barra_ret']+1).cumprod()
        
        debug_alpha_signal[['cumret','signal']].plot()
        
        return debug_alpha_signal[['cumret','signal','earnings']]
        


if __name__ == '__main__':
    
    @jit(forceobj = True)
    def strat_rev_beatmiss(self, num, dict_param):
        # get signal and hold forever except for earnings
        
        # enter
        tmp_size = np.where((self.arr_ed_result[num,:]!=0) & (np.abs(self.arr_ed_result[num,:])<0.5), 0.5 * np.sign(self.arr_ed_result[num,:]), self.arr_ed_result[num,:])
        
        cond_enter = (self.arr_ed_result[num,:]!=0)
        cond_enough_dats_before_ed = (self.arr_bd2e[num, :] >=4)
        cond_combined = cond_enter & cond_enough_dats_before_ed 
        self.arr_ordD_unfilled[num,cond_combined] = 0
        self.arr_ordD_bo[num,cond_combined] = \
                        - self.arr_pstD_bc[num,cond_combined] + \
                        np.multiply(tmp_size[cond_combined] , 2e6)
        
        # hold 50 tdays and quit 
        cond_hold50 = (self.arr_tbarsheld_since_pst_open[num,:] >= 50)
        cond_exit = (self.arr_pstD_bc[num,:]!=0) & cond_hold50
     
        self.arr_ordD_unfilled[num,cond_exit]=0
        self.arr_ordD_bo[num, cond_exit] = - self.arr_pstD_bc[num, cond_exit]

   
 @jit(forceobj = True)
    def strat_rev_beatmiss_02(self, num, dict_param):    
        
        # identify 
        pass
        
    def strat_modus_01(self, num, dict_param):
        # hold modus signal before earnings, hold actual beat/miss after earnings
        
        # first bar initiation
        if num == self.first_bar:
            self.vc_signals = self.h_create_zero_vc()
            self.vc_signals2 = self.h_create_zero_vc()
            self.vc_pre_earning_mode = self.h_create_zero_vc()
            self.vc_post_earning_mode = self.h_create_zero_vc()
            self.debug2 = self.h_create_zero_arr()
        
        # update pre/post earning mode
        cond_4bd_before_e = self.arr_bd2e[num, :] >= 4
        cond_signal_occur = (self.arr_signals[num,:]!=0) & (self.arr_signals[num-1,:]==0)
        self.vc_pre_earning_mode[cond_4bd_before_e & cond_signal_occur] = 1
        self.vc_pre_earning_mode[(~cond_4bd_before_e)] = 0
        
        cond_past_e = (self.arr_bd2e[num-1,:] <= 1)&(self.arr_bd2e[num,:] > 30)
        self.vc_post_earning_mode[cond_past_e & (self.vc_pre_earning_mode==0)] = 1
        self.vc_post_earning_mode[self.vc_pre_earning_mode!=0] = 0
        
        self.debug2[num,:] = self.vc_post_earning_mode
        
        # update signals before entry        
        self.vc_signals[self.arr_signals[num,:]!=0] = self.arr_signals[num,self.arr_signals[num,:]!=0]
        self.vc_signals2[self.arr_ed_result[num,:]!=0] = self.arr_ed_result[num,self.arr_ed_result[num,:]!=0]
        self.vc_signals2 = np.where(np.abs(self.vc_signals2) <0.5, 0.5*np.sign(self.vc_signals2), self.vc_signals2 )
        
        
        # enter w.r.t Modus
        cond_enter = (self.vc_signals != 0 )
        cond_enough_dats_before_ed = (self.arr_bd2e[num, :] >=4)
        cond_no_recent_earning = (np.sum(self.arr_bd2e[num-2:num+1,:]<=2,axis = 0) == 0)
        cond_combined = cond_enter & cond_enough_dats_before_ed & cond_no_recent_earning & (self.vc_pre_earning_mode==1)
        self.arr_ordD_unfilled[num,cond_combined] = 0
        self.arr_ordD_bo[num,cond_combined] = \
                        - self.arr_pstD_bc[num,cond_combined] + \
                        np.multiply(self.vc_signals[cond_combined] , 2e6)
        
        # enter w.r.t actual earning beat / miss
        cond_enter2 = (self.vc_signals2 != 0 )
        cond_combined2 = cond_enter2 & (self.vc_post_earning_mode == 1)
        self.arr_ordD_unfilled[num,cond_combined2] = 0
        self.arr_ordD_
bo[num,cond_combined2] = \
                        - self.arr_pstD_bc[num,cond_combined2] + \
                        np.multiply(self.vc_signals2[cond_combined2] , 3e6)
        
        
        # exit 1 day before earnings if recent alpha is sloping upwards
        cond_exit = (self.arr_pstD_bc[num,:]!=0) & (self.arr_curr_pst_pnlD[num,:] > 0) & (self.arr_bd2e[num,:]<= 2 + self.arr_tbar_unfilled_ord[num-40:num,:].max(axis = 0) )
    
        self.arr_ordD_unfilled[num,cond_exit]=0
        self.arr_ordD_bo[num, cond_exit] = - self.arr_pstD_bc[num, cond_exit]

    
    def strat_200430c(self, num, dict_param):        
        # if +pnl, leave before earnings
        # if -ve pnl, leave after earnigns
        # avoid pdufa
        
        # This is most basic strategy.
        
        
        # enter
        cond_enter = (self.arr_signals[num,:] != 0 )
        self.arr_ordD_unfilled[num,cond_enter ] = 0
        self.arr_ordD_bo[num,cond_enter] = - self.arr_pstD_bc[num, cond_enter] + np.multiply(self.arr_signals[num,cond_enter] , 2e6)
        
        # exit 1 day before earnings 
        cond_exit = (self.arr_pstD_bc[num,:]!=0) & (self.arr_curr_pst_pnlD[num,:] > 0) & (self.arr_bd2e[num,:]<= 2 + self.arr_tbar_unfilled_ord[num-40:num,:].max(axis = 0) )
    
        self.arr_ordD_unfilled[num,cond_exit]=0
        self.arr_ordD_bo[num, cond_exit] = - self.arr_pstD_bc[num, cond_exit]
        
        # exit 1 day after earnings anyways
        cond_exit2 = (self.arr_pstD_bc[num,:]!=0) & (self.arr_bd2e[num,:] > self.arr_bd2e[num-1,:])
        
        self.arr_ordD_unfilled[num,cond_exit2]=0
        self.arr_ordD_bo[num, cond_exit2] = - self.arr_pstD_bc[num, cond_exit2]
        
        # exit 1 day before pdufa
        cond_exit3 = (self.arr_pstD_bc[num,:]!=0) & (self.arr_pdufa[num,:] <=2)
        
        self.arr_ordD_unfilled[num,cond_exit3]=0
        self.arr_ordD_bo[num, cond_exit3] = - self.arr_pstD_bc[num, cond_exit3]
        
    def strat_200520(self, num, dict_param):
        
        # signal lookback
        SL = 40
        
        # ta status
        cond_boll_breakdown = (self.arr_l[num,:] < self.arr_boll_l[num,:])
        cond_boll_breakup = (self.arr_h[num,:] > self.arr_boll_u[num,:])
        
        cond_macd_bottom_reverse = (0 > self.arr_macd[num,:]) &\
                         (self.arr_macd[num,:] > self.arr_macd[num-1,:]) &\
                         (self.arr_macd[num-1,:] > self.arr_macd[num-2,:])
        cond_macd_top_reverse = (0 < s
elf.arr_macd[num,:]) &\
                         (self.arr_macd[num,:] < self.arr_macd[num-1,:]) &\
                         (self.arr_macd[num-1,:] < self.arr_macd[num-2,:])
        cond_reg_down_trend = (self.arr_reg_param[num,:] < -0.004 ) & (self.arr_reg_r2[num,:] > 0.75)
        cond_reg_up_trend = (self.arr_reg_param[num,:] > 0.004 ) & (self.arr_reg_r2[num,:] > 0.75)
                         
        # pst status
        cond_have_long = (self.arr_pstD_bc[num,:] > 0)
        cond_have_short = (self.arr_pstD_bc[num,:] < 0)
        #cond_have_pst = (self.arr_pstD_bc[num,:] != 0)
        #cond_have_none = (self.arr_pstD_bc[num,:] == 0)
        
        # ed status
        cond_no_recent_ed = (np.sum(self.arr_bd2e[num-SL:num+1,:]<=2,axis = 0) == 0)
        cond_enough_dats_before_ed = (self.arr_bd2e[num, :] >=4)
        
        # enter
        cond_in_short = (np.sum(self.arr_signals[num-SL:num+1,:],axis = 0) < 0 ) &\
                             (   ~cond_have_short   ) &\
                             (   cond_boll_breakup | cond_macd_top_reverse   ) &\
                             (   cond_no_recent_ed    ) &\
                             (   ~cond_reg_up_trend   ) & cond_enough_dats_before_ed
        
        self.arr_ordD_unfilled[num, cond_in_short] = 0
        self.arr_ordD_bo[num, cond_in_short] = -self.arr_pstD_bc[num, cond_in_short] + \
                np.multiply(self.h_last_nonzero(self.arr_signals[num-SL:num+1,:], 0, SL)[cond_in_short], 1e6)
        
        
        
        cond_in_long = (np.sum(self.arr_signals[num-SL:num+1,:],axis = 0) > 0 ) &\
                             (   ~cond_have_long    ) &\
                             (   cond_boll_breakdown | cond_macd_bottom_reverse   ) &\
                             (   cond_no_recent_ed    ) &\
                             (   ~cond_reg_down_trend   ) & cond_enough_dats_before_ed
        
        self.arr_ordD_unfilled[num, cond_in_long] = 0
        self.arr_ordD_bo[num, cond_in_long] = -self.arr_pstD_bc[num, cond_in_long] + \
                np.multiply(self.h_last_nonzero(self.arr_signals[num-SL:num+1,:], 0, SL)[cond_in_long], 1e6)
                
        # exit 1 day before earnings 
        cond_exit = (self.arr_pstD_bc[num,:]!=0) & (self.arr_curr_pst_pnlD[num,:] > 0) & (self.arr_bd2e[num,:]<=2)
    
        self.arr_ordD_unfilled[num,cond_exit]=0
        self.arr_ordD_bo[num, cond_exit] = - self.arr_pstD_bc[num, cond_exit]
        
        # exit 1 day after earnings anyways
      
  cond_exit2 = (self.arr_pstD_bc[num,:]!=0) & (self.arr_bd2e[num,:] > self.arr_bd2e[num-1,:])
        
        self.arr_ordD_unfilled[num,cond_exit2]=0
        self.arr_ordD_bo[num, cond_exit2] = - self.arr_pstD_bc[num, cond_exit2]
        
        # exit 1 day before pdufa
        cond_exit3 = (self.arr_pstD_bc[num,:]!=0) & (self.arr_pdufa[num,:] <=2)
        
        self.arr_ordD_unfilled[num,cond_exit3]=0
        self.arr_ordD_bo[num, cond_exit3] = - self.arr_pstD_bc[num, cond_exit3]
        
    def strat_200521(self, num, dict_param):
        
        # first bar initiation
        if num == self.first_bar:
            self.vc_signals = self.h_create_zero_vc()
            self.tmp_boll_u = self.h_create_zero_arr()
            self.tmp_boll_l = self.h_create_zero_arr()
            self.tmp_signals = self.h_create_zero_arr()
            self.reg_up_trend = self.h_create_zero_arr()
            self.reg_down_trend = self.h_create_zero_arr()
            self.cond_long = self.h_create_zero_arr()
            self.cond_short = self.h_create_zero_arr()

        # signal lookback
        SL = 40
        
        # ta status
        cond_boll_breakdown = (self.arr_l[num,:] < self.arr_boll_l[num,:])
        cond_boll_breakup = (self.arr_h[num,:] > self.arr_boll_u[num,:])
        
        #cond_boll_minor_bull = (self.arr_boll_index[num,:] < 0.6)
        #cond_boll_minor_bear = (self.arr_boll_index[num,:] > 0.4)
        
        cond_macd_bottom_reverse = (self.arr_macd[num,:]<0) & (self.arr_sig[num,:]<0) &\
                                    (self.arr_macd[num-1,:] < self.arr_sig[num-1,:]) &\
                                    (self.arr_macd[num,:] > self.arr_sig[num,:])
        cond_macd_top_reverse = (self.arr_macd[num,:]>0) & (self.arr_sig[num,:]>0) &\
                                    (self.arr_macd[num-1,:] > self.arr_sig[num-1,:]) &\
                                    (self.arr_macd[num,:] < self.arr_sig[num,:])
        cond_reg_down_trend = (self.arr_reg_param[num,:] < -0.004 ) & (self.arr_reg_r2[num,:] > 0.75)
        cond_reg_up_trend = (self.arr_reg_param[num,:] > 0.004 ) & (self.arr_reg_r2[num,:] > 0.75)
                         
        # pst status
        cond_have_long = (self.arr_pstD_bc[num,:] > 0)
        cond_have_short = (self.arr_pstD_bc[num,:] < 0)
        #cond_have_pst = (self.arr_pstD_bc[num,:] != 0)
        #cond_have_none = (self.arr_pstD_bc[num,:] == 0)
        
        # ed status
        cond_no_recent_ed = (np.sum(self.arr_bd2
e[num-SL:num+1,:]<=2,axis = 0) == 0)
        cond_enough_dats_before_ed = (self.arr_bd2e[num, :] >=4)

        
        # update signals before entry
        self.vc_signals[self.arr_signals[num,:]!=0] = self.arr_signals[num,self.arr_signals[num,:]!=0]
        self.vc_signals[~cond_enough_dats_before_ed] = 0

        
        # record temp var
        self.tmp_boll_u[num,:] = cond_boll_breakup
        self.tmp_boll_l[num,:] = cond_boll_breakdown
        self.tmp_signals[num,:] = self.vc_signals
        self.reg_up_trend[num,:] = cond_reg_up_trend
        self.reg_down_trend[num,:] = cond_reg_down_trend
        
        # enter
        cond_in_short = (    self.vc_signals < 0) &\
                             (   ~cond_have_short   ) &\
                             (   cond_boll_breakup  ) &\
                             (   cond_no_recent_ed    ) &\
                             (   ~cond_reg_up_trend   ) & cond_enough_dats_before_ed 
        self.cond_short[num,:] = cond_in_short
        
        
        self.arr_ordD_unfilled[num, cond_in_short] = 0
        self.arr_ordD_bo[num, cond_in_short] = -self.arr_pstD_bc[num, cond_in_short] + \
                np.multiply(self.vc_signals[cond_in_short], 1e6)
        
        
        cond_in_long = (     self.vc_signals > 0) &\
                             (   ~cond_have_long    ) &\
                             (   cond_boll_breakdown  ) &\
                             (   cond_no_recent_ed    ) &\
                             (   ~cond_reg_down_trend   ) & cond_enough_dats_before_ed
        self.cond_long[num,:] = cond_in_long
        
        self.arr_ordD_unfilled[num, cond_in_long] = 0
        self.arr_ordD_bo[num, cond_in_long] = -self.arr_pstD_bc[num, cond_in_long] + \
                np.multiply(self.vc_signals[cond_in_long], 1e6)
        
        
        # exit stop win
        
        cond_long_stop_win = ((self.arr_p[num,:] > self.arr_boll_u[num,:]) | cond_macd_top_reverse )& \
                                cond_have_long & (self.arr_curr_pst_pnlD[num,:] > 0)
        cond_short_stop_win = ((self.arr_p[num,:] < self.arr_boll_l[num,:]) | cond_macd_bottom_reverse ) &\
                                cond_have_short & (self.arr_curr_pst_pnlD[num,:] > 0)
        
        self.arr_ordD_unfilled[num, cond_long_stop_win & cond_have_long]=0
        self.arr_ordD_bo[num, cond_long_stop_win & cond_have_long] = \
                                            - self.arr_pstD_bc[num, cond_long_stop_win & cond_have
_long]
        
        self.arr_ordD_unfilled[num, cond_short_stop_win & cond_have_short]=0
        self.arr_ordD_bo[num, cond_short_stop_win & cond_have_short] = \
                                            - self.arr_pstD_bc[num, cond_short_stop_win & cond_have_short]
        
        
        
        # exit 1 day before earnings 
        cond_exit = (self.arr_bd2e[num,:]<=2) &\
                    (np.multiply(self.arr_pstD_bc[num,:], self.arr_reg_param[num,:])>0)
    
        self.arr_ordD_unfilled[num,cond_exit]=0
        self.arr_ordD_bo[num, cond_exit] = - self.arr_pstD_bc[num, cond_exit]
        
        # exit 1 day after earnings anyways
        cond_exit2 = (self.arr_pstD_bc[num,:]!=0) & (self.arr_bd2e[num,:] > self.arr_bd2e[num-1,:])
        
        self.arr_ordD_unfilled[num,cond_exit2]=0
        self.arr_ordD_bo[num, cond_exit2] = - self.arr_pstD_bc[num, cond_exit2]
        
        # exit 1 day before pdufa
        cond_exit3 = (self.arr_pstD_bc[num,:]!=0) & (self.arr_pdufa[num,:] <=2)
        
        self.arr_ordD_unfilled[num,cond_exit3]=0
        self.arr_ordD_bo[num, cond_exit3] = - self.arr_pstD_bc[num, cond_exit3]

    
    bt = Backtest(['barra','ed','edresult','pdufa','ta_macd','ta_reg','ta_boll'], i3, '2015-07-01','2019-08-01',40)
    bt.start(strat_modus_01, {}) #strat_200430c   strat_200520
    o1 = bt.reporting()


