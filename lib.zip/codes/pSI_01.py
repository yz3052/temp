﻿#$%^&* pSI_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Sep  8 19:49:15 2020

@author: thzhang
"""

import pandas as pd
import numpy as np

import os, re

import xml.etree.ElementTree as ET

# This script imports raw data from Z drive to N drive


xml_files = os.listdir(r'Z:\185018\2794\Event_Driven_Newsfeed\Trial_20200818') #616500
xml_files2 = [i for i in xml_files if i.endswith('.xml')] #399929

#xml_files = os.listdir(r'Z:\185018\2794\Event_Driven_Newsfeed\Trial_20200924') #418596
#xml_files2 = [i for i in xml_files if i.endswith('.xml')] #399929

o_error = []
o1 = []
cnt = 0
for f in xml_files2:
    
    t_data = []
    
    try:
        i_xml = ET.parse(os.path.join(r'Z:\185018\2794\Event_Driven_Newsfeed\Trial_20200818',f))
    except:
        o_error.append(f)
        continue
    
    article = i_xml.getroot()
    
    # article id
    try:
        t_data.append(article.attrib['id'])
    except:
        raise Exception('Article ID missing.')
    # pubDate
    try:
        t_data.append(article.findall('./pubDate')[0].text)
    except:
        raise Exception('PubDate missing.')
    # headline
    try:
        t_data.append(article.findall('./headline')[0].text)
    except:
        raise Exception('Headline missing.')
    # category 1 - 10
    t_category = article.findall('./categories/category')
    for j in range(10):
        if j < len(t_category):
            try:
                t_data.append(t_category[j].text)
            except:
                raise Exception('category missing.')
        else:
            t_data.append(np.nan)
    # link
    try:
        t_data.append(article.findall('./link')[0].text)
    except:
        raise Exception('Link missing.')
    # text body
    try:
        t_text = article.findall('./body')[0].text
        if t_text is None:
            t_text=''
        t_data.append(re.sub("<.*?>", '', t_text))
        del t_text
    except:
        raise Exception('Body missing.') 
    # ticker (to be put at last because there might be multiple tickers)
    tickers = article.findall('./symbols/symbol')
    for t in tickers:
        o1.append(t_data + [t.text])
    
    # quality check
    if len(t_data) != 15:
        raise Exception ('t_data len is wrong.')
    else:
        cnt+=1

o2 = pd.DataFrame(o1, columns = ['id','pubDate','headline']+['cat'+str(i) for i in range(10)]+['link','body','ticker'])
o2.to_parquet(r'N:\projects\street_insider\trial.parquet')

