﻿#$%^&* featurepool_cn_apb_prodSYNC.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  5 16:48:33 2022

@author: thzhang
"""

import sys
import os
import pandas as pd
import numpy as np

import datetime

from sqlalchemy import create_engine
import urllib









#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------

source_path = '/export/dataprod2/CNL2/SHSZ/q_trod_apb'
save_path = '/dat/summit_capital/TZ/PROD_FEATURES/featurepool_cn_desc_pv_apb'
conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))

today = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
today = pd.to_datetime(today.date())
today_str = today.strftime('%Y%m%d')




#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------

i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()



#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------



dates_to_query = i_cal['DataDate'].dt.strftime('%Y%m%d.parquet').drop_duplicates().tolist()
dates_to_query = [d for d in dates_to_query if (d>='20170101.parquet') and (d<today.strftime('%Y%m%d.parquet'))]

existing_dates = os.listdir(save_path)
dates_to_query = [d for d in dates_to_query if d not in existing_dates]





#------------------------------------------------------------------------------
### calculate descriptors
#------------------------------------------------------------------------------

for i in dates_to_query:
    
    # date string
    t_1d = pd.to_datetime(i, format='%Y%m%d.parquet')    
    t_1d_str = t_1d.strftime('%Y%m%d')
    t_1d_dotstr = t_1d.strftime('%Y.%m.%d')
    
    # get q query results
    
    i_q = pd.read_csv(os.path.join(source_path, t_1d_dotstr+'.txt'), sep = '|', )    
    i_q = i_q.rename(columns = 
{'code': 'Ticker', 'date': 'T-1d'})
    i_q['Ticker'] = i_q['Ticker'].astype(int).astype(str).str.zfill(6)
    i_q['T-1d'] = pd.to_datetime(i_q['T-1d'])    
    
    # get twap
    
    i_twap = pd.read_sql('''select Ticker, AVG(PV/Volume) as twap 
                         FROM [CNDBPROD].[dbo].[TRTH_CN_TRADE_{0}] 
                         where hour*100+min>=930 and hour*100+min<=1500 
                         and volume!=0 
                         and DataDate = '{1}'
                         group by datadate, ticker
                         '''.format(t_1d_str[2:4], t_1d_str), conn)
    i_twap['Ticker'] = i_twap['Ticker'].str[:6]
    
    # combine
    
    icom = i_q.merge(i_twap, on = ['Ticker'], how = 'left')
    icom = icom.merge(i_cal, on = ['T-1d'], how = 'left')
    
    icom['apb'] = icom['twap'].divide(icom['odB_pTRD_vwap'])    
    icom['apb'] = icom['apb'].replace(0, np.nan).replace(np.inf, np.nan).replace(-np.inf, np.nan)
    icom['apb'] = np.log(icom['apb'])
   
    if icom['apb'].notnull().sum() > 0:
        icom[['Ticker', 'DataDate', 'apb']].to_parquet(os.path.join(save_path, i))



