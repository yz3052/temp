﻿#$%^&* util_intra.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 13 02:00:18 2023

@author: thzhang
"""

import pandas as pd
import numpy as np

import util as yu
import os

from statsmodels.stats.anova import anova_lm
import matplotlib.pyplot as plt
from pandas.plotting import table as ptable




def prepare_intra_sd():    
    
    # get tdate
    i_tdate = yu.get_sql('''select distinct [TradeDate_next] as tm1d 
                         from [cndbprod].[dbo].[Calendar_Dates_CN]
                         where [TradeDate_next] > '2021-01-01' and [TradeDate_next]<'2023-07-20'
                         ''')
    
    # get timestamps (15 min interval)
    def helper_ts(d):
        dstr = d.strftime('%Y-%m-%d')        
        session1 = pd.DataFrame({'ts15m_s': pd.date_range(dstr+" 09:30", dstr+" 11:15", freq="15min"),
                                 'ts15m_e': pd.date_range(dstr+" 09:45", dstr+" 11:30", freq="15min"),
                                 'tm1d': d})
        session2 = pd.DataFrame({'ts15m_s': pd.date_range(dstr+" 13:00", dstr+" 14:45", freq="15min"),
                                 'ts15m_e': pd.date_range(dstr+" 13:15", dstr+" 15:00", freq="15min"),
                                 'tm1d':d})
        return pd.concat([session1, session2], axis=0)
    i_ts = pd.concat([helper_ts(d) for d in i_tdate['tm1d'].tolist()], axis=0)
    
    
    # get 1800 ticker universe 
    i_uni = yu.get_sql('''select datadate as tm1d, Ticker 
                       from cndbprod.dbo.UNIVERSE_CSI1800
                       where datadate>'2021-01-01' and datadate<'2023-07-20'
                       ''')
    
    # get ret            
    root_ret = '/dat/summit_capital/TZ/PROD_Q/q_intraday_return/'
    def helper_ret(f):
        tm1d = pd.to_datetime(f,format='%Y.%m.%d.txt')
        t_uni = i_uni[i_uni['tm1d'].eq(tm1d)]
        if len(t_uni)==0:
            return pd.DataFrame()
        i_csv = pd.read_csv(root_ret + f, sep = '|')
        i_csv['Ticker'] = i_csv['code'].astype(int).astype(str).str.zfill(6)
        i_csv = i_csv[i_csv['Ticker'].isin(t_uni['Ticker'].tolist())]
        i_csv['tm1d'] = pd.to_datetime(i_csv['date'])
        i_csv = i_csv.drop(columns = ['code', 'date'])
        return i_csv
    i_ret = pd.concat([helper_ret(f) for f in os.listdir(root_ret)], axis=0)    
    
    i_ret['ts15m_e'] = pd.to_datetime(i_ret['ts5m_e'], format = '%Y-%m-%dD%H:%M:%S.000000000')
    for c in ['rawret_p15m', 'rawret_p60m', 'rawret_
eod', 'rawret_m5m', 
              'rawret_m15m', 'rawret_m60m', 'rawret_sod']:
        i_ret[c] = i_ret[c].replace('0n',np.nan).replace('inf',np.nan).replace('-inf',np.nan)
        i_ret[c] = pd.to_numeric(i_ret[c])        
    i_ret = i_ret[['Ticker', 'tm1d', 'ts15m_e',
                   'rawret_p15m', 'rawret_p60m', 'rawret_eod', 'rawret_m5m', 
                   'rawret_m15m', 'rawret_m60m', 'rawret_sod']]
    
    # other static table columns
    # calculate tm1d here because we want universe data 1 day before intraday data's date
    i_other_date_map = yu.get_sql('''select distinct datadate 
                                  from [CNDBPROD].[dbo].UNIVERSE_ALL_CN_GEM3L 
                                  order by datadate''')
    i_other_date_map['tm1d'] = i_other_date_map['datadate'].shift()
    
    i_other = yu.get_sql('''select datadate, Ticker, GIND, spread, avgPVadj, 
                         gk_vol_63d as volatility, cn_index, MC
                         from [CNDBPROD].[dbo].UNIVERSE_ALL_CN_GEM3L
                         where datadate>'2020-12-20' and datadate<'2023-08-10'  ''')
    i_other = i_other.merge(i_other_date_map, on = 'datadate', how = 'left')
    i_other = i_other.drop(columns = ['datadate'])
    
    
    # combine
    o_data = i_uni.merge(i_ts, on='tm1d', how='inner')
    o_data = o_data.merge(i_ret, on = ['Ticker','tm1d','ts15m_e'], how = 'left')
    o_data = o_data.merge(i_other, on = ['Ticker', 'tm1d'], how = 'left')
    
    o_data['rawret_p15m_rk'] = o_data.groupby(['tm1d','ts15m_s'])['rawret_p15m'].apply(yu.uniformed_rank)
    o_data['rawret_p60m_rk'] = o_data.groupby(['tm1d','ts15m_s'])['rawret_p60m'].apply(yu.uniformed_rank)
    o_data['rawret_eod_rk'] = o_data.groupby(['tm1d','ts15m_s'])['rawret_eod'].apply(yu.uniformed_rank)
    
    o_data.to_parquet('/dat/summit_capital/TZ/backtester/data_cache/sd_cn_intra.parquet')



def get_intra_sd():
    
    return pd.read_parquet('/dat/summit_capital/TZ/backtester/data_cache/sd_cn_intra.parquet')
    


def get_feat_act(p):
    # this to be used in multiprocessing
    # root1 = '/dat/summit_capital/TZ/PROD_Q/q_intraday_trd_act/'
    # with Pool(20) as pool:
    #     i_feat_act = pool.map(yui.get_feat_act, [root1+f for f in os.listdir(root1)])
    i_feat_act = pd.read_csv(p, sep = '|')
    i_feat_act['Ticker'] = i_feat_act['code'].astype(int).astype(str).str.zfill(6)
    i_feat_act['tm1d'] = pd.to_datetime(i_feat_act['date'])
    i_feat_act['ts15m_s'] = i_feat_act['date'] + ' 
' + i_feat_act['hh5m_s'].astype(int).astype(str).str.zfill(4)
    i_feat_act['ts15m_s'] = pd.to_datetime(i_feat_act['ts15m_s'])
    i_feat_act = i_feat_act.drop(columns = ['code', 'date', 'hh5m_s', 'hh5m_e'])
    return i_feat_act

def get_feat_ls(p):
    # this to be used in multiprocessing
    # root2 = '/dat/summit_capital/TZ/PROD_Q/q_intraday_trd_ls/'
    # with Pool(20) as pool:
    #     i_feat_ls = pool.map(yui.get_feat_ls, [root1+f for f in os.listdir(root2)])
    i_feat_ls = pd.read_csv(p, sep = '|')
    i_feat_ls['Ticker'] = i_feat_ls['code'].astype(int).astype(str).str.zfill(6)
    i_feat_ls['tm1d'] = pd.to_datetime(i_feat_ls['date'])
    i_feat_ls['ts15m_s'] = i_feat_ls['date'] + ' ' + i_feat_ls['hh5m_s'].astype(int).astype(str).str.zfill(4)
    i_feat_ls['ts15m_s'] = pd.to_datetime(i_feat_ls['ts15m_s'])
    i_feat_ls = i_feat_ls.drop(columns = ['code', 'date', 'hh5m_s', 'hh5m_e'])
    return i_feat_ls


def get_feat_imb(p):
    # this to be used in multiprocessing
    # root3 = '/dat/summit_capital/TZ/PROD_Q/q_intraday_odbk_imb/'
    # with Pool(20) as pool:
    #     i_feat_imb = pool.map(yui.get_feat_imb, [root1+f for f in os.listdir(root3)])
    i_feat_imb = pd.read_csv(p, sep = '|')
    i_feat_imb['Ticker'] = i_feat_imb['code'].astype(int).astype(str).str.zfill(6)
    i_feat_imb['tm1d'] = pd.to_datetime(i_feat_imb['date'])
    i_feat_imb['ts15m_s'] = i_feat_imb['date'] + ' ' + i_feat_imb['hh1m_s'].astype(int).astype(str).str.zfill(4)
    i_feat_imb['ts15m_s'] = pd.to_datetime(i_feat_imb['ts15m_s'])
    i_feat_imb = i_feat_imb.drop(columns = ['code', 'date', 'hh1m_s'])
    return i_feat_imb







def plot_barchart_cn(icom, col_bucket, col_feat, col_ret = 'rawret_p15m_rk'):
    # icom must have: ticker, tm1d, spread, avgPVadj, MC, volatility
    
        
    # prepare data     
    
    icom_dropna = icom.copy()
    icom_dropna = icom_dropna.dropna(subset = [col_bucket, col_feat, col_ret, 'avgPVadj']).copy()
    icom_dropna['clip15m'] = (icom_dropna['avgPVadj']/16*0.02).apply(lambda x: min(x, 1e6)) # rmb clip capped at 1m rmb
    icom_dropna['avgPVadj_rk'] = icom_dropna.groupby('tm1d')['avgPVadj'].apply(yu.uniformed_rank).values
    icom_dropna['MC_rk'] = icom_dropna.groupby('tm1d')['MC'].apply(yu.uniformed_rank).values
    icom_dropna['volatility_rk'] = icom_dropna.groupby('tm1d')['volatility'].apply(yu.uniformed_rank).values
    icom_dropna['spread_rk'] = icom_dropna.groupby('tm1d')['spread'].apply(yu.uniformed_rank).values
    
    
   
 # metrics
    
    s_ret = icom_dropna.groupby(col_bucket)\
            .apply(lambda r: pd.Series(np.average(r[[col_ret]],weights=r['clip15m'],axis=0),['mean_ret']))
    s_ret = s_ret.reset_index()
        
    icom_dropna = icom_dropna.merge(s_ret, on = col_bucket, how = 'left')
    icom_dropna['ret_demean_sqr'] = (icom_dropna[col_ret] - icom_dropna['mean_ret'])**2
    
    s_var = icom_dropna.groupby(col_bucket)\
            .apply(lambda r: pd.Series(np.average(r[['ret_demean_sqr']],weights=r['clip15m'],axis=0),['var_ret']))
    s_num = icom_dropna.groupby(col_bucket)[['clip15m']].count().rename(columns={'clip15m':'num'})
    s_feat = icom_dropna.groupby(col_bucket)[[col_feat]].mean().rename(columns={col_feat:'mean_feat'})
    s_others = icom_dropna.groupby(col_bucket)[['avgPVadj_rk','MC_rk','spread_rk','volatility_rk']].mean()
    s_ret = s_ret.set_index(col_bucket)
    
    s_all = pd.concat([s_ret,s_var,s_num,s_feat,s_others],axis=1)
    s_all ['tstats'] = s_all ['mean_ret'] / np.sqrt(s_all ['var_ret']) * np.sqrt(s_all ['num'])
    s_all ['tstats'] = s_all ['tstats'].apply(lambda r: np.round(r,1))
    s_all ['mean_ret'] = s_all ['mean_ret'].apply(lambda r: np.round(r*1e4,1)) # in bp
    s_all ['mean_feat'] = s_all ['mean_feat'].apply(lambda x: "{:.0e}".format(x))
    s_all ['num'] = s_all ['num'].apply(lambda x: "{:.0e}".format(x))
    s_all ['avgPVadj_rk'] = s_all ['avgPVadj_rk'].apply(lambda r: np.round(r,2))
    s_all ['MC_rk'] = s_all ['MC_rk'].apply(lambda r: np.round(r,2))
    s_all ['spread_rk'] = s_all ['spread_rk'].apply(lambda r: np.round(r,2))
    s_all ['volatility_rk'] = s_all ['volatility_rk'].apply(lambda x: np.round(x,2))


    # plot 
    
    fig = plt.figure(figsize=(15,16))
    plt.title(col_feat)
    ax1 = fig.add_subplot(311)
    ax1.bar(s_all.index, s_all ['mean_ret'], align = 'center')
    ax1.grid()
    ax1.set_xlim(s_all .index.values.min()-0.5,s_all .index.values.max()+0.5)
    ax1.set_xticks(range(int(s_all.index.values.min()),int(s_all.index.values.max())+1))
    ax1.set_xticklabels([])
    ax1.tick_params(axis='y', labelsize=20)
    tbl1 = ptable(ax1, s_all [['mean_ret','tstats','num','mean_feat','avgPVadj_rk','MC_rk','spread_rk','volatility_rk']].T, 
           cellLoc='center',loc='bottom',bbox=[0,-1.0,1,1.0])
    tbl1.set_fontsize(20)
    ax1.set_ylabel(col_ret+' (bps)', fontsize= 20)
    
    
    
def plot_pnl_cn(icom, col_sgnl = '', col_ret = 'rawret_p15m', neutral = True):
    # col_sgnl must be a +ve/-ve number
 indicating number of clips
    # 
        
    
    # get data 
    
    icom['clip15m'] = (icom['avgPVadj']/16*0.02).apply(lambda x: min(x, 3e5)) # rmb clip capped at 1m rmb
    icom_dropna = icom.dropna(subset = [col_sgnl, col_ret, 'clip15m']).copy()
    icom_dropna['mv'] = icom_dropna['clip15m'] * icom_dropna[col_sgnl]
    icom_dropna['gmv'] = icom_dropna['mv'].abs()
    
    
    # on each timestamp, decide total L & S gmv
    
    if neutral:
        cond_pos_sgnl = icom_dropna[col_sgnl]>0
        cond_neg_sgnl = icom_dropna[col_sgnl]<0
        
        c_gmv_long = icom_dropna.loc[cond_pos_sgnl, 'mv'].sum()
        c_gmv_short = - icom_dropna.loc[cond_neg_sgnl, 'mv'].sum()
        c_gmv_final = min([c_gmv_long, c_gmv_short])
        icom_dropna.loc[cond_pos_sgnl, 'mv'] = icom_dropna.loc[cond_pos_sgnl, 'mv'] / c_gmv_long * c_gmv_final
        icom_dropna.loc[cond_neg_sgnl, 'mv'] = icom_dropna.loc[cond_neg_sgnl, 'mv'] / c_gmv_short * c_gmv_final
        
    # calc trading return 
    
    icom_dropna['pnl_bc'] = icom_dropna['mv'] * icom_dropna[col_ret]
    
    # calc trading cost 
        
    icom_dropna = icom_dropna.sort_values(['Ticker', 'tm1d', 'ts15m_s'])
    icom_dropna.loc[icom_dropna['tm1d'].ne(icom_dropna['tm1d'].shift()), 'flg_sod'] = 1
    icom_dropna.loc[icom_dropna['tm1d'].ne(icom_dropna['tm1d'].shift(-1)), 'flg_eod'] = 1
    icom_dropna.loc[icom_dropna['flg_eod'].eq(1), 'mv'] = 0 # last ts should have no intraday signals
    
    icom_dropna['mv_m1ts'] = icom_dropna.groupby(['Ticker', 'tm1d'])['mv'].shift()
    icom_dropna['mv_m1ts'] = icom_dropna['mv_m1ts'].fillna(0)
    icom_dropna['trdd'] = icom_dropna['mv'] - icom_dropna['mv_m1ts']
    icom_dropna['trdd_abs'] = icom_dropna['trdd'].abs()
    
    icom_dropna['cost_stamp'] = icom_dropna['trdd_abs'] * 0.0002
    icom_dropna.loc[icom_dropna['trdd'].lt(0), 'cost_stamp'] = icom_dropna.loc[icom_dropna['trdd'].lt(0), 'trdd_abs'] * 0.0012
    icom_dropna['cost_inst'] = icom_dropna['spread'] * icom_dropna['trdd_abs'] * 0.16
    icom_dropna['cost_trans'] = 0.068 * ((icom_dropna['volatility']/np.sqrt(252))**0.6)\
                                * ((icom_dropna['trdd_abs']/icom_dropna['avgPVadj'])**0.5) \
                                * icom_dropna['trdd_abs']
    icom_dropna['cost_perm'] = 18.9 * ((icom_dropna['volatility']/np.sqrt(252))**2) \
                                * ((icom_dropna['trdd_abs']/icom_dropna['avgPVadj'])) \
                                * icom_dropna['trdd_abs']    

    icom_dropna['tcost'] = icom_dropna['cost_stamp'] + icom_dropna['cost_inst'] + \
                           icom_dropna['cost_trans'] + icom_dropna['cost_perm']
    
    icom_dropna['pnl_ac'] = icom_dropna['pnl_bc'] - icom_dropna['tcost']
    
    
    
    
    
    
    
    ret = icom_dropna.groupby('tm1d')['pnl_bc','pnl_ac'].sum()
    ret = ret.reset_index()
    ret = ret.dropna()
    ret['cumpnl_bc'] = ret['pnl_bc'].cumsum()
    ret['cumpnl_ac'] = ret['pnl_ac'].cumsum()
    
    sr_pnl_bc = np.round(ret['pnl_bc'].mean() / ret['pnl_bc'].std() * np.sqrt(252),2)
    sr_pnl_ac = np.round(ret['pnl_ac'].mean() / ret['pnl_ac'].std() * np.sqrt(252),2)
    
    mean_ret_bc = np.round( (icom_dropna['pnl_bc'].sum() / icom_dropna['gmv'].sum())*1e4,2)
    mean_ret_ac = np.round( (icom_dropna['pnl_ac'].sum() / icom_dropna['gmv'].sum())*1e4,2)
    
    ept = np.round( (icom_dropna['pnl_bc'].sum() / icom_dropna['trdd_abs'].sum())*1e4,2)
    to = np.round(icom_dropna['trdd_abs'].sum() / icom_dropna['gmv'].sum() * 100)
    
    ret = ret.set_index('tm1d')    
    
    fig1 = plt.figure(figsize=(10,8))
    ax1 = fig1.add_subplot(211)
    ax1.plot(ret['cumpnl_bc'])
    ax1.plot(ret['cumpnl_ac'])

    ax1.grid()
    ax1.set_ylabel(col_sgnl, fontsize = 20)
    
    ax1.text(0.01, 0.87, 'Annualized Sharpe: ' + str(sr_pnl_bc) + '(bc), ' +  str(sr_pnl_ac) + ' (ac) ', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.81, 'Daily Return on GMV: ' + str(mean_ret_bc) + ' bps (bc), ' + str(mean_ret_ac) + ' bps (ac)', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.75, 'Edge Per Trade: ' + str(ept) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.69, 'Turnover: ' + str(to) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    spos_gmvret = icom_dropna.groupby('tm1d')[['pnl_ac','gmv']].sum()
    spos_gmvret_number = spos_gmvret['pnl_ac'].sum() / spos_gmvret[spos_gmvret['gmv']>0]['gmv'].mean() / len(spos_gmvret) * 252
    spos_gmvret_number = round(spos_gmvret_number*100,2)
    ax1.text(0.01, 0.63, 'GMV Ret AC: ' + str(spos_gmvret_number) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fon
tsize = 10 )
    
    
    # plot gmv
    
    
    gmvlong = icom_dropna[icom_dropna['mv'] > 0].groupby(['tm1d','ts15m_e'])['gmv'].sum().reset_index()
    gmvlong = gmvlong.groupby('tm1d')['gmv'].mean().reset_index()
    gmvlong.columns = ['tm1d','long']
    gmvlong = gmvlong.set_index('tm1d')
    gmvshort = icom_dropna[icom_dropna['mv'] < 0].groupby(['tm1d','ts15m_e'])['gmv'].sum().reset_index()
    gmvshort = gmvshort.groupby('tm1d')['gmv'].mean().reset_index()
    gmvshort.columns = ['tm1d','short']
    gmvshort = gmvshort.set_index('tm1d')
    
    ax2 = fig1.add_subplot(212)
    gmv = pd.concat([gmvlong,gmvshort],axis=1)
    ax2.plot(gmv)    
    ax2.grid()
    ax2.set_ylabel('GMV', fontsize = 16)
    ax2.set_xlabel('Date',fontsize = 16)
    
    pnl_bc_tot = icom_dropna['pnl_bc'].sum()
    pnl_bc_hr1 = icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('0930','1030')]['pnl_bc'].sum() / pnl_bc_tot
    pnl_bc_hr1 = int(pnl_bc_hr1*100)
    pnl_bc_hr2 = icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('1030','1130')]['pnl_bc'].sum() / pnl_bc_tot
    pnl_bc_hr2 = int(pnl_bc_hr2*100)
    pnl_bc_hr3 = icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('1300','1400')]['pnl_bc'].sum() / pnl_bc_tot
    pnl_bc_hr3 = int(pnl_bc_hr3*100)
    pnl_bc_hr4 = icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('1400','1500')]['pnl_bc'].sum() / pnl_bc_tot
    pnl_bc_hr4 = int(pnl_bc_hr4*100)
    eff_bc_hr1 = pnl_bc_tot * pnl_bc_hr1 / 100 / icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('0930','1030')]['pnl_bc'].count()
    eff_bc_hr2 = pnl_bc_tot * pnl_bc_hr2 / 100 / icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('1030','1130')]['pnl_bc'].count()
    eff_bc_hr3 = pnl_bc_tot * pnl_bc_hr3 / 100 / icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('1300','1400')]['pnl_bc'].count()
    eff_bc_hr4 = pnl_bc_tot * pnl_bc_hr4 / 100 / icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('1400','1500')]['pnl_bc'].count()
    min_eff = min([abs(eff_bc_hr1),abs(eff_bc_hr2),abs(eff_bc_hr3),abs(eff_bc_hr4)])
    eff_bc_hr1 = np.round(eff_bc_hr1 / min_eff,2)
    eff_bc_hr2 = np.round(eff_bc_hr2 / min_eff,2)
    eff_bc_hr3 = np.round(eff_bc_hr3 / min_eff,2)
    eff_bc_hr4 = np.round(eff_bc_hr4 / min_eff,2)
    
    to = np.round(icom_dropna['trdd_abs'].sum() / icom_dropna['gmv'].sum() * 100)
    
    ax2.text(0.01, 0.93, 'Avg Instentaneous Long / Short Size: ' + str(np.round(gmvlong
['long'].mean()/1e6)) +' m  /  '\
                         + str(np.round(gmvshort['short'].mean()/1e6)) +' m', 
             verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.87, 'Total PNL (bc) by hour: ' +str(pnl_bc_hr1)+'% | '+ str(pnl_bc_hr2)\
                         +'% | '+ str(pnl_bc_hr3) +'% | ' + str(pnl_bc_hr4)+'%',
             verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.81, 'PNL (bc) efficiency score by hour: ' +str(eff_bc_hr1)+' | '+ str(eff_bc_hr2)\
                         +' | '+ str(eff_bc_hr3) +' | ' + str(eff_bc_hr4),
             verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.76, 'Turnover: ' + str(to) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    
    
    





def plot_pnl_cn_wquota(icom, col_sgnl = '', col_ret = 'rawret_p15m'):
    # col_sgnl must be a +ve/-ve number indicating number of clips
    # 
        
    
    # get data 
    
    icom['clip15m'] = (icom['avgPVadj']/16*0.02).apply(lambda x: min(x, 1e6)) # rmb clip capped at 1m rmb
    c1 = icom['clip15m'].gt( icom['quota'] / 2)
    icom.loc[c1, 'clip15m'] = icom.loc[c1, 'quota'] / 2
    icom_dropna = icom.dropna(subset = [col_sgnl, col_ret, 'clip15m']).copy()
    icom_dropna['mv'] = icom_dropna['clip15m'] * icom_dropna[col_sgnl]
    icom_dropna['gmv'] = icom_dropna['mv'].abs()
    
    
    # on each timestamp, decide total L & S gmv
    
    cond_pos_sgnl = icom_dropna[col_sgnl]>0
    cond_neg_sgnl = icom_dropna[col_sgnl]<0
    
    c_gmv_long = icom_dropna.loc[cond_pos_sgnl, 'mv'].sum()
    c_gmv_short = - icom_dropna.loc[cond_neg_sgnl, 'mv'].sum()
    c_gmv_final = min([c_gmv_long, c_gmv_short])
    icom_dropna.loc[cond_pos_sgnl, 'mv'] = icom_dropna.loc[cond_pos_sgnl, 'mv'] / c_gmv_long * c_gmv_final
    icom_dropna.loc[cond_neg_sgnl, 'mv'] = icom_dropna.loc[cond_neg_sgnl, 'mv'] / c_gmv_short * c_gmv_final
        
    # calc trading return
    
    icom_dropna['pnl_bc'] = icom_dropna['mv'] * icom_dropna[col_ret]
    
    # calc trading cost 
        
    icom_dropna = icom_dropna.sort_values(['Ticker', 'tm1d', 'ts15m_s'])
    icom_dropna.loc[icom_dropna['tm1d'].ne(icom_dropna['tm1d'].shift()), 'flg_sod'] = 1
    icom_dropna.loc[i
com_dropna['tm1d'].ne(icom_dropna['tm1d'].shift(-1)), 'flg_eod'] = 1
    icom_dropna.loc[icom_dropna['flg_eod'].eq(1), 'mv'] = 0 # last ts should have no intraday signals
    
    icom_dropna['mv_m1ts'] = icom_dropna.groupby(['Ticker', 'tm1d'])['mv'].shift()
    icom_dropna['mv_m1ts'] = icom_dropna['mv_m1ts'].fillna(0)
    icom_dropna['trdd'] = icom_dropna['mv'] - icom_dropna['mv_m1ts']
    icom_dropna['trdd_abs'] = icom_dropna['trdd'].abs()
    
    icom_dropna['cost_stamp'] = icom_dropna['trdd_abs'] * 0.0002
    icom_dropna.loc[icom_dropna['trdd'].lt(0), 'cost_stamp'] = icom_dropna.loc[icom_dropna['trdd'].lt(0), 'trdd_abs'] * 0.0012
    icom_dropna['cost_inst'] = icom_dropna['spread'] * icom_dropna['trdd_abs'] * 0.16
    icom_dropna['cost_trans'] = 0.068 * ((icom_dropna['volatility']/np.sqrt(252))**0.6)\
                                * ((icom_dropna['trdd_abs']/icom_dropna['avgPVadj'])**0.5) \
                                * icom_dropna['trdd_abs']
    icom_dropna['cost_perm'] = 18.9 * ((icom_dropna['volatility']/np.sqrt(252))**2) \
                                * ((icom_dropna['trdd_abs']/icom_dropna['avgPVadj'])) \
                                * icom_dropna['trdd_abs']    
    icom_dropna['tcost'] = icom_dropna['cost_stamp'] + icom_dropna['cost_inst'] + \
                           icom_dropna['cost_trans'] + icom_dropna['cost_perm']
    
    icom_dropna['pnl_ac'] = icom_dropna['pnl_bc'] - icom_dropna['tcost']
    
    
    
    
    
    
    
    ret = icom_dropna.groupby('tm1d')['pnl_bc','pnl_ac'].sum()
    ret = ret.reset_index()
    ret = ret.dropna()
    ret['cumpnl_bc'] = ret['pnl_bc'].cumsum()
    ret['cumpnl_ac'] = ret['pnl_ac'].cumsum()
    
    sr_pnl_bc = np.round(ret['pnl_bc'].mean() / ret['pnl_bc'].std() * np.sqrt(252),2)
    sr_pnl_ac = np.round(ret['pnl_ac'].mean() / ret['pnl_ac'].std() * np.sqrt(252),2)
    
    mean_ret_bc = np.round( (icom_dropna['pnl_bc'].sum() / icom_dropna['gmv'].sum())*1e4,2)
    mean_ret_ac = np.round( (icom_dropna['pnl_ac'].sum() / icom_dropna['gmv'].sum())*1e4,2)
    
    ept = np.round( (icom_dropna['pnl_bc'].sum() / icom_dropna['trdd_abs'].sum())*1e4,2)
    to = np.round(icom_dropna['trdd_abs'].sum() / icom_dropna['gmv'].sum() * 100)
    
    ret = ret.set_index('tm1d')    
    
    fig1 = plt.figure(figsize=(10,8))
    ax1 = fig1.add_subplot(211)
    ax1.plot(ret['cumpnl_bc'])
    ax1.plot(ret['cumpnl_ac'])

    ax1.grid()
    ax1.set_ylabel(col_sgnl, fontsize = 20)
    
    ax1.text(0.01, 0.87, 'A
nnualized Sharpe: ' + str(sr_pnl_bc) + '(bc), ' +  str(sr_pnl_ac) + ' (ac) ', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.81, 'Daily Return on GMV: ' + str(mean_ret_bc) + ' bps (bc), ' + str(mean_ret_ac) + ' bps (ac)', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.75, 'Edge Per Trade: ' + str(ept) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.69, 'Turnover: ' + str(to) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    spos_gmvret = icom_dropna.groupby('tm1d')[['pnl_ac','gmv']].sum()
    spos_gmvret_number = spos_gmvret['pnl_ac'].sum() / spos_gmvret[spos_gmvret['gmv']>0]['gmv'].mean() / len(spos_gmvret) * 252
    spos_gmvret_number = round(spos_gmvret_number*100,2)
    ax1.text(0.01, 0.63, 'GMV Ret AC: ' + str(spos_gmvret_number) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    
    
    # plot gmv
    
    
    gmvlong = icom_dropna[icom_dropna['mv'] > 0].groupby(['tm1d','ts15m_e'])['gmv'].sum().reset_index()
    gmvlong = gmvlong.groupby('tm1d')['gmv'].mean().reset_index()
    gmvlong.columns = ['tm1d','long']
    gmvlong = gmvlong.set_index('tm1d')
    gmvshort = icom_dropna[icom_dropna['mv'] < 0].groupby(['tm1d','ts15m_e'])['gmv'].sum().reset_index()
    gmvshort = gmvshort.groupby('tm1d')['gmv'].mean().reset_index()
    gmvshort.columns = ['tm1d','short']
    gmvshort = gmvshort.set_index('tm1d')
    
    ax2 = fig1.add_subplot(212)
    gmv = pd.concat([gmvlong,gmvshort],axis=1)
    ax2.plot(gmv)    
    ax2.grid()
    ax2.set_ylabel('GMV', fontsize = 16)
    ax2.set_xlabel('Date',fontsize = 16)
    
    pnl_bc_tot = icom_dropna['pnl_bc'].sum()
    pnl_bc_hr1 = icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('0930','1030')]['pnl_bc'].sum() / pnl_bc_tot
    pnl_bc_hr1 = int(pnl_bc_hr1*100)
    pnl_bc_hr2 = icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('1030','1130')]['pnl_bc'].sum() / pnl_bc_tot
    pnl_bc_hr2 = int(pnl_bc_hr2*100)
    pnl_bc_hr3 = icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('1300','1400')]['pnl_bc'].sum() / pnl_bc_tot
    pnl_bc_hr3 = int(pnl_bc_hr3*100)
    pn
l_bc_hr4 = icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('1400','1500')]['pnl_bc'].sum() / pnl_bc_tot
    pnl_bc_hr4 = int(pnl_bc_hr4*100)
    eff_bc_hr1 = pnl_bc_tot * pnl_bc_hr1 / 100 / icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('0930','1030')]['pnl_bc'].count()
    eff_bc_hr2 = pnl_bc_tot * pnl_bc_hr2 / 100 / icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('1030','1130')]['pnl_bc'].count()
    eff_bc_hr3 = pnl_bc_tot * pnl_bc_hr3 / 100 / icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('1300','1400')]['pnl_bc'].count()
    eff_bc_hr4 = pnl_bc_tot * pnl_bc_hr4 / 100 / icom_dropna[icom_dropna['ts15m_e'].dt.strftime('%H%M').between('1400','1500')]['pnl_bc'].count()
    min_eff = min([abs(eff_bc_hr1),abs(eff_bc_hr2),abs(eff_bc_hr3),abs(eff_bc_hr4)])
    eff_bc_hr1 = np.round(eff_bc_hr1 / min_eff,2)
    eff_bc_hr2 = np.round(eff_bc_hr2 / min_eff,2)
    eff_bc_hr3 = np.round(eff_bc_hr3 / min_eff,2)
    eff_bc_hr4 = np.round(eff_bc_hr4 / min_eff,2)
    
    to = np.round(icom_dropna['trdd_abs'].sum() / icom_dropna['gmv'].sum() * 100)
    
    ax2.text(0.01, 0.93, 'Avg Instentaneous Long / Short Size: ' + str(np.round(gmvlong['long'].mean()/1e6)) +' m  /  '\
                         + str(np.round(gmvshort['short'].mean()/1e6)) +' m', 
             verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.87, 'Total PNL (bc) by hour: ' +str(pnl_bc_hr1)+'% | '+ str(pnl_bc_hr2)\
                         +'% | '+ str(pnl_bc_hr3) +'% | ' + str(pnl_bc_hr4)+'%',
             verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.81, 'PNL (bc) efficiency score by hour: ' +str(eff_bc_hr1)+' | '+ str(eff_bc_hr2)\
                         +' | '+ str(eff_bc_hr3) +' | ' + str(eff_bc_hr4),
             verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.76, 'Turnover: ' + str(to) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    
    
    


