﻿#$%^&* featurepool_cn_graph_ret_corr_desc.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  7 09:38:17 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import os

import datetime

from sqlalchemy import create_engine
import urllib
import pyodbc


# to be scheduled on crontab at 5 am


#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------

save_path = '/export/dataprod/Feature_Pool_CN/featurepool_desc_graph_ret_corr'

conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))

today = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
today = pd.to_datetime(today.date())
today_str = today.strftime('%Y%m%d')




#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------

i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()



#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------

dates_existing = os.listdir(save_path)
dates_existing = [i.replace('.parquet','').replace('.','') for i in dates_existing]

dates_avail = i_cal[i_cal['T-1d'].lt(today) & i_cal['T-1d'].ge('2017-01-01')]
dates_avail['yyyymmdd'] = dates_avail['T-1d'].dt.strftime('%Y%m%d')

dates_to_query = dates_avail[~dates_avail['yyyymmdd'].isin(dates_existing)]
dates_to_query = dates_to_query.sort_values('T-1d')

dates_to_query_min_1h_str = (dates_to_query['T-1d'].min()-pd.to_timedelta('182 days')).strftime('%Y%m%d')



#------------------------------------------------------------------------------
### get all the return data needed
#------------------------------------------------------------------------------


i_mkt = pd.read_sql('''select Ticker, [T-1d], o2c_rawret as adjret_o_c
                    from [CNDBPROD].[dbo].[BARRA_GEM3L_o2c_rret]
                   
 with (nolock)
                    where datadate <= '{0}' and datadate > '{1}'
                    '''.format(today_str, dates_to_query_min_1h_str), conn)



#------------------------------------------------------------------------------
### query and calculate metrics
#------------------------------------------------------------------------------

for i,r  in dates_to_query.iterrows():
    
    # get date string
    
    t_1d_str = r['T-1d'].strftime('%Y%m%d')
    
    # get universe
    
    i_dtk = pd.read_sql('''select datadate as [T-1d], ticker as Ticker
                        from cndbprod.dbo.universe_all_cn_gem3l 
                        with (nolock)
                        where datadate = '{0}' 
                        '''.format(t_1d_str), conn)
    i_dtk = i_dtk.drop_duplicates(subset = ['T-1d', 'Ticker'], keep = 'last')
    
    # get market data
    
    t_mkt = i_mkt[(i_mkt['T-1d']<=r['T-1d'])&(i_mkt['T-1d']>=r['T-1d']-pd.to_timedelta('91 days'))]
    t_mkt_pv = t_mkt.pivot_table(index = 'T-1d', columns = 'Ticker', values = 'adjret_o_c')

    # calc correlation

    t_corr = t_mkt_pv.corr()
    t_corr.values[[np.arange(len(t_corr))]*2] = np.nan
    if len(t_corr) == 0:
        continue
    
    t_corr_mean = t_corr.mean(axis = 1)
    t_corr_mean = t_corr_mean.reset_index().rename(columns={0: 'ret_corr_mean'})
    
    # combine
                   
    icom = i_dtk.merge(t_corr_mean, on = ['Ticker'], how = 'left')
    icom = icom.merge(i_cal, on = 'T-1d', how = 'left')
    
    # output
    
    file_name = r['T-1d'].strftime('%Y.%m.%d.parquet')
    icom[['T-1d', 'DataDate', 'Ticker', 'ret_corr_mean']].to_parquet(os.path.join(save_path, file_name))
    
    os.system("chgrp summit_thzhang "+os.path.join(save_path, file_name)+";")
    os.system("chmod 770 "+os.path.join(save_path, file_name)+";")
    


