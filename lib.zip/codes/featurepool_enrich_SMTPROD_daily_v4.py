﻿#$%^&* featurepool_enrich_SMTPROD_daily_v4.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 11 14:49:57 2022

@author: thzhang
"""

import os
import gc

import pandas as pd
import numpy as np

import datetime
from featurepool_enrich_lib import orth, rerank

from sqlalchemy import create_engine
import urllib


# this is used for productionize alphas calculated from the FORMAT tables





#------------------------------------------------------------------------------
### folder / database mapping
#------------------------------------------------------------------------------


i_map = {'act':'F001_ACT_CN_FORMAT',
         'bar':'F001_BAR_CN_FORMAT',
         'canc':'F001_CANC_CN_FORMAT',
         'cav':'F001_CANC_CN_FORMAT',
         'd2m':'F001_TWAP2M_CN_FORMAT',
         'd3s':'F001_TWAP3S60S_CN_FORMAT',
         'd60s':'F001_TWAP3S60S_CN_FORMAT',
         'enft':'SMTCN_CHILDALPHA_F008_ERNFT_T2000_SLOW_LO',
         'enugdg':'SMTCN_CHILDALPHA_F008_ERNUG_T2000_SLOW_LO',
         'gb':'SMTCN_CHILDALPHA_F002_GBV2_T2000_SLOW_LS',
         'jm':'SMTCN_CHILDALPHA_F007_JM5d_T2000_SLOW_LO',
         'lt':'F001_LT_CN_FORMAT_ALL',
         'st':'F001_ST_CN_FORMAT_ALL',
         'nb':'SMTCN_CHILDALPHA_F004_NB_T2000_SLOW_LS',
         'pvar':'F001_PVAR_CN_FORMAT',
         'shsz':'F001_SHSZ_CN_FORMAT_ALL'}



#------------------------------------------------------------------------------
### create folders for new signals
#------------------------------------------------------------------------------

root = '/export/dataprod/Feature_Pool_CN'

for s in i_map.keys():
    if not os.path.exists(os.path.join(root, 'smtprod_enrich_'+s)):
        print(s)
        os.makedirs( os.path.join(root,'smtprod_enrich_'+s))





#------------------------------------------------------------------------------
### get 1800 universe
#------------------------------------------------------------------------------

# conn

conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))

# calendar

df_cd = pd.read_sql('''
                    select distinct TradeDate_next as DataDate
                    from CNDBPROD.dbo.Calendar_Dates_CN
                    ''',conn)
df_cd = df_cd.sort_values('DataDate')
df_cd = df_cd.reset_index(drop=True)
df_cd['T-1d'] = df_cd['DataDate'].shift()

# 1800 universe ###!!! need a prod-
mode table here ....

i_1800 = pd.read_sql('''select Ticker, DataDate as [T-1d] 
                    from cndbprod.dbo.universe_csi1800 ''', conn)
i_1800 = i_1800.drop_duplicates(subset=['Ticker','T-1d'],keep = 'last')

# barra

i_barra = pd.read_sql('''select Ticker, DataDate as [T-1d], GIND, w_ind, 
                   SRISK, BETA, MOMENTUM, SIZE, SIZENL, EARNYILD, RESVOL, GROWTH, BTOP, LEVERAGE, LIQUIDTY 
                   from cndbprod.dbo.universe_all_cn_gem3l''', conn)
i_barra = i_barra.drop_duplicates(subset=['Ticker','T-1d'],keep = 'last')

# combine

i_1800 = i_1800.merge(df_cd, on = ['T-1d'], how = 'left')
i_1800 = i_1800.merge(i_barra, on = ['Ticker', 'T-1d'], how = 'left')
i_1800 = i_1800.sort_values(['Ticker', 'T-1d'])
i_1800 = i_1800.drop_duplicates(subset = ['Ticker', 'T-1d'], keep = 'last')

i_1800_ind = pd.get_dummies(i_1800['w_ind'])
i_1800_ind.columns = ['wd'+str(c) for c in i_1800_ind.columns.tolist()]
i_1800 = pd.concat([i_1800, i_1800_ind], axis = 1)

cols_i = i_1800_ind.columns.tolist()
cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'SIZENL', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']

i_barra = None
i_1800_ind = None





#------------------------------------------------------------------------------
### helper - sql
#------------------------------------------------------------------------------


def get_sql_cndb(query):    
    engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;DATABASE=CNDBPROD;;UID=svc_tz_dbo;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
    return pd.read_sql_query(query, con=engine)



#-----------------------------------------------------------------------------
### ACT
#-----------------------------------------------------------------------------


# calculate query start date 

signal = 'act'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
    start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get FORMAT data

i_act = get_sql_cndb('''select * from cndbprod.dbo.F001_ACT_CN_FORMAT
                     where datadate >= '{0}' '''.format(start_dt))
i_pv = get_sql_cndb('''select Ticker, pv, DataDate from cndbprod.dbo.TRTH_PV_CN
                    where datadate >= '{0}' '''.format(start_dt))
i_pv['Ticker'] = i_pv['Ticker'].str[:6]
i_act = i_act.merge(i_pv, on = ['Ticker', 'DataDate'], how = 'left')
i_act['act'] =
 (i_act['pv_act_b_09301000'] - i_act['pv_act_s_09301000']) / i_act['pv']
i_act = i_act.sort_values(['Ticker', 'DataDate'])
i_act['act_t5d'] = i_act.groupby('Ticker').rolling(datetime.timedelta(days=7),min_periods=2,on='DataDate')['act'].mean().values
i_act['act_t10d'] = i_act.groupby('Ticker').rolling(datetime.timedelta(days=14),min_periods=5,on='DataDate')['act'].mean().values
i_act['act_t20d'] = i_act.groupby('Ticker').rolling(datetime.timedelta(days=28),min_periods=10,on='DataDate')['act'].mean().values
i_act['act_t40d'] = i_act.groupby('Ticker').rolling(datetime.timedelta(days=56),min_periods=20,on='DataDate')['act'].mean().values
i_act['act_t60d'] = i_act.groupby('Ticker').rolling(datetime.timedelta(days=84),min_periods=30,on='DataDate')['act'].mean().values
i_act = i_act.rename(columns = {'DataDate': 'T-1d'})
i_act = i_act[['Ticker', 'T-1d', 'act', 'act_t5d', 'act_t10d', 'act_t20d', 'act_t40d', 'act_t60d']]


# calculate alpha ###???

c1 = signal
sign1 = 1
c2 = signal+'_t5d'
sign2 = 1
c3 = signal+'_t10d'
sign3 = 1
c4 = signal+'_t20d'
sign4 = 1
c5 = signal+'_t40d'
sign5 = 1
c6 = signal+'_t60d'
sign6 = 1

icom = i_1800[i_1800['DataDate']>=start_dt].merge(i_act, on = ['Ticker', 'T-1d'], how = 'left')

icom[c1+'_t1d_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c1]+cols_f+cols_i].apply(lambda x: orth(x[c1], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c1+'_t1d_orthgem3l_sgnl'] = sign1 * icom.groupby('DataDate')[c1+'_t1d_orthgem3l'].apply(rerank)

icom[c2+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c2]+cols_f+cols_i].apply(lambda x: orth(x[c2], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c2+'_orthgem3l_sgnl'] = sign2* icom.groupby('DataDate')[c2+'_orthgem3l'].apply(rerank)

icom[c3+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c3]+cols_f+cols_i].apply(lambda x: orth(x[c3], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c3+'_orthgem3l_sgnl'] = sign3* icom.groupby('DataDate')[c3+'_orthgem3l'].apply(rerank)

icom[c4+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c4]+cols_f+cols_i].apply(lambda x: orth(x[c4], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c4+'_orthgem3l_sgnl'] = sign4* icom.groupby('DataDate')[c4+'_orthgem3l'].apply(rerank)

icom[c5+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c5]+cols_f+cols_i].apply(lambda x: orth(x[c5], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c5+'_orthgem3l_sgnl'] = sign5* icom.groupby('DataDate')[c5+'_orthgem3l'].apply(rerank)

icom[c6+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c6]+c
ols_f+cols_i].apply(lambda x: orth(x[c6], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c6+'_orthgem3l_sgnl'] = sign6* icom.groupby('DataDate')[c6+'_orthgem3l'].apply(rerank)


# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filename'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['filename'].drop_duplicates():
    if file not in existing_files:
        output_cols = [c1+'_t1d_orthgem3l_sgnl', c2+'_orthgem3l_sgnl', c3+'_orthgem3l_sgnl',
                       c4+'_orthgem3l_sgnl', c5+'_orthgem3l_sgnl', c6+'_orthgem3l_sgnl']
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal+'/'+file)






#-----------------------------------------------------------------------------
### BAR
#-----------------------------------------------------------------------------


# calculate query start date 

signal = 'bar'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
    start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get FORMAT data

i_bar = get_sql_cndb('''select * from cndbprod.dbo.F001_BAR_CN_FORMAT
                     where datadate>= '{0}' '''.format(start_dt))
i_bar['bar'] = i_bar['avg_b_v'] / i_bar['avg_a_v']
i_bar = i_bar.sort_values(['Ticker', 'DataDate'])
i_bar['bar_t5d'] = i_bar.groupby('Ticker').rolling(datetime.timedelta(days=7),min_periods=2,on='DataDate')['bar'].mean().values
i_bar['bar_t10d'] = i_bar.groupby('Ticker').rolling(datetime.timedelta(days=14),min_periods=5,on='DataDate')['bar'].mean().values
i_bar['bar_t20d'] = i_bar.groupby('Ticker').rolling(datetime.timedelta(days=28),min_periods=10,on='DataDate')['bar'].mean().values
i_bar['bar_t40d'] = i_bar.groupby('Ticker').rolling(datetime.timedelta(days=56),min_periods=20,on='DataDate')['bar'].mean().values
i_bar['bar_t60d'] = i_bar.groupby('Ticker').rolling(datetime.timedelta(days=84),min_periods=30,on='DataDate')['bar'].mean().values

i_bar = i_bar.rename(columns = {'DataDate': 'T-1d'})
i_bar = i_bar[['Ticker', 'T-1d', 'bar', 'bar_t5d', 'bar_t10d', 'bar_t20d', 'bar_t40d', 'bar_t60d']]


# calculate alpha


c1 = signal
sign1 = 1
c2 = signal+'_t5d'
sign2 = 1
c3 = signal+'_t10d'
sign3 = 1
c4 = signal+'_t20d'
sign4 = 1
c5 = signal+'_t40d'
sign5 = 1
c6 = signal+'_t60d'
sign6 = 1


icom = i_1800[i_1
800['DataDate']>=start_dt].merge(i_bar, on = ['Ticker', 'T-1d'], how = 'left')

icom[c1+'_t1d_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c1]+cols_f+cols_i].apply(lambda x: orth(x[c1], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c1+'_t1d_orthgem3l_sgnl'] = sign1 * icom.groupby('DataDate')[c1+'_t1d_orthgem3l'].apply(rerank)        

icom[c2+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c2]+cols_f+cols_i].apply(lambda x: orth(x[c2], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c2+'_orthgem3l_sgnl'] = sign2* icom.groupby('DataDate')[c2+'_orthgem3l'].apply(rerank)

icom[c3+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c3]+cols_f+cols_i].apply(lambda x: orth(x[c3], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c3+'_orthgem3l_sgnl'] = sign3* icom.groupby('DataDate')[c3+'_orthgem3l'].apply(rerank)

icom[c4+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c4]+cols_f+cols_i].apply(lambda x: orth(x[c4], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c4+'_orthgem3l_sgnl'] = sign4* icom.groupby('DataDate')[c4+'_orthgem3l'].apply(rerank)

icom[c5+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c5]+cols_f+cols_i].apply(lambda x: orth(x[c5], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c5+'_orthgem3l_sgnl'] = sign5* icom.groupby('DataDate')[c5+'_orthgem3l'].apply(rerank)

icom[c6+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c6]+cols_f+cols_i].apply(lambda x: orth(x[c6], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c6+'_orthgem3l_sgnl'] = sign6* icom.groupby('DataDate')[c6+'_orthgem3l'].apply(rerank)    



# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filename'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['filename'].drop_duplicates():
    if file not in existing_files:
        output_cols = [c1+'_t1d_orthgem3l_sgnl', c2+'_orthgem3l_sgnl', c3+'_orthgem3l_sgnl',
                       c4+'_orthgem3l_sgnl', c5+'_orthgem3l_sgnl', c6+'_orthgem3l_sgnl']
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal+'/'+file)




#-----------------------------------------------------------------------------
### CANC
#-----------------------------------------------------------------------------

# calculate query start date 

signal = 'canc'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
 
   start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get FORMAT data

i_canc = get_sql_cndb('''select * from cndbprod.dbo.F001_CANC_CN_FORMAT
                      where datadate>= '{0}' '''.format(start_dt))
i_canc['canc'] = i_canc['v_b_deleted'] / i_canc['v_b_added']
i_canc = i_canc.sort_values(['Ticker', 'DataDate'])
i_canc['canc_t5d'] = i_canc.groupby('Ticker').rolling(datetime.timedelta(days=7),min_periods=2,on='DataDate')['canc'].mean().values
i_canc['canc_t10d'] = i_canc.groupby('Ticker').rolling(datetime.timedelta(days=14),min_periods=5,on='DataDate')['canc'].mean().values
i_canc['canc_t20d'] = i_canc.groupby('Ticker').rolling(datetime.timedelta(days=28),min_periods=10,on='DataDate')['canc'].mean().values
i_canc['canc_t40d'] = i_canc.groupby('Ticker').rolling(datetime.timedelta(days=56),min_periods=20,on='DataDate')['canc'].mean().values
i_canc['canc_t60d'] = i_canc.groupby('Ticker').rolling(datetime.timedelta(days=84),min_periods=30,on='DataDate')['canc'].mean().values
i_canc = i_canc.rename(columns = {'DataDate': 'T-1d'})
i_canc = i_canc[['Ticker', 'T-1d', 'canc', 'canc_t5d', 'canc_t10d', 'canc_t20d', 'canc_t40d', 'canc_t60d']]


# calculate alpha


c1 = signal
sign1 = -1
c2 = signal+'_t5d'
sign2 = -1
c3 = signal+'_t10d'
sign3 = -1
c4 = signal+'_t20d'
sign4 = -1
c5 = signal+'_t40d'
sign5 = -1
c6 = signal+'_t60d'
sign6 = -1

icom = i_1800[i_1800['DataDate']>=start_dt].merge(i_canc, on = ['Ticker', 'T-1d'], how = 'left')

icom[c1+'_t1d_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c1]+cols_f+cols_i].apply(lambda x: orth(x[c1], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c1+'_t1d_orthgem3l_sgnl'] = sign1 * icom.groupby('DataDate')[c1+'_t1d_orthgem3l'].apply(rerank)        

icom[c2+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c2]+cols_f+cols_i].apply(lambda x: orth(x[c2], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c2+'_orthgem3l_sgnl'] = sign2* icom.groupby('DataDate')[c2+'_orthgem3l'].apply(rerank)

icom[c3+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c3]+cols_f+cols_i].apply(lambda x: orth(x[c3], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c3+'_orthgem3l_sgnl'] = sign3* icom.groupby('DataDate')[c3+'_orthgem3l'].apply(rerank)

icom[c4+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c4]+cols_f+cols_i].apply(lambda x: orth(x[c4], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c4+'_orthgem3l_sgnl'] = sign4* icom.groupby('DataDate')[c4+'_orthgem3l'].apply(rerank)

icom[c5+'_orthgem3l']
 = icom.groupby('DataDate')[['SRISK',c5]+cols_f+cols_i].apply(lambda x: orth(x[c5], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c5+'_orthgem3l_sgnl'] = sign5* icom.groupby('DataDate')[c5+'_orthgem3l'].apply(rerank)

icom[c6+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c6]+cols_f+cols_i].apply(lambda x: orth(x[c6], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c6+'_orthgem3l_sgnl'] = sign6* icom.groupby('DataDate')[c6+'_orthgem3l'].apply(rerank)    



# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filename'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['filename'].drop_duplicates():
    if file not in existing_files:
        output_cols = [c1+'_t1d_orthgem3l_sgnl', c2+'_orthgem3l_sgnl', c3+'_orthgem3l_sgnl',
                       c4+'_orthgem3l_sgnl', c5+'_orthgem3l_sgnl', c6+'_orthgem3l_sgnl']
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal+'/'+file)



#-----------------------------------------------------------------------------
### CAV
#-----------------------------------------------------------------------------

# calculate query start date 

signal = 'cav'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
    start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get FORMAT data

i_cav = get_sql_cndb('''select * from cndbprod.dbo.F001_CAV_CN_FORMAT
                     where datadate>= '{0}' '''.format(start_dt))
i_cav['cav'] = i_cav['ca_pv'] / i_cav['tot_pv']
i_cav = i_cav.sort_values(['Ticker', 'DataDate'])
i_cav['cav_t5d'] = i_cav.groupby('Ticker').rolling(datetime.timedelta(days=7),min_periods=2,on='DataDate')['cav'].mean().values
i_cav['cav_t10d'] = i_cav.groupby('Ticker').rolling(datetime.timedelta(days=14),min_periods=5,on='DataDate')['cav'].mean().values
i_cav['cav_t20d'] = i_cav.groupby('Ticker').rolling(datetime.timedelta(days=28),min_periods=10,on='DataDate')['cav'].mean().values
i_cav['cav_t40d'] = i_cav.groupby('Ticker').rolling(datetime.timedelta(days=56),min_periods=20,on='DataDate')['cav'].mean().values
i_cav['cav_t60d'] = i_cav.groupby('Ticker').rolling(datetime.timedelta(days=84),min_periods=30,on='DataDate')['cav'].mean().values
i_cav = i_cav.rename(columns = {'DataDate': 'T-1d'})
i_cav = i_cav[['Ticker', 'T-1d', 
'cav', 'cav_t5d', 'cav_t10d', 'cav_t20d', 'cav_t40d', 'cav_t60d']]


# calculate alpha


c1 = signal
sign1 = -1
c2 = signal+'_t5d'
sign2 = -1
c3 = signal+'_t10d'
sign3 = -1
c4 = signal+'_t20d'
sign4 = -1
c5 = signal+'_t40d'
sign5 = -1
c6 = signal+'_t60d'
sign6 = -1


icom = i_1800[i_1800['DataDate']>=start_dt].merge(i_cav, on = ['Ticker', 'T-1d'], how = 'left')

icom[c1+'_t1d_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c1]+cols_f+cols_i].apply(lambda x: orth(x[c1], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c1+'_t1d_orthgem3l_sgnl'] = sign1 * icom.groupby('DataDate')[c1+'_t1d_orthgem3l'].apply(rerank)        

icom[c2+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c2]+cols_f+cols_i].apply(lambda x: orth(x[c2], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c2+'_orthgem3l_sgnl'] = sign2* icom.groupby('DataDate')[c2+'_orthgem3l'].apply(rerank)

icom[c3+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c3]+cols_f+cols_i].apply(lambda x: orth(x[c3], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c3+'_orthgem3l_sgnl'] = sign3* icom.groupby('DataDate')[c3+'_orthgem3l'].apply(rerank)

icom[c4+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c4]+cols_f+cols_i].apply(lambda x: orth(x[c4], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c4+'_orthgem3l_sgnl'] = sign4* icom.groupby('DataDate')[c4+'_orthgem3l'].apply(rerank)

icom[c5+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c5]+cols_f+cols_i].apply(lambda x: orth(x[c5], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c5+'_orthgem3l_sgnl'] = sign5* icom.groupby('DataDate')[c5+'_orthgem3l'].apply(rerank)

icom[c6+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c6]+cols_f+cols_i].apply(lambda x: orth(x[c6], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c6+'_orthgem3l_sgnl'] = sign6* icom.groupby('DataDate')[c6+'_orthgem3l'].apply(rerank)    



# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filename'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['filename'].drop_duplicates():
    if file not in existing_files:
        output_cols = [c1+'_t1d_orthgem3l_sgnl', c2+'_orthgem3l_sgnl', c3+'_orthgem3l_sgnl',
                       c4+'_orthgem3l_sgnl', c5+'_orthgem3l_sgnl', c6+'_orthgem3l_sgnl']
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal+'/'+file)


#-----------------------------------------------
------------------------------
### LT
#-----------------------------------------------------------------------------

# calculate query start date 

signal = 'lt'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
    start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get FORMAT data

i_lt = get_sql_cndb('''select * from cndbprod.dbo.F001_LT_CN_FORMAT_ALL
                    where datadate>= '{0}' '''.format(start_dt))
i_lt = i_lt.sort_values(['Ticker', 'DataDate'])
i_lt['lt_t5d'] = i_lt.groupby('Ticker').rolling(datetime.timedelta(days=7),min_periods=2,on='DataDate')['descriptor'].mean().values
i_lt['lt_t10d'] = i_lt.groupby('Ticker').rolling(datetime.timedelta(days=14),min_periods=5,on='DataDate')['descriptor'].mean().values
i_lt['lt_t20d'] = i_lt.groupby('Ticker').rolling(datetime.timedelta(days=28),min_periods=10,on='DataDate')['descriptor'].mean().values
i_lt['lt_t40d'] = i_lt.groupby('Ticker').rolling(datetime.timedelta(days=56),min_periods=20,on='DataDate')['descriptor'].mean().values
i_lt['lt_t60d'] = i_lt.groupby('Ticker').rolling(datetime.timedelta(days=84),min_periods=30,on='DataDate')['descriptor'].mean().values
i_lt['lt'] = i_lt['descriptor']
i_lt = i_lt[['Ticker', 'DataDate', 'lt', 'lt_t5d', 'lt_t10d', 'lt_t20d', 'lt_t40d', 'lt_t60d']]


# calculate alpha


c1 = signal
sign1 = 1
c2 = signal+'_t5d'
sign2 = 1
c3 = signal+'_t10d'
sign3 = 1
c4 = signal+'_t20d'
sign4 = 1
c5 = signal+'_t40d'
sign5 = 1
c6 = signal+'_t60d'
sign6 = 1

icom = i_1800[i_1800['DataDate']>=start_dt].merge(i_lt, on = ['Ticker', 'DataDate'], how = 'left')

icom[c1+'_t1d_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c1]+cols_f+cols_i].apply(lambda x: orth(x[c1], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c1+'_t1d_orthgem3l_sgnl'] = sign1 * icom.groupby('DataDate')[c1+'_t1d_orthgem3l'].apply(rerank)        

icom[c2+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c2]+cols_f+cols_i].apply(lambda x: orth(x[c2], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c2+'_orthgem3l_sgnl'] = sign2* icom.groupby('DataDate')[c2+'_orthgem3l'].apply(rerank)

icom[c3+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c3]+cols_f+cols_i].apply(lambda x: orth(x[c3], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c3+'_orthgem3l_sgnl'] = sign3* icom.groupby('DataDate')[c3+'_orthgem3l'].apply(rerank)

icom[c4+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c4]+cols_f+cols_i].apply(lambd
a x: orth(x[c4], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c4+'_orthgem3l_sgnl'] = sign4* icom.groupby('DataDate')[c4+'_orthgem3l'].apply(rerank)

icom[c5+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c5]+cols_f+cols_i].apply(lambda x: orth(x[c5], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c5+'_orthgem3l_sgnl'] = sign5* icom.groupby('DataDate')[c5+'_orthgem3l'].apply(rerank)

icom[c6+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c6]+cols_f+cols_i].apply(lambda x: orth(x[c6], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c6+'_orthgem3l_sgnl'] = sign6* icom.groupby('DataDate')[c6+'_orthgem3l'].apply(rerank)   



# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filename'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['filename'].drop_duplicates():
    if file not in existing_files:
        output_cols = [c1+'_t1d_orthgem3l_sgnl', c2+'_orthgem3l_sgnl', c3+'_orthgem3l_sgnl',
                       c4+'_orthgem3l_sgnl', c5+'_orthgem3l_sgnl', c6+'_orthgem3l_sgnl']
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal+'/'+file)


#-----------------------------------------------------------------------------
### ST
#-----------------------------------------------------------------------------

# calculate query start date 

signal = 'st'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
    start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get FORMAT data

i_st = get_sql_cndb('''select * from cndbprod.dbo.F001_ST_CN_FORMAT_ALL
                    where datadate>= '{0}' '''.format(start_dt))
i_st = i_st.sort_values(['Ticker', 'DataDate'])
i_st['st_t5d'] = i_st.groupby('Ticker').rolling(datetime.timedelta(days=7),min_periods=2,on='DataDate')['descriptor'].mean().values
i_st['st_t10d'] = i_st.groupby('Ticker').rolling(datetime.timedelta(days=14),min_periods=5,on='DataDate')['descriptor'].mean().values
i_st['st_t20d'] = i_st.groupby('Ticker').rolling(datetime.timedelta(days=28),min_periods=10,on='DataDate')['descriptor'].mean().values
i_st['st_t40d'] = i_st.groupby('Ticker').rolling(datetime.timedelta(days=56),min_periods=20,on='DataDate')['descriptor'].mean().values
i_st['st_t60d'] = i_st.groupby('Ticker').rolling(datetime.timedelta(days=84),min_
periods=30,on='DataDate')['descriptor'].mean().values
i_st['st'] = i_st['descriptor']
i_st = i_st[['Ticker', 'DataDate', 'st', 'st_t5d', 'st_t10d', 'st_t20d', 'st_t40d', 'st_t60d']]


# calculate alpha


c1 = signal
sign1 = -1
c2 = signal+'_t5d'
sign2 = -1
c3 = signal+'_t10d'
sign3 = -1
c4 = signal+'_t20d'
sign4 = -1
c5 = signal+'_t40d'
sign5 = -1
c6 = signal+'_t60d'
sign6 = -1


icom = i_1800[i_1800['DataDate']>=start_dt].merge(i_st, on = ['Ticker', 'DataDate'], how = 'left')

icom[c1+'_t1d_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c1]+cols_f+cols_i].apply(lambda x: orth(x[c1], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c1+'_t1d_orthgem3l_sgnl'] = sign1 * icom.groupby('DataDate')[c1+'_t1d_orthgem3l'].apply(rerank)        

icom[c2+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c2]+cols_f+cols_i].apply(lambda x: orth(x[c2], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c2+'_orthgem3l_sgnl'] = sign2* icom.groupby('DataDate')[c2+'_orthgem3l'].apply(rerank)

icom[c3+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c3]+cols_f+cols_i].apply(lambda x: orth(x[c3], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c3+'_orthgem3l_sgnl'] = sign3* icom.groupby('DataDate')[c3+'_orthgem3l'].apply(rerank)

icom[c4+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c4]+cols_f+cols_i].apply(lambda x: orth(x[c4], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c4+'_orthgem3l_sgnl'] = sign4* icom.groupby('DataDate')[c4+'_orthgem3l'].apply(rerank)

icom[c5+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c5]+cols_f+cols_i].apply(lambda x: orth(x[c5], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c5+'_orthgem3l_sgnl'] = sign5* icom.groupby('DataDate')[c5+'_orthgem3l'].apply(rerank)

icom[c6+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c6]+cols_f+cols_i].apply(lambda x: orth(x[c6], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c6+'_orthgem3l_sgnl'] = sign6* icom.groupby('DataDate')[c6+'_orthgem3l'].apply(rerank)     



# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filename'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['filename'].drop_duplicates():
    if file not in existing_files:
        output_cols = [c1+'_t1d_orthgem3l_sgnl', c2+'_orthgem3l_sgnl', c3+'_orthgem3l_sgnl',
                       c4+'_orthgem3l_sgnl', c5+'_orthgem3l_sgnl', c6+'_orthgem3l_sgnl']
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet
('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal+'/'+file)



#-----------------------------------------------------------------------------
### PVAR
#-----------------------------------------------------------------------------

# calculate query start date 

signal = 'pvar'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
    start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get FORMAT data

i_pvar = get_sql_cndb('''select * from cndbprod.dbo.F001_PVAR_CN_FORMAT
                      where datadate>= '{0}' '''.format(start_dt))
i_pvar = i_pvar.sort_values(['Ticker', 'DataDate'])
i_pvar['pvar_t5d'] = i_pvar.groupby('Ticker').rolling(datetime.timedelta(days=7),min_periods=2,on='DataDate')['order_p_dv_p_ask_var'].mean().values
i_pvar['pvar_t10d'] = i_pvar.groupby('Ticker').rolling(datetime.timedelta(days=14),min_periods=5,on='DataDate')['order_p_dv_p_ask_var'].mean().values
i_pvar['pvar_t20d'] = i_pvar.groupby('Ticker').rolling(datetime.timedelta(days=28),min_periods=10,on='DataDate')['order_p_dv_p_ask_var'].mean().values
i_pvar['pvar_t40d'] = i_pvar.groupby('Ticker').rolling(datetime.timedelta(days=56),min_periods=20,on='DataDate')['order_p_dv_p_ask_var'].mean().values
i_pvar['pvar_t60d'] = i_pvar.groupby('Ticker').rolling(datetime.timedelta(days=84),min_periods=30,on='DataDate')['order_p_dv_p_ask_var'].mean().values

i_pvar['pvar'] = i_pvar['order_p_dv_p_ask_var']
i_pvar = i_pvar.rename(columns = {'DataDate': 'T-1d'})
i_pvar = i_pvar[['Ticker', 'T-1d', 'pvar', 'pvar_t5d', 'pvar_t10d', 'pvar_t20d', 'pvar_t40d', 'pvar_t60d']]


# calculate alpha


c1 = signal
sign1 = -1
c2 = signal+'_t5d'
sign2 = -1
c3 = signal+'_t10d'
sign3 = -1
c4 = signal+'_t20d'
sign4 = -1
c5 = signal+'_t40d'
sign5 = -1
c6 = signal+'_t60d'
sign6 = -1


icom = i_1800[i_1800['DataDate']>=start_dt].merge(i_pvar, on = ['Ticker', 'T-1d'], how = 'left')

icom[c1+'_t1d_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c1]+cols_f+cols_i].apply(lambda x: orth(x[c1], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c1+'_t1d_orthgem3l_sgnl'] = sign1 * icom.groupby('DataDate')[c1+'_t1d_orthgem3l'].apply(rerank)        

icom[c2+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c2]+cols_f+cols_i].apply(lambda x: orth(x[c2], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c2+'_orthgem3l_sgnl'] = sign2* icom.groupby('DataDate')[c2+'_orthgem3l'].apply(rerank)

icom[c3+'_orthgem3l'] = icom.
groupby('DataDate')[['SRISK',c3]+cols_f+cols_i].apply(lambda x: orth(x[c3], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c3+'_orthgem3l_sgnl'] = sign3* icom.groupby('DataDate')[c3+'_orthgem3l'].apply(rerank)

icom[c4+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c4]+cols_f+cols_i].apply(lambda x: orth(x[c4], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c4+'_orthgem3l_sgnl'] = sign4* icom.groupby('DataDate')[c4+'_orthgem3l'].apply(rerank)

icom[c5+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c5]+cols_f+cols_i].apply(lambda x: orth(x[c5], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c5+'_orthgem3l_sgnl'] = sign5* icom.groupby('DataDate')[c5+'_orthgem3l'].apply(rerank)

icom[c6+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c6]+cols_f+cols_i].apply(lambda x: orth(x[c6], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c6+'_orthgem3l_sgnl'] = sign6* icom.groupby('DataDate')[c6+'_orthgem3l'].apply(rerank)    



# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filename'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['filename'].drop_duplicates():
    if file not in existing_files:
        output_cols = [c1+'_t1d_orthgem3l_sgnl', c2+'_orthgem3l_sgnl', c3+'_orthgem3l_sgnl',
                       c4+'_orthgem3l_sgnl', c5+'_orthgem3l_sgnl', c6+'_orthgem3l_sgnl']
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal+'/'+file)




#-----------------------------------------------------------------------------
### SHSZ
#-----------------------------------------------------------------------------

# calculate query start date 

signal = 'shsz'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
    start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get FORMAT data

i_shsz = get_sql_cndb('''select * from cndbprod.dbo.F001_SHSZ_CN_FORMAT_ALL
                      where datadate>= '{0}' '''.format(start_dt))
i_shsz = i_shsz.sort_values(['Ticker', 'DataDate'])
i_shsz['shsz_t5d'] = i_shsz.groupby('Ticker').rolling(datetime.timedelta(days=7),min_periods=2,on='DataDate')['descriptor'].mean().values
i_shsz['shsz_t10d'] = i_shsz.groupby('Ticker').rolling(datetime.timedelta(days=14),min_periods=5,on='DataDate')['descriptor'].mean().values
i_shsz['shsz_t20d'] = i
_shsz.groupby('Ticker').rolling(datetime.timedelta(days=28),min_periods=10,on='DataDate')['descriptor'].mean().values
i_shsz['shsz_t40d'] = i_shsz.groupby('Ticker').rolling(datetime.timedelta(days=56),min_periods=20,on='DataDate')['descriptor'].mean().values
i_shsz['shsz_t60d'] = i_shsz.groupby('Ticker').rolling(datetime.timedelta(days=84),min_periods=30,on='DataDate')['descriptor'].mean().values

i_shsz['shsz'] = i_shsz['descriptor']
i_shsz = i_shsz[['Ticker', 'DataDate', 'shsz', 'shsz_t5d', 'shsz_t10d', 'shsz_t20d', 'shsz_t40d', 'shsz_t60d']]


# calculate alpha


c1 = signal
sign1 = 1
c2 = signal+'_t5d'
sign2 = 1
c3 = signal+'_t10d'
sign3 = 1
c4 = signal+'_t20d'
sign4 = 1
c5 = signal+'_t40d'
sign5 = 1
c6 = signal+'_t60d'
sign6 = 1


icom = i_1800[i_1800['DataDate']>=start_dt].merge(i_shsz, on = ['Ticker', 'DataDate'], how = 'left')

icom[c1+'_t1d_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c1]+cols_f+cols_i].apply(lambda x: orth(x[c1], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c1+'_t1d_orthgem3l_sgnl'] = sign1 * icom.groupby('DataDate')[c1+'_t1d_orthgem3l'].apply(rerank)        

icom[c2+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c2]+cols_f+cols_i].apply(lambda x: orth(x[c2], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c2+'_orthgem3l_sgnl'] = sign2* icom.groupby('DataDate')[c2+'_orthgem3l'].apply(rerank)

icom[c3+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c3]+cols_f+cols_i].apply(lambda x: orth(x[c3], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c3+'_orthgem3l_sgnl'] = sign3* icom.groupby('DataDate')[c3+'_orthgem3l'].apply(rerank)

icom[c4+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c4]+cols_f+cols_i].apply(lambda x: orth(x[c4], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c4+'_orthgem3l_sgnl'] = sign4* icom.groupby('DataDate')[c4+'_orthgem3l'].apply(rerank)

icom[c5+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c5]+cols_f+cols_i].apply(lambda x: orth(x[c5], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c5+'_orthgem3l_sgnl'] = sign5* icom.groupby('DataDate')[c5+'_orthgem3l'].apply(rerank)

icom[c6+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c6]+cols_f+cols_i].apply(lambda x: orth(x[c6], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c6+'_orthgem3l_sgnl'] = sign6* icom.groupby('DataDate')[c6+'_orthgem3l'].apply(rerank)    



# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filename'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['file
name'].drop_duplicates():
    if file not in existing_files:
        output_cols = [c1+'_t1d_orthgem3l_sgnl', c2+'_orthgem3l_sgnl', c3+'_orthgem3l_sgnl',
                       c4+'_orthgem3l_sgnl', c5+'_orthgem3l_sgnl', c6+'_orthgem3l_sgnl']
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal+'/'+file)




#-----------------------------------------------------------------------------
### d2m
#-----------------------------------------------------------------------------

# calculate query start date 

signal = 'd2m'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
    start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get FORMAT data

i_2m = get_sql_cndb('''select * from cndbprod.dbo.F001_TWAP2M_CN_FORMAT
                    where datadate>= '{0}' '''.format(start_dt))
i_2m = i_2m.sort_values(['Ticker', 'DataDate'])
i_2m['cnt_0s_tot'] = i_2m['cnt_0s_tot'].fillna(0)
i_2m['cnt_1s_tot'] = i_2m['cnt_1s_tot'].fillna(0)
i_2m['cnt_2s_tot'] = i_2m['cnt_2s_tot'].fillna(0)
i_2m['cnt_lt3s'] = i_2m['cnt_0s_tot'] + i_2m['cnt_1s_tot'] + i_2m['cnt_2s_tot']
i_2m['d2m'] = i_2m['cnt_lt3s'] / i_2m['cnt_tot']
i_2m = i_2m.sort_values(['Ticker', 'DataDate'])
i_2m['d2m_t5d'] = i_2m.groupby('Ticker').rolling(datetime.timedelta(days=7),min_periods=2,on='DataDate')['d2m'].mean().values
i_2m['d2m_t10d'] = i_2m.groupby('Ticker').rolling(datetime.timedelta(days=14),min_periods=5,on='DataDate')['d2m'].mean().values
i_2m['d2m_t20d'] = i_2m.groupby('Ticker').rolling(datetime.timedelta(days=28),min_periods=10,on='DataDate')['d2m'].mean().values
i_2m['d2m_t40d'] = i_2m.groupby('Ticker').rolling(datetime.timedelta(days=56),min_periods=20,on='DataDate')['d2m'].mean().values
i_2m['d2m_t60d'] = i_2m.groupby('Ticker').rolling(datetime.timedelta(days=84),min_periods=30,on='DataDate')['d2m'].mean().values

i_2m = i_2m.rename(columns = {'DataDate': 'T-1d'})
i_2m = i_2m[['Ticker', 'T-1d', 'd2m', 'd2m_t5d', 'd2m_t10d', 'd2m_t20d', 'd2m_t40d', 'd2m_t60d']]


# calculate alpha


c1 = signal
sign1 = -1
c2 = signal+'_t5d'
sign2 = -1
c3 = signal+'_t10d'
sign3 = -1
c4 = signal+'_t20d'
sign4 = -1
c5 = signal+'_t40d'
sign5 = -1
c6 = signal+'_t60d'
sign6 = -1

icom = i_1800[i_1800['DataDate']>=start_dt].merge(i_2m, on = ['Ticker', 'T-1d'], how = 'left')

icom[c1+'_t1d_orthgem
3l'] = icom.groupby('DataDate')[['SRISK',c1]+cols_f+cols_i].apply(lambda x: orth(x[c1], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c1+'_t1d_orthgem3l_sgnl'] = sign1 * icom.groupby('DataDate')[c1+'_t1d_orthgem3l'].apply(rerank)        

icom[c2+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c2]+cols_f+cols_i].apply(lambda x: orth(x[c2], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c2+'_orthgem3l_sgnl'] = sign2* icom.groupby('DataDate')[c2+'_orthgem3l'].apply(rerank)

icom[c3+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c3]+cols_f+cols_i].apply(lambda x: orth(x[c3], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c3+'_orthgem3l_sgnl'] = sign3* icom.groupby('DataDate')[c3+'_orthgem3l'].apply(rerank)

icom[c4+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c4]+cols_f+cols_i].apply(lambda x: orth(x[c4], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c4+'_orthgem3l_sgnl'] = sign4* icom.groupby('DataDate')[c4+'_orthgem3l'].apply(rerank)

icom[c5+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c5]+cols_f+cols_i].apply(lambda x: orth(x[c5], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c5+'_orthgem3l_sgnl'] = sign5* icom.groupby('DataDate')[c5+'_orthgem3l'].apply(rerank)

icom[c6+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c6]+cols_f+cols_i].apply(lambda x: orth(x[c6], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c6+'_orthgem3l_sgnl'] = sign6* icom.groupby('DataDate')[c6+'_orthgem3l'].apply(rerank)    



# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filename'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['filename'].drop_duplicates():
    if file not in existing_files:
        output_cols = [c1+'_t1d_orthgem3l_sgnl', c2+'_orthgem3l_sgnl', c3+'_orthgem3l_sgnl',
                       c4+'_orthgem3l_sgnl', c5+'_orthgem3l_sgnl', c6+'_orthgem3l_sgnl']
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal+'/'+file)




#-----------------------------------------------------------------------------
### d3s 
#-----------------------------------------------------------------------------

# calculate query start date 

signal = 'd3s'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
    start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get F
ORMAT data

i_3s60s = get_sql_cndb('''select * from cndbprod.dbo.F001_TWAP3S60S_CN_FORMAT
                       where datadate>= '{0}' '''.format(start_dt))
i_3s60s = i_3s60s.sort_values(['Ticker', 'DataDate'])
i_3s60s['d3s_t5d'] = i_3s60s.groupby('Ticker').rolling(datetime.timedelta(days=7),min_periods=2,on='DataDate')['twap_cnt_prd3s_pct'].mean().values
i_3s60s['d3s_t10d'] = i_3s60s.groupby('Ticker').rolling(datetime.timedelta(days=14),min_periods=5,on='DataDate')['twap_cnt_prd3s_pct'].mean().values
i_3s60s['d3s_t20d'] = i_3s60s.groupby('Ticker').rolling(datetime.timedelta(days=28),min_periods=10,on='DataDate')['twap_cnt_prd3s_pct'].mean().values
i_3s60s['d3s_t40d'] = i_3s60s.groupby('Ticker').rolling(datetime.timedelta(days=56),min_periods=20,on='DataDate')['twap_cnt_prd3s_pct'].mean().values
i_3s60s['d3s_t60d'] = i_3s60s.groupby('Ticker').rolling(datetime.timedelta(days=84),min_periods=30,on='DataDate')['twap_cnt_prd3s_pct'].mean().values

i_3s60s['d3s'] = i_3s60s['twap_cnt_prd3s_pct']
i_3s60s = i_3s60s.rename(columns = {'DataDate': 'T-1d'})
i_3s60s = i_3s60s[['Ticker', 'T-1d', 'd3s', 'd3s_t5d', 'd3s_t10d', 'd3s_t20d', 'd3s_t40d', 'd3s_t60d']]


# calculate alpha


c1 = signal
sign1 = 1
c2 = signal+'_t5d'
sign2 = 1
c3 = signal+'_t10d'
sign3 = 1
c4 = signal+'_t20d'
sign4 = 1
c5 = signal+'_t40d'
sign5 = 1
c6 = signal+'_t60d'
sign6 = 1


icom = i_1800[i_1800['DataDate']>=start_dt].merge(i_3s60s, on = ['Ticker', 'T-1d'], how = 'left')

icom[c1+'_t1d_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c1]+cols_f+cols_i].apply(lambda x: orth(x[c1], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c1+'_t1d_orthgem3l_sgnl'] = sign1 * icom.groupby('DataDate')[c1+'_t1d_orthgem3l'].apply(rerank)        

icom[c2+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c2]+cols_f+cols_i].apply(lambda x: orth(x[c2], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c2+'_orthgem3l_sgnl'] = sign2* icom.groupby('DataDate')[c2+'_orthgem3l'].apply(rerank)

icom[c3+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c3]+cols_f+cols_i].apply(lambda x: orth(x[c3], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c3+'_orthgem3l_sgnl'] = sign3* icom.groupby('DataDate')[c3+'_orthgem3l'].apply(rerank)

icom[c4+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c4]+cols_f+cols_i].apply(lambda x: orth(x[c4], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c4+'_orthgem3l_sgnl'] = sign4* icom.groupby('DataDate')[c4+'_orthgem3l'].apply(rerank)

icom[c5+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',
c5]+cols_f+cols_i].apply(lambda x: orth(x[c5], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c5+'_orthgem3l_sgnl'] = sign5* icom.groupby('DataDate')[c5+'_orthgem3l'].apply(rerank)

icom[c6+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c6]+cols_f+cols_i].apply(lambda x: orth(x[c6], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c6+'_orthgem3l_sgnl'] = sign6* icom.groupby('DataDate')[c6+'_orthgem3l'].apply(rerank)     



# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filename'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['filename'].drop_duplicates():
    if file not in existing_files:
        output_cols = [c1+'_t1d_orthgem3l_sgnl', c2+'_orthgem3l_sgnl', c3+'_orthgem3l_sgnl',
                       c4+'_orthgem3l_sgnl', c5+'_orthgem3l_sgnl', c6+'_orthgem3l_sgnl']
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal+'/'+file)



#-----------------------------------------------------------------------------
### d60s 
#-----------------------------------------------------------------------------


# calculate query start date 

signal = 'd60s'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
    start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get FORMAT data

i_3s60s = get_sql_cndb('''select * from cndbprod.dbo.F001_TWAP3S60S_CN_FORMAT
                       where datadate>= '{0}' '''.format(start_dt))
i_3s60s = i_3s60s.sort_values(['Ticker', 'DataDate'])
i_3s60s['d60s_t5d'] = i_3s60s.groupby('Ticker').rolling(datetime.timedelta(days=7),min_periods=2,on='DataDate')['twap_cnt_prd60s_pct'].mean().values
i_3s60s['d60s_t10d'] = i_3s60s.groupby('Ticker').rolling(datetime.timedelta(days=14),min_periods=5,on='DataDate')['twap_cnt_prd60s_pct'].mean().values
i_3s60s['d60s_t20d'] = i_3s60s.groupby('Ticker').rolling(datetime.timedelta(days=28),min_periods=10,on='DataDate')['twap_cnt_prd60s_pct'].mean().values
i_3s60s['d60s_t40d'] = i_3s60s.groupby('Ticker').rolling(datetime.timedelta(days=56),min_periods=20,on='DataDate')['twap_cnt_prd60s_pct'].mean().values
i_3s60s['d60s_t60d'] = i_3s60s.groupby('Ticker').rolling(datetime.timedelta(days=84),min_periods=30,on='DataDate')['twap_cnt_prd60s_pct'].mean().values


i_3s60s['d60s'] = i_3s60s['twap_cnt_prd60s_pc
t']
i_3s60s = i_3s60s.rename(columns = {'DataDate': 'T-1d'})
i_3s60s = i_3s60s[['Ticker', 'T-1d', 'd60s', 'd60s_t5d', 'd60s_t10d', 'd60s_t20d', 'd60s_t40d', 'd60s_t60d']]


# calculate alpha


c1 = signal
sign1 = 1
c2 = signal+'_t5d'
sign2 = 1
c3 = signal+'_t10d'
sign3 = 1
c4 = signal+'_t20d'
sign4 = 1
c5 = signal+'_t40d'
sign5 = 1
c6 = signal+'_t60d'
sign6 = 1

icom = i_1800[i_1800['DataDate']>=start_dt].merge(i_3s60s, on = ['Ticker', 'T-1d'], how = 'left')

icom[c1+'_t1d_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c1]+cols_f+cols_i].apply(lambda x: orth(x[c1], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c1+'_t1d_orthgem3l_sgnl'] = sign1 * icom.groupby('DataDate')[c1+'_t1d_orthgem3l'].apply(rerank)        

icom[c2+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c2]+cols_f+cols_i].apply(lambda x: orth(x[c2], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c2+'_orthgem3l_sgnl'] = sign2* icom.groupby('DataDate')[c2+'_orthgem3l'].apply(rerank)

icom[c3+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c3]+cols_f+cols_i].apply(lambda x: orth(x[c3], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c3+'_orthgem3l_sgnl'] = sign3* icom.groupby('DataDate')[c3+'_orthgem3l'].apply(rerank)

icom[c4+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c4]+cols_f+cols_i].apply(lambda x: orth(x[c4], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c4+'_orthgem3l_sgnl'] = sign4* icom.groupby('DataDate')[c4+'_orthgem3l'].apply(rerank)

icom[c5+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c5]+cols_f+cols_i].apply(lambda x: orth(x[c5], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c5+'_orthgem3l_sgnl'] = sign5* icom.groupby('DataDate')[c5+'_orthgem3l'].apply(rerank)

icom[c6+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',c6]+cols_f+cols_i].apply(lambda x: orth(x[c6], x[cols_f], x[cols_i], x['SRISK'])).values
icom[c6+'_orthgem3l_sgnl'] = sign6* icom.groupby('DataDate')[c6+'_orthgem3l'].apply(rerank)



# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filename'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['filename'].drop_duplicates():
    if file not in existing_files:
        output_cols = [c1+'_t1d_orthgem3l_sgnl', c2+'_orthgem3l_sgnl', c3+'_orthgem3l_sgnl',
                       c4+'_orthgem3l_sgnl', c5+'_orthgem3l_sgnl', c6+'_orthgem3l_sgnl']
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet('/export/dataprod/Featu
re_Pool_CN/smtprod_enrich_'+signal+'/'+file)



#-----------------------------------------------------------------------------
### jm
#-----------------------------------------------------------------------------

# calculate query start date 

signal = 'jm'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
    start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get FORMAT data

i_jm = get_sql_cndb('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F007_JM5d_T2000_SLOW_LO
                    where datadate>= '{0}' '''.format(start_dt))
i_jm = i_jm.rename(columns = {'alpha': 'jm_sgnl'})
i_jm = i_jm[['Ticker', 'DataDate', 'jm_sgnl']]

icom = i_1800[i_1800['DataDate']>=start_dt].merge(i_jm, on = ['Ticker', 'DataDate'], how = 'left')


# calculate alpha

# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filename'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['filename'].drop_duplicates():
    if file not in existing_files:
        output_cols = [signal+'_sgnl']        
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal+'/'+file)





#-----------------------------------------------------------------------------
### ernft
#-----------------------------------------------------------------------------

# calculate query start date 

signal = 'enft'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
    start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get FORMAT data

i_ernft = get_sql_cndb('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F008_ERNFT_T2000_SLOW_LO
                       where datadate>= '{0}' '''.format(start_dt))
i_ernft = i_ernft.rename(columns = {'alpha': 'enft_sgnl'})
i_ernft = i_ernft[['Ticker', 'DataDate', 'enft_sgnl']]

icom = i_1800[i_1800['DataDate']>=start_dt].merge(i_ernft, on = ['Ticker', 'DataDate'], how = 'left')


# calculate alpha

# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filename'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['filename'].drop_duplicates():
    if file not in existing_files:
        output_cols = [signal+'_sgnl']
        icom = i
com.reset_index(drop=True)
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal+'/'+file)




#-----------------------------------------------------------------------------
### ernugdg
#-----------------------------------------------------------------------------

# calculate query start date 

signal = 'enugdg'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
    start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get FORMAT data

i_ernugdg = get_sql_cndb('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F008_ERNUG_T2000_SLOW_LO
                         where datadate>= '{0}' '''.format(start_dt))
i_ernugdg = i_ernugdg.rename(columns = {'alpha': 'enugdg_sgnl'})
i_ernugdg = i_ernugdg[['Ticker', 'DataDate', 'enugdg_sgnl']]

icom = i_1800[i_1800['DataDate']>=start_dt].merge(i_ernugdg, on = ['Ticker', 'DataDate'], how = 'left')


# calculate alpha

# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filename'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['filename'].drop_duplicates():
    if file not in existing_files:
        output_cols = [signal+'_sgnl']        
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal+'/'+file)





#-----------------------------------------------------------------------------
### nb
#-----------------------------------------------------------------------------

# calculate query start date 

signal = 'nb'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
    start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get FORMAT data

i_nb = get_sql_cndb('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F004_NB_T2000_SLOW_LS
                    where datadate>= '{0}' '''.format(start_dt))
i_nb = i_nb.rename(columns = {'alpha': 'nb_sgnl'})
i_nb = i_nb[['Ticker', 'DataDate', 'nb_sgnl']]

icom = i_1800[i_1800['DataDate']>=start_dt].merge(i_nb, on = ['Ticker', 'DataDate'], how = 'left')


# calculate alpha

# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filen
ame'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['filename'].drop_duplicates():
    if file not in existing_files:
        output_cols = [signal+'_sgnl']        
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal+'/'+file)




#-----------------------------------------------------------------------------
### gb
#-----------------------------------------------------------------------------

# calculate query start date 

signal = 'gb'

if os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal) == []:
    start_dt = '2017-01-01'
else:
    start_dt = (datetime.datetime.today() - datetime.timedelta(days=91)).strftime('%Y-%m-%d')


# get FORMAT data

i_gb = get_sql_cndb('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F002_GBV2_T2000_SLOW_LS
                    where datadate>= '{0}' '''.format(start_dt))
i_gb = i_gb.rename(columns = {'alpha': 'gb_sgnl'})
i_gb = i_gb[['Ticker', 'DataDate', 'gb_sgnl']]

icom = i_1800[i_1800['DataDate']>=start_dt].merge(i_gb, on = ['Ticker', 'DataDate'], how = 'left')


# calculate alpha

# output

existing_files = os.listdir('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal)
icom['filename'] = icom['DataDate'].dt.strftime('%Y%m%d.parquet')
for file in icom['filename'].drop_duplicates():
    if file not in existing_files:
        output_cols = [signal+'_sgnl']        
        t_data = icom.loc[icom['filename']==file, ['Ticker', 'DataDate', 'T-1d'] + output_cols]
        t_data.to_parquet('/export/dataprod/Feature_Pool_CN/smtprod_enrich_'+signal+'/'+file)






#-----------------------------------------------------------------------------
### accss
#-----------------------------------------------------------------------------

os.system("chgrp summit_thzhang /export/dataprod/Feature_Pool_CN/smtprod_enrich* -R")
os.system("chmod 770 /export/dataprod/Feature_Pool_CN/smtprod_enrich* -R")
