﻿#$%^&* featurepool_enrich_daily.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 11 14:49:57 2022

@author: thzhang
"""

import os
import gc

import pandas as pd
import numpy as np

import datetime
from featurepool_enrich_lib import orth

from sqlalchemy import create_engine
import urllib


# this is not ready for production yet. 



### helper


    
def uniformed_rank(input_data, str_type=None):
    # transform(uniformed_rank) 
    # returns nan if apply(uniformed_rank)
    
    # str_type = 'zero_cutoff'
    
    t_input_data_type = ''
    if isinstance(input_data, (pd.core.series.Series)):
        t_r = input_data.rank(method='min')
        t_index = input_data.index
        t_input_data_type = 'Series'
    elif isinstance(input_data, (np.ndarray)):
        t_r = pd.Series(input_data).rank(method='min')
        input_data = pd.Series(input_data)
        t_input_data_type = 'ndarray'
    elif isinstance(input_data, (list)):
        input_data = pd.Series(input_data)
        t_r = pd.Series(input_data).rank(method='min')
        t_input_data_type = 'list'
    else:
        raise Exception("input array type error.")
    
    if len(t_r)<2:
        return pd.Series([np.nan]*len(t_r), index = t_index)
    
    if t_r.notnull().sum()<=1:
        return pd.Series([np.nan]*len(t_r), index = t_index)
    
    if str_type is None:
        return t_r.sub((t_r.min() + t_r.max())/2).divide(t_r.max()-t_r.min())*2
        #return t_r.sub(t_r.mean()).divide(t_r.max()-t_r.min())*2
        
    elif str_type == 'zero_cutoff':
        i01 = input_data.values #ndarray
        o1 = np.array([np.nan] * len(i01))
        o1[i01>0] = pd.Series(i01[i01>0]).rank().values / max(pd.Series(i01[i01>0]).rank().max(),pd.Series(i01[i01<0]).rank().max())
        o1[i01<0] = pd.Series(i01[i01<0]).rank(ascending=False).values / max(pd.Series(i01[i01>0]).rank().max(), pd.Series(i01[i01<0]).rank().max()) * (-1)  
        
        if t_input_data_type == 'Series':
            return pd.Series(o1, index = t_index)
        else:
            return pd.Series(o1)
    else:
        raise Exception("str_type param input error.")


### find all the featurepool_desc folders with data in it

root = '/export/dataprod/Feature_Pool_CN'
i_feature_folders = os.listdir(root)
i_feature_folders = [i for i in i_feature_folders if i[:17]=='featurepool_desc_']
i_feature_folders = [i for i in i_feature_folders if len(os.listdir(os.path.join(root,i))) > 0]


### create enrich folde
rs for all the featurepool_desc folders

for f in i_feature_folders:
    if not os.path.exists(os.path.join(root, f.replace('featurepool_desc_','featurepool_enrich_'))):
        print(f)
        os.makedirs( os.path.join(root, f.replace('featurepool_desc_','featurepool_enrich_')) )




### get 1800 universe

conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))

i_1k8 = pd.read_sql('''select Ticker, DataDate as [T-1d] 
                    from cndbprod.dbo.universe_csi1800 ''', conn)
i_1k8 = i_1k8.drop_duplicates(subset=['Ticker','T-1d'],keep = 'last')
i_barra = pd.read_sql('''select Ticker, DataDate as [T-1d], GIND, 
                   SRISK, BETA, MOMENTUM, SIZE, SIZENL, EARNYILD, RESVOL, GROWTH, BTOP, LEVERAGE, LIQUIDTY 
                   from cndbprod.dbo.universe_all_cn_gem3l''', conn)
i_barra = i_barra.drop_duplicates(subset=['Ticker','T-1d'],keep = 'last')
i_1k8 = i_1k8.merge(i_barra, on = ['Ticker', 'T-1d'], how = 'left')
i_1k8 = i_1k8.sort_values(['Ticker', 'T-1d'])
i_1k8 = i_1k8.drop_duplicates(subset = ['Ticker', 'T-1d'], keep = 'last')

i_1k8_ind = pd.get_dummies(i_1k8['GIND'])
i_1k8 = pd.concat([i_1k8, i_1k8_ind], axis = 1)
cols_i = i_1k8_ind.columns.tolist()
cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'SIZENL', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']



### calendar

df_cd = pd.read_sql('''
                    select distinct TradeDate_next as DataDate
                    from CNDBPROD.dbo.Calendar_Dates_CN
                    ''',conn)
df_cd = df_cd.sort_values('DataDate')
df_cd = df_cd.reset_index(drop=True)
df_cd['T-1d'] = df_cd['DataDate'].shift()





### loop thru folders and enrich all dates 
# for f in i_feature_folders: 
#     t1 = pd.read_parquet(os.path.join(root, f, os.listdir(os.path.join(root, f))[0]))
#     print(f)
#     print (t1.columns)

root = '/export/dataprod/Feature_Pool_CN'

for f in i_feature_folders: 
    #print(f)
    
    # get all dates (T-1d) from desc folders    
    files_desc = os.listdir(os.path.join(root, f))
    files_desc = [i.replace('.','').replace('parquet','.parquet') for i in files_desc]    
    
    files_desc_df = pd.DataFrame({'files_desc_name': files_desc})
    files_desc_df['desc_t_1d'] = pd.to_datetime(files_desc_df['files_desc_name'].str.split('.').str[0], format='%Y%m%d')
    files_desc_df = files_desc_df.merge(df_cd, left_o
n='desc_t_1d', right_on='T-1d')
    files_desc_df['desc_t0d'] = files_desc_df['DataDate'].dt.strftime('%Y%m%d.parquet')    
    files_desc_t0d_lst = files_desc_df['desc_t0d'].tolist()
    
    # get all dates (DataDate) from enrich folders
    files_enrich = os.listdir(os.path.join(root, f.replace('featurepool_desc_','featurepool_enrich_')))
        
    # calculate date range
    files_diff = list(set(files_desc_t0d_lst).difference(set(files_enrich)))
    if len(files_diff) == 0:
        continue
    date_diff = [pd.to_datetime(i.replace('.parquet',''),format='%Y%m%d') for i in files_diff]
    date_start = pd.to_datetime(min(files_diff).replace('.parquet',''),format='%Y%m%d') - pd.to_timedelta('56 days')
    file_start = date_start.strftime('%Y.%m.%d.parquet')
    date_end = pd.to_datetime(max(files_diff).replace('.parquet',''),format='%Y%m%d')
    file_end = date_end.strftime('%Y.%m.%d.parquet')
    
    
    # get descriptor data within date range
    
    i_desc = pd.concat([pd.read_parquet(os.path.join(root,f,i)) \
                        for i in os.listdir(os.path.join(root, f)) \
                        if (i>=file_start) & (i<file_end)], axis = 0) ###!!!
    i_desc = i_desc.sort_values(['Ticker', 'T-1d'])
    i_desc = i_desc.drop_duplicates(subset = ['Ticker', 'T-1d'], keep = 'last')    
    i_desc = i_desc.merge(i_1k8, on = ['Ticker', 'T-1d'], how = 'inner')
    
    if f == 'featurepool_desc_suntime_ugdg_e':
        i_desc['np_pct_up_t1q_sgnl'] = i_desc.groupby('T-1d')['np_pct_up_t1q'].apply(uniformed_rank)
        i_desc = i_desc[['Ticker','DataDate','T-1d','np_pct_up_t1q_sgnl']]
    if f == 'featurepool_desc_trod_apb':
        name = 'apb_B_pTRD_vwap'
        i_desc[name+'_ma20d'] = i_desc.groupby('Ticker').rolling(datetime.timedelta(days=28),on='T-1d',min_periods=10)[name].mean().values
        i_desc[name+'_ma20d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name+'_ma20d']+cols_f+cols_i].apply(lambda x: orth(x[name+'_ma20d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma20d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')[name+'_ma20d'+'_orthgem3l'].apply(uniformed_rank)        
        i_desc[name+'_ma1d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name]+cols_f+cols_i].apply(lambda x: orth(x[name], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma1d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')[name+'_ma1d'+'_orthgem3l'].apply(uniformed_rank)
        i_desc = i_desc[['Ticker','DataDate','T-1d',name+'_
ma20d'+'_orthgem3l_sgnl',name+'_ma1d'+'_orthgem3l_sgnl']]
    if f == 'featurepool_desc_order_3s':
        name = 'twap3s_order_pctoftot'
        i_desc[name+'_ma20d'] = i_desc.groupby('Ticker').rolling(datetime.timedelta(days=28),on='T-1d',min_periods=10)[name].mean().values
        i_desc[name+'_ma20d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name+'_ma20d']+cols_f+cols_i].apply(lambda x: orth(x[name+'_ma20d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma20d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')[name+'_ma20d'+'_orthgem3l'].apply(uniformed_rank)        
        i_desc[name+'_ma1d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name]+cols_f+cols_i].apply(lambda x: orth(x[name], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma1d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')[name+'_ma1d'+'_orthgem3l'].apply(uniformed_rank)
        i_desc = i_desc[['Ticker','DataDate','T-1d',name+'_ma20d'+'_orthgem3l_sgnl',name+'_ma1d'+'_orthgem3l_sgnl']]
    if f == 'featurepool_desc_order_60s':
        name = 'twap60s_order_pctoftot'
        i_desc[name+'_ma20d'] = i_desc.groupby('Ticker').rolling(datetime.timedelta(days=28),on='T-1d',min_periods=10)[name].mean().values
        i_desc[name+'_ma20d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name+'_ma20d']+cols_f+cols_i].apply(lambda x: orth(x[name+'_ma20d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma20d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')[name+'_ma20d'+'_orthgem3l'].apply(uniformed_rank)        
        i_desc[name+'_ma1d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name]+cols_f+cols_i].apply(lambda x: orth(x[name], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma1d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')[name+'_ma1d'+'_orthgem3l'].apply(uniformed_rank)
        i_desc = i_desc[['Ticker','DataDate','T-1d',name+'_ma20d'+'_orthgem3l_sgnl',name+'_ma1d'+'_orthgem3l_sgnl']]
    if f == 'featurepool_desc_trade_large':
        name = 'trade_large_desc'
        i_desc[name+'_ma20d'] = i_desc.groupby('Ticker').rolling(datetime.timedelta(days=28),on='T-1d',min_periods=10)[name].mean().values
        i_desc[name+'_ma20d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name+'_ma20d']+cols_f+cols_i].apply(lambda x: orth(x[name+'_ma20d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma20d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')[name+'_ma20d'+'_orthgem3l'].apply(uniformed_rank)        
        i_desc
[name+'_ma1d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name]+cols_f+cols_i].apply(lambda x: orth(x[name], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma1d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')[name+'_ma1d'+'_orthgem3l'].apply(uniformed_rank)
        i_desc = i_desc[['Ticker','DataDate','T-1d',name+'_ma20d'+'_orthgem3l_sgnl',name+'_ma1d'+'_orthgem3l_sgnl']]
    if f == 'featurepool_desc_order_0920cancel':
        name = 'cancel_b'
        i_desc[name+'_ma20d'] = i_desc.groupby('Ticker').rolling(datetime.timedelta(days=28),on='T-1d',min_periods=10)[name].mean().values
        i_desc[name+'_ma20d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name+'_ma20d']+cols_f+cols_i].apply(lambda x: orth(x[name+'_ma20d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma20d'+'_orthgem3l_sgnl'] = -i_desc.groupby('T-1d')[name+'_ma20d'+'_orthgem3l'].apply(uniformed_rank)        
        i_desc[name+'_ma1d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name]+cols_f+cols_i].apply(lambda x: orth(x[name], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma1d'+'_orthgem3l_sgnl'] = -i_desc.groupby('T-1d')[name+'_ma1d'+'_orthgem3l'].apply(uniformed_rank)
        i_desc = i_desc[['Ticker','DataDate','T-1d',name+'_ma20d'+'_orthgem3l_sgnl',name+'_ma1d'+'_orthgem3l_sgnl']]        
    if f == 'featurepool_desc_reversal':
        name = 'o2c_bret'
        i_desc[name+'_ma20d'] = i_desc.groupby('Ticker').rolling(datetime.timedelta(days=28),on='T-1d',min_periods=10)[name].mean().values
        i_desc[name+'_ma20d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name+'_ma20d']+cols_f+cols_i].apply(lambda x: orth(x[name+'_ma20d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma20d'+'_orthgem3l_sgnl'] = -i_desc.groupby('T-1d')[name+'_ma20d'+'_orthgem3l'].apply(uniformed_rank)        
        i_desc[name+'_ma1d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name]+cols_f+cols_i].apply(lambda x: orth(x[name], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma1d'+'_orthgem3l_sgnl'] = -i_desc.groupby('T-1d')[name+'_ma1d'+'_orthgem3l'].apply(uniformed_rank)
        i_desc = i_desc[['Ticker','DataDate','T-1d',name+'_ma20d'+'_orthgem3l_sgnl',name+'_ma1d'+'_orthgem3l_sgnl']]     
    if f == 'featurepool_desc_suntime_coverage':
        i_desc['organ_cnt'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK','organ_cnt']+cols_f+cols_i].apply(lambda x: orth(x['organ_cnt'], x[cols_f], x[cols_i], x['SRIS
K'])).values
        i_desc['organ_cnt'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')['organ_cnt'+'_orthgem3l'].apply(uniformed_rank)     
        i_desc = i_desc[['Ticker','DataDate','T-1d','organ_cnt'+'_orthgem3l_sgnl']]        
    if f == 'featurepool_desc_order_bidask_size_ratio':
        name = 'ba_ratio_1000'
        i_desc[name+'_ma20d'] = i_desc.groupby('Ticker').rolling(datetime.timedelta(days=28),on='T-1d',min_periods=10)[name].mean().values
        i_desc[name+'_ma20d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name+'_ma20d']+cols_f+cols_i].apply(lambda x: orth(x[name+'_ma20d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma20d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')[name+'_ma20d'+'_orthgem3l'].apply(uniformed_rank)        
        i_desc[name+'_ma1d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name]+cols_f+cols_i].apply(lambda x: orth(x[name], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma1d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')[name+'_ma1d'+'_orthgem3l'].apply(uniformed_rank)
        i_desc = i_desc[['Ticker','DataDate','T-1d',name+'_ma20d'+'_orthgem3l_sgnl',name+'_ma1d'+'_orthgem3l_sgnl']]
    if f == 'featurepool_desc_graph_ret_corr':
        i_desc['ret_corr_mean'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK','ret_corr_mean']+cols_f+cols_i].apply(lambda x: orth(x['ret_corr_mean'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc['ret_corr_mean'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')['ret_corr_mean'+'_orthgem3l'].apply(uniformed_rank)     
        i_desc = i_desc[['Ticker','DataDate','T-1d','ret_corr_mean'+'_orthgem3l_sgnl']]
    if f == 'featurepool_desc_mf_holding':
        i_desc['mf_active_pctOfSO'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK','mf_active_pctOfSO']+cols_f+cols_i].apply(lambda x: orth(x['mf_active_pctOfSO'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc['mf_active_pctOfSO'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')['mf_active_pctOfSO'+'_orthgem3l'].apply(uniformed_rank)     
        i_desc = i_desc[['Ticker','DataDate','T-1d','mf_active_pctOfSO'+'_orthgem3l_sgnl']]
    if f == 'featurepool_desc_nb_flow_std':
        i_desc['nb_absflow_dv_v_abs_ma20d'] = i_desc.groupby('Ticker').rolling(datetime.timedelta(days=28),on='T-1d',min_periods=10)['nb_absflow_dv_v_abs'].mean().values
        i_desc['nb_absflow_dv_v_abs_ma20d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK','nb_absflow_dv_v_abs_ma20d']+cols_f+cols_i].apply(lambda x: orth(x['nb_a
bsflow_dv_v_abs_ma20d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc['nb_absflow_dv_v_abs_ma20d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')['nb_absflow_dv_v_abs_ma20d'+'_orthgem3l'].apply(uniformed_rank)     
        i_desc = i_desc[['Ticker','DataDate','T-1d','nb_absflow_dv_v_abs_ma20d'+'_orthgem3l_sgnl']]
    if f == 'featurepool_desc_nb_pctofso':
        i_desc['bb_pctofso'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK','bb_pctofso']+cols_f+cols_i].apply(lambda x: orth(x['bb_pctofso'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc['bb_pctofso'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')['bb_pctofso'+'_orthgem3l'].apply(uniformed_rank)     
        i_desc = i_desc[['Ticker','DataDate','T-1d','bb_pctofso'+'_orthgem3l_sgnl']]
    if f == 'featurepool_desc_order_price_std':
        name = 'order_p_dv_p_ask_var'
        i_desc[name+'_ma20d'] = i_desc.groupby('Ticker').rolling(datetime.timedelta(days=28),on='T-1d',min_periods=10)[name].mean().values
        i_desc[name+'_ma20d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name+'_ma20d']+cols_f+cols_i].apply(lambda x: orth(x[name+'_ma20d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma20d'+'_orthgem3l_sgnl'] = -i_desc.groupby('T-1d')[name+'_ma20d'+'_orthgem3l'].apply(uniformed_rank)        
        i_desc[name+'_ma1d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name]+cols_f+cols_i].apply(lambda x: orth(x[name], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma1d'+'_orthgem3l_sgnl'] = -i_desc.groupby('T-1d')[name+'_ma1d'+'_orthgem3l'].apply(uniformed_rank)
        i_desc = i_desc[['Ticker','DataDate','T-1d',name+'_ma20d'+'_orthgem3l_sgnl',name+'_ma1d'+'_orthgem3l_sgnl']]        
    if f == 'featurepool_desc_trade_active':
        name = 'actN_09301000_dv_pv'
        i_desc[name+'_ma20d'] = i_desc.groupby('Ticker').rolling(datetime.timedelta(days=28),on='T-1d',min_periods=10)[name].mean().values
        i_desc[name+'_ma20d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name+'_ma20d']+cols_f+cols_i].apply(lambda x: orth(x[name+'_ma20d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma20d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')[name+'_ma20d'+'_orthgem3l'].apply(uniformed_rank)        
        i_desc[name+'_ma1d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name]+cols_f+cols_i].apply(lambda x: orth(x[name], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma1d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1
d')[name+'_ma1d'+'_orthgem3l'].apply(uniformed_rank)
        i_desc = i_desc[['Ticker','DataDate','T-1d',name+'_ma20d'+'_orthgem3l_sgnl',name+'_ma1d'+'_orthgem3l_sgnl']]
    if f == 'featurepool_desc_trade_mktc':
        name = 'v_mktc_pct'
        i_desc[name+'_ma20d'] = i_desc.groupby('Ticker').rolling(datetime.timedelta(days=28),on='T-1d',min_periods=10)[name].mean().values
        i_desc[name+'_ma20d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name+'_ma20d']+cols_f+cols_i].apply(lambda x: orth(x[name+'_ma20d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma20d'+'_orthgem3l_sgnl'] = - i_desc.groupby('T-1d')[name+'_ma20d'+'_orthgem3l'].apply(uniformed_rank)        
        i_desc[name+'_ma1d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name]+cols_f+cols_i].apply(lambda x: orth(x[name], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma1d'+'_orthgem3l_sgnl'] = - i_desc.groupby('T-1d')[name+'_ma1d'+'_orthgem3l'].apply(uniformed_rank)
        i_desc = i_desc[['Ticker','DataDate','T-1d',name+'_ma20d'+'_orthgem3l_sgnl',name+'_ma1d'+'_orthgem3l_sgnl']]
    if f == 'featurepool_desc_trade_pqcorr':        
        i_desc['pq_dpct_corr_t20d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK','pq_dpct_corr_t20d']+cols_f+cols_i].apply(lambda x: orth(x['pq_dpct_corr_t20d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc['pq_dpct_corr_t20d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')['pq_dpct_corr_t20d'+'_orthgem3l'].apply(uniformed_rank)     
        i_desc = i_desc[['Ticker','DataDate','T-1d','pq_dpct_corr_t20d'+'_orthgem3l_sgnl']]
    if f == 'featurepool_desc_trade_skew':
        name = 'skew_5min_10001430'
        i_desc[name+'_ma20d'] = i_desc.groupby('Ticker').rolling(datetime.timedelta(days=28),on='T-1d',min_periods=10)[name].mean().values
        i_desc[name+'_ma20d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name+'_ma20d']+cols_f+cols_i].apply(lambda x: orth(x[name+'_ma20d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma20d'+'_orthgem3l_sgnl'] = - i_desc.groupby('T-1d')[name+'_ma20d'+'_orthgem3l'].apply(uniformed_rank)        
        i_desc[name+'_ma1d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name]+cols_f+cols_i].apply(lambda x: orth(x[name], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma1d'+'_orthgem3l_sgnl'] = - i_desc.groupby('T-1d')[name+'_ma1d'+'_orthgem3l'].apply(uniformed_rank)
        i_desc = i_desc[['Ticker','DataDate','T-1d',name+'_ma20d'+'_
orthgem3l_sgnl',name+'_ma1d'+'_orthgem3l_sgnl']]        
    if f == 'featurepool_desc_trade_small':
        name = 'trade_small_desc'
        i_desc[name+'_ma20d'] = i_desc.groupby('Ticker').rolling(datetime.timedelta(days=28),on='T-1d',min_periods=10)[name].mean().values
        i_desc[name+'_ma20d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name+'_ma20d']+cols_f+cols_i].apply(lambda x: orth(x[name+'_ma20d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma20d'+'_orthgem3l_sgnl'] = - i_desc.groupby('T-1d')[name+'_ma20d'+'_orthgem3l'].apply(uniformed_rank)        
        i_desc[name+'_ma1d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK',name]+cols_f+cols_i].apply(lambda x: orth(x[name], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc[name+'_ma1d'+'_orthgem3l_sgnl'] = - i_desc.groupby('T-1d')[name+'_ma1d'+'_orthgem3l'].apply(uniformed_rank)
        i_desc = i_desc[['Ticker','DataDate','T-1d',name+'_ma20d'+'_orthgem3l_sgnl',name+'_ma1d'+'_orthgem3l_sgnl']]
    if f == 'featurepool_desc_odbk_bidask_size_ratio':
        i_desc['unseen_b_dv_s_ma5d'] = i_desc.groupby('Ticker').rolling(datetime.timedelta(days=7),on='T-1d',min_periods=3)['unseen_b_dv_s'].mean().values
        i_desc['unseen_b_dv_s_ma5d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK','unseen_b_dv_s_ma5d']+cols_f+cols_i].apply(lambda x: orth(x['unseen_b_dv_s_ma5d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc['unseen_b_dv_s_ma5d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')['unseen_b_dv_s_ma5d'+'_orthgem3l'].apply(uniformed_rank)
        i_desc['unseen_b_dv_s_ma1d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK','unseen_b_dv_s']+cols_f+cols_i].apply(lambda x: orth(x['unseen_b_dv_s'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc['unseen_b_dv_s_ma1d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')['unseen_b_dv_s_ma1d'+'_orthgem3l'].apply(uniformed_rank)     
        i_desc = i_desc[['Ticker','DataDate','T-1d','unseen_b_dv_s_ma5d'+'_orthgem3l_sgnl','unseen_b_dv_s_ma1d'+'_orthgem3l_sgnl']]
    if f == 'featurepool_desc_odbk_bidask_std_ratio':
        i_desc['bidask_vstd_gt10_ma5d'] = i_desc.groupby('Ticker').rolling(datetime.timedelta(days=7),on='T-1d',min_periods=3)['bidask_vstd_gt10'].mean().values
        i_desc['bidask_vstd_gt10_ma5d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK','bidask_vstd_gt10_ma5d']+cols_f+cols_i].apply(lambda x: orth(x['bidask_vstd_gt10_ma5d'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc['bidask_vstd_gt10_m
a5d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')['bidask_vstd_gt10_ma5d'+'_orthgem3l'].apply(uniformed_rank)   
        i_desc['bidask_vstd_gt10_ma1d'+'_orthgem3l'] = i_desc.groupby('T-1d')[['SRISK','bidask_vstd_gt10']+cols_f+cols_i].apply(lambda x: orth(x['bidask_vstd_gt10'], x[cols_f], x[cols_i], x['SRISK'])).values
        i_desc['bidask_vstd_gt10_ma1d'+'_orthgem3l_sgnl'] = i_desc.groupby('T-1d')['bidask_vstd_gt10_ma1d'+'_orthgem3l'].apply(uniformed_rank)   
        i_desc = i_desc[['Ticker','DataDate','T-1d','bidask_vstd_gt10_ma5d'+'_orthgem3l_sgnl','bidask_vstd_gt10_ma1d'+'_orthgem3l_sgnl']]
    if f == 'featurepool_desc_earn_exp':
        i_desc = i_desc[['Ticker','DataDate','T-1d','earn_exp_sgnl']]
    if f == 'featurepool_desc_guba':
        i_desc['guba_desc_sgnl'] = i_desc.groupby('T-1d')['guba_desc'].apply(uniformed_rank)     
        i_desc = i_desc[['Ticker','DataDate','T-1d','guba_desc_sgnl']]
    if f == 'featurepool_desc_earn_frcst':
        i_desc = i_desc[['Ticker','DataDate','T-1d','ern_frcst_sgnl']]
    if f == 'featurepool_desc_jm':
        i_desc = i_desc[['Ticker','DataDate','T-1d','jm_sgnl']]
    if f == 'featurepool_desc_corpact_unlock':
        i_desc = i_desc[['Ticker','DataDate','T-1d','unlock12_dv_v_sgnl']]
    if f == 'featurepool_desc_earn_ugdg':
        i_desc = i_desc[['Ticker','DataDate','T-1d','ern_ugdg_sgnl']]
    if f == 'featurepool_desc_specsit':
        i_desc = i_desc[['Ticker','DataDate','T-1d',
                         'ipo_gt1y_sgnl',
                         'flg_has_sus_1d_sgnl', 'flg_has_sus_7d_sgnl', 'flg_has_sus_182d_ge5_sgnl',
                         'flg_has_sus_182d_ge20_sgnl', 'flg_has_sus_365d_ge5_sgnl', 'flg_has_sus_365d_ge20_sgnl',
                         'flg_touch_up_1d_sgnl', 'flg_touch_dn_1d_sgnl', 'flg_close_up_1d_sgnl',
                         'flg_close_dn_1d_sgnl', 'flg_has_uplmt_30d_gt2d_sgnl', 'flg_has_uplmt_30d_gt5d_sgnl',
                         'flg_has_dnlmt_30d_gt2d_sgnl', 'flg_has_dnlmt_30d_gt5d_sgnl',
                         'flg_has_uplmt_182d_gt5d_sgnl', 'flg_has_uplmt_182d_gt10d_sgnl',
                         'flg_has_dnlmt_182d_gt5d_sgnl', 'flg_has_dnlmt_182d_gt10d_sgnl', 
                         'flg_has_st_sgnl']]
    
    
    
    
    
    
    # select dates that need to be output
    
    for dd in date_diff:
        t_desc = i_desc[i_desc['DataDate'] == dd]
        tgt = os.path.join(root, f.replace('featurepool_desc_','featurepool_enrich_'), dd.strftime('%Y%m%d')+'
.parquet')
        if not os.path.exists(tgt):
            t_desc.to_parquet( tgt )
    
    
    i_desc = None
    t_desc = None
    gc.collect()
