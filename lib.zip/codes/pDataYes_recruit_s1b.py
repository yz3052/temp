﻿#$%^&* pDataYes_recruit_s1b.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 31 10:19:20 2021

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import zipfile
import csv

import jieba
import tfidf_matcher as tm 

# this analyzes the string data in title, based on tf idf
t_match = tm.matcher(t_fda['PROPRIETARYNAME'].fillna('@').tolist(), t_va['Name'].tolist(),1,2)

tm.matcher( ['我们'], ['我们一起','你好'],1,1)


### get ind

i_ind = yu.get_sql('''select datadate, ticker, gsector, ggrop, gind, gsubind 
                   FROM [CNDB].[dbo].[UNIVERSE_ALL_CN]
                   where datadate >= '2016-01-01' ''')
c_sh = i_ind['ticker'].str[0].isin(['6'])
c_sz = i_ind['ticker'].str[0].isin(['3','0'])
i_ind.loc[c_sh, 'ticker'] = i_ind.loc[c_sh, 'ticker'] + '.SH'
i_ind.loc[c_sz, 'ticker'] = i_ind.loc[c_sz, 'ticker'] + '.SZ'


### get sd
i_sd = pw.get_ashare_hk_sd_v2()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','a50_300_flag','a50_flag']]

i_sd_map_300 =i_sd_map[i_sd_map['a50_300_flag']==1]
i_sd_datadate_sr = i_sd_map_300['datadate'].drop_duplicates()
i_sd_map_50  = i_sd_map[i_sd_map['a50_flag']==1]




#--------------------------------------------------
### get strings 

# collect data

i_p = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet')

i_tk_str = pd.DataFrame()
for p in i_p:
    t_data = pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet', p),
                             columns = ['id','ticker_symbol','source','title','published_at','created_at'])
    t_data = t_data[t_data['ticker_symbol'].notnull()]
    t_data = t_data[t_data['ticker_symbol'].str.contains('\d{6}')]
    
    #t_data= t_data[t_data['source']=='51job'] ###!!!
    
    t_data['datadate'] = pd.to_datetime(pd.to_datetime(t_data['created_at']).dt.date)
        
        

    
    t_data['title3'] = t_data['title'].str.replace('\(.*\)','').str.replace('（.*）','').\
                 str.replace('\[.*\]','').str.replace('\【.*\】','').\
                 str.replace('\d[K|k|W|w|千|万]','').str.replace('\d','').\
                 str.replace('（|）|,|，|\.|。|:|：|;|；|\(|\)|\*|~|`|!|@|#|$|&|-|—|\+|\/|、|\?',' ').\
                 str.replace('职位编号','').\

                 str.strip().str.replace('[ ]+', ' ').\
                 str.upper()
    t_data = t_data[t_data['title3'].notnull() & (t_data['title3']!='')]
    t_data['title_seg'] = t_data['title3'].apply(lambda x: '@'.join(jieba.cut(x)))

    
    c_sz = t_data['ticker_symbol'].str[0].isin(['0', '3'])
    c_sh = t_data['ticker_symbol'].str[0].isin(['6'])
    t_data.loc[c_sz, 'ticker'] = t_data.loc[c_sz, 'ticker_symbol'] + '.SZ'
    t_data.loc[c_sh, 'ticker'] = t_data.loc[c_sh, 'ticker_symbol'] + '.SH'

    
    
    t_data = t_data.merge(i_ind, on = ['ticker','datadate'], how = 'left')
    t_data = t_data.sort_values(['ticker','datadate'])
    t_data['gsector'] = t_data.groupby('ticker')['gsector'].ffill()
    t_data['ggrop'] = t_data.groupby('ticker')['ggrop'].ffill()
    t_data['gind'] = t_data.groupby('ticker')['gind'].ffill()
    t_data['gsubind'] = t_data.groupby('ticker')['gsubind'].ffill()
    
    i_tk_str = i_tk_str.append(t_data, sort = False)



# trailing 1 year title list , each ticker and date

i_tk_t1y_titleLst = pd.DataFrame()
for dt in pd.date_range(start = '2016-04-01', end = '2021-08-01'):
    print('.', end='')
    t_str = i_tk_str[(i_tk_str['datadate']<=dt) & (i_tk_str['datadate']>=dt-pd.to_timedelta('365 days'))]

    t_word = t_str.groupby('ticker')['title3'].\
            apply(lambda x: '@'.join(list(set(( x.tolist() ))))).reset_index()
    t_word['datadate'] = dt
    
    i_tk_t1y_titleLst = i_tk_t1y_titleLst.append(t_word, sort = False)
    
# calculate growth

i_tk_t1y_titleLst['datadate_1y'] = i_tk_t1y_titleLst['datadate'] - pd.to_timedelta('365 days')


i_tk_t1y_titleLst = i_tk_t1y_titleLst.merge(i_tk_t1y_titleLst[['ticker', 'datadate','title3']],
                                        left_on = ['datadate_1y', 'ticker'], right_on = ['datadate', 'ticker'],
                                        how = 'left', suffixes = ['', '_merge'])
i_tk_t1y_titleLst = i_tk_t1y_titleLst.drop(columns = ['datadate_merge'])
i_tk_t1y_titleLst = i_tk_t1y_titleLst.rename(columns = {'title3_merge': 'title3_1y'})


### calculate jobs that is similar or dissimilar to historical jobs


i_p = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet')

def helper1(title_str, seg_title_str):
    t_jieba1 = list(jieba.cut(title_str))
    t_jieba2 = set([i for i in t_jieba1 if i.strip()!=''])
    seg_title_lst = set(seg_title_str.split('@'))
    return t_jieba2.issubset(seg_title_lst)

def helper2(title_str, seg_title_str):
    t_lst1 = [titl
e_str]
    t_lst2 = seg_title_str.split('@')
    if len(t_lst2)<= 1:
        return '0@?'
    t_match = tm.matcher( t_lst1, t_lst2, 1, 1)
    return str(t_match.loc[0]['Match Confidence'])+'@'+str(t_match.loc[0]['Lookup 1'])


def helper3(title_str, seg_title_str):
    t_lst1 = title_str.tolist()
    t_lst2 = seg_title_str.unique()[0].split('@')
    if len(t_lst2)<= 1:
        return ['0@?']*len(title_str)
    t_match = tm.matcher( t_lst1, t_lst2, 1, 1)
    return (t_match['Match Confidence'].astype(str) + '@' + t_match['Lookup 1'].astype(str)).tolist()


i_raw_seg = pd.DataFrame()
for p in i_p:
    print(p)
    t_data = pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet', p),
                             columns = ['ticker_symbol','title','published_at','id','source'])
    t_data = t_data[t_data['ticker_symbol'].notnull()]
    t_data = t_data[t_data['ticker_symbol'].str.contains('\d{6}')]
    t_data = t_data[t_data.source.isin(['51job'])] ###!!!
    t_data['datadate'] = pd.to_datetime(pd.to_datetime(t_data['published_at']).dt.date) + pd.to_timedelta('1 day')
    
    c_sh = t_data['ticker_symbol'].str[0].isin(['6'])
    c_sz = t_data['ticker_symbol'].str[0].isin(['0', '3'])
    t_data.loc[c_sh, 'ticker'] = t_data.loc[c_sh, 'ticker_symbol'] + '.SH'
    t_data.loc[c_sz, 'ticker'] = t_data.loc[c_sz, 'ticker_symbol'] + '.SZ'
    
    
    t_data['title3'] = t_data['title'].str.replace('\(.*\)','').str.replace('（.*）','').\
                 str.replace('\[.*\]','').str.replace('\【.*\】','').\
                 str.replace('\d[K|k|W|w|千|万]','').str.replace('\d','').\
                 str.replace('（|）|,|，|\.|。|:|：|;|；|\(|\)|\*|~|`|!|@|#|$|&|-|—|\+|\/|、|\?',' ').\
                 str.replace('职位编号','').\
                 str.strip().str.replace('[ ]+', ' ').\
                 str.upper()
    t_data = t_data[t_data['title3'].notnull() & (t_data['title3']!='')]
    
    t_data = t_data.merge(i_tk_t1y_titleLst[['ticker', 'datadate', 'title3_1y']], 
                          on = ['ticker', 'datadate'], how = 'left')
    t_data = t_data[t_data['title3_1y'].notnull()]
    
    i_raw_seg = i_raw_seg.append(t_data, sort = False)


i_raw_seg['title3_1y_grp'] = i_raw_seg['title3_1y']
i_raw_seg = i_raw_seg.sort_values(['title3_1y']).reset_index(drop = True)
i_raw_seg['match_results'] = i_raw_seg.groupby('title3_1y_grp')[['title3', 'title3_1y']].apply(lambda x: pd.Series(helper3(x['title3'],x['title3_1y']),index=x.index).to_frame()).values
i_ra
w_seg['match_prob'] = i_raw_seg['match_results'].str.split('@').str[0].astype(float)
    
# i_raw_seg.to_parquet(r'S:\Data\China Data Hunt\cache\pDataYes_recruit_s1b.parquet')

# now we get summarized data per ticker per datadate
# next we calculate t1y metrics
    
    
i_tk_t1y_same_cnt = pd.DataFrame()
for dt in pd.date_range(start = '2016-04-01', end = '2021-08-01'):
    print('.', end='')
    t_raw = i_raw_seg[(i_raw_seg['datadate']<=dt) & (i_raw_seg['datadate']>=dt-pd.to_timedelta('365 days'))]
    t_raw['same_concept_flag'] = t_raw['match_prob']>=0.9
    
    t_sum = t_raw.groupby(['ticker'])['id'].count().reset_index()
    t_sum = t_sum.rename(columns = {'id':'id_t1y'})
    t_sum_same = t_raw[t_raw['same_concept_flag']].groupby(['ticker'])['id'].count().reset_index()
    t_sum_same = t_sum_same.rename(columns = {'id':'id_same_t1y'})
    
    t_sum = t_sum.merge(t_sum_same, on = ['ticker'], how = 'outer')
    t_sum['datadate'] = dt
    i_tk_t1y_same_cnt = i_tk_t1y_same_cnt.append(t_sum, sort = False)
    
    



# Calculate various job count growth 

i_tk_t1y_same_cnt['datadate_1y'] = i_tk_t1y_same_cnt['datadate'] - pd.to_timedelta('365 days')


i_tk_t1y_same_cnt = i_tk_t1y_same_cnt.merge(i_tk_t1y_same_cnt[['ticker', 'datadate','id_same_t1y']],
                                        left_on = ['datadate_1y', 'ticker'], right_on = ['datadate', 'ticker'],
                                        how = 'left', suffixes = ['', '_merge'])
i_tk_t1y_same_cnt = i_tk_t1y_same_cnt.drop(columns = ['datadate_merge'])
i_tk_t1y_same_cnt = i_tk_t1y_same_cnt.rename(columns = {'id_same_t1y_merge': 'id_same_t1y_1y'})
i_tk_t1y_same_cnt = i_tk_t1y_same_cnt.drop(columns = ['datadate_1y'])



### get historical mc

i_mc = yu.get_sql('''select ticker, datadate, mc from [CNDB].[dbo].[UNIVERSE_ALL_CN] 
                    where ticker in ('{0}') '''.format("','".join( i_sd_map['ticker'].str[:6].unique().tolist() )))
i_mc['datadate_2y'] = i_mc['datadate'] - pd.to_timedelta('730 days')
i_mc['datadate_1y'] = i_mc['datadate'] - pd.to_timedelta('365 days')
i_mc['datadate_1h'] = i_mc['datadate'] - pd.to_timedelta('182 days')
i_mc['datadate_1q'] = i_mc['datadate'] - pd.to_timedelta('91 days')
i_mc['datadate_1m'] = i_mc['datadate'] - pd.to_timedelta('30 days')
i_mc['datadate_1w'] = i_mc['datadate'] - pd.to_timedelta('7 days')

i_mc = i_mc.sort_values('datadate')

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1q
', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1q'})

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1y', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1y'})
i_mc = i_mc.drop(columns = ['datadate_1q', 'datadate_1y'])

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_2y', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_2y'})
i_mc = i_mc.drop(columns = ['datadate_2y'])

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1h', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1h'})
i_mc = i_mc.drop(columns = ['datadate_1h'])

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1m', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1m'})
i_mc = i_mc.drop(columns = ['datadate_1m'])

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1w', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1w'})
i_mc = i_mc.drop(columns = ['datadate_1w'])

c_sh = i_mc['ticker'].str[0].isin(['6'])
c_sz = i_mc['ticker'].str[0].isin(['0', '3'])
i_mc.loc[c_sz, 'ticker'] = i_mc.loc[c_sz, 'ticker'] + '.SZ'
i_mc.loc[c_sh, 'ticker'] = i_mc.loc[c_sh, 'ticker'] + '.SH'



### get asset 
i_bs = yu.get_sql('''select ann_dt, s_info_windcode as ticker, report_period, 
                  TOT_CUR_ASSETS as c_asset, TOT_ASSETS as t_asset,
                  TOT_SHRHLDR_EQY_INCL_MIN_INT as eqy, TOT_LIAB as liab 
                  from [WIND].[dbo].[ASHAREBALANCESHEET]
                  where statement_type = '408001000' ''')

i_bs = i_bs[i_bs['ann_dt'].notnull()]
i_bs['datadate'] = pd.to_datetime
(i_bs['ann_dt'], format='%Y%m%d')
i_bs['report_period'] = pd.to_datetime(i_bs['report_period'], format = '%Y%m%d')
i_bs = i_bs.drop(columns = ['ann_dt'])

i_bs = i_bs.sort_values(['ticker','datadate'])
i_bs['max_report_date'] = i_bs.groupby('ticker')['report_period'].cummax()
i_bs = i_bs[i_bs['report_period']>=i_bs['max_report_date']]

i_bs = i_bs.drop(columns = ['report_period', 'max_report_date'])
i_bs = i_bs.sort_values('datadate')


i_bs = pd.merge_asof(i_sd_map[['ticker','datadate']].sort_values('datadate'), 
                     i_bs[['c_asset','t_asset','ticker','datadate']], 
                     by = 'ticker', on = 'datadate')
i_bs['datadate_1y'] = i_bs['datadate'] - pd.to_timedelta('365 days')
i_bs['datadate_1q'] = i_bs['datadate'] - pd.to_timedelta('91 days')

i_bs = pd.merge_asof(i_bs, i_bs[['c_asset','t_asset','ticker','datadate']],
                     by='ticker', left_on='datadate_1y', right_on='datadate',suffixes=['','_m'])
i_bs = i_bs.drop(columns=['datadate_m'])
i_bs = i_bs.rename(columns={'c_asset_m':'c_asset_1y','t_asset_m':'t_asset_1y'})

i_bs = pd.merge_asof(i_bs, i_bs[['c_asset','t_asset','ticker','datadate']],
                     by='ticker', left_on='datadate_1q', right_on='datadate',suffixes=['','_m'])
i_bs = i_bs.drop(columns=['datadate_m'])
i_bs = i_bs.rename(columns={'c_asset_m':'c_asset_1q','t_asset_m':'t_asset_1q'})




#------------------------------------------------------------------------------
### ---- combine (csi300 universe)
#------------------------------------------------------------------------------

icom_300 = i_sd[i_sd['a50_300_flag']==1].merge(i_mc, on = ['ticker', 'datadate'], how = 'left')
icom_300 = icom_300.merge(i_bs, on = ['ticker', 'datadate'], how = 'left')
icom_300 = icom_300.merge(i_tk_t1y_seg, on = ['ticker', 'datadate'], how = 'left')
icom_300 = icom_300.merge(i_tk_t1y_same_cnt, on = ['ticker', 'datadate'], how = 'left')
icom_300 = icom_300.sort_values(['ticker','datadate'])




# count the jobs that are similar as before


icom2 = icom_300.copy()

icom2['jobSame_t1y_df1y'] = icom2['id_same_t1y'] - icom2['id_same_t1y_1y']
icom2['jobSame_t1y_df1y_dv_mc'] = icom2['jobSame_t1y_df1y'].divide(icom2['mc_1y'])
icom2['jobSame_t1y_df1y_dv_mc_rk'] = icom2.groupby('datadate')['jobSame_t1y_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['jobSame_t1y_df1y_dv_mc_bk'] = icom2.groupby('datadate')['jobSame_t1y_df1y_dv_mc'].apply(lambda x: yu.pdqcut(x, bins = 10)).values

icom2['jobSame_t1y_df1y_dv_mc_secrk'] = 
icom2.groupby(['datadate','GSECTOR'])['jobSame_t1y_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['jobSame_t1y_df1y_dv_mc_secbk'] = icom2.groupby(['datadate','GSECTOR'])['jobSame_t1y_df1y_dv_mc'].apply(lambda x: yu.pdqcut(x, bins = 10)).values


icom2['jobSame_t1y_df1y_dv_ta'] = icom2['jobSame_t1y_df1y'].divide(icom2['t_asset_1y'])
icom2['jobSame_t1y_df1y_dv_ta_rk'] = icom2.groupby('datadate')['jobSame_t1y_df1y_dv_ta'].apply(yu.uniformed_rank).values
icom2['jobSame_t1y_df1y_dv_ta_bk'] = icom2.groupby('datadate')['jobSame_t1y_df1y_dv_ta'].apply(lambda x: yu.pdqcut(x, bins = 10)).values




icom2['sgnl4'] = np.nan
c1 = icom2['jobSame_t1y_df1y_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl4'] = icom2.loc[c1, 'jobSame_t1y_df1y_dv_mc_rk']


icom2['sgnl41'] = np.nan
c1 = icom2['jobSame_t1y_df1y_dv_mc_secrk']>0.8
icom2.loc[c1, 'sgnl41'] = icom2.loc[c1, 'jobSame_t1y_df1y_dv_mc_secrk']



icom2['sgnl5'] = np.nan
c1 = icom2['jobSame_t1y_df1y_dv_ta_rk']>0.8
icom2.loc[c1, 'sgnl5'] = icom2.loc[c1, 'jobSame_t1y_df1y_dv_ta_rk']



yu.create_cn_3x3(icom2, ['jobSame_t1y_df1y_dv_mc_bk'], 'jobSame_t1y_df1y_dv_mc')

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['sgnl4','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl4','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.95 / 1.65 using tfidf vs 2.77 / 2.49 with seg only

o_1.merge(i_sd[['ticker','datadate','GSECTOR']],on=['ticker','datadate'],how='left').groupby('GSECTOR')['pnl_ac'].apply(lambda x:x.mean()/x.std()*np.sqrt(x.count()))


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['jobSame_t1y_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jobSame_t1y_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prev 1.48 / 1.06 tfidf vs 1.24 / 0.82 with seg only

yu.create_cn_3x3(icom2, ['jobSame_t1y_df1y_dv_mc_bk'],'jobSame_t1y_df1y_dv_mc')



# events: new segs
icom2 = icom_300.copy()
icom2 = icom2.sort_values(['ticker', 'datadate'])
icom2 = icom2.reset_index(drop = True)

icom2['segNew_cnt_1d'] = icom2.groupby('ticker')['segNew_cnt'].shift().values
icom2['new_seg_evt'] = icom2['segNew_cnt'] > icom2['segNew_cnt_1d']
icom2.loc[icom2['new_seg_evt']==True, 'new_seg_sgnl'] = 1

icom2['high_seg_yy_evt']  = icom2['seg_cnt_yy']>2
icom2.loc[icom2['high_seg_yy_evt']==True, 'high_seg_yy_sgnl'] = 1


yu.create_cn_decay(icom2, 'new_seg_evt')
yu.create_cn_decay(icom2, 'high_
seg_yy_evt')



o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['new_seg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'new_seg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prev 1.24 / 0.82


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['high_seg_yy_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'high_seg_yy_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prev 1.24 / 0.82



