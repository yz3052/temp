﻿#$%^&* pCorpAct_cn_dvd_waiting.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed May 18 10:48:48 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime




### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])


### get close price

i_c = yu.get_sql('''select s_info_windcode as ticker, s_dq_close as c, trade_dt as datadate 
                    from wind_prod.dbo.ashareeodprices
                    where trade_Dt >'20150101' and trade_dt < '20211231' ''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format = '%Y%m%d')
i_c = i_c.sort_values('datadate')


### WIND dividend waiting time

i_wait = yu.get_sql_prod('''select * from wind.dbo.AShareDividend ''')

i_wait = i_wait.rename(columns = {'S_INFO_WINDCODE':'ticker'})
i_wait['DVD_PAYOUT_DT'] = i_wait['DVD_PAYOUT_DT'].fillna('NA')
i_wait['S_DIV_SMTGDATE'] = i_wait['S_DIV_SMTGDATE'].fillna('NA')
i_wait['DVD_ANN_DT'] = i_wait['DVD_ANN_DT'].fillna('NA')
i_wait['wait'] = (pd.to_datetime(i_wait['DVD_PAYOUT_DT'],format='%Y%m%d',errors='coerce') - 
                  pd.to_datetime(i_wait['S_DIV_SMTGDATE'],format='%Y%m%d',errors='coerce')).dt.days
i_wait['datadate'] = pd.to_datetime(i_wait['DVD_ANN_DT'],format='%Y%m%d',errors='coerce')

i_wait = i_wait[i_wait['datadate'].notnull()]
i_wait  = i_wait.sort_values('datadate')
i_wait = pd.merge_asof(i_wait, i_c, by = 'ticker', on = 'datadate', tolerance = pd.to_timedelta('7 days'))
i_wait['cash_ret'] = i_wait['CASH_DVD_PER_SH_PRE_TAX'].divide(i_wait['c'])

i_wait = i_wait[['ticker', 'datadate', 'wait', 'cash_ret']].dropna()
i_wait = i_wait.sort_values('datadate')







### combine

icom = pd.merge_asof(i_sd, i_wait, by = 'ticker', on = 'datadate', tolerance = pd.to_timedelta('730 days'))

icom['wait_bk'] = icom.groupby('datadate')['wait'].apply(lambda x: yu.pdqcut(x, bins=10))

yu.create_cn_3x3(icom, ['wait_bk'], 'wait')
yu.create_cn_3x3(icom[icom['cash_ret']>=0.02], ['wait_bk'], 'wait')

