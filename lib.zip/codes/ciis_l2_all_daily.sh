﻿#$%^&* ciis_l2_all_daily.sh #$%^&*
#!/bin/bash
datestr=$(TZ=Asia/Shanghai date -d "1 day ago"  +%Y%m%d)
$HOME/q/l64/q /export/dataprod2/CNL2/scripts/ciis_l2_trade_newfiles_daily.q $datestr
$HOME/q/l64/q /export/dataprod2/CNL2/scripts/ciis_l2_order_prod_gf.q $datestr

