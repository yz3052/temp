﻿#$%^&* pWIND_util_backup.py #$%^&*
"""
Created on Wed Mar  3 10:02:17 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

from yz.util import tic, toc, get_sql, get_q, get_sql_prod
from yz.util import ta_zigzag, ta_best_ma_period
from yz.util import ols_residual
import yz.util as yu


import re
import os
import io
import pathlib
import datetime, time
from dateutil.relativedelta import relativedelta

#from qpython import qconnection
from sqlalchemy import create_engine

import zipfile

from sklearn.linear_model import LinearRegression

### calendar
# SSE:shanghai SZSE:shenzhen SHN:shanghai north SZN:shenzhen north

def get_wind_trade_cal():    
    i_cal = get_sql('select trade_days as datadate, S_INFO_EXCHMARKET from [WIND].[dbo].[ASHARECALENDAR]')
    i_cal = i_cal.drop_duplicates()
    i_cal['datadate'] = pd.to_datetime(i_cal['datadate'], format= '%Y%m%d')
    i_cal =i_cal.sort_values(['S_INFO_EXCHMARKET','datadate'])
    i_cal['tdate_p1d'] = i_cal.groupby('S_INFO_EXCHMARKET')['datadate'].shift(-1)
    i_cal['tdate_1d'] = i_cal.groupby('S_INFO_EXCHMARKET')['datadate'].shift()    
    return i_cal

### calendar dates
    
def prepare_wind_cdate_cal():
    # for each ticker, between ipo and current date, outputs full calendar dates 
    # output is cdate continuous
    
    i_minmaxdt = get_sql('''select s_info_windcode as ticker, max(trade_dt) as maxdt, min(trade_dt) as mindt 
                         FROM [WIND].[dbo].[ASHAREEODPRICES]
                         group by s_info_windcode''')
    
    def get_wind_cdate_cal_gen_dates(row):
        t_date_range = pd.date_range(start = row['mindt'], end = row['maxdt'])
        t_ticker = [row['ticker']] * len(t_date_range)
        return pd.DataFrame({'ticker': t_ticker, 'datadate': t_date_range})
        
    o_cdate_cal = pd.concat((get_wind_cdate_cal_gen_dates(r) for i,r in i_minmaxdt.iterrows()), sort = False)
    
    o_cdate_cal.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_cdate_cal.parquet')
    
def get_wind_cdate_cal():
    
    return pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_cdate_cal.parquet')
    


### calendar tradeding (mainland and northbound)
    
def prepare_wind_trade_cal_byticker():
    
    # output is tdate continuous
    
    # mainland_tradable = 1 means a ticker is active and can be traded in SH/SZ
    # hk_tradable tells us if HKex is open or not
    
    # get ticker-date mapping from EOD PRices
    i_tdate = get_sql('''select [S_INFO_WINDCODE] 
as ticker, [TRADE_DT] as datadate, [S_DQ_TRADESTATUSCODE] as trade_status 
                      from [WIND].[dbo].[ASHAREEODPRICES]''')
    i_tdate.loc[i_tdate['trade_status']!=0,'mainland_tradable'] = 1
    i_tdate['datadate'] = pd.to_datetime(i_tdate['datadate'], format='%Y%m%d')
    
    ### get ticker universe from HK connect
    i_tk_uni = get_sql('''(select S_INFO_WINDCODE as ticker, entry_dt, remove_dt from [WIND].[dbo].[SZSCMEMBERS]) 
                       UNION
                       (select S_INFO_WINDCODE as ticker, entry_dt, remove_dt from [WIND].[dbo].[SHSCMEMBERS]) ''')
    i_tk_uni['entry_dt'] = pd.to_datetime(i_tk_uni['entry_dt'], format='%Y%m%d')
    i_tk_uni.loc[i_tk_uni['remove_dt'].isnull(), 'remove_dt'] = np.nan
    i_tk_uni['remove_dt'] = pd.to_datetime(i_tk_uni['remove_dt'], format='%Y%m%d')    
    
    # merge mainland tk-date mapping with HK connect
    i_tdate_s2 = i_tdate.merge(i_tk_uni, on = ['ticker'], how = 'left')
    c_isin = (i_tdate_s2['datadate'] >= i_tdate_s2['entry_dt']) & ((i_tdate_s2['datadate'] <= i_tdate_s2['remove_dt'])|i_tdate_s2['remove_dt'].isnull())
    i_tdate_s2.loc[c_isin,'isin_hk_uni'] = 1
    i_tdate_s2 = i_tdate_s2.rename(columns={'entry_dt':'hk_uni_entry','remove_dt':'hk_uni_remove'})
    i_tdate_s2 = i_tdate_s2.sort_values(['ticker','datadate','isin_hk_uni'])
    i_tdate_s2 = i_tdate_s2.drop_duplicates(subset=['ticker','datadate'], keep = 'first')
    
    # get mainland and HK trade calendar 
    i_tdate_byexchange = get_wind_trade_cal()
    i_tdate_byexchange['unity'] = 1
    i_tdate_byexchange = i_tdate_byexchange.pivot_table(index = 'datadate', columns = 'S_INFO_EXCHMARKET', values = 'unity').reset_index()
    
    # merge trade calendar
    i_tdate_s2 = i_tdate_s2.merge(i_tdate_byexchange, on = ['datadate'], how = 'left')
    i_tdate_s2.loc[(i_tdate_s2['SSE']!=1)&(i_tdate_s2['SZSE']!=1),'mainland_tradable'] = 0
    i_tdate_s2 = i_tdate_s2.drop(columns = ['SSE','SZSE'])
    c_sz = (i_tdate_s2['ticker'].str.contains('.SZ')) & (i_tdate_s2['SZN']==1)
    c_sh = (i_tdate_s2['ticker'].str.contains('.SH')) & (i_tdate_s2['SHN']==1)
    i_tdate_s2.loc[(i_tdate_s2['isin_hk_uni']==1)&(c_sz | c_sh),'hk_tradable'] = 1
    i_tdate_s2 = i_tdate_s2.drop(columns=['SHN','SZN','hk_uni_entry','hk_uni_remove'])
  
    i_tdate_s2.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_ticker_date_mapping.parquet')


def get_wind_trade_cal_byticker():
    
    return pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_uti
l_ticker_date_mapping.parquet')

### calendar： individual stock earning calendar

def prepare_ed_calendar():
    
    # v2 is better
    
    # on each calendar date, for each ticker, this gives all available ed_l1q and ed_n1q
    #hence we might need to dedup
    # CNINFO_ED_SNAP thru 2022.06.01
    # CNINFO_ED_SNAP is based on cninfo. It doesn't have ed forecast for tickers earlier in a quarter
    

    # future ed   
    
    i_fut_ed = get_sql('''select datadate, ticker, ped, next_ed FROM [CNDBPROD].[dbo].[CNINFO_ED_SNAP]''')
    
    c_sh = i_fut_ed['ticker'].str[0].isin(['6'])
    c_sz = i_fut_ed['ticker'].str[0].isin(['0','3'])
    i_fut_ed.loc[c_sh, 'ticker'] = i_fut_ed.loc[c_sh, 'ticker'] + '.SH'
    i_fut_ed.loc[c_sz, 'ticker'] = i_fut_ed.loc[c_sz, 'ticker'] + '.SZ'    
    i_fut_ed['report_period'] = (i_fut_ed['ped'].dt.year*10+i_fut_ed['ped'].dt.month/3).astype(int)
    
    i_fut_ed = i_fut_ed.sort_values(['ticker', 'report_period','next_ed', 'datadate'])
    i_fut_ed = i_fut_ed[['datadate', 'ticker', 'next_ed', 'report_period']]
    
    i_fut_ed_dd = i_fut_ed['datadate'].drop_duplicates()
    
    # past ed
    # past ed data is accurate

    i_past_ed = get_sql('''select S_INFO_WINDCODE as ticker, REPORT_PERIOD as report_period,
                              S_STM_ACTUAL_ISSUINGDATE as ed_l1q 
                              from wind_prod.dbo.AShareIssuingDatePredict
                              where S_STM_ACTUAL_ISSUINGDATE is not null''')
    i_past_ed['ed_l1q'] = pd.to_datetime(i_past_ed['ed_l1q'], format='%Y%m%d')
    i_past_ed['report_period'] = i_past_ed['report_period'].str[:4]+(i_past_ed['report_period'].str[4:6].astype(int)/3).astype(int).astype(str)
    i_past_ed['report_period'] = i_past_ed['report_period'].astype(int)
    i_past_ed = i_past_ed.sort_values(['ticker', 'report_period', 'ed_l1q']).reset_index(drop=True)
    i_past_ed = i_past_ed[['ticker', 'report_period', 'ed_l1q']]
    

    # loop
    o_ed = []
    for dt in pd.date_range(start='2014-01-01', end='2022-06-20'):
        
        t_fut_ed = i_fut_ed[i_fut_ed['datadate']==i_fut_ed_dd[i_fut_ed_dd<=dt].max()]
        t_fut_ed = t_fut_ed.drop_duplicates(subset = ['ticker', 'report_period'], keep='first')
        t_fut_ed = t_fut_ed.rename(columns = {'report_period':'report_period_n1q','next_ed':'ed_n1q'})
        t_fut_ed = t_fut_ed[['ticker', 'report_period_n1q', 'ed_n1q']]
        
        t_past_ed = i_past_ed[(i_past_ed['ed_l1q']<=dt)&(i_past_ed['ed_l1q']>=dt-pd.t
o_timedelta('273 days'))]
        t_past_ed = t_past_ed.drop_duplicates(subset='ticker', keep='last')
        t_past_ed = t_past_ed.rename(columns={'report_period':'report_period_l1q'})
        t_past_ed = t_past_ed[['ticker', 'report_period_l1q', 'ed_l1q']]
        
        t_com = t_past_ed.merge(t_fut_ed, on = 'ticker', how = 'outer')
        t_com['datadate'] = dt
        
        o_ed.append(t_com)
        print(dt.strftime('%Y%m%d'), end=',')
    o_ed = pd.concat(o_ed, axis = 0)
    
    # fill nan ped_n1q
    c1 = o_ed['report_period_l1q'].notnull() & o_ed['report_period_n1q'].isnull()
    o_ed.loc[c1, 'report_period_n1q'] = o_ed.loc[c1, 'report_period_l1q'] + 1
    c2 = o_ed['report_period_n1q'].mod(5)==0
    o_ed.loc[c2, 'report_period_n1q'] = o_ed.loc[c2, 'report_period_n1q'] + 6
    
    # fill erroneous ped_n1q
    c1 = o_ed['report_period_l1q']>=o_ed['report_period_n1q']
    o_ed.loc[c1, 'report_period_n1q'] = o_ed.loc[c1, 'report_period_l1q'] + 1
    o_ed.loc[c1, 'ed_n1q'] = np.nan
    c2 = o_ed['report_period_n1q'].mod(5)==0
    o_ed.loc[c2, 'report_period_n1q'] = o_ed.loc[c2, 'report_period_n1q'] + 6
    
    # calculate td2e
    
    o_ed['td2e'] = yu.get_tdate_cnt(o_ed['datadate'], o_ed['ed_n1q'])
    
    # output
    
    o_ed.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_ed_calendar.parquet')
        

def prepare_ed_calendar_v2():
    # v1 is based on gf's tables; v2 is based on wind pit (history) and scraped cninfo data
    # wind max(ann_dt) = 2021.08.29, cninfo scraper min(datadate) = 2021.06.22
    # td2e = 0 means earning is available post market on the same day; 
    # bret+0d is the first return of ed.
    
    
    
    ### get wind BT table for hisotry 
    # every time there is any change to predicted_issue_date, there is a new row.
    # however if an earning is actually announced, there is nothing that tells us when it happened.
    # we can only assume the actual earning is reported on "actual_issuingdate"
    
    i_wind = get_sql('''select backtime, s_info_windcode as ticker, 
                     report_period, s_stm_predict_issuingdate, s_stm_actual_issuingdate,
                     ann_dt
                     from wind.dbo.ASHAREISSUINGDATEPREDICTBT''')
    for c in ['report_period','s_stm_predict_issuingdate','s_stm_actual_issuingdate','ann_dt']:
        i_wind[c] = i_wind[c].fillna('nan')
        i_wind[c] = pd.to_datetime(i_wind[c], format='%Y%m%d', errors='coerce')
    
    
        
    ### get cni
nfo pit
    
    i_cninfo = get_sql('''select * from cndbdev.dbo.cninfo_ed_calendar''')
    
    i_cninfo = i_cninfo.sort_values(['ticker', 'report_period', 'scrape_ts_cn'])
    i_cninfo['actual_date2'] = i_cninfo.groupby(['ticker','report_period'])['actual_date'].ffill() # this is for missing actual date on 2021.11.05
    
    i_cninfo_dd = i_cninfo['datadate'].drop_duplicates()
    
    
    ### loop for wind 
    # output: ticker, datadate, report_period_l1q, q_l1q, ed_l1q, 
    #         report_period_n1q, q_n1q, ed_n1q, td2e, cd2e
    df_ed_cal_wind = []
    
    for dt in pd.date_range('2015-01-01', '2021-08-15'):
        print(dt.strftime('%Y%m%d'),end=',')
        
        dt_p1d_0400_str = (dt + pd.to_timedelta('1 day')).strftime('%Y-%m-%d') + ' 04:00:00'
        t_wind = i_wind[(i_wind['backtime']>=dt_p1d_0400_str) | (i_wind['backtime'].isnull())]
        t_wind = t_wind[t_wind['ann_dt']<=dt]
        
        # find l1q, on ed, the l1q is not the current q
        
        t_wind_l1q = t_wind[t_wind['s_stm_actual_issuingdate']<dt] # not <=, so when datadate=actual_date, bd2e=0
        t_wind_l1q_maxrr = t_wind_l1q.groupby('ticker')['report_period'].max().reset_index() # cannot skip this, latest backtime might be a correction of very old q
        t_wind_l1q = t_wind_l1q.merge(t_wind_l1q_maxrr,on=['ticker','report_period'],how='inner')
        t_wind_l1q['backtime'] = t_wind_l1q['backtime'].fillna(pd.to_datetime('2050-12-31')) #only get max backtime after selecting max report_period
        t_wind_l1q = t_wind_l1q.sort_values(['ticker','backtime'])
        t_wind_l1q = t_wind_l1q.drop_duplicates(subset='ticker',keep='last')
        
        t_wind_l1q = t_wind_l1q[['ticker','report_period','s_stm_actual_issuingdate']]
        t_wind_l1q.columns = ['ticker','report_period_l1q','ed_l1q']
        t_wind_l1q['q_l1q'] = t_wind_l1q['report_period_l1q'].dt.year*10+t_wind_l1q['report_period_l1q'].dt.quarter
        t_wind_l1q = t_wind_l1q[['ticker','report_period_l1q','ed_l1q','q_l1q']]
    
        # find n1q, make sure ann_dt not null
        
        t_wind_n1q = t_wind[(t_wind['s_stm_actual_issuingdate']>=dt)|(t_wind['s_stm_actual_issuingdate'].isnull())] # opposite to 1st line in lq
        t_wind_n1q = t_wind_n1q.merge(t_wind_l1q[['ticker', 'report_period_l1q']],on='ticker',how='left')
        t_wind_n1q = t_wind_n1q[t_wind_n1q['report_period']>t_wind_n1q['report_period_l1q']] #n1q must > l1q
        
        t_wind_n1q_minrr = t_wind_n1q.groupby('t
icker')['report_period'].min().reset_index() # find report period first
        t_wind_n1q = t_wind_n1q.merge(t_wind_n1q_minrr,on=['ticker','report_period'],how='inner')
        t_wind_n1q['backtime'] = t_wind_n1q['backtime'].fillna(pd.to_datetime('2050-12-31'))
        t_wind_n1q = t_wind_n1q.sort_values(['ticker','backtime'])
        t_wind_n1q = t_wind_n1q.drop_duplicates(subset='ticker',keep='last') # then select max nan-filled backtime
        
        t_wind_n1q = t_wind_n1q[['ticker','report_period','s_stm_actual_issuingdate']]
        t_wind_n1q.columns = ['ticker','report_period_n1q','ed_n1q']
        t_wind_n1q['q_n1q'] = t_wind_n1q['report_period_n1q'].dt.year*10+t_wind_n1q['report_period_n1q'].dt.quarter
        t_wind_n1q = t_wind_n1q[['ticker','report_period_n1q','ed_n1q','q_n1q']]
        
        # combine l1q and n1q
        
        t_wind_com = t_wind_l1q.merge(t_wind_n1q, on = ['ticker'], how = 'outer')
        t_wind_com['datadate'] = dt
        t_wind_com['td2e'] = yu.get_tdate_cnt(t_wind_com['datadate'], t_wind_com['ed_n1q'])
        t_wind_com['cd2e'] = (t_wind_com['ed_n1q'] - dt).dt.days
        
        df_ed_cal_wind.append(t_wind_com)
        
    ### loop for cninfo
    
    df_ed_cal_cninfo = []
    
    for dt in pd.date_range('2021-08-15', '2022-07-18'):
        print(dt.strftime('%Y%m%d'),end=',')
        
        t_cninfo_tdy = i_cninfo[i_cninfo['datadate']==i_cninfo_dd[i_cninfo_dd<=dt].max()]        
        t_cninfo_t1q = i_cninfo[(i_cninfo['datadate']<=dt) & (i_cninfo['datadate']>=dt-pd.to_timedelta('91 days'))]
        
        # l1q (logic similar to wind above)   
        
        t_cninfo_l1q_maxrr = t_cninfo_t1q[(t_cninfo_t1q['actual_date']<dt)].groupby('ticker')['report_period'].max().reset_index()
        t_cninfo_l1q = t_cninfo_t1q.merge(t_cninfo_l1q_maxrr, on = ['ticker', 'report_period'], how = 'inner')
        t_cninfo_l1q = t_cninfo_l1q.sort_values(['ticker', 'datadate'])
        t_cninfo_l1q = t_cninfo_l1q.drop_duplicates(subset='ticker', keep = 'last')
        
        t_cninfo_l1q = t_cninfo_l1q[['ticker','report_period','actual_date']]
        t_cninfo_l1q.columns = ['ticker','report_period_l1q','ed_l1q']
        t_cninfo_l1q['q_l1q'] = t_cninfo_l1q['report_period_l1q'].dt.year*10+t_cninfo_l1q['report_period_l1q'].dt.quarter
        t_cninfo_l1q = t_cninfo_l1q[['ticker','report_period_l1q','ed_l1q','q_l1q']]
        
        # n1q (logic similar to wind above)
        c1 = (t_cninfo_tdy['final_scheduled_
date'].isnull()|(t_cninfo_tdy['final_scheduled_date']>=dt)) & t_cninfo_tdy['actual_date'].isnull()
        c2 = (t_cninfo_tdy['actual_date']>=dt) | t_cninfo_tdy['actual_date'].isnull()
        t_cninfo_n1q_minrr = t_cninfo_tdy[c1 | c2].groupby('ticker')['report_period'].min().reset_index()
        t_cninfo_n1q = t_cninfo_tdy.merge(t_cninfo_n1q_minrr, on = ['ticker', 'report_period'], how = 'inner')
        t_cninfo_n1q = t_cninfo_n1q.sort_values(['ticker', 'datadate'])
        t_cninfo_n1q = t_cninfo_n1q.drop_duplicates(subset='ticker',keep='last')
        
        t_cninfo_n1q = t_cninfo_n1q[['ticker','report_period','final_scheduled_date']]
        t_cninfo_n1q.columns = ['ticker','report_period_n1q','ed_n1q']
        t_cninfo_n1q['q_n1q'] = t_cninfo_n1q['report_period_n1q'].dt.year*10+t_cninfo_n1q['report_period_n1q'].dt.quarter
        t_cninfo_n1q = t_cninfo_n1q[['ticker','report_period_n1q','ed_n1q','q_n1q']]
        
        
        # combine l1q and n1q
        
        t_cninfo_com = t_cninfo_l1q.merge(t_cninfo_n1q, on = ['ticker'], how = 'outer')
        t_cninfo_com['datadate'] = dt
        t_cninfo_com['td2e'] = yu.get_tdate_cnt(t_cninfo_com['datadate'], t_cninfo_com['ed_n1q'])
        t_cninfo_com['cd2e'] = (t_cninfo_com['ed_n1q'] - dt).dt.days
        
        df_ed_cal_cninfo.append(t_cninfo_com)
        
    o_ed = pd.concat(df_ed_cal_wind+df_ed_cal_cninfo, axis = 0)
    o_ed.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_ed_calendar_v2.parquet')





### hk connect tickers

def upload_hk_uni():
    
    i_ticker_date_mapping = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_ticker_date_mapping.parquet')
    i_ticker_date_mapping = i_ticker_date_mapping.drop(columns=['trade_status','mainland_tradable','hk_tradable'])
    i_ticker_date_mapping['isin_hk_uni'] = i_ticker_date_mapping['isin_hk_uni'].fillna(0)
    
    i_ticker_date_mapping.to_csv(r'S:\TZ\China Data Hunt\cache\tmp_hk_uni.csv', index = False)
    
    # create table hk_connect_uni (ticker varchar(20), datadate datetime, isin_hk_uni int)
    # bcp [BackTest].[dbo].[hk_connect_uni] in "S:\TZ\China Data Hunt\cache\tmp_hk_uni.csv" -c -t  , -S summitsqldb -U AD\thzhang -T -F 2 




###  stock IPO dates
    
def get_ipo_date():
    # this returns the IPO date of each ticker
    # the output is not tdate continuous
    
    i_first_date = get_sql('''select s_info_windcode as ticker, min(trade_dt) as ipo_date 
                           from wind_prod.dbo.ashareeod
prices 
                           group by s_info_windcode''')
    i_first_date['ipo_date'] = pd.to_datetime(i_first_date['ipo_date'], format = '%Y%m%d')
    
    return i_first_date


### scheduled earning dates
    
def prepare_wind_ed_calendar_pit():
    
    # this return cdate continuous n1q PIT earning date
    # if predicted n11_ed is unkown, I used l4q's ed as an estimate
    
    # step 1 - get cdate calendar
    i_cal = get_wind_cdate_cal()
    i_cal = i_cal.sort_values(['datadate', 'ticker'])
    
    # step 2 - get l1q report_period and release date
    i_l1q = get_sql('''
                    select s_info_windcode as ticker, report_period as ped_l1q, S_STM_ACTUAL_ISSUINGDATE as ed_l1q 
                    from [WIND].[dbo].[AShareIssuingDatePredict] where S_STM_ACTUAL_ISSUINGDATE is not null
                    ''')
    i_l1q['ped_l1q'] = pd.to_datetime(i_l1q['ped_l1q'], format = '%Y%m%d')
    i_l1q['ed_l1q'] = pd.to_datetime(i_l1q['ed_l1q'], format = '%Y%m%d')
    i_l1q = i_l1q.sort_values(['ed_l1q', 'ticker'])
    
    # step 3 - get ped_l1q and ed_l1q for each ticker, on each cdate
    i1 = pd.merge_asof(i_cal, i_l1q, left_on = ['datadate'], right_on = ['ed_l1q'], by = ['ticker'])
    
    # step 4 - get ped_l2q ... l5q, n1q
    i1['ped_l2q'] = i1['ped_l1q'] - pd.tseries.offsets.QuarterEnd(n=1, startingMonth=3)
    i1['ped_l3q'] = i1['ped_l2q'] - pd.tseries.offsets.QuarterEnd(n=1, startingMonth=3)
    i1['ped_l4q'] = i1['ped_l3q'] - pd.tseries.offsets.QuarterEnd(n=1, startingMonth=3)
    i1['ped_l5q'] = i1['ped_l4q'] - pd.tseries.offsets.QuarterEnd(n=1, startingMonth=3)
    i1['ped_n1q'] = i1['ped_l1q'] + pd.tseries.offsets.QuarterEnd(n=1, startingMonth=3)
    
    # step 5 - get cninfo's calendar 
    i_cninfo = get_sql('''select rectime as datadate, ticker, ped as ped_n1q, next_ed as edCNINFO_n1q
                       from [CNDBPROD].[dbo].cninfo_ed_raw''')
    i_cninfo['datadate'] = pd.to_datetime(i_cninfo['datadate'].dt.date)
    c_sh = i_cninfo['ticker'].str[0].isin(['6'])
    c_sz = i_cninfo['ticker'].str[0].isin(['0','3'])
    i_cninfo.loc[c_sh, 'ticker'] = i_cninfo.loc[c_sh, 'ticker'] + '.SH'
    i_cninfo.loc[c_sz, 'ticker'] = i_cninfo.loc[c_sz, 'ticker'] + '.SZ'
    i_cninfo = i_cninfo.sort_values('datadate')
    
    i1 = pd.merge_asof(i1, i_cninfo, on = ['datadate'], by = ['ticker', 'ped_n1q'])
    
    # step 6 - get actual ed 1 year ago, so we can estimate n1q's ed
    
    i_l4q = get_sql('''select s_info_windcode as ticker,
 report_period as ped_l4q, S_STM_ACTUAL_ISSUINGDATE as ed_l4q 
                    from wind.dbo.AShareIssuingDatePredict 
                    where S_STM_ACTUAL_ISSUINGDATE is not null''')
    i_l4q['ped_l4q'] = pd.to_datetime(i_l4q['ped_l4q'], format='%Y%m%d')
    i_l4q['ed_l4q'] = pd.to_datetime(i_l4q['ed_l4q'], format='%Y%m%d')
    i1 = i1.merge(i_l4q, on = ['ticker','ped_l4q'], how = 'left')
    i1['edEst_n1q'] = i1['ped_n1q'] + pd.to_timedelta((i1['ed_l4q'] - i1['ped_l4q']).dt.days, unit='d')
    
    # step 7 - get predicted ed dates, per ticker and report period, on each ann_dt
    i_n1q = get_sql('''select s_info_windcode as ticker, report_period as ped_n1q, 
                    S_STM_PREDICT_ISSUINGDATE ed_n1q, ann_dt as datadate 
                    from [WIND].[dbo].[AShareIssuingDatePredictBT] 
                    where S_STM_PREDICT_ISSUINGDATE is not null and ann_dt is not null
                    order by s_info_windcode, report_period, ann_dt
                    ''')
    i_n1q = i_n1q.drop_duplicates()
    i_n1q['datadate'] = pd.to_datetime(i_n1q['datadate'])
    i_n1q['ped_n1q'] = pd.to_datetime(i_n1q['ped_n1q'])
    i_n1q['ed_n1q'] = pd.to_datetime(i_n1q['ed_n1q'])
    i_n1q = i_n1q.sort_values('datadate')
    i1 = pd.merge_asof(i1, i_n1q, left_on = ['datadate'], right_on = ['datadate'], by = ['ticker','ped_n1q'])
    
    # step 8 - tag changed ed_n1q
    i1 = i1.sort_values(['ticker','datadate']).reset_index(drop = True)
    c_chgd = (i1['ticker'] == i1['ticker'].shift()) & (i1['ped_n1q']==i1['ped_n1q'].shift()) &\
             (i1['ed_n1q'].notnull()) & (i1['ed_n1q'].shift().notnull()) &\
             (i1['ed_n1q']!=i1['ed_n1q'].shift())
    i1.loc[c_chgd, 'ed_n1q_chgd'] = 1
    
    # step 9 - flags for estimated ed, combine l4q-estimated and predicted ed into 1 column
    i1.loc[i1['ed_n1q'].isnull(), 'ed_n1q'] = i1.loc[i1['ed_n1q'].isnull(), 'edCNINFO_n1q'] 
    i1.loc[i1['ed_n1q'].isnull(), 'ed_n1q_is_est'] = 1
    i1.loc[i1['ed_n1q'].isnull(), 'ed_n1q'] = i1.loc[i1['ed_n1q'].isnull(), 'edEst_n1q'] 
    
    # step 10 - get ed_n1q from yesterday
    i1['ed_n1q_prev'] = i1.groupby('ticker')['ed_n1q'].shift().values
    
    # step 11 - add express / forecast information
    i_frcst = get_sql('''select stock_code as ticker, declare_date as datadate,
                     report_year as year, report_period*3 as month, 1 as day
                     from [CNDBDEV].[dbo].[fin_performance_forecast] ''')
    i_frcst['tag_frcst_exp'] = 'for
ecast'
        
    i_exp = get_sql('''select stock_code as ticker, declare_date as datadate,
                       report_year as year, report_period*3 as month, 1 as day 
                       from [CNDBDEV].[dbo].[fin_performance_express] ''')
    i_exp['tag_frcst_exp'] = 'express'
    
    i_frcst_exp = i_frcst.append(i_exp, sort = False)
    
    c_sh = i_frcst_exp['ticker'].str[0].isin(['6'])
    c_sz = i_frcst_exp['ticker'].str[0].isin(['0','3'])
    i_frcst_exp.loc[c_sh, 'ticker'] = i_frcst_exp.loc[c_sh, 'ticker'] + '.SH'
    i_frcst_exp.loc[c_sz, 'ticker'] = i_frcst_exp.loc[c_sz, 'ticker'] + '.SZ'
    
    i_frcst_exp['ped_n1q'] = pd.to_datetime(i_frcst_exp[['year','month','day']])
    i_frcst_exp['ped_n1q'] = i_frcst_exp['ped_n1q'] + pd.offsets.MonthEnd()
    
    i_frcst_exp = i_frcst_exp[['ticker','datadate','ped_n1q','tag_frcst_exp']]
    i_frcst_exp = i_frcst_exp.sort_values('datadate')
    
    i1 = i1.sort_values('datadate').reset_index(drop = True)
    i1 = pd.merge_asof(i1, i_frcst_exp, by = ['ticker','ped_n1q'], on = ['datadate'])
    i1 = i1.sort_values(['ticker','datadate']).reset_index(drop = True)


    # step 12 - get tdate calendar to calculate bd2e and bdae
    i_tdate_cal = get_wind_trade_cal()
    i_tdate_cal = i_tdate_cal[i_tdate_cal['S_INFO_EXCHMARKET'].isin(['SZSE','SSE'])]
    i_tdate_cal = i_tdate_cal.drop_duplicates(subset=['datadate']).sort_values(['datadate'])
    i_tdate_cal['id_num'] = [i for i in range(len(i_tdate_cal))]
    i_tdate_cal = i_tdate_cal[['datadate','id_num']]
    i_tdate_cal = i_tdate_cal.reset_index(drop = True)
    t_date_range = pd.date_range(start = i_tdate_cal['datadate'].min(), end = i_tdate_cal['datadate'].max())
    i_tdate_cal = i_tdate_cal.set_index('datadate')
    i_tdate_cal = i_tdate_cal.reindex(t_date_range)
    i_tdate_cal['id_num'] = i_tdate_cal['id_num'].fillna(method='bfill') # weekend to nextmonday bd2e = 0
    i_tdate_cal = i_tdate_cal.reset_index()
    i_tdate_cal = i_tdate_cal.rename(columns={'index':'datadate'})
    o_tdate = {}
    for i,r in i_tdate_cal.iterrows():
        o_tdate[r['datadate'].strftime('%Y%m%d')] = r['id_num']
    
    # step 13 - calculate bd2e, bdae, cd2e, cdae
    c_nn = i1['ed_n1q'].notnull() & i1['datadate'].notnull()
    i1.loc[c_nn,'bd2e'] = i1.loc[c_nn, ['ed_n1q', 'datadate']].apply(lambda x: o_tdate[x['ed_n1q'].strftime('%Y%m%d')] - o_tdate[x['datadate'].strftime('%Y%m%d')], axis=1)
    c_ed = i1['datadate'] == i1['ed_l1q']
    i1.loc[c_ed, 'bd2e'] = 
0 
    i1['bd2e'] = i1['bd2e'].fillna(999)
    
    c_nn = i1['ed_n1q'].notnull() & i1['datadate'].notnull()
    i1.loc[c_nn,'cd2e'] = (i1.loc[c_nn, 'ed_n1q'] - i1.loc[c_nn, 'datadate']).dt.days
    c_ed = i1['datadate'] == i1['ed_l1q']
    i1.loc[c_ed, 'cd2e'] = 0 
    i1['cd2e'] = i1['cd2e'].fillna(999)
    
    i1['cdae'] = (i1['datadate'] - i1['ed_l1q']).dt.days
    c_nn = i1['ed_l1q'].notnull() & i1['datadate'].notnull()
    i1.loc[c_nn, 'bdae'] = i1.loc[c_nn,['ed_l1q', 'datadate']].apply(lambda x: o_tdate[x['datadate'].strftime('%Y%m%d')] - o_tdate[x['ed_l1q'].strftime('%Y%m%d')], axis=1)
    
    # output
    i1 = i1[['ticker', 'datadate', 'ped_l1q', 'ed_l1q', 'ped_l2q', 'ped_l3q',
           'ped_l4q', 'ed_l4q', 'ped_l5q', 'ped_n1q', 
           'ed_n1q', 'ed_n1q_chgd', 'ed_n1q_is_est', 'ed_n1q_prev', 
           'tag_frcst_exp',
           'bd2e', 'cd2e', 'cdae', 'bdae']]
    i1.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_ed_cal_pit.parquet')

def get_wind_ed_calendar_pit():
    # output
    return pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_ed_cal_pit.parquet')
    
    

def prepare_wind_ed_calendar():
    
    # This function is obsolete. DISGARD it.
    
    # the output is cdate continuous
    # this outputs past earning and future earning dates
    
    # step 1 - get cdate calendar
    i_cal = get_wind_cdate_cal()
    i_cal = i_cal.sort_values(['datadate', 'ticker'])
    
    # step 2 - get l1q report_period and release date    
    i_l1q = get_sql('''
                    select s_info_windcode as ticker, report_period as ped_l1q, S_STM_ACTUAL_ISSUINGDATE as ed_l1q 
                    from [WIND].[dbo].[AShareIssuingDatePredict] where S_STM_ACTUAL_ISSUINGDATE is not null
                    ''')
    i_l1q['ped_l1q'] = pd.to_datetime(i_l1q['ped_l1q'], format = '%Y%m%d')
    i_l1q['ed_l1q'] = pd.to_datetime(i_l1q['ed_l1q'], format = '%Y%m%d')
    i_l1q = i_l1q.sort_values(['ed_l1q', 'ticker'])
    
    # step 3 - get ped_l1q and ed_l1q for each ticker, on each cdate
    i1 = pd.merge_asof(i_cal, i_l1q, left_on = ['datadate'], right_on = ['ed_l1q'], by = ['ticker'])
    
    # step 4 - get ped_l2q ...l4q
    i1['ped_l2q'] = i1['ped_l1q'] - pd.tseries.offsets.QuarterEnd(n=1, startingMonth=3)
    i1['ped_l3q'] = i1['ped_l2q'] - pd.tseries.offsets.QuarterEnd(n=1, startingMonth=3)
    i1['ped_l4q'] = i1['ped_l3q'] - pd.tseries.offsets.QuarterEnd(n=1, startingMonth=3)
    i1['ped_l5q'] = i1['ped_l4q'] - pd.tseries.offsets.Quar
terEnd(n=1, startingMonth=3)
        
    # step 5 - get tdate calendar to calculate bd2e and bdae
    i_tdate_cal = get_wind_trade_cal()
    i_tdate_cal = i_tdate_cal[i_tdate_cal['S_INFO_EXCHMARKET'].isin(['SZSE','SSE'])]
    i_tdate_cal = i_tdate_cal.drop_duplicates(subset=['datadate']).sort_values(['datadate'])
    i_tdate_cal['id_num'] = [i for i in range(len(i_tdate_cal))]
    i_tdate_cal = i_tdate_cal[['datadate','id_num']]
    i_tdate_cal = i_tdate_cal.reset_index(drop = True)
    t_date_range = pd.date_range(start = i_tdate_cal['datadate'].min(), end = i_tdate_cal['datadate'].max())
    i_tdate_cal = i_tdate_cal.set_index('datadate')
    i_tdate_cal = i_tdate_cal.reindex(t_date_range)
    i_tdate_cal['id_num'] = i_tdate_cal['id_num'].fillna(method='bfill') # weekend to nextmonday bd2e = 0
    i_tdate_cal = i_tdate_cal.reset_index()
    i_tdate_cal = i_tdate_cal.rename(columns={'index':'datadate'})
    o_tdate = {}
    for i,r in i_tdate_cal.iterrows():
        o_tdate[r['datadate'].strftime('%Y%m%d')] = r['id_num']
    
    # step 6 - get ped n1q
    i1['ped_n1q'] = i1['ped_l1q'] + pd.tseries.offsets.QuarterEnd(n=1, startingMonth=3)
    
    # step 7 - get release date n1q
    i_n1q = get_sql('''
                    select s_info_windcode as ticker, report_period as ped_n1q, S_STM_PREDICT_ISSUINGDATE as ed_n1q,
                    ann_dt as release_n1q
                    from [WIND].[dbo].[AShareIssuingDatePredict] where S_STM_PREDICT_ISSUINGDATE is not null and ann_dt is not null
                    ''')
    i_n1q['ped_n1q'] = pd.to_datetime(i_n1q['ped_n1q'], format='%Y%m%d')
    i_n1q['ed_n1q'] = pd.to_datetime(i_n1q['ed_n1q'], format='%Y%m%d')
    i_n1q['release_n1q'] = pd.to_datetime(i_n1q['release_n1q'], format='%Y%m%d')
    i_n1q = i_n1q.sort_values(['release_n1q', 'ticker'])
    
    i1 = pd.merge_asof(i1, i_n1q, left_on = ['datadate'], right_on = ['release_n1q'], by = ['ticker','ped_n1q'])
    
    # step 8 - calculate bd2e, bdae, cd2e, cdae
    c_nn = i1['ed_n1q'].notnull() & i1['datadate'].notnull()
    i1.loc[c_nn,'bd2e'] = i1.loc[c_nn, ['ed_n1q', 'datadate']].apply(lambda x: o_tdate[x['ed_n1q'].strftime('%Y%m%d')] - o_tdate[x['datadate'].strftime('%Y%m%d')], axis=1)
    c_ed = i1['datadate'] == i1['ed_l1q']
    i1.loc[c_ed, 'bd2e'] = 0 
    i1['bd2e'] = i1['bd2e'].fillna(999)
    
    c_nn = i1['ed_n1q'].notnull() & i1['datadate'].notnull()
    i1.loc[c_nn,'cd2e'] = (i1.loc[c_nn, 'ed_n1q'] - i1.loc[c_nn, 'datadate']).dt.days
    c_ed =
 i1['datadate'] == i1['ed_l1q']
    i1.loc[c_ed, 'cd2e'] = 0 
    i1['cd2e'] = i1['cd2e'].fillna(999)
    
    i1['cdae'] = (i1['datadate'] - i1['ed_l1q']).dt.days
    c_nn = i1['ed_l1q'].notnull() & i1['datadate'].notnull()
    i1.loc[c_nn, 'bdae'] = i1.loc[c_nn,['ed_l1q', 'datadate']].apply(lambda x: o_tdate[x['datadate'].strftime('%Y%m%d')] - o_tdate[x['ed_l1q'].strftime('%Y%m%d')], axis=1)
    
    # step 9 - get actual earning date (fwdlk bias here) 
    i_act = get_sql('''
                    select s_info_windcode as ticker, report_period as ped_n1q, S_STM_ACTUAL_ISSUINGDATE as ed_n1q_fwdlk 
                    from [WIND].[dbo].[AShareIssuingDatePredict] where S_STM_ACTUAL_ISSUINGDATE is not null
                    ''')
    i_act['ped_n1q'] = pd.to_datetime(i_act['ped_n1q'], format='%Y%m%d')
    i_act['ed_n1q_fwdlk'] = pd.to_datetime(i_act['ed_n1q_fwdlk'], format='%Y%m%d')
    
    i1 = i1.merge(i_act, on = ['ticker', 'ped_n1q'], how = 'left')
    c_nn = i1['ed_n1q_fwdlk'].notnull()
    i1.loc[c_nn,'bd2e_fwdlk'] = i1.loc[c_nn, ['ed_n1q_fwdlk', 'datadate']].apply(lambda x: o_tdate[x['ed_n1q_fwdlk'].strftime('%Y%m%d')] - o_tdate[x['datadate'].strftime('%Y%m%d')], axis=1)
    i1.loc[c_nn,'cd2e_fwdlk'] = (i1.loc[c_nn,'ed_n1q_fwdlk'] - i1.loc[c_nn,'datadate']).dt.days
    
    i1.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_ed_cal.parquet')
    
def get_wind_ed_calendar():
    # output
    return pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_ed_cal.parquet')
    
### mutual fund disclosure dates
    
def prepare_wind_mfrpt_calendar():
    # this output l1q and n1q ed for each compcode on each calendar date
    # note: bd2n1rpt could be negative: e.g. -143. It means forecasted date has passed, but there is 
    #       no reporting.
    
    
    # get data
    i_rpt_cal= get_sql('''select distinct b.s_info_compcode, a.f_prt_enddate as report_period, a.ann_date as datadate 
                        from wind_prod.dbo.ChinaMutualFundStockPortfolio a
                        left join wind_prod.dbo.windcustomcode b
                        on a.s_info_windcode = b.s_info_windcode''')
    i_rpt_cal['datadate'] = pd.to_datetime(i_rpt_cal['datadate'], format='%Y%m%d')
    i_rpt_cal['ped'] = pd.to_datetime(i_rpt_cal['report_period'], format='%Y%m%d')
    i_rpt_cal['q'] = i_rpt_cal['ped'].dt.year*10 + i_rpt_cal['ped'].dt.quarter
    
    # get rid of irregular reports
    i_rpt_cal = i_rpt_cal[i_rpt_cal['report_period'].str.endswith('0331')|\
  
                        i_rpt_cal['report_period'].str.endswith('0630')|\
                          i_rpt_cal['report_period'].str.endswith('0930')|\
                          i_rpt_cal['report_period'].str.endswith('1231')]
    
    # loop
    o_cal = []
    for dt in pd.date_range(start='2016-01-01', end='2022-07-01'):
        print(dt.strftime('%Y%m%d'),end=',')
        
        t_rpt_cal_t2y = i_rpt_cal[(i_rpt_cal['datadate']<=dt)&(i_rpt_cal['datadate']>=dt-pd.to_timedelta('730 days'))]
        t_rpt_cal_t2y = t_rpt_cal_t2y.rename(columns={'q':'q_n1q_1y','datadate':'ed_n1q_1y'})
        t_rpt_cal_t2y = t_rpt_cal_t2y.groupby(['s_info_compcode','q_n1q_1y'])['ed_n1q_1y'].min().reset_index()
        t_rpt_cal_t2y = t_rpt_cal_t2y[['s_info_compcode','q_n1q_1y','ed_n1q_1y']]
        
        t_rpt_cal_t1y = i_rpt_cal[(i_rpt_cal['datadate']<=dt)&(i_rpt_cal['datadate']>=dt-pd.to_timedelta('365 days'))]
        t_rpt_cal_t1y = t_rpt_cal_t1y.sort_values(['s_info_compcode','report_period','datadate'])
        
        # get l1q        
        s_rpt_cal = t_rpt_cal_t1y.drop_duplicates(subset = ['s_info_compcode'], keep =  'last')
        s_rpt_cal = s_rpt_cal.reset_index(drop=True)
        s_rpt_cal = s_rpt_cal.rename(columns={'q':'q_l1q', 'ped':'ped_l1q','datadate':'ed_l1q'})
        s_rpt_cal = s_rpt_cal[['s_info_compcode','ped_l1q','q_l1q','ed_l1q']]
        
        # get n1q
        s_rpt_cal['q_n1q'] = s_rpt_cal['q_l1q']+1
        c1 = s_rpt_cal['q_n1q'].mod(5)==0
        s_rpt_cal.loc[c1, 'q_n1q'] = s_rpt_cal.loc[c1, 'q_n1q'] + 6
        
        # estimate n1q report date
        s_rpt_cal['q_n1q_1y'] = s_rpt_cal['q_n1q'] - 10
        s_rpt_cal = s_rpt_cal.merge(t_rpt_cal_t2y, on = ['s_info_compcode','q_n1q_1y'], how = 'left')
        s_rpt_cal['ed_n1q'] = s_rpt_cal['ed_n1q_1y'] + pd.to_timedelta('365 days')
        s_rpt_cal['ed_n1q_weekday'] = s_rpt_cal['ed_n1q'].dt.weekday
        c1 = s_rpt_cal['ed_n1q_weekday'] == 5
        s_rpt_cal.loc[c1, 'ed_n1q'] = s_rpt_cal.loc[c1, 'ed_n1q'] - pd.to_timedelta('1 day')
        c1 = s_rpt_cal['ed_n1q_weekday'] == 6
        s_rpt_cal.loc[c1, 'ed_n1q'] = s_rpt_cal.loc[c1, 'ed_n1q'] - pd.to_timedelta('2 day')
        
        #bdsl1rpt, bd2n1rpt        
        s_rpt_cal['datadate'] = dt
        s_rpt_cal['bdsl1rpt'] = yu.get_tdate_cnt(s_rpt_cal['ed_l1q'], s_rpt_cal['datadate'])
        s_rpt_cal['bd2n1rpt'] = yu.get_tdate_cnt(s_rpt_cal['datadate'], s_rpt_cal['ed_n1q'])
        
                        
        #outp
ut
        s_rpt_cal = s_rpt_cal[['s_info_compcode','datadate',
                               'q_l1q','ed_l1q','q_n1q','ed_n1q',
                               'bdsl1rpt','bd2n1rpt']]
        o_cal.append(s_rpt_cal)
        
    o_cal = pd.concat(o_cal, axis=0)
    
    # add-on: fund company level forecasts    
#    i_fund_mgmt = get_sql('''select b.s_info_compcode, max(a.F_INFO_CORP_FUNDMANAGEMENTID) as fund_mgmt_id 
#                              from wind.dbo.ChinaMutualFundDescription a
#                              left join wind.dbo.WINDCUSTOMCODE b
#                              on a.f_info_windcode = b.s_info_windcode
#                              group by b.S_INFO_COMPCODE ''')
#    o_cal = o_cal.merge(i_fund_mgmt, on = ['s_info_compcode'], how = 'left')
                                
    o_cal.to_parquet(r'S:\TZ\China Data Hunt\cache\pWNID_util_prepare_wind_mfrpt_calendar.parquet')
    


### compustat net income

def get_compustat_ni_ttm():
    
    # for each ticker and its disclosure date, this output ttm net income over the past 5 quarters
    # when using it, merge_asof this into static data 
    
    i_ni = get_sql('''select ticker, periodEndDate as ped_l1q, sourceDate, 
                   ni_ttm as ni_ttm_l1q 
                   FROM [CNDBDEV].[dbo].[ni_pit]''')
    i_ni = i_ni[i_ni['sourceDate'].notnull()]
    
    c_sh = i_ni['ticker'].str[0].isin(['6'])
    c_sz = i_ni['ticker'].str[0].isin(['0', '3'])
    i_ni.loc[c_sh, 'ticker'] = i_ni.loc[c_sh, 'ticker'] + '.SH'
    i_ni.loc[c_sz, 'ticker'] = i_ni.loc[c_sz, 'ticker'] + '.SZ'
    
    i_ni['datadate'] = i_ni['sourceDate'].dt.tz_localize('UTC').dt.tz_convert('Asia/Shanghai').dt.tz_localize(None)
    i_ni = i_ni.drop(columns = ['sourceDate'])
    
    i_ni['ped_l2q'] = i_ni['ped_l1q'] - pd.DateOffset( months = 3 ) - pd.tseries.offsets.MonthBegin(1) + pd.tseries.offsets.MonthEnd(1)
    i_ni['ped_l3q'] = i_ni['ped_l2q'] - pd.DateOffset( months = 3 ) - pd.tseries.offsets.MonthBegin(1) + pd.tseries.offsets.MonthEnd(1)
    i_ni['ped_l4q'] = i_ni['ped_l3q'] - pd.DateOffset( months = 3 ) - pd.tseries.offsets.MonthBegin(1) + pd.tseries.offsets.MonthEnd(1)
    i_ni['ped_l5q'] = i_ni['ped_l4q'] - pd.DateOffset( months = 3 ) - pd.tseries.offsets.MonthBegin(1) + pd.tseries.offsets.MonthEnd(1)
    
    i_ni.loc[i_ni['datadate'].dt.hour<=6, 'datadate'] = i_ni.loc[i_ni['datadate'].dt.hour<=6, 'datadate'] - pd.to_timedelta('1 day')
    i_ni['datadate'] = pd.to_datetime(i_ni['datadate'].dt.date)
 
   i_ni = i_ni.sort_values('datadate')
    
    
    i_ni = pd.merge_asof(i_ni, i_ni[['ticker','datadate','ped_l1q','ni_ttm_l1q']],
                         left_by = ['ticker', 'ped_l2q'], right_by = ['ticker','ped_l1q'],
                         on = 'datadate', suffixes = ['', '_m'])
    i_ni = i_ni.drop(columns=['ped_l1q_m']).rename(columns={'ni_ttm_l1q_m':'ni_ttm_l2q'})
    
    i_ni = pd.merge_asof(i_ni, i_ni[['ticker','datadate','ped_l1q','ni_ttm_l1q']],
                         left_by = ['ticker', 'ped_l3q'], right_by = ['ticker','ped_l1q'],
                         on = 'datadate', suffixes = ['', '_m'])
    i_ni = i_ni.drop(columns=['ped_l1q_m']).rename(columns={'ni_ttm_l1q_m':'ni_ttm_l3q'})
    
    i_ni = pd.merge_asof(i_ni, i_ni[['ticker','datadate','ped_l1q','ni_ttm_l1q']],
                         left_by = ['ticker', 'ped_l4q'], right_by = ['ticker','ped_l1q'],
                         on = 'datadate', suffixes = ['', '_m'])
    i_ni = i_ni.drop(columns=['ped_l1q_m']).rename(columns={'ni_ttm_l1q_m':'ni_ttm_l4q'})
    
    i_ni = pd.merge_asof(i_ni, i_ni[['ticker','datadate','ped_l1q','ni_ttm_l1q']],
                         left_by = ['ticker', 'ped_l5q'], right_by = ['ticker','ped_l1q'],
                         on = 'datadate', suffixes = ['', '_m'])
    i_ni = i_ni.drop(columns=['ped_l1q_m']).rename(columns={'ni_ttm_l1q_m':'ni_ttm_l5q'})
    
    
    return i_ni


def get_compustat_ni_qtr():
    
    # for each ticker and its disclosure date, this output QTR net income over the past 5 quarters
    # when using it, merge_asof this into static data 
    
    i_ni = get_sql('''SELECT ticker, periodenddate as ped, sourceDate,
                   ni_qtr as ni_l1q, ni_qtr_l1q as ni_l2q, ni_qtr_l2q as ni_l3q, ni_qtr_l3q as ni_l4q 
                   FROM [CNDBDEV].[dbo].[ni_qtr_pit]''')
    
    i_ni = i_ni[i_ni['sourceDate'].notnull()]
    
    c_sh = i_ni['ticker'].str[0].isin(['6'])
    c_sz = i_ni['ticker'].str[0].isin(['0', '3'])
    i_ni.loc[c_sh, 'ticker'] = i_ni.loc[c_sh, 'ticker'] + '.SH'
    i_ni.loc[c_sz, 'ticker'] = i_ni.loc[c_sz, 'ticker'] + '.SZ'
    
    i_ni['datadate'] = i_ni['sourceDate'].dt.tz_localize('UTC').dt.tz_convert('Asia/Shanghai').dt.tz_localize(None)
    i_ni = i_ni.drop(columns = ['sourceDate'])
    
    return i_ni


### financial disclosure: history
# wind: [PITINDEXCHANGE] and [PITFINANCIALFACTOR] tables are both TTM 
# suntime: fin_performance_forecast, fin_performance_express

def prepare_wind_actual():
    

    # still lack of data
    
    # this outputs actual fundamental data per ticker per cdate
    # fields: revenue = or_ttm, net income = np_ttm, 
    
    i_pitf = get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                     s_fda_or_ttm as or_ttm, S_DFA_NETPROFIT_TTM as np_ttm, 
                     FROM [WIND].[dbo].[PITFINANCIALFACTOR]''')
    
    pass
    


### SEDOL ISIN

def prepare_isin_sedol():
    
    i_tk_date_map = get_sql('''select [S_INFO_WINDCODE] as ticker, [TRADE_DT] as datadate from [WIND].[dbo].[ASHAREEODPRICES] ''')
    
    i_tk_date_map['ticker'] = i_tk_date_map['ticker'].str.replace('.SH','.SS')
    t_ticker = '`'+'`'.join(i_tk_date_map['ticker'].str[:6].unique().tolist())
    
    get_q('system"l /dat/summit_capital/Infrastructure/tiq/tiqclient.q";')
    get_q('/.tiq.init enlist[`password]!enlist "*ubsoilArtRelearn";')
    get_q('h: hopen `$":impact-h:9000:thzhang:*ubsoilArtRelearn";')
    
    for d in i_tk_date_map.datadate.unique():
        d_q = d[:4]+'.'+d[4:6]+'.'+d[6:8]
        t1 = get_q("t1: h (`run;`eqhcr;`date`targets`id!("+d_q+";`RIC`ISIN`CUSIP`SEDOL`TICKER`ID_BB_UNIQUE`ID_BB_GLOBAL`ID_BB_COMPANY`NAME;([]TICKER:"+t_ticker+"))); t1")
        for c in t1.columns.tolist():
            if c =='date':
                continue
            else:
                t1[c] = t1[c].str.decode('utf-8')
        t1 = t1[t1['RIC'].notnull()&(t1['RIC']!='')]
        t1.to_parquet(os.path.join(r'S:\TZ\China Data Hunt\tmp',d_q+'_isin_sedol.parquet'))
        
    # read 
    i_parqs = os.listdir(r'S:\TZ\China Data Hunt\tmp')
    i_parqs = [i for i in i_parqs if i.endswith('.parquet')]
    i_sedol_isin = pd.concat(pd.read_parquet(os.path.join(r'S:\TZ\China Data Hunt\tmp',f)) for f in i_parqs)
    i_sedol_isin = i_sedol_isin.rename(columns={'date':'DataDate'})
    i_sedol_isin = i_sedol_isin[i_sedol_isin['RIC']!='']
    i_sedol_isin = i_sedol_isin.sort_values(['DataDate','TICKER'])
    i_sedol_isin = i_sedol_isin[~i_sedol_isin['RIC'].str.contains('KQ|KS')]
    i_sedol_isin.to_csv(r'S:\TZ\China Data Hunt\tmp\isin_sedol.csv', index = False)
    
    # delete
    for f in i_parqs:
        os.remove(os.path.join(r'S:\TZ\China Data Hunt\tmp',f))
    
    # upload to sql
    '''
    create table IMPACTH_isin_sedol (DataDate datetime, TICKER varchar(20), RIC varchar(50), ISIN varchar(50), 
    CUSIP varchar(50), SEDOL varchar(50), ID_BB_UNIQUE varchar(100), ID_BB_GLOBAL varchar(100), 
    ID_BB_COMPANY varchar(100), NAM
E varchar(max));
    '''
    '''
    bcp [BackTest].[dbo].[IMPACTH_isin_sedol] in "S:\TZ\China Data Hunt\tmp\isin_sedol.csv" -c -t  , -S summitsqldb -U AD\thzhang -T -F 2
    '''
    
    # delete
    os.remove(r'S:\TZ\China Data Hunt\tmp\isin_sedol.csv')

def get_isin_sedol():
    
    return get_sql('''select * from [BackTest].[dbo].[IMPACTH_isin_sedol]''')

    

### index constituents
    

def prepare_csi_index_constituent():
    
    # wt sums up to 100 (official name: Investable Weight)
    # iwght sums up to 1 (more significant figures) (Investable Weight in Index (Source))
    
    
    # TIQ - CSI 50 300 500
    get_q('system"l /dat/summit_capital/Infrastructure/tiq/tiqclient.q";')
    get_q('h: hopen `$":tiq:9100:thzhang:*ubsoilArtRelearn";')
    
    i_300 = get_q('''const300_alldates: raze {
                     show x;
                     const300: h (`run;`gd;`ds`tbl`date`id`columns!(`csi;`CSI300.ccons;x;`;`date`descr`indexdesc`primric`sedol`index`iwght`wt));
                     const300: update primric: `$ssr[;".SS";".SH"] each string primric from const300;
                     const300} each 2013.01.01 + til ( 1 + 2021.08.18-2013.01.01);
                     select date, indexdesc, primric, sedol, index, iwght, wt from const300_alldates''')
    for c in ['indexdesc','primric','sedol','index']:
        i_300[c] = i_300[c].str.decode('utf-8')
    
    i_500 = get_q('''const500_alldates: raze {
                     show x;
                     const500: h (`run;`gd;`ds`tbl`date`id`columns!(`csi;`CSI500.ccons;x;`;`date`descr`indexdesc`primric`sedol`index`iwght`wt));
                     const500: update primric: `$ssr[;".SS";".SH"] each string primric from const500;
                     const500} each 2013.01.01 + til ( 1 + 2021.03.18-2013.01.01);
                     select date, indexdesc, primric, sedol, index, iwght, wt from const500_alldates''')
    for c in ['indexdesc','primric','sedol','index']:
        i_500[c] = i_500[c].str.decode('utf-8')
    
    i_50 = get_q('''const50_alldates: raze {
                     show x;
                     const50: h (`run;`gd;`ds`tbl`date`id`columns!(`csi;`SSE50.ccons;x;`;`date`descr`indexdesc`primric`sedol`index`iwght`wt));
                     const50: update primric: `$ssr[;".SS";".SH"] each string primric from const50;
                     const50} each 2013.01.01 + til ( 1 + 2021.03.18-2013.01.01);
                     select date, indexdesc, primric, sedol, index, iwght, wt from const50_allda
tes''')
    for c in ['indexdesc','primric','sedol','index']:
        i_50[c] = i_50[c].str.decode('utf-8')
        
    i_300.to_parquet(r'S:\TZ\China Data Hunt\cache\CSI300_constituents.parquet')
    i_500.to_parquet(r'S:\TZ\China Data Hunt\cache\CSI500_constituents.parquet')
    i_50.to_parquet(r'S:\TZ\China Data Hunt\cache\CSI50_constituents.parquet')
    
    
    
    # A50 (open constituent)
    
    a50_files = []
    for p, d, fs in os.walk(r'Z:\FTSE\Regional_And_Partner\Asia_Pacific\China\Constituent'):
        for f in fs:
            if (f[:4] == 'x9co') and (f.endswith('.csv')):
                a50_files.append([p, f])
                break
    
    a50_ticker=[]
    a50_datadate=[]
    a50_modified_date=[]
    a50_sedol=[]
    a50_weight=[]
    
    for loc in a50_files:
        print('.', end='')
        
        t_data = pd.read_csv(os.path.join(loc[0], loc[1]), skiprows = 3, 
                             dtype={'SEDOL':str})
        t_data = t_data[t_data['Local Code'].notnull()]
        t_data = t_data[~t_data['Cons Code'].str.contains('XXXXXXXXXX')]
        
        t_data['date_modified'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                  time.localtime(os.path.getmtime(os.path.join(loc[0],loc[1]))))
        
        t_splt = loc[0].split('\\')
        t_data['datadate'] = pd.to_datetime(t_splt[-3]+'-'+t_splt[-2]+'-'+t_splt[-1])
        t_data['ticker'] = t_data['Local Code'].astype(int).astype(str).str.zfill(6)
        c_sh = t_data['ticker'].str[0].isin(['6'])
        c_sz = t_data['ticker'].str[0].isin(['3','0'])
        t_data.loc[c_sh, 'ticker'] = t_data.loc[c_sh, 'ticker'] + '.SH'
        t_data.loc[c_sz, 'ticker'] = t_data.loc[c_sz, 'ticker'] + '.SZ'
        
        a50_ticker.extend(t_data['ticker'].tolist())
        a50_datadate.extend(t_data['datadate'].tolist())
        a50_modified_date.extend(t_data['date_modified'].tolist())
        a50_sedol.extend(t_data['SEDOL'].tolist())
        a50_weight.extend(t_data['% wght in Index'].tolist())
        
        
    a50 = pd.DataFrame({'ticker': a50_ticker, 'datadate': a50_datadate, 'modified_date': a50_modified_date,
                       'sedol':a50_sedol, 'weight': a50_weight})
    a50['modified_date'] = pd.to_datetime(a50['modified_date'])
    
    a50.to_parquet(r'S:\TZ\China Data Hunt\cache\ftse_a50_constituents.parquet')
    '''
    create table index_constituent_a50 (ticker varchar(20), datadate datetime, modified_date datetime,
    sedol varchar(20),
 weight float)
    '''
    param_engine = create_engine('mssql+pyodbc://summitsqldb_cndb') 
    a50.to_sql('index_constituent_a50', param_engine , index = False, if_exists = 'append')
    
    # mdwarehouse CSI 300
    
    csi300_files = []
    for p, d, fs in os.walk(r'Z:\CSI\CSI_300_Index\weight_for_next_trading_day'):
        for f in fs:
            if (f[:6] == '000300') & (f.endswith('.zip')):
                csi300_files.append([p, f])
    
    o_csi300 = pd.DataFrame()
    for loc in csi300_files:
        print('.', end='')
        zipfile
            
        with zipfile.ZipFile(os.path.join(loc[0], loc[1])) as z:
            for f in z.namelist():
                if (f.endswith('.xls')) & (f[:6]=='000300'):
                    t_data = pd.read_excel(io.BytesIO(z.open(f).read()))
        
        t_data.columns = [i.replace('\n','').replace('\r','').strip() for i in t_data.columns.tolist()]
        t_data = t_data.rename(columns={'生效日期Effective Date':'Effective Date', '指数代码Index Code':'Index Code', 
                                        '指数名称Index Name':'Index Name', '指数英文名称Index Name(Eng.)':'Index Name Eng', 
                                        '成分券代码Constituent Code': 'Constituent Code', 
                                        '成分券名称Constituent Name': 'Constituent Name', 
                                        '成分券英文名称Constituent Name(Eng.)': 'Constituent Name Eng', 
                                        '交易所Exchange': 'Exchange', '总股本(股)Total A Shares(share)': 'Total A Shares',
                                        '自由流通比例(%)(归档后)Categorized  Inclusion Factor(%)': 'Categorized  Inclusion Factor',
                                        '计算用股本(股)Shares in Index(share)': 'Shares in Index', 
                                        '权重因子Cap Factor': 'Cap Factor', '收盘Close': 'Close',
                                        '调整后开盘参考价Reference Open Price for Next Trading Day': 'Reference Open Price for Next Trading Day',
                                        '总市值Total Market Capitalization': 'Total Market Capitalization', 
                                        '计算用市值Market Cap in Index': 'arket Cap in Index',
                                        '权重(%)Weight(%)': 'Weight', '交易货币Trading Currency': 'Trading Currency', 
                                        '汇率Exchange Rate': 'Exchange Rate','Sedol码Sedol Code':'Sedol Code'})
        t_splt = loc[0].split('\\')
        t_data['datadte'] = pd.to_datetime(t_splt[-3]+'-'+t_splt[-2]+'-'
+t_splt[-1])
        t_data['modified_date'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                  time.localtime(os.path.getmtime(os.path.join(loc[0],loc[1]))))
        o_csi300 = o_csi300.append(t_data, sort = False)
        
        
    o_csi300.to_parquet(r'S:\TZ\China Data Hunt\cache\csi300_mdwarehouse_constituents.parquet')
    param_engine = create_engine('mssql+pyodbc://summitsqldb_cndb') 
    o_csi300.to_sql('index_constituent_csi300', param_engine , index = False, if_exists = 'append')
    

def get_csi_index_membership():
    
    # the output is tdate continuous
    
    i_300 = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\CSI300_constituents.parquet',columns = ['date','primric'])
    i_500 = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\CSI500_constituents.parquet',columns = ['date','primric'])
    i_50 = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\CSI50_constituents.parquet',columns = ['date','primric'])
    
    i_300 = i_300.rename(columns = {'date': 'datadate', 'primric': 'ticker'})
    i_300['is_300'] = 1
    
    i_50 = i_50.rename(columns = {'date': 'datadate', 'primric': 'ticker'})
    i_50['is_50'] = 1
    
    i_500 = i_500.rename(columns = {'date': 'datadate', 'primric': 'ticker'})
    i_500['is_500'] = 1
    
    i_mem = i_300.merge(i_50, on = ['datadate', 'ticker'], how = 'outer')
    i_mem = i_mem.merge(i_500, on = ['datadate', 'ticker'], how = 'outer')
    i_mem['hedgeable'] = 1
    
    return i_mem

def get_a50_index_membership():
    
    return pd.read_parquet(r'S:\TZ\China Data Hunt\cache\ftse_a50_constituents.parquet')
    

def get_index_weight():
    
    # the output is tdate continuous
    
    i_300 = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\CSI300_constituents.parquet',columns = ['date','primric','iwght'])
    i_500 = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\CSI500_constituents.parquet',columns = ['date','primric','iwght'])
    i_50 = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\CSI50_constituents.parquet',columns = ['date','primric','iwght'])
    
    i_300 = i_300[['date','primric','iwght']].rename(columns = {'date': 'datadate', 'primric': 'ticker', 'iwght':'wt300'})
    i_300['is_300'] = 1
    
    i_50 = i_50[['date','primric','iwght']].rename(columns = {'date': 'datadate', 'primric': 'ticker', 'iwght':'wt50'})
    i_50['is_50'] = 1
    
    i_500 = i_500[['date','primric','iwght']].rename(columns = {'date': 'datadate', 'primric': 'ticker', 'iwght':'wt500'})
    i_500['is_500'] = 
1
    
    i_wt = i_300.merge(i_50, on = ['datadate', 'ticker'], how = 'outer')
    i_wt = i_wt.merge(i_500, on = ['datadate', 'ticker'], how = 'outer')
    i_wt['hedgeable'] = 1
    
    return i_wt


def prepare_rime_index_membership():
    # all the data below is "Next Day" constituent data.
    # on date T 5 am ET, we receive data from the vendor, it tells us the constituent on the next day
    
    param_engine = create_engine('mssql+pyodbc://summitsqldb_cndb')

    # 500
    for p,f,fs in os.walk(r'Z:\Rimes\Indices\CSI\CSI500'):
        if fs != ['']:
            for f in fs:
                if f.endswith('.psv') and '-ND-' in f:
                    print (f)
                    try:
                        t_data = pd.read_csv(os.path.join(p, f), sep='|')
                    except:
                        t_data = pd.read_csv(os.path.join(p, f), sep='|',encoding='Windows-1252')
                    
                    #if t_data['Date of Portfolio'].max()<20200603:
                    #    continue
                    t_data['Exchange'] = np.nan
                    t_data['Date of Portfolio'] = pd.to_datetime(t_data['Date of Portfolio'].astype(str),format='%Y%m%d')
                    t_data['Ticker'] = t_data['Primary RIC Company Level'].str[:6]
                    
                    t_data.to_sql('index_constituent_rime_csi500', param_engine , index = False, if_exists = 'append', chunksize = 10000)
    
    # 300
    for p,f,fs in os.walk(r'Z:\Rimes\Indices\CSI\CSI300'):
        if fs != ['']:
            for f in fs:
                if f.endswith('.psv') and '-ND-' in f  and 'CSI300' in f:
                    print (f)
                    try:
                        t_data = pd.read_csv(os.path.join(p, f), sep='|')
                    except:
                        t_data = pd.read_csv(os.path.join(p, f), sep='|',encoding='Windows-1252')
                    
                    t_data['Date of Portfolio'] = pd.to_datetime(t_data['Date of Portfolio'].astype(str),format='%Y%m%d')
                    t_data['Ticker'] = t_data['Database Symbol'].str[-6:]
                    
                    
                    t_data = t_data[['Date of Portfolio', 'CSRC Industry Description',
       'CSRC Industry Description - Full', 'Description', 'Index Description',
       'ISIN Code', 'Sedol Code', 
       'Database Source', 'Database Symbol', 'Currency Code',
       'Country Description', 'Country Code', 'Exchange',
       'Industry Level 1 Code', 'In
dustry Level 1 Description',
       'Industry Level 2 Code', 'Industry Level 2 Description',
       'Industry Level 3 Code', 'Industry Level 3 Description',
       'Industry Level 4 Code', 'Industry Level 4 Description',
       'Sector Description', 'Investable Factor',
       'Investable Market Value in Local Currency',
       'Market Value in Local Currency',
       'Gross Investable Market Value in Local Currency',
       'Total Return in Local Currency', 'Unadjusted Price in Local Currency',
       'Investable Weight', 'Total Return Investible Weight',
       'Investable Weight in Index (Source)', 'Investable Shares Outstanding',
       'Shares Outstanding', 'CSRC Industry Code', 'CSRC Industry Code - Full',
       'Ticker']]
                    t_data.to_sql('index_constituent_rime_csi300', param_engine , index = False, if_exists = 'append', chunksize = 10000)
    
    # 500 history (not in sql yet)
    for p,f,fs in os.walk(r'Z:\Rimes\Indices\CSI\CSI500_History'):
        if fs != ['']:
            for f in fs:
                if f.endswith('.psv') and '-ND-' in f and "CSI500" in f:
                    print (f)
                    try:
                        t_data = pd.read_csv(os.path.join(p, f), sep='|')
                    except:
                        t_data = pd.read_csv(os.path.join(p, f), sep='|',encoding='Windows-1252')
                    if '20160308' in f:
                        continue

                    t_data['Date of Portfolio'] = pd.to_datetime(t_data['Date of Portfolio'].astype(str),format='%Y%m%d')
                    t_data['Ticker'] = t_data['Primary RIC Company Level'].str[:6]

                    t_data.to_sql('index_constituent_rime_csi500', param_engine , index = False, if_exists = 'append', chunksize = 10000)
    
    # 300 History (not in sql yet)
    for p,f,fs in os.walk(r'Z:\Rimes\Indices\CSI\CSI300_History2014'):
        if fs != ['']:
            for f in fs:
                if f.endswith('.psv') and '-ND-' in f and 'CSI300' in f:
                    print (f)
                    try:
                        t_data = pd.read_csv(os.path.join(p, f), sep='|')
                    except:
                        t_data = pd.read_csv(os.path.join(p, f), sep='|',encoding='Windows-1252')

                    t_data['Date of Portfolio'] = pd.to_datetime(t_data['Date of Portfolio'].astype(str),format='%Y%m%d')
                    t_data['Ticker'] = t_data['Database Symbol'].str[-6:]
                    
                
    t_data = t_data[['Date of Portfolio', 'CSRC Industry Description',
       'CSRC Industry Description - Full', 'Description', 'Index Description',
       'ISIN Code', 'Sedol Code', 
       'Database Source', 'Database Symbol', 'Currency Code',
       'Country Description', 'Country Code', 'Exchange',
       'Industry Level 1 Code', 'Industry Level 1 Description',
       'Industry Level 2 Code', 'Industry Level 2 Description',
       'Industry Level 3 Code', 'Industry Level 3 Description',
       'Industry Level 4 Code', 'Industry Level 4 Description',
       'Sector Description', 'Investable Factor',
       'Investable Market Value in Local Currency',
       'Market Value in Local Currency',
       'Gross Investable Market Value in Local Currency',
       'Total Return in Local Currency', 'Unadjusted Price in Local Currency',
       'Investable Weight', 'Total Return Investible Weight',
       'Investable Weight in Index (Source)', 'Investable Shares Outstanding',
       'Shares Outstanding', 'CSRC Industry Code', 'CSRC Industry Code - Full',
       'Ticker']]
                    t_data.to_sql('index_constituent_rime_csi300', param_engine , index = False, if_exists = 'append', chunksize = 10000)
    
    # 500 & 300 historical performance
    i_perf = pd.read_csv(r"S:\TZ\China Data Hunt\cache\000300_000905.csv")
    i_perf['DataDate'] = pd.to_datetime(i_perf['DataDate'])
    i_perf.to_sql('index_constituent_csi300500_perf', param_engine , index = False, if_exists = 'append', chunksize = 10000)



def get_rime_csi500_mem():
    
    csi500 = get_sql('''select [date of portfolio] as datadate, [primary ric company level] as Ticker, 1 as flag_csi500 
                     from cndb.dbo.index_constituent_rime_csi500 where [investable weight]!=0 ''' )
    
    c_sh = csi500['Ticker'].str[0].isin(['6'])
    c_sz = csi500['Ticker'].str[0].isin(['0', '3'])
    csi500.loc[c_sh, 'ticker'] = csi500.loc[c_sh, 'Ticker'].str[:6] + '.SH'
    csi500.loc[c_sz, 'ticker'] = csi500.loc[c_sz, 'Ticker'].str[:6] + '.SZ'
    
    
    return csi500[['ticker','datadate','flag_csi500']]
    
def get_rime_csi800_mem():
    
    csi500 = get_sql('''select [date of portfolio] as datadate, [primary ric company level] as Ticker, 1 as flag_csi800 
                     from cndb.dbo.index_constituent_rime_csi500 where [investable weight]!=0 ''' )
    
    c_sh = csi500['Ticker'].str[0].isin(['6'])
    c_sz = csi500['Ticker'].str[0].isin(['0', '3'])
    csi500.loc[c_sh, 'ticker'] = csi500
.loc[c_sh, 'Ticker'].str[:6] + '.SH'
    csi500.loc[c_sz, 'ticker'] = csi500.loc[c_sz, 'Ticker'].str[:6] + '.SZ'
    
    csi300 = get_sql('''select [date of portfolio] as datadate, [database symbol] as Ticker, 1 as flag_csi800 
                     from cndb.dbo.index_constituent_rime_csi300 where [investable weight]!=0 ''' )
    
    c_sh = csi300['Ticker'].str[1].isin(['6'])
    c_sz = csi300['Ticker'].str[1].isin(['0', '3'])
    csi300.loc[c_sh, 'ticker'] = csi300.loc[c_sh, 'Ticker'].str[-6:] + '.SH'
    csi300.loc[c_sz, 'ticker'] = csi300.loc[c_sz, 'Ticker'].str[-6:] + '.SZ'
    
    return csi500[['ticker','datadate','flag_csi800']].append(csi300[['ticker','datadate','flag_csi800']])
    



def prepare_stock_borrowing_list():
    # output data is tdate continuous
    # only output tickers that can be borrowed
    
    i_rzrq_tk = yu.get_sql('''
                           select s_info_windcode as ticker, S_MARGIN_EFFECTDATE, S_MARGIN_ELIMINDATE
                           from wind.dbo.AShareMarginSubject 
                           where s_margin_sharetype = 244000002 
                           order by s_info_windcode ''')
    
    o_rq_tk = []
    for dt in pd.date_range(start='2016-01-01', end='2022-07-31'):
        print('.',end='')
        dtstr = dt.strftime('%Y%m%d')
        t_rzrq = i_rzrq_tk[(i_rzrq_tk['S_MARGIN_EFFECTDATE']<=dtstr) &\
                           (i_rzrq_tk['S_MARGIN_ELIMINDATE'].isnull()|(i_rzrq_tk['S_MARGIN_ELIMINDATE']>=dtstr))]
        t_rzrq['datadate'] = dt
        t_rzrq['flg_rq'] = 1
        if t_rzrq.duplicated(subset='ticker').sum() > 0:
            print('error')
        else:
            o_rq_tk.append(t_rzrq[['ticker','datadate','flg_rq']])
    o_rq_tk = pd.concat(o_rq_tk, axis=0)
    o_rq_tk.to_parquet(r'S:\TZ\China Data Hunt\cache\shsz_borrow_list.parquet')
    

def get_stock_borrowing_list():
    return pd.read_parquet(r'S:\TZ\China Data Hunt\cache\shsz_borrow_list.parquet')


def prepare_stock_levbuy_list():
    # output data is tdate continuous
    # only output tickers that can be leverage-bought
    
    i_rzrq_tk = yu.get_sql('''
                           select s_info_windcode as ticker, S_MARGIN_EFFECTDATE, S_MARGIN_ELIMINDATE
                           from wind.dbo.AShareMarginSubject 
                           where s_margin_sharetype = 244000001 
                           order by s_info_windcode ''')
    
    o_rz_tk = []
    for dt in pd.date_range(start='2016-01-01', end='2022-07-31'):
    
    print('.',end='')
        dtstr = dt.strftime('%Y%m%d')
        t_rzrq = i_rzrq_tk[(i_rzrq_tk['S_MARGIN_EFFECTDATE']<=dtstr) &\
                           (i_rzrq_tk['S_MARGIN_ELIMINDATE'].isnull()|(i_rzrq_tk['S_MARGIN_ELIMINDATE']>=dtstr))]
        t_rzrq['datadate'] = dt
        t_rzrq['flg_rz'] = 1
        if t_rzrq.duplicated(subset='ticker').sum() > 0:
            print('error')
        else:
            o_rz_tk.append(t_rzrq[['ticker','datadate','flg_rz']])
    o_rz_tk = pd.concat(o_rz_tk, axis=0)
    o_rz_tk.to_parquet(r'S:\TZ\China Data Hunt\cache\shsz_levbuy_list.parquet')
    

def get_stock_levbuy_list():
    return pd.read_parquet(r'S:\TZ\China Data Hunt\cache\shsz_levbuy_list.parquet')




    
def prepare_shortable_amount():
    
    # the output is 
    
    # for each ticker, on each date, it gives us shortable shares count and shortable MC, no fees
    
    # get sedol / ticker mapping
    o_bbg_sedol = get_sql('''select distinct Sedol, ticker from [BackTest].[dbo].[IMPACTH_isin_sedol]''')
    o_bbg_sedol = o_bbg_sedol.dropna()
    c_sz = o_bbg_sedol['ticker'].str[0].isin(['0','3'])
    o_bbg_sedol.loc[c_sz, 'ticker'] = o_bbg_sedol.loc[c_sz, 'ticker'] + '.SZ'
    c_sh = o_bbg_sedol['ticker'].str[0].isin(['6'])
    o_bbg_sedol.loc[c_sh, 'ticker'] = o_bbg_sedol.loc[c_sh, 'ticker'] + '.SH'
    
    # get RMB prices 
    i_rmb_px = get_sql('''select s_info_windcode as ticker, trade_dt as datadate, 
                       S_DQ_CLOSE as c from wind.dbo.ashareeodprices''')
    i_rmb_px['datadate'] = pd.to_datetime(i_rmb_px['datadate'], format='%Y%m%d')
    i_rmb_px = i_rmb_px.sort_values(['datadate','ticker'])
    
    # get "china indicative availability" files, 20180509 onwards
    i_files_ia = os.listdir(r'\\ad\dfs\botraders\alltraders\China_Avail\history')
    i_files_ia = [i for i in i_files_ia if i.startswith('china_indicative_availability')]
    i_files_ia = [i for i in i_files_ia if ('withoutFee' not in i) and ('20180509_174744' not in i) and ('_BBG_' not in i)]
    
    
    # loop over cdates
    o_data_short_amount = []
    for f in i_files_ia:
        print(f.split('_')[3].replace('.csv',''), end=' ')
        
        # read data
        t_r = pd.read_csv(os.path.join(r'\\ad\dfs\botraders\alltraders\China_Avail\history', f))
        t_r = t_r.rename(columns = {'Value':'shortable_mc_usd', 'StockAmount':'shortable_shares'})
        
        # shortable shares from top PB
        c_topPB = t_r['Broker'].isin(['GS', 'MorganPB'])
     
   t_r.loc[c_topPB, 'shortable_shares_topPB'] = t_r.loc[c_topPB, 'shortable_shares']
    
        # attach WIND ticker, get rid of SEDOLs that cannot be mapped to a ticker
        t_r = t_r.merge(o_bbg_sedol, on = ['Sedol'], how = 'left')
        t_r = t_r[t_r['ticker'].notnull()]
        
        # group to ticker
        t_r_tk = t_r.groupby('ticker')[['shortable_shares','shortable_shares_topPB','shortable_mc_usd']].sum()
        t_r_tk = t_r_tk.reset_index()
        
        # get ET modified time 
        fname = pathlib.Path(os.path.join(r'\\ad\dfs\botraders\alltraders\China_Avail\history', f))
        mtime = datetime.datetime.fromtimestamp(fname.stat().st_mtime)
        t_r_tk['publish_datetime_et'] = mtime
        t_r_tk['publish_datetime_et'] = t_r_tk['publish_datetime_et'].dt.tz_localize('US/Eastern')
        
        # get CST publish datetime and datadate
        # data published on T+1 CST 8am, date string from file name is T+0. Hence datadate=T+0
        t_r_tk['publish_datetime_cst'] = t_r_tk['publish_datetime_et'].dt.tz_convert('Asia/Shanghai')
        t_r_tk['publish_datetime_cst'] = t_r_tk['publish_datetime_cst'].dt.tz_localize(None)
        t_r_tk['datadate'] = pd.to_datetime(f.split('_')[3].replace('.csv',''))
        t_r_tk = t_r_tk.sort_values('datadate')
        
        # attach rmb price
        t_rmb_px_maxdd = i_rmb_px.loc[i_rmb_px['datadate']<=mtime, 'datadate'].max()
        t_rmb_px = i_rmb_px[i_rmb_px['datadate']==t_rmb_px_maxdd]
        t_rmb_px = t_rmb_px.drop(columns=['datadate'])
        t_r_tk = t_r_tk.merge(t_rmb_px, on = ['ticker'], how = 'left')
        t_r_tk['shortable_mc_rmb'] = t_r_tk['shortable_shares'].multiply(t_r_tk['c'])
        
        t_r_tk = t_r_tk[['ticker','datadate','shortable_shares','shortable_shares_topPB','shortable_mc_rmb']]
        
        # append
        o_data_short_amount.append(t_r_tk)
        
    o_data_short_amount = pd.concat(o_data_short_amount, axis=0)
    o_data_short_amount.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_shortable_amount.parquet')

    
def get_shortable_amount():
    return pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_shortable_amount.parquet')
    
    

def get_shortable_amount_n_fee_etb():
    # this data is only available on tdates
    
    i_etb = get_sql("select * from CNDB.dbo.CN_ETBList_ABC")
    i_etb = i_etb.rename(columns = {'Ticker':'ticker', 'DataDate':'datadate_p1d'})
    
    c_sh = i_etb['ticker'].str[0].isin(['6'])
    c_sz = i_etb
['ticker'].str[0].isin(['0', '3'])
    i_etb.loc[c_sh, 'ticker'] = i_etb.loc[c_sh, 'ticker'] + '.SH'
    i_etb.loc[c_sz, 'ticker'] = i_etb.loc[c_sz, 'ticker'] + '.SZ'
    
    return i_etb



def prepare_shortable_amount_n_fee():
    
    # the output is cdate continuous
    # for each ticker, on each date, it gives us shortable shares count, fees, shortable MC, etc.
    
    
    # get sedol / ticker mapping
    o_bbg_sedol = get_sql('''select distinct Sedol, ticker from [BackTest].[dbo].[IMPACTH_isin_sedol]''')
    o_bbg_sedol = o_bbg_sedol.dropna()
    c_sz = o_bbg_sedol['ticker'].str[0].isin(['0','3'])
    o_bbg_sedol.loc[c_sz, 'ticker'] = o_bbg_sedol.loc[c_sz, 'ticker'] + '.SZ'
    c_sh = o_bbg_sedol['ticker'].str[0].isin(['6'])
    o_bbg_sedol.loc[c_sh, 'ticker'] = o_bbg_sedol.loc[c_sh, 'ticker'] + '.SH'
    
    # get RMB prices 
    i_rmb_px = get_sql('''select s_info_windcode as ticker, trade_dt as datadate, 
                       S_DQ_CLOSE as c from wind.dbo.ashareeodprices''')
    i_rmb_px['datadate'] = pd.to_datetime(i_rmb_px['datadate'], format='%Y%m%d')
    i_rmb_px = i_rmb_px.sort_values(['datadate','ticker'])
    
    # get files
    i_files_r = os.listdir(r'\\ad\dfs\botraders\alltraders\China_Avail\history')
    i_files_r = [i for i in i_files_r if i.startswith('china_indicative_availability')]
    i_files_r = [i for i in i_files_r if ('withoutFee' not in i) and  ('20180509_174744' not in i)]
    
    i_files_r_fee = [i for i in i_files_r if (i.split('_')[3][:8] >= '20190328') & ('_BBG_' not in i)]
    i_files_r_nofee = [i for i in i_files_r if (i.split('_')[3][:8] < '20190328') & ('_BBG_' not in i)]
    
    
    # analyze files with fees 
    o_data_tk_lvl_fee = pd.DataFrame()
    o_data_brk_lvl_fee = pd.DataFrame()
    for f in i_files_r_fee:
        print(f.split('_')[3].replace('.csv',''), end=' ')
        
        # read data
        t_r = pd.read_csv(os.path.join(r'\\ad\dfs\botraders\alltraders\China_Avail\history', f))
        t_r = t_r.rename(columns = {'Value':'shortable_mc_usd', 'StockAmount':'shortable_shares'})
        
        # alert
        if t_r['Fee'].isnull().sum() > 0:
            raise Exception('Fee has nan values.')
    
        # get ET modified time 
        fname = pathlib.Path(os.path.join(r'\\ad\dfs\botraders\alltraders\China_Avail\history', f))
        mtime = datetime.datetime.fromtimestamp(fname.stat().st_mtime)
        t_r['publish_datetime_et'] = mtime
        t_r['publish_datetime_et'] = t_r['publish_da
tetime_et'].dt.tz_localize('US/Eastern')
        
        # get CST publish datetime and datadate
        t_r['publish_datetime_cst'] = t_r['publish_datetime_et'].dt.tz_convert('Asia/Shanghai')
        t_r['publish_datetime_cst'] = t_r['publish_datetime_cst'].dt.tz_localize(None)
        t_r['datadate'] = pd.to_datetime(f.split('_')[3].replace('.csv','')) + pd.to_timedelta('1 day')
        t_r = t_r.sort_values('datadate')
        
        # attach WIND ticker, get rid of SEDOLs that cannot be mapped to a ticker
        t_r = t_r.merge(o_bbg_sedol, on = ['Sedol'], how = 'left')
        t_r = t_r[t_r['ticker'].notnull()]
        
        # attach rmb price
        t_r = pd.merge_asof(t_r, i_rmb_px, by = ['ticker'], on = ['datadate'], allow_exact_matches = False)
        t_r['shortable_mc_rmb'] = t_r['shortable_shares'].multiply(t_r['c'])
        
        # format
        t_r = t_r.drop(columns = ['CCY','ReportDate','publish_datetime_et','c'])
        
        # process fee
        t_r.loc[t_r['Fee']>50, 'Fee'] = 10 ###!!! This is a huge assumption here ...
        t_r['fee_x_shortable_shares'] = t_r['Fee'].multiply(t_r['shortable_shares'])
        
        # weighted fee
        t_r_grp = t_r.groupby(['ticker','datadate','publish_datetime_cst']).agg({'shortable_mc_rmb':sum,
                             'shortable_mc_usd':sum,'shortable_shares':sum,'fee_x_shortable_shares':sum}).reset_index()
        t_r_grp['fee'] = t_r_grp['fee_x_shortable_shares'].divide(t_r_grp['shortable_shares'])
        t_r_grp = t_r_grp.drop(columns = ['fee_x_shortable_shares'])
        
        # append
        o_data_tk_lvl_fee = o_data_tk_lvl_fee.append(t_r_grp, ignore_index = True)
        if mtime.year == 2019:       
            o_data_brk_lvl_fee = o_data_brk_lvl_fee.append(t_r, ignore_index = True)
    
    # earliest fee 
    o_data_brk_lvl_fee = o_data_brk_lvl_fee.sort_values(['datadate', 'ticker'])
    o_data_brk_lvl_fee_earliest = o_data_brk_lvl_fee.groupby(['Broker','Sedol','ticker'])['Fee'].first()
    o_data_brk_lvl_fee_earliest = o_data_brk_lvl_fee_earliest.reset_index()
    
    # analyze files without fees
    o_data_tk_lvl_nofee = pd.DataFrame()
    for f in i_files_r_nofee:
        print(f.split('_')[3].replace('.csv',''), end=' ')
        
        # read data
        t_r = pd.read_csv(os.path.join(r'\\ad\dfs\botraders\alltraders\China_Avail\history', f))
        t_r = t_r.rename(columns = {'Value':'shortable_mc_usd', 'StockAmount':'shortable_shares'})
        
  
      # get ET modified time 
        fname = pathlib.Path(os.path.join(r'\\ad\dfs\botraders\alltraders\China_Avail\history', f))
        mtime = datetime.datetime.fromtimestamp(fname.stat().st_mtime)
        t_r['publish_datetime_et'] = mtime
        t_r['publish_datetime_et'] = t_r['publish_datetime_et'].dt.tz_localize('US/Eastern')
        
        # get CST publish datetime and datadate
        t_r['publish_datetime_cst'] = t_r['publish_datetime_et'].dt.tz_convert('Asia/Shanghai')
        t_r['publish_datetime_cst'] = t_r['publish_datetime_cst'].dt.tz_localize(None)
        t_r['datadate'] = pd.to_datetime(f.split('_')[3].replace('.csv','')) + pd.to_timedelta('1 day')
        
        # attach WIND ticker, get rid of SEDOLs that cannot be mapped to a ticker
        t_r = t_r.merge(o_bbg_sedol, on = ['Sedol'], how = 'left')
        t_r = t_r[t_r['ticker'].notnull()]
        
        # attach rmb price
        t_r = pd.merge_asof(t_r, i_rmb_px, by = ['ticker'], on = ['datadate'], allow_exact_matches = False)
        t_r['shortable_mc_rmb'] = t_r['shortable_shares'].multiply(t_r['c'])
        
        # format
        t_r = t_r.drop(columns = ['CCY','ReportDate','publish_datetime_et','c'])
        
        # merge fee
        t_r = t_r.merge(o_data_brk_lvl_fee_earliest, on = ['Broker', 'Sedol', 'ticker'], how = 'left')
        t_r = t_r[t_r['Fee'].notnull()]
        
        # weighted fee
        t_r['fee_x_shortable_shares'] = t_r['Fee'].multiply(t_r['shortable_shares'])
        t_r_grp = t_r.groupby(['ticker','datadate','publish_datetime_cst']).agg({'shortable_mc_rmb':sum,
                             'shortable_mc_usd':sum,'shortable_shares':sum,'fee_x_shortable_shares':sum}).reset_index()
        t_r_grp['fee'] = t_r_grp['fee_x_shortable_shares'].divide(t_r_grp['shortable_shares'])
        t_r_grp = t_r_grp[t_r_grp['shortable_shares']>0]
        t_r_grp = t_r_grp.drop(columns = ['fee_x_shortable_shares'])
        
        # append
        o_data_tk_lvl_nofee = o_data_tk_lvl_nofee.append(t_r_grp, ignore_index = True)
        
    # combine fee files nad no-fee files, then output to csv
    o_fee = o_data_tk_lvl_nofee.append(o_data_tk_lvl_fee, sort = False)
    o_fee = o_fee.reset_index(drop = True)
    o_fee['publish_datetime_cst'] = pd.to_datetime(o_fee['publish_datetime_cst'].dt.strftime('%Y-%m-%d %H:%M:%S'))
    o_fee.to_csv(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_shortable_limit.csv',index = False)
    o_fee.to_parquet(r'S:\TZ\China Data 
Hunt\cache\pWIND_util_prepare_shortable_limit.parquet')
    
    # create table china_indicative_availability (Ticker varchar(20), DataDate datetime, publish_datetime_cst datetime, shortable_shares float, shortable_mc_rmb float, shortable_mc_usd float, fee float)
    # bcp [Backtest].[dbo].[china_indicative_availability] in "S:\TZ\China Data Hunt\cache\pWIND_util_prepare_shortable_limit.csv" -c -t  , -S summitsqldb -U AD\thzhang -T -F 2 

def get_shortable_amount_n_fee():
    
    return get_sql("select * from [Backtest].[dbo].[china_indicative_availability]")


def get_wind_limit():
    
    # output is tdate continuous
    # it gives (1, 0) data that tells us limit up/down information
    
    i_eod = get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                    S_DQ_OPEN as o, S_DQ_HIGH as h, S_DQ_LOW as l, S_DQ_CLOSE as c, 
                    S_DQ_LIMIT as limit_up, S_DQ_STOPPING as limit_down
                    from wind_prod.dbo.AShareEODPrices''')
    
    c_up_allday = i_eod['l'] == i_eod['limit_up']
    i_eod.loc[c_up_allday, 'limitup_allday'] = 1
    i_eod['limitup_allday'] = i_eod['limitup_allday'].replace(np.nan, 0)
    
    c_down_allday = i_eod['h'] == i_eod['limit_down']
    i_eod.loc[c_down_allday, 'limitdown_allday'] = 1
    i_eod['limitdown_allday'] = i_eod['limitdown_allday'].replace(np.nan, 0)
    
    c_up_touch = (i_eod['l'] < i_eod['limit_up']) & (i_eod['h'] == i_eod['limit_up'])
    i_eod.loc[c_up_touch, 'limitup_touch'] = 1
    i_eod['limitup_touch'] = i_eod['limitup_touch'].replace(np.nan, 0)
    
    c_down_touch = (i_eod['h'] > i_eod['limit_down']) & (i_eod['l'] == i_eod['limit_down'])
    i_eod.loc[c_down_touch, 'limitdown_touch'] = 1
    i_eod['limitdown_touch'] = i_eod['limitdown_touch'].replace(np.nan, 0)
    
    c_up_onclose = i_eod['c'] == i_eod['limit_up']
    i_eod.loc[c_up_onclose , 'limitup_onclose'] = 1
    i_eod['limitup_onclose'] = i_eod['limitup_onclose'].replace(np.nan, 0)
    
    c_down_onclose = i_eod['c'] == i_eod['limit_down']
    i_eod.loc[c_down_onclose , 'limitdown_onclose'] = 1
    i_eod['limitdown_onclose'] = i_eod['limitdown_onclose'].replace(np.nan, 0)
    
    # format 
    i_eod['datadate'] = pd.to_datetime(i_eod['datadate'], format= '%Y%m%d')
    
    return i_eod[['ticker', 'datadate',
                  'limitup_allday', 'limitdown_allday', 'limitup_touch',
                  'limitdown_touch', 'limitup_onclose', 'limitdown_onclose']]


### 特殊状态: 停牌

def get_wind_suspensi
on():
    
    i_sus = get_sql('''select s_info_windcode as ticker, trade_dt as datadate, s_dq_TRADESTATUS as status from wind.dbo.ashareeodprices''')
    i_sus['datadate']= pd.to_datetime(i_sus['datadate'], format='%Y%m%d')
    
    i_sus.loc[i_sus['status']=='停牌', 'flag_suspension'] = 1
    i_sus['flag_suspension'] = i_sus['flag_suspension'].fillna(0)
    
    return i_sus[['ticker','datadate','flag_suspension']]



def get_st_flag():
    
    i_st = get_sql('''select s_info_windcode as ticker, begindate, enddate,
                  s_info_name as st_name from wind.dbo.ASharePreviousName 
                  where s_info_name like 'ST%' or s_info_name like '*ST%' ''')
    i_st.loc[i_st['enddate'].isnull(), 'enddate'] = datetime.date.today().strftime('%Y%m%d')
    i_st['begindate'] = pd.to_datetime(i_st['begindate'], format='%Y%m%d')
    i_st['enddate'] = pd.to_datetime(i_st['enddate'], format='%Y%m%d')
    
    def gen_df(r):
        sr_date = pd.date_range(start=r['begindate'], end=r['enddate'])
        return pd.DataFrame({'datadate': sr_date, 'ticker': [r['ticker']]*len(sr_date), 
                             'name': [r['st_name']]*len(sr_date), 'flag_st': [1]*len(sr_date)})
    i_st_flag = pd.concat(gen_df(r) for i, r in i_st.iterrows() )
    
    return i_st_flag



# AsharePreviusName gives us PIT ticker names, including ST, *ST, T, etc.
# AshareDescription gives us delist date, etc.
# AShareST has ST information
    
def get_delist_tag():
    # the output is: ticker-date-deslit_tag, date is calendar date continuous between delist announcement date and actual delist date
    
    i_dl = get_sql('''select s_info_windcode as ticker, ann_dt, begindate, enddate 
                    from wind.dbo.asharepreviousname 
                    where changereason in ('200004000','200027000','200036000') 
                    ''')
    i_dl.loc[i_dl['enddate'].isnull(), 'enddate'] = '20301231'
    i_dl['begindate'] = pd.to_datetime(i_dl['begindate'], format='%Y%m%d')
    i_dl['enddate'] = pd.to_datetime(i_dl['enddate'], format='%Y%m%d')
    i_dl['ann_dt'] = pd.to_datetime(i_dl['ann_dt'], format='%Y%m%d')
    
    o_dl = pd.DataFrame()
    for i, r in i_dl.iterrows():
        t_daterange = pd.date_range(start = r['ann_dt'], end = r['enddate'])
        o_dl = o_dl.append(pd.DataFrame({'datadate': t_daterange,
                                         'ticker': r['ticker'],
                                         'delist_flag':1}), 
                           ignore_inde
x = True)
    
    return o_dl    



def prepare_abnormal_move():
    # this outputs total abnormal cnt t1y t1q t1m, for each ticker on each cdate
    
    # get data
    
    i_ab = get_sql('''select s_info_windcode as ticker, end_dt as datadate, 
                   type_code from wind_prod.dbo.AShareStrangeTradedetail''')
    i_ab['datadate'] = pd.to_datetime(i_ab['datadate'], format='%Y%m%d')
        
    
    # loop
    
    o_ab = []    
    for dt in pd.date_range(start = '2016-01-01', end = '2022-07-21'):
        
        t_ab_t1y = i_ab[(i_ab['datadate']<=dt)&(i_ab['datadate']>=dt-pd.to_timedelta('365 days'))]
        t_ab_t1q = t_ab_t1y[(t_ab_t1y['datadate']<=dt)&(t_ab_t1y['datadate']>=dt-pd.to_timedelta('91 days'))]
        t_ab_t1m = t_ab_t1y[(t_ab_t1y['datadate']<=dt)&(t_ab_t1y['datadate']>=dt-pd.to_timedelta('28 days'))]
        
        s_ab_t1y = t_ab_t1y.groupby('ticker')['datadate'].count().reset_index()
        s_ab_t1y.columns = ['ticker', 'abnml_cnt_t1y']
        s_ab_t1q = t_ab_t1q.groupby('ticker')['datadate'].count().reset_index()
        s_ab_t1q.columns = ['ticker', 'abnml_cnt_t1q']
        s_ab_t1m = t_ab_t1m.groupby('ticker')['datadate'].count().reset_index()
        s_ab_t1m.columns = ['ticker', 'abnml_cnt_t1m']
        
        s = s_ab_t1y.merge(s_ab_t1q, on='ticker', how='outer')
        s = s.merge(s_ab_t1m, on='ticker', how='outer')
        s['datadate'] = dt        
        o_ab.append(s)
        
    o_ab = pd.concat(o_ab, axis = 0)
    
    o_ab.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_abnormal_move.parquet')



def prepare_special_situation():
    
    
    i_tdate_cal = get_sql('''select s_info_windcode as ticker, trade_dt as datadate from wind.dbo.ashareeodprices''')
    i_tdate_cal['datadate'] = pd.to_datetime(i_tdate_cal['datadate'], format = '%Y-%m-%d')
    
    i_lmt = get_wind_limit()
    i_sus = get_wind_suspension()
    i_st = get_st_flag()
    i_ipo = get_ipo_date()
    
    i_ss = i_tdate_cal.merge(i_lmt, on = ['ticker', 'datadate'], how = 'left')
    i_ss = i_ss.merge(i_sus, on = ['ticker', 'datadate'], how = 'left')
    i_ss = i_ss.merge(i_st, on = ['ticker', 'datadate'], how = 'left')
    i_ss = i_ss.merge(i_ipo, on = ['ticker'], how = 'left')
    i_ss = i_ss.sort_values(['ticker','datadate'])
    
    # at updown limit @ market close
    c_lmt = (i_ss['limitup_allday']==1)|(i_ss['limitdown_allday']==1)|(i_ss['limitup_onclose']==1)|(i_ss['limitdown_onclose']==1)
    i_ss.loc[c_lmt, 'fla
g_lmt'] = 1
    i_ss['flag_lmt'] = i_ss['flag_lmt'].fillna(0)
    
    # trailing 1w limit
    i_ss['flag_lmt_t1w'] = i_ss.groupby('ticker').rolling(datetime.timedelta(days=7),on='datadate')['flag_lmt'].sum().values
    i_ss.loc[i_ss['flag_lmt_t1w']>0, 'flag_lmt_t1w'] = 1
    i_ss.loc[i_ss['flag_lmt_t1w']==0, 'flag_lmt_t1w'] = 0
    
    # trailing 1w suspension
    i_ss['flag_suspension_t1w'] = i_ss.groupby('ticker').rolling(datetime.timedelta(days=7),on='datadate')['flag_suspension'].sum().values
    i_ss.loc[i_ss['flag_suspension_t1w']>0, 'flag_suspension_t1w'] = 1
    i_ss.loc[i_ss['flag_suspension_t1w']==0, 'flag_suspension_t1w'] = 0
    
    # days since ipo
    i_ss['days_since_ipo'] = (i_ss['datadate'] - i_ss['ipo_date']).dt.days
    
    # output 
    i_ss = i_ss[['datadate', 'ticker', 
                'flag_lmt', 'flag_lmt_t1w', 
                'flag_suspension', 'flag_suspension_t1w',
                'flag_st',
                'days_since_ipo']]
    i_ss = i_ss.fillna(0)
    
    i_ss.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_special_situation.parquet')
    
    
    
    
def get_special_situation():
    
    return pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_special_situation.parquet')
    

### forex
def prepare_wind_fx():
    
    # read data sources
    i_fx = pd.read_excel(r"S:\TZ\China Data Hunt\cache\hkconnect_fx.xlsx")    
    i_hkd_usd = get_q('''
                      fx: raze{show x;
                      t_fx: h (`run;`gd;`ds`tbl`date`id`columns`where!(`bbg;`curr;x;`;`;"(NAME =`$\\"HKD-USD X-RATE\\"), (region = `asia2) " ));t_fx}
                      each 2010.01.01 + til ( 1 + 2021.03.25-2010.01.01);fx''')
    i_hkd_usd = i_hkd_usd[['date','PX_MID']]
    i_hkd_usd = i_hkd_usd.rename(columns={'date':'DataDate', 'PX_MID': 'USDHKD'})
    
    i_cnh_usd = get_q('''
                      fx: raze{show x;
                      t_fx: h (`run;`gd;`ds`tbl`date`id`columns`where!(`bbg;`curr;x;`;`;"(NAME =`$\\"USD-CNH Cross Rate\\"), (region = `asia2) " ));t_fx}
                      each 2010.01.01 + til ( 1 + 2021.03.25-2010.01.01);fx''')
    i_cnh_usd = i_cnh_usd[['date', 'PX_MID']]
    i_cnh_usd = i_cnh_usd.rename(columns={'date':'DataDate', 'PX_MID': 'CNYUSD'})
    
    # merge data
    i_fx = i_fx.merge(i_hkd_usd, on = ['DataDate'], how = 'left')
    
    # calculate hk connect rate: HKD/CNY
    i_fx['CNYHKD'] = (i_fx['buy_rate'] + i_fx['sell_rate'])*0.5
    i_fx = i_fx.drop(columns = ['buy_rate',
 'sell_rate', 'currency'])
    
    # calculate USD/CNY
    i_fx['CNYUSD'] = i_fx['CNYHKD'].divide(i_fx['USDHKD'])
    
    # append backfilled USD/CNY
    i_fx = i_cnh_usd[i_cnh_usd['DataDate']<i_fx['DataDate'].min()].append(i_fx, ignore_index = True)
    
    
    # calculate USD/CNY from yesterday
    i_fx = i_fx.sort_values('DataDate')
    i_fx['CNYUSD_l1d'] = i_fx['CNYUSD'].shift()
    
    # output
    i_fx = i_fx[['DataDate', 'CNYHKD', 'USDHKD', 'CNYUSD', 'CNYUSD_l1d']]
    param_engine = create_engine('mssql+pyodbc://summitsqldb') #'mssql+pyodbc://FGSQLBACKTEST'
    i_fx.to_sql("Static_Data_FX", param_engine, index = False, if_exists = 'replace')

def get_wind_fx():
    return get_sql("select * from [BackTest].[dbo].[Static_Data_FX]")

    
    
### holding: mf
    
def prepare_wind_holding_mf():
    
    i_h = get_sql('''select s_info_windcode as ticker, ann_date as datadate, 
                  report_period, s_holder_compcode, s_holder_pct, s_holder_holdercategory 
                  FROM [WIND].[dbo].[ASHAREINSTHOLDERDERDATA] ''')
    i_h = i_h[i_h['s_holder_holdercategory']=='基金']
    i_h = i_h[i_h['datadate'].notnull()]
    i_h['datadate'] = pd.to_datetime(i_h['datadate'], format = '%Y%m%d')
    i_h['report_period'] = pd.to_datetime(i_h['report_period'], format = '%Y%m%d')
    i_h = i_h.sort_values(['ticker', 'report_period', 'datadate'])
    
    # current+last report_period mapping
    i_period = pd.DataFrame(i_h['report_period'].sort_values().unique(), columns = ['report_period'])
    i_period['report_period_l1q'] = i_period['report_period'].shift()
    i_period = i_period.dropna()
    
    o_h_pit = pd.DataFrame()
    for d in pd.date_range(start = '2013-01-01', end = i_h.datadate.max()):
        print(d, end=',')
        
        # only look at data whose report period is within the past 9 months
        t_h = i_h[(i_h['datadate']<=d) & (i_h['report_period']>=d-pd.to_timedelta('273 days'))]
        # get the max report_period for each fund on date d
        t_report_each_fund = t_h.groupby('s_holder_compcode')['report_period'].max().reset_index()
        t_report_each_fund = t_report_each_fund.merge(i_period, on = ['report_period'], how = 'left')
        t_report_each_fund.loc[t_report_each_fund['report_period'].dt.month.mod(6)==0,'min_report_period'] = t_report_each_fund.loc[t_report_each_fund['report_period'].dt.month.mod(6)==0,'report_period']
        t_report_each_fund.loc[t_report_each_fund['report_period'].dt.month.mod(6)!=0,'min_rep
ort_period'] = t_report_each_fund.loc[t_report_each_fund['report_period'].dt.month.mod(6)!=0,'report_period_l1q']
        t_report_each_fund = t_report_each_fund[['s_holder_compcode','min_report_period']]
        # for each fund, select data from recent 1 or 2 report periods 
        t_h = t_h.merge(t_report_each_fund, on = ['s_holder_compcode'], how = 'left')
        t_h = t_h[t_h['report_period']>=t_h['min_report_period']]
        # fpr each ticker and fund, select the most recent holding data
        t_h = t_h.sort_values(['s_holder_compcode', 'ticker', 'report_period', 'datadate'])
        t_h = t_h.drop_duplicates(subset = ['s_holder_compcode', 'ticker'], keep = 'last')
        # get total holding for each ticker
        t_output = t_h.groupby('ticker')['s_holder_pct'].sum().reset_index()
        # output
        t_output['datadate'] = d
        o_h_pit = o_h_pit.append(t_output, ignore_index = True)
    
    o_h_pit.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_holding_mf.parquet')
    
def get_wind_holding_mf():
    # output is cdate continuous
    # on each date, this tables gives the best estimate of total mutual fund holding
    
    return pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_holding_mf.parquet')


def prepare_wind_hodling_mffund_q():
    # this prepares quarterly holding for each ticker by each mutual fund (vs total mf holding from above)
    # output is not tdate continuous; it only gives a row per quarter (datadate is ann_dt)
    
    
    # fetch raw holding data
    
    i_h = get_sql('''select mfp.S_INFO_WINDCODE as fund_ticker, code.s_info_name as fund_name, code.s_info_compcode as fund_windcode, 
                    mfp.f_prt_enddate as report_period, mfp.s_info_stockwindcode as ticker, mfp.ann_date as datadate,
                    mfp.f_prt_stkvaluetonav as nav_pct, 
                    mfp.f_prt_stkvalue as hold_rmb, mfp.f_prt_stkquantity as hold_shares, 
                    mfp.F_PRT_POSSTKVALUE as hold_active_rmb, mfp.F_PRT_POSSTKQUANTITY as hold_active_shares,
                    mfp.F_PRT_PASSTKEVALUE as hold_index_rmb, mfp.F_PRT_PASSTKQUANTITY as hold_active_shares, 
                    STOCK_PER as mktcap_pct, FLOAT_SHR_PER as float_pct,
                    mf_desc.F_INFO_CORP_FUNDMANAGEMENTCOMP as corp_name, mf_desc.F_INFO_CORP_FUNDMANAGEMENTID as corp_windcode 
                    from wind.dbo.CHINAMUTUALFUNDSTOCKPORTFOLIO as mfp
                    left join wind.dbo.windcustomcode as code
          
          on mfp.S_INFO_WINDCODE = code.S_INFO_WINDCODE
                    left join wind.dbo.CHINAMUTUALFUNDDESCRIPTION as mf_desc
                    on code.S_INFO_WINDCODE = mf_desc.f_info_windcode
                    where mfp.f_prt_enddate >= '20100101' ''')

    i_h = i_h[i_h['datadate'].notnull()]
    i_h['datadate'] = pd.to_datetime(i_h['datadate'], format = '%Y%m%d')
    i_h['report_period'] = pd.to_datetime(i_h['report_period'], format = '%Y%m%d')
    i_h['hold_index_rmb'] = i_h['hold_index_rmb'].replace(np.nan, 0)
    i_h['hold_active_rmb'] = i_h['hold_rmb'] - i_h['hold_index_rmb']
    i_h['mktcap_active_pct'] = i_h['mktcap_pct'].divide(i_h['hold_rmb']).multiply(i_h['hold_active_rmb'])
    i_h = i_h.sort_values(['fund_windcode','fund_ticker','ticker', 'report_period', 'datadate'])
    
    
    
    
    # current+last report_period mapping
    i_period = pd.DataFrame(i_h['report_period'].sort_values().unique(), columns = ['report_period'])
    i_period['report_period_l1q'] = i_period['report_period'].shift()
    i_period = i_period.dropna()
    
    o_h_pit = pd.DataFrame()
    for d in i_h.sort_values('datadate').datadate.unique():
        print(d, end=',')        
        # only look at mf companies that published data on d
        # only look at data whose report period is within the past 2 years
        t_target_funds = i_h[i_h['datadate']==d]['fund_windcode'].unique().tolist()
        t_h = i_h[i_h['fund_windcode'].isin(t_target_funds)]
        t_h = t_h[(t_h['datadate']<=d) & (t_h['report_period']>=d-pd.to_timedelta('821 days'))]
        # calculate the min report_period for each fund on date d
        t_report_each_fund = t_h.groupby(['fund_windcode', 'fund_ticker', 'corp_windcode'])['report_period'].max().reset_index()
        t_report_each_fund = t_report_each_fund.merge(i_period, on = ['report_period'], how = 'left')
        t_report_each_fund.loc[t_report_each_fund['report_period'].dt.month.mod(6)==0,'min_report_period'] = t_report_each_fund.loc[t_report_each_fund['report_period'].dt.month.mod(6)==0,'report_period']
        t_report_each_fund.loc[t_report_each_fund['report_period'].dt.month.mod(6)!=0,'min_report_period'] = t_report_each_fund.loc[t_report_each_fund['report_period'].dt.month.mod(6)!=0,'report_period_l1q']
        t_report_each_fund = t_report_each_fund[['fund_windcode','min_report_period']]
        # for each fund, select data from recent 1 or 2 report periods 
        t_h_recent = t_h.merge(t_report_each_fund, on = 
['fund_windcode'], how = 'left')
        t_h_recent = t_h_recent[t_h_recent['report_period']>=t_h_recent['min_report_period']]
        # for each ticker and fund, select the most recent holding data
        t_h_recent = t_h_recent.sort_values(['fund_windcode', 'ticker', 'report_period', 'datadate'])
        t_h_recent = t_h_recent.drop_duplicates(subset = ['fund_windcode', 'ticker'], keep = 'last')
        t_h_recent = t_h_recent[['ticker','fund_windcode','fund_ticker','corp_windcode','mktcap_pct','mktcap_active_pct','hold_rmb','hold_active_rmb','nav_pct']]
        t_h_recent['datadate'] = d
        # for each ticker and fund, calculate mean holding over the past 2 years
        t_h = t_h.sort_values(['fund_windcode','ticker','report_period'])
        t_h = t_h[~t_h['report_period'].dt.month.isin([3,9])]
        t_h = t_h.groupby(['fund_windcode','ticker']).tail(4).reset_index()
        t_h_hist = t_h.groupby(['corp_windcode','fund_ticker','fund_windcode','ticker'])[['mktcap_pct','mktcap_active_pct','nav_pct']].apply(lambda x: x.sum()/4).reset_index()
        t_h_hist = t_h_hist.rename(columns = {'mktcap_pct':'mean_mktcap_pct','mktcap_active_pct':'mean_mktcap_active_pct','nav_pct':'mean_nav_pct'})
        t_h_hist['datadate'] =d        
        # merge both historical mean holding and holding today
        if len(t_h_hist) == 0:
            t_h_hist = pd.DataFrame([], columns = ['corp_windcode','fund_windcode','fund_ticker','ticker', 'mean_mktcap_pct', 'mean_mktcap_active_pct', 'mean_nav_pct', 'datadate'])
        if len(t_h_recent) == 0:
            t_h_recent = pd.DataFrame([], columns = ['corp_windcode','fund_windcode','fund_ticker','ticker', 'mktcap_pct', 'mktcap_active_pct', 'nav_pct','datadate'])
        o_t = t_h_hist.merge(t_h_recent, on = ['corp_windcode','fund_windcode','fund_ticker','ticker','datadate'], how = 'outer')
        o_t = o_t.replace(np.nan, 0)
        
        o_h_pit = o_h_pit.append(o_t, ignore_index = True)
    
    o_h_pit['datadate'] = pd.to_datetime(o_h_pit['datadate'])
    o_h_pit['corp_windcode'] = o_h_pit['corp_windcode'].astype(str)
    o_h_pit['fund_ticker'] = o_h_pit['fund_ticker'].astype(str)
    o_h_pit['fund_windcode'] = o_h_pit['fund_windcode'].astype(str)
    o_h_pit['ticker'] = o_h_pit['ticker'].astype(str)
    o_h_pit.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_holding_mffund_q.parquet') ###???
    
    # step 2: for each mutual fund, each quarterm each stock, calculate past 2 year average holding, 
    #  
   past 2 year holding quarter counts
    # 
    
    #---
    # step 3: for each meeting and participant, merge_asof holding data into it 

###holding 
# new / dropped ticker, increase / decrease weight
def prepare_wind_holding_mf_top10_owuw():
    
    #--------------------------------------------------------------------------
    # get holding data
    i_mf_holding = get_sql('''select a.s_info_windcode as ticker_fund, 
                                   a.ann_date as datadate,
                                   a.f_prt_enddate as report_period, 
                                   a.s_info_stockwindcode as ticker,
                                   a.f_prt_stkvalue as held_dollar, 
                                   a.f_prt_stkquantity as held_shares,
                                   a.stock_per/100 as pctOfMFSTK,
                                   b.s_info_compcode 
                          from wind.dbo.ChinaMutualFundStockPortfolio a
                          left join wind.dbo.windcustomcode b
                          on a.s_info_windcode = b.s_info_windcode ''')
    i_mf_holding = i_mf_holding.sort_values(['s_info_compcode','report_period','datadate','ticker','ticker_fund'])
    i_mf_holding = i_mf_holding.drop_duplicates(subset = ['s_info_compcode','report_period', 'datadate','ticker'], keep = 'first')
    i_mf_holding = i_mf_holding.sort_values(['s_info_compcode','report_period','datadate','held_dollar'])
    i_mf_holding = i_mf_holding.reset_index(drop = True)
    
    i_mf_holding['pctOfMFSTK_nrk'] = i_mf_holding.groupby(['s_info_compcode','report_period','datadate'])['held_dollar'].rank(ascending = False).values
    i_mf_holding.loc[i_mf_holding['pctOfMFSTK_nrk']<=10, 'flag_isTop10'] = 1
    
    
    o_ledger = {}
    
    for dt in i_mf_holding['datadate'].sort_values().drop_duplicates().tolist():
        print(dt.strftime('%Y%m%d'), end = ' ')
        
        # get data
        t_h = i_mf_holding[i_mf_holding['datadate']<=dt]
        
        # check if funds are in ledger
        t_o_ledger_fd = list(o_ledger.kerys())
        for fd in t_h['s_info_compcode'].unique().tolist():
            if fd not in t_o_ledger_fd:
                o_ledger['fd'] = [pd.DataFrame({'s_info_compcode':['test']})]
        
        for fd in t_h['s_info_compcode'].unique().tolist():
            
            t_curr = t_h[t_h['s_info_compcode']==fd]
            t_prev = o_ledger[fd][-1]
            
             # if we are processing the first data for a fund

            if t_prev['s_info_compcode'].unique()[0] != t_curr['s_info_compcode'].unique()[0]:
                o_ledger[fd].append(t_curr)
        
    
    


### holding ETF
    
def prepare_etf_holding():
    # parquet files come from pETF_strat_5 etc.
    
    i_creation_u = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\cninfo_etf_creation_unit.parquet')
    i_creation_u = i_creation_u[['SECCODE','DECLAREDATE','F008N']]
    i_creation_u = i_creation_u.rename(columns={'SECCODE':'fund_seccode','DECLAREDATE':'publish_date','F008N':'etf_shares_per_unit'})
    i_creation_u['publish_date']= pd.to_datetime(i_creation_u['publish_date'])
    i_creation_u = i_creation_u.sort_values(['fund_seccode','publish_date'])
    i_creation_u['etf_shares_per_unit_1d'] = i_creation_u.groupby('fund_seccode')['etf_shares_per_unit'].shift()
    i_creation_u['etf_shares_per_unit'] = i_creation_u['etf_shares_per_unit'].fillna(0)
    i_creation_u['etf_shares_per_unit_1d'] = i_creation_u['etf_shares_per_unit_1d'].fillna(0)
    
    
    i_closure = i_creation_u.groupby('fund_seccode')['publish_date'].max().reset_index()
    i_closure.loc[i_closure['publish_date']=='2021-07-29', 'publish_date'] = pd.to_datetime('2025-12-31')
    i_closure = i_closure.rename(columns={'publish_date':'closure_date'})
    
    i_icpt = i_creation_u.groupby('fund_seccode')['publish_date'].min().reset_index()
    i_icpt = i_icpt.rename(columns={'publish_date':'icpt_date'})
    
    
    t_etf_tk = i_creation_u['fund_seccode'].unique().tolist()
    i_etf_shr_wind = get_sql(''' select * from wind.dbo.ChinaMutualFundShare''')
    i_etf_shr_wind = i_etf_shr_wind.sort_values(['F_INFO_WINDCODE','ANN_DATE','CHANGE_DATE'])
    i_etf_shr_wind = i_etf_shr_wind.drop_duplicates(subset=['F_INFO_WINDCODE', 'ANN_DATE'], keep = 'last')
    i_etf_shr_wind['fund_seccode'] = i_etf_shr_wind['F_INFO_WINDCODE'].str.split('.').str[0]
    i_etf_shr_wind = i_etf_shr_wind[i_etf_shr_wind['fund_seccode'].isin(t_etf_tk)]
    i_etf_shr_wind['publish_date'] = pd.to_datetime(i_etf_shr_wind['ANN_DATE'], format = '%Y%m%d')
    i_etf_shr_wind['EQY_SH_OUT'] = i_etf_shr_wind['FUNDSHARE_TOTAL']*10000
    i_etf_shr_wind = i_etf_shr_wind.sort_values(['fund_seccode','publish_date'])
    i_etf_shr_wind['EQY_SH_OUT_1d'] = i_etf_shr_wind.groupby(['fund_seccode'])['EQY_SH_OUT'].shift()
    i_etf_shr_wind = i_etf_shr_wind[['publish_date', 'fund_seccode', 'EQY_SH_OUT','EQY_SH_OUT_1d']]
    i_etf_shr_wind = i_etf_shr_wind.sort_values('publish_date')
 
   
    
    i_files = os.listdir(r'S:\TZ\China Data Hunt\CNINFO\etf_constituent_monthly')
    i_const = pd.concat(pd.read_parquet(os.path.join(r'S:\TZ\China Data Hunt\CNINFO\etf_constituent_monthly', f)) for f in i_files)
    i_const = i_const.sort_values(['SECCODE', 'F002V', 'F001D']).reset_index(drop = True)
    i_const = i_const[i_const['F002V'].str.contains('\d{6}')]
    i_const.columns = ['publish_date','seccode','secname','stock_shares_per_unit','cash_substitution','cash_premium','fixed_substitution','fund_seccode','fund_secname']
    i_const['publish_date'] = pd.to_datetime(i_const['publish_date'])
    c_sh = i_const['seccode'].str[0]=='6'
    c_sz = i_const['seccode'].str[0].isin(['0','3'])
    i_const.loc[c_sh, 'seccode'] = i_const.loc[c_sh, 'seccode'] + '.SH'
    i_const.loc[c_sz, 'seccode'] = i_const.loc[c_sz, 'seccode'] + '.SZ'
    
    i_const = i_const[['publish_date', 'seccode', 'stock_shares_per_unit', 'fund_seccode']]
    i_const = i_const.sort_values('publish_date')
    i_creation_u = i_creation_u.sort_values('publish_date')
    i_const = pd.merge_asof(i_const, i_creation_u, by = 'fund_seccode', on = 'publish_date')
    i_const = pd.merge_asof(i_const, i_etf_shr_wind, by = 'fund_seccode', on = 'publish_date', tolerance = pd.to_timedelta('7 days'))
    i_const = pd.merge(i_const, i_closure, on = ['fund_seccode'], how = 'left')
    i_const['days_2_closure'] = (i_const['closure_date'] - i_const['publish_date']).dt.days
    i_const = pd.merge(i_const, i_icpt, on = ['fund_seccode'], how = 'left')
    i_const['days_s_icpt'] = (i_const['publish_date'] - i_const['icpt_date']).dt.days
     
    i_const = i_const.sort_values(['fund_seccode', 'seccode','publish_date'])
    i_const = i_const.reset_index(drop = True)
    i_const['etf_unit'] = i_const['EQY_SH_OUT'].divide(i_const['etf_shares_per_unit'])
    i_const['etf_unit'] = i_const['etf_unit'].replace(np.inf,0).replace(-np.inf,0)
    i_const['etf_unit'] = i_const['etf_unit'].fillna(0)
    i_const['shares_held_conceptual'] = i_const['stock_shares_per_unit'].multiply(i_const['etf_unit'])
    i_const.loc[i_const['days_s_icpt']<0, 'shares_held_conceptual'] = 0
    i_const.loc[i_const['days_2_closure']<=0, 'shares_held_conceptual'] = 0
    
    i_const_grp = i_const.groupby(['publish_date','seccode'])['shares_held_conceptual'].sum().reset_index()
    i_const_grp = i_const_grp.sort_values(['seccode', 'publish_date'])
    i_const_grp = i_const_grp.rename(columns={'publish_date': 'datadate', 'seccode': '
ticker','shares_held_conceptual':'shares_by_etf'})

    i_const_grp.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_etf_holding.parquet')






###


    
### WIND industry
def get_wind_ind():
    # this output WIND industry level 1,2,3 per ticker per period
    # level 2 and 3 are nullable
    
    i_ind1 = get_sql('''select a.s_info_windcode as ticker, a.wind_ind_code, a.entry_dt, a.remove_dt, b.Industriesname as indname_1 
                     from [WIND].[dbo].ASHAREINDUSTRIESCLASS a, [WIND].[dbo].AShareIndustriesCode b
                     where substring(a.wind_ind_code, 1, 4) = substring(b.IndustriesCode, 1, 4)
                     and b.levelnum = '2' ''')
    
    i_ind2 = get_sql('''select a.s_info_windcode as ticker, a.wind_ind_code, a.entry_dt, a.remove_dt, b.Industriesname as indname_2 
                     from [WIND].[dbo].ASHAREINDUSTRIESCLASS a, [WIND].[dbo].AShareIndustriesCode b
                     where substring(a.wind_ind_code, 1, 6) = substring(b.IndustriesCode, 1, 6)
                     and b.levelnum = '3' ''')
    
    i_ind3 = get_sql('''select a.s_info_windcode as ticker, a.wind_ind_code, a.entry_dt, a.remove_dt, b.Industriesname as indname_3 
                     from [WIND].[dbo].ASHAREINDUSTRIESCLASS a, [WIND].[dbo].AShareIndustriesCode b
                     where substring(a.wind_ind_code, 1, 8) = substring(b.IndustriesCode, 1, 8)
                     and b.levelnum = '4' ''')
    
    o_ind = i_ind1.merge(i_ind2.drop(columns=['remove_dt']), on = ['ticker','wind_ind_code','entry_dt'], how = 'left')
    o_ind = o_ind.merge(i_ind3.drop(columns=['remove_dt']), on = ['ticker','wind_ind_code','entry_dt'], how = 'left')
    
    o_ind = o_ind[o_ind['entry_dt'].notnull()]
    
    return o_ind
    

### audit opinions (financials + internal control)

def get_wind_audit_opinion():
    # output datadate is discrete
    i_audit_opinion = get_sql('''select S_INFO_WINDCODE as ticker, ANN_DT as datadate,
                              REPORT_PERIOD as ped_1rq, S_STMNOTE_AUDIT_CATEGORY as audit_code,
                              S_PAY_AUDIT_EXPENSES as audit_expense, S_AUDIT_RESULT_MEMO
                              from [WIND].[dbo].[ASHAREAUDITOPINION]''')
    i_audit_opinion['datadate'] = pd.to_datetime(i_audit_opinion['datadate'], format='%Y%m%d')
    i_in_control_audit = get_sql('''select S_INFO_WINDCODE as ticker, ANN_DT1 as datadate,
                              REPORT_PERIOD as ped_1rq, S_IN_CONTROL_AUDIT_OPINION as audit_
code,
                              S_PAY_AUDIT_EXPENSES as audit_expense, S_IN_CONTROL_AUDIT 
                              from [WIND].[dbo].[ASHAREAUDITOPINION]''')
    i_in_control_audit['datadate'] = pd.to_datetime(i_in_control_audit['datadate'], format='%Y%m%d')
    i_in_control_audit = i_in_control_audit.dropna(subset=['datadate'])
    return i_audit_opinion, i_in_control_audit

### block
def get_wind_blocktrade():
    # output datadate is discrete
    
    
    i_block = get_sql('''select S_INFO_WINDCODE as ticker, TRADE_DT as datadate,
                      S_BLOCK_PRICE, S_BLOCK_VOLUME, S_BLOCK_AMOUNT, 
                      S_BLOCK_BUYERNAME, S_BLOCK_SELLERNAME, S_BLOCK_FREQUENCY 
                      from [WIND].[dbo].[ASHAREBLOCKTRADE]''')
    i_block['block_shares'] = i_block['S_BLOCK_VOLUME']*10000
    i_block['block_amt_rmb'] = i_block['S_BLOCK_AMOUNT']*10000
    i_block = i_block.drop(columns = ['S_BLOCK_VOLUME', 'S_BLOCK_AMOUNT'])
    return i_block






### investor meeting

def get_wind_investor_meeting():
    
    # get raw meeting data
    i_meeting = get_sql('''select S_INFO_WINDCODE as ticker, [EVENT_ID], [S_ACTIVITIESTYPE], 
                        [S_SURVEYDATE], [S_SURVEYTIME], [ANN_DT] as datadate, [S_SURVEYTYPECODE], 
                        [S_SURVEYINSTIS_TOT] from [WIND].[dbo].[ASHAREISACTIVITY] 
                        where len(S_SURVEYDATE)=8 ''')
    i_meeting = i_meeting[i_meeting['S_SURVEYDATE'].notnull()]
    i_meeting['datadate'] = pd.to_datetime(i_meeting['datadate'], format='%Y%m%d')
    
    # get avg PV  / MC
    i_pv_dv_mc = get_sql_prod("select ric as ticker, datadate, avgPVadj / mc_l1d / 10000 as pv_dv_mc FROM [SUMMITDBPROD].[dbo].[Static_Data_CN]")    
    
    # get holding data
    i_holding = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_holding_mffund_q.parquet')
    i_holding_corp = i_holding.groupby(['datadate', 'ticker', 'corp_windcode'])[['mean_mktcap_active_pct', 'mean_mktcap_pct', 'mktcap_active_pct', 'mktcap_pct']].sum().reset_index()

    # meeting participants
    i_participants = get_sql('''SELECT [EVENT_ID], [S_INSTITUTIONNAME], [S_INSTITUTIONCODE] as S_INFO_COMPCODE,
                             [S_INSTITUTIONTYPE], [S_ANALYSTNAME],[S_INSTITUTIONTYPECODE],[MANAGER_POST],[S_ANALYST_ID] 
                             FROM [WIND].[dbo].[ASHAREISPARTICIPANT]''')
    i_participants = i_participants[i_participants['S_INSTITUTIONTYPE'].notnull()]
    i_participants['S_INSTITUTIONTYPE'] = 
i_participants['S_INSTITUTIONTYPE'].astype(int)
    i_participants.loc[i_participants['S_ANALYSTNAME'].isnull(), 'S_ANALYSTNAME'] = 'unknown'
    
    i_part_cnt = i_participants.groupby(['EVENT_ID','S_INSTITUTIONTYPE'])['S_INFO_COMPCODE'].nunique().reset_index()
    i_part_cnt = i_part_cnt.rename(columns={'S_INFO_COMPCODE':'cnt'})
    i_part_cnt = pd.pivot_table(i_part_cnt, index='EVENT_ID', columns='S_INSTITUTIONTYPE', values = 'cnt')
    i_part_cnt = i_part_cnt.reset_index()
    
    
    # participants' most recent holding and holding in the future
    i_participants = i_participants.merge(i_meeting[['EVENT_ID','datadate','ticker']], on=['EVENT_ID'], how = 'left')
    i_participants = i_participants.rename(columns={'S_INFO_COMPCODE': 's_holder_compcode'})
    i_participants = i_participants[i_participants['datadate'].notnull()]
    
    i_participants = i_participants.sort_values(['datadate','s_holder_compcode'])
    i_holding_corp = i_holding_corp.rename(columns = {'corp_windcode':'s_holder_compcode'})
    i_holding_corp = i_holding_corp.sort_values(['datadate','s_holder_compcode'])
    i_participants_h = pd.merge_asof(i_participants, i_holding_corp, by = ['s_holder_compcode','ticker'], on = ['datadate'],
                                     tolerance = pd.Timedelta('100 days'))
    i_participants_h = pd.merge_asof(i_participants_h, i_holding_corp, by = ['s_holder_compcode','ticker'], on = ['datadate'],
                                     tolerance = pd.Timedelta('100 days'), direction='forward', suffixes=['','_fwdlk']) 
    for c in ['mean_mktcap_active_pct', 'mean_mktcap_pct', 'mktcap_active_pct', 'mktcap_pct']:
        i_participants_h[c] = i_participants_h[c].replace(np.nan, 0)
        
    i_participants_h['chg_pst_fwdlk'] = i_participants_h['mktcap_active_pct_fwdlk'] - i_participants_h['mktcap_active_pct']
        
    # participant's net asset
    i_netasset = get_sql('''select nav.f_info_windcode as fund_ticker, nav.ann_date as datadate, 
                     nav.f_prt_netasset as na, mf_desc.F_INFO_CORP_FUNDMANAGEMENTCOMP as corp_name, 
                     mf_desc.F_INFO_CORP_FUNDMANAGEMENTID as corp_windcode 
                     from [WIND].[dbo].ChinaMutualFundNAV as nav
                     left join wind.dbo.windcustomcode as code
                     on nav.f_info_windcode = code.S_INFO_WINDCODE
                     left join wind.dbo.CHINAMUTUALFUNDDESCRIPTION as mf_desc
                     on code.S_INFO_WINDCODE = mf_desc.f_info_w
indcode
                     where nav.f_prt_netasset is not null and nav.ann_date is not null
                     order by nav.f_info_windcode, nav.ann_date''')
    i_netasset['datadate'] = pd.to_datetime(i_netasset['datadate'],format='%Y%m%d')
    i_netasset = i_netasset.sort_values(['datadate','fund_ticker'])
    
    o_netasset = pd.DataFrame()
    for dt in pd.date_range(start = '2013-01-01', end = i_netasset['datadate'].max()):
        print(dt.strftime('%Y%m%d'),end=',')
        t_netasset = i_netasset[(i_netasset['datadate']<=dt)&(i_netasset['datadate']>=dt-pd.to_timedelta('180 days'))]
        t_netasset = t_netasset.drop_duplicates(subset=['fund_ticker'],keep='last')
        
        t_netasset_corp = t_netasset.groupby(['corp_windcode','corp_name'])['na'].sum().reset_index()
        t_netasset_corp['datadate'] = dt
        o_netasset = o_netasset.append(t_netasset_corp, sort = False)
    o_netasset['na_rk'] = o_netasset.groupby('datadate')['na'].apply(lambda x: x.rank()/len(x))
    o_netasset = o_netasset[['datadate','corp_windcode','na','na_rk']]
    o_netasset = o_netasset.rename(columns={'corp_windcode':'s_holder_compcode'})
    
    
    # aggregate mutual fund participant's holding to event
    i_mf = i_participants_h[i_participants_h['S_INSTITUTIONTYPE']==257001003]
    i_mf = i_mf.merge(o_netasset, on = ['datadate','s_holder_compcode'], how = 'left')
    i_mf = i_mf.merge(i_pv_dv_mc, on = ['ticker','datadate'], how = 'left')
    
    i_mf = i_mf.drop_duplicates(subset=['EVENT_ID','S_INSTITUTIONNAME'], keep = 'last')
    i_mf['hold_lt_mean'] = (i_mf['mktcap_pct']<i_mf['mean_mktcap_pct']) | (i_mf['mktcap_pct']==0)
    i_mf['active_hold_lt_mean'] = (i_mf['mktcap_active_pct']<i_mf['mean_mktcap_active_pct']) | (i_mf['mktcap_active_pct']==0)
    
    i_mf['chg_pst_fwdlk_dv_turnover'] = i_mf['chg_pst_fwdlk'].divide(i_mf['pv_dv_mc'])
    
    i_mf_stats_grp = i_mf.groupby(['EVENT_ID','ticker'])
    i_mf_stats = pd.concat([i_mf_stats_grp['S_INSTITUTIONNAME'].nunique(),
                            i_mf_stats_grp['mktcap_pct'].apply(lambda x: (x==0).sum()),
                            i_mf_stats_grp['mktcap_active_pct'].apply(lambda x: (x==0).sum()),
                            i_mf_stats_grp['hold_lt_mean'].sum(),
                            i_mf_stats_grp['active_hold_lt_mean'].sum(),
                            i_mf_stats_grp['na'].sum(),
                            i_mf_stats_grp['na_rk'].sum(),
                            i_mf_stats_grp['chg_p
st_fwdlk_dv_turnover'].sum()
                            ],axis=1)
    i_mf_stats = i_mf_stats.reset_index().rename(columns = {'S_INSTITUTIONNAME':'num_mf', 
                                                            'mktcap_pct':'mf_zero_h',
                                                            'mktcap_active_pct':'mf_zero_active_h',
                                                            'hold_lt_mean':'mf_lt_mean',
                                                            'active_hold_lt_mean':'mf_active_lt_mean'})
    
    # count no of mf + am per meeting
    i_am = i_participants_h[(i_participants_h['S_INSTITUTIONTYPE']==257001005)&(i_participants_h['S_INSTITUTIONNAME'].str.contains('资管|资产管理'))]
    i_am_stats = i_am.groupby(['EVENT_ID','ticker'])['S_INSTITUTIONNAME'].nunique().reset_index()
    i_am_stats = i_am_stats.rename(columns = {'S_INSTITUTIONNAME':'num_am'})
    

    # q&a details for investor meetings (cninfo sseinfo q&a will be processed separately)
    i_qa = get_sql("select EVENT_ID, S_INFO_WINDCODE as ticker, S_QUESTIONTYPE  FROM [WIND].[dbo].[ASHAREISQA]  where S_QUESTIONSOURCETYPE = '269001000' ")
    i_qa['unity'] = 1
    i_qa['S_QUESTIONTYPE'] = i_qa['S_QUESTIONTYPE'].astype(int).astype(str)
    i_qa['S_QUESTIONTYPE'] = i_qa['S_QUESTIONTYPE'].replace('259001000', 'operation').replace('259002000', 'industry').\
                             replace('259003000', 'finance').replace('259004000', 'ma').replace('259005000', 'hr').\
                             replace('259006000', 'management').replace('259007000', 'equity').\
                             replace('259008000', 'major event').replace('259009000', 'other' )
    i_qa = i_qa.pivot_table(index = ['EVENT_ID', 'ticker'], columns = 'S_QUESTIONTYPE', values = 'unity')
    i_qa = i_qa.reset_index()
    
    # output
    o_investor_meeting = i_meeting.merge(i_part_cnt, on = ['EVENT_ID'], how = 'left')
    o_investor_meeting = o_investor_meeting.merge(i_qa, on = ['EVENT_ID','ticker'], how = 'left')
    o_investor_meeting = o_investor_meeting.merge(i_mf_stats, on = ['EVENT_ID','ticker'], how = 'left')
    o_investor_meeting = o_investor_meeting.merge(i_am_stats, on = ['EVENT_ID','ticker'], how = 'left')
    o_investor_meeting = o_investor_meeting[['ticker','datadate','EVENT_ID','S_ACTIVITIESTYPE',
                                             'S_SURVEYDATE', 'S_SURVEYTIME', 
                                             'S_SURVEYTYPECODE', 'S_SURVEYINSTIS_TOT',
             
                                257001001, 257001002, 257001003, 257001004,
                                             257001005, 257001006, 257001007, 257002001,
                                             'equity', 'finance', 'hr', 'industry', 'ma',
                                             'major event', 'management', 'operation', 'other',
                                             'num_mf', 'mf_zero_h', 'mf_zero_active_h','mf_lt_mean', 'mf_active_lt_mean',
                                             'na', 'na_rk','chg_pst_fwdlk_dv_turnover', 'num_am']]
    o_investor_meeting['datadate'] = pd.to_datetime(o_investor_meeting['datadate'], format='%Y%m%d')
    
    return o_investor_meeting


def get_wind_online_qa(): 
    # output is tdate discrete, 1 row for 1 online qa
    # note that answer date might be null (i.e. unanswered questions)
    
    
    i_qa = get_sql('''select s_info_windcode as ticker, 
                   s_askdate, s_questiontype, s_questioncontent, 
                   s_answercontent, s_answerdate 
                   from [WIND].[dbo].[ASHAREISQA] 
                    where (ORIGINALWEBSITE like '%sseinfo.com%' or 
                           ORIGINALWEBSITE like '%cninfo.com.cn%' or 
                           ORIGINALWEBSITE like '%p5w.net%') 
                    and EVENT_ID is null''')
                    
    return i_qa
                    
    
                    
                        
                    

### news

def get_wind_news():
    # returns news + sentiment scores from news devoted to 1 ticker
    # datadate discrete 
    
    
    # select news ID that is associated with 1 ticker only
    i_news     = get_sql('''with 
                         news_with_id as (select [OBJECT_ID], CODE from [WIND].[dbo].[FINANCIALNEWS_C] 
                                         where field = 'WINDCODES' and ((CODE like '%.SZ') or (CODE like '%.SH')) ),
                         news_with_1id as (select object_id from news_with_id group by object_id having count(CODE)=1 )
                         select l.object_id, l.publishdate as datadate, l.title, l.content, l.windcodes, l.mktsentiments, 
                         l.newslevels, l.sectercodes 
                         from [WIND].[dbo].[FINANCIALNEWS] l 
                         inner join news_with_1id r 
                         on l.OBJECT_ID=r.OBJECT_ID 
                         where l.windcodes is not null                         ''')
                         
    # 
extract ticker
    i_news['ticker'] = i_news['windcodes'].str.extract('(\d{6}.S[HZ])')
    i_news = i_news[i_news['ticker'].notnull()]
    
    # replace "null:" sentiment / sector with nan
    i_news['mktsentiments'] = i_news['mktsentiments'].replace('null:',np.nan)
    i_news.loc[i_news['mktsentiments'].isnull(),'mktsentiments'] = np.nan    
    i_news['sectercodes'] = i_news['sectercodes'].replace('null:',np.nan)
    i_news.loc[i_news['sectercodes'].isnull(),'sectercodes'] = np.nan
    
    # process sentiment: only pick up sentiment regarding the target stock, then count positive and negative 
    def process_sentiment(x):
        # step 1: if there is no sentiment
        if pd.isnull(x['mktsentiments']):
            return np.nan
        # step 2: if there is sentiment directly for a ticker
        x_list = x['mktsentiments'].split('|')
        for item in x_list:
            if x['ticker'] in item:
                if '负' in item:
                    return -1
                if '正' in item:
                    return 1
        # step 3:
        return x['mktsentiments'].count('正')-x['mktsentiments'].count('负')
    i_news['sentiment_score'] = i_news[['mktsentiments','ticker']].apply(lambda x: process_sentiment(x), axis = 1)
        
    return i_news



def get_wind_news_v2():
    # returns news + sentiment scores from news devoted to multiple tickers
    # datadate discrete 
    
    
    # select news ID that is associated with 1 ticker only
    i_news = get_sql('''with 
                         news_with_id as (select OBJECT_ID, CODE as ticker from [WIND].[dbo].[FINANCIALNEWS_C] 
                                         where field = 'WINDCODES' 
                                         and ((CODE like '%.SZ') or (CODE like '%.SH')) 
                                         and ((CODE like '0%') or (CODE like '3%') or (CODE like '6%')) ) 
                         select l.object_id, l.publishdate as publishts, l.title, l.mktsentiments, r.ticker
                         from [WIND].[dbo].[FINANCIALNEWS]  l
                         inner join news_with_id  r
                         on l.OBJECT_ID = r.object_id ''')
                         
    # calculate number of tickers sharing 1 news ID    
    i_obj_tkcnt = i_news.groupby('object_id')['ticker'].nunique().reset_index()
    i_obj_tkcnt.columns = ['object_id','tk_cnt']
    i_news = i_news.merge(i_obj_tkcnt, on = 'object_id', how = 'left')
    
    
    # replace "null:" sentiment / sector with n
an
    i_news['mktsentiments'] = i_news['mktsentiments'].replace('null:',np.nan)
    i_news.loc[i_news['mktsentiments'].isnull(),'mktsentiments'] = np.nan    
    
    
    # process sentiment: only pick up sentiment regarding the target stock, then count positive and negative 
    def process_sentiment(x):
        # step 1: if there is no sentiment
        if pd.isnull(x['mktsentiments']):
            return np.nan
        # step 2: if there is sentiment directly for a ticker
        x_list = x['mktsentiments'].split('|')
        for item in x_list:
            if x['ticker'] in item:
                if '负' in item:
                    return -1
                if '正' in item:
                    return 1
        # step 3:
        return x['mktsentiments'].count('正')-x['mktsentiments'].count('负')
    i_news['sentiment_score'] = i_news[['mktsentiments','ticker']].apply(lambda x: process_sentiment(x), axis = 1)
        
    return i_news


### risk news

def get_wind_risk_news():
    # returns news + sentiment scores from news devoted to 1 ticker
    # datadate discrete 
    
    i_risk = get_sql('''select object_id, publishdate as datadate, title, mktsentiments, windcodes
                     FROM [WIND].[dbo].[WINDRISKINFORMATION] where windcodes is not null''')
    
    # extract ticker
    i_risk['windcodes_cnt'] = i_risk['windcodes'].apply(lambda x: len(re.findall('\d{6}.S[HZ]', x)))
    i_risk = i_risk[i_risk['windcodes_cnt']==1]
    i_risk['ticker'] = i_risk['windcodes'].str.extract('(\d{6}.S[HZ])')
    
    return i_risk

### wei gui

def get_sec_investigation():
    
    # the output is cdate continuous
    # it gives the number of days since last investigation, nan = 999999 by default
    
    # calendar
    i_cal = get_wind_cdate_cal()
    
    # sec investigation
    i_sec_investigation = get_sql('''select s_info_windcode as ticker, sur_institute, 
                                      sur_reasons, str_anndate as datadate
                                      from wind.dbo.[AShareRegInv] 
                                      where str_anndate is not null''')
    i_sec_investigation['datadate'] = pd.to_datetime(i_sec_investigation['datadate'], format= '%Y%m%d')
    i_sec_investigation = i_sec_investigation.drop_duplicates(subset=['ticker','datadate'],keep = 'last')
    i_sec_investigation['sec_investigation_date'] = i_sec_investigation['datadate']
    i_sec_investigation['sec_investigation_flag'] = 1
    i_sec_investigation = i_sec_investigation
[['ticker','datadate','sec_investigation_date','sec_investigation_flag']]
    
    #merge
    o_1 = i_cal.merge(i_sec_investigation, on = ['ticker', 'datadate'], how = 'left')
    
    o_1 = o_1.sort_values(['ticker', 'datadate'])
    o_1['sec_investigation_date'] = o_1.groupby('ticker')['sec_investigation_date'].ffill()
    o_1['sec_days_since_investigation'] = (o_1['datadate'] - o_1['sec_investigation_date']).dt.days
    o_1['sec_days_since_investigation'] = o_1['sec_days_since_investigation'].fillna(999999)
    
    return o_1[['ticker','datadate','sec_days_since_investigation']]




### analyst rating
    
def get_wind_rating_sum(lookback_period= 30):
    # the output of this is tdate continuous
    # avg_rating: 1分代表买入，2分代表增持，3分代表中性，4分代表减持，5分代表卖出 
    # S_WRATING_CYCLE means the lookback period - 263001000:过去30天 263002000:90天 263003000:180天
    
    dict_lookback_map ={30: '263001000', 60: '263002000', 90: '263003000'}
    
    i_date_map = get_wind_trade_cal_byticker()
    
    i_rate_sum = get_sql('''select [S_INFO_WINDCODE] as ticker, [RATING_DT] as datadate, S_WRATING_CYCLE,
                         S_WRATING_AVG as avg_rating, S_WRATING_INSTNUM as inst_cnt, 
                         [S_WRATING_UPGRADE] as up_cnt, [S_WRATING_DOWNGRADE] as down_cnt, [S_WRATING_MAINTAIN] as same_cnt, 
                         [S_WRATING_NUMOFBUY] as buy_cnt, [S_WRATING_NUMOFOUTPERFORM] as ow_cnt, [S_WRATING_NUMOFHOLD] as hold_cnt, 
                         [S_WRATING_NUMOFUNDERPERFORM] as uw_cnt, [S_WRATING_NUMOFSELL] as sell_cnt 
                         FROM [WIND].[dbo].[ASHARESTOCKRATINGCONSUS] where [S_WRATING_CYCLE] = '{0}'
                         '''.format(dict_lookback_map[lookback_period]))
    i_rate_sum['datadate'] = pd.to_datetime(i_rate_sum['datadate'], format='%Y%m%d')
    
    i_rate_sum_fulldate = i_date_map.merge(i_rate_sum, on = ['ticker','datadate'], how = 'left')
    i_rate_sum_fulldate = i_rate_sum_fulldate.sort_values(['ticker','datadate'])
    i_rate_sum_fulldate = i_rate_sum_fulldate.groupby('ticker').ffill()
    
    return i_rate_sum_fulldate

### target price
    
def get_wind_tp_sum(lookback_period = 30):
    # the output of this is tdate continuous
    # S_WRATING_CYCLE means the lookback period 
    
    dict_lookback_map ={30: '263001000', 60: '263002000', 90: '263003000'}
    
    # get ticket-date map
    i_date_map = get_wind_trade_cal_byticker()
    
    # get close price (unadj)
    i_close = get_sql('''select [S_INFO_WINDCODE] 
as ticker, [TRADE_DT] as datadate, S_DQ_CLOSE as c  
                      from [WIND].[dbo].[ASHAREEODPRICES]''')
    i_close['datadate'] = pd.to_datetime(i_close['datadate'], format= '%Y%m%d')
    
    # get target price
    i_tp_sum = get_sql('''select [S_INFO_WINDCODE] as ticker, [RATING_DT] as datadate, S_WRATING_CYCLE,
                         S_EST_PRICE as tp, S_EST_PRICEINSTNUM as tp_inst_cnt     
                         FROM [WIND].[dbo].[ASHARESTOCKRATINGCONSUS] where [S_WRATING_CYCLE] = '{0}'
                         '''.format(dict_lookback_map[lookback_period]))
    i_tp_sum['datadate'] = pd.to_datetime(i_tp_sum['datadate'], format='%Y%m%d')
    
    # merge all data sources 
    i_tp_sum_fulldate = i_date_map.merge(i_tp_sum, on = ['ticker','datadate'], how = 'left')
    i_tp_sum_fulldate = i_tp_sum_fulldate.sort_values(['ticker','datadate'])
    i_tp_sum_fulldate = i_tp_sum_fulldate.groupby('ticker').ffill()
    i_tp_sum_fulldate = i_tp_sum_fulldate.merge(i_close, on = ['datadate','ticker'], how = 'left')
    
    # calculate tp / close 
    i_tp_sum_fulldate['tp_dv_c'] = i_tp_sum_fulldate['tp'].divide(i_tp_sum_fulldate['c'])
    
    return i_tp_sum_fulldate
    


    
### analyst estimate

# s_est_yeartype: 
def get_wind_earning_est_sum(METRIC,lookback_period = 30): 
    # output is tdate continuous
    # this only outputs annual (FY) EPS forecasts 
    
    dict_lookback_map = {30:'263001000',90:'263002000',180:'263003000',18000:'263004000'}
    
    # get all columns
    i_est_cols = get_sql('''select top 1 * from [WIND].[dbo].[ASHARECONSENSUSDATA] ''')
    i_est_cols = i_est_cols.drop(columns = ['OBJECT_ID', 'OPDATE', 'OPMODE',
                                            'S_INFO_WINDCODE', 'WIND_CODE', 
                                            'EST_DT', 'EST_REPORT_DT', 'NUM_EST_INST',
                                            'CONSEN_DATA_CYCLE_TYP','S_EST_YEARTYPE','S_EST_BASESHARE'])
    i_est_cols = i_est_cols.columns.tolist()
    
    # generate sql codes
    if METRIC == 'EBIT':
        o_est_cols = [i for i in i_est_cols if (METRIC in i) & ('EBITDA' not in i)]
    else:
        o_est_cols = [i for i in i_est_cols if (METRIC in i)]
    o_est_cols = ','.join(o_est_cols)
    
    # query sql    
    i_est = get_sql('''SELECT S_INFO_WINDCODE as ticker,EST_DT as datadate,EST_REPORT_DT,NUM_EST_INST as inst_cnt, 
                    S_EST_YEARTYPE, {1} 
                    from [WIND].[dbo].[ASHARECONSENSUSDATA] 
                
    where CONSEN_DATA_CYCLE_TYP = '{0}' and s_est_yeartype != 'FY0' 
                    '''.format(dict_lookback_map[lookback_period], o_est_cols))
    i_est['EST_REPORT_DT'] = pd.to_numeric(i_est['EST_REPORT_DT'])
    
    # pivot table: make metric columns for FY1,2,3
    i_est_melt = pd.melt(i_est,
                         id_vars = ['ticker', 'datadate', 'S_EST_YEARTYPE'],
                         value_vars = [i for i in i_est.columns.tolist() if i not in ['ticker', 'datadate', 'S_EST_YEARTYPE', 'S_EST_BASESHARE']],
                         value_name = 'values',
                         var_name = 'metrics' )
    i_est_melt['metrics'] = i_est_melt['metrics'] + '_' + i_est_melt['S_EST_YEARTYPE']
    i_est_melt = i_est_melt.drop(columns=['S_EST_YEARTYPE'])
    i_est_melt = i_est_melt.drop_duplicates(subset = ['ticker','datadate','metrics'], keep = 'first')
    i_est_pv = i_est_melt.pivot_table(values='values', index=['ticker','datadate'], columns='metrics')
    i_est_pv = i_est_pv.reset_index()
    i_est_pv['EST_REPORT_DT_FY1'] = pd.to_datetime(i_est_pv['EST_REPORT_DT_FY1'].astype('Int64').astype(str),format='%Y%m%d')
    i_est_pv['EST_REPORT_DT_FY2'] = pd.to_datetime(i_est_pv['EST_REPORT_DT_FY2'].astype('Int64').astype(str),format='%Y%m%d')
    i_est_pv['EST_REPORT_DT_FY3'] = pd.to_datetime(i_est_pv['EST_REPORT_DT_FY3'].astype('Int64').astype(str),format='%Y%m%d')
    
    
    # get complete ticker-date map
    i_date_map = get_wind_trade_cal_byticker()
    i_date_map = i_date_map.sort_values(['ticker','datadate'])
    
    # merge ticker_date map and earning est data
    i_est_pv['datadate'] = pd.to_datetime(i_est_pv['datadate'], format = '%Y%m%d')
    i_est_pv['record_id'] = list(range(len(i_est_pv)))
    o_est = i_date_map.merge(i_est_pv, on = ['ticker', 'datadate'], how = 'left')
    o_est['record_id'] = o_est['record_id'].fillna(method='ffill')
    
    # ffill
    o_est = o_est.groupby(['ticker','record_id']).ffill()
    
    
    return o_est


### financials - actual

def get_wind_actuals(METRIC):
    # this outputs the most recent actual figure
    #
    
    # example: METRIC in ['S_FA_ROA2']
    
    i_act = get_sql('''select ann_dt as datadate, s_info_windcode as ticker, report_period, {0} 
                       from [WIND].[dbo].[ASHAREFINANCIALINDICATOR]
                    '''.format(METRIC))
    i_act = i_act[i_act['datadate'].notnull()]
    i_act['datadate'] = pd.to_datetime(i_act['datadate'], format = '%Y%m%d')
    
    # get date
 ticker map
    i_map = get_wind_trade_cal_byticker()
    
    # merge data
    o_act = i_map[['ticker', 'datadate']].merge(i_act, on = ['ticker', 'datadate'], how = 'left')
    o_act = o_act.sort_values(['ticker', 'datadate'])
    o_act[METRIC] = o_act.groupby('ticker')[METRIC].ffill()
    o_act['report_period'] = o_act.groupby('ticker')['report_period'].ffill()
    
    return o_act

### financials - TTM
def get_ttm_metrics(METRIC):
    
    # this output ttm metrics 
    # the output is cdate continuous
    
    # 总资产净利率： s_fa_roa_ttm
    
    i_ttm = get_sql('''select s_info_windcode as ticker, 
                    ann_dt as datadate, cast(report_period as int) as report_period, 
                    cast(report_period as int)-10000 as report_period_1y,  
                    statement_type, {0} from wind.dbo. AShareTTMHis 
                    where ann_dt is not null '''.format(METRIC))
    
    i_ttm['datadate'] = pd.to_datetime(i_ttm['datadate'], format='%Y%m%d')
    i_ttm = i_ttm.sort_values(['ticker','datadate', 'report_period'])
    i_ttm_mr = i_ttm.drop_duplicates(subset = ['ticker','datadate'], keep = 'last')
    i_ttm_mr = i_ttm_mr.sort_values('datadate')
    i_ttm = i_ttm.sort_values('datadate')    
    
    i_ttm2 = pd.merge_asof(i_ttm_mr, i_ttm[['ticker','report_period','statement_type','s_fa_roa_ttm','datadate']],
                          left_by = ['ticker', 'report_period_1y', 'statement_type'], 
                          right_by = ['ticker', 'report_period', 'statement_type'],
                          on = ['datadate'], suffixes = ['', '_l1y'])
    i_ttm2 = i_ttm2.drop(columns = ['report_period_l1y'])
    i_ttm2 = i_ttm2.rename(columns={'s_fa_roa_ttm_l1y':'s_fa_roa_ttm_1y'})
    i_ttm2['report_period'] = pd.to_datetime(i_ttm2['report_period'].astype(str), format='%Y%m%d')
    i_ttm2['report_period_1y'] = pd.to_datetime(i_ttm2['report_period_1y'].astype(str), format='%Y%m%d')
    i_ttm2 = i_ttm2.sort_values('datadate')
    
    i_cal = get_wind_cdate_cal()
    i_cal = i_cal.sort_values('datadate')
    
    o_ttm = pd.merge_asof(i_cal, i_ttm2, by = ['ticker'], on = 'datadate')
    
    return o_ttm





### Mkt Data: TWAP

def prepare_twap_fullday():
    # output is tdate continuous
    # the price here is raw price from TRTHv2
    
    i_fullday_twap = get_sql('''
                    (select datadate, ticker, AVG(PV/Volume) as twap, AVG(case when time<=1129 then PV/Volume end) as twap_am, AVG(case when time>=1300 then PV/Volume end) as 
twap_pm, AVG(case when time<=1430 then PV/Volume end) as twap_xC, AVG(case when time>=1000 then PV/Volume end) as twap_xO, AVG(case when time between 1000 and 1430 then PV/Volume end) as twap_xOC  FROM [CNDBPROD].[dbo].[TRTH_CN_TRADE_13] where hour*100+min>=930 and hour*100+min<=1500 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as twap, AVG(case when time<=1129 then PV/Volume end) as twap_am, AVG(case when time>=1300 then PV/Volume end) as twap_pm, AVG(case when time<=1430 then PV/Volume end) as twap_xC, AVG(case when time>=1000 then PV/Volume end) as twap_xO, AVG(case when time between 1000 and 1430 then PV/Volume end) as twap_xOC  FROM [CNDBPROD].[dbo].[TRTH_CN_TRADE_14] where hour*100+min>=930 and hour*100+min<=1500 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as twap, AVG(case when time<=1129 then PV/Volume end) as twap_am, AVG(case when time>=1300 then PV/Volume end) as twap_pm, AVG(case when time<=1430 then PV/Volume end) as twap_xC, AVG(case when time>=1000 then PV/Volume end) as twap_xO, AVG(case when time between 1000 and 1430 then PV/Volume end) as twap_xOC  FROM [CNDBPROD].[dbo].[TRTH_CN_TRADE_15] where hour*100+min>=930 and hour*100+min<=1500 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as twap, AVG(case when time<=1129 then PV/Volume end) as twap_am, AVG(case when time>=1300 then PV/Volume end) as twap_pm, AVG(case when time<=1430 then PV/Volume end) as twap_xC, AVG(case when time>=1000 then PV/Volume end) as twap_xO, AVG(case when time between 1000 and 1430 then PV/Volume end) as twap_xOC  FROM [CNDBPROD].[dbo].[TRTH_CN_TRADE_16] where hour*100+min>=930 and hour*100+min<=1500 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as twap, AVG(case when time<=1129 then PV/Volume end) as twap_am, AVG(case when time>=1300 then PV/Volume end) as twap_pm, AVG(case when time<=1430 then PV/Volume end) as twap_xC, AVG(case when time>=1000 then PV/Volume end) as twap_xO, AVG(case when time between 1000 and 1430 then PV/Volume end) as twap_xOC  FROM [CNDBPROD].[dbo].[TRTH_CN_TRADE_17] where hour*100+min>=930 and hour*100+min<=1500 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ti
cker, AVG(PV/Volume) as twap, AVG(case when time<=1129 then PV/Volume end) as twap_am, AVG(case when time>=1300 then PV/Volume end) as twap_pm, AVG(case when time<=1430 then PV/Volume end) as twap_xC, AVG(case when time>=1000 then PV/Volume end) as twap_xO, AVG(case when time between 1000 and 1430 then PV/Volume end) as twap_xOC  FROM [CNDBPROD].[dbo].[TRTH_CN_TRADE_18] where hour*100+min>=930 and hour*100+min<=1500 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as twap, AVG(case when time<=1129 then PV/Volume end) as twap_am, AVG(case when time>=1300 then PV/Volume end) as twap_pm, AVG(case when time<=1430 then PV/Volume end) as twap_xC, AVG(case when time>=1000 then PV/Volume end) as twap_xO, AVG(case when time between 1000 and 1430 then PV/Volume end) as twap_xOC  FROM [CNDBPROD].[dbo].[TRTH_CN_TRADE_19] where hour*100+min>=930 and hour*100+min<=1500 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as twap, AVG(case when time<=1129 then PV/Volume end) as twap_am, AVG(case when time>=1300 then PV/Volume end) as twap_pm, AVG(case when time<=1430 then PV/Volume end) as twap_xC, AVG(case when time>=1000 then PV/Volume end) as twap_xO, AVG(case when time between 1000 and 1430 then PV/Volume end) as twap_xOC  FROM [CNDBPROD].[dbo].[TRTH_CN_TRADE_20] where hour*100+min>=930 and hour*100+min<=1500 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as twap, AVG(case when time<=1129 then PV/Volume end) as twap_am, AVG(case when time>=1300 then PV/Volume end) as twap_pm, AVG(case when time<=1430 then PV/Volume end) as twap_xC, AVG(case when time>=1000 then PV/Volume end) as twap_xO, AVG(case when time between 1000 and 1430 then PV/Volume end) as twap_xOC  FROM [CNDBPROD].[dbo].[TRTH_CN_TRADE_21] where hour*100+min>=930 and hour*100+min<=1500 and volume!=0 group by datadate, ticker)
                    ''')
    i_fullday_twap = i_fullday_twap.sort_values(['ticker', 'datadate'])
    
    i_fullday_twap.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_twap_fullday.parquet')


def get_twap_fullday():
    
    return pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_twap_fullday.parquet')

    

def prepare_twap_1st_hr():
    # output is tdate continuous
    # the price here is raw price from TRTHv2
    
    i_1st_hr_twap = ge
t_sql_prod('''
                    (select datadate, ticker, AVG(PV/Volume) as px_1st_hr FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_13] where hour*100+min>=930 and hour*100+min<=1030 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_1st_hr FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_14] where hour*100+min>=930 and hour*100+min<=1030 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_1st_hr FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_15] where hour*100+min>=930 and hour*100+min<=1030 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_1st_hr FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_16] where hour*100+min>=930 and hour*100+min<=1030 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_1st_hr FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_17] where hour*100+min>=930 and hour*100+min<=1030 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_1st_hr FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_18] where hour*100+min>=930 and hour*100+min<=1030 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_1st_hr FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_19] where hour*100+min>=930 and hour*100+min<=1030 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_1st_hr FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_20] where hour*100+min>=930 and hour*100+min<=1030 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_1st_hr FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_21] where hour*100+min>=930 and hour*100+min<=1030 and volume!=0 group by datadate, ticker)
                    ''')
    i_1st_hr_twap = i_1st_hr_twap.sort_values(['ticker', 'datadate'])
    
    i_1st_hr_twap.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_twap_1st_hr.parquet')

def get_twap_1st_hr():
    
    return pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_twap_1st_hr.parquet')

def prepare_twap_am():
    # output is tdate continuous
    # the price here is raw price from TRTHv2

    
    i_am_twap = get_sql_prod('''
                    (select datadate, ticker, AVG(PV/Volume) as px_am FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_13] where hour*100+min>=930 and hour*100+min<=1130 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_am FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_14] where hour*100+min>=930 and hour*100+min<=1130 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_am FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_15] where hour*100+min>=930 and hour*100+min<=1130 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_am FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_16] where hour*100+min>=930 and hour*100+min<=1130 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_am FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_17] where hour*100+min>=930 and hour*100+min<=1130 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_am FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_18] where hour*100+min>=930 and hour*100+min<=1130 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_am FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_19] where hour*100+min>=930 and hour*100+min<=1130 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_am FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_20] where hour*100+min>=930 and hour*100+min<=1130 and volume!=0 group by datadate, ticker)
                    union
                    (select datadate, ticker, AVG(PV/Volume) as px_am FROM [SUMMITDBPROD].[dbo].[TRTH_CN_TRADE_21] where hour*100+min>=930 and hour*100+min<=1130 and volume!=0 group by datadate, ticker)
                    ''')
    i_am_twap = i_am_twap.sort_values(['ticker', 'datadate'])
    
    i_am_twap.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_twap_am.parquet')
    

def get_twap_am():
    
    return pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_twap_am.parquet')



def prepare_st_ugdg_per_tkdate(): # UNDER CONSTRUCTION
    # output ugdg descriptors per cdate, ticker
    
    
    # param
    
# 
   TRAILING_WINDOW = '91 days'
        
    # get suntime data (augmented data)
    
    i_rpt_aug = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_st_ugdg_per_report.parquet')
    i_rpt_aug = i_rpt_aug.sort_values(['organ_id','author_1st','ticker','report_period','report_id','datadate','entrytime'])
    
    
    # get earning calendar
    # 'ticker', 'datadate', 
    # 'ped_l1q', 'ed_l1q', 'ped_l2q', 'ped_l3q', 'ped_l4q', 'ed_l4q', 'ped_l5q', 'ped_n1q', 'ed_n1q', 
    # 'ed_n1q_chgd', 'ed_n1q_is_est', 'ed_n1q_prev', 'tag_frcst_exp', 'bd2e', 'cd2e', 'cdae', 'bdae'
    i_ed = get_wind_ed_calendar_pit()        
    i_ed['report_period_n1q'] = i_ed['ped_n1q'].dt.year*10 + i_ed['ped_n1q'].dt.month.apply(lambda x: np.ceil (x/3))
    i_ed['report_period_n1y'] = i_ed['ped_n1q'].dt.year*10 + 4
    i_ed['report_period_n2y'] = i_ed['ped_n1q'].dt.year*10 + 14
    
    i_ed = i_ed[['ticker','datadate','report_period_n1q','report_period_n1y','report_period_n2y']]
    
    
    # loop over cdate
#    o_ugdg_sum = []
    
#    for dt in pd.date_range(start = '2016-01-01', end = '2021-11-15').tolist():
#        print(dt.strftime('%Y%m%d'), end = ' ')
#        
#        t_ed = i_ed[i_ed['datadate']==dt]
#        t_ed_n1q = t_ed[['ticker','report_period_n1q']].rename(columns = {'report_period_n1q':'report_period'})
#        t_ed_n1y = t_ed[['ticker','report_period_n1y']].rename(columns = {'report_period_n1y':'report_period'})
#        t_ed_n2y = t_ed[['ticker','report_period_n2y']].rename(columns = {'report_period_n2y':'report_period'})
#        
#        t_rpt = i_rpt_aug[(i_rpt_aug['datadate']<=dt)&(i_rpt_aug['create_date']>=dt-pd.to_timedelta(TRAILING_WINDOW))]
#        
#        # or ugdg
#        
#        t_ed
#        
#        # np ugdg
#        
#        # eps ugdg
#        
#        # ggrate ugdg
#        
#        # tp ugdg
#        t_rpt_tp = t_rpt[t_rpt['tp'].notnull() & t_rpt['tp_prev'].notnull() & (t_rpt['tp']!=t_rpt['tp_prev'])]
#        t_rpt_tp_n1q
#        t_rpt_tp_n1y
#        t_rpt_tp_n2y
#        
#        
#        # tp ret ugdg
#        
#        # combine and output
#        
#        o_ugdg_sum.append(t_sum)
    
    

def get_st_ugdg_per_tkdate():
    pass


###  Raw 5min-AVG(Price) as of 11:30 am, 2 pm
def get_price_asof_hhmm(int_hh_mm):
    # int_hh_mm example: 1400, 1130
    
    int_hh_mm_end = str(int(int_hh_mm))
    int_hh_mm_start = str(int(int_hh_mm-5)) if (int_hh_mm-5)%100<=55 else str(int(int_hh_mm-45))
    
    o_pric
e = pd.DataFrame()
    for yr in ['13','14','15','16','17','18','19','20','21']:
        t_price_asof = get_sql_prod('''
                       with nbbo_all as
                       (select ticker, datadate, hour*100+min as ts, bid, ask 
                        from TRTH_CN_NBBO_{0}  
                        where ((bid is not null and bid > 0) or (ask is not null and ask > 0)) 
                        and hour*100+min<={1} and hour*100+min>={2}),
                       nbbo_most_recent_ts as
                       (select ticker,datadate,max(ts) as ts from nbbo_all group by ticker, datadate),
                       nbbo_output as
                       (select alldata.ticker, alldata.datadate, alldata.bid, alldata.ask 
                        from nbbo_most_recent_ts as recent 
                        inner join nbbo_all as alldata on recent.ticker = alldata.ticker 
                        and recent.datadate = alldata.datadate and recent.ts = alldata.ts),
                       trade as
                       (select ticker as trd_ticker, datadate as trd_datadate, AVG(PV/Volume) as price 
                        from TRTH_CN_TRADE_{0} where hour*100+min<={1} and hour*100+min>={2} group by ticker, datadate),
                       trade_nbbo as
                       (select * from nbbo_output as n full outer join 
                        trade as t on n.datadate=t.trd_datadate and n.ticker = t.trd_ticker)
                       select ticker, datadate, 
                       case when (price is null) and (bid is not null and bid != 0) and (ask is not null and ask!=0) then (bid+ask)/2
                       when (price is null) and (bid is not null and bid!=0) and (ask is null or ask = 0) then bid 
                       when (price is null) and (bid is null or bid = 0) and (ask is not null and ask!= 0) then ask
                       else price end as px from trade_nbbo 
                       '''.format(yr, int_hh_mm_end, int_hh_mm_start))
        o_price = o_price.append(t_price_asof, ignore_index = True)
    
    return o_price
        


### return

def prepare_wind_mkt_data():
    
    # output is tdate continuous
    # this returns all a share tickers, with hk connect flagged 
    # HK connect flag: ==1 / !=1
    
    # there is a problem here : if a ticker is suspended, o=h=l=c 
    
    ### get HK connect ticker universe
    i_tk_uni = get_sql('''(select S_INFO_WINDCODE as ticker, entry_dt, remove_dt from [WIND].[dbo].[SZSCMEMBERS]) 
         
              UNION
                       (select S_INFO_WINDCODE as ticker, entry_dt, remove_dt from [WIND].[dbo].[SHSCMEMBERS]) ''')
    i_tk_uni['entry_dt'] = pd.to_datetime(i_tk_uni['entry_dt'], format='%Y%m%d')
    i_tk_uni.loc[i_tk_uni['remove_dt'].isnull(), 'remove_dt'] = np.nan
    i_tk_uni['remove_dt'] = pd.to_datetime(i_tk_uni['remove_dt'], format='%Y%m%d')    
    
    ### get individual stock adj ret
    i_eod = get_sql('''select trade_dt as datadate,
                 S_INFO_WINDCODE as ticker, cast(substring(S_INFO_WINDCODE,1,6) as int) as ticker_int, 
                 S_DQ_CLOSE / S_DQ_PRECLOSE - 1 as adjret, S_DQ_VOLUME as v, S_DQ_AMOUNT as amt, 
                 S_DQ_OPEN as o, S_DQ_HIGH as h, S_DQ_LOW as l, 
                 S_DQ_CLOSE as c, S_DQ_PRECLOSE as pre_c, S_DQ_TRADESTATUS, 
                 S_DQ_TRADESTATUSCODE, S_DQ_LIMIT as limit_up, S_DQ_STOPPING as limit_down,
                 S_DQ_ADJOPEN as o_adj, S_DQ_ADJHIGH as h_adj, S_DQ_ADJLOW as l_adj, S_DQ_ADJCLOSE as c_adj,
                 S_DQ_ADJPRECLOSE as pre_c_adj 
                 from [WIND].[dbo].[ASHAREEODPRICES]''') # 2 min
    i_eod['datadate'] = pd.to_datetime(i_eod['datadate'], format='%Y%m%d')
    
    ### get am twap, then calculate adjret_o_c
    i_px_1sthr = get_twap_1st_hr()
    i_eod = i_eod.merge(i_px_1sthr, on = ['ticker', 'datadate'], how = 'left')
    i_eod.loc[i_eod['px_1st_hr'].isnull(),'px_1st_hr'] = i_eod.loc[i_eod['px_1st_hr'].isnull(),'o']
    
    t_qa1 = i_eod[~((i_eod['px_1st_hr'].round(2)>=i_eod['l'])&(i_eod['px_1st_hr'].round(2)<=i_eod['h']))]
    if len(t_qa1) > 0:
        raise Exception('1st hour mean price goes beyond h-l range.')
        
    i_eod['adjret_o_c'] = i_eod['c'].divide(i_eod['px_1st_hr'])-1
    
    ### get 2pm price, then calculate: 1) adjret_c_2pm and 2) adjusted 2 pm price
    # the 2pm price is a mixture of trade and nbbo
    # there is a small chance that 2 pm price goes beyond h-l range. 
    # This happens when there is no trade near 2pm, but there is bid ask. 
    # When we take mid point of bid ask and when either bid or ask is never traded, we get this seemingly wrong data. It's actually ok.
    i_px_2pm = get_price_asof_hhmm(1400)
    i_px_2pm = i_px_2pm.rename(columns = {'px': 'px_2pm'})
    i_eod = i_eod.merge(i_px_2pm, on = ['ticker','datadate'], how = 'left')
    
    t_qa2 = i_eod[(~((i_eod['px_2pm'].round(2)>=i_eod['l'])&(i_eod['px_2pm'].round(2)<=i_eod['h'])))&i_eod['px_2pm'].notnull()]
    if len(t_qa2) > 2:
  
      raise Exception('2pm price goes beyond h-l range.')
    
    i_eod['adjret_c_2pm'] = i_eod['px_2pm'].divide(i_eod['pre_c'])-1
    i_eod['adjret_o_2pm'] = i_eod['px_2pm'].divide(i_eod['o'])-1
    
    i_eod['px_adj_2pm']=(i_eod['o_adj']+i_eod['h_adj']+i_eod['l_adj']+i_eod['c_adj']).\
                        divide(i_eod['o']+i_eod['h']+i_eod['l']+i_eod['c']).\
                        multiply(i_eod['px_2pm'])# calculate adj_factor
    
    ### get 300, 500 and 50 ETF return
    i_hedge = pd.read_csv(r"S:\TZ\China Data Hunt\cache\510500_300_050.csv")
    i_hedge['datadate'] = pd.to_datetime(i_hedge['datadate'])
    i_hedge = i_hedge[['datadate','ticker','c']]
    i_hedge = i_hedge.sort_values(['ticker','datadate'])
    i_hedge['c_1d'] = i_hedge.groupby('ticker')['c'].shift()
    i_hedge['ret'] = i_hedge['c'].divide(i_hedge['c_1d'])-1
    i_hedge = i_hedge[['datadate','ticker','ret']].dropna()
    
    # get pbeta
    i_beta = get_sql('''select datadate, locid, pbeta from [BackTest].[dbo].[BARRA_CNE5S] ''')
    i_beta = i_beta[i_beta['locid'].str[:2]=='CN']
    i_beta['ticker_int'] = i_beta['locid'].str[2:].astype(int)
    i_beta = i_beta.drop(columns=['locid'])
    i_beta = i_beta.drop_duplicates(subset=['ticker_int','datadate'], keep = 'first')
        
    # merge stock return and hedge ticker return
    i_eod2 = i_eod.merge(i_hedge[i_hedge['ticker']=='510300.SH'][['datadate','ret']].rename(columns={'ret':'ret_300'}), 
                        on = ['datadate'], how = 'left')
    i_eod2 = i_eod2.merge(i_hedge[i_hedge['ticker']=='510500.SH'][['datadate','ret']].rename(columns={'ret':'ret_500'}), 
                        on = ['datadate'], how = 'left')
    i_eod2 = i_eod2.merge(i_hedge[i_hedge['ticker']=='510050.SH'][['datadate','ret']].rename(columns={'ret':'ret_50'}), 
                        on = ['datadate'], how = 'left')
    
    # merge HK connect flag
    i_eod2 = i_eod2.merge(i_tk_uni, on = ['ticker'], how = 'left')
    
    c_isin = (i_eod2['datadate'] >= i_eod2['entry_dt']) & ((i_eod2['datadate'] <= i_eod2['remove_dt'])|i_eod2['remove_dt'].isnull())
    i_eod2.loc[c_isin,'isin_hk_uni'] = 1
    i_eod2 = i_eod2.rename(columns={'entry_dt':'hk_uni_entry','remove_dt':'hk_uni_remove'})
    
    i_eod2 = i_eod2.sort_values(['ticker','datadate','isin_hk_uni'])
    i_eod2 = i_eod2.drop_duplicates(subset=['ticker','datadate'], keep = 'first')
    
    # merge pbeta
    i_eod2 = i_eod2.merge(i_beta, on = ['datadate','ticker_int'], how = 'left')
    
  
  # calculate hedged return (300)
    i_eod2['hret_300'] = i_eod2['adjret'] - i_eod2['pbeta'].multiply(i_eod2['ret_300'])
    
    # calculate nXd returns
    # nXd means the next X days of return. Haven't considered trade suspension here. Just mechanically get nXd return.
    
    i_eod2['adjret_n1d'] = i_eod2.groupby('ticker')['adjret'].shift(-2)
    for i in range(2,61):
        i_eod2['adjret_n'+str(i)+'d'] = i_eod2['adjret_n'+str(i-1)+'d'] + i_eod2.groupby('ticker')['adjret'].shift(-i-1)
    i_delete = [7,9,12,14,17,19]+list(range(21,25))+list(range(26,30))+list(range(31,35))+list(range(36,40))+list(range(41,45))+list(range(46,50))+list(range(51,55))+list(range(56,60))
    i_eod2 = i_eod2.drop(columns = ['adjret_n'+str(i)+'d' for i in i_delete])
    
    # formatting
    i_eod2 = i_eod2.drop(columns = ['hk_uni_entry', 'hk_uni_remove'])
    i_eod2 = i_eod2[['datadate', 'ticker', 'ticker_int', 'isin_hk_uni', 
                     'adjret', 'adjret_o_c', 'adjret_c_2pm', 'adjret_o_2pm', 
                     'v', 'amt', 'o', 'h', 'l', 'c', 'pre_c', 
                     'o_adj', 'h_adj', 'l_adj', 'c_adj', 'pre_c_adj',
                     'px_2pm', 'px_adj_2pm',
                     'S_DQ_TRADESTATUS', 'S_DQ_TRADESTATUSCODE', 
                     'limit_up', 'limit_down', 
                     'px_1st_hr', 
                     'ret_300', 'ret_500', 'ret_50', 'pbeta', 'hret_300',
                     'adjret_n1d', 'adjret_n2d', 'adjret_n3d', 'adjret_n4d', 'adjret_n5d',
                     'adjret_n6d', 'adjret_n8d', 'adjret_n10d', 'adjret_n11d', 'adjret_n13d',
                     'adjret_n15d', 'adjret_n16d', 'adjret_n18d', 'adjret_n20d',
                     'adjret_n25d', 'adjret_n30d', 'adjret_n35d', 'adjret_n40d',
                     'adjret_n45d', 'adjret_n50d', 'adjret_n55d', 'adjret_n60d']]
    i_eod2.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_mkt_data.parquet')
    
    
    # columns
#    ['datadate', 'ticker', 'ticker_int', 'isin_hk_uni', 
#     'adjret', 'adjret_o_c', 'adjret_c_2pm', 'adjret_o_2pm', 
#     'v', 'amt', 'o', 'h', 'l', 'c', 'pre_c', 
#     'o_adj', 'h_adj', 'l_adj', 'c_adj', 'pre_c_adj',
#     'px_2pm', 'px_adj_2pm',
#     'S_DQ_TRADESTATUS', 'S_DQ_TRADESTATUSCODE', 
#     'limit_up', 'limit_down', 
#     'px_1st_hr', 
#     'ret_300', 'ret_500', 'ret_50', 'pbeta', 'hret_300',
#     'adjret_n1d', 'adjret_n2d', 'adjret_n3d', 'adjret_n4d', 'adjret_n5d',
#     'adjret_n6d', 'adjret_n8d', 'adjret_n10d', 'adjret_n11d', 'ad
jret_n13d',
#     'adjret_n15d', 'adjret_n16d', 'adjret_n18d', 'adjret_n20d',
#     'adjret_n25d', 'adjret_n30d', 'adjret_n35d', 'adjret_n40d',
#     'adjret_n45d', 'adjret_n50d', 'adjret_n55d', 'adjret_n60d']


def get_wind_mkt_data(tk_list=None, col_list=None):
    
    if col_list is None:
        i_mkt_data = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_mkt_data.parquet')
    else:
        i_mkt_data = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_mkt_data.parquet',columns=col_list)
    
    if tk_list is not None:
        i_mkt_data = i_mkt_data[i_mkt_data['ticker'].isin(tk_list)]
    
    return i_mkt_data

def prepare_wind_ta_optperiod():
    
    cols = ['datadate','ticker','o_adj', 'h_adj', 'l_adj', 'c_adj', 'pre_c_adj', 'adjret']
    i_mktdata = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_mkt_data.parquet',columns=cols)
    i_mktdata = i_mktdata.sort_values(['ticker', 'datadate'])

    i_mktdata[['zz_curr_trend','zz_curr_idx','zz_vertex_1','zz_vertex_idx1','zz_vertex_2','zz_vertex_idx2',
               'zz_vertex_3','zz_vertex_idx3','zz_vertex_4','zz_vertex_idx4','zz_vertex_5','zz_vertex_idx5',
               'zz_vertex_6','zz_vertex_idx6','zz_vertex_7','zz_vertex_idx7','zz_vertex_8','zz_vertex_idx8',
               'zz_vertex_9','zz_vertex_idx9','zz_vertex_10','zz_vertex_idx10']] =\
               pd.DataFrame(i_mktdata.groupby('ticker')[['c_adj','h_adj','l_adj',]].\
               apply(lambda x: pd.DataFrame(ta_zigzag(x['c_adj'].values, x['h_adj'].values,x['l_adj'].values, 60, 3))).values)
    
    # calculate optimal period: median length of the past 9 zigzag lines 
    for i in range(1,10):
        i_mktdata['zz_line'+str(i)] = (i_mktdata['zz_vertex_idx'+str(i)] - i_mktdata['zz_vertex_idx'+str(i+1)])
    #i_mktdata['median_period'] = i_mktdata[['zz_line1','zz_line2','zz_line3','zz_line4','zz_line5',
    #                                         'zz_line6','zz_line7','zz_line8','zz_line9']].quantile(axis=1)
    
    # calculate optimal period: average length of the most recent 4 lines
    i_mktdata['median_period'] = i_mktdata[['zz_line1','zz_line2','zz_line3','zz_line4']].mean(axis=1).round(0)
    
    # smooth the optimal period time series
    i_mktdata['ticker_same'] = i_mktdata['ticker']==i_mktdata['ticker'].shift()    
    c_1st_period = (i_mktdata['ticker_same'])&(i_mktdata['median_period'].notnull()) &\
                   (i_mktdata['median_period'].shift().isnull())
    i_mktdata.loc[c_1st_period, 
'optperiod'] = i_mktdata.loc[c_1st_period, 'median_period']
    
    for i in range(1,len(i_mktdata)):
        if i_mktdata['ticker_same'].values[i] & pd.isnull(i_mktdata['optperiod'].values[i]):
            i_mktdata['optperiod'].values[i] = i_mktdata['optperiod'].values[i-1]+\
                np.sign(i_mktdata['median_period'].values[i]-i_mktdata['optperiod'].values[i-1])
    
    # final optperiod = optperiod * 0.6 (i.e. delay = 1/3 of an average line in zigzag)
    i_mktdata['optperiod'] = (i_mktdata['optperiod']*0.6).round(0)
    i_mktdata.loc[i_mktdata['optperiod'].notnull(),'optperiod'] = i_mktdata.loc[i_mktdata['optperiod'].notnull(),'optperiod'].astype(int)
    
    # qa
    if (len(i_mktdata[i_mktdata['median_period'].notnull() & i_mktdata['optperiod'].isnull()])>0) or \
        (len(i_mktdata[i_mktdata['median_period'].isnull() & i_mktdata['optperiod'].notnull()])>0):
        raise Exception('median_period and optperiod length do not align.')
    
    i_mktdata[['ticker','datadate','optperiod']].to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_optperiod.parquet')


def get_wind_ta_optperiod():
    return pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_optperiod.parquet')


def prepare_wind_ta_optperiod_method2():
    
    # this is based on the "best-fit ma period" idea    
    cols = ['datadate','ticker','o_adj', 'h_adj', 'l_adj', 'c_adj', 'pre_c_adj', 'adjret']
    i_mktdata = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_mkt_data.parquet',columns=cols)
    i_mktdata = i_mktdata.sort_values(['ticker', 'datadate'])
    
    i_mktdata['optperiod_tmp'] = i_mktdata.groupby('ticker').rolling(130)['c_adj'].\
                                     apply(lambda x: ta_best_ma_period(x, lower_limit=10, upper_limit=61), raw = True).values
    i_mktdata['optperiod'] = i_mktdata.groupby('ticker').rolling(20)['optperiod_tmp'].mean().values
    i_mktdata['optperiod'] = i_mktdata['optperiod'].round()
    i_mktdata = i_mktdata.drop(columns = ['optperiod_tmp'])
    
    i_mktdata[['ticker','datadate','optperiod']].to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_optperiod_method2.parquet')


def get_wind_ta_optperiod_method2():
    return pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_optperiod_method2.parquet')

def verify_optperiod():
    
    # this shows that:
    # when optperiod is median period, optperiod's pnl has lower variance, but not superior to 20-14 Dual-MA's pnl.
    # when optperiod is mean of recent 4 periods, 
optperiod's pnl is inferior to 20-14.
    
    cols = ['datadate', 'ticker', 'adjret', 'o_adj', 'h_adj', 'l_adj', 'c_adj', 'pre_c_adj', 'adjret_n1d', 'adjret_n2d', ]
    i_mkt = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_mkt_data.parquet', columns = cols)
    i_mkt = i_mkt.sort_values(['ticker','datadate'])
    
    i_optperiod = get_wind_ta_optperiod_method2()
    i_mkt = i_mkt.merge(i_optperiod, on = ['datadate', 'ticker'], how = 'left')
    i_mkt.loc[i_mkt['optperiod'].notnull(), 'optperiod'] = i_mkt.loc[i_mkt['optperiod'].notnull(), 'optperiod'].astype(int)
    
    i_mkt['id'] = list(range(len(i_mkt)))
    t_tk_loc = i_mkt.groupby('ticker')['id'].agg(['min','max'])
    o_pst_20_14 = []
    o_pst_optperiod = []
    for i,r in t_tk_loc.iterrows():
        print('.',end='')
        t_mkt = i_mkt.iloc[r['min']:r['max']+1]
        #normal ma
        t_mkt['ma_20'] = t_mkt.rolling(20)['c_adj'].mean()
        t_mkt['ma_14'] = t_mkt.rolling(14)['c_adj'].mean()
        c_up_cross = (t_mkt['ma_14']>t_mkt['ma_20'])&(t_mkt['ma_14'].shift()<t_mkt['ma_20'].shift())
        c_down_cross = (t_mkt['ma_14']<t_mkt['ma_20'])&(t_mkt['ma_14'].shift()>t_mkt['ma_20'].shift())
        t_mkt.loc[c_up_cross, 'pst_20_14'] = 1
        t_mkt.loc[c_down_cross, 'pst_20_14'] = -1
        t_mkt['pst_20_14'] = t_mkt['pst_20_14'].fillna(method = 'ffill')
        o_pst_20_14.extend(t_mkt['pst_20_14'].values.tolist())
        #optperiod ma
        t_l_ma = []
        t_l_ma_1d = []
        t_s_ma = []
        t_s_ma_1d = []
        for j in range(0, len(t_mkt)):
            curr_optperiod = np.nan if np.isnan(t_mkt['optperiod'].values[j]) else int(t_mkt['optperiod'].values[j])
            if np.isnan(curr_optperiod) or (curr_optperiod>(t_mkt['id'].values[j]-r['min']+1)):
                t_l_ma.append(np.nan)
                t_l_ma_1d.append(np.nan)
                t_s_ma.append(np.nan)
                t_s_ma_1d.append(np.nan)
            else:
                t_l_ma.append(np.mean(t_mkt['c_adj'].values[j+1-curr_optperiod+1:j+1]))
                t_l_ma_1d.append(np.mean(t_mkt['c_adj'].values[j-curr_optperiod+1:j]))
                t_s_ma.append(np.mean(t_mkt['c_adj'].values[j+1-int(curr_optperiod*0.7)+1:j+1]))
                t_s_ma_1d.append(np.mean(t_mkt['c_adj'].values[j-int(curr_optperiod*0.7)+1:j]))
        t_l_ma =  pd.Series(t_l_ma)
        t_l_ma_1d =  pd.Series(t_l_ma_1d)
        t_s_ma =  pd.Series(t_s_ma)
        t_s_ma_1d =  pd.Series(t_s_ma_1d)
        t_mkt.loc
[(t_s_ma>t_l_ma).values, 'pst_optperiod'] = 1
        t_mkt.loc[(t_s_ma<t_l_ma).values, 'pst_optperiod'] = -1
        o_pst_optperiod.extend(t_mkt['pst_optperiod'].values.tolist())
    i_mkt['pst_20_14'] = o_pst_20_14
    i_mkt['pst_optperiod'] = o_pst_optperiod
    
    i_mkt['pnl_20_14'] = i_mkt['pst_20_14'].multiply(i_mkt['adjret_n1d'])
    i_mkt['pnl_optperiod'] = i_mkt['pst_optperiod'].multiply(i_mkt['adjret_n1d'])
    
    o_pnl1 = i_mkt.groupby('datadate')['pnl_20_14'].sum().cumsum()
    o_pnl2 = i_mkt.groupby('datadate')['pnl_optperiod'].sum().cumsum()
    o_pnl_all = pd.concat((o_pnl1, o_pnl2), axis = 1)
    o_pnl_all.plot()
    
    t1 = i_mkt[i_mkt.ticker=='002494.SZ']
    t1[['pnl_20_14','pnl_optperiod']].cumsum(axis=0).plot()


def prepare_trailing_ret():
    
    
    # close price
    
    i_wind_c = get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                       s_dq_close as c, s_dq_preclose as prec
                       from wind_prod.dbo.ashareeodprices
                       where s_dq_tradestatuscode!=0 and trade_dt>='20170101' 
                       and s_info_windcode not like '%BJ' ''')
    i_wind_c['datadate'] = pd.to_datetime(i_wind_c['datadate'], format = '%Y%m%d')
    
    
    # L2_cn_codebook / Ingest SHSZ trade open price
    
    i_o = get_q('''get `$":/export/datadev/Data/SHSZ/TRADE_metrics/price_mkt_open" ''')
    i_o['ticker'] = i_o['code'].str.decode('utf8')
    c_sh = i_o['ticker'].str[0].isin(['6'])
    c_sz = i_o['ticker'].str[0].isin(['0','3'])
    i_o.loc[c_sh, 'ticker'] = i_o.loc[c_sh, 'ticker'] + '.SH'
    i_o.loc[c_sz, 'ticker'] = i_o.loc[c_sz, 'ticker'] + '.SZ'
    i_o['datadate'] = i_o['date']
    
    i_o = i_o.drop(columns=['date', 'code'])
        

    # barra

    i_b = get_sql('''select * FROM [CNDBPROD].[dbo].[BARRA_GEM3L_CN_FORMAT] 
                     where datadate >= '2017-01-01' ''')
    i_b = i_b.rename(columns = {'Ticker': 'ticker', 'DataDate': 'datadate'})
    c_sh = i_b['ticker'].str[0].isin(['6'])
    c_sz = i_b['ticker'].str[0].isin(['0','3'])
    i_b.loc[c_sh, 'ticker'] = i_b.loc[c_sh, 'ticker'] + '.SH'
    i_b.loc[c_sz, 'ticker'] = i_b.loc[c_sz, 'ticker'] + '.SZ'
    
    
    # 2k universe
    
    i_2k = get_sql('''select ticker, datadate from [CNDBPROD].[dbo].[UNIVERSE_T2000_CN_GEM3L]''')
    c_sh = i_2k['ticker'].str[0].isin(['6'])
    c_sz = i_2k['ticker'].str[0].isin(['0','3'])
    i_2k.loc[c_sh, 'ticker'] = i_2k.loc[c_sh, 'ticker'] + '.SH'
    i_2k.loc[c_s
z, 'ticker'] = i_2k.loc[c_sz, 'ticker'] + '.SZ'
    i_2k['flg_2k'] = 1
    
    
    # combine data
    
    icom = i_o.merge(i_wind_c, on = ['ticker', 'datadate'], how = 'inner')
    icom = icom.merge(i_b, on = ['ticker', 'datadate'], how = 'inner')
    icom = icom.merge(i_2k, on = ['ticker', 'datadate'], how = 'left')
    icom = icom.sort_values(['ticker', 'datadate']).reset_index(drop = True)
    
    COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD',
           'RESVOL', 'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL',
           'AIRLINES', 'AUTOCOMP', 'BANKS', 'BIOTECH', 'CAPGOODS', 'CHEMICAL',
           'COMMSVCS', 'COMMUNIC', 'COMPUTER', 'CONSDUR', 'CONSTPP', 'CONSVCS',
           'DIVFINAN', 'DIVMETAL', 'ENERGY', 'FOODPRD', 'FOODRETL', 'HEALTH',
           'HSHLDPRD', 'INSURAN', 'INTERNET', 'MEDIA', 'OILEXPL', 'OILGAS',
           'PHARMAC', 'PRECMETL', 'REALEST', 'RETAIL', 'SEMICOND', 'SOFTWARE',
           'STEEL', 'TELECOM', 'TRANSPRT', 'UTILITY']
    
    
    for c in ['vwap1030', 'vwap1000', 'twap1030', 'twap1000']:
        icom[c+'_2c'] = icom['c'].divide(icom[c])-1
    icom['c2c'] = icom['c'].divide(icom['prec'])-1
    icom.loc[icom['flg_2k']==1, 'twap1000_2c_2k'] = icom.loc[icom['flg_2k']==1, 'twap1000_2c']
    
    
    def tmp_orth(alpha_sr, factors_df):    
        cols_factor = factors_df.columns.tolist()
        df_orth = factors_df.copy()
        df_orth[alpha_sr.name] = alpha_sr.values    
        return pd.Series(ols_residual(df_orth[cols_factor].values, df_orth[alpha_sr.name].values, intercept=False),index=alpha_sr.index).to_frame()
    for c in ['vwap1030_2c', 'vwap1000_2c', 'twap1030_2c', 'twap1000_2c', 'c2c']:
        icom[c+'_bret'] = icom.groupby('datadate')[COLS+[c]].apply(lambda x: tmp_orth(x[c], x[COLS])).values
    icom['twap1000_2c_2k_bret'] = icom.groupby('datadate')[COLS+['twap1000_2c_2k']].apply(lambda x: tmp_orth(x['twap1000_2c_2k'], x[COLS])).values
    
    
    for c in ['vwap1030_2c', 'vwap1000_2c', 'twap1030_2c', 'twap1000_2c', 'c2c']:
        icom[c+'_t4w'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate',min_period=10)[c].mean().values
        icom[c+'_t9w'] = icom.groupby('ticker').rolling(datetime.timedelta(days=63),on='datadate',min_period=20)[c].mean().values
        icom[c+'_t13w'] = icom.groupby('ticker').rolling(datetime.timedelta(days=91),on='datadate',min_period=30)[c].mean().values
        icom[c+'_bret_t4w'] = icom.groupby('ticker').rolling(datetime.ti
medelta(days=28),on='datadate',min_period=10)[c+'_bret'].mean().values
        icom[c+'_bret_t9w'] = icom.groupby('ticker').rolling(datetime.timedelta(days=63),on='datadate',min_period=20)[c+'_bret'].mean().values
        icom[c+'_bret_t13w'] = icom.groupby('ticker').rolling(datetime.timedelta(days=91),on='datadate',min_period=30)[c+'_bret'].mean().values        
    icom['twap1000_2c_2k_bret_t4w'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate',min_period=10)['twap1000_2c_2k_bret'].mean().values
    
    
    icom = icom[['ticker', 'datadate',
                 'vwap1030', 'vwap1000', 'twap1030', 'twap1000', 'c', 'prec',
                 'vwap1030_2c', 'vwap1000_2c', 'twap1030_2c', 'twap1000_2c', 'c2c', 
                 'vwap1030_2c_bret', 'vwap1000_2c_bret', 'twap1030_2c_bret', 'twap1000_2c_bret', 'c2c_bret',
                 'vwap1030_2c_t4w', 'vwap1030_2c_t9w', 'vwap1030_2c_t13w', 'vwap1030_2c_bret_t4w', 'vwap1030_2c_bret_t9w', 'vwap1030_2c_bret_t13w',
                 'vwap1000_2c_t4w', 'vwap1000_2c_t9w', 'vwap1000_2c_t13w', 'vwap1000_2c_bret_t4w', 'vwap1000_2c_bret_t9w', 'vwap1000_2c_bret_t13w',
                 'twap1030_2c_t4w', 'twap1030_2c_t9w', 'twap1030_2c_t13w', 'twap1030_2c_bret_t4w', 'twap1030_2c_bret_t9w', 'twap1030_2c_bret_t13w',
                 'twap1000_2c_t4w', 'twap1000_2c_t9w', 'twap1000_2c_t13w', 'twap1000_2c_bret_t4w', 'twap1000_2c_bret_t9w', 'twap1000_2c_bret_t13w',
                 'c2c_t4w', 'c2c_t9w', 'c2c_t13w', 'c2c_bret_t4w', 'c2c_bret_t9w', 'c2c_bret_t13w',
                 'twap1000_2c_2k_bret', 'twap1000_2c_2k_bret_t4w']]
    
    icom.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet')
    
    
    


def prepare_future_ret():
    
    # on each datadate for each ticker, this outputs future sum and avg return
    
    
    # close price
    
    i_wind_c = get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                       s_dq_close as c, s_dq_preclose as prec
                       from wind_prod.dbo.ashareeodprices
                       where s_dq_tradestatuscode!=0 and trade_dt>='20170101' 
                       and s_info_windcode not like '%BJ' ''')
    i_wind_c['datadate'] = pd.to_datetime(i_wind_c['datadate'], format = '%Y%m%d')
    
    
    # barra

    i_b = get_sql('''select * FROM [CNDBPROD].[dbo].[BARRA_GEM3L_CN_FORMAT] 
                     where datadate >= '2017-01-01' ''')
    i_b = i_b.rename(columns = {'Ticker': 'ticker
', 'DataDate': 'datadate'})
    c_sh = i_b['ticker'].str[0].isin(['6'])
    c_sz = i_b['ticker'].str[0].isin(['0','3'])
    i_b.loc[c_sh, 'ticker'] = i_b.loc[c_sh, 'ticker'] + '.SH'
    i_b.loc[c_sz, 'ticker'] = i_b.loc[c_sz, 'ticker'] + '.SZ'
    
    
    # 2k universe
    
    i_2k = get_sql('''select ticker, datadate from [CNDBPROD].[dbo].[UNIVERSE_T2000_CN_GEM3L]''')
    c_sh = i_2k['ticker'].str[0].isin(['6'])
    c_sz = i_2k['ticker'].str[0].isin(['0','3'])
    i_2k.loc[c_sh, 'ticker'] = i_2k.loc[c_sh, 'ticker'] + '.SH'
    i_2k.loc[c_sz, 'ticker'] = i_2k.loc[c_sz, 'ticker'] + '.SZ'
    i_2k['flg_2k'] = 1
    
    
    # combine data
    
    icom = i_wind_c.merge(i_b, on = ['ticker', 'datadate'], how = 'inner')
    icom = icom.merge(i_2k, on = ['ticker', 'datadate'], how = 'left')
    icom = icom.sort_values(['ticker', 'datadate']).reset_index(drop = True)
    
    # calculate bret
    
    COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD',
           'RESVOL', 'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL',
           'AIRLINES', 'AUTOCOMP', 'BANKS', 'BIOTECH', 'CAPGOODS', 'CHEMICAL',
           'COMMSVCS', 'COMMUNIC', 'COMPUTER', 'CONSDUR', 'CONSTPP', 'CONSVCS',
           'DIVFINAN', 'DIVMETAL', 'ENERGY', 'FOODPRD', 'FOODRETL', 'HEALTH',
           'HSHLDPRD', 'INSURAN', 'INTERNET', 'MEDIA', 'OILEXPL', 'OILGAS',
           'PHARMAC', 'PRECMETL', 'REALEST', 'RETAIL', 'SEMICOND', 'SOFTWARE',
           'STEEL', 'TELECOM', 'TRANSPRT', 'UTILITY']
    
    icom['c2c'] = icom['c'].divide(icom['prec'])-1
    
    def tmp_orth(alpha_sr, factors_df):    
        cols_factor = factors_df.columns.tolist()
        df_orth = factors_df.copy()
        df_orth[alpha_sr.name] = alpha_sr.values    
        return pd.Series(ols_residual(df_orth[cols_factor].values, df_orth[alpha_sr.name].values, intercept=False),index=alpha_sr.index).to_frame()
    icom['c2c_bret'] = icom.groupby('datadate')[COLS+['c2c']].apply(lambda x: tmp_orth(x['c2c'], x[COLS])).values
    
    # calculate future returns
    
    icom = icom.sort_values(['ticker', 'datadate'])
    icom['datadate+2d'] = icom.groupby('ticker')['datadate'].shift(-2)
    icom['c2c+2d'] = icom.groupby('ticker')['c2c'].shift(-2)
    icom['c2c_bret+2d'] = icom.groupby('ticker')['c2c_bret'].shift(-2)
    
    o_futureret = []
    
    for dt in pd.date_range(start= '2017-01-01', end = '2022-06-30'):
        print(dt.strftime('%Y%m%d'),end=',')
        
        tcom_n1y = icom[icom['datadate'].ge(
dt) & icom['datadate+2d'].le(dt+pd.to_timedelta('365 days'))]
        s_n1y = tcom_n1y.groupby(['ticker']).agg({'c2c+2d':['mean','sum'], 'c2c_bret+2d':['mean','sum']})
        s_n1y = s_n1y.reset_index()
        s_n1y.columns = ['ticker','c2c_avn1y','c2c_smn1y','c2c_bret_avn1y','c2c_bret_smn1y']
        tcom_n1q = tcom_n1y[tcom_n1y['datadate+2d'].le(dt+pd.to_timedelta('91 days'))]
        s_n1q = tcom_n1q.groupby(['ticker']).agg({'c2c+2d':['mean','sum'], 'c2c_bret+2d':['mean','sum']})
        s_n1q = s_n1q.reset_index()
        s_n1q.columns = ['ticker','c2c_avn1q','c2c_smn1q','c2c_bret_avn1q','c2c_bret_smn1q']
        tcom_n1m = tcom_n1q[tcom_n1q['datadate+2d'].le(dt+pd.to_timedelta('28 days'))]
        s_n1m = tcom_n1m.groupby(['ticker']).agg({'c2c+2d':['mean','sum'], 'c2c_bret+2d':['mean','sum']})
        s_n1m = s_n1m.reset_index()
        s_n1m.columns = ['ticker','c2c_avn1m','c2c_smn1m','c2c_bret_avn1m','c2c_bret_smn1m']
        tcom_n2w = tcom_n1m[tcom_n1m['datadate+2d'].le(dt+pd.to_timedelta('14 days'))]
        s_n2w = tcom_n2w.groupby(['ticker']).agg({'c2c+2d':['mean','sum'], 'c2c_bret+2d':['mean','sum']})
        s_n2w = s_n2w.reset_index()
        s_n2w.columns = ['ticker','c2c_avn2w','c2c_smn2w','c2c_bret_avn2w','c2c_bret_smn2w']
        tcom_n1w = tcom_n2w[tcom_n2w['datadate+2d'].le(dt+pd.to_timedelta('7 days'))]
        s_n1w = tcom_n1w.groupby(['ticker']).agg({'c2c+2d':['mean','sum'], 'c2c_bret+2d':['mean','sum']})
        s_n1w = s_n1w.reset_index()
        s_n1w.columns = ['ticker','c2c_avn1w','c2c_smn1w','c2c_bret_avn1w','c2c_bret_smn1w']
    
        s = s_n1y.merge(s_n1q, on = 'ticker', how = 'outer')
        s = s.merge(s_n1m, on = 'ticker', how = 'outer')
        s = s.merge(s_n2w, on = 'ticker', how = 'outer')
        s = s.merge(s_n1w, on = 'ticker', how = 'outer')
        s['datadate'] = dt
        o_futureret.append(s)
        
    o_futureret = pd.concat(o_futureret, axis = 0)    
    o_futureret.to_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_future_ret.parquet')
    
    
    

### ADV
def get_wind_adv():
    # for each tdate (wind), output adv figures 
    # the adjustment factors includes both stock split and dividend 
    
    i_adv = get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                   S_DQ_ADJFACTOR as adjf, S_DQ_VOLUME*100 as v 
                   from wind_prod.dbo.ashareeodprices
                   order by ticker, datadate ''')

    i_adv['vadj'] = i_adv['v'].divide(i_adv['
adjf'])
    i_adv['adv_t20d'] = i_adv.groupby('ticker')['vadj'].rolling(20).mean().values
    i_adv['adv_t20d'] = i_adv['adv_t20d'].multiply(i_adv['adjf'])
    i_adv['adv_t65d'] = i_adv.groupby('ticker')['vadj'].rolling(65).mean().values
    i_adv['adv_t65d'] = i_adv['adv_t65d'].multiply(i_adv['adjf'])
    i_adv['adv_t130d'] = i_adv.groupby('ticker')['vadj'].rolling(130).mean().values
    i_adv['adv_t130d'] = i_adv['adv_t130d'].multiply(i_adv['adjf'])
    i_adv['adv_t252d'] = i_adv.groupby('ticker')['vadj'].rolling(252).mean().values
    i_adv['adv_t252d'] = i_adv['adv_t252d'].multiply(i_adv['adjf'])
    
    i_adv['datadate'] = pd.to_datetime(i_adv['datadate'], format = '%Y%m%d')
    i_adv = i_adv.drop(columns = ['vadj','adjf'])
    return i_adv
    








### shares outstanding

def get_wind_float():
    
    i_float = get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                      TOT_SHR_TODAY*10000 as tot_guben, FLOAT_A_SHR_TODAY*10000 as float_guben, 
                      FREE_SHARES_TODAY*10000 as freefloat_guben 
                      from wind_prod.dbo.AShareEODDerivativeIndicator
                      where trade_dt >= '20150101'
                      ''')
    i_float['datadate'] = pd.to_datetime(i_float['datadate'] , format='%Y%m%d')
    i_float = i_float.sort_values('datadate')
    
    return i_float



### factor: Barra
def get_barra_factors(date_start='2017-06-01', date_end='2019-05-01'):
    # this returns all a-share tickers, on all tdates, per barra 
    # output columns: 
    #     ['bf_LIQUIDTY', 'bf_LEVERAGE', 'bf_BTOP', 'bf_GROWTH', 'bf_EARNYILD', 'bf_SIZE', 
    #               'bf_MOMENTUM', 'bf_SRISK', 'bf_SPREAD', 'bf_AVGPVADJ', 'bf_RESVOL', 'bf_TURNOVER', 
    #               'G_45', 'G_20', 'G_25', 'G_35', 'G_15', 'G_55', 'G_30', 'G_40', 'G_60', 'G_10', 'G_50']
    
    i_factor = get_sql('''select ticker as code, datadate, 
                           LIQUIDTY as bf_LIQUIDTY, LEVERAGE as bf_LEVERAGE, BTOP as bf_BTOP, GROWTH as bf_GROWTH,
                           EARNYILD as bf_EARNYILD, SIZE as bf_SIZE, MOMENTUM as bf_MOMENTUM, SRISK as bf_SRISK, 
                           spread as bf_SPREAD, avgPVadj as bf_AVGPVADJ, RESVOL as bf_RESVOL, 
                           PX_VOLUME / EQY_FLOAT as bf_TURNOVER, GSECTOR 
                          from cndb.dbo.UNIVERSE_ALL_CN where datadate >'{0}' and datadate< '{1}' '''.format(date_start, date_end))
    i_factor['bf_TURNOVER'] = i_factor['bf_TURNOVER'].rep
lace(np.inf,np.nan).replace(-np.inf,np.nan)
    i_factor['bf_TURNOVER'] = i_factor['bf_TURNOVER'].replace(0, np.nan)
    i_factor['bf_TURNOVER'] = np.log(i_factor['bf_TURNOVER'])
    
    for g in i_factor['GSECTOR'].unique().tolist():
        i_factor.loc[i_factor['GSECTOR']==g, 'G_'+g] = 1
        i_factor.loc[i_factor['GSECTOR']!=g, 'G_'+g] = 0
    i_factor = i_factor.drop(columns=['GSECTOR'])
        
    return i_factor


### Static Data

def prepare_china_sd():
    
    i_sd = get_sql_prod('''select datadate, replace(ric, '.SS', '.SH') as ticker, name,
                       [GSECTOR],[GGROP],[GIND],[GSUBIND],
                       [avgPVadj],[spread],[volatility],[MC_l1d],[FLOAT_l1d],[WIND_V_l1d],[V_l1d],[PV_l1d],
                       [SRISK],[BETA],[MOMENTUM],[SIZE],[EARNYILD],[RESVOL],[GROWTH],[BTOP],
                       [LEVERAGE],[LIQUIDTY],[SIZENL],
                       [BarrRet_SRISK-5d],[BarrRet_SRISK-4d],[BarrRet_SRISK-3d],[BarrRet_SRISK-2d],[BarrRet_SRISK-1d],
                       [BarrRet_SRISK+0d],
                       [BarrRet_SRISK+1d],[BarrRet_SRISK+2d],[BarrRet_SRISK+3d],[BarrRet_SRISK+4d],[BarrRet_SRISK+5d],
                       [BarrRet_SRISK+6d],[BarrRet_SRISK+7d],[BarrRet_SRISK+8d],[BarrRet_SRISK+9d],[BarrRet_SRISK+10d],
                       [BarrRet_SRISK+11d],[BarrRet_SRISK+12d],[BarrRet_SRISK+13d],[BarrRet_SRISK+14d],[BarrRet_SRISK+15d],
                       [BarrRet_SRISK+16d],[BarrRet_SRISK+17d],[BarrRet_SRISK+18d],[BarrRet_SRISK+19d],[BarrRet_SRISK+20d],
                       [BarrRet_SRISK+21d],
                       [BarrRet_CLIP-1d],[BarrRet_CLIP+0d],[BarrRet_CLIP+1d],[BarrRet_CLIP+2d],[BarrRet_CLIP+3d],
                       [BarrRet_CLIP+4d],[BarrRet_CLIP+5d],[BarrRet_CLIP+6d],[BarrRet_CLIP+7d],[BarrRet_CLIP+8d],
                       [BarrRet_CLIP+9d],[BarrRet_CLIP+10d],[BarrRet_CLIP+11d],[BarrRet_CLIP+12d],[BarrRet_CLIP+13d],
                       [BarrRet_CLIP+14d],[BarrRet_CLIP+15d],[BarrRet_CLIP+16d],[BarrRet_CLIP+17d],[BarrRet_CLIP+18d],
                       [BarrRet_CLIP+19d],[BarrRet_CLIP+20d],[BarrRet_CLIP+21d],
                       [RawRet+1d], [RawRet+0d] 
                       from [SUMMITDBPROD].[dbo].[Static_Data_CN]
                       order by ticker, datadate''')
    i_sd = i_sd.drop_duplicates(subset=['ticker','datadate'],keep = 'first')
    
    # fetch exchange code
    i_sd['S_INFO_EXCHMARKET'] = i_sd['ticker'].str.split('.').str[-1]
    i_sd = i_sd[i_sd['S_INFO_EXCHMA
RKET']!='ZK']
    
    # get trading calendar 
    i_cal = get_wind_trade_cal()
    i_cal = i_cal[i_cal['S_INFO_EXCHMARKET'].isin(['SSE','SZSE'])]
    i_cal['S_INFO_EXCHMARKET'] = i_cal['S_INFO_EXCHMARKET'].replace('SSE', 'SH')
    i_cal['S_INFO_EXCHMARKET'] = i_cal['S_INFO_EXCHMARKET'].replace('SZSE', 'SZ')
    i_cal = i_cal.rename(columns={'datadate':'datadate_p1d', 'tdate_1d':'datadate'})
    i_cal = i_cal[['datadate','S_INFO_EXCHMARKET','datadate_p1d']]
    i_cal = i_cal.dropna()
    
    # process datadate
    i_sd = i_sd.rename(columns = {'datadate': 'datadate_p1d'})
    i_sd = i_sd.merge(i_cal, on = ['S_INFO_EXCHMARKET','datadate_p1d'], how = 'left')
        
    i_sd.to_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data.parquet")



### Static Data - FX adjusted

def prepare_china_sd_fx():
    
    i_sd = get_sql_prod('''select datadate, replace(ric, '.SS', '.SH') as ticker, name,
                       [GSECTOR],[GGROP],[GIND],[GSUBIND],
                       [avgPVadj],[spread],[volatility],[MC_l1d],[FLOAT_l1q],[WIND_V_l1d],V,PV,
                       [SRISK],[BETA],[MOMENTUM],[SIZE],[EARNYILD],[RESVOL],[GROWTH],[BTOP],
                       [LEVERAGE],[LIQUIDTY],[SIZENL],
                       [BarrRet_SRISK-5d],[BarrRet_SRISK-4d],[BarrRet_SRISK-3d],[BarrRet_SRISK-2d],[BarrRet_SRISK-1d],
                       [BarrRet_SRISK+0d],
                       [BarrRet_SRISK+1d],[BarrRet_SRISK+2d],[BarrRet_SRISK+3d],[BarrRet_SRISK+4d],[BarrRet_SRISK+5d],
                       [BarrRet_SRISK+6d],[BarrRet_SRISK+7d],[BarrRet_SRISK+8d],[BarrRet_SRISK+9d],[BarrRet_SRISK+10d],
                       [BarrRet_SRISK+11d],[BarrRet_SRISK+12d],[BarrRet_SRISK+13d],[BarrRet_SRISK+14d],[BarrRet_SRISK+15d],
                       [BarrRet_SRISK+16d],[BarrRet_SRISK+17d],[BarrRet_SRISK+18d],[BarrRet_SRISK+19d],[BarrRet_SRISK+20d],
                       [BarrRet_SRISK+21d],
                       [BarrRet_CLIP-1d],[BarrRet_CLIP+0d],[BarrRet_CLIP+1d],[BarrRet_CLIP+2d],[BarrRet_CLIP+3d],
                       [BarrRet_CLIP+4d],[BarrRet_CLIP+5d],[BarrRet_CLIP+6d],[BarrRet_CLIP+7d],[BarrRet_CLIP+8d],
                       [BarrRet_CLIP+9d],[BarrRet_CLIP+10d],[BarrRet_CLIP+11d],[BarrRet_CLIP+12d],[BarrRet_CLIP+13d],
                       [BarrRet_CLIP+14d],[BarrRet_CLIP+15d],[BarrRet_CLIP+16d],[BarrRet_CLIP+17d],[BarrRet_CLIP+18d],
                       [BarrRet_CLIP+19d],[BarrRet_CLIP+20d],[BarrRet_CLIP+21d],
                       [RawRet+1d], [RawRet+0d
] 
                       from [SUMMITDBPROD].[dbo].[Static_Data_CN_FX]
                       order by ticker, datadate''')
    i_sd = i_sd.drop_duplicates(subset=['ticker','datadate'],keep = 'first')
    
    # calculate V and PV_lqd
    i_sd = i_sd.sort_values(['ticker', 'datadate'])
    i_sd['V_l1d'] = i_sd.groupby('ticker')['V'].shift()
    i_sd['PV_l1d'] = i_sd.groupby('ticker')['PV'].shift()
    
    # fetch exchange code
    i_sd['S_INFO_EXCHMARKET'] = i_sd['ticker'].str.split('.').str[-1]
    i_sd = i_sd[i_sd['S_INFO_EXCHMARKET']!='ZK']
    
    # get trading calendar 
    i_cal = get_wind_trade_cal()
    i_cal = i_cal[i_cal['S_INFO_EXCHMARKET'].isin(['SSE','SZSE'])]
    i_cal['S_INFO_EXCHMARKET'] = i_cal['S_INFO_EXCHMARKET'].replace('SSE', 'SH')
    i_cal['S_INFO_EXCHMARKET'] = i_cal['S_INFO_EXCHMARKET'].replace('SZSE', 'SZ')
    i_cal = i_cal.rename(columns={'datadate':'datadate_p1d', 'tdate_1d':'datadate'})
    i_cal = i_cal[['datadate','S_INFO_EXCHMARKET','datadate_p1d']]
    i_cal = i_cal.dropna()
    
    # process datadate
    i_sd = i_sd.rename(columns = {'datadate': 'datadate_p1d'})
    i_sd = i_sd.merge(i_cal, on = ['S_INFO_EXCHMARKET','datadate_p1d'], how = 'left')
        
    i_sd.to_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_fx.parquet")




def prepare_hkuni_sd():
    
    i_sd = get_sql_prod('''select datadate, replace(ric, '.SS', '.SH') as ticker, name,
                       [GSECTOR],[GGROP],[GIND],[GSUBIND],
                       [avgPVadj],[spread],[volatility],[MC_l1d],[FLOAT_l1q],[WIND_V_l1d],V,PV,
                       [SRISK],[BETA],[MOMENTUM],[SIZE],[EARNYILD],[RESVOL],[GROWTH],[BTOP],
                       [LEVERAGE],[LIQUIDTY],[SIZENL],
                       [BarrRet_SRISK-5d],[BarrRet_SRISK-4d],[BarrRet_SRISK-3d],[BarrRet_SRISK-2d],[BarrRet_SRISK-1d],
                       [BarrRet_SRISK+0d],
                       [BarrRet_SRISK+1d],[BarrRet_SRISK+2d],[BarrRet_SRISK+3d],[BarrRet_SRISK+4d],[BarrRet_SRISK+5d],
                       [BarrRet_SRISK+6d],[BarrRet_SRISK+7d],[BarrRet_SRISK+8d],[BarrRet_SRISK+9d],[BarrRet_SRISK+10d],
                       [BarrRet_SRISK+11d],[BarrRet_SRISK+12d],[BarrRet_SRISK+13d],[BarrRet_SRISK+14d],[BarrRet_SRISK+15d],
                       [BarrRet_SRISK+16d],[BarrRet_SRISK+17d],[BarrRet_SRISK+18d],[BarrRet_SRISK+19d],[BarrRet_SRISK+20d],
                       [BarrRet_SRISK+21d],
                       [BarrRet_CLIP-1d],[BarrRet_CLIP+0d],[BarrRet_CLIP+1d],[BarrRe
t_CLIP+2d],[BarrRet_CLIP+3d],
                       [BarrRet_CLIP+4d],[BarrRet_CLIP+5d],[BarrRet_CLIP+6d],[BarrRet_CLIP+7d],[BarrRet_CLIP+8d],
                       [BarrRet_CLIP+9d],[BarrRet_CLIP+10d],[BarrRet_CLIP+11d],[BarrRet_CLIP+12d],[BarrRet_CLIP+13d],
                       [BarrRet_CLIP+14d],[BarrRet_CLIP+15d],[BarrRet_CLIP+16d],[BarrRet_CLIP+17d],[BarrRet_CLIP+18d],
                       [BarrRet_CLIP+19d],[BarrRet_CLIP+20d],[BarrRet_CLIP+21d],
                       [RawRet+1d], [RawRet+0d] 
                       from [SUMMITDBPROD].[dbo].[Static_Data_CN_FXHC]
                       order by ticker, datadate''')
    i_sd = i_sd.drop_duplicates(subset=['ticker','datadate'],keep = 'first')
    
    # calculate V and PV_lqd
    i_sd = i_sd.sort_values(['ticker', 'datadate'])
    i_sd['V_l1d'] = i_sd.groupby('ticker')['V'].shift()
    i_sd['PV_l1d'] = i_sd.groupby('ticker')['PV'].shift()
    
    # fetch exchange code
    i_sd['S_INFO_EXCHMARKET'] = i_sd['ticker'].str.split('.').str[-1]
    i_sd = i_sd[i_sd['S_INFO_EXCHMARKET']!='ZK']
    
    # get trading calendar 
    i_cal = get_wind_trade_cal()
    i_cal = i_cal[i_cal['S_INFO_EXCHMARKET'].isin(['SSE','SZSE'])]
    i_cal['S_INFO_EXCHMARKET'] = i_cal['S_INFO_EXCHMARKET'].replace('SSE', 'SH')
    i_cal['S_INFO_EXCHMARKET'] = i_cal['S_INFO_EXCHMARKET'].replace('SZSE', 'SZ')
    i_cal = i_cal.rename(columns={'datadate':'datadate_p1d', 'tdate_1d':'datadate'})
    i_cal = i_cal[['datadate','S_INFO_EXCHMARKET','datadate_p1d']]
    i_cal = i_cal.dropna()
    
    # process datadate
    i_sd = i_sd.rename(columns = {'datadate': 'datadate_p1d'})
    i_sd = i_sd.merge(i_cal, on = ['S_INFO_EXCHMARKET','datadate_p1d'], how = 'left')
        
    i_sd.to_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_fx_hk.parquet")


def prepare_hkuni_sd_v2():
    # v2 is between 2016 and 2020 
    # no short availability / borrow cost, but accurate barra returns
    
    i_sd = get_sql_prod('''select datadate, [T-1d],replace(ric, '.SS', '.SH') as ticker, name,
                       [GSECTOR],[GGROP],[GIND],[GSUBIND],
                       [avgPVadj],[spread],[volatility],[MC_l1d],[FLOAT_l1d],[WIND_V_l1d],V_l1d,PV_l1d,avgPVadj_USD,
                       [SRISK],[BETA],[MOMENTUM],[SIZE],[EARNYILD],[RESVOL],[GROWTH],[BTOP],
                       [LEVERAGE],[LIQUIDTY],[SIZENL],
                       [BarrRet_SRISK_USD-1d],[BarrRet_SRISK_USD+0d], [BarrRet_SRISK_USD+1d],
                       [BarrRet_CLIP
_USD-5d],[BarrRet_CLIP_USD-4d],[BarrRet_CLIP_USD-3d],[BarrRet_CLIP_USD-2d],
                       [BarrRet_CLIP_USD-1d],[BarrRet_CLIP_USD+0d],[BarrRet_CLIP_USD+1d],[BarrRet_CLIP_USD+2d],[BarrRet_CLIP_USD+3d],
                       [BarrRet_CLIP_USD+4d],[BarrRet_CLIP_USD+5d],[BarrRet_CLIP_USD+6d],[BarrRet_CLIP_USD+7d],[BarrRet_CLIP_USD+8d],
                       [BarrRet_CLIP_USD+9d],[BarrRet_CLIP_USD+10d],[BarrRet_CLIP_USD+11d],[BarrRet_CLIP_USD+12d],[BarrRet_CLIP_USD+13d],
                       [BarrRet_CLIP_USD+14d],[BarrRet_CLIP_USD+15d],[BarrRet_CLIP_USD+16d],[BarrRet_CLIP_USD+17d],[BarrRet_CLIP_USD+18d],
                       [BarrRet_CLIP_USD+19d],[BarrRet_CLIP_USD+20d],[BarrRet_CLIP_USD+21d],
                       [RawRet_USD+1d], [RawRet_USD+0d], 
                       fx_l1d as FX_LAST 
                       from [CNDB].[dbo].[Static_Data_HC] 
                       order by ticker, datadate''')
    i_sd = i_sd.drop_duplicates(subset=['ticker','datadate'],keep = 'first')
    
    # calculate V and PV_lqd
    i_sd = i_sd.sort_values(['ticker', 'datadate'])
    #i_sd['V_l1d'] = i_sd.groupby('ticker')['V'].shift()
    #i_sd['PV_l1d'] = i_sd.groupby('ticker')['PV'].shift()
    
    # fetch exchange code
    i_sd['S_INFO_EXCHMARKET'] = i_sd['ticker'].str.split('.').str[-1]
    i_sd = i_sd[i_sd['S_INFO_EXCHMARKET']!='ZK']
    
    # process datadate
    i_sd = i_sd.rename(columns = {'datadate': 'datadate_p1d', 'T-1d':'datadate'})
        
    i_sd.to_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_hk_v2.parquet")


def prepare_hkuni_sd_v2p1():
    # v2p1 is between 2016 and 2021
    # GEM3L
    # no short availability / borrow cost, but accurate barra returns
    
    i_sd = get_sql_prod('''select datadate, [T-1d], ticker, 
                       [GSECTOR],[GGROP],[GIND],[GSUBIND],
                       avgVadj,[avgPVadj],[spread],[cccny_vol_21d] as volatility,[MC_l1d],[FLOAT_l1d],[WIND_V_l1d],V_l1d,PV_l1d,avgPVadj_USD,
                       [SRISK],[BETA],[MOMENTUM],[SIZE],[EARNYILD],[RESVOL],[GROWTH],[BTOP],
                       [LEVERAGE],[LIQUIDTY],[SIZENL],
                       [BarrRet_SRISK_USD-1d],[BarrRet_SRISK_USD+0d], [BarrRet_SRISK_USD+1d],
                       [BarrRet_CLIP_USD-5d],[BarrRet_CLIP_USD-4d],[BarrRet_CLIP_USD-3d],[BarrRet_CLIP_USD-2d],
                       [BarrRet_CLIP_USD-1d],[BarrRet_CLIP_USD+0d],[BarrRet_CLIP_USD+1d],[BarrRet_CLIP_USD+2d],[BarrRet_CLIP_USD+3d],
                       [BarrRet_C
LIP_USD+4d],[BarrRet_CLIP_USD+5d],
                       [RawRet_USD+1d], [RawRet_USD+0d], 
                       fx_l1d as FX_LAST 
                       from [CNDBPROD].[dbo].[Static_Data_HC_GEM3L] 
                       order by ticker, datadate''')
    i_sd = i_sd.drop_duplicates(subset=['ticker','datadate'],keep = 'first')
    
    # ticker
    c_sh = i_sd['ticker'].str[0].isin(['6'])
    c_sz = i_sd['ticker'].str[0].isin(['0','3'])
    i_sd.loc[c_sh,'ticker'] = i_sd.loc[c_sh,'ticker'] + '.SH'
    i_sd.loc[c_sz,'ticker'] = i_sd.loc[c_sz,'ticker'] + '.SZ'
    
    
    # fetch exchange code
    i_sd['S_INFO_EXCHMARKET'] = i_sd['ticker'].str.split('.').str[-1]
    i_sd = i_sd[i_sd['S_INFO_EXCHMARKET']!='ZK']
    
    # process datadate
    i_sd = i_sd.rename(columns = {'datadate': 'datadate_p1d', 'T-1d':'datadate'})
        
    i_sd.to_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_hk_v2p1.parquet")
    

def prepare_hkuni_sd_v2p2():
    # v2p2 is between 2016 and 2021
    # GEMTR
    # no short availability / borrow cost, but accurate barra returns
    
    i_sd = get_sql_prod('''select datadate, [T-1d], ticker, 
                       [GSECTOR],[GGROP],[GIND],[GSUBIND],
                       [avgPVadj],[spread],[cccny_vol_21d] as volatility,[MC_l1d],[FLOAT_l1d],[WIND_V_l1d],V_l1d,PV_l1d,avgPVadj_USD,
                       [SRISK],[BETA],[MOMENTUM],[SIZE],[EARNYILD],[RESVOL],[GROWTH],[BTOP],
                       [LEVERAGE],[LIQUIDTY],
                       [BarrRet_SRISK_USD-1d],[BarrRet_SRISK_USD+0d], [BarrRet_SRISK_USD+1d],
                       [BarrRet_CLIP_USD-5d],[BarrRet_CLIP_USD-4d],[BarrRet_CLIP_USD-3d],[BarrRet_CLIP_USD-2d],
                       [BarrRet_CLIP_USD-1d],[BarrRet_CLIP_USD+0d],[BarrRet_CLIP_USD+1d],[BarrRet_CLIP_USD+2d],[BarrRet_CLIP_USD+3d],
                       [BarrRet_CLIP_USD+4d],[BarrRet_CLIP_USD+5d],
                       [RawRet_USD+1d], [RawRet_USD+0d], 
                       fx_l1d as FX_LAST 
                       from [CNDB].[dbo].[Static_Data_HC_GEMTR] 
                       order by ticker, datadate''')
    i_sd = i_sd.drop_duplicates(subset=['ticker','datadate'],keep = 'first')
    
    # ticker
    c_sh = i_sd['ticker'].str[0].isin(['6'])
    c_sz = i_sd['ticker'].str[0].isin(['0','3'])
    i_sd.loc[c_sh,'ticker'] = i_sd.loc[c_sh,'ticker'] + '.SH'
    i_sd.loc[c_sz,'ticker'] = i_sd.loc[c_sz,'ticker'] + '.SZ'
    
    
    # fetch exchange code
    i_sd['S_INFO_EXCHMARKET'] = i_sd['t
icker'].str.split('.').str[-1]
    i_sd = i_sd[i_sd['S_INFO_EXCHMARKET']!='ZK']
    
    # process datadate
    i_sd = i_sd.rename(columns = {'datadate': 'datadate_p1d', 'T-1d':'datadate'})
        
    i_sd.to_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_hk_v2p2.parquet")
    
    
def prepare_hkuni_sd_v2p3():
    # v2p3 is between 2016 and 2021
    # GEMTR
    # no short availability / borrow cost, but accurate barra returns
    
    i_sd = get_sql_prod('''select datadate, [T-1d], ticker, 
                       [GSECTOR],[GGROP],[GIND],[GSUBIND],
                       [avgPVadj],[spread],[cccny_vol_21d] as volatility,[MC_l1d],[FLOAT_l1d],[WIND_V_l1d],V_l1d,PV_l1d,avgPVadj_USD,
                       [SRISK],[BETA],[MOMENTUM],[SIZE],[EARNYILD],[RESVOL],[GROWTH],[BTOP],
                       [LEVERAGE],[LIQUIDTY],
                       [BarrRet_SRISK_USD-1d],[BarrRet_SRISK_USD+0d], [BarrRet_SRISK_USD+1d],
                       [BarrRet_CLIP_USD-5d],[BarrRet_CLIP_USD-4d],[BarrRet_CLIP_USD-3d],[BarrRet_CLIP_USD-2d],
                       [BarrRet_CLIP_USD-1d],[BarrRet_CLIP_USD+0d],[BarrRet_CLIP_USD+1d],[BarrRet_CLIP_USD+2d],[BarrRet_CLIP_USD+3d],
                       [BarrRet_CLIP_USD+4d],[BarrRet_CLIP_USD+5d],
                       [RawRet_USD+1d], [RawRet_USD+0d], 
                       fx_l1d as FX_LAST 
                       from [CNDB].[dbo].[Static_Data_HC_GEM3S] 
                       order by ticker, datadate''')
    i_sd = i_sd.drop_duplicates(subset=['ticker','datadate'],keep = 'first')
    
    # ticker
    c_sh = i_sd['ticker'].str[0].isin(['6'])
    c_sz = i_sd['ticker'].str[0].isin(['0','3'])
    i_sd.loc[c_sh,'ticker'] = i_sd.loc[c_sh,'ticker'] + '.SH'
    i_sd.loc[c_sz,'ticker'] = i_sd.loc[c_sz,'ticker'] + '.SZ'
    
    
    # fetch exchange code
    i_sd['S_INFO_EXCHMARKET'] = i_sd['ticker'].str.split('.').str[-1]
    i_sd = i_sd[i_sd['S_INFO_EXCHMARKET']!='ZK']
    
    # process datadate
    i_sd = i_sd.rename(columns = {'datadate': 'datadate_p1d', 'T-1d':'datadate'})
        
    i_sd.to_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_hk_v2p3.parquet")



def prepare_hkuni_sd_v3():
    # v3 is between 2018.3 and 2020.11 where we can estimate short quota and cost
    i_sd = get_sql_prod('''select datadate, replace(ric, '.SS', '.SH') as ticker, name,
                       [GSECTOR],[GGROP],[GIND],[GSUBIND],
                       [avgPVadj],[avgPVadj_USD],[spread],[volatility],[MC_l1d],[FLOAT_l1d],
[WIND_V_l1d],V_l1d,PV_l1d,
                       [SRISK],[BETA],[MOMENTUM],[SIZE],[EARNYILD],[RESVOL],[GROWTH],[BTOP],
                       [LEVERAGE],[LIQUIDTY],[SIZENL], ClosePrice_l1d, 
                       [BarrRet_SRISK_USD-5d],[BarrRet_SRISK_USD-4d],[BarrRet_SRISK_USD-3d],[BarrRet_SRISK_USD-2d],[BarrRet_SRISK_USD-1d],
                       [BarrRet_SRISK_USD+0d], [BarrRet_SRISK_USD+1d],
                       [BarrRet_CLIP_USD-1d],[BarrRet_CLIP_USD+0d],[BarrRet_CLIP_USD+1d],[BarrRet_CLIP_USD+2d],[BarrRet_CLIP_USD+3d],
                       [BarrRet_CLIP_USD+4d],[BarrRet_CLIP_USD+5d],[BarrRet_CLIP_USD+6d],[BarrRet_CLIP_USD+7d],[BarrRet_CLIP_USD+8d],
                       [BarrRet_CLIP_USD+9d],[BarrRet_CLIP_USD+10d],[BarrRet_CLIP_USD+11d],[BarrRet_CLIP_USD+12d],[BarrRet_CLIP_USD+13d],
                       [BarrRet_CLIP_USD+14d],[BarrRet_CLIP_USD+15d],[BarrRet_CLIP_USD+16d],[BarrRet_CLIP_USD+17d],[BarrRet_CLIP_USD+18d],
                       [BarrRet_CLIP_USD+19d],[BarrRet_CLIP_USD+20d],[BarrRet_CLIP_USD+21d],
                       [RawRet_USD+1d], [RawRet_USD+0d], 
                       [Avail_Amount_sum], [Avail_Amount_max], 
                       [Rate_mean], [Rate_median], [Rate_max], [Rate_min], [wRate],
                       [FX_l1d] 
                       from [CNDB].[dbo].[Static_Data_HC_bc] 
                       order by ticker, datadate''')
    i_sd = i_sd.drop_duplicates(subset=['ticker','datadate'],keep = 'first')
    
    # calculate V and PV_lqd
    i_sd = i_sd.sort_values(['ticker', 'datadate'])
    #i_sd['V_l1d'] = i_sd.groupby('ticker')['V'].shift()
    #i_sd['PV_l1d'] = i_sd.groupby('ticker')['PV'].shift()
    
    # fetch exchange code
    i_sd['S_INFO_EXCHMARKET'] = i_sd['ticker'].str.split('.').str[-1]
    i_sd = i_sd[i_sd['S_INFO_EXCHMARKET']!='ZK']
    
    # get trading calendar 
    i_cal = get_wind_trade_cal()
    i_cal = i_cal[i_cal['S_INFO_EXCHMARKET'].isin(['SSE','SZSE'])]
    i_cal['S_INFO_EXCHMARKET'] = i_cal['S_INFO_EXCHMARKET'].replace('SSE', 'SH')
    i_cal['S_INFO_EXCHMARKET'] = i_cal['S_INFO_EXCHMARKET'].replace('SZSE', 'SZ')
    i_cal = i_cal.rename(columns={'datadate':'datadate_p1d', 'tdate_1d':'datadate'})
    i_cal = i_cal[['datadate','S_INFO_EXCHMARKET','datadate_p1d']]
    i_cal = i_cal.dropna()
    
    # process datadate
    i_sd = i_sd.rename(columns = {'datadate': 'datadate_p1d'})
    i_sd = i_sd.merge(i_cal, on = ['S_INFO_EXCHMARKET','datadate_p1d'], how = 'left')
        
    i_sd.to_parq
uet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_hk_v3.parquet")



def prepare_2kuni_sd():
    
    # get data    
    i_sd = get_sql_prod('''
                        select datadate, [T-1d], ticker, 
                               [GSECTOR],[GGROP],[GIND],[GSUBIND],
                               hedge, isinHC, cn_index, 
                               avgVadj,[avgPVadj],[spread],[cccny_vol_21d] as volatility,[MC_l1d],[FLOAT_l1d],V_l1d,PV_l1d,avgPVadj_USD,
                               [SRISK],[BETA],[MOMENTUM],[SIZE],[EARNYILD],[RESVOL],[GROWTH],[BTOP],[LEVERAGE],[LIQUIDTY],[SIZENL],
                               [BarrRet_SRISK_USD-1d],[BarrRet_SRISK_USD+0d], [BarrRet_SRISK_USD+1d],
                               [BarrRet_CLIP_USD-5d],[BarrRet_CLIP_USD-4d],[BarrRet_CLIP_USD-3d],[BarrRet_CLIP_USD-2d],
                               [BarrRet_CLIP_USD-1d],[BarrRet_CLIP_USD+0d],[BarrRet_CLIP_USD+1d],[BarrRet_CLIP_USD+2d],[BarrRet_CLIP_USD+3d],
                               [BarrRet_CLIP_USD+4d],[BarrRet_CLIP_USD+5d],
                               [HedgeRet_CSI500_USD-5d], [HedgeRet_CSI500_USD-4d], [HedgeRet_CSI500_USD-3d], [HedgeRet_CSI500_USD-2d],
                               [HedgeRet_CSI500_USD-1d], [HedgeRet_CSI500_USD+0d], [HedgeRet_CSI500_USD+1d], [HedgeRet_CSI500_USD+2d],
                               [HedgeRet_CSI500_USD+3d], [HedgeRet_CSI500_USD+4d], [HedgeRet_CSI500_USD+5d], 
                               [HedgeRet_CSI300_USD-5d], [HedgeRet_CSI300_USD-4d], [HedgeRet_CSI300_USD-3d], [HedgeRet_CSI300_USD-2d],
                               [HedgeRet_CSI300_USD-1d], [HedgeRet_CSI300_USD+0d], [HedgeRet_CSI300_USD+1d], [HedgeRet_CSI300_USD+2d],
                               [HedgeRet_CSI300_USD+3d], [HedgeRet_CSI300_USD+4d], [HedgeRet_CSI300_USD+5d], 
                               [RawRet_USD-1d], [RawRet_USD+0d], [RawRet_USD+1d],
                               fx_l1d as FX_LAST 
                        from [CNDBPROD].[dbo].[Static_Data_T2000_GEM3L] 
                        order by ticker, datadate ''')
    
    i_sd = i_sd.drop_duplicates(subset=['ticker','datadate'],keep = 'first')
    
    # ticker
    c_sh = i_sd['ticker'].str[0].isin(['6'])
    c_sz = i_sd['ticker'].str[0].isin(['0','3'])
    i_sd.loc[c_sh,'ticker'] = i_sd.loc[c_sh,'ticker'] + '.SH'
    i_sd.loc[c_sz,'ticker'] = i_sd.loc[c_sz,'ticker'] + '.SZ'
        
    # process datadate
    i_sd = i_sd.rename(columns = {'datadate': 'datadate_p1d', 'T-1d':'datadate'})
     
   
    i_sd.to_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_t2000_v2p1.parquet")
    
    
    
def prepare_3kuni_sd():

    # get data    
    i_sd = get_sql_prod('''
                        select datadate, [T-1d], ticker, 
                               [GSECTOR],[GGROP],[GIND],[GSUBIND],
                               hedge, isinHC, cn_index, 
                               avgVadj,[avgPVadj],[spread],[cccny_vol_21d] as volatility,[MC_l1d],[FLOAT_l1d],V_l1d,PV_l1d,avgPVadj_USD,
                               [SRISK],[BETA],[MOMENTUM],[SIZE],[EARNYILD],[RESVOL],[GROWTH],[BTOP],[LEVERAGE],[LIQUIDTY],[SIZENL],
                               [BarrRet_SRISK_USD-1d],[BarrRet_SRISK_USD+0d], [BarrRet_SRISK_USD+1d],
                               [BarrRet_CLIP_USD-5d],[BarrRet_CLIP_USD-4d],[BarrRet_CLIP_USD-3d],[BarrRet_CLIP_USD-2d],
                               [BarrRet_CLIP_USD-1d],[BarrRet_CLIP_USD+0d],[BarrRet_CLIP_USD+1d],[BarrRet_CLIP_USD+2d],[BarrRet_CLIP_USD+3d],
                               [BarrRet_CLIP_USD+4d],[BarrRet_CLIP_USD+5d],
                               [RawRet_USD-1d], [RawRet_USD+0d], [RawRet_USD+1d],
                               fx_l1d as FX_LAST 
                        from [CNDBPROD].[dbo].[Static_Data_T3000_GEM3L] 
                        order by ticker, datadate ''')    
    
    i_sd = i_sd.drop_duplicates(subset=['ticker','datadate'],keep = 'first')
    
    # ticker
    c_sh = i_sd['ticker'].str[0].isin(['6'])
    c_sz = i_sd['ticker'].str[0].isin(['0','3'])
    i_sd.loc[c_sh,'ticker'] = i_sd.loc[c_sh,'ticker'] + '.SH'
    i_sd.loc[c_sz,'ticker'] = i_sd.loc[c_sz,'ticker'] + '.SZ'
        
    # process datadate
    i_sd = i_sd.rename(columns = {'datadate': 'datadate_p1d', 'T-1d':'datadate'})
        
    i_sd.to_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_t3000_v2p1.parquet")
    

def get_china_sd(str_type = 'backtest', fx_adj = False):    
    if str_type == 'backtest':
        print ('loading sd ... ', end='')
        tic()
        if fx_adj == False:
            i_sd = pd.read_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data.parquet")
        elif fx_adj == True:
            i_sd = pd.read_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_fx.parquet")
               
        # fx-adj return
        i_fx = get_wind_fx()
        i_fx = i_fx.rename(columns={'DataDate': 'datadate'})
        i_fx['CNYUSD_apprec'] = i_fx['CNYUSD'].divide(i_fx['CNYUSD_l1d'])
        i_f
x = i_fx[['datadate','CNYUSD_apprec']]
        i_full_date = pd.DataFrame(pd.date_range(start=i_fx['datadate'].min(),end=i_fx['datadate'].max()), 
                                   columns = ['datadate'])
        i_fx = i_full_date.merge(i_fx, on = ['datadate'], how = 'left')
        i_fx['CNYUSD_apprec'] = i_fx['CNYUSD_apprec'].fillna(method = 'ffill')
        
        i_sd = i_sd.merge(i_fx, on = ['datadate'], how = 'left')
        i_sd['fxRet_SRISK+1d'] = (i_sd['BarrRet_SRISK+1d']+1).divide(i_sd['CNYUSD_apprec'])-1
        i_sd['fxRet_CLIP+1d'] = (i_sd['BarrRet_CLIP+1d']+1).divide(i_sd['CNYUSD_apprec'])-1
        
        # hk connect flag
        i_tk_uni = get_sql('''(select S_INFO_WINDCODE as ticker, entry_dt, remove_dt from [WIND].[dbo].[SZSCMEMBERS]) 
                       UNION
                       (select S_INFO_WINDCODE as ticker, entry_dt, remove_dt from [WIND].[dbo].[SHSCMEMBERS]) ''')
        i_tk_uni['entry_dt'] = pd.to_datetime(i_tk_uni['entry_dt'], format='%Y%m%d')
        i_tk_uni.loc[i_tk_uni['remove_dt'].isnull(), 'remove_dt'] = np.nan
        i_tk_uni['remove_dt'] = pd.to_datetime(i_tk_uni['remove_dt'], format='%Y%m%d')
        
        i_sd = i_sd.merge(i_tk_uni, on = ['ticker'], how = 'left')
    
        c_isin = (i_sd['datadate'] >= i_sd['entry_dt']) & ((i_sd['datadate'] <= i_sd['remove_dt'])|i_sd['remove_dt'].isnull())
        i_sd.loc[c_isin,'isin_hk_uni'] = 1
        i_sd = i_sd.rename(columns={'entry_dt':'hk_uni_entry','remove_dt':'hk_uni_remove'})
        
        i_sd = i_sd.sort_values(['ticker','datadate','isin_hk_uni'])
        i_sd = i_sd.drop_duplicates(subset=['ticker','datadate'], keep = 'first')
        
        toc()
        return i_sd
    else:
        if fx_adj == False:
            i_sd = pd.read_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data.parquet")
        elif fx_adj == True:
            i_sd = pd.read_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_fx.parquet")
        return i_sd


def get_china_ss_sd():
    
    i_sd_ss = yu.get_sql('''select * from [CNDBPROD].[dbo].[Static_Data_SS_GEM3L] ''')
    i_sd_ss = i_sd_ss.rename(columns = {'DataDate':'datadate_p1d', 'T-1d':'datadate', 'Ticker':'ticker', 'gk_vol_21d':'volatility'})
    
    c_sh = i_sd_ss['ticker'].str[0].isin(['6'])
    c_sz = i_sd_ss['ticker'].str[0].isin(['0', '3'])
    i_sd_ss.loc[c_sh, 'ticker'] = i_sd_ss.loc[c_sh, 'ticker'] + '.SH'
    i_sd_ss.loc[c_sz, 'ticker'] = i_sd_ss.loc[c_sz, 'ticker'] + '.SZ'
    
    
i_sd_ss = i_sd_ss.sort_values('datadate')
    
    return i_sd_ss

    

def get_ashare_hk_sd(str_type = 'backtest'):    
    if str_type == 'backtest':
        print ('loading sd ... ', end='')
        tic()
        i_sd = pd.read_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_fx_hk.parquet")
        
        # hk connect flag
        i_tk_uni = get_sql('''(select S_INFO_WINDCODE as ticker, entry_dt, remove_dt from [WIND].[dbo].[SZSCMEMBERS]) 
                       UNION
                       (select S_INFO_WINDCODE as ticker, entry_dt, remove_dt from [WIND].[dbo].[SHSCMEMBERS]) ''')
        i_tk_uni['entry_dt'] = pd.to_datetime(i_tk_uni['entry_dt'], format='%Y%m%d')
        i_tk_uni.loc[i_tk_uni['remove_dt'].isnull(), 'remove_dt'] = np.nan
        i_tk_uni['remove_dt'] = pd.to_datetime(i_tk_uni['remove_dt'], format='%Y%m%d')
        
        i_sd = i_sd.merge(i_tk_uni, on = ['ticker'], how = 'left')
    
        c_isin = (i_sd['datadate'] >= i_sd['entry_dt']) & ((i_sd['datadate'] <= i_sd['remove_dt'])|i_sd['remove_dt'].isnull())
        i_sd.loc[c_isin,'isin_hk_uni'] = 1
        i_sd = i_sd.rename(columns={'entry_dt':'hk_uni_entry','remove_dt':'hk_uni_remove'})
        
        i_sd = i_sd.sort_values(['ticker','datadate','isin_hk_uni'])
        i_sd = i_sd.drop_duplicates(subset=['ticker','datadate'], keep = 'first')
        
        toc()
        return i_sd
    else:
        i_sd = pd.read_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_fx_hk.parquet")
        return i_sd



def get_ashare_hk_sd_v2(str_type = 'backtest', version='2'):
    # v2 is between 2016 and 2020 where we have hk-uni residual return 
    # v2p1 is between 2016 and 2021
    if str_type == 'backtest':
        print ('loading sd ... ', end='')
        tic()
        i_sd = pd.read_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_hk_v{0}.parquet".format(version))
    
        
        # hk connect flag
        i_tk_uni = get_sql('''(select S_INFO_WINDCODE as ticker, entry_dt, remove_dt from [WIND].[dbo].[SZSCMEMBERS]) 
                       UNION
                       (select S_INFO_WINDCODE as ticker, entry_dt, remove_dt from [WIND].[dbo].[SHSCMEMBERS]) ''')
        i_tk_uni['entry_dt'] = pd.to_datetime(i_tk_uni['entry_dt'], format='%Y%m%d')
        i_tk_uni.loc[i_tk_uni['remove_dt'].isnull(), 'remove_dt'] = np.nan
        i_tk_uni['remove_dt'] = pd.to_datetime(i_tk_uni['remove_dt'], format='%Y%m%d')
        
        i_sd = i_sd.merge(i_tk_u
ni, on = ['ticker'], how = 'left')
    
        c_isin = (i_sd['datadate'] >= i_sd['entry_dt']) & ((i_sd['datadate'] <= i_sd['remove_dt'])|i_sd['remove_dt'].isnull())
        i_sd.loc[c_isin,'isin_hk_uni'] = 1
        i_sd = i_sd.rename(columns={'entry_dt':'hk_uni_entry','remove_dt':'hk_uni_remove'})
        
        i_sd = i_sd.sort_values(['ticker','datadate','isin_hk_uni'])
        i_sd = i_sd.drop_duplicates(subset=['ticker','datadate'], keep = 'first')
        
        # get csi300 membership from prod tables
        i_mem_csi300 = get_sql('''select date_of_portfolio as datadate_p1d,
                               replace(primary_ric_company_level,'.SS','.SH') as ticker 
                               from cndbprod.dbo.csi_300_cons''')
        i_mem_csi300['csi300_flag'] = 1
        i_sd = i_sd.merge(i_mem_csi300, on = ['ticker', 'datadate_p1d'], how = 'left')
        

        toc()
        return i_sd
    else:
        i_sd = pd.read_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_hk_v{0}.parquet".format(version))
        return i_sd

    


def get_ashare_hk_sd_v3(str_type = 'backtest'):
    # v3 is between 2018.3 and 2020.11 where we can estimate short quota and cost
    if str_type == 'backtest':
        print ('loading sd ... ', end='')
        tic()
        i_sd = pd.read_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_hk_v3.parquet")
        
        # hk connect flag
        i_tk_uni = get_sql('''(select S_INFO_WINDCODE as ticker, entry_dt, remove_dt from [WIND].[dbo].[SZSCMEMBERS]) 
                       UNION
                       (select S_INFO_WINDCODE as ticker, entry_dt, remove_dt from [WIND].[dbo].[SHSCMEMBERS]) ''')
        i_tk_uni['entry_dt'] = pd.to_datetime(i_tk_uni['entry_dt'], format='%Y%m%d')
        i_tk_uni.loc[i_tk_uni['remove_dt'].isnull(), 'remove_dt'] = np.nan
        i_tk_uni['remove_dt'] = pd.to_datetime(i_tk_uni['remove_dt'], format='%Y%m%d')
        
        i_sd = i_sd.merge(i_tk_uni, on = ['ticker'], how = 'left')
    
        c_isin = (i_sd['datadate'] >= i_sd['entry_dt']) & ((i_sd['datadate'] <= i_sd['remove_dt'])|i_sd['remove_dt'].isnull())
        i_sd.loc[c_isin,'isin_hk_uni'] = 1
        i_sd = i_sd.rename(columns={'entry_dt':'hk_uni_entry','remove_dt':'hk_uni_remove'})
        
        i_sd = i_sd.sort_values(['ticker','datadate','isin_hk_uni'])
        i_sd = i_sd.drop_duplicates(subset=['ticker','datadate'], keep = 'first')
        
        toc()
        return i_sd
    else:
   
     i_sd = pd.read_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_hk_v3.parquet")
        return i_sd

def get_ashare_t1800_sd():
    
    tdata = pd.read_parquet('S:/TZ/China Data Hunt/cache/util_prepare_sd_cn_1800.parquet')
    tdata = tdata.rename(columns = {'T-1d': 'datadate', 'DataDate': 'datadate_p1d'})
    
    c_sh = tdata['Ticker'].str[0].isin(['6'])
    c_sz = tdata['Ticker'].str[0].isin(['0','3'])
    tdata.loc[c_sh, 'ticker'] = tdata.loc[c_sh, 'Ticker'] + '.SH'
    tdata.loc[c_sz, 'ticker'] = tdata.loc[c_sz, 'Ticker'] + '.SZ'
    
    tdata = tdata.drop(columns = 'Ticker')
    
    return tdata
    
def get_ashare_t2000_sd():
    # This is T2000 universe static data
    # between 2016 and 2021
    
    return pd.read_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_t2000_v2p1.parquet")


def get_ashare_t3000_sd():
    # This is T3000 universe static data
    # between 2016 and 2021
    
    return pd.read_parquet(r"S:\TZ\China Data Hunt\cache\pWIND_util_static_data_t3000_v2p1.parquet")


    
