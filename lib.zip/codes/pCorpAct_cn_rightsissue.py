﻿#$%^&* pCorpAct_cn_rightsissue.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu May 12 13:21:21 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime




### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])





### rights issue

i_right = yu.get_sql('''select * from wind.dbo.ASHARERIGHTISSUE ''')
i_right = i_right.rename(columns = {'S_INFO_WINDCODE': 'ticker'})
i_right = i_right[i_right['S_RIGHTSISSUE_ANNCEDATE'].notnull()]
i_right = i_right[i_right['S_RIGHTSISSUE_EXDIVIDENDDATE'].notnull()]
i_right['S_RIGHTSISSUE_ANNCEDATE'] = pd.to_datetime(i_right['S_RIGHTSISSUE_ANNCEDATE'], format='%Y%m%d')
i_right['S_RIGHTSISSUE_EXDIVIDENDDATE'] = pd.to_datetime(i_right['S_RIGHTSISSUE_EXDIVIDENDDATE'], format='%Y%m%d')

i_right = i_right[i_right['S_RIGHTSISSUE_ANNCEDATE']>='2016-01-01']
i_right['S_RIGHTSISSUE_APPROVEDDATE'] = pd.to_datetime(i_right['S_RIGHTSISSUE_APPROVEDDATE'], format='%Y%m%d')
i_right['S_RIGHTSISSUE_PREPLANDATE'] = pd.to_datetime(i_right['S_RIGHTSISSUE_PREPLANDATE'], format='%Y%m%d')
i_right = i_right.sort_values('S_RIGHTSISSUE_APPROVEDDATE')

i_px = yu.get_sql('''select trade_dt as S_RIGHTSISSUE_APPROVEDDATE, s_info_windcode as ticker, s_dq_close
                  from wind.dbo.ASHAREEODPRICES
                  where s_info_windcode in ('{0}') '''.format( "','".join(i_right['ticker'].unique().tolist()))) 
i_px['S_RIGHTSISSUE_APPROVEDDATE']=pd.to_datetime(i_px['S_RIGHTSISSUE_APPROVEDDATE'],format='%Y%m%d')
i_px = i_px.sort_values('S_RIGHTSISSUE_APPROVEDDATE')

i_right = pd.merge_asof(i_right, i_px, by = 'ticker', on='S_RIGHTSISSUE_APPROVEDDATE')
i_right['discount'] = i_right['S_RIGHTSISSUE_PRICE'].divide(i_right['s_dq_close'])

o_right = []
for dt in pd.date_range(start = '2017-01-01', end = '2020-12-31'):
    #print(dt.strftime('%Y%m%d')[2:], end = ' ')
    t_right = i_right[(i_right['S_RIGHTSISSUE_PREPLANDATE']<=dt)&(i_right['S_RIGHTSISSUE_EXDIVIDENDDATE']>dt-pd.to_timedelta('1 day'))]
    t_right['flag_preplan'] = 1
    t_right['flag_approved'] = np.nan
    t_right.loc[(t_right['S_RIGHTSISSUE_APPROVEDDATE']<=dt)&(t_right['S_RIGHTSISSUE_EXDIVIDENDDATE']>dt-pd.to_timedelta('1 day')), 'flag_approved']=1
    t_right['datadate']=dt
    t_right = t_right.drop_duplicates(subset='ticker', keep = 'last')
    o_right.append(t_right[['ticker','datadate','flag_preplan','flag_approved']])
o_right = pd.concat(o_right, axis=0)





### combin
e (配股)

#icom = pd.merge_asof(i_sd, o_right, by = 'ticker', on = 'datadate', tolerance = pd.to_timedelta('3 days'))
icom = i_sd.merge(o_right, on = ['ticker','datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['test'] = np.nan
icom.loc[icom['flag_preplan']==1, 'test'] = -1

icom['test2'] = np.nan
icom.loc[(icom['flag_preplan']==1)&(icom['flag_preplan'].shift().isnull()), 'test2'] = -1

icom['test3'] = np.nan
icom.loc[(icom['flag_approved']==1)&(icom['flag_approved'].shift().isnull()), 'test3'] = -1
icom['test3'] = icom.groupby('ticker')['test3'].ffill(limit=1)

yu.create_cn_decay(icom, 'test') # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['test','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test','BarrRet_CLIP_USD+1d', static_data = i_sd) # not working

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['test2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test2','BarrRet_CLIP_USD+1d', static_data = i_sd) # only fwdlk 2day: working

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['test3','BarrRet_CLIP_USD-1d']).drop_duplicates(subset=['ticker','datadate']),
            'test3','BarrRet_CLIP_USD-1d', static_data = i_sd) # not working


t1=icom[icom.ticker=='600919.SH']
t1=icom[icom.ticker=='000977.SZ']
t1 = o_1.groupby('ticker')['pnl_ac'].sum().reset_index()
t1 = t1.merge(i_right[['ticker','discount']],on='ticker',how='left')
t1 = i_xd_rightsissue[i_xd_rightsissue['ticker']=='002466.SZ']




### combine (配股2)

i_right2 = yu.get_sql('''select * from wind.dbo.ASHARERIGHTISSUE ''')
i_right2 = i_right2.rename(columns = {'S_INFO_WINDCODE': 'ticker'})

# guquan dengji ri

i_right2_reg = i_right2[['ticker','S_RIGHTSISSUE_REGDATESHAREB']]
i_right2_reg = i_right2_reg.dropna()
i_right2_reg['S_RIGHTSISSUE_REGDATESHAREB']=pd.to_datetime(i_right2_reg['S_RIGHTSISSUE_REGDATESHAREB'],format='%Y%m%d')
i_right2_reg = i_right2_reg.sort_values('S_RIGHTSISSUE_REGDATESHAREB')
icom = pd.merge_asof(i_sd, i_right2_reg, by = 'ticker', left_on='datadate',right_on='S_RIGHTSISSUE_REGDATESHAREB')
icom = icom.sort_values(['ticker','datadate'])
icom['flag'] = np.nan
c1=(icom['ticker']==icom['ticker'].shift())&(icom['S_RIGHTSISSUE_REGDATESHAREB'].notnull())&(icom['S_RIGHTSISSUE_REGDATESHAREB']!=icom['S_RIGHTSISSUE_REGDATESHAREB'].shift())
icom.loc[c1, 'flag'] = -1

yu.cre
ate_cn_decay(icom, 'flag')

# annce date


i_right2_ann = i_right2[['ticker','S_RIGHTSISSUE_ANNCEDATE','S_RIGHTSISSUE_REGDATESHAREB']]
i_right2_ann = i_right2_ann.dropna()
i_right2_ann['S_RIGHTSISSUE_ANNCEDATE']=pd.to_datetime(i_right2_ann['S_RIGHTSISSUE_ANNCEDATE'],format='%Y%m%d')
i_right2_ann['S_RIGHTSISSUE_REGDATESHAREB']=pd.to_datetime(i_right2_ann['S_RIGHTSISSUE_REGDATESHAREB'],format='%Y%m%d')
i_right2_ann = i_right2_ann.sort_values('S_RIGHTSISSUE_ANNCEDATE')
icom = pd.merge_asof(i_sd, i_right2_ann, by = 'ticker', left_on='datadate',right_on='S_RIGHTSISSUE_ANNCEDATE')
icom = icom.sort_values(['ticker','datadate'])
icom['flag'] = np.nan
c1=(icom['ticker']==icom['ticker'].shift())&(icom['S_RIGHTSISSUE_ANNCEDATE'].notnull())&(icom['S_RIGHTSISSUE_ANNCEDATE']!=icom['S_RIGHTSISSUE_ANNCEDATE'].shift())
icom.loc[c1, 'flag'] = -1
icom.loc[icom['S_RIGHTSISSUE_REGDATESHAREB']==icom['datadate'], 'flag'] = 0 
icom['flag'] = icom.groupby('ticker')['flag'].ffill(limit=5)

yu.create_cn_decay(icom, 'flag')

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['flag','BarrRet_CLIP_USD-1d']).drop_duplicates(subset=['ticker','datadate']),
            'flag','BarrRet_CLIP_USD-1d', static_data = i_sd) #5.4 / 4.87

