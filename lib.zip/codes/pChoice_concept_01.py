﻿#$%^&* pChoice_concept_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 15 20:57:25 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw




### sd


i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['ticker', 'datadate'])
i_sd['V_t30d'] = i_sd.groupby('ticker').rolling(30)['V_l1d'].mean().values
i_sd['bret_t20d'] = i_sd.groupby('ticker').rolling(20)['BarrRet_CLIP_USD-1d'].mean().values
i_sd['bret_t63d'] = i_sd.groupby('ticker').rolling(63)['BarrRet_CLIP_USD-1d'].mean().values
i_sd['bret_t126d'] = i_sd.groupby('ticker').rolling(126)['BarrRet_CLIP_USD-1d'].mean().values
i_sd['MOMENTUM_1d'] = i_sd.groupby('ticker')['MOMENTUM'].shift()


i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d','V_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','csi300_flag']]

i_sd_map_300 =i_sd_map[i_sd_map['csi300_flag']==1]

### get data 

# list of concepts
i_concept_list = yu.get_sql_choice('''select * from [Choice].[dbo].[v_CDSY_KP_PUBLISHINDEX] ''')
i_concept_list_s = i_concept_list[['PUBLISHCODE','PUBLISHNAME','ENDDATE','STARTDATE','EITIME','EUTIME','EISDEL']]

# the reason why a ticker is assigned to a concept
i_concept_reason = yu.get_sql_choice('''select * from [Choice].[dbo].[v_CDSY_KP_PUBLISHREASON] ''')

# parent-child-concept relation
i_concept_relation = yu.get_sql_choice('''select * from [Choice].[dbo].[v_CDSY_KP_PUBLISHRELATION] ''')

# concept-ticker relation 2
i_concept_relation2 = yu.get_sql_choice('''select * from [Choice].[dbo].[v_CDSY_KP_PUBLISHSTOCK] ''')
i_concept_relation2 = i_concept_relation2[['PUBLISHCODE','MSECUCODE','SECURITYNAME','EID','EITIME','EUTIME','EISDEL']]

i_concept_relation3 = i_concept_relation2.merge(i_concept_list_s, on = ['PUBLISHCODE'], how = 'left', suffixes=['','cpt'])
i_concept_relation4 = i_concept_relation3[i_concept_relation3['PUBLISHNAME'].notnull()]
i_concept_relation4['EIDATE'] = pd.to_datetime(i_concept_relation4['EITIME'].dt.date)


# loop: concept count 

o_concept_cnt = []
for dt in pd.date_range(start = '2016-01-01', end = '2019-12-31'):
    print(dt.strftime('%Y%m%d'),end='')
    
    t_concept = i_concept_relation4[i_concept_relation4['EIDATE']<=dt]
    t_concept_cnt = t_concept.groupby('MSECUCODE')['PUBLISHCODE'].nunique().reset_index()
    t
_concept_cnt = t_concept_cnt.rename(columns={'MSECUCODE':'ticker'})
    t_concept_cnt['datadate'] = dt
    
    o_concept_cnt.append(t_concept_cnt)
    
df_concept = pd.concat(o_concept_cnt, axis = 0)


# loop v2

o_concept_tk_map = []
for dt in pd.date_range(start = '2016-01-01', end = '2020-12-31'):   
    print (dt.strftime('%Y%m%d'), end = ' ')
    t_concept = i_concept_relation4[i_concept_relation4['EIDATE']<=dt]
    t_concept = t_concept.rename(columns={'MSECUCODE':'ticker'})
    t_concept['datadate'] = dt
    t_concept = t_concept[['ticker','datadate','PUBLISHCODE']]
    o_concept_tk_map.append(t_concept)
o_concept_tk_map = pd.concat(o_concept_tk_map, axis = 0)

o_concept_mom_v2 = []
for cpt in o_concept_tk_map['PUBLISHCODE'].unique().tolist():
    print(cpt, end = ' ')
    t_concept = o_concept_tk_map[o_concept_tk_map['PUBLISHCODE']==cpt]
    t_sd = i_sd.merge(t_concept, on = ['datadate', 'ticker'], how = 'inner')
    t_sd['MOMENTUM_rk'] = t_sd.groupby('datadate')['MOMENTUM_1d'].apply(yu.uniformed_rank).values
    t_sd['bret126_rk'] = t_sd.groupby('datadate')['bret_t126d'].apply(yu.uniformed_rank).values
    t_sd['bret63_rk'] = t_sd.groupby('datadate')['bret_t63d'].apply(yu.uniformed_rank).values
    t_sd = t_sd[['ticker','datadate','PUBLISHCODE','MOMENTUM_rk','bret126_rk','bret63_rk']]
    o_concept_mom_v2.append(t_sd)    
o_concept_mom_v2 = pd.concat(o_concept_mom_v2, axis = 0)
o_concept_mom_v2.to_parquet(r'S:\Data\China Data Hunt\cache\pChoice_concept_01_d.parquet')

o_concept_mom_v2_sum = o_concept_mom_v2.groupby(['ticker','datadate'])[['MOMENTUM_rk','bret126_rk','bret63_rk']].mean().reset_index()


### get wind industry

i_wsec = yu.get_sql('''select ticker, datadate, w_ind, w_subind from cndb.dbo.universe_all_cn_gem3l''')
c_sh = i_wsec['ticker'].str[0].isin(['6'])
c_sz = i_wsec['ticker'].str[0].isin(['0','3'])
i_wsec.loc[c_sh, 'ticker'] = i_wsec.loc[c_sh, 'ticker'] + '.SH'
i_wsec.loc[c_sz, 'ticker'] = i_wsec.loc[c_sz, 'ticker'] + '.SZ'


### combine

icom = i_sd.merge(df_concept, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(o_concept_mom_v2_sum, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(i_wsec, on = ['ticker','datadate'], how = 'left')

icom['PUBLISHCODE'] = icom['PUBLISHCODE'].fillna(0)



### rank of t126d bret

icom['bret126_rk_bk'] = icom.groupby('datadate')['bret126_rk'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['bret126_rk_rk'] = icom.groupby('datadate')['bret126_rk'].apply(yu.uniformed_rank).val
ues

icom['bret126_rk_sgnl'] = - icom['bret126_rk_rk']

yu.create_cn_3x3(icom, ['bret126_rk_bk'], 'bret126_rk') #mono +10 -10
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['bret126_rk_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'bret126_rk_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.74/1.84, 2.43bp/d
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['bret126_rk_sgnl']>0)].\
            dropna(subset=['bret126_rk_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'bret126_rk_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 4.43/2.44, 3.33bp/d


### rank of momentum within wind

icom['MOMENTUM_windbk'] = icom.groupby(['datadate','w_ind'])['MOMENTUM'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['MOMENTUM_windrk'] = icom.groupby(['datadate','w_ind'])['MOMENTUM'].apply(yu.uniformed_rank).values

icom['MOMENTUM_windrk_sgnl'] = - icom['MOMENTUM_windrk']

icom['MOMENTUM_wsubindbk'] = icom.groupby(['datadate','w_subind'])['MOMENTUM'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['MOMENTUM_wsubindrk'] = icom.groupby(['datadate','w_subind'])['MOMENTUM'].apply(yu.uniformed_rank).values

icom['MOMENTUM_wsubindrk_sgnl'] = - icom['MOMENTUM_wsubindrk']

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['MOMENTUM_windrk_sgnl']>0)].\
            dropna(subset=['MOMENTUM_windrk_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'MOMENTUM_windrk_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 6.07/4.9, 3.01bp/d
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['MOMENTUM_wsubindrk_sgnl']>0)].\
            dropna(subset=['MOMENTUM_wsubindrk_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'MOMENTUM_wsubindrk_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 6.07/4.9, 3.01bp/d


### rank of momentum within concepts

icom['MOMENTUM_rk_bk'] = icom.groupby('datadate')['MOMENTUM_rk'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['MOMENTUM_rk_rk'] = icom.groupby('datadate')['MOMENTUM_rk'].apply(yu.uniformed_rank).values

icom['MOMENTUM_rk_sgnl'] = - icom['MOMENTUM_rk_rk']


yu.create_cn_3x3(icom, ['MOMENTUM_rk_bk'], 'MOMENTUM_rk') #mono +8, -8

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['MOMENTUM_rk_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']
),
            'MOMENTUM_rk_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 7.04/5.44, 3.18bp/d
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['MOMENTUM_rk_sgnl']>0)].\
            dropna(subset=['MOMENTUM_rk_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'MOMENTUM_rk_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 6.32/4.99, 3.85bp/d
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['MOMENTUM_rk_sgnl']<0)].\
            dropna(subset=['MOMENTUM_rk_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'MOMENTUM_rk_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2019-12-31'))&(icom['MOMENTUM_rk_sgnl']<-0.8)&(icom['a50_300_flag']==1)].\
            dropna(subset=['MOMENTUM_rk_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'MOMENTUM_rk_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.46/1.69, 1.61bp/d


### rank of concept counts

icom['cpt_rk'] = icom.groupby('datadate')['PUBLISHCODE'].apply(yu.uniformed_rank).values
icom['cpt_bk'] = icom.groupby('datadate')['PUBLISHCODE'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom, ['cpt_bk'], 'PUBLISHCODE') # it is monotonic 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['cpt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cpt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.35 / 0.7

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['cpt_rk']>0)].\
            dropna(subset=['cpt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cpt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.85/0.49

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['cpt_rk']<0)].\
            dropna(subset=['cpt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cpt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.62 / 0.79

### new concept event

icom['PUBLISHCODE_chg_flag'] = icom.groupby('ticker')['PUBLISHCODE'].apply(lambda x: x!=x.shift()).values

icom['new_cpt_sgnl'] = np.nan
icom.loc[icom['PUBLISHCODE_chg_flag'], 'new_cpt_sgnl'] = 1
icom['new_cpt_sgnl'] = icom.groupby('ticker')['new_cpt_sgnl'].ffill(limit=10)


yu.create_cn_decay(icom, 'PUBLISHCODE_chg_flag')
o_1 = yu.bt_cn_15(icom[(icom['
datadate']<='2019-12-31')].\
            dropna(subset=['new_cpt_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'new_cpt_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs -0.56


### within concept momentum


龙头股 clustering 




