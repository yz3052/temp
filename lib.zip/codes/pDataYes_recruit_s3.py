﻿#$%^&* pDataYes_recruit_s3.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Sep  2 20:38:06 2021

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import zipfile
import csv

import jieba



# this analyzes the string data in job desc
# s2 analyzes number of word segemtns
# s3 analyzes if a job can be matched to past word segs



### get ind

i_ind = yu.get_sql('''select datadate, ticker, gsector, ggrop, gind, gsubind 
                   FROM [CNDB].[dbo].[UNIVERSE_ALL_CN]
                   where datadate >= '2016-01-01' ''')
c_sh = i_ind['ticker'].str[0].isin(['6'])
c_sz = i_ind['ticker'].str[0].isin(['3','0'])
i_ind.loc[c_sh, 'ticker'] = i_ind.loc[c_sh, 'ticker'] + '.SH'
i_ind.loc[c_sz, 'ticker'] = i_ind.loc[c_sz, 'ticker'] + '.SZ'


### get sd
i_sd = pw.get_ashare_hk_sd_v2()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','a50_300_flag','a50_flag']]

i_sd_map_300 =i_sd_map[i_sd_map['a50_300_flag']==1]
i_sd_datadate_sr = i_sd_map_300['datadate'].drop_duplicates()
i_sd_map_hk  = i_sd_map[i_sd_map['isin_hk_uni']==1]



#--------------------------------------------------

### Create jd segments per row


i_files = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\txt_w_tk')
i_str = pd.concat(pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\txt_w_tk',f)) for f in i_files)
i_str = i_str.drop(columns=['position_responsibilities', 'position_requirements', 'published_at'])

i_str['job_desc'] = i_str['job_desc'].fillna('')
i_str['jd_clean'] = i_str['job_desc'].str.replace('\(.*\)','').str.replace('（.*）','').\
                     str.replace('\d+、',' ').str.replace('\d+\.',' ').\
                     str.replace('\r', ' ').str.replace('\n', ' ').\
                     str.replace('\[.*\]','').str.replace('\【.*\】','').\
                     str.replace('（|）|,|，|\.|。|:|：|;|；|\(|\)|\*|~|`|!|@|#|$|&|-|—|\+|\/|、|\?',' ').\
                     str.strip().str.replace('[ ]+', ' ').\
                     str.upper()

i_str['jd_seg'] = i_str['jd_clean'].apply(lambda x: '@'.join( list(set(jieba.cut(x))) ))


# get main post data
i_files2 = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet')
i_post = pd.concat(pd.read_par
quet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet',f),columns=['id','source','published_at','ticker_symbol']) for f in i_files2)
i_post = i_post[i_post['ticker_symbol'].notnull()]
i_post = i_post[i_post['ticker_symbol'].str.contains('\d{6}')]

# select 51 job data
i_str = i_str.merge(i_post, on = ['id'], how = 'inner')
i_str = i_str[i_str['source'].isin(['51job','猎聘网'])]




### calculate monthly ttm seg set for each ticker
i_str300 = i_str[i_str['ticker'].isin(i_sd_map_300['ticker'].unique().tolist())] ###!!!

i_t1y_segset = pd.DataFrame()
for dt in pd.date_range(start = '2017-01-01', end = '2020-05-31'):
    if dt.day != 1:
        continue
    print('.', end='')
    t_str = i_str300[i_str300['datadate'].between(dt-pd.to_timedelta('365 days'), dt)]
    t_segs = t_str.groupby('ticker')['jd_seg'].apply(lambda x:  set('@'.join(x.tolist()).split('@')) ).reset_index()
    t_segs = t_segs.rename(columns={'jd_seg': 'jd_seg_set'})
    t_segs['datadate'] = dt
    
    i_t1y_segset = i_t1y_segset.append(t_segs, sort = False)
    t_str = None
    t_segs = None

### Calculate trailing 1 year metrics

i_str300['datadate_1y'] = i_str300['datadate'] - pd.to_timedelta('365 days')
i_str300 = i_str300.sort_values('datadate')
i_t1y_segset = i_t1y_segset.sort_values('datadate')
i_str300 = pd.merge_asof(i_str300, i_t1y_segset, by = 'ticker', 
                         left_on = 'datadate_1y', right_on = 'datadate',
                         suffixes = ['', '_merge'])
i_str300 = i_str300.drop(columns=['datadate_merge'])
i_str300['jd_seg_set'] = i_str300['jd_seg_set'].fillna('')
i_str300['pct_matched'] = i_str300[['jd_seg','jd_seg_set']].\
                        apply(lambda x: len(set(x['jd_seg'].split('@')).intersection(x['jd_seg_set'])) / (x['jd_seg'].count('@')+1) , axis = 1)
#i_str300['pct_matched'] = i_str300[['jd_seg','jd_seg_set']].\
#                        apply(lambda x: len(set(x['jd_seg'].split('@')).intersection(x['jd_seg_set'])) / len(set(x['jd_seg'].split('@'))) , axis = 1) # lower sharpe

i_t1y = pd.DataFrame()
for dt in pd.date_range(start = '2017-01-01', end = '2020-05-31'):
    print('.', end='')
    t_str = i_str300[i_str300['datadate'].between(dt-pd.to_timedelta('365 days'), dt)]
    
    t_pct_matched = t_str.groupby('ticker')['pct_matched'].mean().reset_index()
    t_1_id_cnt = t_str[t_str['pct_matched']>0.1].groupby('ticker')['id'].nunique().reset_index()

    t_4_id_cnt = t_str[t_str['pct_matched']>0.4].groupby('ticker')['id'].nun
ique().reset_index()
    t_4_id_cnt = t_4_id_cnt.rename(columns={'id':'id4_cnt_t1y'})
    t_5_id_cnt = t_str[t_str['pct_matched']>0.5].groupby('ticker')['id'].nunique().reset_index()
    t_5_id_cnt = t_5_id_cnt.rename(columns={'id':'id5_cnt_t1y'})
    t_6_id_cnt = t_str[t_str['pct_matched']>0.6].groupby('ticker')['id'].nunique().reset_index()
    t_6_id_cnt = t_6_id_cnt.rename(columns={'id':'id6_cnt_t1y'})
    t_7_id_cnt = t_str[t_str['pct_matched']>0.7].groupby('ticker')['id'].nunique().reset_index()
    t_7_id_cnt = t_7_id_cnt.rename(columns={'id':'id7_cnt_t1y'})
    t_8_id_cnt = t_str[t_str['pct_matched']>0.8].groupby('ticker')['id'].nunique().reset_index()
    t_8_id_cnt = t_8_id_cnt.rename(columns={'id':'id8_cnt_t1y'})
    t_9_id_cnt = t_str[t_str['pct_matched']>0.9].groupby('ticker')['id'].nunique().reset_index()
    t_9_id_cnt = t_9_id_cnt.rename(columns={'id':'id9_cnt_t1y'})
    t_98_id_cnt = t_str[t_str['pct_matched']>0.98].groupby('ticker')['id'].nunique().reset_index()
    t_98_id_cnt = t_98_id_cnt.rename(columns={'id':'id98_cnt_t1y'})
    
    t_t1y = t_pct_matched.merge(t_8_id_cnt, on = ['ticker'], how = 'outer')
    t_t1y = t_t1y.merge(t_9_id_cnt, on = ['ticker'], how = 'outer')
    t_t1y = t_t1y.merge(t_98_id_cnt, on = ['ticker'], how = 'outer')
    
    t_t1y = t_t1y.merge(t_7_id_cnt, on = ['ticker'], how = 'outer')
    t_t1y = t_t1y.merge(t_6_id_cnt, on = ['ticker'], how = 'outer')
    t_t1y = t_t1y.merge(t_5_id_cnt, on = ['ticker'], how = 'outer')
    t_t1y = t_t1y.merge(t_4_id_cnt, on = ['ticker'], how = 'outer')

    
    t_t1y['datadate'] = dt
    i_t1y = i_t1y.append(t_t1y, sort = False)
    
    t_str = None



i_t1y['datadate_l1y'] = i_t1y['datadate'] - pd.to_timedelta('365 days')
i_t1y = i_t1y.merge(i_t1y, 
                    left_on = ['ticker', 'datadate_l1y'],
                    right_on = ['ticker', 'datadate'], 
                    how = 'left', suffixes = ['', '_1y'])
i_t1y = i_t1y.drop(columns = ['datadate_l1y','datadate_1y'])




### Calculate trailing 1 q metrics

i_t1q = pd.DataFrame()
for dt in pd.date_range(start = '2017-01-01', end = '2020-05-31'):
    print('.', end='')
    t_str = i_str300[i_str300['datadate'].between(dt-pd.to_timedelta('91 days'), dt)]
    
    t_pct_matched = t_str.groupby('ticker')['pct_matched'].mean().reset_index()
    t_8_id_cnt = t_str[t_str['pct_matched']>0.8].groupby('ticker')['id'].nunique().reset_index()
    t_8_id_cnt = t_8_id_cnt.rename(columns={'id':'id8_cnt_t1q'})
    t_9_id_cnt = t_
str[t_str['pct_matched']>0.9].groupby('ticker')['id'].nunique().reset_index()
    t_9_id_cnt = t_9_id_cnt.rename(columns={'id':'id9_cnt_t1q'})
    t_98_id_cnt = t_str[t_str['pct_matched']>0.98].groupby('ticker')['id'].nunique().reset_index()
    t_98_id_cnt = t_98_id_cnt.rename(columns={'id':'id98_cnt_t1q'})
    
    t_t1q = t_pct_matched.merge(t_8_id_cnt, on = ['ticker'], how = 'outer')
    t_t1q = t_t1q.merge(t_9_id_cnt, on = ['ticker'], how = 'outer')
    t_t1q = t_t1q.merge(t_98_id_cnt, on = ['ticker'], how = 'outer')
    
    t_t1q['datadate'] = dt
    i_t1q = i_t1q.append(t_t1q, sort = False)    
    t_str = None

i_t1q['datadate_l1y'] = i_t1q['datadate'] - pd.to_timedelta('365 days')
i_t1q = i_t1q.rename(columns={'pct_matched':'pct_matched_t1q'})
i_t1q = i_t1q.merge(i_t1q, 
                    left_on = ['ticker', 'datadate_l1y'],
                    right_on = ['ticker', 'datadate'], 
                    how = 'left', suffixes = ['', '_1y'])
i_t1q = i_t1q.drop(columns = ['datadate_l1y','datadate_1y'])


### MC

i_mc = yu.get_sql('''select ticker, datadate, mc from [CNDB].[dbo].[UNIVERSE_ALL_CN] 
                    where ticker in ('{0}') '''.format("','".join( i_sd_map['ticker'].str[:6].unique().tolist() )))
i_mc['datadate_1y'] = i_mc['datadate'] - pd.to_timedelta('365 days')
i_mc['datadate_1q'] = i_mc['datadate'] - pd.to_timedelta('91 days')


i_mc = i_mc.sort_values('datadate')

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1q', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1q'})

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1y', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1y'})
i_mc = i_mc.drop(columns = ['datadate_1q', 'datadate_1y'])


c_sh = i_mc['ticker'].str[0].isin(['6'])
c_sz = i_mc['ticker'].str[0].isin(['0', '3'])
i_mc.loc[c_sz, 'ticker'] = i_mc.loc[c_sz, 'ticker'] + '.SZ'
i_mc.loc[c_sh, 'ticker'] = i_mc.loc[c_sh, 'ticker'] + '.SH'


### combine
icom = i_sd_map_300.merge(i_t1y, on = ['ticker', 'datadate'], how = 'left') ###!!!
icom = icom.merge(i_t1q, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_mc, on = ['ticker', 'datadate'], how = 'left')


##
# backtest

icom2 = icom.copy()


icom2['id4_df1y'] = icom2['id4_cnt_t1y'] - icom2['id4_cnt_t1y_1y']
icom2['id4_df1y_dv_mc'] = icom2['id4_df1y'].divide(icom2['mc_1y'])
icom2['id4_df1y_rk'] = icom2.groupby('datadate')['id4_df1y'].apply(yu.uniformed_rank).values
icom2['id4_df1y_bk'] = icom2.groupby('datadate')['id4_df1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['id4_df1y_dv_mc_rk'] = icom2.groupby('datadate')['id4_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['id4_df1y_dv_mc_bk'] = icom2.groupby('datadate')['id4_df1y_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom2['id5_df1y'] = icom2['id5_cnt_t1y'] - icom2['id5_cnt_t1y_1y']
icom2['id5_df1y_dv_mc'] = icom2['id5_df1y'].divide(icom2['mc_1y'])
icom2['id5_df1y_rk'] = icom2.groupby('datadate')['id5_df1y'].apply(yu.uniformed_rank).values
icom2['id5_df1y_bk'] = icom2.groupby('datadate')['id5_df1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['id5_df1y_dv_mc_rk'] = icom2.groupby('datadate')['id5_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['id5_df1y_dv_mc_bk'] = icom2.groupby('datadate')['id5_df1y_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom2['id6_df1y'] = icom2['id6_cnt_t1y'] - icom2['id6_cnt_t1y_1y']
icom2['id6_df1y_dv_mc'] = icom2['id6_df1y'].divide(icom2['mc_1y'])
icom2['id6_df1y_rk'] = icom2.groupby('datadate')['id6_df1y'].apply(yu.uniformed_rank).values
icom2['id6_df1y_bk'] = icom2.groupby('datadate')['id6_df1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['id6_df1y_dv_mc_rk'] = icom2.groupby('datadate')['id6_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['id6_df1y_dv_mc_bk'] = icom2.groupby('datadate')['id6_df1y_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom2['id7_df1y'] = icom2['id7_cnt_t1y'] - icom2['id7_cnt_t1y_1y']
icom2['id7_df1y_dv_mc'] = icom2['id7_df1y'].divide(icom2['mc_1y'])
icom2['id7_df1y_rk'] = icom2.groupby('datadate')['id7_df1y'].apply(yu.uniformed_rank).values
icom2['id7_df1y_bk'] = icom2.groupby('datadate')['id7_df1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['id7_df1y_dv_mc_rk'] = icom2.groupby('datadate')['id7_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['id7_df1y_dv_mc_bk'] = icom2.groupby('datadate')['id7_df1y_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values


icom2['id8_df1y'] = icom2['id8_cnt_t1y'] - icom2['id8_cnt_t1y_1y']
icom2['id8_df1y_dv_mc'] = icom2['id8_df1y'].divide(icom2['mc_1y'])
icom2['id8_df1y_rk'] = icom2.groupby('datadate')['id8_df1y'].apply(yu.uniformed_rank).values
icom2['id8
_df1y_bk'] = icom2.groupby('datadate')['id8_df1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['id8_df1y_dv_mc_rk'] = icom2.groupby('datadate')['id8_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['id8_df1y_dv_mc_bk'] = icom2.groupby('datadate')['id8_df1y_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom2['id9_df1y'] = icom2['id9_cnt_t1y'] - icom2['id9_cnt_t1y_1y']
icom2['id9_df1y_dv_mc'] = icom2['id9_df1y'].divide(icom2['mc_1y'])
icom2['id9_df1y_rk'] = icom2.groupby('datadate')['id9_df1y'].apply(yu.uniformed_rank).values
icom2['id9_df1y_bk'] = icom2.groupby('datadate')['id9_df1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['id9_df1y_dv_mc_rk'] = icom2.groupby('datadate')['id9_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['id9_df1y_dv_mc_bk'] = icom2.groupby('datadate')['id9_df1y_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values


icom2['id98_df1y'] = icom2['id98_cnt_t1y'] - icom2['id98_cnt_t1y_1y']
icom2['id98_df1y_dv_mc'] = icom2['id98_df1y'].divide(icom2['mc_1y'])
icom2['id98_df1y_rk'] = icom2.groupby('datadate')['id98_df1y'].apply(yu.uniformed_rank).values
icom2['id98_df1y_bk'] = icom2.groupby('datadate')['id98_df1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['id98_df1y_dv_mc_rk'] = icom2.groupby('datadate')['id98_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['id98_df1y_dv_mc_bk'] = icom2.groupby('datadate')['id98_df1y_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values


yu.create_cn_3x3(icom2, ['id1_df1y_dv_mc_bk'], 'id1_df1y_dv_mc')
yu.create_cn_3x3(icom2, ['id2_df1y_dv_mc_bk'], 'id2_df1y_dv_mc')
yu.create_cn_3x3(icom2, ['id3_df1y_dv_mc_bk'], 'id3_df1y_dv_mc')
yu.create_cn_3x3(icom2, ['id4_df1y_dv_mc_bk'], 'id4_df1y_dv_mc')
yu.create_cn_3x3(icom2, ['id5_df1y_dv_mc_bk'], 'id5_df1y_dv_mc')
yu.create_cn_3x3(icom2, ['id6_df1y_dv_mc_bk'], 'id6_df1y_dv_mc')
yu.create_cn_3x3(icom2, ['id7_df1y_dv_mc_bk'], 'id7_df1y_dv_mc')
yu.create_cn_3x3(icom2, ['id8_df1y_dv_mc_bk'], 'id8_df1y_dv_mc')
yu.create_cn_3x3(icom2, ['id9_df1y_dv_mc_bk'], 'id9_df1y_dv_mc')
yu.create_cn_3x3(icom2, ['id98_df1y_dv_mc_bk'], 'id98_df1y_dv_mc')


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['id1_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'id1_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['id2_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_du
plicates(subset=['ticker','datadate']),
            'id2_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['id3_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'id3_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['id4_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'id4_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['id5_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'id5_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['id6_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'id6_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['id7_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'id7_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 



o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['id8_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'id8_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.02 / 3.6

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['id8_df1y_dv_mc_rk']>0.8)].\
            dropna(subset=['id8_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'id8_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['id8_df1y_dv_mc_rk']>0)].\
            dropna(subset=['id8_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'id8_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.69 / 2.47
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['id8_df1y_dv_mc_rk']<0)].\
            dropna(subset=['id8_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'id8_df1
y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.54 / 2.12



o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['id9_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'id9_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.18 / 1.81

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['id98_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'id98_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.06 / 0.74


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['pct_matched_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_matched_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

