﻿#$%^&* pCorpAct_cn_pledge.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 21 11:07:40 2022

@author: thzhang
"""




import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime

import os


### sd 

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])


### sd stable shortable 

i_sd_ss = pw.get_china_ss_sd()


### c and adj

i_c = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                 s_dq_close as c, s_dq_adjfactor as adj 
                 from wind_prod.dbo.ashareeodprices
                 where trade_dt >= '20120101' ''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format = '%Y%m%d')
i_c = i_c.sort_values('datadate')


i_c_220720 = i_c[i_c['datadate']=='2022-7-20'][['ticker', 'adj']]


### pledge

# PF = pledge finance?
# openline: 预估平仓线
# pf_start_date: 质押开始日期
# close_forward_adjprice: 质押日收盘价
# pf_holder_ratio: 所占持股比例
# pf_num： 质押股份数量 (share)
# pf_tsr: 占总股本比例
# accum_pledge_tsr: 累计抵押的股票的占比
# pre_accum_pledge_tsr: 上次 累计抵押的股票的占比

#预警线算法：冻结起始日收盘价前复权*质押率*预警线比例
#平仓线算法：冻结起始日收盘价前复权*质押率*平仓线比例
#质押率：融资额和质押股票市值的比例。质押率因行业、企业等情况不同，通常在3-6折。
#预警线/平仓线比例：目前市场上通用的标准有两个，分别是160%/140%和150%/130%；此处计算时使用160%/140%标准。

i_files = os.listdir(r'N:\projects\plegde_eastmoney')
i_pledge = pd.concat([pd.read_parquet(os.path.join(r'N:\projects\plegde_eastmoney',i)) for i in i_files], sort = False)
i_pledge = i_pledge.reset_index(drop=True)

i_pledge = i_pledge.rename(columns = {'SECUCODE':'ticker', 'NOTICE_DATE':'datadate'})
i_pledge = i_pledge.drop(columns=['BOARD_CODE','BOARD_NAME','MARKET_CAP','WARNING_STATE','MXID',
                                  'PF_PURPOSE_CODE','PFORG_TYPE','PF_ORG_CODE','ORG_CODE',
                                  'UNFREEZE_STATE','TRADE_DATE',                                  
                                  'CLOSE_FORWARD_ADJPRICE','CLOSE_PRICE','CLOSE_FORWARD_ADJPRICE_TODAY',
                                  'HOLDER_CODE','PF_SECURITY_NAME_ABBR','PF_SECURITY_CODE',
                                  'PF_ORG_CODE_PARENT','PF_ORG_NAME_PARENT','HOLDER_CODE'])

i_pledge['ACTUAL_UNFREEZE_DATE'] = i_pledge['ACTUAL_UNFREEZE_DATE'].fillna('nan')
i_pledge['ACTUAL_UNFREEZE_DATE'] = pd.to_datetime(i_pledge['ACTUAL_UNFREEZE_DATE'], errors='coerce')
i_pledge['datadate'] = pd.to_datetime(i_pledge['datadate'])
i_pledge['PF_START_DATE'] = pd.to_datetime(i_pledge['PF_START_DATE'])

# append adj on PF_START_DATE
i_pledge = i_pledge.sort_values('PF_START_DATE')
i_p
ledge = pd.merge_asof(i_pledge, i_c[['ticker', 'datadate', 'adj']]\
                         .rename(columns={'datadate':'PF_START_DATE', 'adj':'adj_startdate'}),
                         by='ticker', on = 'PF_START_DATE')





### loop

df_pledge = []

for dt in pd.date_range(start = '2017-01-01', end = '2022-06-30'):
    print(dt.strftime('%Y%m%d'), end = ',')
    
    # select pit data
    
    t_pledge = i_pledge[(i_pledge['datadate']<=dt)]
    t_pledge = t_pledge[t_pledge['OPENLINE'].notnull()]
    t_pledge = t_pledge[t_pledge['PF_START_DATE']>=dt - pd.to_timedelta('2000 days')]
    
    t_adj = i_c[(i_c['datadate']<=dt)&(i_c['datadate']>=dt-pd.to_timedelta('91 days'))]\
            .groupby('ticker').tail(1)[['ticker','adj']]
            
    t_c = i_c[(i_c['datadate']<=dt)&(i_c['datadate']>=dt-pd.to_timedelta('28 days'))]\
          .groupby('ticker').tail(1)[['ticker','c']]
    
    
    # select active pledges
    
    c1 = (t_pledge['ACTUAL_UNFREEZE_DATE']>dt+pd.to_timedelta('7 days')) | t_pledge['ACTUAL_UNFREEZE_DATE'].isnull()
    t_pledge = t_pledge[(t_pledge['PF_START_DATE']<=dt) & c1]
    
    # dedup
    # t_pledge = t_pledge.drop_duplicates() ###??? maybe this is not correct
    
    # append adjfactor for today and for 2022.07.20
    # then calculate pit hold_num, open and warning line 
        
    t_pledge = t_pledge.merge(t_adj, on = 'ticker', how = 'left')
    t_pledge = t_pledge.rename(columns = {'adj': 'adj_today'})
    t_pledge['warning_pit'] = t_pledge['WARNING_LINE'] * t_pledge['adj_startdate'] / t_pledge['adj_today']
    t_pledge['open_pit'] = t_pledge['OPENLINE'] * t_pledge['adj_startdate'] / t_pledge['adj_today']
    t_pledge['held_num_pit'] = t_pledge['HOLD_NUM'] / t_pledge['adj_startdate'] * t_pledge['adj_today']
    
    # calculate total held_num when current price is below warning / open
    
    t_pledge = t_pledge.merge(t_c, on = 'ticker', how = 'left')
    
    t_pledge['pct_above_warning'] = (t_pledge['c'] - t_pledge['warning_pit']).divide(t_pledge['warning_pit'])
    t_pledge['pct_above_open'] = (t_pledge['c'] - t_pledge['open_pit']).divide(t_pledge['warning_pit'])
    
    t_pledge.loc[t_pledge['c']<=t_pledge['warning_pit'], 'flg_below_warning'] = 1
    t_pledge.loc[t_pledge['c']<=t_pledge['open_pit'], 'flg_below_open'] = 1
    
    s_tot_shares_lt_warning = t_pledge[t_pledge['flg_below_warning']==1].groupby('ticker')['held_num_pit'].sum().reset_index()
    s_tot_shares_lt_warning = s_tot_shares_lt_warning.rename(co
lumns={'held_num_pit': 'held_num_lt_warning'})
    s_tot_shares_lt_open = t_pledge[t_pledge['flg_below_open']==1].groupby('ticker')['held_num_pit'].sum().reset_index()
    s_tot_shares_lt_open = s_tot_shares_lt_open.rename(columns={'held_num_pit': 'held_num_lt_open'})
    
    s = s_tot_shares_lt_warning.merge(s_tot_shares_lt_open, on = 'ticker', how = 'outer')
    s['datadate'] = dt
    df_pledge.append(s)
    
df_pledge = pd.concat(df_pledge, axis = 0)


    
    
    
### combine 

icom = i_sd.merge(df_pledge, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])


icom['num_lt_warning_dv_v'] = icom['held_num_lt_warning'].divide(icom['avgVadj'])
icom['num_lt_warning_dv_v_bk'] = icom.groupby('datadate')['num_lt_warning_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['num_lt_open_dv_v'] = icom['held_num_lt_open'].divide(icom['avgVadj'])
icom['num_lt_open_dv_v_bk'] = icom.groupby('datadate')['num_lt_open_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['num_lt_warning_dv_v_bk'], 'num_lt_warning_dv_v')
yu.create_cn_3x3(icom, ['num_lt_open_dv_v_bk'], 'num_lt_open_dv_v')

icom['flg_lt_open'] = np.nan
c1 = icom.groupby('ticker')['held_num_lt_open'].shift().isnull() & (icom['held_num_lt_open']>0)
icom.loc[c1, 'flg_lt_open'] = 1

icom['flg_lt_warning'] = np.nan
c1 = icom.groupby('ticker')['held_num_lt_warning'].shift().isnull() & (icom['held_num_lt_warning']>0)
icom.loc[c1, 'flg_lt_warning'] = 1

yu.create_cn_decay(icom, 'flg_lt_open')
yu.create_cn_decay(icom, 'flg_lt_warning')


