﻿#$%^&* pFlow_cn_lof.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 13 11:13:45 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu


# it's weird that when funds nav > c, i.e. expecting outflow in stocks, we actually see higher return
# etf bar chart more monotonic than LOF etc. 






### sd


i_sd = pw.get_ashare_t2000_sd()





### premium / discount 
# ETF has IOPV NAV tables

i_pd = yu.get_sql('''select a.s_info_windcode as ticker_fund, 
                  a.trade_dt, a.s_dq_close as c, b.F_NAV_UNIT as nav, a.s_dq_amount * 1000 as amt 
                  from wind.dbo.ChinaClosedFundEODPrice a
                  inner join wind.dbo.ChinaMutualFundNAV b
                  on a.TRADE_DT = b.PRICE_DATE and a.s_info_windcode = b.f_info_windcode 
                  where a.trade_dt >= '20160101'
                  order by a.TRADE_DT ''')
i_pd['datadate'] = pd.to_datetime(i_pd['trade_dt'], format='%Y%m%d')

i_pd['premium'] = i_pd['c'] / i_pd['nav'] - 1
i_pd.loc[i_pd['premium'].ge(1) | i_pd['premium'].le(-0.5), 'premium'] = np.nan


### get mf holding

i_mf = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_wind_holding_mf_q_est.parquet',
                       columns = ['ticker_fund','ticker','datadate','pctOfMFNAV'])
i_mf_dd = i_mf['datadate'].drop_duplicates()




### loop: on each day, estimate flow

o_est_flow = []

for dt in i_pd['datadate'].drop_duplicates():
    print(dt.strftime('%Y%m%d'),end=',')
    
    # get holding 
    
    max_dd = i_mf_dd[i_mf_dd<=dt].max()
    t_mf = i_mf[i_mf['datadate'] == max_dd]
    t_mf = t_mf[['ticker_fund', 'ticker', 'pctOfMFNAV']]
        
    # get premium 
    
    t_premium = i_pd[i_pd['datadate'] == dt]    
    t_premium = t_premium[t_premium['premium'].abs() > 0.01]
    
    t_premium['flow_mf_est1'] = t_premium['amt'] * (t_premium['premium'] // 0.01)
    t_premium['flow_mf_est2'] = t_premium['amt'] * (t_premium['premium'] // 0.03)
    
    c1 = t_premium['ticker_fund'].str.contains('51.*SH') | t_premium['ticker_fund'].str.contains('15.*SZ') # etf
    c2 = (~t_premium['ticker_fund'].str.contains('51.*SH')) & (~t_premium['ticker_fund'].str.contains('15.*SZ')) # LOF
    
    t_premium.loc[c1, 'fund_type'] = 'etf'
    t_premium.loc[c2, 'fund_type'] = 'others'
    
    t_premium = t_premium[['ticker_fund', 'fund_type', 'flow_mf_est1', 'flow_mf_est2']]
       
    
    # combine
    
    tcom = t_premium.merge(t_mf, on = ['ticker_fu
nd'], how = 'left')
    tcom['flow_stk_est1'] = tcom['flow_mf_est1'] * tcom['pctOfMFNAV']
    tcom['flow_stk_est2'] = tcom['flow_mf_est2'] * tcom['pctOfMFNAV']
    
    s_flow1 = tcom.groupby('ticker')[['flow_stk_est1', 'flow_stk_est2']].sum().reset_index()
    
    s_flow2 = tcom[tcom['fund_type'] == 'etf'].groupby('ticker')[['flow_stk_est1', 'flow_stk_est2']].sum().reset_index()
    s_flow2 = s_flow2.rename(columns = {'flow_stk_est1': 'flow_etf_stk_est1', 'flow_stk_est2':'flow_etf_stk_est2'})
    s_flow3 = tcom[tcom['fund_type'] == 'others'].groupby('ticker')[['flow_stk_est1', 'flow_stk_est2']].sum().reset_index()
    s_flow3 = s_flow3.rename(columns = {'flow_stk_est1': 'flow_oth_stk_est1', 'flow_stk_est2':'flow_oth_stk_est2'})
    
    # output
    
    s_flow = s_flow1.merge(s_flow2, on = 'ticker', how = 'outer')
    s_flow = s_flow.merge(s_flow3, on = 'ticker', how = 'outer')    
    s_flow['datadate'] = dt
    o_est_flow.append(s_flow)


o_est_flow = pd.concat(o_est_flow, axis = 0)




### combine

icom = i_sd.merge(o_est_flow, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['mfarb1_dv_pv'] = icom['flow_stk_est1'] / icom['avgPVadj']
icom['mfarb1_etf_dv_pv'] = icom['flow_etf_stk_est1'] / icom['avgPVadj']
icom['mfarb1_oth_dv_pv'] = icom['flow_oth_stk_est1'] / icom['avgPVadj']
icom['mfarb1_dv_pv_bk'] = icom.groupby('datadate')['mfarb1_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['mfarb1_etf_dv_pv_bk'] = icom.groupby('datadate')['mfarb1_etf_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['mfarb1_oth_dv_pv_bk'] = icom.groupby('datadate')['mfarb1_oth_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['mfarb1_dv_pv_bk'], 'mfarb1_dv_pv', col_ret='BarrRet_CLIP_USD+1d') # +3 -3 +2 0
yu.create_cn_3x3(icom, ['mfarb1_dv_pv_bk'], 'mfarb1_dv_pv', col_ret='BarrRet_CLIP_USD+2d') # +3 -3 0
yu.create_cn_3x3(icom, ['mfarb1_dv_pv_bk'], 'mfarb1_dv_pv', col_ret='BarrRet_CLIP_USD+3d') # +5 -2 0
yu.create_cn_3x3(icom, ['mfarb1_dv_pv_bk'], 'mfarb1_dv_pv', col_ret='BarrRet_CLIP_USD+4d') # random: +3 +5 -2 +3 0

yu.create_cn_3x3(icom, ['mfarb1_etf_dv_pv_bk'], 'mfarb1_etf_dv_pv', col_ret='BarrRet_CLIP_USD+1d') # random 
yu.create_cn_3x3(icom, ['mfarb1_etf_dv_pv_bk'], 'mfarb1_etf_dv_pv', col_ret='BarrRet_CLIP_USD+2d') # 2.5 -1 +0.5
yu.create_cn_3x3(icom, ['mfarb1_etf_dv_pv_bk'], 'mfarb1_etf_dv_pv', col_ret='BarrRet_CLIP_USD+3d') # 3 -4 +4 -2

yu.create_cn_3x3(icom, ['mfarb1_oth_dv_p
v_bk'], 'mfarb1_oth_dv_pv', col_ret='BarrRet_CLIP_USD+1d') # random
yu.create_cn_3x3(icom, ['mfarb1_oth_dv_pv_bk'], 'mfarb1_oth_dv_pv', col_ret='BarrRet_CLIP_USD+2d') # random
yu.create_cn_3x3(icom, ['mfarb1_oth_dv_pv_bk'], 'mfarb1_oth_dv_pv', col_ret='BarrRet_CLIP_USD+3d') # +2 +3 -2


yu.create_cn_3x3(icom, ['mfarb2_dv_pv_bk'], 'mfarb2_dv_pv', col_ret='BarrRet_CLIP_USD+1d') # +3 -5 +1
yu.create_cn_3x3(icom, ['mfarb2_dv_pv_bk'], 'mfarb2_dv_pv', col_ret='BarrRet_CLIP_USD+2d') # +4 -3



icom['sgnl1'] = np.nan
icom.loc[icom['mfarb1_dv_pv_bk']==0, 'sgnl1'] = 1
icom['sgnl1'] = icom.groupby('ticker')['sgnl1'].ffill(limit=2)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.62 / -2.01
