﻿#$%^&* pChinaScope_etl_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 24 20:45:51 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import zipfile

import gc

# this saves all china scope's data to parquet

l_files_all = os.listdir(r'Z:\120102\DATA-9368\MachineReadableNewsandSentiment')

l_files_concept = [i for i in l_files_all if 'news_concept' in i]
l_files_company = [i for i in l_files_all if 'news_company' in i]
l_files_event_entity = [i for i in l_files_all if 'news_event_entity' in i]
l_files_event_label = [i for i in l_files_all if 'news_event_label' in i]
l_files_industry = [i for i in l_files_all if 'news_industry_label' in i]
l_files_info = [i for i in l_files_all if 'news_info' in i]
l_files_people = [i for i in l_files_all if 'news_people' in i]
l_files_product = [i for i in l_files_all if 'news_product' in i]
l_files_region = [i for i in l_files_all if 'news_region' in i]


o_concept = []
for f in l_files_concept:
    print(f, end=' ')
    t_data = pd.read_csv(os.path.join(r'Z:\120102\DATA-9368\MachineReadableNewsandSentiment',f))
    t_data['file_name'] = f
    o_concept.append(t_data)
o_concept = pd.concat(o_concept, axis = 0)
o_concept.to_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\concept.parquet')
del o_concept
gc.collect()

o_company = []
for f in l_files_company:
    print(f, end=' ')
    t_data = pd.read_csv(os.path.join(r'Z:\120102\DATA-9368\MachineReadableNewsandSentiment',f))
    t_data['file_name'] = f
    o_company.append(t_data)
o_company = pd.concat(o_company, axis = 0)
o_company.to_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\company.parquet')
del o_company
gc.collect()

o_event_entity = []
for f in l_files_event_entity:
    print(f, end=' ')
    t_data = pd.read_csv(os.path.join(r'Z:\120102\DATA-9368\MachineReadableNewsandSentiment',f))
    t_data['file_name'] = f
    o_event_entity.append(t_data)
o_event_entity = pd.concat(o_event_entity, axis = 0)
o_event_entity.to_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\event_entity.parquet')
del o_event_entity
gc.collect()

o_event_label = []
for f in l_files_event_label:
    print(f, end=' ')
    t_data = pd.read_csv(os.path.join(r'Z:\120102\DATA-9368\MachineReadableNewsandSentiment',f))
    t_data['file_name'] = f
    o_event_label.append(t_data)
o_event_label = pd.concat(o_event_label, axis = 0)
o_event_label.to_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\event_label.pa
rquet')
del o_event_label
gc.collect()

o_industry = []
for f in l_files_industry:
    print(f, end=' ')
    t_data = pd.read_csv(os.path.join(r'Z:\120102\DATA-9368\MachineReadableNewsandSentiment',f))
    t_data['file_name'] = f
    o_industry.append(t_data)
o_industry = pd.concat(o_industry, axis = 0)
o_industry.to_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\indsutry.parquet')
del o_industry
gc.collect()

o_info = []
for f in l_files_info:
    print(f, end=' ')
    t_data = pd.read_csv(os.path.join(r'Z:\120102\DATA-9368\MachineReadableNewsandSentiment',f),
                         dtype={'newsSource':str, 'newsExtId':str})
    t_data['file_name'] = f
    o_info.append(t_data)
o_info = pd.concat(o_info, axis = 0)
o_info.to_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\info.parquet')
del o_info
gc.collect()

o_people = []
for f in l_files_people:
    print(f, end=' ')
    t_data = pd.read_csv(os.path.join(r'Z:\120102\DATA-9368\MachineReadableNewsandSentiment',f))
    t_data['file_name'] = f
    o_people.append(t_data)
o_people = pd.concat(o_people, axis = 0)
o_people.to_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\people.parquet')
del o_people
gc.collect()

o_product = []
for f in l_files_product:
    print(f, end=' ')
    t_data = pd.read_csv(os.path.join(r'Z:\120102\DATA-9368\MachineReadableNewsandSentiment',f))
    t_data['file_name'] = f
    o_product.append(t_data)
o_product = pd.concat(o_product, axis = 0)
o_product.to_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\product.parquet')
del o_product
gc.collect()

o_region = []
for f in l_files_region:
    print(f, end=' ')
    t_data = pd.read_csv(os.path.join(r'Z:\120102\DATA-9368\MachineReadableNewsandSentiment',f))
    t_data['file_name'] = f
    o_region.append(t_data)
o_region = pd.concat(o_region, axis = 0)
o_region.to_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\region.parquet')
del o_region
gc.collect()
