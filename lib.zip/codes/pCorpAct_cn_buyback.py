﻿#$%^&* pCorpAct_cn_buyback.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Jun  8 14:03:23 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import datetime





'''
289001000  市值管理         271001002   非股权激励流通股   312
289002000  股权激励注销     271001001   股权激励流通股  4
                           271002000    股权激励限售股   5185
289003000  实施股权激励     271001002   非股权激励流通股   236
289004000  盈利补偿         271001002   非股权激励流通股  14
                           271002002   非股权激励限售股   444
289005000   others         271001001   股权激励流通股   1
                           271001002   非股权激励流通股   1169
                           271002000                 2
                           271002002                 1
289006000                  271001002   非股权激励流通股  1
                           271002002                 1
289007000                  271001002   非股权激励流通股   22
'''






### sd 


i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()



yq_tk = yu.get_sql('''select distinct s_info_windcode as ticker from wind.dbo.ashareconseption where wind_sec_code = '0201d00000' ''')
gq_tk = yu.get_sql('''select distinct s_info_windcode as ticker from wind.dbo.ashareconseption where wind_sec_code = '02011b7000' ''')



### uni-date map


i_uni_dt = yu.get_sql('''select datadate, ticker, avgPVadj FROM [CNDBPROD].[dbo].[UNIVERSE_ALL_CN_GEM3L] ''')

c_sh = i_uni_dt['ticker'].str[0].isin(['6'])
c_sz = i_uni_dt['ticker'].str[0].isin(['0', '3'])
i_uni_dt.loc[c_sh, 'ticker'] =  i_uni_dt.loc[c_sh, 'ticker'] + '.SH'
i_uni_dt.loc[c_sz, 'ticker'] =  i_uni_dt.loc[c_sz, 'ticker'] + '.SZ'







### o2c


i_past_ret = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet')
i_past_ret = i_past_ret.sort_values(['ticker', 'datadate']).reset_index(drop = True)

i_past_ret['twap1000_2c_t4w_rk'] = i_past_ret.groupby('datadate')['twap1000_2c_t4w'].apply(yu.uniformed_rank)
i_past_ret['c2c_bret_t4w_rk'] = i_past_ret.groupby('datadate')['c2c_bret_t4w'].apply(yu.uniformed_rank)

#i_past_ret['twap1000_2c_t4w_20dslefrk'] = i_past_ret.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['twap1000_2c_t4w'].apply(lambda x: (x.rank()/x.count()).values[-1],raw=False).values



### c 

i_c = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate, s_dq_close as c, s_dq_adjclose as adjc, s_dq_adjfactor as f 
                    from
 wind_prod.dbo.ashareeodprices  
                    where trade_dt >= '20140101'  ''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format='%Y%m%d')
i_c = i_c.sort_values(['ticker', 'datadate'])

i_c['ma200'] = i_c.groupby('ticker').rolling(datetime.timedelta(days=365),on='datadate')['adjc'].mean().values
i_c['ma200'] = i_c['ma200'].divide(i_c['f'])


i_c_dd = i_c['datadate'].drop_duplicates()





### calendar

i_ed = yu.get_sql('''select ticker, datadate, ped, next_ed FROM [CNDBPROD].[dbo].[CNINFO_ED_SNAP]  
                     where datadate >= '2017-01-01' 
                     order by ticker, datadate, ped''')
c_sz = i_ed['ticker'].str[0].isin(['0', '3'])
c_sh = i_ed['ticker'].str[0].isin(['6'])
i_ed.loc[c_sz, 'ticker'] = i_ed.loc[c_sz, 'ticker'] + '.SZ'
i_ed.loc[c_sh, 'ticker'] = i_ed.loc[c_sh, 'ticker'] + '.SH'
i_ed['td2e'] = yu.get_tdate_cnt(i_ed['datadate'], i_ed['next_ed'])

i_ed = i_ed.drop_duplicates(subset=['ticker','datadate'], keep = 'first') # 1 day has ed forecasts for 2 different future quarters

i_ed['report_period'] = i_ed['ped'].dt.year*10 + i_ed['ped'].dt.quarter
i_ed['report_period'] = i_ed['report_period'].astype(int).astype(str)

i_ed = i_ed[['ticker', 'datadate', 'ped', 'report_period', 'next_ed', 'td2e']]



### cash flow

i_cash = yu.get_sql('''
                      select s_info_windcode as ticker, ann_dt, report_period, FREE_CASH_FLOW 
                      from wind.dbo.AShareCashFlow
                      where statement_type = '408001000' and report_period >= '20160101' and FREE_CASH_FLOW is not null
                      order by s_info_windcode, report_period, ann_dt''')
i_cash['datadate'] = pd.to_datetime(i_cash['ann_dt'], format = '%Y%m%d')
i_cash = i_cash.sort_values('datadate')
i_cash = i_cash[['ticker','datadate','FREE_CASH_FLOW']]



### PB

i_pb = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                            S_VAL_PB_NEW as pb 
                     from wind_prod.dbo.ashareeodderivativeindicator 
                     where trade_dt > '20160101'  ''')
i_pb['datadate'] = pd.to_datetime(i_pb['datadate'], format = '%Y%m%d')
  

### zeng jian 

i_zj = pw.get_wind_zengjian()
i_zj = i_zj[i_zj['TRANSACT_TYPE']=='减持']
i_zj = i_zj.rename(columns = {'S_INFO_WINDCODE':'ticker','ANN_DT':'datadate'})
c1 = i_zj['HOLDER_STATUS'].str.contains('控股股东')
c2 = i_zj['HOLDER_STATUS'].str.contains('实际控制')
c3 = i_zj['HOLDER_STATUS'].str.contains('经理|管理|财务|董事')
i_zj = i_zj[c1 | c2 | c3]
i_zj['flg_
jianchi'] = 1
i_zj['datadate'] = pd.to_datetime(i_zj['datadate'], format = '%Y%m%d')
i_zj = i_zj[['ticker', 'datadate', 'flg_jianchi']]



### bond

i_bond = yu.get_sql('''select a.b_info_issuercode, b.s_info_windcode as ticker, a.b_info_fullname, 
                              a.B_ISSUE_ANNOUNCEMENT as datadate from wind.dbo.CBondDescription a 
                       left join wind.dbo.windcustomcode b
                       on a.b_info_issuercode = b.s_info_compcode
                       where ((b.s_info_windcode like '3%SZ') or (b.s_info_windcode like '0%SZ') or (b.s_info_windcode like '6%SH'))  and b_issue_announcement > '20160101'
                       ''')
i_bond['datadate'] = pd.to_datetime(i_bond['datadate'], format = '%Y%m%d')


### repo

i_buyback = yu.get_sql('''select * from wind.dbo.AshareStockRepo''')

i_buyback = i_buyback.rename(columns= {'S_INFO_WINDCODE':'ticker'})

i_buyback['STATUS'] = i_buyback['STATUS'].astype(int).astype(str)
i_buyback['STOCK_REPO_OBJECTIVE_CODE'] = i_buyback['STOCK_REPO_OBJECTIVE_CODE'].astype(int).astype(str)
i_buyback['S_SHARE_LSTTYPECODE'] = i_buyback['S_SHARE_LSTTYPECODE'].astype(int).astype(str)

i_buyback['ANN_DT'] = pd.to_datetime(i_buyback['ANN_DT'], format = '%Y%m%d')

i_buyback['q_remain'] = i_buyback['EXP_QTY'] - i_buyback['QTY'].fillna(0)

i_buyback = i_buyback.sort_values('ANN_DT')
i_c = i_c.sort_values('datadate')
i_buyback = pd.merge_asof(i_buyback, i_c[['ticker','datadate','f']],by='ticker',left_on='ANN_DT',right_on='datadate')
i_buyback = i_buyback.drop(columns = ['datadate'])
i_buyback['upper_lmt_adj'] = i_buyback['S_DQ_HIGH'].multiply(i_buyback['f'])

i_buyback = i_buyback.sort_values(['ticker', 'EVENT_ID', 'ANN_DT']).reset_index(drop=True)


# filter
# get rid of samples that are not delivered on time

#i_buyback['opdate_dt'] = pd.to_datetime(i_buyback['OPDATE'].dt.date)
#i_buyback['delay'] = (i_buyback['opdate_dt'] - i_buyback['ANN_DT']).dt.days
#i_buyback = i_buyback[i_buyback['delay']<=0]


# filter
# not 股权激励注销 / 业绩补偿
# has to be floating shares

i_buyback = i_buyback[(~i_buyback['STOCK_REPO_OBJECTIVE_CODE'].isin(['289002000', '289004000'])) \
                      &(i_buyback['S_SHARE_LSTTYPECODE'].isin(['271001001','271001002']))]









#------------------------------------------------------------------------------
# an isolated experiment
# attach c

i_buyback2 = i_buyback.merge(i_c, left_on=['ANN_DT','ticker'], right_on=['datadate','ticker'], how = 'left', suffixes=['','_m'])
i_buyba
ck2['q_remain_v2'] = i_buyback2['q_remain']
c1 = i_buyback2['q_remain_v2'].isnull()
i_buyback2.loc[c1, 'q_remain_v2'] = i_buyback2.loc[c1, 'AMT'].divide(i_buyback2.loc[c1, 'c'])
i_buyback2 = i_buyback2[i_buyback2['STATUS'].isin(['324003002','324003003','324003004'])]
i_buyback2 = i_buyback2.groupby(['ticker','EVENT_ID']).tail(1)
i_buyback2 = i_buyback2.groupby(['ticker', 'ANN_DT'])['q_remain_v2'].sum().reset_index()
i_buyback2['flg'] = 1
i_buyback2 = i_buyback2.rename(columns = {'ANN_DT': 'datadate'})

icomt = i_sd.merge(i_buyback2, on = ['datadate', 'ticker'], how = 'left')
icomt = icomt.merge(i_c, on = ['ticker', 'datadate'], how = 'left')
icomt = icomt.sort_values(['ticker', 'datadate'])

icomt['sgnl'] = icomt['flg']
icomt['sgnl'] = icomt.groupby('ticker')['sgnl'].ffill(limit = 65)

icomt['sgnl2'] = np.nan 
icomt.loc[(icomt['c']<icomt['ma200'])&(icomt['sgnl']==1), 'sgnl2'] = 1
icomt['sgnl2'] = icomt.groupby('ticker')['sgnl2'].ffill(limit = 20)

yu.create_cn_decay(icomt, 'flg')
o_1 = yu.bt_cn_15(icomt[(icomt['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd)
o_1 = yu.bt_cn_15(icomt[(icomt['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd)
#------------------------------------------------------------------------------





### loop 1 - hold while a buyback is active 

o1 = []

for dt in pd.date_range(start = '2017-01-01', end = '2021-12-31'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    # get data 
    
    t_c = i_c[i_c['datadate']==i_c_dd[i_c_dd<=dt].max()]
    t_c = t_c[['ticker','adjc']]
    
    t_buyback = i_buyback[i_buyback['ANN_DT']<=dt]
    
    t_bond = i_bond[(i_bond['datadate']<=dt)&(i_bond['datadate']>=dt-pd.to_timedelta('182 days'))]
    
    # get latest buyback
    
    t_buyback = t_buyback.groupby(['ticker','EVENT_ID']).tail(1)
    t_buyback = t_buyback[~t_buyback['STATUS'].isin(['324004000','324005001','324005002','324005003'])]
    t_buyback = t_buyback.merge(t_c, on = 'ticker', how = 'left')
    
    # get first ann dt of each event
    
    t_buyback_valid_earliest = t_buyback.groupby(['ticker','EVENT_ID']).head(1)
    t_buyback_valid_earliest = t_buyback_valid_earliest.rename(columns={'ANN_DT':
'first_anndt'})
    t_buyback_valid_earliest = t_buyback_valid_earliest[['ticker', 'EVENT_ID', 'first_anndt']]
    t_buyback = t_buyback.merge(t_buyback_valid_earliest,on=['ticker','EVENT_ID'],how='left')
        
    # get most recent buyback of each ticker
    
    t_buyback_latest = t_buyback.groupby(['ticker','EVENT_ID']).tail(1)
    
    # all buybacks
    
    s_all = t_buyback.groupby('ticker')[['q_remain','AMT','EXP_QTY']].sum()
    s_all = s_all.reset_index()
    
    
    # all buyback without bonds
    s_all_woB = s_all[~s_all['ticker'].isin(t_bond['ticker'].tolist())]
    s_all_woB = s_all_woB.rename(columns = {'q_remain':'q_remain_woB', 'AMT':'AMT_woB', 'EXP_QTY':'EXP_QTY_woB'})
    
    # latest buyabck of each ticker
    
    s_latest = t_buyback_latest[['ticker','q_remain','AMT','EXP_QTY']]
    s_latest = s_latest.rename(columns = {'q_remain':'q_remain_latest', 'AMT':'AMT_latest', 'EXP_QTY':'EXP_QTY_latest'})
    s_latest = s_latest[['ticker','q_remain_latest','AMT_latest','EXP_QTY_latest']]
    
    # latest buyback within 1 yr of ann
    
    s_latest_within1y = t_buyback_latest[(dt - t_buyback_latest['first_anndt']).dt.days<365][['ticker','q_remain','AMT','EXP_QTY']]
    s_latest_within1y = s_latest_within1y.rename(columns = {'q_remain':'q_remain_latest_within1y', 'AMT':'AMT_latest_within1y', 'EXP_QTY':'EXP_QTY_latest_within1y'})
    s_latest_within1y = s_latest_within1y[['ticker','q_remain_latest_within1y','AMT_latest_within1y','EXP_QTY_latest_within1y']]
    
    # latest buybacks below upper lmt
    
    s_latest_belowLmt = t_buyback_latest[((t_buyback_latest['adjc']<t_buyback_latest['upper_lmt_adj'])|t_buyback_latest['upper_lmt_adj'].isnull())]
    s_latest_belowLmt = s_latest_belowLmt.rename(columns = {'q_remain':'q_remain_latest_belowLmt', 'AMT':'AMT_latest_belowLmt', 'EXP_QTY':'EXP_QTY_latest_belowLmt'})
    s_latest_belowLmt = s_latest_belowLmt[['ticker','q_remain_latest_belowLmt','AMT_latest_belowLmt','EXP_QTY_latest_belowLmt']]
    
    # latest buybacks within 1 yr of ann below upper lmt
    
    s_latest_belowLmt_within1y = t_buyback_latest[((t_buyback_latest['adjc']<t_buyback_latest['upper_lmt_adj'])|t_buyback_latest['upper_lmt_adj'].isnull())]
    s_latest_belowLmt_within1y = s_latest_belowLmt_within1y[(dt - s_latest_belowLmt_within1y['first_anndt']).dt.days<365]
    s_latest_belowLmt_within1y = s_latest_belowLmt_within1y.rename(columns = {'q_remain':'q_remain_latest_belowLmt_within1y', 'AMT':'AMT_latest_belowLmt_within1y',
 'EXP_QTY':'EXP_QTY_latest_belowLmt_within1y'})
    s_latest_belowLmt_within1y = s_latest_belowLmt_within1y[['ticker','q_remain_latest_belowLmt_within1y','AMT_latest_belowLmt_within1y','EXP_QTY_latest_belowLmt_within1y']]
    
    # all buybacks, with no other buy backs over the past 1 years
    t_buyback_t5y = i_buyback[(i_buyback['ANN_DT']>=dt-pd.to_timedelta('1825 days'))]
    t_buyback_t5y = t_buyback_t5y.groupby('ticker')['EVENT_ID'].nunique()
    t_buyback_t5y = t_buyback_t5y[t_buyback_t5y==1]
    t_buyback_t3y = i_buyback[(i_buyback['ANN_DT']>=dt-pd.to_timedelta('1095 days'))]
    t_buyback_t3y = t_buyback_t3y.groupby('ticker')['EVENT_ID'].nunique()
    t_buyback_t3y = t_buyback_t3y[t_buyback_t3y==1]    
    t_buyback_t1y = i_buyback[(i_buyback['ANN_DT']>=dt-pd.to_timedelta('365 days'))]
    t_buyback_t1y = t_buyback_t1y.groupby('ticker')['EVENT_ID'].nunique()
    t_buyback_t1y = t_buyback_t1y[t_buyback_t1y==1]
    
    s_all_5yclean = t_buyback.groupby('ticker')[['q_remain','AMT','EXP_QTY']].sum().reset_index()
    s_all_5yclean = s_all_5yclean[s_all_5yclean['ticker'].isin(t_buyback_t5y.index.tolist())]
    s_all_5yclean = s_all_5yclean.rename(columns={'q_remain':'q_remain_5yclean','AMT':'AMT_5yclean','EXP_QTY':'EXP_QTY_5yclean'})
        
    s_all_3yclean = t_buyback.groupby('ticker')[['q_remain','AMT','EXP_QTY']].sum().reset_index()
    s_all_3yclean = s_all_3yclean[s_all_3yclean['ticker'].isin(t_buyback_t3y.index.tolist())]
    s_all_3yclean = s_all_3yclean.rename(columns={'q_remain':'q_remain_3yclean','AMT':'AMT_3yclean','EXP_QTY':'EXP_QTY_3yclean'})
        
    s_all_1yclean = t_buyback.groupby('ticker')[['q_remain','AMT','EXP_QTY']].sum().reset_index()
    s_all_1yclean = s_all_1yclean[s_all_1yclean['ticker'].isin(t_buyback_t1y.index.tolist())]
    s_all_1yclean = s_all_1yclean.rename(columns={'q_remain':'q_remain_1yclean','AMT':'AMT_1yclean','EXP_QTY':'EXP_QTY_1yclean'})
    
    # all buybacks, with prior history of buybacks 
    t_buyback_t5y = i_buyback[(i_buyback['ANN_DT']>=dt-pd.to_timedelta('1825 days'))]
    t_buyback_t5y = t_buyback_t5y.groupby('ticker')['EVENT_ID'].nunique()
    t_buyback_t5y = t_buyback_t5y[t_buyback_t5y>1]
    
    s_all_5ymulti = t_buyback.groupby('ticker')[['q_remain','AMT','EXP_QTY']].sum().reset_index()
    s_all_5ymulti = s_all_5ymulti[s_all_5ymulti['ticker'].isin(t_buyback_t5y.index.tolist())]
    s_all_5ymulti = s_all_5ymulti.rename(columns={'q_remain':'q_remain_5ymulti','AMT':'AMT_5ymulti','EXP_QTY':'EXP
_QTY_5ymulti'})
    
    
    
    # output
    s = s_all.merge(s_latest, on = 'ticker', how = 'outer')
    s = s.merge(s_all_woB, on = 'ticker', how = 'outer')    
    s = s.merge(s_latest_within1y, on = 'ticker', how = 'outer')
    s = s.merge(s_latest_belowLmt, on = 'ticker', how = 'outer')
    s = s.merge(s_latest_belowLmt_within1y, on = 'ticker', how = 'outer')
    s = s.merge(s_all_5yclean, on = 'ticker', how = 'outer')
    s = s.merge(s_all_3yclean, on = 'ticker', how = 'outer')
    s = s.merge(s_all_1yclean, on = 'ticker', how = 'outer')
    s = s.merge(s_all_5ymulti, on = 'ticker', how = 'outer')
    s['datadate'] = dt
    
    o1.append(s)
    
    
o1 = pd.concat(o1, axis = 0)    



### loop 2 - buyback announcement as an event 


o2 = []

for dt in pd.date_range(start = '2017-01-01', end = '2021-12-31'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    # get data
    
    t_buyback = i_buyback[i_buyback['ANN_DT']<=dt]
    t_buyback = t_buyback.rename(columns={'f':'f_anndt'})
    
    t_c = i_c[(i_c['datadate']<=dt)&(i_c['datadate']>=dt-pd.to_timedelta('365 days'))]
    t_c = t_c[['ticker','datadate','adjc','f']]
    
    t_uni_dt = i_uni_dt[(i_uni_dt['datadate']<=dt)&(i_uni_dt['datadate']>=dt-pd.to_timedelta('365 days'))]
    t_uni_dt = t_uni_dt[t_uni_dt['ticker'].isin(t_buyback['ticker'].tolist())]
    t_uni_dt = t_uni_dt.sort_values('datadate')
    t_uni_dt = t_uni_dt[['ticker','datadate','avgPVadj']]
    
    t_past_ret = i_past_ret[(i_past_ret['datadate']<=dt)&(i_past_ret['datadate']>=dt-pd.to_timedelta('365 days'))]
    t_past_ret = t_past_ret[['ticker','datadate','twap1000_2c_t4w_rk']]
    
    
    
    # latest buyback 
    # get rid of completed/cancelled buybacks 
    
    t_buyback_latest = t_buyback.groupby(['ticker','EVENT_ID']).tail(1)
    t_buyback_invalid = t_buyback_latest[t_buyback_latest['STATUS'].isin(['324004000','324005001','324005002','324005003'])]
    t_buyback_valid = t_buyback[~t_buyback['EVENT_ID'].isin(t_buyback_invalid['EVENT_ID'].tolist())]    
    t_buyback_valid_earliest = t_buyback_valid.groupby(['ticker','EVENT_ID']).head(1)
    t_buyback_valid_earliest = t_buyback_valid_earliest.sort_values('ANN_DT')
    t_buyback_valid_earliest = t_buyback_valid_earliest.drop_duplicates(subset='ticker', keep ='last')
    
    # buyback ann date
    t_buyback_anndt = t_buyback.groupby(['ticker','EVENT_ID'])['ANN_DT'].min().reset_index()
    t_buyback_anndt = t_buyback_anndt.rename(columns = {'ANN_DT':'first_anndt'})
    
t_buyback_valid_earliest = t_buyback_valid_earliest.merge(t_buyback_anndt,on=['ticker','EVENT_ID'],how='left')
    
    # merge buyback into uni-date-map and market-data
    
    t_data = pd.merge_asof(t_uni_dt, t_buyback_valid_earliest, by='ticker', 
                           left_on='datadate', right_on='ANN_DT')
    t_data = t_data.merge(t_c, on = ['ticker', 'datadate'], how = 'left')
    t_data = t_data[t_data['EVENT_ID'].notnull()]
    
    t_data['dist_to_lmt'] = (t_data['upper_lmt_adj'] - t_data['adjc']).divide(t_data['adjc'])
    t_data['days_since_latest_anndt'] = (t_data['datadate'] - t_data['ANN_DT']).dt.days
    t_data['days_since_first_anndt'] = (t_data['datadate'] - t_data['first_anndt']).dt.days
    
    t_data = t_data.merge(t_past_ret, on = ['ticker', 'datadate'], how = 'left')
    
    # get rid of tickers that have reached high o2c
    
    t_highO2C_tk = t_data.groupby('ticker')['twap1000_2c_t4w_rk'].max().reset_index()
    t_highO2C_tk = t_highO2C_tk[t_highO2C_tk['twap1000_2c_t4w_rk']>0.8]
    t_data = t_data[~t_data['ticker'].isin(t_highO2C_tk['ticker'].tolist())]
    
    # get rid of tickers that have hit upper lmt
    
    t_reach_lmt = t_data.groupby('ticker')['dist_to_lmt'].min().reset_index()
    t_reach_lmt = t_reach_lmt[t_reach_lmt['dist_to_lmt']<0.05]
    t_data = t_data[~t_data['ticker'].isin(t_reach_lmt['ticker'].tolist())]
    
    # get rid of positions that last > 1y
        
    t_too_long = t_data.groupby('ticker')['days_since_latest_anndt'].max().reset_index()
    t_too_long = t_too_long[t_too_long['days_since_strat']>182]
    t_data = t_data[~t_data['ticker'].isin(t_too_long['ticker'].tolist())]
    
    # identify tickers that reached low o2c
    t_lowO2C_tk = t_data.groupby('ticker')['twap1000_2c_t4w_rk'].min().reset_index()
    t_lowO2C_tk = t_lowO2C_tk[t_lowO2C_tk['twap1000_2c_t4w_rk']<-0.8]    
    
    # buyback yield
    
    t_data['amt_dv_pv'] = t_data['AMT'].divide(t_data['avgPVadj'])
    
    # signals
    
    s_all = t_data[['ticker']].drop_duplicates()
    s_all['flg_all'] = 1
    
    s_all_lowO2c = t_data[['ticker']].drop_duplicates()
    s_all_lowO2c = s_all_lowO2c[~s_all_lowO2c['ticker'].isin(t_lowO2C_tk['ticker'].tolist())]
    s_all_lowO2c['flg_lowO2c'] = 1
    
    s_highyild = t_data[t_data['amt_dv_pv']>5][['ticker']].drop_duplicates()
    s_highyild['flg_highyild'] = 1
    
    s = s_all.merge(s_highyild, on = 'ticker', how = 'outer')
    s = s.merge(s_all_lowO2c, on = 'ticker', how = 'outer')

    s['datadate'] = dt    
    o2.append(s)
    
o2 = pd.concat(o2, axis = 0)    








### combine (hold while buyback active)

icom = i_sd.merge(o1, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_past_ret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values('datadate')
icom = pd.merge_asof(icom, i_cash, by = 'ticker', on = 'datadate')
i_zj = i_zj.sort_values('datadate')
icom = pd.merge_asof(icom, i_zj, by = 'ticker', on = 'datadate', tolerance = pd.to_timedelta('365 days'))
#icom = icom.merge(i_ed, on = ['ticker', 'datadate'], how = 'left')
#icom = icom.merge(i_pb, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])





### a first look 
#'q_remain_latest', 'AMT_latest', 'EXP_QTY_latest', 
#'q_remain_latest_within1y', 'AMT_latest_within1y', 'EXP_QTY_latest_within1y', 
#'q_remain_latest_belowLmt', 'AMT_latest_belowLmt', 'EXP_QTY_latest_belowLmt', 
#'q_remain_latest_belowLmt_within1y', 'AMT_latest_belowLmt_within1y', 'EXP_QTY_latest_belowLmt_within1y',
#'q_remain_5yclean', 'AMT_5yclean', 'EXP_QTY_5yclean', 
#'q_remain_3yclean', 'AMT_3yclean', 'EXP_QTY_3yclean',
#'q_remain_1yclean', 'AMT_1yclean', 'EXP_QTY_1yclean'

icom['q_dv_adv'] = icom['q_remain'].divide(icom['avgVadj'])
icom.loc[icom['q_dv_adv']<0, 'q_dv_adv'] = 0
icom['q_dv_adv_bk'] = icom.groupby('datadate')['q_dv_adv'].apply(lambda x: yu.pdqcut(x,bins=10))

#c1 = (icom['q_remain_woB_dv_adv']>0)&(icom['twap1000_2c_t4w_rk']<-0.6)&(icom['flg_jianchi']!=1)
#yu.create_cn_3x3(icom[c1], ['q_dv_adv_bk'], 'q_dv_adv') # not mono


icom['amt_remain_rk'] = icom.groupby('datadate')['AMT'].apply(yu.uniformed_rank)
icom['FREE_CASH_FLOW_rk'] = icom.groupby('datadate')['FREE_CASH_FLOW'].apply(yu.uniformed_rank)
icom['amt_cfc_rkdf'] = icom['amt_remain_rk'] - icom['FREE_CASH_FLOW_rk']
icom['amt_cfc_rkdf_bk'] = icom.groupby('datadate')['amt_cfc_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10))
yu.create_cn_3x3(icom,['amt_cfc_rkdf_bk'],'amt_cfc_rkdf')


icom['q_remain_1yclean_dv_so'] = icom['q_remain_1yclean'].divide(icom['FLOAT_l1d'])
icom.loc[icom['q_remain_1yclean_dv_so']<0, 'q_remain_1yclean_dv_so'] = 0
icom['q_remain_1yclean_dv_so_bk'] = icom.groupby('datadate')['q_remain_1yclean_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10))
yu.create_cn_3x3(icom, ['q_remain_1yclean_dv_so_bk'], 'q_remain_1yclean_dv_so')

icom['q_remain_5ymulti_dv_so'] = icom['q_remain_5ymulti'].divide(icom['FLOAT_l1d'])
icom.loc[icom['q_remain_5ymulti_dv_so']<0, 'q_remain_5ymulti_d
v_so'] = 0
icom['q_remain_5ymulti_dv_so_bk'] = icom.groupby('datadate')['q_remain_5ymulti_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10))
yu.create_cn_3x3(icom, ['q_remain_5ymulti_dv_so_bk'], 'q_remain_5ymulti_dv_so')


icom['EXP_QTY_latest_within1y_dv_so'] = icom['EXP_QTY_latest_within1y'].divide(icom['FLOAT_l1d'])
icom['EXP_QTY_latest_within1y_dv_so_bk'] = icom.groupby('datadate')['EXP_QTY_latest_within1y_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10))
yu.create_cn_3x3(icom, ['EXP_QTY_latest_within1y_dv_so_bk'], 'EXP_QTY_latest_within1y_dv_so') # random 

icom['q_remain_latest_within1y_dv_so'] = icom['q_remain_latest_within1y'].divide(icom['FLOAT_l1d'])
icom.loc[icom['q_remain_latest_within1y_dv_so']<0, 'q_remain_latest_within1y_dv_so'] = 0
icom['q_remain_latest_within1y_dv_so_bk'] = icom.groupby('datadate')['q_remain_latest_within1y_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10))
yu.create_cn_3x3(icom, ['q_remain_latest_within1y_dv_so_bk'], 'q_remain_latest_within1y_dv_so') # +ve return on the left side

icom['q_latest_belowLmt_within1y_dv_adv'] = icom['q_remain_latest_belowLmt_within1y'].divide(icom['avgVadj'])
icom.loc[icom['q_latest_belowLmt_within1y_dv_adv']<0, 'q_latest_belowLmt_within1y_dv_adv'] = 0
icom['q_latest_belowLmt_within1y_dv_adv_bk'] = icom.groupby('datadate')['q_latest_belowLmt_within1y_dv_adv'].apply(lambda x: yu.pdqcut(x,bins=10))
icom['c2c_bret_t4w_bk'] = icom.groupby('datadate')['c2c_bret_t4w'].apply(lambda x: yu.pdqcut(x,bins=10))
yu.create_cn_3x3(icom[icom['c2c_bret_t4w_bk']==0], ['q_latest_belowLmt_within1y_dv_adv_bk'], 'q_latest_belowLmt_within1y_dv_adv') 

icom['q_latest_belowLmt_within1y_dv_so'] = icom['q_remain_latest_belowLmt_within1y'].divide(icom['FLOAT_l1d'])
icom.loc[icom['q_latest_belowLmt_within1y_dv_so']<0, 'q_latest_belowLmt_within1y_dv_so'] = 0
icom['q_latest_belowLmt_within1y_dv_so_bk'] = icom.groupby('datadate')['q_latest_belowLmt_within1y_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10))
icom['c2c_bret_t4w_bk'] = icom.groupby('datadate')['c2c_bret_t4w'].apply(lambda x: yu.pdqcut(x,bins=10))
yu.create_cn_3x3(icom[icom['c2c_bret_t4w_bk']==0], ['q_latest_belowLmt_within1y_dv_so_bk'], 'q_latest_belowLmt_within1y_dv_so') 

icom['FREE_CASH_FLOW_bk'] = icom.groupby('datadate')['FREE_CASH_FLOW'].apply(lambda x: yu.pdqcut(x,bins=10))
yu.create_cn_3x3(icom, ['FREE_CASH_FLOW_bk'], 'FREE_CASH_FLOW') 





### buyback + o2c



    
icom['twap1000_2c_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_t4w'].apply(yu.uniformed_rank)
icom['c
2c_bret_t4w_rk'] = icom.groupby('datadate')['c2c_bret_t4w'].apply(yu.uniformed_rank)
    
icom['price_mean'] = icom['PV_l1d'].divide(icom['V_l1d'])
#icom['amt_dv_fcf'] = icom['price_mean'].multiply(icom['q_remain']).divide(icom['FREE_CASH_FLOW'])

icom['amt'] = icom['price_mean'].multiply(icom['q_remain'])

icom['q_dv_adv'] = icom['q_remain'].divide(icom['avgVadj'])
icom.loc[icom['q_dv_adv']<=0, 'q_dv_adv'] = np.nan
icom['q_dv_adv_01'] = icom['q_dv_adv'] / 20
icom.loc[icom['q_dv_adv_01']>1, 'q_dv_adv_01'] = 1
icom['q_dv_so'] = icom['q_remain'].divide(icom['FLOAT_l1d'])

icom['q_remain_pct'] = icom['q_remain'].divide(icom['EXP_QTY'])

icom['q_remain_woB_dv_adv'] = icom['q_remain_woB'].divide(icom['avgVadj'])
icom['q_remain_within1y_pct_dv_adv'] = icom['q_remain_latest_within1y'].divide(icom['avgVadj'])

icom['PV_l1d_rk'] = icom.groupby('datadate')['PV_l1d'].apply(yu.uniformed_rank)
icom['avgVadj_rk'] = icom.groupby('datadate')['avgVadj'].apply(yu.uniformed_rank)

icom['q_remain_1yclean_dv_so'] = icom['q_remain_1yclean'].divide(icom['FLOAT_l1d'])
icom.loc[icom['q_remain_1yclean_dv_so']<0, 'q_remain_1yclean_dv_so'] = 0
icom['q_remain_3yclean_dv_so'] = icom['q_remain_3yclean'].divide(icom['FLOAT_l1d'])
icom.loc[icom['q_remain_3yclean_dv_so']<0, 'q_remain_3yclean_dv_so'] = 0

icom['pb_rk'] = icom.groupby(['datadate','GIND'])['pb'].apply(yu.uniformed_rank).values

icom = icom.sort_values(['ticker', 'datadate'])




# main signals

icom['sgnl_1'] = np.nan
icom.loc[(icom['q_dv_adv']>0)&(icom['twap1000_2c_t4w_rk']<-0.6), 'sgnl_1'] = 1
icom.loc[icom['twap1000_2c_t4w_rk']>0.6, 'sgnl_1'] = 0
icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit=20)

icom['sgnl_1'] = np.nan
icom.loc[(icom['q_dv_adv']>0)&(icom['twap1000_2c_t4w_rk']<-0.6)&(icom['flg_jianchi']!=1), 'sgnl_1'] = 1
icom.loc[icom['twap1000_2c_t4w_rk']>0.6, 'sgnl_1'] = 0
icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit=20)

icom['sgnl_1'] = np.nan
icom.loc[(icom['q_remain_woB_dv_adv']>0)&(icom['twap1000_2c_t4w_rk']<-0.6), 'sgnl_1'] = 1
icom.loc[icom['twap1000_2c_t4w_rk']>0.6, 'sgnl_1'] = 0
icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit=20)

icom['sgnl_1'] = np.nan
icom.loc[(icom['q_remain_woB_dv_adv']>0)&(icom['twap1000_2c_t4w_rk']<-0.6)&(icom['flg_jianchi']!=1), 'sgnl_1'] = 1
icom.loc[icom['twap1000_2c_t4w_rk']>0.6, 'sgnl_1'] = 0
icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit=20)




icom['sgnl_1b'] = np.nan
c1 = (icom['q_dv_adv']>0)&(icom['twap1000_2c_t4w_rk
']<-0.6)&(icom['flg_jianchi']!=1)
icom.loc[c1, 'sgnl_1b'] = -icom.loc[c1, 'twap1000_2c_t4w_rk']
icom.loc[c2 | c3, 'sgnl_1b'] = 0
icom['sgnl_1b'] = icom.groupby('ticker')['sgnl_1b'].ffill(limit=20)

icom['sgnl_1c'] = np.nan
c1 = (icom['q_dv_adv']>0)&(icom['c2c_bret_t4w_rk']<-0.6)
icom.loc[c1, 'sgnl_1c'] = 1
c2 = icom['twap1000_2c_t4w_rk']>0.8
c3 = (icom['twap1000_2c_t4w_rk'].shift(3)>0.6)&(icom['twap1000_2c_t4w_rk'].shift(2)<=0.6)&(icom['twap1000_2c_t4w_rk'].shift(1)<=0.6)&(icom['twap1000_2c_t4w_rk']<=0.6)
icom.loc[c2|c3, 'sgnl_1c'] = 0
icom['sgnl_1c'] = icom.groupby('ticker')['sgnl_1c'].ffill(limit=20)

icom['sgnl_1d'] = np.nan
icom.loc[(icom['c289005000_dv_adv']>0)&(icom['twap1000_2c_t4w_rk']<-0.8), 'sgnl_1d'] = 1
icom.loc[icom['twap1000_2c_t4w_rk']>0.8, 'sgnl_1d'] = 0
icom['sgnl_1d'] = icom.groupby('ticker')['sgnl_1d'].ffill(limit=20)

icom['sgnl_1e'] = np.nan
c1 = (icom['q_dv_adv']>0)&(icom['twap1000_2c_t4w_rk']<-0.8)
icom.loc[c1, 'sgnl_1e'] = icom.loc[c1, 'q_dv_adv_01']
icom.loc[icom['twap1000_2c_t4w_rk']>0.8, 'sgnl_1e'] = 0
icom['sgnl_1e'] = icom.groupby('ticker')['sgnl_1e'].ffill(limit=20)


icom['sgnl_1f'] = np.nan
icom.loc[(icom['q_dv_adv']>0)&(icom['c2c_bret_t4w_rk']<-0.6), 'sgnl_1f'] = 1
icom.loc[icom['c2c_bret_t4w_rk']>0.6, 'sgnl_1f'] = 0
icom['sgnl_1f'] = icom.groupby('ticker')['sgnl_1f'].ffill(limit=20)


icom['sgnl_2'] = np.nan
icom.loc[(icom['q_dv_adv']>2)&(icom['twap1000_2c_t4w_rk']<-0.8), 'sgnl_2'] = 1
icom.loc[icom['twap1000_2c_t4w_rk']>0.8, 'sgnl_2'] = 0
icom['sgnl_2'] = icom.groupby('ticker')['sgnl_2'].ffill(limit=20)


icom['sgnl_3'] = np.nan
icom.loc[(icom['q_dv_adv']>0.5), 'sgnl_3'] = 1

icom['sgnl_4'] = np.nan
icom.loc[(icom['q_belowLMT_fresh_dv_adv']>0)&(icom['twap1000_2c_t4w_rk']<-0.8), 'sgnl_4'] = 1
icom.loc[icom['twap1000_2c_t4w_rk']>0.8, 'sgnl_4'] = 0
icom['sgnl_4'] = icom.groupby('ticker')['sgnl_4'].ffill(limit=20)




o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31')) ].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd) 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-12-31')) ].\
            dropna(subset=['sgnl_1b','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1b','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.66/2.15

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna
(subset=['sgnl_1c','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1c','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31')) ].\
            dropna(subset=['sgnl_1f','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1f','BarrRet_CLIP_USD+1d', static_data = i_sd) 


o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['sgnl_4','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_4','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))&(icom['ticker'].str[0]!='6')].\
            dropna(subset=['sgnl_4','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_4','BarrRet_CLIP_USD+1d', static_data = i_sd) # 



# weigui 
# not much improvement if no weigui t1y; get worse if no weigui t5y

i_weigui = yu.get_sql('''select s_info_windcode as ticker, ann_dt as datadate, ann_dt as mrdate, PROCESSOR 
                      from wind.dbo.AShareIllegality''')
i_weigui = i_weigui[i_weigui['PROCESSOR'].str.contains('证券')]
i_weigui = i_weigui.drop(columns = ['PROCESSOR'])
i_weigui['datadate'] = pd.to_datetime(i_weigui['datadate'], format='%Y%m%d')
i_weigui['mrdate'] = pd.to_datetime(i_weigui['mrdate'], format='%Y%m%d')
i_weigui = i_weigui.sort_values('datadate')


icom = icom.sort_values('datadate')
icom = pd.merge_asof(icom, i_weigui, by='ticker', on='datadate')
icom['days_since_ill'] = (icom['datadate']-icom['mrdate']).dt.days

icom['sgnl_1'] = np.nan
c1 = icom['days_since_ill'].isnull() | (icom['days_since_ill']>365*5)
icom.loc[(icom['q_dv_adv']>0)&(icom['twap1000_2c_t4w_rk']<-0.6)&c1, 'sgnl_1'] = 1
icom.loc[icom['twap1000_2c_t4w_rk']>0.6, 'sgnl_1'] = 0
icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31')) ].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd)





# sgnl_1 uses amt / q

t1 = yu.explore(icom, 'sgnl_1')
icom['to'] = icom['avgVadj'].divide(icom['FLOAT_l1d'])
icom['to'].hist(bins=100)
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31')) & (icom['to']<0.05)].\
            dropna(subset=['sgn
l_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.19 / 1.45




# using fresh not superior either 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['sgnl_1c','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1c','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.49/4.93

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['sgnl_1d','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1d','BarrRet_CLIP_USD+1d', static_data = i_sd) #
# 1.21/0.95 # 市值管理 289001000
# 1.44/0.82 # 股权激励注销 289002000
# 0.5/0.35 # 289003000  实施股权激励
# 0.2/-0.04 # 289004000  盈利补偿
# 2.19/1.71 # 289005000   others 



o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['sgnl_2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['sgnl_3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_3','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.57/0.16







### combine (buyback event)

icom = i_sd.merge(o2, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_past_ret, on = ['ticker', 'datadate'], how = 'left')


o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['flg_all','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_all','BarrRet_CLIP_USD+1d', static_data = i_sd) # <1.0

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['flg_highyild','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_highyild','BarrRet_CLIP_USD+1d', static_data = i_sd) # <1.0
 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['flg_lowO2c','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_lowO2c','BarrRet_CLIP_USD+1d', static_data = i_sd)


o_1.groupby('ticker')['pnl_ac'].sum().sort_values()
o_1[o_1.ticker=='601211.SH']['pnl_ac'].cumsum().plot()
t1 = icom[icom.ticker=='601211.SH
']
t2 = i_buyback[i_buyback.ticker=='601211.SH']




### combine daily codes

i_alpha = pd.read_csv('S:/Data/China Data Hunt/SMTCN_CHILDALPHA_test_BUYBACK_LO.txt',sep='|',names=['Ticker','alpha','DataDate'])
i_alpha = i_alpha.rename(columns = {'DataDate':'datadate_p1d', 'Ticker':'ticker'})
i_alpha['datadate_p1d'] = pd.to_datetime(i_alpha['datadate_p1d'])
i_alpha['ticker'] = i_alpha['ticker'].astype(int).astype(str).str.zfill(6)
c_sh = i_alpha['ticker'].str[0].isin(['6'])
c_sz = i_alpha['ticker'].str[0].isin(['0', '3'])
i_alpha.loc[c_sh, 'ticker'] = i_alpha.loc[c_sh, 'ticker'] + '.SH'
i_alpha.loc[c_sz, 'ticker'] = i_alpha.loc[c_sz, 'ticker'] + '.SZ'

icomt = i_sd.merge(i_alpha, on = ['datadate_p1d','ticker'], how = 'inner')

o_1 = yu.bt_cn_15(icomt[(icomt['datadate'].between('2017-01-01','2021-12-31'))].\
            dropna(subset=['alpha','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'alpha','BarrRet_CLIP_USD+1d', static_data = i_sd)
