﻿#$%^&* pDataYes_recruit_summary.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 29 18:56:56 2021

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import zipfile
import csv

import jieba



### get ind

i_ind = yu.get_sql('''select datadate, ticker, gsector, ggrop, gind, gsubind 
                   FROM [CNDB].[dbo].[UNIVERSE_ALL_CN]
                   where datadate >= '2016-01-01' ''')
c_sh = i_ind['ticker'].str[0].isin(['6'])
c_sz = i_ind['ticker'].str[0].isin(['3','0'])
i_ind.loc[c_sh, 'ticker'] = i_ind.loc[c_sh, 'ticker'] + '.SH'
i_ind.loc[c_sz, 'ticker'] = i_ind.loc[c_sz, 'ticker'] + '.SZ'


### get sd
i_sd = pw.get_ashare_hk_sd_v2()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','a50_300_flag','a50_flag']]

i_sd_map_300 =i_sd_map[i_sd_map['a50_300_flag']==1]
i_sd_datadate_sr = i_sd_map_300['datadate'].drop_duplicates()
i_sd_map_50  = i_sd_map[i_sd_map['a50_flag']==1]


### get datayes

i_p = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet')

i_raw = pd.DataFrame()
for p in i_p[:-1]:
    print(p)
    t_data = pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet', p))
        
    t_data = t_data[t_data.source == '51job'] ###!!!
    
    t_data['datadate'] = pd.to_datetime(pd.to_datetime(t_data['created_at']).dt.date)
    t_data['publish_date'] = pd.to_datetime(pd.to_datetime(t_data['published_at']).dt.date)
    
    
    t_data.loc[t_data['ticker_symbol'].str.len()!=6, 'ticker_symbol'] = np.nan
    c_sh = t_data['ticker_symbol'].str[0].isin(['6'])
    c_sz = t_data['ticker_symbol'].str[0].isin(['0', '3'])
    t_data.loc[c_sh, 'ticker'] = t_data.loc[c_sh, 'ticker_symbol'] + '.SH'
    t_data.loc[c_sz, 'ticker'] = t_data.loc[c_sz, 'ticker_symbol'] + '.SZ'
        

    t_data['educational_requirement'] = t_data['educational_requirement'].fillna('')
    c1 = (t_data['educational_requirement']=='') | t_data['educational_requirement'].str.contains('限') | t_data['educational_requirement'].str.contains('小学')
    t_data.loc[c1, 'edu'] = 1
    c2 = t_data['educational_requirement'].str.contains('初中')
    t_data.loc[c2, 'edu'] = 2
    c3 = t_data['educational_requirement'].str.contains('中.*技') | t_data['e
ducational_requirement'].str.contains('中.*专')
    t_data.loc[c3, 'edu'] = 3
    c4 = t_data['educational_requirement'].str.contains('高中')
    t_data.loc[c4, 'edu'] = 4
    c5 = t_data['educational_requirement'].str.contains('大专')
    t_data.loc[c5, 'edu'] = 5
    c6 = t_data['educational_requirement'].str.contains('本科|学士')
    t_data.loc[c6, 'edu'] = 6
    c7 = t_data['educational_requirement'].str.contains('硕士|MBA')
    t_data.loc[c7, 'edu'] = 7
    c8 = t_data['educational_requirement'].str.upper().str.contains('博士|PHD')
    t_data.loc[c8, 'edu'] = 8
    t_data.loc[t_data['edu'].isnull(), 'edu'] = 1
    
    t_data.loc[t_data['edu']<=5, 'edu_desc'] = 0
    t_data.loc[t_data['edu']==6, 'edu_desc'] = 1
    t_data.loc[t_data['edu']>=7, 'edu_desc'] = 2
    
    
    c_0 = t_data['working_experience'].isnull()
    t_data.loc[c_0, 'working_experience'] = ''
    c_0 = t_data['working_experience'].notnull()
    t_data.loc[c_0, 'working_experience'] = t_data.loc[c_0, 'working_experience'].str.replace(' ','')
    c_n = t_data['working_experience'].str.contains('^\d+年')
    t_data.loc[c_n, 'exp'] = t_data.loc[c_n, 'working_experience'].str.extract('(\d+)年').astype(int).values
    c_n = t_data['working_experience'].str.contains('\d+-\d+年')
    t_data.loc[c_n, 'exp'] = t_data.loc[c_n, 'working_experience'].str.extract('(\d+)-\d+年').astype(int).values
    c_0 = t_data['working_experience'].str.contains('无|应届|不限|1年以下|一年以下|在读')
    t_data.loc[c_0, 'exp'] = 0
    t_data.loc[t_data['working_experience']=='', 'exp'] = 0
    c_1 = t_data['working_experience'].str.contains('一年经验')
    t_data.loc[c_1, 'exp'] = 1
    
    
    t_data.loc[t_data['exp']==0, 'exp_desc'] = 'r0'
    t_data.loc[t_data['exp'].between(1,3), 'exp_desc'] = 'r1'
    t_data.loc[t_data['exp'].between(4,7), 'exp_desc'] = 'r2'
    t_data.loc[t_data['exp']>=8, 'exp_desc'] = 'r3'
    
    
    
    t_data['title3'] = t_data['title'].str.replace('\(.*\)','').str.replace('（.*）','').\
                     str.replace('\[.*\]','').str.replace('\【.*\】','').\
                     str.replace('\d[K|k|W|w|千|万]','').str.replace('\d','').\
                     str.replace('（|）|,|，|\.|。|:|：|;|；|\(|\)|\*|~|`|!|@|#|$|&|-|—|\+|\/|、|\?',' ').\
                     str.replace('职位编号','').\
                     str.strip().str.replace('[ ]+', ' ').\
                     str.upper()
    t_data = t_data[t_data['title3'].notnull() & (t_data['title3']!='')]
    
    
    
    c1 = t_data['working_location'].str.contains('北京|上海|广州|
深圳') | t_data['working_address'].str.contains('北京|上海|广州|深圳')
    t_data.loc[c1, 'city_tier'] = 1
    c1 = t_data['working_location'].str.contains('成都|重庆|杭州|武汉|西安|郑州|青岛|长沙|天津|苏州|南京|东莞|沈阳|合肥|佛山') |\
         t_data['working_address'].str.contains('成都|重庆|杭州|武汉|西安|郑州|青岛|长沙|天津|苏州|南京|东莞|沈阳|合肥|佛山')
    t_data.loc[c1, 'city_tier'] = 2
    c1 = t_data['working_location'].str.contains('昆明|福州|无锡|厦门|哈尔滨|长春|南昌|济南|宁波|大连|贵阳|温州|石家庄|泉州|南宁|金华|常州|珠海|惠州|嘉兴|南通|中山|保定|兰州|台州|徐州|太原|绍兴|烟台|廊坊') |\
         t_data['working_address'].str.contains('昆明|福州|无锡|厦门|哈尔滨|长春|南昌|济南|宁波|大连|贵阳|温州|石家庄|泉州|南宁|金华|常州|珠海|惠州|嘉兴|南通|中山|保定|兰州|台州|徐州|太原|绍兴|烟台|廊坊')
    t_data.loc[c1, 'city_tier'] = 3
    t_data.loc[t_data['city_tier'].isnull(), 'city_tier'] = 6
    
    
    
    t_data = t_data.merge(i_sd_map[['ticker','datadate','a50_300_flag']], on = ['ticker','datadate'], how = 'left')
    
    t_data = t_data.merge(i_ind, on = ['ticker','datadate'], how = 'left')
    t_data = t_data.sort_values(['ticker','datadate'])
    t_data['gsector'] = t_data.groupby('ticker')['gsector'].ffill()
    t_data['ggrop'] = t_data.groupby('ticker')['ggrop'].ffill()
    t_data['gind'] = t_data.groupby('ticker')['gind'].ffill()
    t_data['gsubind'] = t_data.groupby('ticker')['gsubind'].ffill()
    
    t_data['key_indExp'] = t_data['gind']+'-'+t_data['exp_desc']+'-'+t_data['city_tier'].astype(int).astype(str)
    t_data['key_secExp'] = t_data['gsector']+'-'+t_data['exp_desc']+'-'+t_data['city_tier'].astype(int).astype(str)
    t_data['key_secExpEdu'] = t_data['gsector']+'-'+t_data['exp_desc']+'-'+t_data['city_tier'].astype(int).astype(str)+'-'+t_data['edu_desc'].astype(int).astype(str)
    
    i_raw = i_raw.append(t_data, sort = False)


### summary stats
    
i_raw['ym'] = i_raw['datadate'].dt.strftime('%Y%m')
i_raw['y'] = i_raw['datadate'].dt.strftime('%Y')

# % of csi300 stocks

o_300tk_cnt = i_raw[i_raw['a50_300_flag']==1].groupby('ym')['ticker'].nunique().rename('300_tk_cnt')
o_alltk_cnt = i_raw.groupby('ym')['ticker'].nunique().rename('all_tk_cnt')

o_300job_cnt = -i_raw[i_raw['a50_300_flag']==1].groupby('ym')['id'].nunique().rename('300 job cnt')
o_alltkjob_cnt = i_raw[i_raw['ticker'].notnull()].groupby('ym')['id'].nunique().rename('all ticker job cnt')
o_alljob_cnt = i_raw.groupby('ym')['id'].nunique().rename('all job cnt')

o_1 = pd.concat([o_300tk_cnt, o_alltk_cnt, o_300job_cnt, o_alljob_cnt, o_alltkjob_cnt], axis = 1)
o_1['300 job %'] = o_1['300 job cnt'].divide(o_1['all job cnt'])
o_1['300 job % ah'] = o_1['300 
job cnt'].divide(o_1['all ticker job cnt'])

o_1['300_tk_cnt'].plot()
o_1['all_tk_cnt'].plot()
o_1['300 job cnt'].plot()
o_1['all job cnt'].plot()
o_1['300 job %'].plot()
o_1['300 job % ah'].plot()

# gsector distribution 

o_gsec = i_raw[i_raw['a50_300_flag']==1].groupby(['ym', 'gsector'])['id'].count().reset_index().pivot_table(index = 'ym', columns = 'gsector', values = 'id')
o_gsec.plot()


# ticker coverage within gsectors

o_dy_300_tk = i_raw[i_raw['a50_300_flag']==1].groupby(['ym', 'gsector'])['ticker'].nunique().reset_index().rename(columns={'ticker':'dy_300tk_cnt'})
o_dy_ash_tk = i_raw.groupby(['ym', 'gsector'])['ticker'].nunique().reset_index().rename(columns={'ticker':'dy_alltk_cnt'})

i_sd_map['ym'] = i_sd_map['datadate'].dt.strftime('%Y%m')
o_sd300_tk = i_sd_map[i_sd_map['a50_300_flag']==1].groupby(['ym','GSECTOR'])['ticker'].nunique().reset_index()
o_sd300_tk = o_sd300_tk.rename(columns = {'GSECTOR':'gsector', 'ticker':'sd_tk'})

o_gsec_coverage = o_dy_300_tk.merge(o_dy_ash_tk, on=['ym','gsector'], how='outer')
o_gsec_coverage = o_gsec_coverage.merge(o_sd300_tk, on=['ym','gsector'], how='left')
o_gsec_coverage = o_gsec_coverage.sort_values(['gsector','ym'])
o_gsec_coverage['pct_300_covered'] = o_gsec_coverage['dy_300tk_cnt'].divide(o_gsec_coverage['sd_tk'])

o_gsec_coverage[o_gsec_coverage['gsector']=='10'].set_index('ym')['pct_300_covered'].plot()
o_gsec_coverage[o_gsec_coverage['gsector']=='15'].set_index('ym')['pct_300_covered'].plot()
o_gsec_coverage[o_gsec_coverage['gsector']=='20'].set_index('ym')['pct_300_covered'].plot()
o_gsec_coverage[o_gsec_coverage['gsector']=='25'].set_index('ym')['pct_300_covered'].plot()
o_gsec_coverage[o_gsec_coverage['gsector']=='30'].set_index('ym')['pct_300_covered'].plot()
o_gsec_coverage[o_gsec_coverage['gsector']=='35'].set_index('ym')['pct_300_covered'].plot()
o_gsec_coverage[o_gsec_coverage['gsector']=='40'].set_index('ym')['pct_300_covered'].plot()
o_gsec_coverage[o_gsec_coverage['gsector']=='45'].set_index('ym')['pct_300_covered'].plot()
o_gsec_coverage[o_gsec_coverage['gsector']=='50'].set_index('ym')['pct_300_covered'].plot()
o_gsec_coverage[o_gsec_coverage['gsector']=='55'].set_index('ym')['pct_300_covered'].plot()
o_gsec_coverage[o_gsec_coverage['gsector']=='60'].set_index('ym')['pct_300_covered'].plot()



# work city 

o_loc = i_raw.groupby(['ym','working_location'])['id'].count().reset_index()
o_loc = o_loc.sort_values(['ym','id'], ascending = [True, False])
o_loc_top20 = o_loc.groupby('workin
g_location')['id'].count().sort_values(ascending=False).head(20)
o_loc_top20_ts = o_loc[o_loc['working_location'].isin(o_loc_top20.index.values.tolist())].pivot_table(index='ym',columns='working_location',values='id')

i_raw.groupby(['ym'])['working_location'].apply(lambda x: x.count()/len(x)).plot()

# city tier
o_tier = i_raw.groupby(['ym','city_tier'])['id'].count().reset_index().pivot_table(index='ym',columns='city_tier',values='id')

i_raw.groupby(['ym'])['city_tier'].apply(lambda x: x.count()/len(x)).plot()


# exp
o_exp = i_raw.groupby(['ym','exp_desc'])['id'].count().reset_index().pivot_table(index='ym',columns='exp_desc',values='id')

i_raw.groupby(['ym'])['working_experience'].apply(lambda x: ((x!='')&(x.notnull())).sum()/len(x)).plot()


# IT: jobs with salary / all jobs

o_it_w_s = i_raw[(i_raw['gsector']=='45')&(i_raw['annual_salary_range_start'])].groupby('y')['id'].count().rename('id_w_salary')
o_it_all = i_raw[(i_raw['gsector']=='45')].groupby('y')['id'].count().rename('id_all')

o_it = pd.concat([o_it_w_s, o_it_all], axis=1)
o_it['pct']=o_it['id_w_salary'].divide(o_it['id_all'])


# IT salary bucket 
i_it = i_raw[(i_raw['gsector']=='45')&(i_raw['annual_salary_range_start'].notnull())]
i_it.loc[i_it['annual_salary_range_start']<=200e3, 's_class'] = '0-200'
i_it.loc[i_it['annual_salary_range_start'].between(201e3,4e6), 's_class'] = '200-400'
i_it.loc[i_it['annual_salary_range_start'].between(401e3,6e6), 's_class'] = '400-600'
i_it.loc[i_it['annual_salary_range_start'].between(601e3,8e6), 's_class'] = '600-800'
i_it.loc[i_it['annual_salary_range_start'].between(801e3,1e6), 's_class'] = '800-1000'
i_it.loc[i_it['annual_salary_range_start']>1e6, 's_class'] = '1000-'

o_it_sclass = i_it.groupby(['y','s_class'])['id'].count().reset_index().pivot_table(index='y',columns='s_class',values='id')

# IT salary bucket 2
i_it = i_raw[(i_raw['gsector']=='45')&(i_raw['annual_salary_range_start'].notnull())]
i_it = i_it.reset_index(drop = True)
i_it['salary_rk'] = i_it.groupby('y')['annual_salary_range_start'].apply(yu.uniformed_rank)
i_it = i_it[i_it['salary_rk'].between(-0.9,0.9)]

i_it['salary_bk'] = i_it.groupby('y')['annual_salary_range_start'].apply(lambda x: yu.pdqcut(x,bins=5)).values

o_it_sclass = i_it.groupby(['y','salary_bk'])['annual_salary_range_start'].mean().reset_index().pivot_table(index='y',columns='salary_bk',values='annual_salary_range_start')
o_it_sclass2 = i_it.groupby(['y','salary_bk'])['id'].count().reset_index().pivot_table(index='
y',columns='salary_bk',values='id')

