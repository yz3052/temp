﻿#$%^&* pFlow_cn_hk_03.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Jun  7 16:43:59 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import gc
import os
import datetime


# this studies bb holding within 2k universe; this also tried to improve return of the 01 strategies



### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()


### trading calendar

i_cn_cal = yu.get_sql("select distinct datadate, tradedate_next from [CNDBPROD].[dbo].[Calendar_Dates_CN]")


### return

i_ret = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet',
                        columns = ['ticker','datadate','c2c','c2c_bret','twap1000_2c','twap1000_2c_bret'])

### SO

i_so = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate, 
               FLOAT_A_SHR_TODAY*10000 as so 
               from wind_prod.dbo.AShareEODDerivativeIndicator
               where trade_dt > '20160101' ''')
i_so['datadate'] = pd.to_datetime(i_so['datadate'], format = '%Y%m%d')
i_so = i_so.sort_values('datadate')


### mutual fund holding

i_mf = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_wind_holding_mf_q_est_step2.parquet',
                       columns = ['ticker', 'datadate', 'pctOfSO'])
i_mf = i_mf.rename(columns = {'pctOfSO':'pctOfSO_mf'})


### c
i_c = yu.get_sql('''select s_info_windcode as ticker, trade_Dt as datadate, s_dq_close as c  
                 from wind_prod.dbo.AShareEODPrices''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format = '%Y%m%d')


### HK uni

i_uni = yu.get_sql('''select ticker, datadate from cndbprod.dbo.[UNIVERSE_HC]
                   where datadate >= '2016-06-29' ''')
c_sh = i_uni['ticker'].str[0].isin(['6'])
c_sz = i_uni['ticker'].str[0].isin(['0','3'])
i_uni.loc[c_sh, 'ticker'] = i_uni.loc[c_sh, 'ticker'] + '.SH'
i_uni.loc[c_sz, 'ticker'] = i_uni.loc[c_sz, 'ticker'] + '.SZ'
i_uni = i_uni.sort_values(['ticker','datadate'])


### holding from hk

i_h = yu.get_sql('''
           select s_info_windcode as ticker, 
                   trade_dt as datadate,
                   s_quantity as sharesHeld_hk
           from wind.dbo.SHSCChannelholdings 
           where s_info_windcode not like '%HK' 
           order by s_info_windcode, trade_dt ''')
i_h['datadate'] = pd.to_datetime(i_h['datadate'], format='%Y%m%d')

i_h = i_uni.merge(i_h, o
n = ['datadate', 'ticker'], how = 'left')
i_h = i_h.merge(i_so, on = ['datadate', 'ticker'], how = 'left')
i_h = i_h.merge(i_c, on = ['datadate', 'ticker'], how = 'left')

i_h['c'] = i_h.groupby('ticker')['c'].ffill()
i_h['sharesHeld_hk'] = i_h['sharesHeld_hk'].fillna(0)

t_daily_count = i_h.groupby('datadate')['sharesHeld_hk'].apply(lambda x: (x!=0).sum())
i_h.loc[i_h['datadate'].isin(t_daily_count[t_daily_count==0].index.tolist()), 'sharesHeld_hk'] = np.nan
i_h['sharesHeld_hk'] = i_h.groupby('ticker')['sharesHeld_hk'].ffill(limit = 5)


i_h['pctOfComp_hk'] = i_h['sharesHeld_hk'].divide(i_h['so'])

i_h['pctOfComp_hk_df1d'] = i_h.groupby('ticker')['pctOfComp_hk'].apply(lambda x: x-x.shift()).values
i_h['pctOfComp_hk_df1d_allrk'] = i_h.groupby('datadate')['pctOfComp_hk_df1d'].apply(yu.uniformed_rank).values

i_h['pctOfComp_hk_df20d'] = i_h.groupby('ticker')['pctOfComp_hk'].apply(lambda x: x-x.shift(20))
i_h['pctOfComp_hk_df20d_ma20'] = i_h.groupby('ticker').rolling(20)['pctOfComp_hk_df20d'].mean().values
i_h['pctOfComp_hk_df20d_ma5'] = i_h.groupby('ticker').rolling(5)['pctOfComp_hk_df20d'].mean().values

i_h['pctOfComp_hk_df60d'] = i_h.groupby('ticker')['pctOfComp_hk'].apply(lambda x: x-x.shift(60)).values
i_h['pctOfComp_hk_df60d_ma20'] = i_h.groupby('ticker').rolling(20)['pctOfComp_hk_df60d'].mean().values
i_h['pctOfComp_hk_df60d_ma5'] = i_h.groupby('ticker').rolling(5)['pctOfComp_hk_df60d'].mean().values






# 去掉周六日，节假日， 和台风日， 就可以得到每日完整的持仓名单数据
# participant id 要fill一下，
# 然后开始统计各个broker的历史业绩和autocorrelation


### holding from BB 

i_h_bb_raw = yu.get_sql('''select s_info_windcode as ticker, s_holder_enddate as datadate, 
                                sum(case when s_holder_num in ('B01451', 'B01161', 'B01274', 'B01110', 'B01491', 'B01224') then s_holder_quantity else 0 end) as sharesHeld_bb , 
                                sum(case when (s_holder_num not in ('B01451', 'B01161', 'B01274', 'B01110', 'B01491', 'B01224')) and (s_holder_num like 'B%') then s_holder_quantity else 0 end) as sharesHeld_bexb , 
                                sum(case when s_holder_num like 'C%' then s_holder_quantity else 0 end) as sharesHeld_c,
                                sum(s_holder_quantity) as sharesHeld_hk,
                                count(distinct s_holder_num) as intnum_hk
                           from wind_prod.dbo.SHSCmechanismownership 
                           where (S_INFO_WINDCODE like '%SH' or S_INFO_WINDCODE like '%SZ') 
                         
  group by s_info_windcode, s_holder_enddate ''')
i_h_bb_raw['datadate'] = pd.to_datetime(i_h_bb_raw['datadate'], format='%Y%m%d')

# merge with universe

i_h_bb = i_sd[i_sd['datadate']>='2018-07-01'][['ticker','datadate']].merge(i_h_bb_raw, on = ['datadate', 'ticker'], how = 'left')
i_h_bb = i_h_bb.merge(i_c, on = ['datadate', 'ticker'], how = 'left')
i_h_bb = i_h_bb.merge(i_so, on = ['datadate', 'ticker'], how = 'left')

# fillna

i_h_bb['c'] = i_h_bb.groupby('ticker')['c'].ffill()
i_h_bb['sharesHeld_bb'] = i_h_bb['sharesHeld_bb'].fillna(0)
i_h_bb['sharesHeld_bexb'] = i_h_bb['sharesHeld_bexb'].fillna(0)
i_h_bb['sharesHeld_c'] = i_h_bb['sharesHeld_c'].fillna(0)

# fill missing dates

t_daily_count = i_h_bb.groupby('datadate')['sharesHeld_bb'].apply(lambda x: (x!=0).sum())
i_h_bb.loc[i_h_bb['datadate'].isin(t_daily_count[t_daily_count==0].index.tolist()), 'sharesHeld_bb'] = np.nan
i_h_bb['sharesHeld_bb'] = i_h_bb.groupby('ticker')['sharesHeld_bb'].ffill(limit = 5)
t_daily_count = i_h_bb.groupby('datadate')['sharesHeld_bexb'].apply(lambda x: (x!=0).sum())
i_h_bb.loc[i_h_bb['datadate'].isin(t_daily_count[t_daily_count==0].index.tolist()), 'sharesHeld_bexb'] = np.nan
i_h_bb['sharesHeld_bexb'] = i_h_bb.groupby('ticker')['sharesHeld_bexb'].ffill(limit = 5)
t_daily_count = i_h_bb.groupby('datadate')['sharesHeld_c'].apply(lambda x: (x!=0).sum())
i_h_bb.loc[i_h_bb['datadate'].isin(t_daily_count[t_daily_count==0].index.tolist()), 'sharesHeld_c'] = np.nan
i_h_bb['sharesHeld_c'] = i_h_bb.groupby('ticker')['sharesHeld_c'].ffill(limit = 5)

# metrics

i_h_bb['pctOfComp_bb'] = i_h_bb['sharesHeld_bb'].divide(i_h_bb['so'])
i_h_bb['flowOfComp_bb'] = i_h_bb.groupby('ticker')['pctOfComp_bb'].apply(lambda x: x-x.shift()).values
i_h_bb['flowOfComp_bb_t5d'] = i_h_bb.groupby('ticker').rolling(5)['flowOfComp_bb'].sum().values
i_h_bb['flowOfComp_bb_t20d'] = i_h_bb.groupby('ticker').rolling(20)['flowOfComp_bb'].sum().values
i_h_bb['flowOfComp_bb_t60d'] = i_h_bb.groupby('ticker').rolling(60)['flowOfComp_bb'].sum().values

i_h_bb['flow20dOfComp_bb'] = i_h_bb.groupby('ticker')['pctOfComp_bb'].apply(lambda x: x-x.shift(20)).values

i_h_bb['pctOfComp_bexb'] = i_h_bb['sharesHeld_bexb'].divide(i_h_bb['so'])
i_h_bb['flowOfComp_bexb'] = i_h_bb.groupby('ticker')['pctOfComp_bexb'].apply(lambda x: x-x.shift()).values

i_h_bb['pctOfComp_c'] = i_h_bb['sharesHeld_c'].divide(i_h_bb['so'])
i_h_bb['flowOfComp_c'] = i_h_bb.groupby('ticker')['pctOfComp_c'].apply(lambda x: x-x.shift()).values

i_h_bb =
 i_h_bb.drop(columns = ['c', 'so'])





# temp -  this is to study top decile north holding 

#tcom = i_sd.merge(i_h_bb, on = ['ticker', 'datadate'], how = 'left')
#tcom = tcom.sort_values(['ticker', 'datadate'])
#tcom['pctOfComp_bb_rk'] = tcom.groupby('datadate')['pctOfComp_bb'].apply(yu.uniformed_rank)
#tcom['sgnl'] = np.nan
#tcom.loc[tcom['pctOfComp_bb_rk'] > 0.8, 'sgnl'] = 1
#tcom['sgnl'] = tcom.groupby('ticker')['sgnl'].ffill(limit = 20)
#
#o_1 = yu.bt_cn_15(tcom[(tcom['datadate']<='2021-06-30')].\
#            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
#            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd)




### combine

icom = i_sd.merge(i_h, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_h_bb, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['datadate'])
icom = pd.merge_asof(icom, i_mf, by = 'ticker', on= 'datadate')
icom = icom.sort_values(['ticker', 'datadate'])



### instnum

icom['intnum_hk_bk'] = icom.groupby('datadate')['intnum_hk'].apply(lambda x: yu.pdqcut(x,bins=10))
yu.create_cn_3x3(icom, ['intnum_hk_bk'], 'intnum_hk') # not mono on the long side



### flowOfComp_bb

icom = icom.sort_values(['ticker','datadate'])

icom['pctOfComp_bb_hk'] = icom['pctOfComp_bb'].fillna(0) + icom['pctOfComp_bexb'].fillna(0) + icom['pctOfComp_c'].fillna(0)

icom['flowOfComp_bb_bk'] = icom.groupby('datadate')['flowOfComp_bb'].apply(lambda x: yu.pdqcut(x,bins=10))
icom['flowOfComp_bb_40bk'] = icom.groupby('datadate')['flowOfComp_bb'].apply(lambda x: yu.pdqcut(x,bins=40))

icom['flow20dOfComp_bb_rk'] = icom.groupby('datadate')['flow20dOfComp_bb'].apply(yu.uniformed_rank)
icom['flow20dOfComp_bb_bk'] = icom.groupby('datadate')['flow20dOfComp_bb'].apply(lambda x: yu.pdqcut(x,bins=10))
icom['flow20dOfComp_bb_40bk'] = icom.groupby('datadate')['flow20dOfComp_bb'].apply(lambda x: yu.pdqcut(x,bins=40))

icom['flow20dOfComp_bb_sgnl'] = np.nan
icom.loc[(icom['flow20dOfComp_bb_rk']>0.8)&(icom['pctOfComp_bb_hk']<0.20), 'flow20dOfComp_bb_sgnl'] = 1
icom['flow20dOfComp_bb_sgnl'] = icom.groupby('ticker')['flow20dOfComp_bb_sgnl'].ffill(limit=10)

#yu.create_cn_3x3(icom,['flowOfComp_bb_bk'],'flow20dOfComp_bb') # v shaped: 0 -4 +6
#yu.create_cn_3x3(icom,['flowOfComp_bb_40bk'],'flow20dOfComp_bb') # v shaped: 0 -5 +9 +2

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['flow20dOfComp_bb_sgnl','BarrRet_CLIP_USD+1d']).drop_duplica
tes(subset=['ticker','datadate']),
            'flow20dOfComp_bb_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) 


### flowOfComp_bb + pctOfSO

icom = icom.sort_values(['ticker','datadate'])


icom['flow20dOfComp_bb_rk'] = icom.groupby('datadate')['flow20dOfComp_bb'].apply(yu.uniformed_rank)

icom['pctOfComp_bb_rk'] = icom.groupby('datadate')['pctOfComp_bb'].apply(yu.uniformed_rank).values
icom['pctOfComp_exbb'] = icom['pctOfComp_bexb'] + icom['pctOfComp_c']
icom['pctOfComp_exbb_rk'] = icom.groupby('datadate')['pctOfComp_exbb'].apply(yu.uniformed_rank).values
icom['pctOfComp_bb_hk_rkdf'] = icom['pctOfComp_bb_rk'] - icom['pctOfComp_exbb_rk']
icom['pctOfComp_bb_hk_rkdf_rk'] = icom.groupby('datadate')['pctOfComp_bb_hk_rkdf'].apply(yu.uniformed_rank)



icom['com'] = icom['pctOfComp_bb_hk_rkdf_rk'] + icom['flow20dOfComp_bb_rk']
icom['com_rk'] = icom.groupby('datadate')['com'].apply(yu.uniformed_rank)
icom['com_bk'] = icom.groupby('datadate')['com'].apply(lambda x: yu.pdqcut(x,bins=40))

icom['com_sgnl'] = np.nan
icom.loc[icom['com_rk']>0.8, 'com_sgnl'] = 1
icom['com_sgnl'] = icom.groupby('ticker')['com_sgnl'].ffill(limit=10)

icom['com_sgnl2'] = np.nan
icom.loc[(icom['flow20dOfComp_bb_rk']>0.8)&(icom['pctOfComp_bb_hk_rkdf_rk'].between(0.0, 0.8)), 'com_sgnl2'] = 1
icom['com_sgnl2'] = icom.groupby('ticker')['com_sgnl2'].ffill(limit=5)


yu.create_cn_3x3(icom, ['com_bk'], 'com')
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['com_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'com_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.68 / -0.69

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['com_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'com_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.34 / 0.85



### pctOfComp_bb without high pctOfComp_hk

icom['intnum_hk_rk'] = icom.groupby('datadate')['intnum_hk'].apply(yu.uniformed_rank)

icom['pctOfComp_bb_rk'] = icom.groupby('datadate')['pctOfComp_bb'].apply(yu.uniformed_rank).values
icom['pctOfComp_bb_t5d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=7),on='datadate')['pctOfComp_bb'].mean().values
icom['pctOfComp_bb_t5d_rk'] = icom.groupby('datadate')['pctOfComp_bb_t5d'].apply(yu.uniformed_rank).values
icom['pctOfComp_bb_t10d'] = icom.groupby('ticker').rolling(10)['pctOfComp_bb'].mean().value
s
icom['pctOfComp_bb_t10d_rk'] = icom.groupby('datadate')['pctOfComp_bb_t10d'].apply(yu.uniformed_rank).values

icom['pctOfComp_hk'] = icom['pctOfComp_bb'].fillna(0) + icom['pctOfComp_bexb'].fillna(0) + icom['pctOfComp_c'].fillna(0)
t_hk0p8 = icom.groupby('datadate')['pctOfComp_hk'].quantile(0.8).reset_index().rename(columns = {'pctOfComp_hk': 'hk0p8'})
icom = icom.merge(t_hk0p8, on = 'datadate', how = 'left')

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31')) ].\
            dropna(subset=['pctOfComp_bb_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.41 / 3.19, 1.5e7, 7.6%
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31')) & (icom['pctOfComp_hk']<0.05)].\
            dropna(subset=['pctOfComp_bb_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 5.19/3.69, 1.4e7, 8.9%
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31')) & (icom['pctOfComp_hk']<0.028)].\
            dropna(subset=['pctOfComp_bb_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 5.63 / 3.86, 1.0e7, 9.5%
# broker count as a filter doesn't work here







### pctOfComp: bb <revised> ###!!!



icom['pctOfComp_bb_rk'] = icom.groupby('datadate')['pctOfComp_bb'].apply(yu.uniformed_rank).values
icom['pctOfComp_bb_bk'] = icom.groupby('datadate')['pctOfComp_bb'].apply(lambda x: yu.pdqcut(x,bins=10)).values
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['pctOfComp_bb_orth'] = icom.groupby('datadate')[['pctOfComp_bb']+COLS].apply(lambda x: yu.orthogonalize_cn(x['pctOfComp_bb'], x[COLS])).values
icom['pctOfComp_bb_orth_bk'] = icom.groupby('datadate')['pctOfComp_bb_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['pctOfComp_bb_t5d'] = icom.groupby('ticker').rolling(5)['pctOfComp_bb'].mean().values
icom['pctOfComp_bb_t5d_bk'] = icom.groupby('datadate')['pctOfComp_bb_t5d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['pctOfComp_bb_t5d_rk'] = icom.groupby('datadate')['pctOfComp_bb_t5d'].apply(yu.uniformed_rank).values

icom['sgnl_1'] = np.nan
icom.loc[icom['pctOfComp_bb_rk']>0.8, 'sgnl_1'] = icom.loc[icom['pctOfComp_bb_rk']>0.8, '
pctOfComp_bb_rk']
icom.loc[icom['pctOfComp_bb_rk']<-0.8, 'sgnl_1'] = icom.loc[icom['pctOfComp_bb_rk']<-0.8, 'pctOfComp_bb_rk']
icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit = 20)

#yu.create_cn_3x3(icom[icom['datadate'].between('2018-07-01','2020-12-31')], ['pctOfComp_bb_bk'], 'pctOfComp_bb_rk') #-11 +3 +3
#yu.create_cn_3x3(icom[icom['datadate'].between('2018-07-01','2020-12-31')], ['pctOfComp_bb_orth_bk'], 'pctOfComp_bb_orth') #-11 +3 +3

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['pctOfComp_bb_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 4.4/3.19, 2.89bp/d, 3.4e7 <---best

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd)


t1 = yu.explore(icom, 'pctOfComp_bb_t5d_rk')



### bb and hk diff

icom = icom.sort_values(['ticker', 'datadate'])
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']


icom['pctOfComp_bb_rk'] = icom.groupby('datadate')['pctOfComp_bb'].apply(yu.uniformed_rank).values
icom['pctOfComp_bb_bk'] = icom.groupby('datadate')['pctOfComp_bb'].apply(lambda x: yu.pdqcut(x,bins=40)).values
icom['pctOfComp_exbb'] = icom['pctOfComp_bexb'] + icom['pctOfComp_c']
icom['pctOfComp_exbb_rk'] = icom.groupby('datadate')['pctOfComp_exbb'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['pctOfComp_bb_bk'], 'pctOfComp_bb')

icom['pctOfComp_bb_t5d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=7),on='datadate')['pctOfComp_bb'].mean().values
icom['pctOfComp_bb_t5d_rk'] = icom.groupby('datadate')['pctOfComp_bb_t5d'].apply(yu.uniformed_rank).values
icom['pctOfComp_bb_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['pctOfComp_bb'].mean().values
icom['pctOfComp_bb_t20d_rk'] = icom.groupby('datadate')['pctOfComp_bb_t20d'].apply(yu.uniformed_rank).values
icom['pctOfComp_exbb_t5d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=7),on='datadate')['pctOfComp_exbb'].mean().values
icom['pctOfComp_exbb_t5d_rk'] = icom.groupby('datadate')['pctOfComp_exbb_t5d'].apply(yu.uniformed_rank).values
icom['pctOfComp_exbb_t20d'] = icom.groupby('ticker').rolling(datetime.ti
medelta(days=28),on='datadate')['pctOfComp_exbb'].mean().values
icom['pctOfComp_exbb_t20d_rk'] = icom.groupby('datadate')['pctOfComp_exbb_t20d'].apply(yu.uniformed_rank).values

icom['pctOfComp_bb_hk_rkdf'] = icom['pctOfComp_bb_rk'] - icom['pctOfComp_exbb_rk']
icom['pctOfComp_bb_hk_rkdf_bk'] = icom.groupby('datadate')['pctOfComp_bb_hk_rkdf'].apply(lambda x: yu.pdqcut(x,bins=40))
icom['pctOfComp_bb_hk_rkdf_rk'] = icom.groupby('datadate')['pctOfComp_bb_hk_rkdf'].apply(yu.uniformed_rank)
icom['pctOfComp_bb_hk_rkdf_orth'] = icom.groupby('datadate')[COLS+['pctOfComp_bb_hk_rkdf']].apply(lambda x: yu.orthogonalize_cn(x['pctOfComp_bb_hk_rkdf'], x[COLS])).values
icom['pctOfComp_bb_hk_rkdf_orth_bk'] = icom.groupby('datadate')['pctOfComp_bb_hk_rkdf_orth'].apply(lambda x: yu.pdqcut(x,bins=40))

icom['pctOfComp_bb_hk_rkdf_dv_so'] = icom['pctOfComp_bb_hk_rkdf'].divide(icom['avgVadj']).multiply(icom['so'])
icom['pctOfComp_bb_hk_rkdf_dv_so_bk'] = icom.groupby('datadate')['pctOfComp_bb_hk_rkdf_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10))
icom['pctOfComp_bb_hk_rkdf_dv_so_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['pctOfComp_bb_hk_rkdf_dv_so'].mean().values
icom['pctOfComp_bb_hk_rkdf_dv_so_t20d_bk'] = icom.groupby('datadate')['pctOfComp_bb_hk_rkdf_dv_so_t20d'].apply(lambda x: yu.pdqcut(x,bins=10))
icom['pctOfComp_bb_hk_rkdf_dv_so_df20d'] = icom.groupby('ticker')['pctOfComp_bb_hk_rkdf_dv_so'].apply(lambda x: x-x.shift(20))
icom['pctOfComp_bb_hk_rkdf_dv_so_df20d_bk'] = icom.groupby('datadate')['pctOfComp_bb_hk_rkdf_dv_so_df20d'].apply(lambda x: yu.pdqcut(x,bins=10))
#yu.create_cn_3x3(icom, ['pctOfComp_bb_hk_rkdf_bk'], 'pctOfComp_bb_hk_rkdf') #mono -7 +5
#yu.create_cn_3x3(icom, ['pctOfComp_bb_hk_rkdf_dv_so_bk'], 'pctOfComp_bb_hk_rkdf_dv_so') # less mono: -4 +4 +3
#yu.create_cn_3x3(icom, ['pctOfComp_bb_hk_rkdf_orth_bk'], 'pctOfComp_bb_hk_rkdf_orth')
icom['test']=np.nan
icom.loc[(icom['pctOfComp_bb_hk_rkdf_dv_so_df1d_bk']==9),'test'] = 1
yu.create_cn_decay(icom, 'test')

icom['pctOfComp_bb_hk_t5d_rkdf'] = icom['pctOfComp_bb_t5d_rk'] - icom['pctOfComp_exbb_t5d_rk']
icom['pctOfComp_bb_hk_t5d_rkdf_rk'] = icom.groupby('datadate')['pctOfComp_bb_hk_t5d_rkdf'].apply(yu.uniformed_rank)
icom['pctOfComp_bb_hk_t20d_rkdf'] = icom['pctOfComp_bb_t20d_rk'] - icom['pctOfComp_exbb_t20d_rk']
icom['pctOfComp_bb_hk_t20d_rkdf_rk'] = icom.groupby('datadate')['pctOfComp_bb_hk_t20d_rkdf'].apply(yu.uniformed_rank)

icom['rkdf_sgnl1'] = np.nan
c1 = icom['pctOfComp_
bb_hk_rkdf_rk'].abs()>0.95
icom.loc[c1, 'rkdf_sgnl1'] = np.sign(icom.loc[c1, 'pctOfComp_bb_hk_rkdf_rk'])
icom['rkdf_sgnl1'] = icom.groupby('ticker')['rkdf_sgnl1'].ffill(limit=2)



o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['pctOfComp_bb_hk_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_hk_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #3.89/-0.7

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['pctOfComp_bb_hk_t5d_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_hk_t5d_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #3.48/1.57

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['pctOfComp_bb_hk_t20d_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_hk_t20d_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.59 / 1.59


o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['rkdf_sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'rkdf_sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #1.22/0.88


### bb and mf diff


icom = icom.sort_values(['ticker', 'datadate'])
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']

icom['pctOfComp_bb_rk'] = icom.groupby('datadate')['pctOfComp_bb'].apply(yu.uniformed_rank).values
icom['pctOfSO_mf_rk'] = icom.groupby('datadate')['pctOfSO_mf'].apply(yu.uniformed_rank).values

icom['pctOfComp_bb_mf_rkdf'] = icom['pctOfComp_bb_rk'] - icom['pctOfSO_mf_rk']
icom['pctOfComp_bb_mf_rkdf_bk'] = icom.groupby('datadate')['pctOfComp_bb_mf_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10))
icom['pctOfComp_mfhk'] = icom['pctOfComp_bexb'] + icom['pctOfComp_c'] + icom['pctOfSO_mf']
icom['pctOfComp_mfhk_rk'] = icom.groupby('datadate')['pctOfComp_mfhk'].apply(yu.uniformed_rank)

icom['pctOfComp_bb_mf_rkdf'] = icom['pctOfComp_bb_rk'] - icom['pctOfSO_mf_rk']
icom['pctOfComp_bb_mf_rkdf_bk'] = icom.groupby('datadate')['pctOfComp_bb_mf_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10))

icom['pctOfComp_bb_mfhk_rkdf'] = icom['pctOfComp_bb_rk'] - icom['pctOfComp_mfhk_rk']
icom['pctOfComp_bb_mfhk_rkdf_bk'] = icom.groupby('datadate')['pctOfComp_bb_mfhk_rkdf'].
apply(lambda x: yu.pdqcut(x,bins=10))
icom['pctOfComp_bb_mfhk_rkdf_rk'] = icom.groupby('datadate')['pctOfComp_bb_mfhk_rkdf'].apply(yu.uniformed_rank)
#yu.create_cn_3x3(icom, ['pctOfComp_bb_mf_rkdf_bk'], 'pctOfComp_bb_mf_rkdf') # less mono -8 +3.5 +3
#yu.create_cn_3x3(icom, ['pctOfComp_bb_mfhk_rkdf_bk'], 'pctOfComp_bb_mfhk_rkdf') # less mono -7.5 +4

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['pctOfComp_bb_mfhk_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_mfhk_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.64 / -0.96


o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31')) & (icom['pctOfComp_bb_mfhk_rkdf_rk'].abs()>0.8)].\
            dropna(subset=['pctOfComp_bb_mfhk_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_mfhk_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #3.37 / -0.94

