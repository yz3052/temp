﻿#$%^&* pERN_cn_post_reversal.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 28 13:09:44 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime



### sd 

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['ticker', 'datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()
i_sd_dd = i_sd_dd[i_sd_dd>='2017-01-01']


### actual earning dates

i_ed = yu.get_sql('''select * from [CNDBPROD].[dbo].[CNINFO_ED_FORMAT]''' )

c_sh = i_ed['Ticker'].str[0].isin(['6'])
c_sz = i_ed['Ticker'].str[0].isin(['0','3'])
i_ed.loc[c_sh, 'ticker'] = i_ed.loc[c_sh, 'Ticker'] + '.SH'
i_ed.loc[c_sz, 'ticker'] = i_ed.loc[c_sz, 'Ticker'] + '.SZ'
i_ed['datadate_p1d'] = i_ed['DataDate']

i_ed = i_ed.drop(columns = ['Ticker', 'DataDate'])
i_ed = i_ed.sort_values('next_ped')
i_ed = i_ed.drop_duplicates(subset=['ticker','datadate_p1d'],keep='first')


### past return 

i_pastret = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet',
                            columns = ['ticker', 'datadate', 'twap1000_2c_bret','c2c_bret'])
i_pastret = i_pastret.sort_values(['ticker','datadate'])

i_pastret['twap1000_2c_bret_t1y'] = i_pastret.groupby('ticker').rolling(datetime.timedelta(days=365),on='datadate',min_periods=120)['twap1000_2c_bret'].mean().values
i_pastret['twap1000_2c_bret_t2w'] = i_pastret.groupby('ticker').rolling(datetime.timedelta(days=14),on='datadate',min_periods=5)['twap1000_2c_bret'].mean().values
i_pastret['twap1000_2c_bret_t2w_1d'] = i_pastret.groupby('ticker')['twap1000_2c_bret_t2w'].shift()
i_pastret['c2c_bret_t2w'] = i_pastret.groupby('ticker').rolling(datetime.timedelta(days=14),on='datadate',min_periods=5)['c2c_bret'].mean().values
i_pastret['c2c_bret_t2w_1d'] = i_pastret.groupby('ticker')['c2c_bret_t2w'].shift()


### ipo date

i_ipo = pw.get_ipo_date()


### abnormal

i_ab = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_abnormal_move.parquet')



### combine

icom = i_sd.merge(i_ed, on = ['ticker', 'datadate_p1d'], how = 'left')
icom = icom.merge(i_pastret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_ipo, on = ['ticker'], how = 'left')
icom = icom.merge(i_ab, on = ['ticker','datadate'], how = 'left')



# flg

icom['twap1000_2c_bret_t2w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t2w'].apply(yu.uniformed_rank)
icom['twap1000_2c_bret_t1y_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t1y'].apply(yu.
uniformed_rank)
icom['twap1000_2c_bret_t2w_1d_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t2w_1d'].apply(yu.uniformed_rank)

icom['flg_lowR_preed'] = np.nan
c1 = (icom['d2nexted']==1) & (icom['twap1000_2c_bret_t2w_1d_rk']<-0.8) 
c2 = ((icom['datadate'] - icom['ipo_date']).dt.days > 365) & (icom['abnml_cnt_t1q']<=5)
c3 = icom['twap1000_2c_bret_t1y_rk'] > 0.6
icom.loc[c1 & c2 & c3, 'flg_lowR_preed'] = 1
icom['sgnl_lowR_preed'] = icom.groupby('ticker')['flg_lowR_preed'].ffill(limit = 3)

#yu.create_cn_decay(icom, 'flg_lowR_preed')

icom['flg_lowR_preed2'] = np.nan
c1 = (icom['d2nexted']==1) & (icom['twap1000_2c_bret_t2w_1d_rk']<-0.4)
icom.loc[c1, 'flg_lowR_preed2'] = 1

#yu.create_cn_decay(icom, 'flg_lowR_preed2')



o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_lowR_preed','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_lowR_preed','BarrRet_CLIP_USD+1d', static_data = i_sd) # not working 0 pnl

t1 = o_1.groupby('ticker')['pnl_ac'].sum().sort_values()
yu.ta_plot(icom, '600733.SH',sgnl_tertiary='flg_lowR_preed')

