﻿#$%^&* pGraph_cn_cpt_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 13 07:14:21 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu



# this studies vertex connectedness 
# main distance variable: shared concept cnt



### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()





### get china scope

i_stcept = pd.read_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\concept.parquet',
                            columns = ['conceptCode','chineseName','newsId','Relevance'])
i_stcept = i_stcept.drop_duplicates()


i_company = pd.read_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\company.parquet',
                            columns = ['stockCode','newsId'])
i_company = i_company[i_company['stockCode'].str.contains('\d{6}') &\
                      i_company['stockCode'].str.contains('S[HZ]') &\
                      i_company['stockCode'].str[0].isin(['0','3','6']) ]
i_company['ticker'] = i_company['stockCode'].str.split('_').str[0]+'.'+i_company['stockCode'].str.split('_').str[1]
i_company = i_company.drop(columns=['stockCode'])
i_company = i_company.drop_duplicates(subset = ['ticker','newsId'])

          
i_info = pd.read_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\info.parquet',
                         columns = ['newsId','newsTs'])
i_info = i_info.drop_duplicates()


i_news_com = i_company.merge(i_info, on = ['newsId'], how = 'left')
i_news_com = i_news_com.merge(i_stcept, on = ['newsId'], how = 'inner')
i_news_com['datadate'] = pd.to_datetime(pd.to_datetime(i_news_com['newsTs']).dt.date)+pd.to_timedelta('1 day')




### daily loop: generate concept list per date per ticker 


o_tk_cpt_map = []

for dt in pd.date_range(start = '2016-01-01', end = '2021-11-01'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    # select data 
    t_cpt = i_news_com[(i_news_com['datadate']<=dt) & (i_news_com['datadate']>=dt-pd.to_timedelta('365 days'))]
    
    t_tk_cpt_map = t_cpt.groupby('ticker')['conceptCode'].apply(lambda x: x.unique().tolist())
    t_tk_cpt_map = t_tk_cpt_map.reset_index()
    t_tk_cpt_map['datadate'] = dt
    
    o_tk_cpt_map.append(t_tk_cpt_map)
    
o_tk_cpt_map = pd.concat(o_tk_cpt_map, axis = 0)
o_tk_cpt_map['conceptCodeSet'] = o_tk_cpt_map['conceptCode'].apply(lambda x: set(x))


### Loop: shared concept within HK uni

o_shared_cpt_cnt = []

for dt in pd.date_range(start
 = '2016-02-01', end = '2021-11-01', freq='W'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    t_sd = i_sd[i_sd['datadate']==i_sd_dd[i_sd_dd<=dt].max()]
    t_tk_cpt_map = o_tk_cpt_map[o_tk_cpt_map['datadate']==dt]
    t_tk_cpt_map = t_tk_cpt_map[t_tk_cpt_map['ticker'].isin(t_sd['ticker'].tolist())]

    
    t_tkPair_cptSet = pd.DataFrame((t_tk_cpt_map['conceptCodeSet'].values[:, None] & t_tk_cpt_map['conceptCodeSet'].values))
    
    t_tkPair_cptCnt = t_tkPair_cptSet.applymap(lambda x: len(x) )
    t_tkPair_cptCnt.columns = t_tk_cpt_map['ticker'].values
    t_tkPair_cptCnt.index = t_tk_cpt_map['ticker'].values
    t_tkPair_cptCnt.values[[np.arange(t_tkPair_cptCnt.shape[0])]*2] = 0
    
    t_sum1 = t_tkPair_cptCnt.mean(axis = 1)
    t_sum1 = t_sum1.reset_index()
    t_sum1.columns = ['ticker','shared_cpt_cnt']
    
    t_sum2 = t_tkPair_cptCnt.max(axis = 1)
    t_sum2 = t_sum2.reset_index()
    t_sum2.columns = ['ticker','shared_cpt_tkmax']
    
    t_sum = t_sum1.merge(t_sum2, on = ['ticker'], how = 'outer')    
    t_sum['shared_scp_allmax'] = t_sum2['shared_cpt_tkmax'].max()
    t_sum['datadate'] = dt
    
    o_shared_cpt_cnt.append(t_sum)

o_shared_cpt_cnt = pd.concat(o_shared_cpt_cnt, axis = 0)
o_shared_cpt_cnt = o_shared_cpt_cnt.sort_values('datadate')

#o_shared_cpt_cnt.to_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_cpt_01_o_shared_cpt_cnt.parquet')
#o_shared_cpt_cnt = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_cpt_01_o_shared_cpt_cnt.parquet')


### combine 

icom = pd.merge_asof(i_sd, o_shared_cpt_cnt, by='ticker', on='datadate')

icom['shared_cpt_cnt_bk'] = icom.groupby('datadate')['shared_cpt_cnt'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['shared_cpt_cnt_dv_tkmax'] = icom['shared_cpt_cnt'].divide(icom['shared_cpt_tkmax'])
icom['shared_cpt_cnt_dv_tkmax_bk'] = icom.groupby('datadate')['shared_cpt_cnt_dv_tkmax'].apply(lambda x: yu.pdqcut(x,bins=10)).values

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['shared_cpt_cnt_orth'] = icom.groupby('datadate')[COLS+['shared_cpt_cnt']].apply(lambda x: yu.orthogonalize_cn(x['shared_cpt_cnt'], x[COLS])).values
icom['shared_cpt_cnt_orth_bk'] = icom.groupby('datadate')['shared_cpt_cnt_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['shared_cpt_cnt_orth_rk'] = icom.groupby('datadate')['shared_cpt_cnt_orth'].apply(yu.uniformed_rank).values

icom['cpt_neg_sgnl'] = np.nan
icom.loc[icom['shared_cpt_cnt
_orth_rk']<-0.8, 'cpt_neg_sgnl'] = -1
icom['cpt_neg_sgnl'] = icom.groupby('ticker')['cpt_neg_sgnl'].ffill(limit=5)

yu.create_cn_3x3(icom, ['shared_cpt_cnt_bk'], 'shared_cpt_cnt') # random
yu.create_cn_3x3(icom, ['shared_cpt_cnt_dv_tkmax_bk'], 'shared_cpt_cnt_dv_tkmax_bk') #
yu.create_cn_3x3(icom, ['shared_cpt_cnt_orth_bk'], 'shared_cpt_cnt_orth') # -2.5 +1.5 -0.5

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cpt_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cpt_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.46 / 0.95

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['csi300_flag']==1)].\
            dropna(subset=['cpt_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cpt_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.27 /1.02
