﻿#$%^&* pAlphaCapture_cn_etl.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Jun  1 13:05:31 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import os 
import json
import xml.etree.ElementTree as ET


### UBS 1600 ET

i_ubs_1600_ET = []

for f in ['2019', '2020', '2021', '2022']:
    for f2 in os.listdir(os.path.join(r'Z:\NoahResearch\Prod\UBS\Data\Alpha_Capture_Real_Time', f)):
        for f3 in os.listdir(os.path.join(r'Z:\NoahResearch\Prod\UBS\Data\Alpha_Capture_Real_Time', f, f2)):
            files = os.listdir(os.path.join(r'Z:\NoahResearch\Prod\UBS\Data\Alpha_Capture_Real_Time', f, f2, f3))
            if len(files) == 1:
                file = files[0]
            elif len(files) == 0:
                print('_', end='')
                continue
            else:
                try:
                    file = max([i for i in files if i[-6:]<='160000'])            
                except ValueError:
                    continue
            t_data = pd.read_csv(os.path.join(r'Z:\NoahResearch\Prod\UBS\Data\Alpha_Capture_Real_Time', f, f2, f3, file), sep = '|')
            t_data['source'] = 'ubs'
            t_data['datadate'] = pd.to_datetime(f+'-'+f2+'-'+f3)
            i_ubs_1600_ET.append(t_data)
            print('.', end='')
            

i_ubs_1600_ET = pd.concat(i_ubs_1600_ET, axis = 0)
i_ubs_1600_ET['authorId'] = i_ubs_1600_ET['authorId'].astype(str).str.replace('.0','')
i_ubs_1600_ET['instrumentId'] = i_ubs_1600_ET['instrumentId'].astype(str).str.replace('.0','')
i_ubs_1600_ET['sedol'] = i_ubs_1600_ET['sedol'].astype(str).str.replace('.0','')
i_ubs_1600_ET.to_parquet(r'S:\Data\China Data Hunt\cache\pAlphaCapture_cn_etl_ubs_1600_et.parquet')




### UBS EOD ET

i_ubs_eod_ET = []

for f in ['2019', '2020', '2021', '2022']:
    for f2 in os.listdir(os.path.join(r'Z:\NoahResearch\Prod\UBS\Data\Alpha_Capture_Real_Time', f)):
        for f3 in os.listdir(os.path.join(r'Z:\NoahResearch\Prod\UBS\Data\Alpha_Capture_Real_Time', f, f2)):
            files = os.listdir(os.path.join(r'Z:\NoahResearch\Prod\UBS\Data\Alpha_Capture_Real_Time', f, f2, f3))
            if len(files) == 1:
                file = files[0]
            elif len(files) == 0:
                print('_', end='')
                continue
            else:
                try:
                    file = max(files)
                except ValueError:
                    continue
            t_data = pd.read_csv(os.path
.join(r'Z:\NoahResearch\Prod\UBS\Data\Alpha_Capture_Real_Time', f, f2, f3, file), sep = '|')
            t_data['source'] = 'ubs'
            t_data['datadate'] = pd.to_datetime(f+'-'+f2+'-'+f3)
            i_ubs_eod_ET.append(t_data)
            print('.', end='')
            
i_ubs_eod_ET = pd.concat(i_ubs_eod_ET, axis = 0)
i_ubs_eod_ET['authorId'] = i_ubs_eod_ET['authorId'].astype(str).str.replace('.0','')
i_ubs_eod_ET['instrumentId'] = i_ubs_eod_ET['instrumentId'].astype(str).str.replace('.0','')
i_ubs_eod_ET['sedol'] = i_ubs_eod_ET['sedol'].astype(str).str.replace('.0','')
i_ubs_eod_ET.to_parquet(r'S:\Data\China Data Hunt\cache\pAlphaCapture_cn_etl_ubs_eod_et.parquet')


### GS
# update time is ET, update time is consistent with MDW folders

i_gs = []
for y in ['2018','2019', '2020', '2021', '2022']:
    for r,p,fs in os.walk(os.path.join(r'Z:\GoldmanSachs\2848\TradeIdeas', y)):
        for f in fs:
            if ('gs_tradeideas' in f.lower()) and f.endswith('json'):
                t_json = json.load(open(os.path.join(r, f)))
                t_data = pd.DataFrame(t_json['data'])
                i_gs.append(t_data)

i_gs = pd.concat(i_gs, axis = 0)
i_gs.to_parquet(r'S:\Data\China Data Hunt\cache\pAlphaCapture_cn_etl_gs.parquet')



### MS
    
i_ms = []

d = r'Z:\MorganStanley\TradeIdeas\2018\10\05\idea_3e726da3-02d4-43b7-b082-ea37f5772e52_close_20181005_164758.xml'

xmlns = '{http://xml.ms.com/ns/clink/tide/external}'

tree = ET.parse(d)
tradeideas = tree.getroot()

tradeideas.findall('.')

for tradeidea in tradeideas:
    for component in tradeidea.find(xmlns+'components').findall(xmlns+'component'):
        row_data = {}
        
        row_data['component_asset'] = component.find(xmlns+'asset').attrib['type']
        row_data['component_sedol'] = component.find(xmlns+'asset').find(xmlns+'sedol').text
        row_data['component_bbgid'] = component.find(xmlns+'asset').find(xmlns+'bloombergId').text
        row_data['component_ric'] = component.find(xmlns+'asset').find(xmlns+'ric').text
        
        for comopnent_detail in component.findall('*'):
            if comopnent_detail.tag != xmlns+'asset':
                row_data[comopnent_detail.replace(xmlns,'')] = comopnent_detail.text
            print (comopnent_detail.tag)
            break
        
        
        
        for i in component.iter():
            
            print(i.tag.replace(xmlns,''), i.attrib)
    
    for component in tradeidea.find('components'):
        print(componen
t.attrib)
    break
    
    for 
    [item for item in tradeidea.iter()]

for item in root.iter('body'):
    print(item.tag)
    print(item.attrib)
    
    
import xmltodict




### TIM PROD - data quality check, identiy all columns

for r, p, fs in os.walk(r'Z:\TIMgroup\messages\Global'):
    for f in fs:
        if f.endswith('txt'):
            try:
                t_data = json.load(open(os.path.join(r, f),encoding='latin'))
            except json.JSONDecodeError:
                print(r+' '+f)
                continue
            # check keys under 'data' ---- yes these are identical across all files
            #for row in t_data:
            #    if sorted(list(row['data'].keys())) != ['comment', 'id', 'idea', 'origin', 'published_at', 'timestamp']:
            #        raise Exception()
            
            # check keys under 'data' -> 'idea'
            for row in t_data:
                if not set(row['data']['idea'].keys()).issubset(set(['author', 'close_timestamp', 'conviction', 'open_timestamp', 'recommendations', 'size', 'state', 'stop_loss', 'time_horizon', 'web_link'])):
                    raise Exception()



### TIM PROD 

i_tim_prod = []

for y in ['2019','2020','2021','2022','history']:
    for r, p, fs in os.walk(os.path.join(r'Z:\TIMgroup\messages\Global', y)):
        print('.',end='')
        for f in fs:
            if f.endswith('txt'):
                try:
                    t_data = json.load(open(os.path.join(r, f),encoding='latin'))
                except json.JSONDecodeError:
                    continue
                for row in t_data:
                    for rec in row['data']['idea']['recommendations']:
                            
                        rec_data = {}
                        rec_data['event_number'] = row['event_number']
                        rec_data['event_type'] = row['event_type']
                        rec_data['event_id'] = row['data']['id']
                        rec_data['comment'] = row['data']['comment']
                        rec_data['origin'] = row['data']['origin']
                        rec_data['published_at'] = row['data']['published_at']
                        rec_data['timestamp'] = row['data']['timestamp']
                        rec_data['author_id'] =             row['data']['idea']['author']['id']
                        rec_data['author_company_name'] =   row['data']['idea']['author']['company']['name']
                        rec_data['author_company_id'] =     r
ow['data']['idea']['author']['company']['id']
                        rec_data['close_timestamp'] =       row['data']['idea']['close_timestamp']
                        rec_data['conviction'] =            row['data']['idea']['conviction']
                        rec_data['open_timestamp'] =        row['data']['idea']['open_timestamp']
                        rec_data['state'] =                 row['data']['idea']['state']
                        try:
                            rec_data['size'] =              row['data']['idea']['size']
                        except:
                            pass
                        rec_data['stoploss'] =              row['data']['idea']['stop_loss']
                        rec_data['time_horizon'] =          row['data']['idea']['time_horizon']
                        rec_data['web_link'] =              row['data']['idea']['web_link']
                        
                        rec_data['rec_curr_investment_value'] = rec['current_investment']['value']
                        rec_data['rec_curr_investment_crcy'] =  rec['current_investment']['currency']
                        rec_data['rec_direction'] =             rec['direction']
                        rec_data['rec_instrument_bbg'] =        rec['instrument']['bloomberg_ticker']
                        rec_data['rec_instrument_ric'] =        rec['instrument']['ric']
                        rec_data['rec_instrument_id'] =         rec['instrument']['public_id']
                        rec_data['rec_id'] =                    rec['public_id']
                        try:
                            rec_data['rec_tp'] =                rec['target_price']['value']
                        except: 
                            pass
                        try:
                            rec_data['rec_tp_curr'] =           rec['target_price']['currency']
                        except: 
                            pass
                        
                        i_tim_prod.append(rec_data)
                        
i_tim_prod = pd.DataFrame(i_tim_prod)


i_tim_prod.to_parquet(r'S:\Data\China Data Hunt\cache\pAlphaCapture_cn_etl_tim.parquet')







### BBG 
# xml format - difficult


for y in ['2018','2019','2020','2021','2022']:
    for r, p, fs in os.walk(os.path.join(r'Z:\Bloomberg\TMSG', y)):
        
        
d = r'Z:\Bloomberg\TMSG\2021\05\05\TradeIdeaList_20210505_1.xml'


