﻿#$%^&* pWIND_strat_mutualfund_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 17 06:51:45 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import datetime


# this studies mutual funds holding (4 times a year, based on estimates)
# this also studies the delta metrics based on the estimated q mutual funds holdings



### features of fund: turnover


### features of fund: rating <done>
# to be merge_asof'ed into mutual fund holding data

i_fund_rating = yu.get_sql('''select s_info_windcode as ticker_fund, rating_ann_date as datadate,
                           rptdate,
                           starlevel, rating_interval, rating_gagency, rating_type 
                           from wind.dbo.CMFundThirdPartyRating
                           where rating_ann_date is not null''')
i_fund_rating['datadate'] = pd.to_datetime(i_fund_rating['datadate'], format='%Y%m%d')
i_fund_rating = i_fund_rating.groupby(['ticker_fund','datadate'])['starlevel'].mean().reset_index()




### features of fund: award <done>

i_fund_award = yu.get_sql(''' select a.s_info_windcode, a.s_info_compcode, 
                          a.s_info_sectypename, a.s_info_name, 
                          b.s_info_award_code, b.opdate 
                          from wind.dbo.WindCustomCode a 
                          inner join wind.dbo.COMPANYAWARD b 
                          on a.s_info_compcode = b.S_INFO_COMPCODE  ''')
i_fund_award['datadate'] = pd.to_datetime(i_fund_award['opdate'].dt.date)

### features of fund: style <done>
i_mf_style = yu.get_sql('''select f_info_windcode, 
                        f_info_firstinvesttype, f_info_firstinveststyle,
                        f_info_setupdate, f_info_issuedate,
                        f_info_benchmark 
                        from wind.dbo.ChinaMutualFundDescription''')

i_mf_style = i_mf_style[(i_mf_style['f_info_firstinvesttype']!='债券型')&\
                        (i_mf_style['f_info_firstinvesttype']!='货币市场型')&\
                        (i_mf_style['f_info_firstinveststyle']!='被动指数型')]
i_mf_style['f_info_issuedate'] = i_mf_style['f_info_issuedate'].fillna(np.nan)
i_mf_style['f_info_issuedate'] = pd.to_datetime(i_mf_style['f_info_issuedate'], format='%Y%m%d', errors = 'coerce')
i_mf_style['f_info_setupdate'] = i_mf_style['f_info_setupdate'].fillna(np.nan)
i_mf_style['f_info_setupdate'] = pd.to_datetime(i_mf_style['f_info_setupdate'], format='%Y%m%d', errors = 'c
oerce')





#------------------------------------------------------------------------------


### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['ticker', 'datadate'])
i_sd['V_t30d'] = i_sd.groupby('ticker').rolling(30)['V_l1d'].mean().values
i_sd = i_sd.sort_values('datadate')

i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d','V_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','csi300_flag']]

### ed
i_ed = pw.get_wind_ed_calendar_pit()


### so

i_so = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate, 
               FLOAT_A_SHR_TODAY*10000 as so 
               from wind_prod.dbo.AShareEODDerivativeIndicator 
               where trade_Dt > '20160101' ''')
i_so['datadate'] = pd.to_datetime(i_so['datadate'], format = '%Y%m%d')


### mutual fund holding (quarterly estimate)

i_mf = pw.get_wind_holding_mf_q_est()
i_mf = i_mf.sort_values('datadate')


### mutual fund delta metrics 

i_delta_metrics = pw.get_wind_holding_mf_q_delta_metrics()
i_delta_metrics = i_delta_metrics.sort_values('datadate')

i_delta_metrics = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_wind_holding_mf_q_delta_metrics_sum_active.parquet')
i_delta_metrics = i_delta_metrics.sort_values('datadate')


### get flow data
i_flow = yu.get_sql('''select S_INFO_WINDCODE as ticker, trade_dt as datadate, 
                    BUY_VALUE_SMALL_ORDER - SELL_VALUE_SMALL_ORDER as retail_net_amt,
                    BUY_VALUE_SMALL_ORDER as retail_buy 
                    from wind.dbo.ASHAREMONEYFLOW order by ticker, datadate''')
i_flow['datadate'] = pd.to_datetime(i_flow['datadate'], format='%Y%m%d')

i_flow['retail_net_amt_t20d'] = i_flow.groupby('ticker').rolling(20)['retail_net_amt'].sum().values
i_flow['retail_net_amt_t60d'] = i_flow.groupby('ticker').rolling(60)['retail_net_amt'].sum().values
i_flow['retail_buy_t20d'] = i_flow.groupby('ticker').rolling(20)['retail_buy'].sum().values
i_flow['retail_buy_t60d'] = i_flow.groupby('ticker').rolling(60)['retail_buy'].sum().values




### concentration
# datadate is T-1 or T?

i_conc = yu.get_sql('''select datadate as datadate_p1d, ticker, conc_all_fit from [CNDBPROD].[dbo].[F005_MF_CN_FORMAT] ''')
c_sh = i_conc['ticker'].str[0].isin(['6'])
c_sz = i_conc['ticker'].str[0].isin(['0','3'])
i_conc.loc
[c_sh, 'ticker'] = i_conc.loc[c_sh, 'ticker'] + '.SH'
i_conc.loc[c_sz, 'ticker'] = i_conc.loc[c_sz, 'ticker'] + '.SZ'




### combine

icom = pd.merge_asof(i_sd, i_mf, by = 'ticker', on = 'datadate', tolerance = pd.to_timedelta('180 days'))
icom = icom.merge(i_delta_metrics, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(i_ed, on = ['ticker','datadate'], how = 'left')

icom = icom.sort_values(['ticker','datadate'])

icom = icom.merge(i_so, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_flow, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_conc, on = ['ticker', 'datadate_p1d'], how = 'left')

icom['rk01_zfill'] = icom['rk01'].fillna(0)
icom['rk01active_zfill'] = icom['rk01active'].fillna(0)
icom['fundNum_zfill'] = icom['fundNum'].fillna(0)




### 

icom['pctOfSO_rk'] = icom.groupby('datadate')['pctOfSO'].apply(yu.uniformed_rank).values
icom['pctOfSO_bk'] = icom.groupby('datadate')['pctOfSO'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['pctOfSO_bk'], 'pctOfSO') # -6 +2, 

icom['pctOfSO_active_rk'] = icom.groupby('datadate')['pctOfSO_active'].apply(yu.uniformed_rank).values
icom['pctOfSO_active_bk'] = icom.groupby('datadate')['pctOfSO_active'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['pctOfSO_active_secrk'] = icom.groupby(['datadate','GSECTOR'])['pctOfSO_active'].apply(yu.uniformed_rank).values
icom['pctOfSO_active_secbk'] = icom.groupby(['datadate','GSECTOR'])['pctOfSO_active'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['pctOfSO_active_bk'], 'pctOfSO_active') # -6 +2
yu.create_cn_3x3(icom, ['pctOfSO_active_secbk'], 'pctOfSO_active') # -5 +2

icom['fundNum_rk'] = icom.groupby('datadate')['fundNum'].apply(yu.uniformed_rank).values
icom['fundNum_secrk'] = icom.groupby(['datadate','GSECTOR'])['fundNum'].apply(yu.uniformed_rank).values
icom['fundNum_bk'] = icom.groupby('datadate')['fundNum'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['fundNum_bk'], 'fundNum') # -5 +1

icom['fundNum_zfill_rk'] = icom.groupby('datadate')['fundNum_zfill'].apply(yu.uniformed_rank).values
icom['fundNum_zfill_bk'] = icom.groupby('datadate')['fundNum_zfill'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['fundNum_zfill_bk'], 'fundNum_zfill') # -5 +1

icom['fundActiveNum_rk'] = icom.groupby('datadate')['fundActiveNum'].apply(yu.uniformed_rank).values
icom['fundActiveNum_bk'] = icom.groupby('datadate')['fundActiveNum'].apply(lambda x: yu.
pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['fundActiveNum_bk'], 'fundActiveNum') # -5 +1

icom['fundActive4sNum_rk'] = icom.groupby('datadate')['fundActive4sNum'].apply(yu.uniformed_rank).values
icom['fundActive4sNum_bk'] = icom.groupby('datadate')['fundActive4sNum'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['fundActive4sNum_bk'], 'fundActive4sNum') # 0 +1.5

icom['fundActiveUpperhalfNum_rk'] = icom.groupby('datadate')['fundActiveUpperhalfNum'].apply(yu.uniformed_rank).values
icom['fundActiveUpperhalfNum_bk'] = icom.groupby('datadate')['fundActiveUpperhalfNum'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['fundActiveUpperhalfNum_bk'], 'fundActiveUpperhalfNum') # -3 +1

icom['rk01_rk'] = icom.groupby('datadate')['rk01'].apply(yu.uniformed_rank).values
icom['rk01_bk'] = icom.groupby('datadate')['rk01'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['rk01_bk'], 'rk01') # -2 +2

icom['rk01active_rk'] = icom.groupby('datadate')['rk01active'].apply(yu.uniformed_rank).values
icom['rk01active_bk'] = icom.groupby('datadate')['rk01active'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['rk01active_bk'], 'rk01active') #-2 +1.5


icom['rk01_zfill_rk'] = icom.groupby('datadate')['rk01_zfill'].apply(yu.uniformed_rank).values
icom['rk01_zfill_bk'] = icom.groupby('datadate')['rk01_zfill'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['rk01_zfill_bk'], 'rk01_zfill') # -2 +2

icom['rk01active_zfill_rk'] = icom.groupby('datadate')['rk01active_zfill'].apply(yu.uniformed_rank).values
icom['rk01active_zfill_bk'] = icom.groupby('datadate')['rk01active_zfill'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['rk01active_zfill_bk'], 'rk01active_zfill') # -2 +1



o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['pctOfSO_active_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfSO_active_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.76/2.15, 1.62bp/d, 2.1e7
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['pctOfSO_active_rk']>0)].\
            dropna(subset=['pctOfSO_active_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfSO_active_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.36/1.9, 1.38bp/d, 1.2e7
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['pctOfSO_active_rk']<0)].\
        
    dropna(subset=['pctOfSO_active_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfSO_active_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.84/2.15, 2.1bp/d, 1e7

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['pctOfSO_active_secrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfSO_active_secrk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.67/2.04, 1.55bp/d, 2.1e7

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['pctOfSO_rk']<0)].\
            dropna(subset=['pctOfSO_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfSO_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.89/2.21, 2.2bp/d, 1e7

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['fundNum_zfill_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'fundNum_zfill_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #3.26/2.65, 1.24bp/d, 1.9e7

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['fundNum_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'fundNum_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.29/2.17, 1.22bp/d, 1.9e7
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')&(icom['fundNum_rk']<0)].\
            dropna(subset=['fundNum_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'fundNum_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.04/2.49, 2.23bp/d, 0.9e7 ###!!!

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')&(icom['fundNum_rk'].between(-1.0,-0.8))].\
            dropna(subset=['fundNum_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'fundNum_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)
# 2021 has no drawdown if we only trade bottom decile

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')&(icom['conc_rk'].between(-1, -0.5 ))].\
            dropna(subset=['fundNum_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'fundNum_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # not working

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2021-12-31')&(icom2['fundNum_rk']<0)&(icom2['pressure_rk'].between(-0.5,1))].\
            dropna(subset=['fundNum_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
          
  'fundNum_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['fundNum_secrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'fundNum_secrk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.3/2.66, 1.25bp/d, 2.0e7


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['fundActiveNum_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'fundActiveNum_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.29 / 2.67, 1.21bp/d, 1.9e7
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['fundActiveNum_rk']>0)].\
            dropna(subset=['fundActiveNum_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'fundActiveNum_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.74 / 2.21, 0.87bp/d, 1.0e7




o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['rk01active_zfill_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'rk01active_zfill_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['rk01active_zfill_rk']>0)].\
            dropna(subset=['rk01active_zfill_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'rk01active_zfill_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['rk01active_zfill_rk']<0)].\
            dropna(subset=['rk01active_zfill_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'rk01active_zfill_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))&(icom['rk01active_zfill_rk']>0)].\
            dropna(subset=['rk01active_zfill_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'rk01active_zfill_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #



### delta metrics

icom['flag_upw_bk'] = icom.groupby('datadate')['flag_upw'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['flag_dnw_bk'] = icom.groupby('datadate')['flag_dnw'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['net_upw'] = icom['flag_upw'] - icom['flag_dnw']
icom['net_upw_bk'] = icom.groupby('datadate')['net_upw'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['flag_upw_
bk'],'flag_upw') # less mono, -5, +2, +1; active: -4,+2,+1
yu.create_cn_3x3(icom, ['net_upw_bk'],'net_upw') # less mono, +1, -3  <--- this is werid!
yu.create_cn_3x3(icom, ['flag_dnw_bk'],'flag_dnw') # less mono, -5, +2.5, +0.5; active: less mono: -4.5 +1 0 1

icom['flag_gupw'] = icom['flag_upw'] + icom['flag_new']
icom['flag_gupw_bk'] = icom.groupby('datadate')['flag_gupw'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['flag_gdnw'] = icom['flag_dnw'] + icom['flag_del']
icom['flag_gdnw_bk'] = icom.groupby('datadate')['flag_gdnw'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['net_gupw'] = icom['flag_upw'] + icom['flag_new'] - icom['flag_dnw'] + icom['flag_del']
icom['net_gupw_bk'] = icom.groupby('datadate')['net_gupw'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['flag_gupw_bk'],'flag_gupw') # mono, -5, +1; active: -5, +1
yu.create_cn_3x3(icom, ['flag_gdnw_bk'],'flag_gdnw') # less mono, -4.5, +1
yu.create_cn_3x3(icom, ['net_gupw_bk'],'net_gupw') # random

icom['flag_new_bk'] = icom.groupby('datadate')['flag_new'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['flag_del_bk'] = icom.groupby('datadate')['flag_del'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['flag_new_bk'],'flag_new') # mono, -3, +1; active: less mono: -2, +2
yu.create_cn_3x3(icom, ['flag_del_bk'],'flag_del') # less mono, -2, +1.5, 0; active: random

icom['flag_newTop10_bk'] = icom.groupby('datadate')['flag_newTop10'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['flag_delTop10_bk'] = icom.groupby('datadate')['flag_delTop10'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['flag_newTop10_bk'],'flag_newTop10') # random
yu.create_cn_3x3(icom, ['flag_delTop10_bk'],'flag_delTop10') # less mono, -4.5, +1


icom['wChg_pctOfMFSTK_inc0_bk'] = icom.groupby('datadate')['wChg_pctOfMFSTK_inc0'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['wChg_pctOfMFSTK_exc0_bk'] = icom.groupby('datadate')['wChg_pctOfMFSTK_exc0'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['wChg_pctOfMFSTK_inc0_bk'],'wChg_pctOfMFSTK_inc0') # V-shaped, 0,-2,+2; active: v-shaped
yu.create_cn_3x3(icom, ['wChg_pctOfMFSTK_exc0_bk'],'wChg_pctOfMFSTK_exc0') # random; active: less mono: 0.5 1.5 -2.5


icom['wChg_pctOfMFSTK_inc0_abs_bk'] = icom.groupby('datadate')['wChg_pctOfMFSTK_inc0_abs'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['wChg_pctOfMFSTK_exc0_abs_bk'] = icom.groupby('datadate')['wChg_pctOfMFSTK_exc0_abs'].ap
ply(lambda x: yu.pdqcut(x,bins=10)).values
icom['wChg_pctOfMFSTK_exc0_abs_rk'] = icom.groupby('datadate')['wChg_pctOfMFSTK_exc0_abs'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icom, ['wChg_pctOfMFSTK_inc0_abs_bk'],'wChg_pctOfMFSTK_inc0_abs') #mono, -5, +1.5; active: similar
yu.create_cn_3x3(icom, ['wChg_pctOfMFSTK_exc0_abs_bk'],'wChg_pctOfMFSTK_exc0_abs') #mono, -6, +1.5; active: similar

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['wChg_pctOfMFSTK_exc0_abs_rk']>0)].\
            dropna(subset=['wChg_pctOfMFSTK_exc0_abs_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'wChg_pctOfMFSTK_exc0_abs_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.83/1.44, 0.77bp/d, 1.25e7
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['wChg_pctOfMFSTK_exc0_abs_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'wChg_pctOfMFSTK_exc0_abs_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.39/1.91, 1.16bp/d, 2.5e7
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['wChg_pctOfMFSTK_exc0_abs_rk']<0)&(icom['csi300_flag']==1)].\
            dropna(subset=['wChg_pctOfMFSTK_exc0_abs_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'wChg_pctOfMFSTK_exc0_abs_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.07/0.88, 2.85bp/d, 1.2e6

 
### turnover

icom['wChg_pctOfMFSTK_exc0_abs_t20d'] = icom.groupby('ticker').rolling(20)['wChg_pctOfMFSTK_exc0_abs'].mean().values
icom['wChg_pctOfMFSTK_exc0_abs_t20d_rk'] = icom.groupby('datadate')['wChg_pctOfMFSTK_exc0_abs_t20d'].apply(yu.uniformed_rank).values

icom['turnover'] = icom['V_l1d'].divide(icom['so'])
icom['turnover_t20d'] = icom.groupby('ticker').rolling(20)['turnover'].mean().values
icom['turnover_t20d_rk'] = icom.groupby('datadate')['turnover_t20d'].apply(yu.uniformed_rank).values

icom['mf_m_turnover_rkdf'] = icom['wChg_pctOfMFSTK_exc0_abs_t20d_rk'] - icom['turnover_t20d_rk']
icom['mf_m_turnover_rkdf_rk'] = icom.groupby('datadate')['mf_m_turnover_rkdf'].apply(yu.uniformed_rank).values
icom['mf_m_turnover_rkdf_t5d'] = icom.groupby('ticker').rolling(5)['mf_m_turnover_rkdf'].mean().values
icom['mf_m_turnover_rkdf_t5d_bk'] = icom.groupby('datadate')['mf_m_turnover_rkdf_t5d'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['mf_m_turnover_rkdf_t5d_rk'] = icom.groupby('datadate')['mf_m_turnover_rkdf_t5d'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(ico
m, ['mf_m_turnover_rkdf_t5d_bk'], 'mf_m_turnover_rkdf_t5d') # -4, +2, 0

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2016-01-01','2020-12-31'))].\
            dropna(subset=['mf_m_turnover_rkdf_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mf_m_turnover_rkdf_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.19/1.61, 1.05bp/d, 2.0e7

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2016-01-01','2020-12-31'))&(icom['bd2e'].between(10,200)&icom['bdae'].between(10,1000))].\
            dropna(subset=['mf_m_turnover_rkdf_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mf_m_turnover_rkdf_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # not working 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2016-01-01','2020-12-31'))].\
            dropna(subset=['mf_m_turnover_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mf_m_turnover_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.21/1.6,1.07bp/d, 2.0e7


### high-MF-holding tickers with very low return

icom['bret_t20d'] = icom.groupby('ticker').rolling(20)['BarrRet_CLIP_USD-1d'].mean().values
icom['bret_t20d_rk'] = icom.groupby('datadate')['bret_t20d'].apply(yu.uniformed_rank).values

c1 = (icom['bret_t20d_rk']<-0.9) & (icom['pctOfSO_rk']>0.9)

icom['high_mf_low_ret_sgnl'] = np.nan
icom.loc[c1, 'high_mf_low_ret_sgnl'] = -1
icom['high_mf_low_ret_sgnl'] = icom.groupby('ticker')['high_mf_low_ret_sgnl'].ffill(limit = 10)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2016-01-01','2020-12-31'))].\
            dropna(subset=['high_mf_low_ret_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'high_mf_low_ret_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # not working; 


### lots of weight increase with very low return
# hopefully in 1q timespan

icom['bret_t20d'] = icom.groupby('ticker').rolling(20)['BarrRet_CLIP_USD-1d'].mean().values
icom['bret_t20d_rk'] = icom.groupby('datadate')['bret_t20d'].apply(yu.uniformed_rank).values
icom['bret_t60d'] = icom.groupby('ticker').rolling(60)['BarrRet_CLIP_USD-1d'].mean().values
icom['bret_t60d_rk'] = icom.groupby('datadate')['bret_t60d'].apply(yu.uniformed_rank).values

icom['flag_gupw'] = icom['flag_upw'] + icom['flag_new']
icom['flag_gupw_rk'] = icom.groupby('datadate')['flag_gupw'].apply(yu.uniformed_rank).values

c1 = (icom['bret_t60d_rk']<-0.8) & (icom['flag_gupw_rk']>0.8)

ic
om['high_upw_low_ret_sgnl'] = np.nan
icom.loc[c1, 'high_upw_low_ret_sgnl'] = 1
icom['high_upw_low_ret_sgnl'] = icom.groupby('ticker')['high_upw_low_ret_sgnl'].ffill(limit = 120)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2016-01-01','2020-12-31'))].\
            dropna(subset=['high_upw_low_ret_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'high_upw_low_ret_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # not working; 




### high pctOfMFSTK

icom['pctOfMFSTK_mean_bk'] = icom.groupby('datadate')['pctOfMFSTK_mean'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['pctOfMFSTK_median_bk'] = icom.groupby('datadate')['pctOfMFSTK_median'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['pctOfMFSTK_dv_std_bk'] = icom.groupby('datadate')['pctOfMFSTK_dv_std'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['pctOfMFSTK_mean_bk'], 'pctOfMFSTK_mean') # mono -4 +1
yu.create_cn_3x3(icom, ['pctOfMFSTK_median_bk'], 'pctOfMFSTK_median') # mono -3 +2
yu.create_cn_3x3(icom, ['pctOfMFSTK_dv_std_bk'], 'pctOfMFSTK_dv_std') # less mono -0.75 +0.75 0.25



### retail sell, MF weight up

icom['flag_gupw'] = icom['flag_upw'] + icom['flag_new']
icom['flag_gupw_rk'] = icom.groupby('datadate')['flag_gupw'].apply(yu.uniformed_rank).values
icom['retail_net_amt_t60d_rk'] = icom.groupby('datadate')['retail_net_amt_t60d'].apply(yu.uniformed_rank).values

icom['gupw_retail_rkdf'] = icom['flag_gupw_rk'] - icom['retail_net_amt_t60d_rk']
icom['gupw_retail_rkdf_bk'] = icom.groupby('datadate')['gupw_retail_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['gupw_retail_rkdf_rk'] = icom.groupby('datadate')['gupw_retail_rkdf'].apply(yu.uniformed_rank).values

icom['gupw_retail_rkdf_sgnl'] = np.nan
icom.loc[icom['gupw_retail_rkdf_rk']<-0.8, 'gupw_retail_rkdf_sgnl'] = -1
icom['gupw_retail_rkdf_sgnl'] = icom.groupby('ticker')['gupw_retail_rkdf_sgnl'].ffill(limit=20)
     
yu.create_cn_3x3(icom, ['gupw_retail_rkdf_bk'], 'gupw_retail_rkdf') # less mono: -5 +3 0

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2016-01-01','2021-12-31'))&(icom['gupw_retail_rkdf_sgnl']<0)].\
            dropna(subset=['gupw_retail_rkdf_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'gupw_retail_rkdf_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
# the drawdown is still significant

### 
