﻿#$%^&* pGraph_cn_guba.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 23 07:00:49 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime





### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()


### trading day flag

i_tdate = yu.get_sql("select distinct tradedate_next as FileDate FROM [CNDBPROD].[dbo].[calendar_dates_cn]")
i_tdate['flag_tdate'] = 1

### get guba 

i_guba = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pDataYes_guba_raw_2_gubaSQL.parquet')


i_guba = i_guba.merge(i_tdate, on = ['FileDate'], how = 'left')
c_is_tdate = i_guba['flag_tdate'] ==  1
i_guba.loc[c_is_tdate, 'cnt_tdate'] = i_guba.loc[c_is_tdate, 'cnt']

i_guba['datadate'] = i_guba['FileDate'] #+ pd.to_timedelta('1 day')
i_guba['baname'] = i_guba['baname'].astype(str).str.zfill(6)
c_sh = i_guba['baname'].str[0].isin(['6'])
c_sz = i_guba['baname'].str[0].isin(['0', '3'])
i_guba.loc[c_sh, 'ticker'] = i_guba.loc[c_sh, 'baname']  + '.SH'
i_guba.loc[c_sz, 'ticker'] = i_guba.loc[c_sz, 'baname']  + '.SZ'
i_guba = i_guba.drop(columns = ['baname'])

i_guba = i_sd[['ticker','datadate']].merge(i_guba, on = ['ticker', 'datadate'], how = 'left')
i_guba = i_guba.sort_values(['ticker', 'datadate'])

i_guba = i_guba.fillna(0)


### corr matrix


o_guba_sum = []

for dt in pd.date_range(start = '2016-02-01', end = '2021-06-01', freq='W'):
    print (dt.strftime('%Y%m%d'), end = ' ')
    
    t_sd = i_sd[i_sd['datadate']==i_sd_dd[i_sd_dd<=dt].max()]
    t_guba = i_guba[(i_guba['datadate']<=dt)&(i_guba['datadate']>=dt-pd.to_timedelta('365 days'))]
    t_guba = t_guba[t_guba['ticker'].isin(t_sd['ticker'].tolist())]
    
    t_guba_pv = t_guba.pivot_table(index = 'datadate', columns = 'ticker', values = 'cnt')
    t_corr = t_guba_pv.corr()
    t_corr.values[[np.arange(len(t_corr))]*2] = np.nan
    if len(t_corr) == 0:
        continue    
    t_corr_mean = t_corr.mean(axis = 1)
    t_corr_mean = t_corr_mean.reset_index().rename(columns={0: 'guba_corr_mean'})
    
    t_gubaT_pv = t_guba[t_guba['flag_tdate']==1].pivot_table(index = 'datadate', columns = 'ticker', values = 'cnt')
    t_corrT = t_gubaT_pv.corr()
    t_corrT.values[[np.arange(len(t_corrT))]*2] = np.nan
    if len(t_corrT) == 0:
        continue    
    t_corrT_mean = t_corrT.mean(axis = 1)
    t_corrT_mean = t_corrT_mean.reset_index().rename(columns={0: 'guba_corrT_mean
'})
    
    t_corr_sum = t_corr_mean.merge(t_corrT_mean, on = ['ticker'], how = 'outer')
    t_corr_sum['datadate'] = dt
    
    o_guba_sum.append(t_corr_sum)

o_guba_sum = pd.concat(o_guba_sum, axis = 0)
o_guba_sum = o_guba_sum.sort_values('datadate')



### combine

icom = pd.merge_asof(i_sd, o_guba_sum, by='ticker', on='datadate')
icom = icom.sort_values(['ticker','datadate'])


icom['guba_corr_mean_bk'] = icom.groupby('datadate')['guba_corr_mean'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['guba_corr_mean_rk'] = icom.groupby('datadate')['guba_corr_mean'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['guba_corrT_mean_bk'], 'guba_corrT_mean') # random

icom['guba_corrT_mean_bk'] = icom.groupby('datadate')['guba_corrT_mean'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['guba_corrT_mean_rk'] = icom.groupby('datadate')['guba_corrT_mean'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['guba_corrT_mean_bk'], 'guba_corrT_mean') # random

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['guba_corr_mean_orth'] = icom.groupby('datadate')[COLS+['guba_corr_mean']].apply(lambda x: yu.orthogonalize_cn(x['guba_corr_mean'], x[COLS])).values
icom['guba_corr_mean_orth_bk'] = icom.groupby('datadate')['guba_corr_mean_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['guba_corr_mean_orth_rk'] = icom.groupby('datadate')['guba_corr_mean_orth'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['guba_corr_mean_orth_bk'], 'guba_corr_mean_orth') # random


    
icom['orth_neg_sgnl'] = np.nan
icom.loc[icom['guba_corr_mean_orth_rk']<-0.8, 'orth_neg_sgnl']  = -1
icom['orth_neg_sgnl'] = icom.groupby('ticker')['orth_neg_sgnl'].ffill(limit=5)

icom['orth_pos_sgnl'] = np.nan
icom.loc[icom['guba_corrT_mean_rk']>0.5, 'orth_pos_sgnl']  = 1
icom['orth_pos_sgnl'] = icom.groupby('ticker')['orth_pos_sgnl'].ffill(limit=5)


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['orth_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'orth_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['csi300_flag']==1)].\
            dropna(subset=['orth_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'orth_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-
12-31')].\
            dropna(subset=['orth_pos_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'orth_pos_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
