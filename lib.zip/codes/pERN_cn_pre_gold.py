﻿#$%^&* pERN_cn_pre_gold.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 30 20:12:04 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime


# the issue is that ... jin gu strict PIT data doesn't have much history


### sd 

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])


### sd stable shortable 

i_sd_ss = yu.get_sql('''select * from [CNDBPROD].[dbo].[Static_Data_SS_GEM3L] ''')
i_sd_ss = i_sd_ss.rename(columns = {'DataDate':'datadate_p1d', 'T-1d':'datadate', 'Ticker':'ticker', 'gk_vol_21d':'volatility'})

c_sh = i_sd_ss['ticker'].str[0].isin(['6'])
c_sz = i_sd_ss['ticker'].str[0].isin(['0', '3'])
i_sd_ss.loc[c_sh, 'ticker'] = i_sd_ss.loc[c_sh, 'ticker'] + '.SH'
i_sd_ss.loc[c_sz, 'ticker'] = i_sd_ss.loc[c_sz, 'ticker'] + '.SZ'

i_sd_ss = i_sd_ss.sort_values('datadate')

i_sd_ss_dd = i_sd_ss['datadate'].drop_duplicates()




### ed

i_ed = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_ed_calendar.parquet')
i_ed = i_ed.rename(columns = {'report_period_n1q':'report_period','ed_n1q':'next_ed'})
i_ed = i_ed[['ticker', 'datadate', 'report_period', 'next_ed', 'td2e']]



### past return

i_pastret = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet',
                            columns = ['ticker', 'datadate', 'twap1000_2c_bret', 'twap1000_2c_bret_t4w'])
i_pastret = i_sd[['ticker', 'datadate']].merge(i_pastret, on = ['ticker', 'datadate'], how = 'inner')
i_pastret['twap1000_2c_bret_rk'] = i_pastret.groupby('datadate')['twap1000_2c_bret'].apply(yu.uniformed_rank)
i_pastret['twap1000_2c_bret_t4w_rk'] = i_pastret.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)
i_pastret = i_pastret.sort_values(['ticker','datadate'])
i_pastret['twap1000_2c_bret_t4wt1y'] = i_pastret.groupby('ticker').rolling(datetime.timedelta(days=365),min_periods = 60,on='datadate')['twap1000_2c_bret_t4w'].mean().values
i_pastret['twap1000_2c_bret_t4wt1y_rk'] = i_pastret.groupby('datadate')['twap1000_2c_bret_t4wt1y'].apply(yu.uniformed_rank)
i_pastret = i_pastret.sort_values('datadate')






### jin gu 

# report tytpe
# 2 机构资讯 7 投资策略 8 投资组合 17 行业点评 18 行业比较 19 行业策略 20 行业资讯
# 25 点评报告 29 预测评级 49 金融工程 85 国际市场 89 其他 113 科创板评述 118 宏观月报 120 大类资产


i_gold = pd.read_parquet(r'S:\Data\China Data Hunt\cache\gold.parquet')

i_gold['entrydate'] = pd.to_datetime(i_gold['entrytime'].dt.date)
i_gold['create_date_p1d'] = pd.to_d
atetime(i_gold['create_date']) + pd.to_timedelta('1 day')
i_gold['create_date_p7d'] = pd.to_datetime(i_gold['create_date']) + pd.to_timedelta('7 day')
i_gold['datadate'] = i_gold[['create_date_p1d','entrydate']].max(axis=1)
#i_gold['datadate'] = i_gold['create_date_p1d']

i_gold['first_author_name'] = i_gold['author_name'].str.split(',').str[0]

c_sh = i_gold['stock_code'].str[1].isin(['6'])
c_sz = i_gold['stock_code'].str[1].isin(['0','3'])
i_gold.loc[c_sh, 'ticker'] = i_gold.loc[c_sh, 'stock_code'] + '.SH'
i_gold.loc[c_sz, 'ticker'] = i_gold.loc[c_sz, 'stock_code'] + '.SZ'

i_gold['flg_gold'] = 1

# filter: only periodic jin gu
#i_gold = i_gold[i_gold['report_type'].isin([7, 8])]
# filter: only shenwan hongyuan
#!i_gold = i_gold[i_gold['organ_id']==15467]

# filter
# 7's sharpe is better than 8
# 东吴，兴业 are the best
# 获奖的研究员的信号似乎质量更高

#o_gold = i_gold[i_gold['flg_xcf']==1].groupby(['ticker', 'datadate'])['flg_gold'].sum().reset_index()
s_gold = i_gold.groupby(['ticker', 'datadate'])['flg_gold'].sum().reset_index()
s_gold = s_gold.sort_values('datadate')



### tim



i_alphacap = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pAlphaCapture_cn_etl_tim.parquet')
i_alphacap = i_alphacap[(i_alphacap['rec_instrument_bbg'].str.endswith(' CH')) |\
                        (i_alphacap['rec_instrument_bbg'].str.endswith('.SH')) |\
                        (i_alphacap['rec_instrument_bbg'].str.endswith('.SZ')) ]
i_alphacap = i_alphacap[i_alphacap['rec_instrument_bbg'].str[0].isin(['0','3','6'])]

i_alphacap['ticker'] = i_alphacap['rec_instrument_bbg'].str[:6]
c_sh = i_alphacap['ticker'].str[0].isin(['6'])
c_sz = i_alphacap['ticker'].str[0].isin(['0','3'])
i_alphacap.loc[c_sh, 'ticker'] = i_alphacap.loc[c_sh, 'ticker'] + '.SH'
i_alphacap.loc[c_sz, 'ticker'] = i_alphacap.loc[c_sz, 'ticker'] + '.SZ'

i_alphacap['timestamp'] = i_alphacap['timestamp'].str.split('.').str[0]
i_alphacap['timestamp_utc'] = pd.to_datetime(i_alphacap['timestamp'], format='%Y-%m-%dT%H:%M:%S', utc=True)
i_alphacap['timestamp_cn'] = i_alphacap['timestamp_utc'].dt.tz_convert('Asia/Shanghai').dt.tz_localize(None)
i_alphacap['datadate'] = pd.to_datetime(i_alphacap['timestamp_cn'].dt.date)
c1 = i_alphacap['timestamp_cn'].dt.hour>=16
i_alphacap.loc[c1,'datadate'] = i_alphacap.loc[c1,'datadate'] + pd.to_timedelta('1 day')

i_alphacap = i_alphacap.sort_values('datadate').reset_index(drop = True)



### loop 

o_tim_sgnl= []

for dt in pd.date_range(start='2018-01-01', end='2022-06-30'):
    print(dt.str
ftime('%Y%m%d'), end = ',')
    
    t_tim = i_alphacap[(i_alphacap['datadate']<=dt) & (i_alphacap['datadate']>=dt-pd.to_timedelta('91 days'))]
        
    threshold_freq_author = t_tim.groupby('author_id')['rec_id'].nunique().median()
    t_gs_cnt_byAuthor = t_tim.groupby('author_id')['rec_id'].nunique().reset_index()
    freq_author = t_gs_cnt_byAuthor.loc[t_gs_cnt_byAuthor['rec_id']>=threshold_freq_author, 'author_id'].tolist()
    
    t_tim_tail = t_tim.groupby('rec_id').tail(1)
    t_tim_tail = t_tim_tail[t_tim_tail['close_timestamp'].isnull()]
    t_tim_tail['direction'] = np.nan
    t_tim_tail.loc[t_tim_tail['rec_direction']=='LONG', 'direction'] = 1
    t_tim_tail.loc[t_tim_tail['rec_direction']=='SHORT', 'direction'] = -1
    
    t_tim_sgnl_large = t_tim_tail[t_tim_tail['conviction']=='Very high'].groupby('ticker')['direction'].sum().reset_index()
    t_tim_sgnl_large = t_tim_sgnl_large.rename(columns={'direction':'large_sum'})
    t_tim_sgnl_large_freq = t_tim_tail[(t_tim_tail['conviction']=='Very high')&(t_tim_tail['author_id'].isin(freq_author))].groupby('ticker')['direction'].sum().reset_index()
    t_tim_sgnl_large_freq = t_tim_sgnl_large_freq.rename(columns={'direction':'large_freq_sum'})
    t_tim_sgnl_lmed = t_tim_tail[t_tim_tail['conviction']=='High'].groupby('ticker')['direction'].sum().reset_index()
    t_tim_sgnl_lmed = t_tim_sgnl_lmed.rename(columns={'direction':'medium_sum'})
    t_tim_sgnl_small = t_tim_tail[t_tim_tail['conviction']=='Medium'].groupby('ticker')['direction'].sum().reset_index()
    t_tim_sgnl_small = t_tim_sgnl_small.rename(columns={'direction':'small_sum'})
    t_tim_sgnl_all = t_tim_tail.groupby('ticker')['direction'].sum().reset_index()
    t_tim_sgnl_all = t_tim_sgnl_all.rename(columns={'direction':'all_sum'})
    
    t_tim_sgnl = t_tim_sgnl_all.merge(t_tim_sgnl_large,on='ticker',how='outer')
    t_tim_sgnl = t_tim_sgnl.merge(t_tim_sgnl_lmed,on='ticker',how='outer')
    t_tim_sgnl = t_tim_sgnl.merge(t_tim_sgnl_small,on='ticker',how='outer')
    t_tim_sgnl = t_tim_sgnl.merge(t_tim_sgnl_large_freq,on='ticker',how='outer')    
    t_tim_sgnl['datadate'] = dt
    
    o_tim_sgnl.append(t_tim_sgnl)
    
o_tim_sgnl = pd.concat(o_tim_sgnl, axis=0)




#------------------------------------------------------------------------------
### combine 2K
#------------------------------------------------------------------------------


icom = i_sd.merge(i_ed, on = ['ticker', 'datadate'], how = 'left')

icom = icom.sort_values(
'datadate')
icom = pd.merge_asof(icom, s_gold, by='ticker', on='datadate', tolerance=pd.to_timedelta('91 days'))

icom = icom.merge(i_pastret[['ticker', 'datadate','twap1000_2c_bret_t4w']],on=['ticker', 'datadate'],how='left')
icom = icom.merge(o_tim_sgnl, on = ['ticker', 'datadate'], how = 'left')

icom = icom.sort_values(['ticker', 'datadate'])


# gold

icom['sgnl_l_preed'] = np.nan
icom.loc[(icom['flg_gold']==1)&(icom['td2e']<=10), 'sgnl_l_preed'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-12-31'))].\
            dropna(subset=['sgnl_l_preed','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_l_preed','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2021: 5.2 / 3.3 


# tim

icom['sgnl_2_preed'] = np.nan
icom.loc[(icom['large_freq_sum']>=1)&(icom['td2e']<=10), 'sgnl_2_preed'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-12-31'))].\
            dropna(subset=['sgnl_2_preed','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_2_preed','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.09/2.09, 19% 




#------------------------------------------------------------------------------
### combine ss
#------------------------------------------------------------------------------



icom = i_sd_ss.merge(i_ed, on = ['ticker', 'datadate'], how = 'left')

icom = icom.sort_values('datadate')
icom = pd.merge_asof(icom, s_gold, by='ticker', on='datadate', tolerance=pd.to_timedelta('91 days'))

icom = icom.merge(i_pastret[['ticker', 'datadate','twap1000_2c_bret_t4w']],on=['ticker', 'datadate'],how='left')

icom = icom.sort_values(['ticker', 'datadate'])



icom['sgnl_l_preed'] = np.nan
icom.loc[(icom['flg_gold']==1)&(icom['td2e']<=10), 'sgnl_l_preed'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-12-31'))].\
            dropna(subset=['sgnl_l_preed','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_l_preed','BarrRet_CLIP_USD+1d', static_data = i_sd_ss) # 

