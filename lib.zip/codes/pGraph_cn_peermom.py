﻿#$%^&* pGraph_cn_peermom.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 28 13:20:03 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os

### get sd 

i_sd = pw.get_ashare_t2000_sd() 


### get lmt_ups

i_lmtup = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate 
                     from wind_prod.dbo.ashareeodprices
                     where trade_dt >= '20150101'
                     and s_dq_limit = s_dq_close ''')
i_lmtup['datadate'] = pd.to_datetime(i_lmtup['datadate'], format = '%Y%m%d')


### get ipo date

i_ipo = pw.get_ipo_date()

### get basic features

i_uni = yu.get_sql('''select ticker, datadate, w_sector
                   FROM [CNDBPROD].[dbo].[UNIVERSE_ALL_CN_GEM3L]''')
c_sh = i_uni['ticker'].str[0].isin(['6'])
c_sz = i_uni['ticker'].str[0].isin(['0','3'])
i_uni.loc[c_sh, 'ticker'] = i_uni.loc[c_sh, 'ticker'] + '.SH'
i_uni.loc[c_sz, 'ticker'] = i_uni.loc[c_sz, 'ticker'] + '.SZ'

i_rret = yu.get_sql('''select datadate, ticker, barrret_cny, rawret_cny
                    from [CNDBPROD].[dbo].[Barra_gem3l_rret_cn]''')
c_sh = i_rret['ticker'].str[0].isin(['6'])
c_sz = i_rret['ticker'].str[0].isin(['0','3'])
i_rret.loc[c_sh, 'ticker'] = i_rret.loc[c_sh, 'ticker'] + '.SH'
i_rret.loc[c_sz, 'ticker'] = i_rret.loc[c_sz, 'ticker'] + '.SZ'

i_pastret = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet', 
                            columns = ['ticker','datadate','c2c_bret_t4w','c2c_t4w'])

i_uni_s2 = i_uni.merge(i_rret, on = ['ticker', 'datadate'], how = 'left')
i_uni_s2 = i_uni_s2.merge(i_pastret, on = ['ticker', 'datadate'], how = 'left')
i_uni_s2 = i_uni_s2.sort_values(['ticker', 'datadate'])
i_uni_s2 = i_uni_s2.rename(columns = {'barrret_cny':'barrret_cny_p0d'})
i_uni_s2['barrret_cny_p1d'] = i_uni_s2.groupby('ticker')['barrret_cny_p0d'].shift(-1)
i_uni_s2['barrret_cny_p2d'] = i_uni_s2.groupby('ticker')['barrret_cny_p0d'].shift(-2)
i_uni_s2['barrret_cny_p3d'] = i_uni_s2.groupby('ticker')['barrret_cny_p0d'].shift(-3)
i_uni_s2['barrret_cny_p4d'] = i_uni_s2.groupby('ticker')['barrret_cny_p0d'].shift(-4)
i_uni_s2['barrret_cny_p5d'] = i_uni_s2.groupby('ticker')['barrret_cny_p0d'].shift(-5)
i_uni_s2['barrret_cny_p6d'] = i_uni_s2.groupby('ticker')['barrret_cny_p0d'].shift(-6)



### calculate correlation

i_data = []

for dt in i_lmtup[i_lmtup['datadate'].gt('2017-01-01')]['datadate'].sort_values().drop_duplicates():

    print(dt.strftime('%Y%m%d'), end = ',')
    
    t_gd_tk = i_ipo.copy()
    t_gd_tk['datadate'] = dt
    t_gd_tk = t_gd_tk[(t_gd_tk['datadate'] - t_gd_tk['ipo_date']).dt.days > 365]
    t_gd_tk = t_gd_tk['ticker'].tolist()
    
    t_lmtup = i_lmtup[i_lmtup['datadate']==dt]
    t_uni_s2 = i_uni_s2[i_uni_s2['datadate']==dt]
    t_uni_s2 = t_uni_s2.drop(columns = ['datadate'])
    
    t_lmtup = t_lmtup.merge(t_uni_s2[['ticker','w_sector']], on = 'ticker', how = 'left')
    t_lmtup = t_lmtup[t_lmtup['w_sector'].notnull()]
    t_lmtup = t_lmtup.merge(t_uni_s2, on = ['w_sector'], how = 'left', suffixes = ['_1','_2'])
    t_lmtup = t_lmtup[t_lmtup['ticker_1'].ne(t_lmtup['ticker_2'])]
    t_lmtup = t_lmtup[t_lmtup['ticker_1'].isin(t_gd_tk)] # leader ticker must be mature tickers (far away from ipo)
    
    i_data.append(t_lmtup)
    
i_data = pd.concat(i_data, axis = 0)


i_relation = []

for dt in pd.date_range(start = '2019-01-01', end = '2021-12-31', freq = 'M'):
    print(dt.strftime('%Y%m%d'), end = ',')
    
    RET_COL = 'barrret_cny_p0d'
    
    t_data = i_data[i_data['datadate'].le(dt - pd.to_timedelta('14 days')) & i_data['datadate'].ge(dt - pd.to_timedelta('730 days'))]
    
    s1 = t_data.groupby(['ticker_1','ticker_2'])[RET_COL].count()
    s1.name = 'tot_cnt'
    s1 = s1.reset_index()
    s2 = t_data[t_data[RET_COL]>0].groupby(['ticker_1','ticker_2'])[RET_COL].count()
    s2.name = 'gt0_cnt'
    s2 = s2.reset_index()
    
    s = s1.merge(s2, on = ['ticker_1', 'ticker_2'], how = 'outer')
    s['gt0_cnt'] = s['gt0_cnt'].fillna(0)
    s['pct_follow'] = (s['gt0_cnt'] / s['tot_cnt']).replace(np.inf, np.nan).replace(-np.inf, np.nan)
    s = s[s['pct_follow']>0.8]
    s = s[s['tot_cnt']>=5]
    s['datadate'] = dt
    
    i_relation.append(s[['ticker_1', 'ticker_2', 'datadate']])

i_relation = pd.concat(i_relation, axis = 0)





i_peer_mom = []

dd_pastret = i_pastret['datadate'].drop_duplicates()

i_pastret2 = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet', 
                            columns = ['ticker','datadate','c2c_bret_t4w', 'c2c'])
i_pastret2['c2c_bret_t4w_rk'] = i_pastret2.groupby('datadate')['c2c_bret_t4w'].apply(yu.uniformed_rank)


for dt in pd.date_range(start = '2019-01-01', end = '2021-12-31'):
    print(dt.strftime('%Y%m%d'), end = ',')
    
    maxdd = i_relation.loc[i_relation['datadate']<=dt, 'datadate'].max()
    t_relation = i_relation[i_relation['datadate']==maxdd]
    t_relation = t_
relation.drop(columns = 'datadate')
        
    t_pastret = i_pastret2[i_pastret2['datadate'] == dd_pastret[dd_pastret<=dt].max()]
    t_pastret = t_pastret.rename(columns = {'ticker': 'ticker_1'})
    t_pastret = t_pastret.drop(columns = 'datadate')
    
    tdata = t_relation.merge(t_pastret, on = 'ticker_1', how = 'left')
    t_peermom = tdata.groupby('ticker_2').agg({'c2c_bret_t4w_rk': 'mean', 'c2c': 'max'})
    t_peermom = t_peermom.reset_index()
    t_peermom = t_peermom.rename(columns = {'ticker_2': 'ticker'})
    t_peermom['datadate'] = dt
    
    i_peer_mom.append(t_peermom)

i_peer_mom = pd.concat(i_peer_mom, axis = 0)





### combine

icom = i_sd.merge(i_peer_mom, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])


# idea 1: mean rank 

icom['sgnl_1'] = np.nan
c1 = icom['c2c_bret_t4w_rk'] > 0.8
icom.loc[c1, 'sgnl_1'] = 1

yu.create_cn_decay(icom, 'sgnl_1')

icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit=3)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd)


# idea 2: rank of mean rank 

icom['c2c_bret_t4w_rk_rk'] = icom.groupby('datadate')['c2c_bret_t4w_rk'].apply(yu.uniformed_rank)

icom['sgnl_1'] = np.nan
c1 = icom['c2c_bret_t4w_rk_rk'] > 0.8
icom.loc[c1, 'sgnl_1'] = 1

yu.create_cn_decay(icom, 'sgnl_1')

icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit=60)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd) 


# idea 3: hit lmtup

icom['sgnl_3'] = np.nan
c1 = icom['c2c'] > 0.095
icom.loc[c1, 'sgnl_3'] = 1

yu.create_cn_decay(icom, 'sgnl_3')


icom['sgnl_3'] = icom.groupby('ticker')['sgnl_3'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_3','BarrRet_CLIP_USD+1d', static_data = i_sd) 
