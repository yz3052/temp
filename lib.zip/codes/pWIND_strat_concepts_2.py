﻿#$%^&* pWIND_strat_concepts_2.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 26 14:00:42 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

### get holding data

i_data = yu.get_sql('''select * from wind.dbo.ChinaMutualFundStockPortfolio''')

i_sum_fwdlk = yu.get_sql('''select f_prt_enddate, s_info_stockwindcode as ticker, count(distinct s_info_windcode) as fund_cnt from wind.dbo.ChinaMutualFundStockPortfolio group by f_prt_enddate, s_info_stockwindcode ''')
i_sum_fwdlk['datadate'] = pd.to_datetime(i_sum_fwdlk['f_prt_enddate'], format = '%Y%m%d') + pd.to_timedelta('20 days')

i_sum_fwdlk['fund_cnt_rk'] = i_sum_fwdlk.groupby('f_prt_enddate')['fund_cnt'].apply(yu.uniformed_rank).values



# get sd

i_sd = pw.get_ashare_hk_sd_v2()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','volatility','spread','BarrRet_SRISK_USD+1d','FX_LAST']]


### combine

i_sd_map = i_sd_map.sort_values('datadate')
i_sum_fwdlk = i_sum_fwdlk.sort_values('datadate')
icom = pd.merge_asof(i_sd_map, i_sum_fwdlk, by = 'ticker', on = 'datadate')


### rk

icom2 = icom.copy()
o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['fund_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'fund_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.24 / 1.12

o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31')&(icom2['fund_cnt_rk']>0.5)].\
            dropna(subset=['fund_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'fund_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.28 / 1.31


o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31')&(icom2['fund_cnt_rk']>0.8)].\
            dropna(subset=['fund_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'fund_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.09 / 1.42



o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31')&(icom2['fund_cnt_rk']<-0.8)].\
            dropna(subset=['fund_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'fund_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs -0.16  / -0.57

### change of rank


### rk within sectors 


### rk + o_c_re
turn

### rk + concepts rk


