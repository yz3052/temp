﻿#$%^&* pL2_cn_orderbook_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 31 09:26:43 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine




### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])


### pv
i_pv_93045 = yu.get_sql('''(select ticker, datadate, sum(volume) as v_093045 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_17]
                            where time between 930 and 945 group by ticker, datadate)
                           union
                           (select ticker, datadate, sum(volume) as v_093045 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_18]
                            where time between 930 and 945 group by ticker, datadate)
                           union
                           (select ticker, datadate, sum(volume) as v_093045 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_19]
                            where time between 930 and 945 group by ticker, datadate)
                           union
                           (select ticker, datadate, sum(volume) as v_093045 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_20]
                            where time between 930 and 945 group by ticker, datadate)''')
i_pv_93045['ticker'] = i_pv_93045['ticker'].str.replace('SS','SH')

i_pv_94510 = yu.get_sql('''(select ticker, datadate, sum(volume) as v_094510 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_17]
                            where time between 945 and 1000 group by ticker, datadate)
                           union
                           (select ticker, datadate, sum(volume) as v_094510 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_18]
                            where time between 945 and 1000 group by ticker, datadate)
                           union
                           (select ticker, datadate, sum(volume) as v_094510 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_19]
                            where time between 945 and 1000 group by ticker, datadate)
                           union
                           (select ticker, datadate, sum(volume) as v_094510 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_20]
                            where time between 945 and 1000 group by ticker, datadate)''')
i_pv_94510['ticker'] = i_pv_94510['ticker'].str.replace('SS','SH')


### order book metrics

i_odbk1 = yu.get_q("get `:/export/datadev/Data/SHSZ/ORDER_metrics/orderbook_metrics_batch1_01")

i_odbk1['code'] = i_odbk
1['code'].str.decode('utf8')
c_sh = i_odbk1['code'].str[0].isin(['6'])
c_sz = i_odbk1['code'].str[0].isin(['0','3'])
i_odbk1.loc[c_sh, 'ticker'] = i_odbk1.loc[c_sh, 'code'] + '.SH'
i_odbk1.loc[c_sz, 'ticker'] = i_odbk1.loc[c_sz, 'code'] + '.SZ'
i_odbk1['datadate'] = pd.to_datetime(i_odbk1['date'])
i_odbk1 = i_odbk1.sort_values(['ticker', 'datadate'])

i_odbk1 = i_odbk1.merge(i_pv_93045, on = ['ticker', 'datadate'], how = 'left')
i_odbk1 = i_odbk1.merge(i_pv_94510, on = ['ticker', 'datadate'], how = 'left')

i_odbk1['net_chg_am_dv_v'] = (i_odbk1['bid_v_09551000'] - i_odbk1['bid_v_09300935']- i_odbk1['ask_v_09551000'] + i_odbk1['ask_v_09300935']).divide(i_odbk1['v_093045']+i_odbk1['v_094510'])

i_odbk1['ba_ratio_t5d'] = i_odbk1.groupby('ticker').rolling(datetime.timedelta(days=7),on='datadate')['ba_ratio'].mean().values
i_odbk1['ba_ratio_t20d'] = i_odbk1.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ba_ratio'].mean().values
i_odbk1['ba_ratio_09301000_t20d'] = i_odbk1.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ba_ratio_09301000'].mean().values

i_odbk1['ba_ratio_09301000_14301500_df'] = i_odbk1['ba_ratio_14301500'] - i_odbk1['ba_ratio_09301000']

i_odbk1['bid_v_09300935_09551000_dv_ask'] = (i_odbk1['bid_v_09551000'] - i_odbk1['bid_v_09300935']).divide(i_odbk1['ask_v_09300935'])

i_odbk1['ba_ratio_09301430_std_t20d'] = i_odbk1.groupby('ticker').rolling(datetime.timedelta(days=20), on = 'datadate')['ba_ratio_09301430_std'].mean().values


### combine

icom = i_sd.merge(i_odbk1, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

### bid ask ratio
# change in bid not working  

icom['bid_v_09300935_09551000_dv_ask_bk'] = icom.groupby('datadate')['bid_v_09300935_09551000_dv_ask'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['bid_v_09300935_09551000_dv_ask_bk'], 'bid_v_09300935_09551000_dv_ask') # random
icom['ba_ratio_bk'] = icom.groupby('datadate')['ba_ratio'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_bk'], 'ba_ratio') # mono: -4 +4 ###!!!
icom['ba_ratio_winsor'] = icom['ba_ratio']
icom.loc[(icom['ba_ratio_winsor']>3)|(icom['ba_ratio_winsor']<0.1), 'ba_ratio_winsor'] = np.nan
icom['ba_ratio_winsor_bk'] = icom.groupby('datadate')['ba_ratio_winsor'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_winsor_bk'], 'ba_ratio_winsor') # mono: -3.5 +3.5
icom['ba_ratio_xTop_bk'] = icom.g
roupby('datadate')['ba_ratio_xTop'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_xTop_bk'], 'ba_ratio_xTop') # mono: -4 +3
icom['ba_ratio_09301000_bk'] = icom.groupby('datadate')['ba_ratio_09301000'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_09301000_bk'], 'ba_ratio_09301000') # mono: -4 +2
icom['ba_ratio_14301500_bk'] = icom.groupby('datadate')['ba_ratio_14301500'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_14301500_bk'], 'ba_ratio_14301500') # mono: -3 +2
icom['ba_ratio_09301000_14301500_df_bk'] =icom.groupby('datadate')['ba_ratio_09301000_14301500_df'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_09301000_14301500_df_bk'], 'ba_ratio_09301000_14301500_df') # V-shaped
icom['ba_ratio_09551000'] = icom['bid_v_09551000'].divide(icom['ask_v_09551000'])
icom['ba_ratio_09551000_bk'] = icom.groupby('datadate')['ba_ratio_09551000'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_09551000_bk'], 'ba_ratio_09551000') # mono -3 +3
icom['ba_ratio_xUp_09551000'] = icom['bid_v_09551000'].divide(icom['ask_v_xUp_09551000'])
icom['ba_ratio_xUp_09551000_bk'] = icom.groupby('datadate')['ba_ratio_xUp_09551000'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_xUp_09551000_bk'], 'ba_ratio_xUp_09551000') # less mono: -1 +3




icom['ba_ratio_t5d_bk'] = icom.groupby('datadate')['ba_ratio_t5d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_t5d_bk'], 'ba_ratio_t5d') # mono: -2 +2
icom['ba_ratio_t20d_bk'] = icom.groupby('datadate')['ba_ratio_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_t20d_bk'], 'ba_ratio_t20d') # random

icom['ba_ratio_1pct_bk'] = icom.groupby('datadate')['ba_ratio_1pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_1pct_bk'], 'ba_ratio_1pct') # random
icom['ba_ratio_1pct_t20d_bk'] = icom.groupby('datadate')['ba_ratio_1pct_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['ba_ratio_09301000_bk'] = icom.groupby('datadate')['ba_ratio_09301000'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_09301000_bk'], 'ba_ratio_09301000') # -4 +2
icom['ba_ratio_09301000_t20d_bk'] = icom.groupby('datadate')['ba_ratio_09301000_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_093
01000_t20d_bk'], 'ba_ratio_09301000_t20d') # barely mono: -1.5 +2 0



icom['ba_ratio_rk'] = icom.groupby('datadate')['ba_ratio'].apply(yu.uniformed_rank).values
icom['ba_ratio_t5d_rk'] = icom.groupby('datadate')['ba_ratio_t5d'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ba_ratio_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ba_ratio_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.24 / -18.61
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ba_ratio_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ba_ratio_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.98 / -5.05



# to sql
icom['Ticker'] = icom['ticker'].str[:6]
icom['DataDate'] = icom['datadate']
param_engine = create_engine('mssql+pyodbc://summitsqldb_cndbdev') 
icom[['Ticker','DataDate','ba_ratio_rk']].to_sql('F001_ODBK_BAratio_LS_1D', param_engine , index = False, if_exists = 'replace', chunksize = 10000)




### bid ask ratio std
# this is a very short term alpha: 2 days maximum

icom['ba_ratio_std_bk'] = icom.groupby('datadate')['ba_ratio_std'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_std_bk'], 'ba_ratio_std') # mono -4 +3
icom['ba_ratio_10001500_std_winsor'] = icom['ba_ratio_10001500_std']
icom.loc[icom['ba_ratio_10001500_std_winsor']>2, 'ba_ratio_10001500_std_winsor'] = 2
icom['ba_ratio_10001500_std_winsor_bk'] = icom.groupby('datadate')['ba_ratio_10001500_std_winsor'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_10001500_std_winsor_bk'], 'ba_ratio_10001500_std_winsor') # mono -5 +4 ###!!!
icom['ba_ratio_09301430_std_bk'] = icom.groupby('datadate')['ba_ratio_09301430_std'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_ratio_09301430_std_bk'], 'ba_ratio_09301430_std') # mono -3 +3


icom['ba_ratio_10001500_std_rk'] = icom.groupby('datadate')['ba_ratio_10001500_std'].apply(yu.uniformed_rank).values
icom['ba_ratio_10001500_std_t2d'] = icom.groupby('ticker').rolling(2)['ba_ratio_10001500_std'].mean().values
icom['ba_ratio_10001500_std_t2d_rk'] = icom.groupby('datadate')['ba_ratio_10001500_std_t2d'].apply(yu.uniformed_rank).values
icom['ba_ratio_10001500_std_t5d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=7),on='datadate')['ba_ratio_10001500_std'].max().values
icom['ba_ratio_1
0001500_std_t5d_rk'] = icom.groupby('datadate')['ba_ratio_10001500_std_t5d'].apply(yu.uniformed_rank).values
icom['ba_ratio_10001500_std_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ba_ratio_10001500_std'].max().values
icom['ba_ratio_10001500_std_t20d_rk'] = icom.groupby('datadate')['ba_ratio_10001500_std_t20d'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ba_ratio_10001500_std_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ba_ratio_10001500_std_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.78 / -20

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ba_ratio_10001500_std_t2d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ba_ratio_10001500_std_t2d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # <1

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ba_ratio_09301430_std_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ba_ratio_09301430_std_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # <1

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ba_ratio_09301430_std_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ba_ratio_09301430_std_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # <1



### bid ask volume std 
# not working

icom['bid_std_dv_avg'] = icom['bid_tot_v_std'].divide(icom['bid_avg_v'])
icom['bid_std_dv_avg_rk'] = icom.groupby('datadate')['bid_std_dv_avg'].apply(yu.uniformed_rank).values
icom['bid_std_dv_avg_bk'] = icom.groupby('datadate')['bid_std_dv_avg'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['bid_std_dv_avg_bk'], 'bid_std_dv_avg') # random
icom['ask_std_dv_avg'] = icom['ask_tot_v_std'].divide(icom['ask_avg_v'])
icom['ask_std_dv_avg_rk'] = icom.groupby('datadate')['ask_std_dv_avg'].apply(yu.uniformed_rank).values
icom['ask_std_dv_avg_bk'] = icom.groupby('datadate')['ask_std_dv_avg'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ask_std_dv_avg_bk'], 'ask_std_dv_avg') # random
icom['ba_std_dv_avg_df'] = icom['bid_std_dv_avg']-icom['ask_std_dv_avg']
icom['ba_std_dv_avg_df_bk'] = icom.groupby('datadate')['ba_std_dv_avg_df'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom,
 ['ba_std_dv_avg_df_bk'], 'ba_std_dv_avg_df') # random
icom['ba_std_dv_avg_rkdf'] = icom['bid_std_dv_avg_rk'] - icom['ask_std_dv_avg_rk']
icom['ba_std_dv_avg_rkdf_bk'] = icom.groupby('datadate')['ba_std_dv_avg_rkdf'].apply(lambda x:yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_std_dv_avg_rkdf_bk'], 'ba_std_dv_avg_rkdf') # random
icom['ba_ratio_std_rk'] = icom.groupby('datadate')['ba_ratio_std'].apply(yu.uniformed_rank).values
icom['ba_ratio_std_bk'] = icom.groupby('datadate')['ba_ratio_std'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom[icom['bid_std_dv_avg_bk']==9], ['ba_ratio_std_bk'], 'ba_ratio_std') # mono -60 -10 0
# yu.create_cn_3x3(icom[icom['bid_std_dv_avg_bk']==0], ['ba_ratio_std_bk'], 'ba_ratio_std') # mono 0 6 10

icom['test2'] = icom['ba_ratio_std_rk'] - icom['bid_std_dv_avg_rk']
icom['test2_bk'] = icom.groupby('datadate')['test2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['test2_bk'], 'test2') # mono: -3 +3

icom['test_sgnl'] = np.nan
icom.loc[(icom['ba_ratio_std_rk']>0.6)&(icom['bid_std_dv_avg_rk']<-0.6), 'test_sgnl'] = 1
icom['test_sgnl'] = icom.groupby('ticker')['test_sgnl'].ffill(limit=10)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['test_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # <0


### ask at lmtup

icom['test'] = icom['ba_ratio_xTop'].divide(icom['ba_ratio'])
icom['test_bk'] = icom.groupby('datadate')['test'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['test_bk'], 'test') # less mono: +1 +2 -1, low t


### change in bids / v

icom['net_chg_am_dv_v_bk'] = icom.groupby('datadate')['net_chg_am_dv_v'].apply(lambda x:yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['net_chg_am_dv_v_bk'], 'net_chg_am_dv_v') # less mono: -1 -2 +2 0


### p / nth quartile p

icom['bid1_dv_1Qp_bk'] = icom.groupby('datadate')['bid1_dv_1Qp'].apply(lambda x:yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['bid1_dv_1Qp_bk'], 'bid1_dv_1Qp') 
icom['bid1_dv_2Qp_bk'] = icom.groupby('datadate')['bid1_dv_2Qp'].apply(lambda x:yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['bid1_dv_2Qp_bk'], 'bid1_dv_2Qp')# not mono: 0 -2.5 +1 0
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['bid1_dv_1Qp_orth'] = icom.groupby('datadate')[COLS+['bid1_dv_1Qp']].apply(lamb
da x: yu.orthogonalize_cn(x['bid1_dv_1Qp'], x[COLS])).values
icom['bid1_dv_1Qp_orth_bk'] = icom.groupby('datadate')['bid1_dv_1Qp_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['bid1_dv_1Qp_orth_bk'], 'bid1_dv_1Qp_orth') # random
icom['bid1_dv_2Qp_orth'] = icom.groupby('datadate')[COLS+['bid1_dv_2Qp']].apply(lambda x: yu.orthogonalize_cn(x['bid1_dv_2Qp'], x[COLS])).values
icom['bid1_dv_2Qp_orth_bk'] = icom.groupby('datadate')['bid1_dv_2Qp_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['bid1_dv_2Qp_orth_bk'], 'bid1_dv_2Qp_orth') # random

icom['ba_2Qp_df'] = icom['bid1_dv_2Qp'] - 1/icom['ask1_dv_2Qp']
icom['ba_2Qp_df_rk'] = icom.groupby('datadate')['ba_2Qp_df'].apply(yu.uniformed_rank).values
icom['ba_2Qp_df_bk'] = icom.groupby('datadate')['ba_2Qp_df'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_2Qp_df_bk'], 'ba_2Qp_df') # mono -3.5 +1.5

icom['ba_1Qp_df'] = icom['bid1_dv_1Qp'] - 1/icom['ask1_dv_1Qp']
icom['ba_1Qp_df_rk'] = icom.groupby('datadate')['ba_1Qp_df'].apply(yu.uniformed_rank).values
icom['ba_1Qp_df_bk'] = icom.groupby('datadate')['ba_1Qp_df'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ba_ratio_bk'] = icom.groupby('datadate')['ba_ratio'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ba_1Qp_df_babk'] = icom.groupby(['datadate','ba_ratio_bk'])['ba_1Qp_df'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_1Qp_df_bk'], 'ba_1Qp_df') # mono -4 +3 +2 ###!!!
# yu.create_cn_3x3(icom, ['ba_1Qp_df_babk'], 'ba_1Qp_df') # mono -3 +1, low t on +ve side

icom['ba_2Qp_df_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=20),on='datadate')['ba_2Qp_df'].mean().values
icom['ba_2Qp_df_t20d_bk'] = icom.groupby('datadate')['ba_2Qp_df_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ba_2Qp_df_t20d_bk'], 'ba_2Qp_df_t20d') # less mono: 0 -2 +1 



o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ba_1Qp_df_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ba_1Qp_df_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.16/-18


### 
