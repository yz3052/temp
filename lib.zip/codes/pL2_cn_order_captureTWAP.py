﻿#$%^&* pL2_cn_order_captureTWAP.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 12 15:31:43 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine


#  This studies price orderbook-quantity correlation


### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])



### order book metrics

i_od3s = yu.get_q('''(get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sh_3s),
                     (get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sz_3s) ''')

i_od3s['code'] = i_od3s['code'].str.decode('utf8')
c_sh = i_od3s['code'].str[0].isin(['6'])
c_sz = i_od3s['code'].str[0].isin(['0','3'])
i_od3s.loc[c_sh, 'ticker'] = i_od3s.loc[c_sh, 'code'] + '.SH'
i_od3s.loc[c_sz, 'ticker'] = i_od3s.loc[c_sz, 'code'] + '.SZ'
i_od3s['datadate'] = pd.to_datetime(i_od3s['date'])
i_od3s = i_od3s.sort_values(['ticker', 'datadate'])
i_od3s = i_od3s[i_od3s['ticker'].notnull()]

i_od3s.loc[i_od3s['cnt_b_z_lt2']>1, 'flg_0s'] = 1
i_od3s['flg_0s'] = i_od3s['flg_0s'].fillna(0)
i_od3s['cnt_0s_t100d'] = i_od3s.groupby('ticker').rolling(datetime.timedelta(days=100),on='datadate')['flg_0s'].sum().values
i_od3s['cnt_0s_t365d'] = i_od3s.groupby('ticker').rolling(datetime.timedelta(days=365),on='datadate')['flg_0s'].sum().values



### get o2c return

i_o2c = yu.get_sql('''SELECT [datadate],[ticker],[close_1hr_vwap]/[open_1hr_vwap]-1 as o2c_ret FROM [CNDBPROD].[dbo].[TRTH_OPENCLOSE_CN]''')
c_sh = i_o2c['ticker'].str[0].isin(['6'])
c_sz = i_o2c['ticker'].str[0].isin(['0', '3'])
i_o2c.loc[c_sh, 'ticker'] = i_o2c.loc[c_sh, 'ticker'] + '.SH'
i_o2c.loc[c_sz, 'ticker'] = i_o2c.loc[c_sz, 'ticker'] + '.SZ'




### combine

icom = i_sd.merge(i_od3s, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_o2c, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])
icom['avgPVadjln'] = np.log(icom['avgPVadj'])
icom['avgPVadjln'] = icom['avgPVadjln'].replace(-np.inf,np.nan)
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY','avgPVadjln']
COLS = ['SIZE', 'LIQUIDTY','avgPVadjln']


### trailing 100d 0s-significant counts

icom['cnt_0s_t100d_bk'] = icom.groupby('datadate')['cnt_0s_t100d'].apply(lambda x: yu.pdqcut(x,bins=10)).
values
icom['cnt_0s_t365d_bk'] = icom.groupby('datadate')['cnt_0s_t365d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_0s_t365d_rk'] = icom.groupby('datadate')['cnt_0s_t365d'].apply(yu.uniformed_rank).values
icom['cnt_0s_t365d_orth'] = icom.groupby('datadate')[['cnt_0s_t365d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['cnt_0s_t365d'], x[COLS])).values
icom['cnt_0s_t365d_orth_bk'] = icom.groupby('datadate')['cnt_0s_t365d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_0s_t365d_orth_rk'] = icom.groupby('datadate')['cnt_0s_t365d_orth'].apply(yu.uniformed_rank).values
yu.create_cn_3x3(icom, ['cnt_0s_t100d_bk'], 'cnt_0s_t100d') # leaning to mono: -2 +2
yu.create_cn_3x3(icom, ['cnt_0s_t365d_bk'], 'cnt_0s_t365d') # -1 -2 +1.5
yu.create_cn_3x3(icom, ['cnt_0s_t365d_orth_bk'], 'cnt_0s_t365d_orth') # mono: -2 +2.5

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cnt_0s_t365d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_0s_t365d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.02/1.22
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cnt_0s_t365d_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_0s_t365d_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.22 / 1.33


### quick look
# buy better than sell, buy's zscore is the best
cs = ['cnt_z_lt2', 'cnt_b_z_lt2', 'cnt_s_z_lt2', 'cnt_n_lt2_dv_tot',
       'cnt_z_lt2_09451130', 'cnt_b_z_lt2_09451130', 'cnt_s_z_lt2_09451130', 'cnt_n_lt2_dv_tot_09451130',
       'cnt_z_lt2_13001445', 'cnt_b_z_lt2_13001445', 'cnt_s_z_lt2_13001445', 'cnt_n_lt2_dv_tot_13001445']
for c in cs:
    icom[c+'_bk'] = icom.groupby('datadate')[c].apply(lambda x: yu.pdqcut(x,bins=10)).values
    yu.create_cn_3x3(icom, [c+'_bk'], c)

icom['cnt_b_z_lt2_rk'] = icom.groupby('datadate')['cnt_b_z_lt2'].apply(yu.uniformed_rank).values
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cnt_b_z_lt2_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_b_z_lt2_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.18 / -25


icom['cnt_dv_tot_bk'] = icom.groupby('datadate')['cnt_dv_tot'].apply(lambda x:yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cnt_dv_tot_bk'], 'cnt_dv_tot') # less mono: -2 -5 +4

 
icom['cnt_b_dv_tot_09451130'] = (icom['cnt_b_avg_lt2_09451130']-icom['cnt_b_avg_gt2_0
9451130']).divide(icom['cnt_b_tot_09451130'] + icom['cnt_s_tot_09451130'])
icom['cnt_b_dv_tot_09451130_bk'] = icom.groupby('datadate')['cnt_b_dv_tot_09451130'].apply(lambda x:yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cnt_b_dv_tot_09451130_bk'], 'cnt_b_dv_tot_09451130') # v-shape: 1 -2 +5

icom['cnt_b_dv_tot_13001445'] = (icom['cnt_b_avg_lt2_13001445']-icom['cnt_b_avg_gt2_13001445']).divide(icom['cnt_b_tot_13001445'] + icom['cnt_s_tot_13001445'])
icom['cnt_b_dv_tot_13001445_bk'] = icom.groupby('datadate')['cnt_b_dv_tot_13001445'].apply(lambda x:yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cnt_b_dv_tot_13001445_bk'], 'cnt_b_dv_tot_13001445') # v-shape: 1 -3 +5

icom['cnt_b_dv_totB_13001445'] = (icom['cnt_b_avg_lt2_13001445']-icom['cnt_b_avg_gt2_13001445']).divide(icom['cnt_b_tot_13001445'])
icom['cnt_b_dv_totB_13001445_bk'] = icom.groupby('datadate')['cnt_b_dv_totB_13001445'].apply(lambda x:yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cnt_b_dv_totB_13001445_bk'], 'cnt_b_dv_totB_13001445') # v-shape: 1 -3 +5


icom['cnt_b_z_lt2_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['cnt_b_z_lt2'].mean().values
icom['cnt_b_z_lt2_t20d_rk'] = icom.groupby('datadate')['cnt_b_z_lt2_t20d'].apply(yu.uniformed_rank).values
icom['cnt_b_z_lt2_t40d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['cnt_b_z_lt2'].mean().values
icom['cnt_b_z_lt2_t40d_rk'] = icom.groupby('datadate')['cnt_b_z_lt2_t40d'].apply(yu.uniformed_rank).values
icom['cnt_b_z_lt2_t60d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=84),on='datadate')['cnt_b_z_lt2'].mean().values
icom['cnt_b_z_lt2_t60d_rk'] = icom.groupby('datadate')['cnt_b_z_lt2_t60d'].apply(yu.uniformed_rank).values
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cnt_b_z_lt2_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_b_z_lt2_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.11 / 0.73
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cnt_b_z_lt2_t40d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_b_z_lt2_t40d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.72 / 1.69
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cnt_b_z_lt2_t60d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_
b_z_lt2_t60d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.13 / 1.58



icom['cnt_dv_tot_bk'] = icom.groupby('datadate')['cnt_dv_tot'].apply(lambda x:yu.pdqcut(x,bins=10)).values
icom['cnt_dv_tot_rk'] = icom.groupby('datadate')['cnt_dv_tot'].apply(yu.uniformed_rank).values
icom['cnt_dv_tot_orth'] = icom.groupby('datadate')[['cnt_dv_tot']+COLS].apply(lambda x: yu.orthogonalize_cn(x['cnt_dv_tot'], x[COLS])).values
icom['cnt_dv_tot_orth_bk'] = icom.groupby('datadate')['cnt_dv_tot_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_dv_tot_xNeg']=np.nan
icom.loc[icom['cnt_dv_tot']>0, 'cnt_dv_tot_xNeg'] = icom.loc[icom['cnt_dv_tot']>0, 'cnt_dv_tot']
icom['cnt_dv_tot_xNeg_ln'] = np.log(icom['cnt_dv_tot_xNeg'])
icom['cnt_dv_tot_xNeg_ln_bk'] = icom.groupby('datadate')['cnt_dv_tot_xNeg_ln'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_dv_tot_xNeg_ln_orth'] = icom.groupby('datadate')[['cnt_dv_tot_xNeg_ln']+COLS].apply(lambda x: yu.orthogonalize_cn(x['cnt_dv_tot_xNeg_ln'], x[COLS])).values
icom['cnt_dv_tot_xNeg_ln_orth_bk'] = icom.groupby('datadate')['cnt_dv_tot_xNeg_ln_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_dv_tot_xNeg_ln_orth_rk'] = icom.groupby('datadate')[['cnt_dv_tot_xNeg_ln_orth']+COLS].apply(lambda x: yu.orthogonalize_cn(x['cnt_dv_tot_xNeg_ln_orth'], x[COLS])).values

icom['cnt_dv_tot_xNeg_ln_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['cnt_dv_tot_xNeg_ln_orth'].mean().values
icom['cnt_dv_tot_xNeg_ln_orth_t20d_rk'] = icom.groupby('datadate')['cnt_dv_tot_xNeg_ln_orth_t20d'].apply(yu.uniformed_rank).values
icom['cnt_dv_tot_xNeg_ln_orth_t60d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=84),on='datadate')['cnt_dv_tot_xNeg_ln_orth'].mean().values
icom['cnt_dv_tot_xNeg_ln_orth_t60d_rk'] = icom.groupby('datadate')['cnt_dv_tot_xNeg_ln_orth_t60d'].apply(yu.uniformed_rank).values


yu.create_cn_3x3(icom, ['cnt_dv_tot_bk'], 'cnt_dv_tot') # less mono: -2 -4 +4
yu.create_cn_3x3(icom, ['cnt_dv_tot_orth_bk'], 'cnt_dv_tot_orth') # -1.5 -4 +6
yu.create_cn_3x3(icom, ['cnt_dv_tot_xNeg_ln_bk'], 'cnt_dv_tot_xNeg_ln') # mono: -4.5 +4.5
yu.create_cn_3x3(icom, ['cnt_dv_tot_xNeg_ln_orth_bk'], 'cnt_dv_tot_xNeg_ln_orth') # mono: -4 +6
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cnt_dv_tot_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_dv_tot_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 5.11/-1
8
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cnt_dv_tot_xNeg_ln_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_dv_tot_xNeg_ln_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.31/-17
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cnt_dv_tot_xNeg_ln_orth_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_dv_tot_xNeg_ln_orth_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.73/2.71, 4.5e7 ###!!!
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cnt_dv_tot_xNeg_ln_orth_t60d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_dv_tot_xNeg_ln_orth_t60d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.89/2.91, 4.5e7 ###!!!






icom['cnt_b_z_dv_tot_bk'] = icom.groupby('datadate')['cnt_b_z_dv_tot'].apply(lambda x:yu.pdqcut(x,bins=10)).values
icom['cnt_b_dv_tot_xNeg']=np.nan
icom.loc[icom['cnt_b_z_dv_tot']>0, 'cnt_b_dv_tot_xNeg'] = icom.loc[icom['cnt_b_z_dv_tot']>0, 'cnt_b_z_dv_tot']
icom['cnt_b_dv_tot_xNeg_ln'] = np.log(icom['cnt_b_dv_tot_xNeg'])
icom['cnt_b_dv_tot_xNeg_ln_bk'] = icom.groupby('datadate')['cnt_b_dv_tot_xNeg_ln'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_b_dv_tot_xNeg_ln_orth'] = icom.groupby('datadate')[['cnt_b_dv_tot_xNeg_ln']+COLS].apply(lambda x: yu.orthogonalize_cn(x['cnt_b_dv_tot_xNeg_ln'], x[COLS])).values
icom['cnt_b_dv_tot_xNeg_ln_orth_bk'] = icom.groupby('datadate')['cnt_b_dv_tot_xNeg_ln_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_b_dv_tot_xNeg_ln_orth_rk'] = icom.groupby('datadate')['cnt_b_dv_tot_xNeg_ln_orth'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icom, ['cnt_b_z_dv_tot_bk'], 'cnt_b_z_dv_tot') # 0 -4 +5
yu.create_cn_3x3(icom, ['cnt_dv_tot_xNeg_ln_orth_bk'], 'cnt_dv_tot_xNeg_ln_orth') # -2 +4 +2

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cnt_b_dv_tot_xNeg_ln_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_b_dv_tot_xNeg_ln_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.8/-16



### cnt + o2c
# not working

icom['cnt_z_lt2'] = icom['cnt_z_lt2'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
icom['cnt_z_lt2_rk'] = icom.groupby('datadate')['cnt_z_lt2'].apply(yu.uniformed_rank).values

icom['o2c_ret_t20d'] = icom.groupby('ticker').rol
ling(datetime.timedelta(days=20),on='datadate')['o2c_ret'].mean().values
icom['o2c_ret_t20d_rk'] = icom.groupby('datadate')['o2c_ret_t20d'].apply(yu.uniformed_rank).values

icom['test_sgnl'] = np.nan
icom.loc[(icom['o2c_ret_t20d_rk']<-0.8)&(icom['cnt_z_lt2_rk']>0.8), 'test_sgnl'] = 1
icom['test_sgnl'] = icom.groupby('ticker')['test_sgnl'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['test_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.66 / 0.57


### cnt

icom['cnt_z_lt2'] = icom['cnt_z_lt2'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
icom['cnt_z_lt2_bk'] = icom.groupby('datadate')['cnt_z_lt2'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['cnt_avg_lt2gt2'] = icom['cnt_avg_lt2'].divide(icom['cnt_avg_gt2'])
icom['cnt_avg_lt2gt2_bk'] = icom.groupby('datadate')['cnt_avg_lt2gt2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_avg_lt2gt2_orth'] = icom.groupby('datadate')[COLS+['cnt_avg_lt2gt2']].apply(lambda x: yu.orthogonalize_cn(x['cnt_avg_lt2gt2'], x[COLS])).values
icom['cnt_avg_lt2gt2_orth_bk'] = icom.groupby('datadate')['cnt_avg_lt2gt2_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values


yu.create_cn_3x3(icom, ['cnt_z_lt2_bk'], 'cnt_z_lt2') # mono: -5 +2
yu.create_cn_3x3(icom, ['cnt_avg_lt2gt2_orth_bk'], 'cnt_avg_lt2gt2_orth') # less mono: -1 -4 +6

## order volume

icom['odV_z_lt2'] = icom['odV_z_lt2'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
icom['odV_z_lt2_bk'] = icom.groupby('datadate')['odV_z_lt2'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['odV_avg_lt2gt2'] = icom['odV_avg_lt2'].divide(icom['odV_avg_gt2'])
icom['odV_avg_lt2gt2_bk'] = icom.groupby('datadate')['odV_avg_lt2gt2'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['odV_z_lt2_bk'], 'odV_z_lt2') # less mono: -2 +2.5 0.5
yu.create_cn_3x3(icom, ['odV_avg_lt2gt2_bk'], 'odV_avg_lt2gt2') # random





