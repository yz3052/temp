﻿#$%^&* pWIND_strat_dragontiger_1.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Aug  4 15:54:29 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

# this tries to follow the strongest branches


### get to-be delisted stocks
i_delist = pw.get_delist_tag()

#### get recent IPO
i_ipo_date = pw.get_ipo_date()

### get fragon tiger 



i_dt = yu.get_sql('''select * from wind.dbo.asharestrangetrade''')

i_dt = i_dt.drop(columns=['OBJECT_ID','OPMODE','OPDATE'])
i_dt = i_dt.rename(columns={'S_INFO_WINDCODE':'ticker', 'S_STRANGE_ENDDATE': 'datadate'})
i_dt['S_VARIANT_DESC'] = i_dt['S_VARIANT_TYPE'].apply(lambda x: dt_reason[x[:2]])
i_dt['net_amt'] = i_dt['S_STRANGE_BUYAMOUNT'].fillna(0) - i_dt['S_STRANGE_SELLAMOUNT'].fillna(0)
i_dt = i_dt[~i_dt['S_VARIANT_TYPE'].str.contains('19')]

i_dt['datadate'] = pd.to_datetime(i_dt['datadate'], format='%Y%m%d')
i_dt = i_dt.merge(i_ipo_date, on = 'ticker', how = 'left')
i_dt =  i_dt[(i_dt['datadate'] - i_dt['ipo_date']).dt.days>180] # no ipo
i_dt = i_dt.drop(columns = ['ipo_date'])

i_dt = i_dt.merge(i_delist, on = ['ticker', 'datadate'], how = 'left')
i_dt = i_dt[i_dt['delist_flag']!=1]
i_dt = i_dt.drop(columns = ['delist_flag']) # no delist


### get sd, pv

i_sd = pw.get_ashare_t1800_sd()


### get barra ret

i_ret = pd.read_parquet(r'S:\TZ\tmp\util_prepare_fut_1800.parquet')
i_ret['bret_fwdlk120d'] = i_ret[['BarrRet_CLIP_USD_p'+str(i)+'d' for i in range(1, 121)]].sum(axis=1)
i_ret['bret_fwdlk60d'] = i_ret[['BarrRet_CLIP_USD_p'+str(i)+'d' for i in range(1, 61)]].sum(axis=1)
i_ret['bret_fwdlk20d'] = i_ret[['BarrRet_CLIP_USD_p'+str(i)+'d' for i in range(1, 21)]].sum(axis=1)
i_ret = i_ret.drop(columns = ['BarrRet_CLIP_USD_p'+str(i)+'d' for i in range(1, 121)])

c_sh = i_ret['Ticker'].str[0].isin(['6'])
c_sz = i_ret['Ticker'].str[0].isin(['0','3'])
i_ret.loc[c_sh, 'ticker'] = i_ret.loc[c_sh, 'Ticker'] + '.SH'
i_ret.loc[c_sz, 'ticker'] = i_ret.loc[c_sz, 'Ticker'] + '.SZ'
i_ret = i_ret.drop(columns = ['Ticker', 'T-1d'])
i_ret = i_ret.rename(columns = {'DataDate': 'datadate_p1d'})



### generate daily signals 

i_dt_s2 = i_sd[['ticker', 'datadate', 'avgPVadj', 'datadate_p1d']].merge(i_dt, on = ['ticker', 'datadate'], how = 'inner')
i_dt_s2 = i_dt_s2.merge(i_ret, on = ['datadate_p1d', 'ticker'], how = 'left')
i_dt_s2['flg_bs'] = np.nan
i_dt_s2.loc[(i_dt_s2['net_amt']/i_dt_s2['avgPVadj'])>0.05, 'flg_bs'] = 1
i_dt_s2.loc[(i_dt_s2['net_amt']/i_dt_s2['avgPVadj'])<-0
.05, 'flg_bs'] = -1


o_dt_stat = []
for dd in pd.date_range(start='2018-01-01', end='2021-06-30'):
    print(dd.strftime('%Y%m%d'),end=',')
    
    t_dt_today = i_dt_s2[i_dt_s2['datadate'] == dd]
    t_dt_today = t_dt_today[(t_dt_today['net_amt']/i_dt_s2['avgPVadj']).abs()>0.05]
        
    if len(t_dt_today) == 0:
        continue
    
    t_dt_hist = i_dt_s2[i_dt_s2['DataDate_p120d'].lt(dd) \
                        & i_dt_s2['datadate'].ge(dd-pd.to_timedelta('1000 days')) \
                        & i_dt_s2['S_STRANGE_TRADERNAME'].isin(t_dt_today['S_STRANGE_TRADERNAME'].tolist())]
    
    t_dt_grp = t_dt_hist.groupby(['S_STRANGE_TRADERNAME','flg_bs'])
    s_dt_grp = pd.concat([t_dt_grp['bret_fwdlk120d'].apply(lambda x: x.mean() / x.std() * np.sqrt(x.count()) if x.std()!=0 else np.nan ),
                          t_dt_grp['bret_fwdlk120d'].count()], axis=1)    
    s_dt_grp.columns = ['t', 'cnt']    
    s_dt_grp = s_dt_grp[s_dt_grp['cnt'].ge(10) & s_dt_grp['t'].abs().ge(2)]
    s_dt_grp = s_dt_grp.reset_index()
    s_dt_grp['flg_dir'] = np.nan
    s_dt_grp.loc[s_dt_grp['t']>5, 'flg_dir'] = 1
    s_dt_grp.loc[s_dt_grp['t']<-2, 'flg_dir'] = -1

    
    t_dt_today = t_dt_today.merge(s_dt_grp[['S_STRANGE_TRADERNAME', 'flg_bs', 'cnt', 'flg_dir']], 
                                  on = ['S_STRANGE_TRADERNAME', 'flg_bs'], how = 'left')
    s_dt_today = t_dt_today.groupby('ticker')['flg_dir'].sum().reset_index()
    s_dt_today['datadate'] = dd
    o_dt_stat.append(s_dt_today)

o_dt_stat = pd.concat(o_dt_stat, axis = 0)



### combine

icom = i_sd.merge(o_dt_stat, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom.loc[icom['flg_dir']>1, 'flg_dir'] = 1
icom.loc[icom['flg_dir']<-1, 'flg_dir'] = -1

yu.create_cn_decay(icom[icom['flg_dir']==1], 'flg_dir')
yu.create_cn_decay(icom[icom['flg_dir']==-1], 'flg_dir')


icom['sgnl_l'] = np.nan
icom.loc[icom['flg_dir']==1, 'sgnl_l'] = 1
icom['sgnl_l'] = icom.groupby('ticker')['sgnl_l'].ffill(limit=120)

icom['sgnl_s'] = np.nan
icom.loc[icom['flg_dir']==-1, 'sgnl_s'] = -1
icom['sgnl_s'] = icom.groupby('ticker')['sgnl_s'].ffill(limit=60)

icom['sgnl_all'] = icom[['sgnl_l', 'sgnl_s']].sum(axis=1)


o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_l','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_l','BarrRet_CLIP_USD+1d', static_data = i_sd) # random

o_1 = yu.bt_cn_15(ic
om[(icom['datadate'].between('2018-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_s','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_s','BarrRet_CLIP_USD+1d', static_data = i_sd) #1.07 / 0.92 / -0.03

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_all','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_all','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.4 / 1.16



t1 = o_1.groupby('ticker')['pnl_ac'].sum()
002356
603160
t1 = icom[icom.ticker=='002356.SZ']

