﻿#$%^&* pWIND_strat_QFII.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 10 09:28:41 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

### QFII

i_qfii = yu.get_sql('''select * from wind.dbo.ASHAREINSTHOLDERDERDATA where S_HOLDER_HOLDERCATEGORY = 'QFII' ''')
i_qfii['datadate'] = pd.to_datetime(i_qfii['ANN_DATE'], format='%Y%m%d')
i_qfii['ticker'] = i_qfii['S_INFO_WINDCODE']
i_qfii = i_qfii.drop(columns=['OBJECT_ID','ANN_DATE','S_INFO_WINDCODE','OPDATE','OPMODE'])

i_qfii.loc[i_qfii['S_HOLDER_COMPCODE'].isin(['08R9EZY049', '04NA6570DA', '08A4E09053',
           '04R858BE6D','04R7DD4957','QA29ACCD','27U4F7464D','0SB577B1CB','08R9CG1249',
           '1A893896DD']), 'flag_bb'] = 1

i_qfii = i_qfii.sort_values(['ticker','datadate'])


### most recent report period

i_disclosure = yu.get_sql('''select distinct s_info_windcode as ticker, ann_date as datadate 
                          from wind.dbo.ASHAREINSTHOLDERDERDATA''')
i_disclosure = i_disclosure[i_disclosure['datadate'].notnull()]
i_disclosure['datadate'] = pd.to_datetime(i_disclosure['datadate'], format='%Y%m%d')


### Calculate QFII metrics

o_qfii_sum = []

for dt in pd.date_range(start = '2016-01-01', end= '2020-12-31'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    # for each ticker and most-recent-report-period, find qfii holding
    t_qfii = i_qfii[i_qfii['datadate'].between(dt-pd.to_timedelta('100 days'), dt)]

    t_qfii = t_qfii.drop_duplicates(subset = ['ticker','S_HOLDER_COMPCODE'], keep = 'last')
    
    t_qfii_sum1 = t_qfii.groupby('ticker')['S_HOLDER_COMPCODE'].nunique().reset_index()
    t_qfii_sum2 = t_qfii.groupby('ticker')['S_HOLDER_PCT'].sum().reset_index()
    t_qfii_sum3 = t_qfii.groupby('ticker')['flag_bb'].sum().reset_index()
    
    t_qfii_sum = t_qfii_sum1.merge(t_qfii_sum2, on = 'ticker', how = 'outer')
    t_qfii_sum = t_qfii_sum.merge(t_qfii_sum3, on = 'ticker', how = 'outer')
    
    t_qfii_sum['datadate'] = dt
    o_qfii_sum.append(t_qfii_sum)
    
o_qfii_sum = pd.concat(o_qfii_sum, axis = 0)

    

### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['ticker', 'datadate'])

i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d','V_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','csi300_
flag']]


### combine

icom = i_sd.merge(o_qfii_sum, on = ['ticker','datadate'], how = 'left')


#icom['S_HOLDER_COMPCODE'] = icom['S_HOLDER_COMPCODE'].fillna(0)
icom['qfiiCnt_rk'] = icom.groupby('datadate')['S_HOLDER_COMPCODE'].apply(yu.uniformed_rank).values
icom['qfiiCnt_bk'] = icom.groupby('datadate')['S_HOLDER_COMPCODE'].apply(lambda x: yu.pdqcut(x,bins=10)).values

#icom['S_HOLDER_PCT'] = icom['S_HOLDER_PCT'].fillna(0)
icom['pctOfComp_qfii_rk'] = icom.groupby('datadate')['S_HOLDER_PCT'].apply(yu.uniformed_rank).values
icom['pctOfComp_qfii_bk'] = icom.groupby('datadate')['S_HOLDER_PCT'].apply(lambda x: yu.pdqcut(x,bins=10)).values


icom.loc[icom['S_HOLDER_COMPCODE']>=1, 'sgnl1'] = 1
icom.loc[icom['flag_bb']>=1, 'sgnl_bb'] = 1


yu.create_cn_3x3(icom, ['qfiiCnt_bk'], 'S_HOLDER_COMPCODE')
yu.create_cn_3x3(icom, ['pctOfComp_qfii_bk'], 'S_HOLDER_PCT')


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.29 / 0.79

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl_bb','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_bb','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.81/0.63

