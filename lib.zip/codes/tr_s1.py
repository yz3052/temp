﻿#$%^&* tr_s1.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 10 14:25:10 2020

@author: thzhang
"""


import os, gc
import inspect
from yz import get_sql, print_progress
from yz.util import pickle_bz_dump, pickle_bz_load

import pandas as pd
import numpy as np
from numba import njit, jit
from datetime import date, datetime

import statsmodels.api as sm
import cvxpy as cp

import pickle

import matplotlib.pyplot as plt

from bokeh.io import show
from bokeh.layouts import column, gridplot
from bokeh.models import ColumnDataSource, RangeTool, HoverTool, CustomJS, CrosshairTool, LinearAxis, Range1d
from bokeh.plotting import figure


# feature of the bt() function:
# 1) Input = DataFrame (entry signal + other features), DataFrame(bbg mkt data and TA)
# 1.1) main input: df_tk_dt_sgnl_feature
#                   - not pivoted
#                   - assume it is sorted by ticker and datadate
#                   - columns must include "ticker" and "datadate"
# 2) main purpose: calculate holding period and stop loss / win 
# 2.1) main limimation: cannot calculate any mkt data related metrics (e.g. TA) in strategy because everything is pivoted
#                       we only do that ticker by ticker (e.g. when a stock halts trading for a few days...)
# 3) numba core function
# 4) generate GF's backtest pnl chart
# 5) generate GF's quintile table and automatically adjust to binary if signals are binary 
# 6) vizualize other backtest variables in bokeh

class Backtest_200910(object):
    
    def __init__(self, df_tk_dt_sgnl_feature, str_sgnl_column, df_bbg_data, str_from_ymd, str_to_ymd):
        
        
        
        print (str(datetime.now()) + ' - __init__ starts.')
        
        #----------------------------------------------------------------------
        ### dates and ticker
        #----------------------------------------------------------------------        
        
        # cdates
        self.cdates = pd.date_range(start=df_tk_dt_sgnl_feature.datadate.min()-pd.to_timedelta('365 days'), 
                                    end=df_tk_dt_sgnl_feature.datadate.max()+pd.to_timedelta('365 days')).tolist()
        
        # tk uni
        self.tk = df_tk_dt_sgnl_feature.ticker.unique().tolist()
        
        print ('cdates and tk done.')
        
        #----------------------------------------------------------------------
        ### process signals
        #----------------------------------------------------------------------   
      
  
        # quality check signals
        if df_tk_dt_sgnl_feature.duplicated(subset=['ticker','datadate'],keep= False).sum() > 0:
            raise Exception("Duplicated ticker / datadate detected in signals.")
        
        # pivot table 
        self.pv_sgnl = df_tk_dt_sgnl_feature.pivot_table(index= 'datadate', columns = 'ticker', values = str_sgnl_column)
        self.pv_sgnl = self.pv_sgnl.set_index('datadate')
        self.pv_sgnl = self.pv_sgnl.reindex(columns = self.tk).reindex(index = self.cdates)
        self.mx_sgnl = self.pv_sgnl.values
        
        print ('sgnl done.')
        
        #----------------------------------------------------------------------
        ### load bbg data (generated in util.py)
        #----------------------------------------------------------------------
        
        # load data
        if df_bbg_data is None:
            self.df_mkt = pd.read_parquet(r"S:\Infrastructure\backtester\data_cache\bbg_mkt_data_v2.parquet")
        else:
            self.df_mkt = df_bbg_data
        
        # quality check
        if self.df_mkt.duplicated(subset=['ticker','datadate'], keep = False).sum() > 0:
            raise Exception("Duplicated ticker / datadate detected in mkt data.")
        
        # tdates
        self.tdates = pd.date_range(start=self.df_mkt.datadate.min(), 
                                    end=self.df_mkt.datadate.max()).tolist()
        
        
        # save np matrices to dic_mkt
        self.dic_mkt_tdate = {}
        self.dic_mkt_cdate = {}
        
        for c in ['ret_c_c', 'ret_o_c', 'ret_optPeriod', 'c_dema_df', 'c_dema_s', 
                  'c_dema_l', 'zz_curr_trend', 'zz_curr_idx', 'zz_vertex_1', 
                  'zz_vertex_idx1', 'zz_vertex_2', 'zz_vertex_idx2', 'zz_vertex_3', 
                  'zz_vertex_idx3', 'zz_vertex_4', 'zz_vertex_idx4', 'zz_vertex_5', 
                  'zz_vertex_idx5', 'zz_vertex_6', 'zz_vertex_idx6', 'zz_vertex_7', 
                  'zz_vertex_idx7', 'zz_vertex_8', 'zz_vertex_idx8', 'zz_vertex_10', 
                  'zz_vertex_idx10', 'uni_ret_std', 'uni_ret_mean', 'bgmv_ret_15std', 
                  'bgmv_ret_2std', 'vol_ret', 'ticker_hdg', 'ret_c_c_hedge', 
                  'ret_o_c_hedge', 'hret_c_c', 'hret_o_c', 'hret_o_c_p1d', 
                  'hret_c_c_p1d', 'hret_pid', 'hret_optPeriod', 'hret_bo_l', 
                  'hret_bo_ema', 'hret_bo_u', 'hret_bo_coef', 'hret_ema_df', 
                  'hret_dema_s', 'hret_dema_l', 'uni_hr
et_std', 'uni_hret_mean',
                  'bgmv_hret_15std', 'bgmv_hret_2std', 'vol_hret', 'bd2e', 'cd2e', 
                  'bdae', 'cdae', 'adpv','adpv_1d']:
            t1 = self.df_mkt.pivot_table(index = 'datadate', columns='ticker', values = c)
            t1 = t1.set_index('datadate')
            t1 = t1.reindex(columns = self.tk)
            self.dic_mkt[c] = t1.values
            
            del t1
            gc.collect()
        
        # tdate cdate index mapping
        df_cdates = pd.DataFrame(self.cdates, columns = ['cdates'])
        df_cdates['id_cdates'] = df_cdates.index.values
        
        df_tdates = pd.DataFrame(self.tdates, columns = ['tdates'])
        df_tdates['cdates'] = df_tdates['tdates']
        df_tdates['id_tdates'] = df_tdates.index.values
        
        df_ct_mapping = df_cdates.merge(df_tdates, on = ['cdates'], how = 'left')
        df_ct_mapping['id_tdates'] = df_ct_mapping['id_tdates'].fillna(method = 'ffill')
        
        dic_ct_mapping = 
        
            
        #----------------------------------------------------------------------
        ### clip size
        #----------------------------------------------------------------------
        
        self.mx_clipD = self.df_mkt.pivot_table(index = 'datadate', columns='ticker', values = 'adpv_1d')
        self.mx_clipD = self.mx_clipD.set_index('datadate')
        self.mx_clipD = self.mx_clipD.reindex(columns = self.tk).reindex(index = self.cdates)
        self.mx_clipD = self.mx_clipD.fillna(method = 'ffill')
        self.mx_clipD = self.mx_clipD*0.01
        self.mx_clipD[self.mx_clipD>1e6] = 1e6
        
        #----------------------------------------------------------------------
        ### strategy variables 
        #----------------------------------------------------------------------
        
        # strat variables        
        self.mx_pstD_bo = self.h_create_zero_mx()
        self.mx_pstD_bc = self.h_create_zero_mx()
        self.mx_pstS_bo = self.h_create_zero_mx()
        self.mx_pstS_bc = self.h_create_zero_mx()
        
        self.mx_ordD_unfilled = self.h_create_zero_mx()
        
        self.mx_ordD_bo = self.h_create_zero_mx()
        self.mx_ordD_bc = self.h_create_zero_mx()
        self.mx_ordS_bo = self.h_create_zero_mx()
        self.mx_ordS_bc = self.h_create_zero_mx()
        self.mx_ordPct_bo = self.h_create_zero_mx()
        self.mx_ordPct_bc = self.h_create_zero_mx()
        
        self.mx_pnlD = self.h_create
_zero_mx()
        
        self.mx_barsheld_since_pst_open = self.h_create_zero_mx() - 1
        self.mx_tbarsheld_since_pst_open = self.h_create_zero_mx() - 1
        
        self.mx_tbar_unfilled_ord = self.h_create_zero_mx()
        self.mx_cbar_unfilled_ord = self.h_create_zero_mx()
        
        self.mx_curr_pst_pnlD = self.h_create_zero_mx()
        
        self.mx_vD_quota = self.h_create_zero_mx()
        self.mx_ones = self.h_create_zero_mx() + 1
        
        # state matrix
        self.dic_state = {}
        
        #----------------------------------------------------------------------
        ### reporting variables
        #----------------------------------------------------------------------  
        
        self.dic_report = {}
        
        print (str(datetime.now()) + ' - Initiation done.')
        
    def h_create_zero_mx(self):
        return np.zeros([len(self.cdates),len(self.tk)])

    
    # ----- loop over strat -----
    
    @jit(forceobj=True)
    def start(self, strat_f, dict_param):
        
        for num in range(len(self.cdates)):
            
            # skip over the first few bars
            if num < 1:
                continue
            
            #---------------------------------------------------------------------------------
            #                                         Carry on pst + unfilled order @ mkt open
            #---------------------------------------------------------------------------------
            
            # carry on unfilled order from the previous bar
            self.mx_ordD_unfilled[num,:] = self.mx_ordD_unfilled[num-1,:]            
            
            # carry on pst from the previous bar
            self.mx_pstD_bo[num,:] = self.mx_pstD_bc[num-1,:]
            
            #---------------------------------------------------------------------------------
            #                                                        set up daily volume quota
            #---------------------------------------------------------------------------------
            
            # setup vD quota before filling orders            
            self.vc_vD_quota = np.nan_to_num(self.arr_vD[num,:]) * 0.02
            self.dic_mkt['adpv_1d'][num,:]
            
            # vD quota is 0 if price is nan
            self.vc_vD_quota[np.isnan(self.arr_cc_ret[num,:])] = 0
