﻿#$%^&* scraper_p5w.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 24 19:11:40 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import requests

import datetime

from sqlalchemy import create_engine

# this scrapes all history from this url: https://rs.p5w.net/roadshow


proxies = {'http':'http://thzhang:Citadel600912!@proxy.mlp.com:3128','https':'https://thzhang:Citadel600912!@proxy.mlp.com:3128'} 


COOKIES = 'Hm_lvt_ed9dac8a2b525df95dc69c97bbcda470=1621129823; SHRIOSESSIONID_RS=726855d6-1e77-4a70-8e39-753752a84cb6; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%2217882fcaf2f878-06f155b0f17bb5-d373666-2073600-17882fcaf30972%22%2C%22first_id%22%3A%22%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E7%9B%B4%E6%8E%A5%E6%B5%81%E9%87%8F%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC_%E7%9B%B4%E6%8E%A5%E6%89%93%E5%BC%80%22%2C%22%24latest_referrer%22%3A%22%22%7D%2C%22%24device_id%22%3A%2217882fcaf2f878-06f155b0f17bb5-d373666-2073600-17882fcaf30972%22%7D'

headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Connection':'keep-alive',
    'Cookie': COOKIES,
    'Content-Length': '58',
    'Host': 'rs.p5w.net',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Origin': 'https://rs.p5w.net',
    'Referer': 'https://rs.p5w.net/roadshow',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest'}


data = {'perComType': '0',
        'newRoadshowType': '',
        'roadshowDate': '',
        'page': '0',
        'rows': '30000'}


url = 'https://rs.p5w.net/roadshow/getAllRoadshowList.shtml'
response = requests.post(url, data=data, headers=headers, proxies=proxies, verify = False)
i_json = response.json()['rows']

df_json = pd.DataFrame(i_json)
df_json['scraper_ts_et'] = datetime.datetime.today()
df_json['datadate'] = datetime.date.today()

param_engine = create_engine('mssql+pyodbc://summitsqldb_cndbdev') #'mssql+pyodbc://FGSQLBACKTEST'
df_json.to_sql('p5w_events_hist', param_engine, index = False)

