﻿#$%^&* featurepool_cn_earn_ugdg_prodSYNC.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  7 17:08:04 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import os

import datetime

from sqlalchemy import create_engine
import urllib
import pyodbc






#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------


save_path = '/dat/summit_capital/TZ/PROD_FEATURES/featurepool_cn_desc_earn_ugdg'

conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
conn_wind = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=WIND_PROD;UID=svc_wind_dbo;PWD=DusONA3Habredl;TDS_Version=8.0;')

today = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
today = pd.to_datetime(today.date())
today_str = today.strftime('%Y%m%d')






#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------


i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()



#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------



dates_to_query = i_cal['DataDate'].dt.strftime('%Y%m%d.parquet').drop_duplicates().tolist()
dates_to_query = [d for d in dates_to_query if (d>='20170101.parquet') and (d<today.strftime('%Y%m%d.parquet'))]

existing_dates = os.listdir(save_path)

dates_to_query = [d for d in dates_to_query if d not in existing_dates]







#------------------------------------------------------------------------------
### metrics
#------------------------------------------------------------------------------


for i in dates_to_query:
    
    
    ### dates
    
    t_1d = pd.to_datetime(i, format='%Y%m%d.parquet')    
    t_1d_str = t_1d.strftime('%Y%m%d')
    t_182d_str = (t_1d - pd.to_timedelta('182 days')).strftime('%Y%m%d')    
    t_0d_str = 
i_cal.loc[i_cal['T-1d']==t_1d, 'DataDate'].dt.strftime('%Y-%m-%d').iloc[0]
    
    
    ### date ticker mapping
    
    i_dtk = pd.read_sql('''select datadate as [T-1d], ticker as Ticker
                        from cndbprod.dbo.universe_all_cn_gem3l 
                        with (nolock)
                        where datadate = '{0}'
                        '''.format(t_1d_str), conn)
    i_dtk = i_dtk.drop_duplicates(subset = ['T-1d', 'Ticker'], keep = 'last')
    
    
    ### ern ugdg
    
    i_ernug = pd.read_sql('''select Ticker, alpha as ern_ugdg_sgnl 
                       from CNDBPROD.dbo.SMTCN_CHILDALPHA_F008_ERNUG_T2000_SLOW_LO 
                       where datadate = '{0}'
                       '''.format(t_0d_str), conn)    
    
    
    # combine
                       
    icom = i_dtk.merge(i_ernug, on = ['Ticker'], how = 'left')
    icom = icom.merge(i_cal, on = 'T-1d', how = 'left')
    
    icom['ern_ugdg_sgnl'] = icom['ern_ugdg_sgnl'].fillna(0)
    
    
    if len(icom)>0:
        icom[['DataDate', 'Ticker', 'ern_ugdg_sgnl']].to_parquet(os.path.join(save_path, i))
    

