﻿#$%^&* pTA_cn_basket_csi300.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May 22 09:37:54 2023

@author: thzhang
"""



import pandas as pd
import numpy as np

import util as yu
import os
import datetime

# this studies market making orders, in another style
# not working at all



### get sd

i_sd = yu.get_sd_cn_1800()


### q

i_q = yu.get_q('''get `:/export/datadev/Data/SHSZ/ORDER_metrics/o_basket_300''')
i_q['code'] = i_q['code'].str.decode('utf8')
i_q = i_q.rename(columns = {'date':'T-1d', 'code':'Ticker'})


### get csi500 weights

i_csi300_cons = yu.get_sql('''select date_of_portfolio as DataDate, database_symbol as Ticker,
                           investable_weight as w 
                           FROM [CNDBPROD].[dbo].[CSI_300_NDCONS] ''')
i_csi300_cons['Ticker'] = i_csi300_cons['Ticker'].str[-6:]
i_csi300_cons['flg_is500'] = 1


### combine

icom = i_sd.merge(i_q, on = ['Ticker', 'T-1d'], how = 'left')
icom = icom.merge(i_csi300_cons, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom.sort_values(['Ticker', 'DataDate'])

icom.loc[icom['d_basket_b'].isnull() & icom['flg_is500'].eq(1), 'd_basket_b'] = 0
icom.loc[icom['d_basket_s'].isnull() & icom['flg_is500'].eq(1), 'd_basket_s'] = 0

icom['d_basket_b_w'] = icom.groupby('DataDate')['d_basket_b'].apply(lambda x: x/x.sum()).values
icom['d_basket_s_w'] = icom.groupby('DataDate')['d_basket_s'].apply(lambda x: x/x.sum()).values
icom['d_basket_net'] = icom['d_basket_b'] - icom['d_basket_s']
icom['d_basket_net_w'] = icom.groupby('DataDate')['d_basket_net'].apply(lambda x: x/x.abs().sum()).values

icom['b_dv_pv'] = icom['d_basket_b'] / icom['avgPVadj']
icom['s_dv_pv'] = icom['d_basket_s'] / icom['avgPVadj']
icom['net_dv_pv'] = icom['d_basket_net'] / icom['avgPVadj']

icom['bw_diff'] = icom['d_basket_b_w'] - icom['w']
icom['bw_grwth'] = (icom['d_basket_b_w'] - icom['w']) / (icom['d_basket_b_w'] + icom['w'])
icom['netw_diff'] = icom['d_basket_net_w'] - icom['w']

icom['sw_diff'] = icom['d_basket_s_w'] - icom['w']
icom['sw_grwth'] = (icom['d_basket_s_w'] - icom['w']) / (icom['d_basket_s_w'] + icom['w'])

icom['d_basket_net_w_rk'] = icom.groupby('DataDate')['d_basket_net_w'].apply(yu.uniformed_rank)
icom['d_basket_b_w_rk'] = icom.groupby('DataDate')['d_basket_b_w'].apply(yu.uniformed_rank)
icom['d_basket_s_w_rk'] = icom.groupby('DataDate')['d_basket_s_w'].apply(yu.uniformed_rank)
icom['w_rk'] = icom.groupby('DataDate')['w'].apply(yu.uniformed_rank)
icom['netw_rkdiff'] = icom
['d_basket_net_w_rk'] - icom['w_rk']
icom['bw_rkdiff'] = icom['d_basket_b_w_rk'] - icom['w_rk']
icom['sw_rkdiff'] = icom['d_basket_s_w_rk'] - icom['w_rk']


def explore1(c):
    icom[c+'_bk'] = icom.groupby('DataDate')[c].apply(lambda x: yu.pdqcut(x,bins=10)).values
    icom[c+'_bk'] = icom.groupby('Ticker')[c+'_bk'].ffill(limit=20)
    yu.create_cn_3x3_linux(icom, [c+'_bk'], c)
for c in ['netw_rkdiff', 'bw_rkdiff', 'sw_rkdiff', 
          'bw_diff', 'bw_grwth', 'sw_diff', 'sw_grwth', 'netw_diff',
          'b_dv_pv', 's_dv_pv', 'net_dv_pv',
          'd_basket_b', 'd_basket_s', 'd_basket_net']:
    explore1(c)
    
