﻿#$%^&* pTA_cn_zhiya.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Apr 13 19:56:14 2023

@author: thzhang
"""




import pandas as pd
import numpy as np

import util as yu

import datetime





### sd china

i_sd = yu.get_sd_cn_1800()
i_sd = i_sd.sort_values(['DataDate'])



### MC

i_mc = yu.get_sql('''select DataDate as [T-1d], Ticker, MC 
                  from  cndbprod.dbo.UNIVERSE_T2000_CN_GEM3L ''')




### |-- PV, c, adjfactor

i_pv = yu.get_sql_wind('''select substring(s_info_windcode,1,6) as Ticker, trade_dt as [T-1d],
                  S_DQ_AMOUNT*1000 as pv, s_dq_close as c, s_dq_adjfactor as f
                  from wind_prod.dbo.ashareeodprices
                  where trade_dt >= '20170101' 
                  and s_info_windcode not like '%BJ' ''')
i_pv['T-1d'] = pd.to_datetime(i_pv['T-1d'], format = '%Y%m%d')
i_pv['cadj'] = i_pv['c'] * i_pv['f']



### zigzag



### zhiya
# this comes from q

i_zhiya = pd.read_csv("/dat/summit_capital/TZ/China Data Hunt/cache/zhiya_metrics.csv")
i_zhiya['T-1d'] = pd.to_datetime(i_zhiya['datadate'])
i_zhiya['Ticker'] = i_zhiya['code'].astype(str).str.zfill(6)



### reversal


i_pastret = pd.read_parquet('/dat/summit_capital/TZ/China Data Hunt/cache/pWIND_util_prepare_trailing_ret.parquet',
                            columns = ['ticker', 'datadate', 'twap1000_2c_bret','twap1000_2c_bret_t4w'])
i_pastret = i_pastret.sort_values(['ticker','datadate'])
i_pastret = i_pastret.rename(columns = {'ticker':'Ticker', 'datadate':'T-1d'})




### combine

icom = i_sd.merge(i_zhiya, on = ['Ticker', 'T-1d'], how = 'left')
icom = icom.merge(i_mc, on = ['Ticker', 'T-1d'], how = 'left')
icom = icom.merge(i_pastret, on = ['Ticker', 'T-1d'], how = 'left')
icom = icom.sort_values(['Ticker', 'T-1d'])


icom['avgPVadj_dv_mc'] = icom['avgPVadj'] / icom['MC']
icom['avgPVadj_dv_mc_rk'] = icom.groupby('datadate')['avgPVadj_dv_mc'].apply(yu.uniformed_rank)

icom['o2c_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)



### idea 1: break up

icom['flg_no_ya'] = np.nan
c2 = icom['amt_ya'].isnull()
c3 = icom['avgPVadj_dv_mc_rk'] > -0.5
icom.loc[c2 & c3, 'flg_no_ya'] = 1

icom.loc[icom['o2c_rk'] > 0.9, 'flg_no_ya'] = 0
icom['sgnl_no_ya'] = icom.groupby('ticker')['flg_no_ya'].ffill(limit = 200)

o_1 = yu.bt_cn_15_linux(icom[(icom['datadate'].between('2018-01-01','2021-12-30'))].\
            dropna(subset=['sgnl_no_ya','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datad
ate']),
            'sgnl_no_ya','BarrRet_CLIP_USD+1d', static_data = i_sd)
#2.89 / 2.07, 5.8%



t1 = yu.explore(icom, 'sgnl_no_ya')
t2 = o_1.groupby('ticker')['pnl_ac'].sum().sort_values()
yu.ta_plot(icom, '002647.SZ', 'sgnl_no_ya', 'flg_no_ya')
t1 = icom[['sgnl_no_ya', 'ticker', 'datadate']]
t1['Ticker'] = t1['ticker'].str[:6]
t1['T-1d'] = t1['datadate']
t1['no_ya_sgnl'] = t1['sgnl_no_ya'].fillna(0)
t1[['Ticker', 'T-1d', 'no_ya_sgnl']].to_parquet(r'S:\TZ\tmp\zhiya_sgnl.parquet')


### idea 1.1: break up for the 1st time
# not working


icom['flg_no_ya'] = np.nan
c1 = (icom['days_since_ipo']>365) & (icom['flag_lmt_t1w']!=1) & (icom['flag_suspension_t1w']!=1)
c2 = icom['amt_ya'].isnull()
c3 = icom['pv_bk'] <2
icom.loc[c1 & c2 & c3, 'flg_no_ya'] = 1

icom['flg_no_ya_s2'] = np.nan
icom['flg_no_ya_sum1y'] = icom.groupby('ticker').rolling(252,min_periods=1)['flg_no_ya'].sum().values
icom.loc[icom['flg_no_ya_sum1y']==1, 'flg_no_ya_s2'] = 1

icom.loc[icom['o2c_rk'] > 0.9, 'flg_no_ya_s2'] = 0
icom['sgnl_no_ya'] = icom.groupby('ticker')['flg_no_ya_s2'].ffill(limit = 120)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_no_ya','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_no_ya','BarrRet_CLIP_USD+1d', static_data = i_sd)



### idea 1.2: break up + stop loss
# a ticker must perform right after we enter position
# as long as there is lmt dn, we stop win/loss

icom['flg_no_ya'] = np.nan
c1 = (icom['days_since_ipo']>365) & (icom['flag_lmt_t1w']!=1) & (icom['flag_suspension_t1w']!=1)
c2 = icom['amt_ya'].isnull()
icom.loc[c1 & c2, 'flg_no_ya'] = 1

icom['sgnl_no_ya'] = np.nan
icom.loc[icom['flg_no_ya'].eq(1) & icom['flg_no_ya'].shift().ne(1), 'sgnl_no_ya'] = 1

icom['flg_no_ya_days'] = icom.groupby('ticker')['flg_no_ya'].apply(yu.calc_tdays_since_bin_sgnl)
c1 = (icom['flg_no_ya_days']==60) & (icom['twap1000_2c_bret_t4w']<0)
icom.loc[c1, 'sgnl_no_ya'] = 0
icom.loc[icom['o2c_rk'] > 0.9, 'sgnl_no_ya'] = 0

icom['sgnl_no_ya'] = icom.groupby('ticker')['sgnl_no_ya'].ffill()

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_no_ya','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_no_ya','BarrRet_CLIP_USD+1d', static_data = i_sd)





    
### idea 2: break down


icom['flg_no_zhi'] = np.nan
icom.loc[icom['amt_zhi'].isnull(), 'flg_no_zhi'] = 1
yu.create_cn_decay(icom, '
flg_no_zhi') # all +ve

### idea 3: zhi and ya

icom['zhiya_pst'] = (icom['c_adj_tdy']*1000 - icom['padj_avg_zhi'])/(icom['padj_avg_ya'] - icom['padj_avg_zhi'])
icom['zhiya_pst_bk'] = icom.groupby('datadate')['zhiya_pst'].apply(lambda x: yu.pdqcut(x,bins=25)).values
yu.create_cn_3x3(icom, ['zhiya_pst_bk'], 'zhiya_pst') # random






