﻿#$%^&* pDTCC_cn_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Apr 21 15:17:10 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os

from pandas.tseries.offsets import BDay


### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])



### ISIN/Ticker mapping

i_isin = yu.get_sql("select datadate as Trade_Date, ticker, ISIN from [CNDBPROD].[dbo].[UNIVERSE_ALL_CN]")
c_sh = i_isin['ticker'].str[0].isin(['6'])
c_sz = i_isin['ticker'].str[0].isin(['0','3'])
i_isin.loc[c_sh, 'ticker'] = i_isin.loc[c_sh, 'ticker'] + '.SH'
i_isin.loc[c_sz, 'ticker'] = i_isin.loc[c_sz, 'ticker'] + '.SZ'
i_isin = i_isin.sort_values(['Trade_Date'])


### DTCC - HK

files = os.listdir(r'S:\Data\test\dtcc')
files = [i for i in files if i.endswith('csv') and ('APAC' in i)]

i_dtcc_hk = []
for f in files:
    t_data = pd.read_csv(os.path.join(r'S:\Data\test\dtcc',f))
    #t_data = t_data[t_data['Trade_currency']=='HKD']
    t_data = t_data[t_data['ISIN'].str.contains('CNE')]
    i_dtcc_hk.append(t_data)
i_dtcc_hk = pd.concat(i_dtcc_hk, axis = 0)
i_dtcc_hk['Trade_Date'] = pd.to_datetime(i_dtcc_hk['Trade_Date'])

i_dtcc_hk = i_dtcc_hk.sort_values(['Trade_Date'])
i_dtcc_hk = pd.merge_asof(i_dtcc_hk, i_isin, on = 'Trade_Date', by = 'ISIN')

i_dtcc_hk['datadate'] = i_dtcc_hk['Trade_Date'].apply(lambda x: x + BDay(3))

# =BDP(A52&" ISIN", "TICKER_AND_EXCH_CODE")
# http://data.10jqka.com.cn/market/ahgbj/


#http://data.10jqka.com.cn/market/ahgbj/
i_ah = pd.read_excel(r'S:\Data\China Data Hunt\AH_ticker_mapping.xlsx')
i_ah = i_ah[['hk','ashare']]
i_bbg = pd.read_excel(r'S:\Data\China Data Hunt\ISIN_BBG_mapping.xlsx')

i_dtcc_hk = i_dtcc_hk.merge(i_bbg, on = ['ISIN'], how = 'left')
c1 = i_dtcc_hk['BBG_TICKER'].str.endswith('CH') | i_dtcc_hk['BBG_TICKER'].str.endswith('HK')
i_dtcc_hk = i_dtcc_hk[i_dtcc_hk['ticker'].notnull() | c1]

# HK sampole too small .. only 7000 rows



### DTCC - China

files = os.listdir(r'S:\Data\test\dtcc')
files = [i for i in files if i.endswith('csv') and ('APAC' in i)]

i_dtcc = []
for f in files:
    t_data = pd.read_csv(os.path.join(r'S:\Data\test\dtcc',f))
    t_data = t_data[t_data['Trade_currency']=='CNY']
    i_dtcc.append(t_data)
i_dtcc = pd.concat(i_dtcc, axis = 0)
i_dtcc['Trade_Date'] = pd.to_datetime(i_dtcc['Trade_Date'])

i_dtcc = i_dtcc.sort_values(['Trade_Date'])
i_dtcc = pd.merge_asof(i_dtcc, i_isin, on = 'Trade_Date', by = 'ISIN')

i_dt
cc['datadate'] = i_dtcc['Trade_Date'].apply(lambda x: x + BDay(3))


### DTCC metrics (event)

i_dtcc_event = i_dtcc[['ticker','datadate','Buy_sell','Volume']]
i_dtcc_event = i_dtcc_event.groupby(['ticker', 'datadate', 'Buy_sell'])['Volume'].sum().reset_index()
i_dtcc_event = i_dtcc_event.pivot_table(index = ['ticker', 'datadate'], columns = 'Buy_sell', values= 'Volume')
i_dtcc_event = i_dtcc_event.reset_index()



### DTCC metrics (t1m)

s_dtcc = []
for dt in pd.date_range(start = '2017-01-01', end = '2020-06-30'):
    print(dt.strftime('%Y%m%d'), end=', ')
    
    t_dtcc = i_dtcc[(i_dtcc['datadate']<=dt)&(i_dtcc['datadate']>=dt-pd.to_timedelta('30 days'))]
    t_dtcc = t_dtcc[['ticker','Volume','Hfa_volume','Tam_volume','Buy_sell','Ims']]
    t_dtcc.loc[t_dtcc['Buy_sell']=='S', 'Volume'] = - t_dtcc.loc[t_dtcc['Buy_sell']=='S', 'Volume']
    t_dtcc.loc[t_dtcc['Buy_sell']=='S', 'Tam_volume'] = - t_dtcc.loc[t_dtcc['Buy_sell']=='S', 'Tam_volume']
    t_dtcc.loc[t_dtcc['Buy_sell']=='S', 'Hfa_volume'] = - t_dtcc.loc[t_dtcc['Buy_sell']=='S', 'Hfa_volume']
    
    sum1 = t_dtcc.groupby('ticker')['Volume'].sum().reset_index()
    sum1 = sum1.rename(columns = {'Volume': 'Volume_t1m'})
    sum2 = t_dtcc.groupby('ticker')['Ims'].sum().reset_index()
    sum2 = sum2.rename(columns = {'Ims': 'Ims_t1m'})
    
    sum_all = sum1.merge(sum2, on = 'ticker', how = 'outer')
    sum_all['datadate'] = dt
    
    s_dtcc.append(sum_all)
s_dtcc = pd.concat(s_dtcc, axis=0)
    
    
### combine
    
icom = i_sd.merge(s_dtcc, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_dtcc_event, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])



### event

icom['b_dv_v'] = icom['B'].divide(icom['avgVadj'])
icom['s_dv_v'] = icom['S'].divide(icom['avgVadj'])


icom['flg_b'] = np.nan
icom.loc[icom['B']>0, 'flg_b'] = 1

icom['flg_b_large'] = np.nan
icom.loc[(icom['B']>0)&(icom['b_dv_v']>0.1), 'flg_b_large'] = 1

yu.create_cn_decay(icom, 'flg_b') #  <2bp +ve alpha ~15 days
yu.create_cn_decay(icom, 'flg_b_large') # ~2bp +ve alpha ~15 days

icom['flg_s'] = np.nan
icom.loc[icom['S']>0, 'flg_s'] = 1

yu.create_cn_decay(icom, 'flg_s')


icom['sgnl_b'] = icom.groupby('ticker')['flg_b'].ffill(limit = 10)
icom['sgnl_b_large'] = icom.groupby('ticker')['flg_b_large'].ffill(limit = 10)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_b','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate'])
,
            'sgnl_b','BarrRet_CLIP_USD+1d', static_data = i_sd) #1.32 / -0.37
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_b_large','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_b_large','BarrRet_CLIP_USD+1d', static_data = i_sd) #0.69 / -0.37


### net institution buy

icom['net_v_t1m_dv_v'] = icom['Volume_t1m'].divide(icom['avgVadj'])
icom['net_v_t1m_dv_v_bk'] = icom.groupby('datadate')['net_v_t1m_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['net_v_t1m_dv_v_bk'], 'net_v_t1m_dv_v') # leaning +ve mono, but low t


### t1m inst trader count

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['Ims_t1m_bk'] = icom.groupby('datadate')['Ims_t1m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['Ims_t1m_orth'] = icom.groupby('datadate')[COLS+['Ims_t1m']].apply(lambda x: yu.orthogonalize_cn(x['Ims_t1m'], x[COLS])).values
icom['Ims_t1m_orth_bk'] = icom.groupby('datadate')['Ims_t1m_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['Ims_t1m_bk'], 'Ims_t1m') # random
yu.create_cn_3x3(icom, ['Ims_t1m_orth_bk'], 'Ims_t1m_orth') # random -2 +2 -0.5



### hedge fund buy

icom['hf_sgnl'] = np.nan
icom.loc[icom['Hfa_volume']>0, 'hf_sgnl'] = 1
#yu.create_cn_decay(icom, 'hf_sgnl')
icom['hf_sgnl'] = icom.groupby('ticker')['hf_sgnl'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['hf_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'hf_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #

