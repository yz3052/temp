﻿#$%^&* pL2_cn_trod_vwap_baratio.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun May  1 05:47:03 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime



#  This studies TWAP capture data (1min spikes)



### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])




### get VWAP capture data 

i_capvwap = yu.get_q('''(get `:/export/datadev/Data/SHSZ/TROD_metrics/i_order_vwap_sh_2),
                        (get `:/export/datadev/Data/SHSZ/TROD_metrics/i_order_vwap_sz_2) ''')

i_capvwap['code'] = i_capvwap['code'].str.decode('utf8')
c_sh = i_capvwap['code'].str[0].isin(['6'])
c_sz = i_capvwap['code'].str[0].isin(['0','3'])
i_capvwap.loc[c_sh, 'ticker'] = i_capvwap.loc[c_sh, 'code'] + '.SH'
i_capvwap.loc[c_sz, 'ticker'] = i_capvwap.loc[c_sz, 'code'] + '.SZ'
i_capvwap['datadate'] = pd.to_datetime(i_capvwap['date'])
i_capvwap = i_capvwap.sort_values(['ticker', 'datadate'])
i_capvwap = i_capvwap[i_capvwap['ticker'].notnull()]



### combine

icom = i_sd.merge(i_capvwap, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])


COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']


'''
'b_cnt_tot', 's_cnt_tot', 'b_cnt_09311456',
's_cnt_09311456', 'b_v_tot', 's_v_tot', 'b_v_09311456', 's_v_09311456',
'b_cnt_totMax', 'b_cnt_avgXmax', 'b_v_totMax', 'b_v_avgXmax',
's_cnt_totMax', 's_cnt_avgXmax', 's_v_totMax', 's_v_avgXmax'
'''



    
icom['ba_dv_totCnt'] = ((icom['b_cnt_totMax'] - icom['b_cnt_avgXmax'])-(icom['s_cnt_totMax'] - icom['s_cnt_avgXmax'])).divide(icom['b_cnt_tot']+icom['s_cnt_tot'])
icom['ba_dv_totCnt_bk'] = icom.groupby('datadate')['ba_dv_totCnt'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['ba_dv_totCnt_bk'], 'ba_dv_totCnt') # v-shaped +3.5 -4.5 +6

icom['bpa_dv_totCnt'] = ((icom['b_cnt_totMax'] - icom['b_cnt_avgXmax'])+(icom['s_cnt_totMax'] - icom['s_cnt_avgXmax'])).divide(icom['b_cnt_tot']+icom['s_cnt_tot'])
icom['bpa_dv_totCnt_bk'] = icom.groupby('datadate')['bpa_dv_totCnt'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['bpa_dv_totCnt_t20d']  = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['bpa_dv_totCnt_bk'].mean().values
icom['bpa_dv_totCnt_t20d_orth'] = icom.groupby('datadate')[['bpa_dv_totCnt_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['bpa_dv_totCnt_t20d'], x[COLS])).value
s
icom['bpa_dv_totCnt_t20d_orth_sgnl'] = icom.groupby('datadate')['bpa_dv_totCnt_t20d_orth'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icom, ['bpa_dv_totCnt_bk'], 'bpa_dv_totCnt') # mono: -8 +7.5

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['bpa_dv_totCnt_t20d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'bpa_dv_totCnt_t20d_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.51 / 3.51, 6e7


icom['bpa_dv_totV'] = ((icom['b_v_totMax'] - icom['b_v_avgXmax'])+(icom['s_v_totMax'] - icom['s_v_avgXmax'])).divide(icom['b_v_tot']+icom['s_v_tot'])
icom['bpa_dv_totV_bk'] = icom.groupby('datadate')['bpa_dv_totV'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['bpa_dv_totV_bk'], 'bpa_dv_totV') #mono: -ve relationship




icom['bpa_dv_totV'] = ((icom['b_v_totMax'] - icom['b_v_avgXmax'])+(icom['s_v_totMax'] - icom['s_v_avgXmax'])).divide(icom['b_v_tot']+icom['s_v_tot'])
icom['bpa_dv_totV_rk'] = icom.groupby('datadate')['bpa_dv_totV'].apply(yu.uniformed_rank).values
icom['bpa_dv_totCnt'] = ((icom['b_cnt_totMax'] - icom['b_cnt_avgXmax'])+(icom['s_cnt_totMax'] - icom['s_cnt_avgXmax'])).divide(icom['b_cnt_tot']+icom['s_cnt_tot'])
icom['bpa_dv_totCnt_rk'] = icom.groupby('datadate')['bpa_dv_totCnt'].apply(yu.uniformed_rank).values

icom['bpa_rk_sum'] = icom['bpa_dv_totV_rk'] + icom['bpa_dv_totCnt_rk']
icom['bpa_rk_sum_bk'] = icom.groupby('datadate')['bpa_rk_sum'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['bpa_rk_sum_bk'], 'bpa_rk_sum') # mono: -7 +7
