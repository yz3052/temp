﻿#$%^&* pCorpAct_cn_unlock_featurepool.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat Sep 24 16:27:48 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import requests
import time
import datetime

from bs4 import BeautifulSoup

import os


#------------------------------------------------------------------------------
### scraper - history backfill
#------------------------------------------------------------------------------

proxies = {'http':'http://thzhang:Citadel881012@@proxy.mlp.com:3128','https':'https://thzhang:Citadel881012@@proxy.mlp.com:3128'} 

COOKIES = 'SINAGLOBAL=174.138.224.248_1614112715.34860; U_TRS1=000000f8.acde7ee7.6047c976.1adadb4f; SGUID=1620841599622_17018594; UOR=,,; visited_trust=; FSINAGLOBAL=174.138.224.248_1614112715.34860; NEWESTVISITED_FUTURE=%7B%22code%22%3A%22RB0%22%2C%22hqcode%22%3A%22nf_RB0%22%2C%22type%22%3A1%7D; SR_SEL=1_511; Apache=204.212.175.30_1663858164.991018; FIN_ALL_VISITED=sh000300%2Csz000488%2Csz200488; ULV=1663878639696:48:5:2:204.212.175.30_1663858164.991018:1663858162556; FINA_V_S_2=sh000300,sz399001,sz000488,sz200488,sz000796,sz002202,sz001914,sh600887,sz002538,sz399005,sh601108,sh000001; FINA_V5_HQ=0; FINA_DMHQ=1; MONEY-FINANCE-SINA-COM-CN-WEB5='
headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Cache-Control': 'max-age=0',
            'Cookie': COOKIES,
            'Host': 'vip.stock.finance.sina.com.cn',
            'Proxy-Connection': 'keep-alive',
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.90 Safari/537.36',
            'Upgrade-Insecure-Requests': '1'}


o_unlock = []

for i in range(1, 50):
    print (i)
    time.sleep(3)
    url = 'http://vip.stock.finance.sina.com.cn/q/go.php/vInvestConsult/kind/xsjj/index.phtml?bdate=2017-01-01&edate=2022-09-24&num=1000&p=' + str(i)
    
    resp = requests.get(url, headers=headers, proxies=proxies, verify = False)
    if resp.status_code != 200:
        print('data fetching failure')
        break
    
    soup = BeautifulSoup(resp.text, 'html.parser')
    t_data = pd.read_html( str(soup.find('table', class_='list_table')) )[0]
    t_data['page'] = i
    o_unlock.append(t_data)

o_unlock = 
pd.concat(o_unlock, axis = 0)
o_unlock['scraper_ts_cn'] = datetime.datetime.now()
o_unlock.to_parquet(r'S:\TZ\China Data Hunt\cache\pCorpAct_cn_unlock_sina_backfill.parquet', allow_truncated_timestamps = True)





o_unlock = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pCorpAct_cn_unlock_sina_backfill.parquet')

o_unlock.columns = ['ticker','name','unlock_date','unlock_10kshares','unlock_100mrmb','batch','datadate','page','scraper_ts_cn']
o_unlock['ticker'] = o_unlock['ticker'].astype(str).str.zfill(6)
c_sh = o_unlock['ticker'].str[0].isin(['6'])
c_sz = o_unlock['ticker'].str[0].isin(['0','3'])
o_unlock.loc[c_sh, 'ticker'] = o_unlock.loc[c_sh, 'ticker'] + '.SH'
o_unlock.loc[c_sz, 'ticker'] = o_unlock.loc[c_sz, 'ticker'] + '.SZ'
o_unlock['unlock_date'] = pd.to_datetime(o_unlock['unlock_date'])
o_unlock['datadate'] = pd.to_datetime(o_unlock['datadate'])
o_unlock['unlock_shares'] = o_unlock['unlock_10kshares'] * 10000



#------------------------------------------------------------------------------
### ongoing data 
#------------------------------------------------------------------------------

i_files = os.listdir(r'S:\PROD\TZ\sina_unlock')
i_ul_daily = pd.concat(pd.read_parquet('S:/PROD/TZ/sina_unlock/'+f) for f in i_files)

i_ul_daily['ticker'] = i_ul_daily['ticker'].astype(int).astype(str).str.zfill(6)
c_sh = i_ul_daily['ticker'].str[0].isin(['6'])
c_sz = i_ul_daily['ticker'].str[0].isin(['0','3'])
i_ul_daily.loc[c_sh, 'ticker'] = i_ul_daily.loc[c_sh, 'ticker'] + '.SH'
i_ul_daily.loc[c_sz, 'ticker'] = i_ul_daily.loc[c_sz, 'ticker'] + '.SZ'

i_ul_daily['unlock_date'] = pd.to_datetime(i_ul_daily['unlock_date'])
i_ul_daily['unlock_shares'] = i_ul_daily['unlock_10kshares'] * 10000




#------------------------------------------------------------------------------
### generate daily descriptos
#------------------------------------------------------------------------------

o_sum = []

for dt in pd.date_range(start='2017-01-01', end='2022-09-26'):
    print(dt.strftime('%Y%m%d'),end=',')
    
    if dt <= pd.to_datetime('2022-09-24'):
        t_unlock = o_unlock[(o_unlock['datadate']<=dt) & (o_unlock['unlock_date']>dt+pd.to_timedelta('3 days'))]
    else:
        t_unlock = i_ul_daily[pd.to_datetime(i_ul_daily['scraper_ts_cn'].dt.date)==dt]
        t_unlock = t_unlock[t_unlock['unlock_date']>dt+pd.to_timedelta('3 days')]
    
    # get data for the next unlock 
    # days to the next unlock
    # unlock shares of the next unlock 
    t_unlock = t_unlock.sor
t_values(['ticker','unlock_date'])
    t_unlock['datadate'] = dt
    t_unlock_n1 = t_unlock.groupby('ticker').head(1)
    t_unlock_n1['flag_n1'] = 1
    t_unlock_n1['days2n1'] = (t_unlock_n1['unlock_date']-t_unlock_n1['datadate']).dt.days
    t_unlock_n1['unlock_shares_n1'] = t_unlock_n1['unlock_shares']
    
    s_n1 = t_unlock_n1[['ticker','unlock_shares_n1','days2n1']]
    
    # get data for the 2nd next unlock 
    # days to the 2nd next unlock 
    # unlock shares of the 2nd next unlock 
    t_unlock_n2 = t_unlock.groupby('ticker').head(2)
    t_unlock_n2_cnt = t_unlock_n2.groupby('ticker')['unlock_date'].nunique().reset_index()
    t_unlock_n2_cnt = t_unlock_n2_cnt[t_unlock_n2_cnt['unlock_date']==2]
    t_unlock_n2 = t_unlock_n2[t_unlock_n2['ticker'].isin(t_unlock_n2['ticker'].tolist())]
    t_unlock_n2 = t_unlock_n2.drop_duplicates(subset='ticker', keep = 'last')
    t_unlock_n2['flag_n2'] = 1
    t_unlock_n2['days2n2'] = (t_unlock_n2['unlock_date']-t_unlock_n2['datadate']).dt.days
    t_unlock_n2['unlock_shares_n2'] = t_unlock_n2['unlock_shares']
    
    s_n2 = t_unlock_n2[['ticker','unlock_shares_n2','days2n2']]

    # output
    t_sum = s_n1.merge(s_n2, on = 'ticker', how = 'outer')
    t_sum['datadate'] = dt
    o_sum.append(t_sum)
    
o_sum = pd.concat(o_sum, axis = 0)




### get longer-term adv

i_adv = pw.get_wind_adv()



### feature pool mapping

i_dtk = yu.get_date_ticker_mapping()


### sd


i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['ticker', 'datadate'])


i_sd = pw.get_ashare_t1800_sd()
i_sd = i_sd.sort_values(['ticker', 'datadate'])


#-------------------------------------------------------------------------
### combine

icom = i_sd.merge(o_sum, on = ['datadate','ticker'], how = 'left')
icom = icom.merge(i_adv, on = ['datadate','ticker'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])





### n1 n2 unlock, unlock/adv

icom['unlock1_dv_adv'] = icom['unlock_shares_n1'].divide(icom['adv_t130d'])
icom.loc[icom['unlock1_dv_adv'].abs()>1, 'unlock1_dv_adv'] = 1
icom['unlock2_dv_adv'] = icom['unlock_shares_n2'].divide(icom['adv_t130d'])
icom.loc[icom['unlock2_dv_adv'].abs()>1, 'unlock2_dv_adv'] = 1

c1 = icom['days2n1'].between(3, 60)
icom['unlock1_dv_v_sgnl'] = np.nan
icom.loc[c1, 'unlock1_dv_v_sgnl'] = - icom.loc[c1, 'unlock1_dv_adv']

c1 = icom['days2n2'].between(3, 60)
icom['unlock2_dv_v_sgnl'] = np.nan
icom.loc[c1, 'unlock2_dv_v_sgnl'] = - icom.loc[c1, 'unlock2_dv_adv']

icom['unlock12_dv_v_sgnl'] = icom[
['unlock1_dv_v_sgnl','unlock2_dv_v_sgnl']].min(axis=1)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['unlock12_dv_v_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'unlock12_dv_v_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #sd 3.07 /2.47, 1.2m, 21m gmv





### output feature pool

i_feature = i_dtk.merge(o_sum, on = ['ticker','datadate'], how = 'left')
i_feature = i_feature.merge(i_adv, on = ['datadate','ticker'], how = 'left')
i_feature = i_feature.sort_values(['ticker','datadate'])

i_feature['unlock1_dv_adv'] = i_feature['unlock_shares_n1'].divide(i_feature['adv_t130d'])
i_feature.loc[i_feature['unlock1_dv_adv'].abs()>1, 'unlock1_dv_adv'] = 1
i_feature['unlock2_dv_adv'] = i_feature['unlock_shares_n2'].divide(i_feature['adv_t130d'])
i_feature.loc[i_feature['unlock2_dv_adv'].abs()>1, 'unlock2_dv_adv'] = 1

c1 = i_feature['days2n1'].between(3, 60)
i_feature['unlock1_dv_v_sgnl'] = np.nan
i_feature.loc[c1, 'unlock1_dv_v_sgnl'] = - i_feature.loc[c1, 'unlock1_dv_adv']

c1 = i_feature['days2n2'].between(3, 60)
i_feature['unlock2_dv_v_sgnl'] = np.nan
i_feature.loc[c1, 'unlock2_dv_v_sgnl'] = - i_feature.loc[c1, 'unlock2_dv_adv']

i_feature['unlock12_dv_v_sgnl'] = i_feature[['unlock1_dv_v_sgnl','unlock2_dv_v_sgnl']].min(axis=1)

i_feature = i_feature.reset_index(drop = True)
i_feature = i_feature[['ticker', 'datadate', 'unlock12_dv_v_sgnl']]
i_feature = i_feature.set_index(['ticker', 'datadate'])
i_feature.to_parquet(r'S:\TZ\backtester\feature_pool\unlock.parquet')



