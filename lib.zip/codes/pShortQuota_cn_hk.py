﻿#$%^&* pShortQuota_cn_hk.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Aug  1 17:03:04 2022

@author: thzhang
"""




import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime
import os
import pathlib


# this studies all types of short interest data





### sd 

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['ticker', 'datadate'])


i_sd_ss = pw.get_china_ss_sd()
i_sd_ss = i_sd_ss.sort_values(['ticker', 'datadate'])

i_sd_hk = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd_hk = i_sd_hk.sort_values(['ticker', 'datadate'])





### get hk bb holding 


i_h_bb = pd.read_parquet(r'S:\Data\China Data Hunt\cache\prepare_northbound_holding_bb.parquet')

s_h_bb = i_h_bb.groupby(['datadate_p1d', 'ticker'])['bb_shares'].sum().reset_index()
s_h_bb = s_h_bb.sort_values('datadate_p1d')






### get stock borrowing list

i_rzrq_tk = pw.get_stock_borrowing_list()





### get stock borrowing data from SHSZ

i_rzrq = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                    S_MARGIN_SECLENDINGBALANCEVOL, S_MARGIN_SALESOFBORROWEDSEC, S_MARGIN_REPAYMENTOFBORROWSEC,
                    S_REFIN_SL_EOD_VOL, S_REFIN_SB_EOD_VOL, S_REFIN_SL_EOP_VOL, S_REFIN_REPAY_VOL
                    from wind.dbo.AShareMarginTrade
                    ''')
i_rzrq['datadate']  = pd.to_datetime(i_rzrq['datadate'], format='%Y%m%d')
i_rzrq = i_rzrq.sort_values(['ticker', 'datadate'])




### HK uni

i_uni_hk = yu.get_sql('''SELECT datadate, ticker  FROM [CNDBPROD].[dbo].[UNIVERSE_HC]''')
c_sh = i_uni_hk['ticker'].str[0].isin(['6'])
c_sz = i_uni_hk['ticker'].str[0].isin(['0','3'])
i_uni_hk.loc[c_sh, 'ticker'] = i_uni_hk.loc[c_sh, 'ticker'] + '.SH'
i_uni_hk.loc[c_sz, 'ticker'] = i_uni_hk.loc[c_sz, 'ticker'] + '.SZ'


### ETB old
#i_etb = yu.get_sql('''select ticker, datadate,
#                   Avail_Amount_1st, Avail_Amount_2nd, Avail_Amount_3rd,
#                   Avail_Amount_4th, Avail_Amount_5th,Avail_Amount_6th,
#                   Avail_Amount_7th                   
#                   from [CNDBPROD].[dbo].[MLP_CN_ETBList_ABC] ''')
#c_sh = i_etb['ticker'].str[0].isin(['6'])
#c_sz = i_etb['ticker'].str[0].isin(['0','3'])
#i_etb.loc[c_sh, 'ticker'] = i_etb.loc[c_sh, 'ticker'] + '.SH'
#i_etb.loc[c_sz, 'ticker'] = i_etb.loc[c_sz, 'ticker'] + '.SZ'
#cols = ['Avail_Amount_1st', 'Avail_Amount_2nd', 'Avail_Amount_3rd',
#        'Avail_Amount_4th', 'Avail_Amount_5th', 'Avail_Amount_6th',
#        'Avail_Amou
nt_7th']
#i_etb['etb_shares'] = i_etb[cols].sum(axis=1)
#
#i_etb = i_uni_hk.merge(i_etb, on = ['ticker','datadate'], how = 'left')
#i_etb['etb_shares'] = i_etb['etb_shares'].fillna(0)



### ETB - QFII + HC

i_etb = yu.get_sql('''select datadate as datadate_p1d, ric,
                   avail_amount_ubs, rate_ubs, avail_amount_gs, rate_gs, 
                   avail_amount_jpm, rate_jpm, avail_amount_baml, rate_baml,
                   avail_amount_citi, rate_citi, avail_amount_ms, rate_ms 
                   from [CNDBPROD].[dbo].[MLP_CN_ETBList_ABC_RIC] 
                   ''')
i_etb['ticker'] = i_etb['ric'].str.replace('SS','SH').str.replace('ZK','SZ')
i_etb = i_etb.sort_values(['ticker', 'datadate_p1d']).reset_index(drop = True)

i_etb['avail_amount_ubs'] = i_etb['avail_amount_ubs'].fillna(0)
i_etb['avail_amount_gs'] = i_etb['avail_amount_gs'].fillna(0)
i_etb['avail_amount_jpm'] = i_etb['avail_amount_jpm'].fillna(0)
i_etb['avail_amount_baml'] = i_etb['avail_amount_baml'].fillna(0)
i_etb['avail_amount_citi'] = i_etb['avail_amount_citi'].fillna(0)
i_etb['avail_amount_ms'] = i_etb['avail_amount_ms'].fillna(0)

i_etb['avail_amt'] = i_etb[['avail_amount_ubs','avail_amount_gs','avail_amount_jpm',
                            'avail_amount_baml','avail_amount_citi','avail_amount_ms']].sum(axis=1)

i_etb['rate'] = (i_etb['avail_amount_ubs']*i_etb['rate_ubs'])\
                 .add(i_etb['avail_amount_gs']*i_etb['rate_gs'], fill_value=0)\
                 .add(i_etb['avail_amount_jpm']*i_etb['rate_jpm'], fill_value=0)\
                 .add(i_etb['avail_amount_baml']*i_etb['rate_baml'], fill_value=0)\
                 .add(i_etb['avail_amount_citi']*i_etb['rate_citi'], fill_value=0)\
                 .add(i_etb['avail_amount_ms']*i_etb['rate_ms'], fill_value=0)\
                 .divide(i_etb['avail_amt'])
i_etb['avail_amt_rate'] = i_etb['avail_amt'] * i_etb['rate']

i_etb = pd.concat([i_etb.groupby(['datadate_p1d', 'ticker'])['avail_amt','avail_amount_ubs','avail_amount_gs',
                   'avail_amount_jpm','avail_amount_baml','avail_amount_citi','avail_amount_ms'].sum(),
                   i_etb.groupby(['datadate_p1d', 'ticker'])['avail_amt_rate'].sum()],
                      axis = 1)
i_etb = i_etb.reset_index()
i_etb['rate'] = i_etb['avail_amt_rate'] / i_etb['avail_amt']
i_etb['rate'] = i_etb['rate'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
i_etb['avail_conc'] = (i_etb['avail_amount_ubs'].fillna(0) / i_etb['avail_amt']).pow(2) \
               
       + (i_etb['avail_amount_gs'].fillna(0) / i_etb['avail_amt']).pow(2) \
                      + (i_etb['avail_amount_jpm'].fillna(0) / i_etb['avail_amt']).pow(2) \
                      + (i_etb['avail_amount_baml'].fillna(0) / i_etb['avail_amt']).pow(2) \
                      + (i_etb['avail_amount_citi'].fillna(0) / i_etb['avail_amt']).pow(2) \
                      + (i_etb['avail_amount_ms'].fillna(0) / i_etb['avail_amt']).pow(2)


### ETB - HC only

i_etb_hc = yu.get_sql('''select datadate as datadate_p1d, ric,
                   avail_amount_ubs, rate_ubs, avail_amount_gs, rate_gs, 
                   avail_amount_jpm, rate_jpm, avail_amount_baml, rate_baml,
                   avail_amount_citi, rate_citi, avail_amount_ms, rate_ms 
                   from [CNDBPROD].[dbo].[MLP_CN_ETBList_ABC_RIC] 
                   where ric like '%SS' or ric like '%ZK'
                   ''')
i_etb_hc['ticker'] = i_etb_hc['ric'].str.replace('SS','SH').str.replace('ZK','SZ')
i_etb_hc = i_etb_hc.sort_values(['ticker', 'datadate_p1d']).reset_index(drop = True)

i_etb_hc['avail_amount_ubs'] = i_etb_hc['avail_amount_ubs'].fillna(0)
i_etb_hc['avail_amount_gs'] = i_etb_hc['avail_amount_gs'].fillna(0)
i_etb_hc['avail_amount_jpm'] = i_etb_hc['avail_amount_jpm'].fillna(0)
i_etb_hc['avail_amount_baml'] = i_etb_hc['avail_amount_baml'].fillna(0)
i_etb_hc['avail_amount_citi'] = i_etb_hc['avail_amount_citi'].fillna(0)
i_etb_hc['avail_amount_ms'] = i_etb_hc['avail_amount_ms'].fillna(0)

i_etb_hc['avail_amt'] = i_etb_hc[['avail_amount_ubs','avail_amount_gs','avail_amount_jpm',
                            'avail_amount_baml','avail_amount_citi','avail_amount_ms']].sum(axis=1)
i_etb_hc['rate'] = (i_etb_hc['avail_amount_ubs']*i_etb_hc['rate_ubs'])\
                 .add(i_etb_hc['avail_amount_gs']*i_etb_hc['rate_gs'], fill_value=0)\
                 .add(i_etb_hc['avail_amount_jpm']*i_etb_hc['rate_jpm'], fill_value=0)\
                 .add(i_etb_hc['avail_amount_baml']*i_etb_hc['rate_baml'], fill_value=0)\
                 .add(i_etb_hc['avail_amount_citi']*i_etb_hc['rate_citi'], fill_value=0)\
                 .add(i_etb_hc['avail_amount_ms']*i_etb_hc['rate_ms'], fill_value=0)\
                 .divide(i_etb_hc['avail_amt'])
i_etb_hc['avail_amt_rate'] = i_etb_hc['avail_amt'] * i_etb_hc['rate']

i_etb_hc = pd.concat([i_etb_hc.groupby(['datadate_p1d', 'ticker'])['avail_amt','avail_amount_ubs','avail_amount_gs','avail_amount_jpm',
                            'avail_amount_baml','a
vail_amount_citi','avail_amount_ms'].sum(),
                   i_etb_hc.groupby(['datadate_p1d', 'ticker'])['avail_amt_rate'].sum()],
                      axis = 1)
i_etb_hc = i_etb_hc.reset_index()
i_etb_hc['rate'] = i_etb_hc['avail_amt_rate'] / i_etb_hc['avail_amt']
i_etb_hc['rate'] = i_etb_hc['rate'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
i_etb_hc['avail_conc'] = (i_etb_hc['avail_amount_ubs'].fillna(0) / i_etb_hc['avail_amt']).pow(2) \
                          + (i_etb_hc['avail_amount_gs'].fillna(0) / i_etb_hc['avail_amt']).pow(2) \
                          + (i_etb_hc['avail_amount_jpm'].fillna(0) / i_etb_hc['avail_amt']).pow(2) \
                          + (i_etb_hc['avail_amount_baml'].fillna(0) / i_etb_hc['avail_amt']).pow(2) \
                          + (i_etb_hc['avail_amount_citi'].fillna(0) / i_etb_hc['avail_amt']).pow(2) \
                          + (i_etb_hc['avail_amount_ms'].fillna(0) / i_etb_hc['avail_amt']).pow(2)


### |-- Float

i_guben = pw.get_wind_float()
i_guben = i_guben.sort_values('datadate')

### |-- reversal

i_pastret = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet',
                            columns = ['ticker', 'datadate', 'twap1000_2c_bret', 'twap1000_2c_bret_t4w'])
i_pastret = i_pastret.sort_values(['ticker','datadate'])
i_pastret['twap1000_2c_bret_t1y'] = i_pastret.groupby('ticker').rolling(252)['twap1000_2c_bret'].mean().values



### |-- IPO

i_ipo = pw.get_ipo_date()


### |-- abnormal

i_ab = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_abnormal_move.parquet')


### |-- c

i_c = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                 s_dq_close as c
                 from wind_prod.dbo.ashareeodprices
                 where trade_dt >= '20150101' ''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format = '%Y%m%d')
i_c = i_c.sort_values('datadate')







### idea 1: reversal + high available amount 


icom = i_sd_hk.merge(i_etb, on = ['ticker','datadate_p1d'], how = 'left')

icom = icom.merge(i_pastret, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(i_ipo, on = ['ticker'], how = 'left')
icom = icom.merge(i_ab, on = ['ticker','datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])

icom['days_since_ipo'] = (icom['datadate'] - icom['ipo_date']).dt.days


# amt / so

icom['etb_shares_dv_so'] = icom['avail_amt'].divide(icom['FLOAT_l1d'])
icom['etb_shares_dv_so_bk'] = icom.grou
pby('datadate')['etb_shares_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
COLS = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL','GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']
icom = icom.dropna(subset = ['ticker','datadate','etb_shares_dv_so']+COLS)
icom['etb_shares_dv_so_orth'] = icom.groupby('datadate')[COLS+['SRISK']+['etb_shares_dv_so']].apply(lambda x: yu.orthogonalize_cn_v2(x['etb_shares_dv_so'], x[COLS], x['SRISK'])).values
icom['etb_shares_dv_so_orth_bk'] = icom.groupby('datadate')['etb_shares_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['etb_shares_dv_so_bk'], 'etb_shares_dv_so') # less mono: -8 +6 +2
yu.create_cn_3x3(icom, ['etb_shares_dv_so_orth_bk'], 'etb_shares_dv_so_orth') # random



# df amt/so

icom['etb_shares_dv_so_avg20d'] = icom.groupby('ticker').rolling(20)['etb_shares_dv_so'].mean().values
icom['etb_shares_dv_so_avg20d_df20d'] = icom['etb_shares_dv_so_avg20d'] - icom.groupby('ticker')['etb_shares_dv_so_avg20d'].shift(20).values
icom['etb_shares_dv_so_avg20d_df20d_bk'] = icom.groupby('datadate')['etb_shares_dv_so_avg20d_df20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['etb_shares_dv_so_avg20d_df20d_bk'], 'etb_shares_dv_so_avg20d_df20d') # v-sahpe: 1 -2.5 +4


# amt

COLS = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL','GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']
icom['etb_shares_orth'] = icom.groupby('datadate')[COLS+['SRISK']+['avail_amt']].apply(lambda x: yu.orthogonalize_cn_v2(x['avail_amt'], x[COLS], x['SRISK'])).values
icom['etb_shares_orth_bk'] = icom.groupby('datadate')['etb_shares_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['etb_shares_orth_bk'], 'etb_shares_orth') # random


# amt/so + o2c

icom['etb_shares_dv_so'] = icom['avail_amt'].divide(icom['FLOAT_l1d'])
icom['etb_shares_dv_so_rk'] = icom.groupby('datadate')['etb_shares_dv_so'].apply(yu.uniformed_rank)
icom['twap1000_2c_bret_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)

icom['sgnl_1'] = np.nan
c1 = icom['etb_shares_dv_so_rk']>0.2
c2 = icom['twap1000_2c_bret_t4w_rk'] <-0.8
icom.loc[c1 & c2 , 'sgnl_1'] = 1
c3 = icom['twap1000_2c_bret_t4w_rk'] > 0.8
icom.loc[c3, 'sgnl_1'] = 0
icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker'
,'datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd_hk) 

# 2k: 2.82 / 2.07, 9.8% (without ipo and abnml limits)
# hk: 3.08 / 2.3, 11.96% (without ipo and abnml limits) ###!!!
# hk: 2.67 / 2.09, 12.58% (with ipo and abnml limits) 
# ss: 1.84 / 1.24, 6% (without ipo and abnml limits)
# ss: 1.29 / 0.82, 5.5% (with ipo and abnml limits)




# MA(amt) / so + o2c

icom['twap1000_2c_bret_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)

icom['avail_amt_ma'] = icom.groupby('ticker').rolling(20)['avail_amt'].median().values
icom['etb_ma_dv_so'] = icom['avail_amt_ma'].divide(icom['FLOAT_l1d'])
icom['etb_ma_dv_so_bk'] = icom.groupby('datadate')['etb_ma_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['etb_ma_dv_so_rk'] = icom.groupby('datadate')['etb_ma_dv_so'].apply(yu.uniformed_rank)
yu.create_cn_3x3(icom, ['etb_ma_dv_so_bk'], 'etb_ma_dv_so') # less mono: -2 +5 0

icom['sgnl_1'] = np.nan
c1 = icom['etb_ma_dv_so_rk']>0.2
c2 = icom['twap1000_2c_bret_t4w_rk'] <-0.8
icom.loc[c1 & c2 , 'sgnl_1'] = 1
c3 = icom['twap1000_2c_bret_t4w_rk'] > 0.8
icom.loc[c3, 'sgnl_1'] = 0
icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd_hk) 
#2.39 /1.8, 9,74%




### idea 1.1: reversal + high available amount, gs / ms / jpm specific
# gs /ms / jpm are similar to each other

icom = i_sd_hk.merge(i_etb, on = ['ticker','datadate'], how = 'left')

icom = icom.merge(i_pastret, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(i_ipo, on = ['ticker'], how = 'left')
icom = icom.merge(i_ab, on = ['ticker','datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])

icom['days_since_ipo'] = (icom['datadate'] - icom['ipo_date']).dt.days
icom['twap1000_2c_bret_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)

# amt/so + o2c

icom['gs_shares_dv_so'] = icom['avail_amount_gs'].divide(icom['FLOAT_l1d'])
icom['gs_shares_dv_so_rk'] = icom.groupby('datadate')['gs_shares_dv_so'].apply(yu.uniformed_rank)
icom['ms_shares_dv_so'] = icom['avail_amount_ms'].divide(icom['FLOAT_l1d'])
icom['ms_shares_dv_so_rk'] = icom.groupby('datadate')['ms_shares_dv_so'].apply(yu.uniformed_rank)
icom['jpm_shares_dv_so'] = icom['avail_amoun
t_jpm'].divide(icom['FLOAT_l1d'])
icom['jpm_shares_dv_so_rk'] = icom.groupby('datadate')['jpm_shares_dv_so'].apply(yu.uniformed_rank)

icom['sgnl_1'] = np.nan
c1 = icom['gs_shares_dv_so_rk']>0.2
c2 = icom['twap1000_2c_bret_t4w_rk'] <-0.8
icom.loc[c1 & c2 , 'sgnl_1'] = 1
c3 = icom['twap1000_2c_bret_t4w_rk'] > 0.8
icom.loc[c3, 'sgnl_1'] = 0
icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit=20)

icom['sgnl_2'] = np.nan
c1 = icom['ms_shares_dv_so_rk']>0.2
c2 = icom['twap1000_2c_bret_t4w_rk'] <-0.8
icom.loc[c1 & c2 , 'sgnl_2'] = 1
c3 = icom['twap1000_2c_bret_t4w_rk'] > 0.8
icom.loc[c3, 'sgnl_2'] = 0
icom['sgnl_2'] = icom.groupby('ticker')['sgnl_2'].ffill(limit=20)

icom['sgnl_3'] = np.nan
c1 = icom['jpm_shares_dv_so_rk']>0.2
c2 = icom['twap1000_2c_bret_t4w_rk'] <-0.8
icom.loc[c1 & c2 , 'sgnl_3'] = 1
c3 = icom['twap1000_2c_bret_t4w_rk'] > 0.8
icom.loc[c3, 'sgnl_3'] = 0
icom['sgnl_3'] = icom.groupby('ticker')['sgnl_3'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd_hk) # 2.52 / 1.7, 7.5%
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_2','BarrRet_CLIP_USD+1d', static_data = i_sd_hk) # 2.55 / 1.79, 8.0%
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_3','BarrRet_CLIP_USD+1d', static_data = i_sd_hk) # 2.01 / 1.35. 6.7%






### idea 2: hk supply and mainland demand of short quota

icom = i_sd[i_sd['isinHC']==1].merge(i_etb, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(i_rzrq_tk, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(i_rzrq, on = ['ticker','datadate'], how = 'left')


icom = icom.merge(i_pastret, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(i_ipo, on = ['ticker'], how = 'left')
icom = icom.merge(i_ab, on = ['ticker','datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])

icom['days_since_ipo'] = (icom['datadate'] - icom['ipo_date']).dt.days

icom = icom[icom['flg_rq']==1]


icom['avail_amt_dv_so'] = icom['avail_amt'].fillna(0) / icom['FLOAT_l1d']
icom['avail_a
mt_dv_so_rk'] = icom.groupby('datadate')['avail_amt_dv_so'].apply(yu.uniformed_rank)
icom['avail_amt_dv_so_bk'] = icom.groupby('datadate')['avail_amt_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['rq_dv_so'] = icom['S_MARGIN_SECLENDINGBALANCEVOL'].fillna(0) / icom['FLOAT_l1d']
icom['rq_dv_so_rk'] = icom.groupby('datadate')['rq_dv_so'].apply(yu.uniformed_rank)
icom['rq_dv_so_bk'] = icom.groupby('datadate')['rq_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['zrq_dv_so'] = icom['S_REFIN_SL_EOP_VOL'].fillna(0) / icom['FLOAT_l1d']
icom['zrq_dv_so_rk'] = icom.groupby('datadate')['zrq_dv_so'].apply(yu.uniformed_rank)

icom['rq_sd'] = icom['zrq_dv_so_rk'] - icom['rq_dv_so_rk']
icom['rq_sd_bk'] = icom.groupby('datadate')['rq_sd'].apply(lambda x: yu.pdqcut(x,bins=10)).values


COLS = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL','GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']

icom['sd'] = icom['avail_amt_dv_so_rk'] - icom['rq_dv_so_rk']
icom['sd_t5d'] = icom.groupby('ticker').rolling(5)['sd'].mean().values
icom['sd_orth'] = icom.groupby('datadate')[COLS+['SRISK']+['sd']].apply(lambda x: yu.orthogonalize_cn_v2(x['sd'], x[COLS], x['SRISK'])).values
icom['sd_rk'] = icom.groupby('datadate')['sd'].apply(yu.uniformed_rank).values
icom['sd_bk'] = icom.groupby('datadate')['sd'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['sd_orth_rk'] = icom.groupby('datadate')['sd_orth'].apply(yu.uniformed_rank).values
icom['sd_orth_bk'] = icom.groupby('datadate')['sd_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['sd_t5d_rk'] = icom.groupby('datadate')['sd_t5d'].apply(yu.uniformed_rank)



yu.create_cn_3x3(icom, ['sd_bk'], 'sd') # HC: mono: -9 +6 +5.5; 2K: 2K: -7 +6
yu.create_cn_3x3(icom, ['sd_orth_bk'], 'sd_orth') # HC: mono: -12 +5; 2K: -8 +7
yu.create_cn_3x3(icom, ['rq_dv_so_bk'], 'rq_dv_so') # HC: less mono: +3 -3 +1 -1
yu.create_cn_3x3(icom, ['rq_sd_bk'], 'rq_sd') # HC: -2 -4 + 4



icom['twap1000_2c_bret_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)

icom['sgnl1'] = np.nan
c1 = icom['sd_t5d_rk']>0.6
c2 = icom['twap1000_2c_bret_t4w_rk'] <-0.8
icom.loc[c1 & c2 , 'sgnl_1'] = 1
c3 = icom['twap1000_2c_bret_t4w_rk'] > 0.8
icom.loc[c3, 'sgnl_1'] = 0
icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit=20)



o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-06-30'))&(icom['sd_rk']>0.6)].\
            dropna(subset=['sd_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['
ticker','datadate']),
            'sd_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd_hk) 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd_hk) 

# 2k: 1.82 / 1.44, 9.7% (without ipo and abnml limits)






### idea 3: hk holding and hk avail amount


icom = i_sd.merge(s_h_bb, on = ['ticker','datadate_p1d'], how = 'left')
icom = icom.merge(i_etb_hc, left_on = ['ticker','datadate_p1d'], right_on = ['ticker','datadate'], how = 'left',suffixes=['','_m'])

icom = icom.merge(i_pastret, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(i_ipo, on = ['ticker'], how = 'left')
icom = icom.merge(i_ab, on = ['ticker','datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])

icom['days_since_ipo'] = (icom['datadate'] - icom['ipo_date']).dt.days
icom['twap1000_2c_bret_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)


# benchmark: bb pctOfSO

icom['bb_shares_pctOfSO'] = icom['bb_shares'].divide(icom['FLOAT_l1d'])
icom['bb_shares_pctOfSO_bk'] = icom.groupby('datadate')['bb_shares_pctOfSO'].apply(lambda x:yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom[icom['isinHC']==1],['bb_shares_pctOfSO_bk'],'bb_shares_pctOfSO') #-9.5 +4 +1


# hk-supply / SO

icom['lend_dv_so'] = icom['avail_amt'] / icom['FLOAT_l1d']
icom['lend_dv_so_bk'] = icom.groupby('datadate')['lend_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['lend_dv_so_bk'], 'lend_dv_so') #-3.5 +6 +3



# pct to be lend
# too many samples at 0, hence ignore all of them

icom['avail_dv_bb'] = icom['avail_amt'] / icom['bb_shares']
icom.loc[icom['avail_dv_bb']>1, 'avail_dv_bb'] = np.nan
icom['avail_dv_bb_bk'] = icom.groupby('datadate')['avail_dv_bb'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['pct_to_lend_bk'], 'pct_to_lend') #zigzag up -2 +8

icom['sgnl_1'] = np.nan
c1 = icom['avail_dv_bb_bk']>=8
c2 = icom['twap1000_2c_bret_t4w_rk'] <-0.8
icom.loc[c1 & c2 , 'sgnl_1'] = 1
c3 = icom['twap1000_2c_bret_t4w_rk'] > 0.8
icom.loc[c3, 'sgnl_1'] = 0
icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            's
gnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd_hk) 

# 2K: 2.29 / 1.76, 12.8%



# pct to be lend, conditional on pct held 
# high pct_to_lend has higher return if bb_pctOfSO is higher

icom['bb_pctOfSO'] = icom['bb_shares'].divide(icom['FLOAT_l1d'])
icom['bb_pctOfSO_rk'] = icom.groupby('datadate')['bb_pctOfSO'].apply(yu.uniformed_rank)

icom['avail_dv_bb'] = icom['avail_amt'] / icom['bb_shares']
icom.loc[icom['avail_dv_bb']>1, 'avail_dv_bb'] = np.nan
icom['avail_dv_bb_bk'] = icom.groupby('datadate')['avail_dv_bb'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['avail_dv_bb_rk'] = icom.groupby('datadate')['avail_dv_bb'].apply(yu.uniformed_rank).values


yu.create_cn_3x3(icom[icom['bb_pctOfSO_rk']>0], ['avail_dv_bb_bk'], 'pct_to_lend') # 0 6 9 
yu.create_cn_3x3(icom[icom['bb_pctOfSO_rk']<0], ['avail_dv_bb_bk'], 'pct_to_lend') # -5 -5 +2 -1



icom['sgnl_1'] = np.nan
c1 = (icom['avail_dv_bb_rk']>0) & (icom['bb_pctOfSO_rk']>0.6)
c2 = icom['twap1000_2c_bret_t4w_rk'] <-0.8
icom.loc[c1 & c2 , 'sgnl_1'] = 1
c3 = icom['twap1000_2c_bret_t4w_rk'] > 0.8
icom.loc[c3, 'sgnl_1'] = 0
icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd_hk) 

# 2K c1(-.6,-.6): 1.9 / 1.12, 5.1%
# 2K c1(0,0): 2.4 / 1.77, 9.74%
# 2K c1(0.6,0): 2.3 / 1.84, 14.18%
# 2K c1(0.6,0.6): 1.99 / 1.6, 15.5%
# 2K c1(0,0.6): 1.9 / 1.41, 10%



### idea 4: rates
# bar chart doesn't look super promising

icom = i_sd_hk.merge(i_etb_hc, left_on = ['ticker','datadate_p1d'], right_on = ['ticker','datadate'], how = 'left',suffixes=['','_m'])
icom = icom.sort_values(['ticker', 'datadate'])


# rate 

COLS = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL','GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']

icom['rate_orth'] = icom.groupby('datadate')[COLS+['SRISK']+['rate']].apply(lambda x: yu.orthogonalize_cn_v2(x['rate'], x[COLS], x['SRISK'])).values
icom['rate_bk'] = icom.groupby('datadate')['rate'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['rate_orth_rk'] = icom.groupby('datadate')['rate_orth'].apply(yu.uniformed_rank)
icom['rate_orth_bk'] = icom.groupby('datadate')['rate_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['avail_dv_so'] = icom['avail_amt'].divide(icom['FLOAT_l1d'])
icom['avail_dv_so_rk'] = icom.groupby('datada
te')['avail_dv_so'].apply(yu.uniformed_rank)
icom['avail_m_rate'] = icom['avail_dv_so_rk'] - icom['rate_orth_rk']

icom['avail_m_rate_bk'] = icom.groupby('datadate')['avail_m_rate'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['rate_bk'], 'rate')
yu.create_cn_3x3(icom, ['rate_orth_bk'], 'rate_orth') # random
yu.create_cn_3x3(icom, ['avail_m_rate_bk'], 'avail_m_rate') # -3 +4.5 +1





# df rate 
# rate up/dn: all +ve return 

icom['rate_df1d'] = icom['rate'] - icom.groupby('ticker')['rate'].shift(1)
icom['rate_df5d'] = icom['rate'] - icom.groupby('ticker')['rate'].shift(5)
icom['rate_df5d_bk'] = icom.groupby('datadate')['rate_df5d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['flg_rate_dn'] = np.nan
icom.loc[icom['rate_df1d']<0, 'flg_rate_dn'] = 1

yu.create_cn_3x3(icom, ['rate_df5d_bk'], 'rate_df5d') # all +ve, random
yu.create_cn_decay(icom, 'flg_rate_dn') # all +ve











### idea 5: RQ on earnings 

i_ed = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_ed_calendar_v2.parquet')
i_ed = i_ed.sort_values(['ticker', 'datadate'])
i_ed['td2e_1d'] = i_ed.groupby('ticker')['td2e'].shift()

icom = i_sd.merge(i_rzrq, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_ed, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])

icom['net_borrow'] = icom['S_MARGIN_SALESOFBORROWEDSEC']-icom['S_MARGIN_REPAYMENTOFBORROWSEC']
icom['net_borrow_dv_so'] = icom['net_borrow'] / icom['FLOAT_l1d']
icom['net_borrow_dv_so_rk'] = icom.groupby('datadate')['net_borrow_dv_so'].apply(yu.uniformed_rank)

icom['flg_ed_p0'] = np.nan
icom.loc[(icom['net_borrow_dv_so_rk']>0.95)&(icom['td2e']==0), 'flg_ed_p0'] = 1

icom['flg_ed_p1'] = np.nan
icom.loc[(icom['net_borrow_dv_so_rk']>0.95)&(icom['td2e_1d']==0), 'flg_ed_p1'] = 1

yu.create_cn_decay(icom, 'flg_ed_p0') # nothing
yu.create_cn_decay(icom, 'flg_ed_p1') # nothing


###???? before earnings?



### idea 5.1: RQ on low return date


icom = i_sd.merge(i_rzrq, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])

icom['bret_rk'] = icom.groupby('datadate')['BarrRet_CLIP_USD-1d'].apply(yu.uniformed_rank)

icom['net_borrow'] = icom['S_MARGIN_SALESOFBORROWEDSEC']-icom['S_MARGIN_REPAYMENTOFBORROWSEC']
icom['net_borrow_dv_so'] = icom['net_borrow'] / icom['FLOAT_l1d']
icom['net_borrow_dv_so_rk'] = icom.groupby('datadate')['net_borrow_dv_so'].apply(yu.uniformed_rank)

icom['flg_lowR_highRQ'] = np.nan
c1 = (ico
m['bret_rk']<-0.8) & (icom['net_borrow_dv_so_rk']>0.8)
icom.loc[c1, 'flg_lowR_highRQ'] = 1

yu.create_cn_decay(icom, 'flg_lowR_highRQ') # nothing





### idea 5.2: RQ / SO
# if RQ/adv high, reversal stronger on the long side

icom = i_sd.merge(i_rzrq, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_pastret, on = ['ticker','datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])

icom['twap1000_2c_bret_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)
icom['twap1000_2c_bret_t4w_bk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['rq_dv_so'] = icom['S_MARGIN_SECLENDINGBALANCEVOL'] / icom['FLOAT_l1d']
icom['rq_dv_so_rk'] = icom.groupby('datadate')['rq_dv_so'].apply(yu.uniformed_rank)
icom['rq_dv_so_bk'] = icom.groupby('datadate')['rq_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values

COLS = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL','GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']
icom['rq_dv_so_orth'] = icom.groupby('datadate')[COLS+['SRISK']+['rq_dv_so']].apply(lambda x: yu.orthogonalize_cn_v2(x['rq_dv_so'], x[COLS], x['SRISK'])).values
icom['rq_dv_so_orth_bk'] = icom.groupby('datadate')['rq_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['rq_dv_so_bk'], 'rq_dv_so') # nothing 
yu.create_cn_3x3(icom, ['rq_dv_so_orth_bk'], 'rq_dv_so_orth') # nothing
yu.create_cn_3x3(icom[icom['rq_dv_so_bk']==0], ['twap1000_2c_bret_t4w_bk'], 'twap1000_2c_bret_t4w')
# +4 -11 -5
yu.create_cn_3x3(icom[icom['rq_dv_so_bk']==9], ['twap1000_2c_bret_t4w_bk'], 'twap1000_2c_bret_t4w')
# +6.45 -5
yu.create_cn_3x3(icom[(icom['rq_dv_so_bk']==0) | (icom['S_MARGIN_SECLENDINGBALANCEVOL'].isnull())], ['twap1000_2c_bret_t4w_bk'], 'twap1000_2c_bret_t4w')
# +7.7 -15
yu.create_cn_3x3(icom[icom['S_MARGIN_SECLENDINGBALANCEVOL'].isnull()], ['twap1000_2c_bret_t4w_bk'], 'twap1000_2c_bret_t4w')
# +8 -16



### idea 5.2: RQ / avgVadj

icom = i_sd.merge(i_rzrq, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_pastret, on = ['ticker','datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])

icom['twap1000_2c_bret_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)
icom['twap1000_2c_bret_t4w_bk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['rq_dv_adv'] = icom['S_MARGIN_SECLENDINGBALANCEVOL'] / icom['avgVadj']
icom['rq_d
v_adv_bk'] = icom.groupby('datadate')['rq_dv_adv'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['rq_dv_adv_bk'], 'rq_dv_adv') # random
yu.create_cn_3x3(icom[icom['rq_dv_adv_bk']==0], ['twap1000_2c_bret_t4w_bk'], 'twap1000_2c_bret_t4w')
# +6 -8
yu.create_cn_3x3(icom[icom['rq_dv_adv_bk']==9], ['twap1000_2c_bret_t4w_bk'], 'twap1000_2c_bret_t4w')
# +4 +5 -6




### idea 6: ETB concentration
# etb concentration not helpful


icom = i_sd_hk.merge(i_etb, on = ['ticker','datadate'], how = 'left')

icom = icom.merge(i_pastret, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(i_ipo, on = ['ticker'], how = 'left')
icom = icom.merge(i_ab, on = ['ticker','datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])

icom['days_since_ipo'] = (icom['datadate'] - icom['ipo_date']).dt.days



# concentration 

icom['avail_conc_bk'] = icom.groupby('datadate')['avail_conc'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['avail_conc_bk'], 'avail_conc') # less mono: +2 +3 -2


# concentration + avail_amt

icom['etb_shares_dv_so'] = icom['avail_amt'].divide(icom['FLOAT_l1d'])
icom['etb_shares_dv_so_bk'] = icom.groupby('datadate')['etb_shares_dv_so'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['etb_shares_dv_so_rk'] = icom.groupby('datadate')['etb_shares_dv_so'].apply(yu.uniformed_rank)

yu.create_cn_3x3(icom, ['etb_shares_dv_so_bk'], 'etb_shares_dv_so') # -8 +6 +2
yu.create_cn_3x3(icom[icom['avail_conc_bk']<8], ['etb_shares_dv_so_bk'], 'etb_shares_dv_so') #-2 +6 +2


# concentration + o2c

icom['twap1000_2c_bret_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)

icom['sgnl_1'] = np.nan
c1 = icom['avail_conc_bk']<8
c2 = icom['twap1000_2c_bret_t4w_rk'] <-0.8
icom.loc[c1 & c2 , 'sgnl_1'] = 1
c3 = icom['twap1000_2c_bret_t4w_rk'] > 0.8
icom.loc[c3, 'sgnl_1'] = 0
icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd_hk) # 2.32 / 1.47, 5.77%
