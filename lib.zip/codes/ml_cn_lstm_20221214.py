﻿#$%^&* ml_cn_lstm_20221214.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 14 10:56:44 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import util as yu

import os
import sys
from sqlalchemy import create_engine
import urllib
import gc

import datetime

year = int(sys.argv[3])
month = int(sys.argv[4])

ddl_str = (datetime.datetime(year, month, 1) + datetime.timedelta(days=40)).strftime('%Y-%m-%d')
ddl_str_2y6m = (datetime.datetime(year, month, 1) - datetime.timedelta(days=876)).strftime('%Y-%m-%d')


conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))





# =============================================================================
### get universe
# =============================================================================


df_cd = pd.read_sql('''
                    select distinct TradeDate_next as DataDate
                    from CNDBPROD.dbo.Calendar_Dates_CN
                    where TradeDate_next >= '2015-01-01' and TradeDate_next<= '{0}'
                    '''.format(ddl_str),conn)
df_cd = df_cd.sort_values('DataDate')
df_cd = df_cd.reset_index(drop=True)
df_cd['T-1d'] = df_cd['DataDate'].shift(1)
df_cd['DataDate_p1d'] = df_cd['DataDate'].shift(-1)
df_cd = df_cd.dropna()



df_universe_all = pd.read_sql('''
                        select DataDate as [T-1d], Ticker, avgPVadj_USD as avgPVadj, spread, 
                        cccny_vol_21d as [cc_vol_21d], SRISK
                        from CNDBPROD.dbo.universe_all_cn_gem3l 
                        where DataDate <= '{0}'
                        and DataDate >= '{1}'
                        '''.format(ddl_str, ddl_str_2y6m), conn)
df_universe_all = df_universe_all.drop_duplicates(subset=['Ticker','T-1d'],keep='last')
df_universe_3000 = pd.read_sql('''
                        select DataDate as [T-1d], Ticker 
                        from CNDBPROD.dbo.UNIVERSE_CSI1800
                        where DataDate <= '{0}'
                        and DataDate >= '{1}'
                        '''.format(ddl_str, ddl_str_2y6m), conn)                        
df_universe_3000 = df_universe_3000.drop_duplicates(subset=['Ticker','T-1d'],keep='last')
df_universe = df_universe_3000.merge(df_universe_all, on = ['T-1d', 'Ticker'], how = 'left')
df_universe_all = None
df_universe_3000 = None
               
         

df_ret_20d = pd.read_sql('''select  DataDate, Ticker, 
                         BarrRet_CLIP5d
                         from CNDBPROD.dbo.BARRA_GEM3L_YRRET_CSI1800
                         where DataDate <= '{0}' 
                         and DataDate >= '{1}' 
                         '''.format(ddl_str, ddl_str_2y6m), conn)


                
df_universe = pd.merge(df_universe, df_cd, on=['T-1d'], how='inner')
df_universe = pd.merge(df_universe, df_ret_20d, on=['DataDate','Ticker'], how='left')
df_universe = df_universe.reset_index(drop=True)
df_cd = None
df_ret = None
gc.collect()

df_universe['BarrRet_CLIP5d_rk'] = df_universe.groupby('DataDate')['BarrRet_CLIP5d'].apply(yu.uniformed_rank)




#------------------------------------------------------------------------------
### get features
#------------------------------------------------------------------------------



i_all = pd.DataFrame(columns = ['Ticker','DataDate','T-1d'])

root = '/export/dataprod/Feature_Pool_CN/'
for fd in ['featurepool_enrich_trade_active','featurepool_enrich_trade_large',
           'featurepool_enrich_trade_mktc','featurepool_enrich_trade_pqcorr',
           'featurepool_enrich_trade_skew','featurepool_enrich_trod_apb',
           'featurepool_enrich_order_3s']:
    i_files = os.listdir(root+fd)
    i_feat = pd.concat([pd.read_parquet(root+fd+'/'+f) for f in i_files], axis=0)
    i_feat = i_feat[i_feat['T-1d'].dt.strftime('%Y%m')<=str(int(year*100+month))]
    i_feat = i_feat.drop_duplicates(subset = ['Ticker', 'DataDate'], keep = 'last')
    i_all = i_all.merge(i_feat, on = ['Ticker','DataDate','T-1d'], how = 'outer')


i_all = i_all.merge(df_universe, on = ['T-1d', 'Ticker','DataDate'], how = 'inner')
i_all['clip'] = i_all['avgPVadj'].apply(lambda r: min([r*0.01,1e6]))
i_all['wts'] = i_all['clip']
i_all= i_all.dropna(subset = ['wts'])

gc.collect()



cols_ft = ['actN_09301000_dv_pv_ma20d_orthgem3l_sgnl', 'actN_09301000_dv_pv_ma1d_orthgem3l_sgnl',
           'trade_large_desc_ma20d_orthgem3l_sgnl', 'trade_large_desc_ma1d_orthgem3l_sgnl',
           'v_mktc_pct_ma20d_orthgem3l_sgnl', 'v_mktc_pct_ma1d_orthgem3l_sgnl',
           'pq_dpct_corr_t20d_orthgem3l_sgnl', 'skew_5min_10001430_ma20d_orthgem3l_sgnl',
           'skew_5min_10001430_ma1d_orthgem3l_sgnl', 'apb_B_pTRD_vwap_ma20d_orthgem3l_sgnl',
           'apb_B_pTRD_vwap_ma1d_orthgem3l_sgnl', 'twap3s_order_pctoftot_ma20d_orthgem3l_sgnl',
           'twap3s_order_pctoftot_ma1d_orthgem3l_sgnl']

#--------------
----------------------------------------------------------------
### LSTM
#------------------------------------------------------------------------------



import datetime
import time
import matplotlib.pyplot as plt

import keras
from keras.models import Sequential
from keras.layers import Dense,Dropout,BatchNormalization,Conv1D,Flatten,MaxPooling1D,LSTM
from keras.callbacks import EarlyStopping,ModelCheckpoint,TensorBoard
from keras.wrappers.scikit_learn import KerasRegressor
from keras.models import load_model
from sklearn.preprocessing import MinMaxScaler



# step 1 - config

config = {'features_lst': cols_ft,
         'window': 20
         }

# step 2 - set up model

model=Sequential()
model.add(LSTM(300, input_shape = (config['window'],len(config['features_lst']))), return_sequences=True)
model.add(Dropout(0.5))
model.add(LSTM(200, input_shape=(config['window'],len(config['features_lst']))), return_sequences=False)
model.add(Dropout(0.5))
model.add(Dense(100,kernel_initializer='uniform',activation='relu'))        
model.add(Dense(1,kernel_initializer='uniform',activation='relu'))
model.compile(loss='mse',optimizer='adam')

# step 3 - prepare data

X_train
y_train
X_test
y_test

# step 4 - fit model

history=model.fit(X_train,y_train,epochs=500, batch_size=24, validation_data=(X_test, y_test), \
                  verbose=0, callbacks=[],shuffle=False)

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper right')
plt.show()


y_pr=model.predict(X_trainw)
plt.figure(figsize=(30,10))
plt.plot(y_trainw, label="actual")
plt.plot(y_pr, label="prediction")
plt.legend(fontsize=20)
plt.grid(axis="both")
plt.title("Actual open price and pedicted one on train set",fontsize=25)
plt.show()
