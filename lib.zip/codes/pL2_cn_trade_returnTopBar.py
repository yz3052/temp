﻿#$%^&* pL2_cn_trade_returnTopBar.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon May  9 13:22:51 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime



#  This studies TWAP capture data



### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])


### 1min bar

date_range = yu.get_sql("select distinct datadate from [CNDBPROD].[dbo].[TRADE_CN_KLINE] where datadate >= '2017-01-01' order by datadate")

o_1min = []
for dt in date_range['datadate'].drop_duplicates():
    print(dt.strftime('%Y%m%d')[2:], end = ' ')
    t_1min = yu.get_sql('''SELECT [datadate], [ticker], [trade_minutes] as hhmm, pv/num as pv_dv_num, [ret] 
                           FROM [CNDBPROD].[dbo].[TRADE_CN_KLINE]
                           where datadate = '{0}' '''.format( dt.strftime('%Y-%m-%d') ) )
    t_1min['rk'] = t_1min.groupby('ticker')['pv_dv_num'].apply(yu.uniformed_rank)
    t_1min.loc[t_1min['hhmm']<1130,'apm'] = 1
    t_1min.loc[t_1min['hhmm']>=1300,'apm'] = -1
    t_1min['rk_apm'] = t_1min.groupby(['ticker','apm'])['pv_dv_num'].apply(yu.uniformed_rank)
    
    s_1min = t_1min[t_1min['rk']>0.33].groupby(['datadate','ticker'])['ret'].mean().reset_index()
    s_1min_am = t_1min[(t_1min['rk_apm']>0.33)&(t_1min['apm']==1)].groupby(['datadate','ticker'])['ret'].mean().reset_index()
    s_1min_am = s_1min_am.rename(columns = {'ret':'ret_am'})
    s_1min_pm = t_1min[(t_1min['rk_apm']>0.33)&(t_1min['apm']==-1)].groupby(['datadate','ticker'])['ret'].mean().reset_index()
    s_1min_pm = s_1min_pm.rename(columns = {'ret':'ret_pm'})
    s = s_1min.merge(s_1min_am, on = ['ticker', 'datadate'], how = 'outer')
    s = s.merge(s_1min_pm, on = ['ticker', 'datadate'], how = 'outer')
    o_1min.append(s)

o_1min = pd.concat(o_1min, axis = 0)
c_sh = o_1min['ticker'].str[0].isin(['6'])
c_sz = o_1min['ticker'].str[0].isin(['0','3'])
o_1min.loc[c_sh, 'ticker'] = o_1min.loc[c_sh, 'ticker'] + '.SH'
o_1min.loc[c_sz, 'ticker'] = o_1min.loc[c_sz, 'ticker'] + '.SZ'


### combine 

icom = i_sd.merge(o_1min, on = ['ticker', 'datadate'])
icom = icom.sort_values(['ticker', 'datadate'])


icom['ret_bk'] = icom.groupby('datadate')['ret'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ret_sgnl'] = - icom.groupby('datadate')['ret'].apply(yu.uniformed_rank)
icom['ret_am_bk'] = icom.groupby('datadate')['ret_am'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ret_pm_bk'] = icom.group
by('datadate')['ret_pm'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ret_t10d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=14),on='datadate')['ret'].mean().values
icom['ret_t10d_sgnl'] = - icom.groupby('datadate')['ret_t10d'].apply(yu.uniformed_rank)
icom['ret_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ret'].mean().values
icom['ret_t20d_sgnl'] = - icom.groupby('datadate')['ret_t20d'].apply(yu.uniformed_rank)

#yu.create_cn_3x3(icom, ['ret_bk'], 'ret') # +3 -4.5
#yu.create_cn_3x3(icom, ['ret_am_bk'], 'ret_am') # +1 0 +2 -2
#yu.create_cn_3x3(icom, ['ret_pm_bk'], 'ret_pm') # +1.5 +2 -4.5


o_1 = yu.bt_cn_15(icom[(icom['datadate'].dt.year<=2020)].\
            dropna(subset=['ret_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ret_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) 


o_1 = yu.bt_cn_15(icom[(icom['datadate'].dt.year<=2020)].\
            dropna(subset=['ret_t10d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ret_t10d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.36 / -4.08

o_1 = yu.bt_cn_15(icom[(icom['datadate'].dt.year<=2020)].\
            dropna(subset=['ret_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ret_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.34 / -2.11
