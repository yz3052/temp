﻿#$%^&* pGraph_cn_supply_02.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 19 06:07:11 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

from datetime import timedelta as td

# this studies how us customer's residual return causes momentum spillover on the US side 
# it appears that momentum spillover (in terms of return) is weak

# next steps: how about a big earning surprise?
# how about us tickers with biggest improvement in revenue growth?
# how about the highest future projected revenue growth - current growth?

# for each a share company, how about model its compelte supply chain? in both china and us 
# summary stats: country distribution of customers? 



### sd china

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['ticker', 'datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()


### sd us

i_sd_us = yu.get_sql('''select [T-1d] as datadate, ticker, 
                     [BarrRet_SRISK-1d] as bret_1d , MC, hedge
                     FROM [BackTest].[dbo].[Static_Data_US]
                     order by ticker, datadate''')

i_sd_us['bret_t20d'] = i_sd_us.groupby('ticker').rolling(td(days=28),on='datadate')['bret_1d'].sum().values
i_sd_us['bret_t20d_rk'] = i_sd_us.groupby('datadate')['bret_t20d'].apply(yu.uniformed_rank).values
i_sd_us['bret_t65d'] = i_sd_us.groupby('ticker').rolling(td(days=91),on='datadate')['bret_1d'].sum().values
i_sd_us['bret_t65d_rk'] = i_sd_us.groupby('datadate')['bret_t65d'].apply(yu.uniformed_rank).values
i_sd_us['bret_t1y'] = i_sd_us.groupby('ticker').rolling(td(days=365),on='datadate')['bret_1d'].sum().values
from numba import njit
@njit
def sharpe(x):
    x = x[~np.isnan(x)]
    return np.mean(x)/np.std(x)*np.sqrt(len(x))    
i_sd_us['bret_sharpe1y'] = i_sd_us.groupby('ticker').rolling(252)['bret_1d'].apply(sharpe, raw = True).values
i_sd_us['bret_t1y_rk'] = i_sd_us.groupby('datadate')['bret_t1y'].apply(yu.uniformed_rank).values

i_sd_us_dd = i_sd_us['datadate'].drop_duplicates()


### factset entity-ticker mapping

i_ent_scr_sec_entity = pd.read_parquet(r"S:\Data\Factset\raw_weekly_full_files\ent_supply_chain_hub\ent_scr_sec_entity\20220101.parquet",
                                       columns = ['FSYM_ID', 'FACTSET_ENTITY_ID']) # 1 entity <> multiple fsym

i_sym_coverage = pd.read_parquet(r"S:\Data\Factset\raw_weekly_full_files\sym_hub\sym_coverage\20220212.parquet",
                                 columns = ['FSYM_ID', 'PROPER_NAM
E', 'FSYM_PRIMARY_EQUITY_ID', 
                                            'FSYM_PRIMARY_LISTING_ID', 'FSYM_REGIONAL_ID', 'FSYM_SECURITY_ID'])
i_sym_coverage = i_sym_coverage[i_sym_coverage['FSYM_ID']==i_sym_coverage['FSYM_PRIMARY_EQUITY_ID']]
    
i_sym_ticker_region = pd.read_parquet(r"S:\Data\Factset\raw_weekly_full_files\sym_ticker\sym_ticker_region\20220101.parquet",
                                      columns = ['FSYM_ID','TICKER_REGION'])

i_tk_map = i_ent_scr_sec_entity.merge(i_sym_coverage, on = 'FSYM_ID', how = 'inner')
i_tk_map = i_tk_map.merge(i_sym_ticker_region, left_on = 'FSYM_PRIMARY_LISTING_ID', right_on = 'FSYM_ID', 
                          how = 'inner', suffixes = ['', '_region'])
i_tk_map = i_tk_map.drop(columns = ['FSYM_ID_region'])
i_tk_map = i_tk_map[['FACTSET_ENTITY_ID','TICKER_REGION','PROPER_NAME']]


### factset supply chain 

i_ent_sc = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_supply_etl_i_supply.parquet')
i_ent_sc['START_DATE'] = pd.to_datetime(i_ent_sc['START_DATE'])
i_ent_sc['END_DATE'] = pd.to_datetime(i_ent_sc['END_DATE'])

i_ent_sc = i_ent_sc.merge(i_tk_map, left_on = 'SUPPLIER_FACTSET_ENTITY_ID', right_on = 'FACTSET_ENTITY_ID', how = 'left')
i_ent_sc = i_ent_sc.drop(columns = ['FACTSET_ENTITY_ID'])\
                   .rename(columns = {'TICKER_REGION':'TICKER_REGION_supplier','PROPER_NAME':'NAME_supplier'})
i_ent_sc = i_ent_sc.merge(i_tk_map, left_on = 'CUSTOMER_FACTSET_ENTITY_ID', right_on = 'FACTSET_ENTITY_ID', how = 'left')
i_ent_sc = i_ent_sc.drop(columns = ['FACTSET_ENTITY_ID'])\
                   .rename(columns = {'TICKER_REGION':'TICKER_REGION_customer','PROPER_NAME':'NAME_customer'})



### loop: mean dnstream returns
                   
o_dnstream_bret = []
                   
for dt in pd.date_range(start = '2016-01-01', end = '2020-08-01'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    t_sd_us = i_sd_us[i_sd_us['datadate'] == i_sd_us_dd[i_sd_us_dd<=dt].max()]
    
    
    t_ent_sc_1st = i_ent_sc[(i_ent_sc['START_DATE']<=dt) & ((i_ent_sc['END_DATE']>=dt)| i_ent_sc['END_DATE'].isnull())]
    
    t_ent_sc_2nd = t_ent_sc_1st.merge(t_ent_sc_1st[['SUPPLIER_FACTSET_ENTITY_ID','CUSTOMER_FACTSET_ENTITY_ID','TICKER_REGION_customer']],
                              left_on='CUSTOMER_FACTSET_ENTITY_ID', right_on='SUPPLIER_FACTSET_ENTITY_ID', how='left', suffixes=['_m',''])
    t_ent_sc_2nd = t_ent_sc_2nd[['TICKER_REGION_supplier','TICKER_REGION_customer']]
    
    
    c1 = t_ent_sc_1st['
TICKER_REGION_customer'].notnull() & t_ent_sc_1st['TICKER_REGION_supplier'].notnull()
    t_ent_sc_1st = t_ent_sc_1st[c1]
    c1 = t_ent_sc_2nd['TICKER_REGION_customer'].notnull() & t_ent_sc_2nd['TICKER_REGION_supplier'].notnull()
    t_ent_sc_2nd = t_ent_sc_2nd[c1]
    
    t_ent_sc_1st = t_ent_sc_1st[t_ent_sc_1st['TICKER_REGION_supplier'].str.contains('-CN')]
    t_ent_sc_1st = t_ent_sc_1st[t_ent_sc_1st['TICKER_REGION_customer'].str.contains('-US')]
    t_ent_sc_1st['ticker_supplier'] = t_ent_sc_1st['TICKER_REGION_supplier'].str.replace('-CN','').str.strip()
    t_ent_sc_1st['ticker_customer'] = t_ent_sc_1st['TICKER_REGION_customer'].str.replace('-US','').str.strip()
    
    t_ent_sc_2nd = t_ent_sc_2nd[t_ent_sc_2nd['TICKER_REGION_supplier'].str.contains('-CN')]
    t_ent_sc_2nd = t_ent_sc_2nd[t_ent_sc_2nd['TICKER_REGION_customer'].str.contains('-US')]
    t_ent_sc_2nd['ticker_supplier'] = t_ent_sc_2nd['TICKER_REGION_supplier'].str.replace('-CN','').str.strip()
    t_ent_sc_2nd['ticker_customer'] = t_ent_sc_2nd['TICKER_REGION_customer'].str.replace('-US','').str.strip()
    
        
    # merge us return, hedge and MC
    t_ent_sc = pd.concat([t_ent_sc_1st, t_ent_sc_2nd], sort = False)
    t_ent_sc = t_ent_sc[['ticker_supplier', 'ticker_customer']].drop_duplicates()
    
    t_ent_sc = t_ent_sc.merge(t_sd_us[['ticker','hedge', 'MC','bret_t1y_rk','bret_t65d_rk','bret_t65d']].rename(columns={'ticker':'ticker_customer'})
                              , on = ['ticker_customer']
                              , how = 'left')
    
    # stats
    t_sum1 = t_ent_sc.groupby('ticker_supplier')['bret_t1y_rk'].agg(['mean', 'max']).reset_index()
    t_sum1.columns = ['ticker_supplier','bretUS_t1y_rk_mean','bretUS_t1y_rk_max']
    
    t_sum2 = t_ent_sc.groupby('ticker_supplier')['bret_t65d_rk'].agg(['mean', 'max']).reset_index()
    t_sum2.columns = ['ticker_supplier','bretUS_t65d_rk_mean','bretUS_t65d_rk_max']
    
    t_sum3 = t_ent_sc.groupby('ticker_supplier')[['bret_t65d_rk','MC']].apply(lambda x: (x['bret_t65d_rk']*x['MC']).sum()/x['MC'].sum()).reset_index()
    t_sum3.columns = ['ticker_supplier','bretUS_t65d_rk_MCmean']
    
    t_sum4 = t_ent_sc.groupby('ticker_supplier')[['bret_t65d','MC']].apply(lambda x: (x['bret_t65d']*x['MC']).sum()/x['MC'].sum()).reset_index()
    t_sum4.columns = ['ticker_supplier','bretUS_t65d_MCmean']
    
    t_sum5 = t_ent_sc[t_ent_sc.hedge=='SPY'].groupby('ticker_supplier')[['bret_t65d','MC']].apply(lambda x: (x['bret_t65d']*x['
MC']).sum()/x['MC'].sum()).reset_index()
    t_sum5.columns = ['ticker_supplier','bretSPY_t65d_MCmean']
       
    
    t_sum = t_sum1.merge(t_sum2, on = 'ticker_supplier', how = 'outer')
    t_sum = t_sum.merge(t_sum3, on = 'ticker_supplier', how = 'outer')
    t_sum = t_sum.merge(t_sum4, on = 'ticker_supplier', how = 'outer')
    t_sum = t_sum.merge(t_sum5, on = 'ticker_supplier', how = 'outer')
    t_sum['datadate'] = dt
    
    o_dnstream_bret.append(t_sum)

o_dnstream_bret = pd.concat(o_dnstream_bret, axis = 0)
c_sh = o_dnstream_bret['ticker_supplier'].str[0].isin(['6'])
c_sz = o_dnstream_bret['ticker_supplier'].str[0].isin(['3','0'])
o_dnstream_bret.loc[c_sh, 'ticker'] = o_dnstream_bret.loc[c_sh, 'ticker_supplier'] + '.SH'
o_dnstream_bret.loc[c_sz, 'ticker'] = o_dnstream_bret.loc[c_sz, 'ticker_supplier'] + '.SZ'
    


### loop: star company

 
o_star = []

for dt in pd.date_range(start = '2016-01-01', end = '2020-08-01'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    t_sd_us = i_sd_us[i_sd_us['datadate'] == i_sd_us_dd[i_sd_us_dd<=dt].max()]
    t_sd_us = t_sd_us[t_sd_us['bret_sharpe1y']>=2]

    t_ent_sc = i_ent_sc[(i_ent_sc['START_DATE']<=dt) & ((i_ent_sc['END_DATE']>=dt)| i_ent_sc['END_DATE'].isnull())]
    t_ent_sc = t_ent_sc[t_ent_sc['TICKER_REGION_customer'].notnull() & t_ent_sc['TICKER_REGION_supplier'].notnull()]
    t_ent_sc = t_ent_sc[t_ent_sc['TICKER_REGION_supplier'].str.contains('-CN')]
    t_ent_sc['ticker_supplier'] = t_ent_sc['TICKER_REGION_supplier'].str.replace('-CN','').str.strip()
    t_ent_sc = t_ent_sc[t_ent_sc['TICKER_REGION_customer'].str.contains('-US')] 
    t_ent_sc['ticker_customer'] = t_ent_sc['TICKER_REGION_customer'].str.replace('-US','').str.strip()
    
    t_ent_sc = t_ent_sc[t_ent_sc['ticker_customer'].isin(t_sd_us['ticker'].tolist())]
    
    s1 = t_ent_sc[['ticker_supplier']]
    s1['datadate']= dt
    s1['flg_customer_gt2']  = 1
    
    o_star.append(s1)

o_star = pd.concat(o_star, axis = 0)
c_sh = o_star['ticker_supplier'].str[0].isin(['6'])
c_sz = o_star['ticker_supplier'].str[0].isin(['3','0'])
o_star.loc[c_sh, 'ticker'] = o_star.loc[c_sh, 'ticker_supplier'] + '.SH'
o_star.loc[c_sz, 'ticker'] = o_star.loc[c_sz, 'ticker_supplier'] + '.SZ'    

o_star = o_star.groupby(['ticker','datadate'])['flg_customer_gt2'].sum().reset_index()




### combine 

icom = i_sd.merge(o_dnstream_bret, on = ['datadate', 'ticker'], how = 'left')
icom = icom.merge(o_star, on = ['datadate', 'ticker'], how = 'left')



### Id
ea 1: average us customer return

icom['flg_high_us'] = np.nan
icom.loc[icom['bretUS_t1y_rk_mean']>0.5, 'flg_high_us'] = 1
icom['sgnl_high_us'] = icom.groupby('ticker')['flg_high_us'].ffill(limit=100)
yu.create_cn_decay(icom, 'flg_high_us')
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_high_us','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_us','BarrRet_CLIP_USD+1d', static_data = i_sd) #1.12 / 1.0


icom['bretUS_t20d_rk_mean_bk'] = icom.groupby('datadate')['bretUS_t20d_rk_mean'].apply(lambda x: yu.pdqcut(x, bins=20)).values
# yu.create_cn_3x3(icom, ['bretUS_t20d_rk_mean_bk'], 'bretUS_t20d_rk_mean') # random
icom['bretUS_t20d_rk_max_bk'] = icom.groupby('datadate')['bretUS_t20d_rk_max'].apply(lambda x: yu.pdqcut(x, bins=20)).values
# yu.create_cn_3x3(icom, ['bretUS_t20d_rk_max_bk'], 'bretUS_t20d_rk_max') # random

icom['bretUS_t65d_rk_mean_bk'] = icom.groupby('datadate')['bretUS_t65d_rk_mean'].apply(lambda x: yu.pdqcut(x, bins=20)).values
# yu.create_cn_3x3(icom, ['bretUS_t65d_rk_mean_bk'], 'bretUS_t65d_rk_mean') # random
icom['bretUS_t65d_rk_max_bk'] = icom.groupby('datadate')['bretUS_t65d_rk_max'].apply(lambda x: yu.pdqcut(x, bins=20)).values
# yu.create_cn_3x3(icom, ['bretUS_t65d_rk_max_bk'], 'bretUS_t65d_rk_max') # random


icom['bretUS_t65d_MCmean_bk'] = icom.groupby('datadate')['bretUS_t65d_MCmean'].apply(lambda x: yu.pdqcut(x, bins=20)).values
yu.create_cn_3x3(icom, ['bretUS_t65d_MCmean_bk'], 'bretUS_t65d_MCmean') # random

icom['bretSPY_t65d_MCmean_bk'] = icom.groupby('datadate')['bretSPY_t65d_MCmean'].apply(lambda x: yu.pdqcut(x, bins=20)).values
yu.create_cn_3x3(icom, ['bretSPY_t65d_MCmean_bk'], 'bretSPY_t65d_MCmean') # random


### Idea 2: high-sharpe us customer
# sample size too low

icom['sgnl_customer_gt2'] = np.nan
c1 = icom['flg_customer_gt2'] >= 1
icom.loc[c1, 'sgnl_customer_gt2'] = 1


o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_customer_gt2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_customer_gt2','BarrRet_CLIP_USD+1d', static_data = i_sd)
