﻿#$%^&* pHolding_cn_mf_discount.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Jul  8 07:22:27 2022

@author: thzhang
"""

import yz.util as yu
import pWIND_util as pw

import pandas as pd
import numpy as np

import os



### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])



### discount

i_discount = yu.get_sql('''select s_info_windcode, trade_dt as datadate, discount_rate/100 as discount
                        from wind.dbo.ChinaClosedFundEODPrice
                        where trade_dt >= '20150101'
                        order by s_info_windcode, datadate''')
i_discount['datadate'] = pd.to_datetime(i_discount['datadate'], format='%Y%m%d')

i_discount['discount_t250d_mean'] = i_discount.groupby('s_info_windcode').rolling(250)['discount'].mean().values
i_discount['discount_t250d_std'] = i_discount.groupby('s_info_windcode').rolling(250)['discount'].std().values
i_discount['discount_t250d_z'] = (i_discount['discount'] - i_discount['discount_t250d_mean']).divide(i_discount['discount_t250d_std'])
i_discount['discount_t250d_z'] = i_discount['discount_t250d_z'].replace(np.inf, np.nan).replace(-np.inf, np.nan)

i_discount['discount_t250d_median'] = i_discount.groupby('s_info_windcode').rolling(250)['discount'].median().values
i_discount['discount_t250d_dist2med'] = i_discount['discount'] - i_discount['discount_t250d_median']


#import random
#tk = i_discount['s_info_windcode'].unique().tolist()[random.randint(0, 1547)]
#print(tk)
#i_discount.loc[i_discount['s_info_windcode']==tk, 'discount'].plot()


### MF liquidity
i_liq_files = os.listdir(r'S:\Data\China Data Hunt\cache\mf_impact')
i_liq_files = [os.path.join(r'S:\Data\China Data Hunt\cache\mf_impact', i) for i in i_liq_files]
i_liq = pd.concat(pd.read_csv(i, sep='|') for i in i_liq_files)
i_liq['ticker_fund'] = i_liq['ric'].str.replace('SS','SH')
i_liq['datadate'] = pd.to_datetime(i_liq['datadate'])

i_liq_dd = i_liq['datadate'].drop_duplicates()



### MF holding data


i_maturity = yu.get_sql('''select a.f_info_windcode as ticker_fund, a.f_info_name, a.f_info_setupdate, 
                     a.f_info_maturitydate, b.s_info_compcode  
                     from wind.dbo.ChinaMutualFundDescription a 
                     left join wind.dbo.WINDCUSTOMCODE b 
                     on a.f_info_windcode = b.S_INFO_WINDCODE''')
i_maturity['f_info_maturitydate'] = i_maturity['f_info_maturitydate'].fillna('20501231')
i_maturity = i_maturity.groupby('s_info_compcod
e')['f_info_maturitydate'].max().reset_index()
i_maturity['f_info_maturitydate'] = pd.to_datetime(i_maturity['f_info_maturitydate'], format='%Y%m%d')
    


i_h = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_wind_holding_mf_q_est.parquet')



# aggregate MF discount to ticker-level metrics

o_discount = []

for dt in i_discount['datadate'].drop_duplicates():
    if (dt.strftime('%Y%m%d') <= '20160101') or (dt.strftime('%Y%m%d') >= '20210101'):
        continue
    print(dt.strftime('%Y%m%d'),end=',')
    
    # get operating funds
    t_operating_compcode = i_maturity.loc[i_maturity['f_info_maturitydate']>=dt,'s_info_compcode'].tolist()
    
    
    # select recent 180 day disclosures
    t_est_holding = i_h[(i_h['datadate'] >= dt-pd.to_timedelta('180 days'))&(i_h['datadate'] <= dt)]
    
    # select the most recent disclosure of each fund 
    t_est_holding_maxdd = t_est_holding.groupby('s_info_compcode')['datadate'].max().reset_index()
    t_est_holding_maxdd = t_est_holding_maxdd[t_est_holding_maxdd['s_info_compcode'].isin(t_operating_compcode)]    
    t_est_holding = t_est_holding_maxdd.merge(t_est_holding, on = ['datadate', 's_info_compcode'], how = 'inner')
    
    # get rmb per 1pct    
    t_liq = i_liq[i_liq['datadate']==i_liq_dd[i_liq_dd<=dt].max()]
    
    
    # get discount
    t_discount = i_discount[i_discount['datadate']==dt]
    t_discount = t_discount[t_discount['s_info_windcode'].isin(t_est_holding['ticker_fund'].unique().tolist())]
    t_discount = t_discount.rename(columns = {'s_info_windcode': 'ticker_fund'})
    t_discount = t_discount[['ticker_fund','discount','discount_t250d_dist2med','discount_t250d_z']]
    
    # aggregate discount information
    tcom = t_est_holding.merge(t_discount, on = 'ticker_fund', how = 'inner')
    tcom = tcom.merge(t_liq[['ticker_fund','rmb_per_1pct']], on = ['ticker_fund'], how = 'left')
    
    s_rmb_wght_discount = tcom.groupby('ticker')[['held_dollar', 'discount']].apply(lambda x: x['held_dollar'].multiply(x['discount']).sum() / x['held_dollar'].sum())
    s_rmb_wght_discount.name = 'discount_rmb_wght'
    s_rmb_wght_discount = s_rmb_wght_discount.reset_index()
    
    s_rmb_wght_discount_z = tcom.groupby('ticker')[['held_dollar', 'discount_t250d_z']].apply(lambda x: x['held_dollar'].multiply(x['discount_t250d_z']).sum() / x['held_dollar'].sum())
    s_rmb_wght_discount_z.name = 'discount_z_rmb_wght'
    s_rmb_wght_discount_z = s_rmb_wght_discount_z.reset_index()
    
 
   s_rmb_wght_discount_d = tcom.groupby('ticker')[['held_dollar', 'discount_t250d_dist2med']].apply(lambda x: x['held_dollar'].multiply(x['discount_t250d_dist2med']).sum() / x['held_dollar'].sum())
    s_rmb_wght_discount_d.name = 'discount_dist2med_rmb_wght'
    s_rmb_wght_discount_d = s_rmb_wght_discount_d.reset_index()
    
    s_rmb = tcom.groupby('ticker')[['held_dollar', 'discount']].apply(lambda x: x['held_dollar'].multiply(x['discount']).sum())
    s_rmb.name = 'rmb_wght'
    s_rmb = s_rmb.reset_index()
        
    s_liq_wght_discount = tcom.groupby('ticker')[['rmb_per_1pct', 'discount']].apply(lambda x: x['rmb_per_1pct'].multiply(x['discount']).divide(0.01).sum() )
    s_liq_wght_discount.name = 'liq_rmb_wght'
    s_liq_wght_discount = s_liq_wght_discount.reset_index()
    
    
    s = s_rmb_wght_discount.merge(s_rmb_wght_discount_z, on = ['ticker'], how = 'outer')
    s = s.merge(s_rmb_wght_discount_d, on = ['ticker'], how = 'outer')
    s = s.merge(s_rmb, on = ['ticker'], how = 'outer')
    s = s.merge(s_liq_wght_discount, on = ['ticker'], how = 'outer')
    s['datadate'] = dt
    
    o_discount.append(s)

                
o_discount = pd.concat(o_discount, axis = 0)



### combine

icom = i_sd.merge(o_discount, on = ['ticker', 'datadate'], how = 'left')

icom['discount_rmb_wght_bk'] = icom.groupby('datadate')['discount_rmb_wght'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['discount_rmb_wght_bk'], 'discount_rmb_wght')

icom['discount_z_rmb_wght_bk'] = icom.groupby('datadate')['discount_z_rmb_wght'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['discount_z_rmb_wght_bk'], 'discount_z_rmb_wght')

icom['discount_dist2med_rmb_wght_bk'] = icom.groupby('datadate')['discount_dist2med_rmb_wght'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['discount_dist2med_rmb_wght_bk'], 'discount_dist2med_rmb_wght')

icom['rmb_wght_dv_pv'] = icom['rmb_wght'].divide(icom['avgPVadj'])
icom['rmb_wght_dv_pv_bk'] = icom.groupby('datadate')['rmb_wght_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['rmb_wght_bk'] = icom.groupby('datadate')['rmb_wght'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['rmb_wght_dv_pv_bk'], 'rmb_wght_dv_pv') # more mono than the others: +1 +2 -2.5 -0.5
yu.create_cn_3x3(icom, ['rmb_wght_bk'], 'rmb_wght')

icom['liq_rmb_wght_dv_pv'] = icom['liq_rmb_wght'].divide(icom['avgPVadj'])
icom['liq_rmb_wght_dv_pv_bk'] = icom.groupby('datadate')['liq_r
mb_wght_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['liq_rmb_wght_dv_pv_bk'], 'liq_rmb_wght_dv_pv') # more mono than the others: +1.5 / -2

