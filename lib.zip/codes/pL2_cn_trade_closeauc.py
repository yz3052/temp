﻿#$%^&* pL2_cn_trade_closeauc.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Sep  8 10:54:54 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine




### sd china

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])



### get pv



i_pv = yu.get_sql("select ticker, datadate, pv from [CNDBPROD].[dbo].[TRTH_PV_CN] where datadate>='2017-01-01'")
i_pv['code'] = i_pv['ticker'].str[:6]
i_pv['ticker'] = i_pv['ticker'].str.replace('SS','SH')




### get close auction trade volumes

i_aucc = pd.read_csv(r'S:\TZ\backtester\data_cache\kdb_L2_cn_codebank_trade_sum_shsz_aucc.csv')

i_aucc['code'] = i_aucc['code'].astype(str).str.zfill(6)
c_sh = i_aucc['code'].str[0].isin(['6'])
c_sz = i_aucc['code'].str[0].isin(['0','3'])
i_aucc.loc[c_sh, 'ticker'] = i_aucc.loc[c_sh, 'code'] + '.SH'
i_aucc.loc[c_sz, 'ticker'] = i_aucc.loc[c_sz, 'code'] + '.SZ'
i_aucc['datadate'] = pd.to_datetime(i_aucc['date'])
i_aucc = i_aucc.sort_values(['ticker', 'datadate'])





### combine 

icom = i_sd.merge(i_aucc, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_pv, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])


icom['large_b_aucc_dv_pvaucc'] = icom['large_b_wind_aucc'] / icom['pv_mktAUCC']
icom['large_b_aucc_dv_pv'] = icom['large_b_wind_aucc'] / icom['pv']
icom['large_net_aucc_dv_pvaucc'] = (icom['large_b_wind_aucc'] - icom['large_s_wind_aucc']) / icom['pv_mktAUCC']
icom['large_net_aucc_dv_pv'] = (icom['large_b_wind_aucc'] - icom['large_s_wind_aucc']) / icom['pv']


icom['avgPVadj_rk'] = icom.groupby('datadate')['avgPVadj'].apply(yu.uniformed_rank)
icom['avgPVadj_bk'] = icom.groupby('datadate')['avgPVadj'].apply(lambda x: yu.pdqcut(x,bins=10)).values

for c in ['large_b_aucc_dv_pvaucc','large_b_aucc_dv_pv','large_net_aucc_dv_pvaucc','large_net_aucc_dv_pv']:
    icom[c+'_bk'] = icom.groupby('datadate')[c].apply(lambda x: yu.pdqcut(x,bins=10)).values
    COLS = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL','GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL' ]
    icom[c+'_orth'] = icom.groupby('datadate')[COLS+['SRISK']+[c]].apply(lambda x: yu.orthogonalize_cn_v2(x[c], x[COLS], x['SRISK'])).values
    icom[c+'_orth_bk'] = icom.groupby(['datadate','avgPVadj_bk'])[c+'_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
    yu.create_cn_3x3(icom, [c+'_bk'], c)
    yu.create_cn_3x3(icom, [c+'_orth_b
k'], c)
    
    
    
icom['large_b_aucc_dv_pvaucc_orth_rk'] = icom.groupby('datadate')['large_b_aucc_dv_pvaucc_orth'].apply(yu.uniformed_rank)
icom['large_b_aucc_dv_pvaucc_orth_rk_ma20d'] = icom.groupby('ticker').rolling(20)['large_b_aucc_dv_pvaucc_orth_rk'].mean().values
icom['large_b_aucc_dv_pvaucc_orth_rk_ma20d_bk'] = icom.groupby('datadate')['large_b_aucc_dv_pvaucc_orth_rk_ma20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['large_b_aucc_dv_pvaucc_orth_rk_ma20d_bk'], 'large_b_aucc_dv_pvaucc_orth_rk_ma20d') #  

icom['large_b_aucc_dv_pvaucc_ma20d'] = icom.groupby('ticker').rolling(20)['large_b_aucc_dv_pvaucc'].mean().values
icom['large_b_aucc_dv_pvaucc_ma20d_orth'] = icom.groupby('datadate')[COLS+['SRISK']+['large_b_aucc_dv_pvaucc_ma20d']].apply(lambda x: yu.orthogonalize_cn_v2(x['large_b_aucc_dv_pvaucc_ma20d'], x[COLS], x['SRISK'])).values
icom['large_b_aucc_dv_pvaucc_ma20d_orth_bk'] = icom.groupby('datadate')['large_b_aucc_dv_pvaucc_ma20d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['large_b_aucc_dv_pvaucc_ma20d_orth_bk'], 'large_b_aucc_dv_pvaucc_ma20d_orth') #  

icom['large_b_aucc_dv_pvaucc_ma20d'] = icom.groupby('ticker').rolling(20)['large_b_aucc_dv_pvaucc'].mean().values
icom['large_b_aucc_dv_pvaucc_ma20d_bk'] = icom.groupby('datadate')['large_b_aucc_dv_pvaucc_ma20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['large_b_aucc_dv_pvaucc_ma20d_bk'], 'large_b_aucc_dv_pvaucc_ma20d') #  

icom['large_b_aucc_dv_pvaucc_ma10d'] = icom.groupby('ticker').rolling(10)['large_b_aucc_dv_pvaucc'].mean().values
icom['large_b_aucc_dv_pvaucc_ma10d_bk'] = icom.groupby('datadate')['large_b_aucc_dv_pvaucc_ma10d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['large_b_aucc_dv_pvaucc_ma10d_bk'], 'large_b_aucc_dv_pvaucc_ma10d') #  



icom['large_b_aucc_dv_pvaucc_rk'] = icom.groupby('datadate')['large_b_aucc_dv_pvaucc'].apply(yu.uniformed_rank)
icom['sgnl'] = np.nan
c1 = icom['large_b_aucc_dv_pvaucc_rk'] > 0.95
icom.loc[c1, 'sgnl'] = 1
icom['sgnl'] = icom.groupby('ticker')['sgnl'].ffill(limit=5)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) 

# pnl generally looks bad 
# b is better than s and net
# it's a short-lived alpha i.e. ma20d looks bad 

