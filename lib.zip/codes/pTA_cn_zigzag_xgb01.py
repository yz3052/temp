﻿#$%^&* pTA_cn_zigzag_xgb01.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 16:21:31 2023

@author: thzhang
"""


import pandas as pd
import numpy as np

import util as yu
import os



### sd

i_sd = yu.get_sd_cn_1800()
i_sd = i_sd.sort_values(['DataDate'])




### zigzag


# get data

i_zz = pd.read_parquet('/dat/summit_capital/TZ/tmp/pTA_cn_zigzag_featurepool7.parquet')
i_zz['T-1d'] = pd.to_datetime(i_zz['T-1d'])

# normalize to 0-1 range

cols = ['zz_vertex_1', 'zz_vertex_2', 'zz_vertex_3', 'zz_vertex_4',
       'zz_vertex_5', 'zz_vertex_6', 'zz_vertex_7', 'zz_vertex_8',
       'zz_vertex_9', 'zz_vertex_10', 'zz_vertex_11', 'zz_vertex_12',
       'zz_vertex_13', 'zz_vertex_14', 'zz_vertex_15']
cols_nm = [c+'_nm' for c in cols]
i_zz['range'] = i_zz[cols+['c']].max(axis=1) - i_zz[cols+['c']].min(axis=1)
i_zz[cols_nm] = i_zz[cols].sub(i_zz[cols+['c']].min(axis=1),axis=0).divide(i_zz['range'], axis = 0)
i_zz['zz_vertex_fut1_nm'] = (i_zz['zz_vertex_fut1'] - i_zz[cols].min(axis=1)) / i_zz['range']
i_zz['c_nm'] = (i_zz['c'] - i_zz[cols+['c']].min(axis=1)) / i_zz['range']

# get rid of rows with short history

i_zz = i_zz[i_zz['zz_vertex_15'].notnull()]

# change from float64 -> float32

cols_32 = [c for c in i_zz.columns.tolist() if ('zz_vertex' in c) or ('seg_hgt' in c) or ('seg_len' in c)]
i_zz[cols_32] = i_zz[cols_32].astype(np.float32)




### get height predictions from xgboost results
# 20230125_z2_upTrend

root = '/dat/summit_capital/TZ/backtester/xg/test_20230125_z2_upTrend'
i_files = os.listdir(root)
i_files = [f for f in i_files if 'fscore' not in f]
i_files = [f for f in i_files if f.endswith('txt')]
i_xg_results = pd.concat([pd.read_csv(os.path.join(root, f), sep='|') for f in i_files], axis = 0)
i_xg_results['Ticker'] = i_xg_results['Ticker'].astype(str).str.zfill(6)
i_xg_results['DataDate'] = pd.to_datetime(i_xg_results['DataDate'])




### combine

icom = i_sd.merge(i_xg_results, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom.merge(i_zz, on = ['Ticker', 'T-1d'], how = 'left')
icom = icom.sort_values(['Ticker', 'DataDate'])



# calculate segment length predictions

icom['curr_hieght_nm'] = icom['c_nm'] - icom['zz_vertex_1_nm']
c1 = icom['zz_curr_trend'] != 1
icom.loc[c1, 'curr_hieght_nm'] = np.nan

icom['pred_resid_ln'] = icom[['seg_len_idx1','seg_len_idx2','seg_len_idx3','seg_len_idx4']].mean(axis=1) - icom['seg_len_curr']
c1 = icom['pred_resid_ln']<=0
icom.loc[c1, 'pred_resid_ln'] = np.nan


icom['dist
_to_pred_nm'] = icom['yhat'] - icom['curr_hieght_nm']
icom['dist_to_pred_nm_perDay'] = icom['dist_to_pred_nm'] / icom['pred_resid_ln']
icom['dist_to_pred'] = icom['dist_to_pred_nm'] * icom['range']
icom['dist_to_pred_perDay'] = icom['dist_to_pred'] / icom['pred_resid_ln']


cols_i = [c for c in i_sd.columns.tolist() if c[:2]=='wd']
cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
icom['ones'] = 1

icom['dist_to_pred_nm_orth'] = icom.groupby('DataDate')[cols_i+cols_f+['dist_to_pred_nm','ones']].apply(lambda x: yu.orthogonalize_cn_v3(x['dist_to_pred_nm'],x[cols_f],x[cols_i],x['ones'])).values
icom['dist_to_pred_orth'] = icom.groupby('DataDate')[cols_i+cols_f+['dist_to_pred','ones']].apply(lambda x: yu.orthogonalize_cn_v3(x['dist_to_pred'],x[cols_f],x[cols_i],x['ones'])).values

icom['dist_to_pred_nm_perDay_orth'] = icom.groupby('DataDate')[cols_i+cols_f+['dist_to_pred_nm_perDay','ones']].apply(lambda x: yu.orthogonalize_cn_v3(x['dist_to_pred_nm_perDay'],x[cols_f],x[cols_i],x['ones'])).values
icom['dist_to_pred_perDay_orth'] = icom.groupby('DataDate')[cols_i+cols_f+['dist_to_pred_perDay','ones']].apply(lambda x: yu.orthogonalize_cn_v3(x['dist_to_pred_perDay'],x[cols_f],x[cols_i],x['ones'])).values

for c in ['dist_to_pred_nm', 'dist_to_pred_nm_perDay', 'dist_to_pred', 'dist_to_pred_perDay',
          'dist_to_pred_nm_orth', 'dist_to_pred_orth',
          'dist_to_pred_nm_perDay_orth', 'dist_to_pred_perDay_orth']:
    icom[c+'_bk'] = icom.groupby('DataDate')[c].apply(lambda x: yu.pdqcut(x, bins=10)).values
    icom[c+'_rk'] = icom.groupby('DataDate')[c].apply(yu.uniformed_rank)
    yu.create_cn_3x3_linux(icom, [c+'_bk'], c)





o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2019-01-01', '2021-12-31') ].\
            dropna(subset=['dist_to_pred_nm_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'dist_to_pred_nm_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # -0.9
# not working, more line a reversal after a bullish move







