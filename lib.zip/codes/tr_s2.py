﻿#$%^&* tr_s2.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 10 14:25:10 2020

@author: thzhang
"""


import os, gc
import inspect
from yz import get_sql, print_progress, tic, toc
from yz.util import pickle_bz_dump, pickle_bz_load

import pandas as pd
import numpy as np
from numba import njit, jit
from datetime import date, datetime

import statsmodels.api as sm
import cvxpy as cp

import pickle

import matplotlib.pyplot as plt

from bokeh.io import show
from bokeh.layouts import column, gridplot
from bokeh.models import ColumnDataSource, RangeTool, HoverTool, CustomJS, CrosshairTool, LinearAxis, Range1d
from bokeh.plotting import figure


# feature of the bt() function:
# 1) Input = DataFrame (entry signal + other features), DataFrame(bbg mkt data and TA)
# 1.1) main input: df_tk_dt_sgnl_feature
#                   - each signal value means pst (the number of clip sizes) we want by the opening of the next trading day
#                   - not pivoted
#                   - assume it is sorted by ticker and datadate
#                   - columns must include "ticker" and "datadate"
#                   - data can be discrete (time series not continuous)
# 2) main purpose: calculate holding period and stop loss / win 
# 2.1) limitation: cannot calculate any mkt data related metrics (e.g. TA) in strategy because everything is pivoted
#                       we only do that ticker by ticker (e.g. when a stock halts trading for a few days...)
# 2.2) main logic: right after the end of each trading day, rebuild today's pst changes and pnls, and set the order for next day
# 3) numba core function
#    - iterate through signals not cdates
# 4) generate GF's backtest pnl chart
# 5) generate GF's quintile table and automatically adjust to binary if signals are binary 
# 6) vizualize other backtest variables in bokeh

class Backtest_200911(object):
    
    def __init__(self, df_tk_dt_sgnl_feature, str_sgnl_column, str_ret_column, df_bbg_data, str_from_ymd, str_to_ymd):
        # str_ret_column: hret, bret
        
        
        print (datetime.now().strftime('%H:%M:%S') + ' - __init__ starts.')
        
        #----------------------------------------------------------------------
        ### dates and ticker
        #----------------------------------------------------------------------
        
        # quality check signals
        if df_tk_dt_sgnl_feature.duplicated(subset=['ticker','datadate'],keep= False).sum() > 0:
            raise Exception("Dup
licated ticker / datadate detected in signals.")
        
        # fill in missing cdates into signal df
        t_cdates_tk = df_tk_dt_sgnl_feature.groupby('ticker')['datadate'].\
                      apply(lambda x: pd.Series(pd.date_range(start=x.min()-pd.to_timedelta('730 days'),
                                                              end=x.max()+pd.to_timedelta('730 days')))
                           ).reset_index()
        t_cdates_tk = t_cdates_tk[t_cdates_tk.datadate<='2020-09-30'][['ticker','datadate']]
        self.df_cdates_tk_sgnl = t_cdates_tk.merge(df_tk_dt_sgnl_feature, on = ['ticker','datadate'], how = 'left')
        
        # fill in missing sgnl values with 0
        self.df_cdates_tk_sgnl[str_sgnl_column] = self.df_cdates_tk_sgnl[str_sgnl_column].fillna(0)
        
        # create arr: arr is the array that backtester will loop thru
        #             all variables that begin with arr should have the same length
        self.arr_ticker = self.df_cdates_tk_sgnl['ticker'].values 
        self.arr_sgnl = self.df_cdates_tk_sgnl[str_sgnl_column].values 
        self.arr_same_tk = (self.df_cdates_tk_sgnl['ticker']==self.df_cdates_tk_sgnl['ticker'].shift()).values
        self.arr_cdates = self.df_cdates_tk_sgnl['datadate'].values

        # tk uni
        self.tk = df_tk_dt_sgnl_feature.ticker.unique().tolist()
        
        print (datetime.now().strftime('%H:%M:%S') + ' - tk and cdates done.')
        
        #----------------------------------------------------------------------
        ### load bbg data (generated in util.py)
        #----------------------------------------------------------------------
        
        # load data
        if df_bbg_data is None:
            self.df_mkt = pd.read_parquet(r"S:\Infrastructure\backtester\data_cache\bbg_mkt_data_v2.parquet")
        else:
            self.df_mkt = df_bbg_data
            
        # filter: data within tk uni and cdates range
        self.df_mkt = self.df_mkt[self.df_mkt.ticker.isin(self.tk)]
        self.df_mkt = self.df_mkt[self.df_mkt.datadate>=np.min(self.arr_cdates)]
        
        # quality check
        if self.df_mkt.duplicated(subset=['ticker','datadate'], keep = False).sum() > 0:
            raise Exception("Duplicated ticker / datadate detected in mkt data.")
        
        #----------------------------------------------------------------------
        # tdate variables: save np arrays to dic_mkt_tdate
        self.dic_mkt_tdate = {}        
  
      for c in ['ret_c_c', 'ret_o_c', 'ret_optPeriod', 'c_dema_df', 'c_dema_s', 
                  'c_dema_l', 'zz_curr_trend', 'zz_curr_idx', 'zz_vertex_1', 
                  'zz_vertex_idx1', 'zz_vertex_2', 'zz_vertex_idx2', 'zz_vertex_3', 
                  'zz_vertex_idx3', 'zz_vertex_4', 'zz_vertex_idx4', 'zz_vertex_5', 
                  'zz_vertex_idx5', 'zz_vertex_6', 'zz_vertex_idx6', 'zz_vertex_7', 
                  'zz_vertex_idx7', 'zz_vertex_8', 'zz_vertex_idx8', 'zz_vertex_10', 
                  'zz_vertex_idx10', 'uni_ret_std', 'uni_ret_mean', 'bgmv_ret_15std', 
                  'bgmv_ret_2std', 'vol_ret', 'hdg_tk', 'ret_c_c_hedge', 
                  'ret_o_c_hedge', 'hret_c_c', 'hret_o_c', 'hret_o_c_p1d', 
                  'hret_c_c_p1d', 'hret_pid', 'hret_optPeriod', 'hret_bo_l', 
                  'hret_bo_ema', 'hret_bo_u', 'hret_bo_coef', 'hret_ema_df', 
                  'hret_dema_s', 'hret_dema_l', 'uni_hret_std', 'uni_hret_mean',
                  'bgmv_hret_15std', 'bgmv_hret_2std', 'vol_hret', 'bd2e', 'cd2e', 
                  'bdae', 'cdae', 'adpv','adpv_1d']:
            self.dic_mkt_tdate[c] = self.df_mkt[c].values
        
        # formatting
        self.df_mkt = self.df_mkt.sort_values(['ticker','datadate']).reset_index(drop = True)
        
        # start and end index for each ticker and date
        self.df_mkt.loc[self.df_mkt['ticker']!=self.df_mkt['ticker'].shift(),'tk_start_idx'] =\
            self.df_mkt.index.values[self.df_mkt['ticker']!=self.df_mkt['ticker'].shift()]
        self.df_mkt['tk_start_idx'] = self.df_mkt['tk_start_idx'].fillna(method = 'ffill')
        self.df_mkt['tk_curr_idx'] = self.df_mkt.index.values
        
        #----------------------------------------------------------------------
        # cadate variables: tdate cdate index mapping + others
        self.df_ctdates_tk_sgnal_data = self.df_cdates_tk_sgnl[['ticker','datadate']].\
                                  merge(self.df_mkt[['ticker','datadate','tk_start_idx','tk_curr_idx',
                                                     'adpv', 'adpv_1d','vD', 
                                                     'hret_pid','hret_c_c','hret_o_c','hret_c_o',
                                                     'bret_c_c','bret_o_c','bret_c_o',
                                                     'bgmv_hret_2std']], 
                                  on = ['ticker','datadate'], how = 'left')
        self.df_ctdates_tk_sgnal_data[['tk_star
t_idx','tk_curr_idx','adpv','adpv_1d']] = \
            self.df_ctdates_tk_sgnal_data[['tk_start_idx','tk_curr_idx','adpv','adpv_1d']].fillna(method = 'ffill')
        
        
        self.arr_tdate_idx_s = self.df_ctdates_tk_sgnal_data['tk_start_idx'].values
        self.arr_tdate_idx_e = self.df_ctdates_tk_sgnal_data['tk_curr_idx'].values
        self.arr_adpv_1d = self.df_ctdates_tk_sgnal_data['adpv_1d'].values
        self.arr_adpv = self.df_ctdates_tk_sgnal_data['adpv'].values
        self.arr_vD = self.df_ctdates_tk_sgnal_data['vD'].values
        self.arr_hret_o_c = self.df_ctdates_tk_sgnal_data['hret_o_c'].values
        self.arr_hret_c_c = self.df_ctdates_tk_sgnal_data['hret_c_c'].values
        self.arr_hret_c_o = self.df_ctdates_tk_sgnal_data['hret_c_o'].values
        self.arr_hret_pid = self.df_ctdates_tk_sgnal_data['hret_pid'].values
        self.arr_xret_o_c = self.df_ctdates_tk_sgnal_data[str_ret_column+'_o_c'].values
        self.arr_xret_c_o = self.df_ctdates_tk_sgnal_data[str_ret_column+'_c_o'].values
        self.arr_xret_c_c = self.df_ctdates_tk_sgnal_data[str_ret_column+'_c_c'].values
        self.arr_bgmv_hret_2std = self.df_ctdates_tk_sgnal_data['bgmv_hret_2std'].values
        
        
        # clip size        
        self.arr_clip_sizeD = self.arr_adpv_1d*0.01
        self.arr_clip_sizeD[self.arr_clip_sizeD>1e6] = 1e6
        
        print (datetime.now().strftime('%H:%M:%S') + ' - bbg done.')
        
        #----------------------------------------------------------------------
        ### static data uni 
        #----------------------------------------------------------------------
        
        i_stdata = get_sql("select ticker, datadate from [BackTest].[dbo].[Static_Data_Daily]")
        i_stdata['isin_stdata'] = True
        self.df_ctdates_tk_sgnal_data = self.df_ctdates_tk_sgnal_data.merge(i_stdata, how = 'left',
                                                                            on = ['datadate','ticker'])
        self.df_ctdates_tk_sgnal_data['isin_stdata'] = self.df_ctdates_tk_sgnal_data['isin_stdata'].fillna(False)
                
        self.arr_isin_stdata = self.df_ctdates_tk_sgnal_data['isin_stdata'].values
        #----------------------------------------------------------------------
        ### strategy variables 
        #----------------------------------------------------------------------
        
        # strat variables        
        self.arr_pstD_bo = self.h_create_zero_arr()
   
     self.arr_pstD_bc = self.h_create_zero_arr()
        self.arr_pstS_bo = self.h_create_zero_arr()
        self.arr_pstS_bc = self.h_create_zero_arr()
        
        self.arr_dsrPstClip_bo = np.array([np.nan] * len(self.arr_cdates))
        self.arr_dsrPstClip_bc = np.array([np.nan] * len(self.arr_cdates))
        
        self.arr_dsrPstD_bo = np.array([np.nan] * len(self.arr_cdates))
        self.arr_dsrPstD_bc = np.array([np.nan] * len(self.arr_cdates))
        self.arr_dsrPstD_unfilled = np.array([np.nan] * len(self.arr_cdates))
        
        self.arr_ordType = self.h_create_zero_arr() + 1 # default: 1 means GFD, 2 means GTC (for 3 days)
        
        self.arr_ordD_bo = self.h_create_zero_arr()
        self.arr_ordD_bc = self.h_create_zero_arr()

        self.arr_pnlD = self.h_create_zero_arr()
        
        self.arr_entry_hret_pid = np.array([np.nan] * len(self.arr_cdates))
        self.arr_entry_ret_pid = np.array([np.nan] * len(self.arr_cdates))
        
        self.arr_barsheld_since_pst_open = self.h_create_zero_arr() - 1
        self.arr_tbarsheld_since_pst_open = self.h_create_zero_arr() - 1
        
        self.arr_tbar_unfilled_ord = self.h_create_zero_arr()
        self.arr_cbar_unfilled_ord = self.h_create_zero_arr()
        
        self.arr_curr_pst_pnlD = self.h_create_zero_arr()
        
        self.arr_vD_quota = self.h_create_zero_arr()
        self.arr_ones = self.h_create_zero_arr() + 1
        
        # state matrix
        self.dic_state = {}
        
        #----------------------------------------------------------------------
        ### reporting variables
        #----------------------------------------------------------------------  
        
        self.dic_report = {}
        
        print (datetime.now().strftime('%H:%M:%S') + ' - Initiation done.')
        

    def h_create_zero_arr(self):
        return np.zeros(len(self.arr_cdates))
    
    # ----- loop over strat -----
    
    @jit(forceobj=True)
    def start(self, strat_f, dict_param):
        
        for num in range(1, len(self.arr_cdates)):
            
            #---------------------------------------------------------------------------------
            #                                         Carry on pst + unfilled order @ mkt open
            #---------------------------------------------------------------------------------
            
            if self.arr_same_tk[num]:
                
                # carry on unfilled orde
r from the previous bar            
                self.arr_dsrPstD_unfilled[num] = self.arr_dsrPstD_unfilled[num-1]            
            
                # carry on pst from the previous bar
                self.arr_pstD_bo[num] = self.arr_pstD_bc[num-1]
            
            #---------------------------------------------------------------------------------
            #                                               set up daily volume quota for ordD
            #---------------------------------------------------------------------------------
            
            
            # here the vD quota is debatable... it could be estimated by adpv_1d or we can limit it to vD*0.01
            # setup vD quota before filling orders   
            # *2 so that we can reverse the pst
            self.arr_vD_quota[num] = self.arr_clip_sizeD[num-1]*2
            
            # vD quota is 0 if price is nan
            if np.isnan(self.arr_hret_c_c[num]):
                self.arr_vD_quota[num] = 0
            
            #---------------------------------------------------------------------------------
            #                                                             fill order @ bo + bc
            #---------------------------------------------------------------------------------
            
            # assign unfilled order from prev bar to the new order from prev bar            
            if self.arr_same_tk[num] & np.isnan(self.arr_dsrPstD_bo[num-1]) &\
                (~np.isnan(self.arr_dsrPstD_unfilled[num])) :
                self.arr_dsrPstD_bo[num-1] = self.arr_dsrPstD_unfilled[num]
                
            # fill orders from prev bar
            if self.arr_same_tk[num] & (~np.isnan(self.arr_dsrPstD_bo[num-1])):
            
                t_dsrOrd_v_bo = self.arr_dsrPstD_bo[num-1] - self.arr_pstD_bo[num]
                t_dsrOrd_abs_v_bo = np.abs(t_dsrOrd_v_bo)
                t_allowedOrd_v_bo = np.minimum(t_dsrOrd_abs_v_bo, self.arr_vD_quota[num])
                
                self.arr_pstD_bo[num] = self.arr_pstD_bo[num] + t_allowedOrd_v_bo * np.sign(t_dsrOrd_v_bo)
            
            elif np.isnan(self.arr_dsrPstD_bo[num-1]):
                
                pass # we already assigned prev day's pst
            
            # update unfilled orders after bo
            if self.arr_same_tk[num] & (self.arr_pstD_bo[num] != self.arr_dsrPstD_bo[num-1]):
                self.arr_dsrPstD_unfilled[num] = self.arr_dsrPstD_
bo[num-1]
            elif self.arr_same_tk[num] & (self.arr_pstD_bo[num] == self.arr_dsrPstD_bo[num-1]):
                self.arr_dsrPstD_unfilled[num] = np.nan
           
            # assume we do not enter pst @ bc
            self.arr_pstD_bc[num] = self.arr_pstD_bo[num]
            
            #---------------------------------------------------------------------------------
            #                                                                   entry hret pid
            #---------------------------------------------------------------------------------
            
            # update entry hret pid with open price if there is a new pst 
            if (np.sign(self.arr_pstD_bo[num]) != np.sign(self.arr_pstD_bc[num-1])) & (self.arr_pstD_bo[num]!=0) :
                self.arr_entry_hret_pid[num] = self.arr_hret_pid[num]/(1 + self.arr_hret_o_c[num])
            # get entry hret pid from prev bar if there is an existing pst
            elif (np.sign(self.arr_pstD_bo[num]) == np.sign(self.arr_pstD_bc[num-1])) & (self.arr_pstD_bo[num]!=0) :
                self.arr_entry_hret_pid[num] = self.arr_entry_hret_pid[num-1]
            else:
                # keep arr_entry_hret_pid = np.nan
                pass
                
            
            #---------------------------------------------------------------------------------
            #                                                                         pnl @ bc
            #---------------------------------------------------------------------------------            
            
            # calc pnl during overnight period
            if self.arr_same_tk[num]:
                self.arr_pnlD[num] = self.arr_pnlD[num] +\
                                    np.multiply(self.arr_pstD_bc[num-1], self.arr_xret_c_o[num])
            
            # calc pnl during the trading session
            self.arr_pnlD[num] = self.arr_pnlD[num] +\
                                np.multiply(self.arr_pstD_bo[num],self.arr_xret_o_c[num])
                                                
            
            #---------------------------------------------------------------------------------
            #                                                                curr pst pnl @ bc
            #---------------------------------------------------------------------------------            
            
            # new or held pst / update curr pst pnl
            if self.arr_same_tk[num] & (self.arr_
pstD_bc[num]!=0):
                self.arr_curr_pst_pnlD[num] = self.arr_curr_pst_pnlD[num-1] + 0 if np.isnan(self.arr_pnlD[num]) else self.arr_curr_pst_pnlD[num-1] + self.arr_pnlD[num]
    
            # closed pst / clear curr pst pnl
            if self.arr_same_tk[num] & (self.arr_pstD_bc[num-1]!=0) & (self.arr_pstD_bc[num]==0):
                self.arr_curr_pst_pnlD[num] = 0
            
            # convert nan to zero
            self.arr_curr_pst_pnlD[num] = np.nan_to_num(self.arr_curr_pst_pnlD[num])
            
            #---------------------------------------------------------------------------------
            #                                                             cbars since pst open
            #---------------------------------------------------------------------------------            
            
            # if there is no pst any more ... 
            if self.arr_same_tk[num] & (self.arr_pstD_bc[num-1] == 0):
                self.arr_barsheld_since_pst_open[num] = -1
            
            # new pst: initiate
            if (self.arr_same_tk[num] & (self.arr_pstD_bc[num]!=0) & (self.arr_pstD_bc[num-1]== 0)) |\
                (np.multiply(self.arr_pstD_bc[num], self.arr_pstD_bc[num-1])<0):
                self.arr_barsheld_since_pst_open[num]=1
            
            # existing pst: update
            if self.arr_same_tk[num] & (np.multiply(self.arr_pstD_bc[num], self.arr_pstD_bc[num-1])>0):
                self.arr_barsheld_since_pst_open[num] = self.arr_barsheld_since_pst_open[num] +1
            
            
            
            #---------------------------------------------------------------------------------
            #                                                             tbars since pst open
            #---------------------------------------------------------------------------------            
            
            # if there is no pst any more ...
            if self.arr_same_tk[num] & (self.arr_pstD_bc[num-1] == 0):
                self.arr_tbarsheld_since_pst_open[num] = -1
            
            # new pst: initiate
            if ((self.arr_pstD_bc[num]!=0) & (self.arr_pstD_bc[num-1]== 0)) |\
                (np.multiply(self.arr_pstD_bc[num], self.arr_pstD_bc[num-1])<0):
                self.arr_tbarsheld_since_pst_open[num] = 1
            
            # if it has been a tdate today ...
            if self.arr_same_tk[num] & (np.multiply(self.arr_pstD_bc[num], self.arr_pstD_bc[num-1])>0
) & \
                (~np.isnan(self.arr_vD[num])) & (~np.isnan(self.arr_hret_c_c[num])):
                self.arr_tbarsheld_since_pst_open[num] = self.arr_tbarsheld_since_pst_open[num-1] + 1

            # if it hasn't been a tdate today ... 
            if self.arr_same_tk[num] & (np.multiply(self.arr_pstD_bc[num], self.arr_pstD_bc[num-1])>0) &\
                (np.isnan(self.arr_vD[num]) | np.isnan(self.arr_hret_c_c[num])):
                self.arr_tbarsheld_since_pst_open[num ] = self.arr_tbarsheld_since_pst_open[num-1]
                
            
                
                
            #---------------------------------------------------------------------------------
            #                                                            cdays of unfilled ord
            #---------------------------------------------------------------------------------            
            
                       
            # cond: new unfilled ord 
            cond_new_unfilled_new_ord = np.isnan(self.arr_dsrPstD_unfilled[num-1]) & (~np.isnan(self.arr_dsrPstD_unfilled[num]))
            cond_new_unfilled_oppo_ord = (np.multiply(self.arr_dsrPstD_unfilled[num-1], self.arr_dsrPstD_unfilled[num]) < 0)
            cond_new_unfilled_ord = cond_new_unfilled_new_ord | cond_new_unfilled_oppo_ord
            
            # cond: unfilled ord is for ADDING pst ONLY 
            cond_existing_unfilled = (np.multiply(self.arr_dsrPstD_unfilled[num], self.arr_dsrPstD_unfilled[num-1])>0)    
            cond_unfilled_curr_pst_same_dir = (np.multiply(self.arr_dsrPstD_unfilled[num], self.arr_pstD_bc[num])>=0)
            cond_unfilled_prev_pst_same_dir = (np.multiply(self.arr_dsrPstD_unfilled[num], self.arr_pstD_bc[num-1])>=0)
            cond_unfilled_existing_and_not_pst_exit = cond_existing_unfilled & \
                                                        cond_unfilled_curr_pst_same_dir & \
                                                        cond_unfilled_prev_pst_same_dir
            
            # new: unfilled ord
            if cond_new_unfilled_ord:
                self.arr_cbar_unfilled_ord[num] = 1
            
            # update: unfilled ord
            if self.arr_same_tk[num] & cond_unfilled_existing_and_not_pst_exit:
                self.arr_cbar_unfilled_ord[num] = self.arr_cbar_unfilled_ord[num-1] + 1
            
            # If the order cannot be filled with 5 cdays, cancel ord 
            cond_cancel_unfilled_ord2 = cond_unfilled_existing
_and_not_pst_exit & (self.arr_cbar_unfilled_ord[num] > 4)
            if self.arr_same_tk[num] & cond_cancel_unfilled_ord2:
                self.arr_dsrPstD_unfilled[num] = np.nan
            
            # unfilled trading bar = 0 if order has been filled 
            if np.isnan(self.arr_dsrPstD_unfilled[num]):
                self.arr_cbar_unfilled_ord[num] = 0
            
            #---------------------------------------------------------------------------------
            #                                                            tdays of unfilled ord
            # no. of trading bars ending up with unfilled ord
            # it shows the EXTRA number of bars taken to fill an order  
            # (e.g. 3 means it takes 1 + 3 days to fill a position)
            #---------------------------------------------------------------------------------            
            
            # unfilled tbar initiated 

            cond_tdate_today = (~np.isnan(self.arr_hret_c_c[num])) & (~np.isnan(self.arr_vD[num]))
            if cond_new_unfilled_ord & cond_tdate_today:
                self.arr_tbar_unfilled_ord[num] = 1

            # unfilled tbar + 1 if ord is not filled  and if it is a tdate today
            cond_existing_unfilled_ord_tdate = cond_unfilled_existing_and_not_pst_exit & cond_tdate_today
            if self.arr_same_tk[num] & cond_existing_unfilled_ord_tdate:                                                
                self.arr_tbar_unfilled_ord[num] = self.arr_tbar_unfilled_ord[num-1] + 1
            
            # unfilled tbar = prev if ord is not filled  and if it is NOT a tdate today
            cond_existing_unfilled_ord_non_tdate = cond_unfilled_existing_and_not_pst_exit & (~cond_tdate_today)
            
            if self.arr_same_tk[num] & cond_existing_unfilled_ord_non_tdate:
                self.arr_tbar_unfilled_ord[num] = self.arr_tbar_unfilled_ord[num-1]  
            
            # If the "add pst" order cannot be filled within 3 tdays, cancel the order  
            cond_cancel_unfilled_ord =  cond_unfilled_existing_and_not_pst_exit & (self.arr_tbar_unfilled_ord[num] > 3)
            if self.arr_same_tk[num] & cond_cancel_unfilled_ord:
                self.arr_dsrPstD_unfilled[num] = np.nan
            
            if np.isnan(self.arr_dsrPstD_unfilled[num]):
                self.arr_tbar_unfilled_ord[num] = 0
                
            
            strat_f(self, num, dict_param)
    
    def reporting(self):
    
    
        ledger = pd.DataFrame({'ticker': self.arr_ticker,
                               'datadate': self.arr_cdates,
                               'pst': self.arr_pstD_bc,
                               'pnl': self.arr_pnlD,
                               'pst_cumpnl': self.arr_curr_pst_pnlD,
                               'sgnl': self.arr_sgnl,
                               'tbar': self.arr_tbarsheld_since_pst_open
                               })
    
        ledger.groupby('datadate')['pnl'].sum().cumsum().plot()
        
        return ledger
    
@jit(forceobj=True)
def strat_si_01(self,num, dict_param):
    
    # send exit order after holding n days 
    if (self.arr_tbarsheld_since_pst_open[num] >= 20) & (self.arr_pstD_bc[num]!=0):
        self.arr_dsrPstD_bo[num] = 0
    
    # send stop loss order
    if (self.arr_pstD_bc[num]!=0):
        # if we make > 10%
        if (self.arr_hret_pid[num]/self.arr_entry_hret_pid[num]-1)*np.sign(self.arr_pstD_bc[num]) > 0.1:
            self.arr_dsrPstD_bo[num] = 0
        
        # if there is a 2 std movement in favor of our pst
        if (np.sign(self.arr_pstD_bc[num]) == np.sign(self.arr_hret_c_c[num])) and self.arr_bgmv_hret_2std[num]:
            self.arr_dsrPstD_bo[num] = 0
        
    # send entry order
    if (self.arr_sgnl[num]!=0) & (self.arr_isin_stdata[num]):
        self.arr_dsrPstD_bo[num] = self.arr_sgnl[num] * self.arr_clip_sizeD[num]
    


        
#i_data_original = pd.read_parquet(r"S:\Data\CHC_research\PRODUCTION_temp\pSI_02_hotDowngrade.parquet")
#i_data_original = pd.read_parquet(r"S:\Data\CHC_research\PRODUCTION_temp\pSI_02_SuddenChange.parquet")
#i_data_original = pd.read_parquet(r"S:\Data\CHC_research\PRODUCTION_temp\pSI_02_SuddenChange_bgmv.parquet")
i_data_original = pd.read_parquet(r"S:\Data\CHC_research\PRODUCTION_temp\pSI_02_SuddenChange_bgmv_xed.parquet")
i_data_original['sgnl'] = i_data_original['sgnl']*(-1)

i_data = i_data_original[['ticker', 'datadate', 'sgnl']]
i_data = i_data.drop_duplicates(keep = 'first')

#i_bbg = pd.read_parquet(r"S:\Infrastructure\backtester\data_cache\bbg_mkt_data_v2.parquet")
bt = Backtest_200911(i_data, 'sgnl', 'bret', df_bbg_data = i_bbg, str_from_ymd = '2017-05-01',str_to_ymd = '2020-06-01')
tic()
bt.start(strat_si_01, {})
toc()
ledger = bt.reporting()
