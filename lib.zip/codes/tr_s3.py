﻿#$%^&* tr_s3.py #$%^&*



class BackTest(Object):
	def __init__(df,strat_func, ret_col, ymd_from_str, ymd_to_str):
	# df must have "datadate", "ticker" and a signal column
