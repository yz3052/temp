﻿#$%^&* pFDMTL_cn_mdna.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb 20 16:09:33 2023

@author: thzhang
"""

import pandas as pd
import numpy as np

import util as yu



### get ed

i_ed = yu.get_sql('''select distinct Ticker, last_ped as ped, last_ed as ed
                  FROM [CNDBPROD].[dbo].[CNINFO_ED_FORMAT]''')
i_ed = i_ed.sort_values('ed')
i_ed = i_ed.drop_duplicates(subset = ['Ticker', 'ped'], keep = 'last')


### get data

i_data = pd.read_parquet('/dat/summit_capital/TZ/mdna_summary_stat.parquet')

i_data = i_data.sort_values(['Ticker', 'ped'])

i_data['charcnt_avg_t3y'] = i_data.groupby('Ticker').rolling(6)['char_cnt'].mean().values
i_data['charcnt_std_t3y'] = i_data.groupby('Ticker').rolling(6)['char_cnt'].std().values
i_data['charcnt_avg_t6y'] = i_data.groupby('Ticker').rolling(12)['char_cnt'].mean().values
i_data['charcnt_std_t6y'] = i_data.groupby('Ticker').rolling(12)['char_cnt'].mean().values

i_data['pos_neg_ratio'] = (i_data['pos_word_cnt'] - i_data['neg_word_cnt']) / (i_data['pos_word_cnt'] + i_data['neg_word_cnt'])
i_data['netpos_dv_charcnt'] = (i_data['pos_word_cnt'] - i_data['neg_word_cnt']) / i_data['char_cnt']

i_data['charcnt_z_3y'] = (i_data['char_cnt'] - i_data['charcnt_avg_t3y']) / i_data['charcnt_std_t3y']
i_data['charcnt_z_6y'] = (i_data['char_cnt'] - i_data['charcnt_avg_t6y']) / i_data['charcnt_std_t6y']

i_data['ped'] = pd.to_datetime(i_data['ped'])
i_data = i_data.merge(i_ed, on = ['Ticker', 'ped'], how = 'left')
i_data = i_data.dropna(subset = ['ed'])

i_data = i_data[['Ticker', 'ped', 'ed', 
                 'pos_neg_ratio', 'netpos_dv_charcnt', 'charcnt_z_3y', 'charcnt_z_6y']]
i_data = i_data.sort_values('ed')


### get sd

i_sd = yu.get_sd_cn_1800_bind()
i_sd = i_sd.sort_values('DataDate')

### get ed

i_d2ed = yu.get_sd_cn_1800gf()
i_d2ed = i_d2ed[['Ticker', 'DataDate', 'd2preed', 'd2nexted']]

### get ni metrics

i_ni = pd.read_csv('/export/datadev/DashBoard/FG/pFDMTL_ciq_ped_gf_ni_1rk.csv', sep = '|')
i_ni['DataDate'] = pd.to_datetime(i_ni['DataDate'])
i_ni['Ticker'] = i_ni['Ticker'].astype(int).astype(str).str.zfill(6)
i_ni = i_ni.rename(columns = {'alpha_raw': 'ni_metric_rk'})


### combine

icom = pd.merge_asof(i_sd, i_data, by = 'Ticker', left_on = 'DataDate', right_on = 'ed')
icom = icom.merge(i_ni, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom.merge(i_d2ed, on = ['Ticker', 'DataDate'], how = 'left')


### vanilla
# pos neg ratio mono -2.5 +1.5
# charcnt zscore is ran
dom

for f in ['pos_neg_ratio', 'netpos_dv_charcnt', 'charcnt_z_3y', 'charcnt_z_6y']:    
    icom[f+'_bk'] = icom.groupby('DataDate')[f].apply(lambda x: yu.pdqcut(x,bins=10)).values
    yu.create_cn_3x3_linux(icom, [f+'_bk'], f)
    
icom['pos_neg_ratio_rk'] = icom.groupby('DataDate')['pos_neg_ratio'].apply(yu.uniformed_rank).values
o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ].\
                dropna(subset=['pos_neg_ratio_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
                'pos_neg_ratio_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.5 / 0.9

    
### pos neg ratio, ni metric, rk diff
# bar chart close to mono, but negative relation

icom['pos_neg_ratio_rk'] = icom.groupby('DataDate')['pos_neg_ratio'].apply(yu.uniformed_rank)
icom['ni_metric_rk'] = icom.groupby('DataDate')['ni_metric_rk'].apply(yu.uniformed_rank)
icom['ni_metric_bk'] = icom.groupby('DataDate')['ni_metric_rk'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['test'] = icom['pos_neg_ratio_rk'] - icom['ni_metric_rk']
icom['test_bk'] = icom.groupby('DataDate')['test'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['test_nibk'] = icom.groupby(['DataDate', 'ni_metric_bk'])['pos_neg_ratio'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3_linux(icom, ['test_bk'], 'test')
yu.create_cn_3x3_linux(icom, ['test_nibk'], 'test') # not superior, close to random


### pos neg ratio within certain periods
# higher bar chart return within posted 5d , but pnl not better

f = 'pos_neg_ratio'
icom[f+'_bk'] = icom.groupby('DataDate')[f].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom[f+'_rk'] = icom.groupby('DataDate')[f].apply(yu.uniformed_rank)
yu.create_cn_3x3_linux(icom, [f+'_bk'], f) # benchmark
yu.create_cn_3x3_linux(icom[icom['d2preed']<=5], [f+'_bk'], f) # bar chart return higher
yu.create_cn_3x3_linux(icom[icom['d2nexted']>=5], [f+'_bk'], f) # random

o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') & icom['d2preed'].le(5) ].\
                dropna(subset=['pos_neg_ratio_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
                'pos_neg_ratio_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.54 / -1.7
    
yu.create_cn_3x3_linux(icom[icom['d2preed']<=5], [f+'_bk'], f)

