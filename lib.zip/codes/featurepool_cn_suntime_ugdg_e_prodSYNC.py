﻿#$%^&* featurepool_cn_suntime_ugdg_e_prodSYNC.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 30 08:15:30 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pyodbc
from sqlalchemy import create_engine
import urllib

import os

import datetime


#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------


save_path = '/dat/summit_capital/TZ/PROD_FEATURES/featurepool_cn_desc_suntime_ugdg_e'
conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
conn_wind = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_wind_dbo;PWD=DusONA3Habredl;''TDS_Version=8.0;')))

today = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
today = pd.to_datetime(today.date())
today_str = today.strftime('%Y%m%d')



#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------


i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()



#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------



dates_to_query = i_cal['DataDate'].dt.strftime('%Y%m%d.parquet').drop_duplicates().tolist()
dates_to_query = [d for d in dates_to_query if (d>='20170101.parquet') and (d<today.strftime('%Y%m%d.parquet'))]

existing_dates = os.listdir(save_path)

dates_to_query = [d for d in dates_to_query if d not in existing_dates]



# =============================================================================
# 
# =============================================================================


if len(dates_to_query) == 0:
    quit()

startdt = pd.to_datetime(min(dates_to_query), format='%Y%m%d.parquet') - pd.to_timedelta('456 days')
startdt = startdt.strftime('%Y-%m-%d')


i_rpt_original = pd.re
ad_sql('''select id, report_id, stock_code as Ticker,create_date,
                    report_year*10 + report_quarter as report_period, 
                    report_type, reliability, organ_id, author_name, 
                    forecast_np as frcst_np, forecast_eps as frcst_eps,
                    attention, entrytime
                    from suntime_prod.dbo.rpt_forecast_stk
                    WITH (NOLOCK)
                    where create_date >= '{0}'
                    '''.format(startdt), conn) 


i_rpt_original['create_date'] = pd.to_datetime(i_rpt_original['create_date'])
i_rpt_original['datadate'] = pd.to_datetime(i_rpt_original['entrytime'].dt.date)

i_rpt_original['author_name'] = i_rpt_original['author_name'].fillna('_')
c1 = i_rpt_original['author_name'].str.contains(',')
i_rpt_original.loc[c1, 'author_1st'] = i_rpt_original.loc[c1, 'author_name'].str.split(',').str[0]
i_rpt_original.loc[~c1, 'author_1st'] = i_rpt_original.loc[~c1, 'author_name']


# =============================================================================
# 
# =============================================================================



for i in dates_to_query:

    
    # dates
    
    t_1d = pd.to_datetime(i, format='%Y%m%d.parquet')    
    t_1d_str = t_1d.strftime('%Y%m%d')
    t_182d_str = (t_1d - pd.to_timedelta('182 days')).strftime('%Y%m%d')    
    
    t_0d_str = i_cal.loc[i_cal['T-1d']==t_1d, 'DataDate'].dt.strftime('%Y-%m-%d').iloc[0]
    t_today = pd.to_datetime(t_0d_str)
    t_today_str = t_today.strftime('%Y-%m-%d')
    t_today_4am_str = t_today_str + ' 04:00:00'
    t_today_4am = pd.to_datetime(t_today_4am_str)
    t_last_tdate_str = t_1d.strftime('%Y-%m-%d')
    t_preday456 = t_today - pd.to_timedelta('456 days')
    t_preday456_str = t_preday456.strftime('%Y-%m-%d')
    
    
    
    
    
    # get ed calendar
    
    t_ed_cal = pd.read_sql('''select Ticker, last_ed
                               FROM [CNDBPROD].[dbo].[CNINFO_ED_format] 
                               with (nolock)
                               where datadate = '{0}'
                               order by Ticker, d2nexted 
                               '''.format(t_last_tdate_str), conn)
    
    t_ed_cal = t_ed_cal.drop_duplicates(subset = ['Ticker'], keep = 'first')
       
    
    
    
    # get suntime data
    
    c1 = i_rpt_original['entrytime'].lt(t_today_4am) | i_rpt_original['create_date'].lt(t_last_tdate_str)
    i_rpt = i_rpt_original[ c1 & (i_rpt_original['creat
e_date']>=t_preday456.strftime('%Y-%m-%d'))]
    
        
    # calculate prev rating 
    
    i_rpt_s3 = i_rpt.sort_values(['organ_id','author_1st','Ticker','report_period','datadate','entrytime','report_id']).reset_index(drop = True)
    
    t_rpt_s3_np = i_rpt_s3[['organ_id','author_1st','Ticker','report_period','report_id','datadate','frcst_np']]
    t_rpt_s3_np = t_rpt_s3_np.drop_duplicates(keep = 'last')
    t_rpt_s3_np = t_rpt_s3_np.dropna()
    t_rpt_s3_np['frcst_np_prev'] = t_rpt_s3_np.groupby(['organ_id', 'author_1st','Ticker','report_period'])['frcst_np'].shift()
    t_rpt_s3_np = t_rpt_s3_np.drop(columns = ['frcst_np'])    
    i_rpt_s3 = i_rpt_s3.merge(t_rpt_s3_np, on = ['organ_id','author_1st','Ticker','report_period','report_id','datadate'], how = 'left')

    t_rpt_s3_eps = i_rpt_s3[['organ_id','author_1st','Ticker','report_period','report_id','datadate','frcst_eps']]
    t_rpt_s3_eps = t_rpt_s3_eps.drop_duplicates(keep = 'last')
    t_rpt_s3_eps = t_rpt_s3_eps.dropna()
    t_rpt_s3_eps['frcst_eps_prev'] = t_rpt_s3_eps.groupby(['organ_id', 'author_1st','Ticker','report_period'])['frcst_eps'].shift()
    t_rpt_s3_eps = t_rpt_s3_eps.drop(columns = ['frcst_eps'])    
    i_rpt_s3 = i_rpt_s3.merge(t_rpt_s3_eps, on = ['organ_id','author_1st','Ticker','report_period','report_id','datadate'], how = 'left')
    
    # calculate rating upgrades since prev ed
    
    i_rpt_s3 = i_rpt_s3[~i_rpt_s3['report_type'].isin([21, 28, 98])]
    i_rpt_s3 = i_rpt_s3.sort_values(['Ticker','report_period','organ_id','datadate'])    
    i_rpt_s3 = i_rpt_s3.merge(t_ed_cal[['Ticker','last_ed']], on = 'Ticker', how = 'left')
    
    
    
    # get the most recent ugdg - since prev ed
    
    i_rpt_s4 = i_rpt_s3[(i_rpt_s3['create_date']>i_rpt_s3['last_ed']+pd.to_timedelta('7 days')) | (i_rpt_s3['last_ed'].isnull())] 
    
    t_ugdg_tk_maxdd = i_rpt_s4.groupby(['Ticker','organ_id'])['create_date'].max().reset_index()
    if len(t_ugdg_tk_maxdd)==0:
        print('__noUGDG__',end=',')
        continue
    t_ugdg_tk_maxdd = t_ugdg_tk_maxdd.merge(i_rpt_s4,on=['Ticker','organ_id','create_date'],how='inner')
        
    t_ugdg_tk_maxdd['flg_np_up'] = np.sign(t_ugdg_tk_maxdd['frcst_np'] - t_ugdg_tk_maxdd['frcst_np_prev'])
    t_ugdg_tk_maxdd['flg_eps_up'] = np.sign(t_ugdg_tk_maxdd['frcst_eps'] - t_ugdg_tk_maxdd['frcst_eps_prev'])
    
    t_ugdg_tk_maxdd['flg_np_up'] = t_ugdg_tk_maxdd['flg_np_up'].fillna(0)
    t_ugdg_tk_maxdd['flg_eps_up'] = t_ugdg_tk_maxdd['flg_ep
s_up'].fillna(0)    
    t_ugdg_tk_maxdd['sgn_flg_e_up'] = np.sign(t_ugdg_tk_maxdd[['flg_np_up','flg_eps_up']].sum(axis=1))   
        
    t_ugdg_tk_maxdd = t_ugdg_tk_maxdd.groupby(['Ticker', 'organ_id'])[['sgn_flg_e_up']].apply(lambda x: np.sign(x.mean())).reset_index()
    
            
    # summarize rating upgrade per ticker

    s_up_ratio_since_ed = t_ugdg_tk_maxdd.groupby('Ticker')['sgn_flg_e_up'].apply(lambda x: x.sum()/x.count())
    s_up_ratio_since_ed = s_up_ratio_since_ed.reset_index()        
    s_up_ratio_since_ed = s_up_ratio_since_ed.rename(columns={'sgn_flg_e_up':'np_pct_up_since_preved'})
    
    
    
    
    
    # get the most recent ugdg - t1q
    
    i_rpt_s4 = i_rpt_s3[i_rpt_s3['create_date']>t_today - pd.to_timedelta('91 days') ] 
    
    t_ugdg_tk_maxdd = i_rpt_s4.groupby(['Ticker','organ_id'])['create_date'].max().reset_index()
    if len(t_ugdg_tk_maxdd)==0:
        print('__noUGDG__',end=',')
        continue
    t_ugdg_tk_maxdd = t_ugdg_tk_maxdd.merge(i_rpt_s4,on=['Ticker','organ_id','create_date'],how='inner')
        
    t_ugdg_tk_maxdd['flg_np_up'] = np.sign(t_ugdg_tk_maxdd['frcst_np'] - t_ugdg_tk_maxdd['frcst_np_prev'])
    t_ugdg_tk_maxdd['flg_eps_up'] = np.sign(t_ugdg_tk_maxdd['frcst_eps'] - t_ugdg_tk_maxdd['frcst_eps_prev'])
    
    t_ugdg_tk_maxdd['flg_np_up'] = t_ugdg_tk_maxdd['flg_np_up'].fillna(0)
    t_ugdg_tk_maxdd['flg_eps_up'] = t_ugdg_tk_maxdd['flg_eps_up'].fillna(0)    
    t_ugdg_tk_maxdd['sgn_flg_e_up'] = np.sign(t_ugdg_tk_maxdd[['flg_np_up','flg_eps_up']].sum(axis=1))   
        
    t_ugdg_tk_maxdd = t_ugdg_tk_maxdd.groupby(['Ticker', 'organ_id'])[['sgn_flg_e_up']].apply(lambda x: np.sign(x.mean())).reset_index()
                
    # summarize rating upgrade per ticker

    s_up_ratio_t1q = t_ugdg_tk_maxdd.groupby('Ticker')['sgn_flg_e_up'].apply(lambda x: x.sum()/x.count())
    s_up_ratio_t1q = s_up_ratio_t1q.reset_index()        
    s_up_ratio_t1q = s_up_ratio_t1q.rename(columns={'sgn_flg_e_up':'np_pct_up_t1q'})
    
    
    
    # output
    
    s_up_ratio = s_up_ratio_since_ed.merge(s_up_ratio_t1q, on = ['Ticker'], how = 'outer')
    s_up_ratio['DataDate'] = t_today
    s_up_ratio.to_parquet(os.path.join(save_path, i))
    
    
    
    
    
    
    
    
    
    
