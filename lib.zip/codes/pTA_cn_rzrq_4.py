﻿#$%^&* pTA_cn_rzrq_4.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 30 10:49:06 2022

@author: thzhang
"""


import pandas as pd
import numpy as np
from scipy import stats

import pWIND_util as pw
import yz.util as yu


# this studies zhuanrongtong's daily balance 

# the problem with the data is that ZRT daily balance could be a bit spotty.
# this data doesn't cover broker's pool, hence it's only a portion of supply


### get sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])


### get ZRT 

i_zrt_trade = pd.read_parquet(r"\\vfudat04\udat04\thzhang\Downloads\zhuanrongtong_trade.parquet")
# 'datadate', 'file_name', 'ticker', 'balance_start_shr', 'lend_shr', 'balance_end_shr', 'balance_end_rmb'

### get morning limitup




### get price
i_px = yu.get_sql("select s_info_windcode as ticker, trade_dt as datadate, S_DQ_ADJCLOSE as c from [WIND].[dbo].[ASHAREEODPRICES]")
i_px['datadate'] = pd.to_datetime(i_px['datadate'], format = '%Y%m%d')


### get 券商 持仓

i_s_h = yu.get_sql("select * from wind.dbo.ashareinstholderderdata where report_period >='20150601' ")
i_s_h = i_s_h[i_s_h['S_HOLDER_HOLDERCATEGORY']=='券商']
i_s_h = i_s_h.rename(columns = {'S_INFO_WINDCODE': 'ticker','ANN_DATE': 'datadate'})
i_s_h['datadate']  = pd.to_datetime(i_s_h['datadate'], format = '%Y%m%d')
i_s_h = i_s_h.sort_values(['datadate'])

o_sellside_h = []

for dt in pd.date_range(start = '2016-01-01', end = '2021-06-01'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    t_h = i_s_h[(i_s_h['datadate']>=dt-pd.to_timedelta('120 days')) & (i_s_h['datadate']<=dt)]
    
    t_h_max_rp = t_h.groupby('ticker')['REPORT_PERIOD'].max().reset_index()
    t_h = t_h.merge(t_h_max_rp, on = ['ticker','REPORT_PERIOD'], how = 'inner')
    
    t_h = t_h.drop_duplicates(subset=['ticker','S_HOLDER_COMPCODE'], keep = 'last')
    
    t_h_sum = t_h.groupby('ticker')['S_HOLDER_QUANTITY','S_HOLDER_PCT'].sum().reset_index()
    t_h_sum['datadate'] = dt
    o_sellside_h.append(t_h_sum)

o_sellside_h = pd.concat(o_sellside_h, axis = 0)

i_float = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate, S_DQ_MV as float_mktcap 
                     from wind.dbo.AShareEODDerivativeIndicator''')
i_float['datadate'] = pd.to_datetime(i_float['datadate'], format = '%Y%m%d')

o_sellside_h = o_sellside_h.merge(i_float, on = ['ticker','datadate'], how = 'left')
    
    
    




### get rzrq data

o_rzrq = pd.read_parquet(r'S:\Data\China Data Hunt\cache\cninfo_rzrq.par
quet')
o_rzrq['datadate'] = pd.to_datetime(o_rzrq['datadate'])
o_rzrq = o_rzrq.drop(columns = ['SECNAME','MEMO'])

# rzrq metrics
o_rzrq = o_rzrq.merge(i_zrt_trade, on = ['ticker', 'datadate'], how = 'left')
o_rzrq['F008N'] = o_rzrq['F008N'].fillna(0)
o_rzrq['rq_dv_zrt'] = o_rzrq['F008N'].divide(o_rzrq['balance_end_rmb'])
o_rzrq['rq_dv_zrt'] = o_rzrq['rq_dv_zrt'].replace(np.inf, np.nan).replace(-np.inf, np.nan)

o_rzrq = o_rzrq.sort_values(['ticker', 'datadate'])
o_rzrq['rq_dv_zrt_t20d'] = o_rzrq.groupby('ticker').rolling(20)['rq_dv_zrt'].mean().values
o_rzrq['rq_dv_zrt_t63d'] = o_rzrq.groupby('ticker').rolling(63)['rq_dv_zrt'].mean().values


# get o_c_ret 

i_o_c_ret = pw.get_wind_mkt_data(col_list = ['ticker', 'datadate', 'adjret_o_c'])
i_o_c_ret = i_o_c_ret.sort_values(['ticker', 'datadate'])
i_o_c_ret['adjret_o_c_l1d'] = i_o_c_ret.groupby('ticker')['adjret_o_c'].shift()
i_o_c_ret['adjret_o_c_bk'] = i_o_c_ret.groupby('datadate')['adjret_o_c'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values

i_o_c_ret['adjret_o_c_t5d'] = i_o_c_ret.groupby('ticker').rolling(5)['adjret_o_c'].sum().values
i_o_c_ret['adjret_o_c_t10d'] = i_o_c_ret.groupby('ticker').rolling(10)['adjret_o_c'].sum().values
i_o_c_ret['adjret_o_c_t20d'] = i_o_c_ret.groupby('ticker').rolling(20)['adjret_o_c'].sum().values
i_o_c_ret['adjret_o_c_t63d'] = i_o_c_ret.groupby('ticker').rolling(63)['adjret_o_c'].sum().values
i_o_c_ret = i_o_c_ret[i_o_c_ret['datadate']>='2013-04-11']
i_o_c_ret['adjret_o_c_t5d_bk'] = i_o_c_ret.groupby('datadate')['adjret_o_c_t5d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values
i_o_c_ret['adjret_o_c_t10d_bk'] = i_o_c_ret.groupby('datadate')['adjret_o_c_t10d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values
i_o_c_ret['adjret_o_c_t20d_bk'] = i_o_c_ret.groupby('datadate')['adjret_o_c_t20d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values
i_o_c_ret['adjret_o_c_t63d_bk'] = i_o_c_ret.groupby('datadate')['adjret_o_c_t63d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values



### combine 

icom = i_sd.merge(o_rzrq, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_o_c_ret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(o_sellside_h, on = ['ticker', 'datadate'], how = 'left')



icom['rq_dv_zrt_bk'] = icom.groupby('datadate')['rq_dv_zrt'].apply(lambda x: yu.pdqcut(x, bins=10)).values
# yu.create_cn_3x3(icom, ['rq_dv_zrt_bk'], 'rq_dv_zrt') # random 

icom['rq_dv_zrt_t20
d_bk'] = icom.groupby('datadate')['rq_dv_zrt_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values
# yu.create_cn_3x3(icom, ['rq_dv_zrt_t20d_bk'], 'rq_dv_zrt_t20d') # random, LHS a bit higher


icom['prop_holding_rmb'] = icom['float_mktcap'] * 10000 * icom['S_HOLDER_PCT'] / 100
icom['rq_dv_zrtprop'] = icom['F008N'].divide(icom['balance_end_rmb'].add(icom['prop_holding_rmb']/2, fill_value = 0)) # assume 1/2 can be borrowed
icom['rq_dv_zrtprop'] = icom['rq_dv_zrtprop'].replace(np.inf,np.nan)
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['rq_dv_zrtprop_orth'] = icom.groupby('datadate')[COLS+['rq_dv_zrtprop']].apply(lambda x: yu.orthogonalize_cn(x['rq_dv_zrtprop'], x[COLS])).values
icom['rq_dv_zrtprop_bk'] = icom.groupby('datadate')['rq_dv_zrtprop'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['rq_dv_zrtprop_orth_bk'] = icom.groupby('datadate')['rq_dv_zrtprop_orth'].apply(lambda x: yu.pdqcut(x, bins=10)).values
# yu.create_cn_3x3(icom[icom.datadate<'2020-12-31'], ['rq_dv_zrtprop_bk'], 'rq_dv_zrtprop') # not mono: 左高右低
# yu.create_cn_3x3(icom[icom.datadate<'2020-12-31'], ['rq_dv_zrtprop_orth_bk'], 'rq_dv_zrtprop_orth') # not mono: 左高右低,比没有orth的好一点


icom['rq_dv_zrtprop_winsor'] = icom['rq_dv_zrtprop']
icom.loc[icom['rq_dv_zrtprop']==0, 'rq_dv_zrtprop_winsor'] = np.nan
icom['rq_dv_zrtprop_winsor_bk'] = icom.groupby('datadate')['rq_dv_zrtprop_winsor'].apply(lambda x: yu.pdqcut(x, bins=10)).values
# yu.create_cn_3x3(icom[icom.datadate<'2020-12-31'], ['rq_dv_zrtprop_winsor_bk'], 'rq_dv_zrtprop_winsor') #  not mono: LHS + RHS -

icom['balance_end_rmb_dv_float'] = icom['balance_end_rmb'].divide(icom['float_mktcap'])
icom['balance_end_rmb_dv_float_bk'] = icom.groupby('datadate')['balance_end_rmb_dv_float'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom[icom.datadate<'2020-12-31'], ['balance_end_rmb_dv_float_bk'], 'balance_end_rmb_dv_float') #  not mono: LHS- RHS+


icom['balance_end_rmb_dv_float_t10d'] = icom.groupby('ticker').rolling(10)['balance_end_rmb_dv_float'].mean().values
icom['balance_end_rmb_dv_float_t10d_bk'] = icom.groupby('datadate')['balance_end_rmb_dv_float_t10d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom[icom.datadate<'2020-12-31'], ['balance_end_rmb_dv_float_t10d_bk'], 'balance_end_rmb_dv_float_t10d') #  random


icom['rq_dv_zrt_rk'] = icom.groupby('datadate')['rq_dv_zrt'].apply(yu.uniformed_rank).values
icom['adjret_o_c_t20d_rk'] 
= icom.groupby('datadate')['adjret_o_c_t20d'].apply(yu.uniformed_rank).values

icom['test1'] = icom['rq_dv_zrt_rk'] - icom['adjret_o_c_t20d_rk']
icom['test1_bk'] = icom.groupby('datadate')['test1'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom[icom['adjret_o_c_t20d_rk']<-0.5], ['test1_bk'], 'test1') # 

# next: stock down, but more ZRT available -> 


### rq_dv_pv high/low, o2c low 


icom['rq_dv_pv'] = icom['F008N'].divide(icom['avgPVadj'])
icom['rq_dv_pv_rk'] = icom.groupby('datadate')['rq_dv_pv'].apply(yu.uniformed_rank).values
icom['rq_dv_pv_bk'] = icom.groupby('datadate')['rq_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['adjret_o_c_t20d_rk'] = icom.groupby('datadate')['adjret_o_c_t20d'].apply(yu.uniformed_rank).values
icom['adjret_o_c_t20d_bk'] = icom.groupby('datadate')['adjret_o_c_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['test2'] = -icom['rq_dv_pv_rk'] - icom['adjret_o_c_t20d_rk']
icom['test2_rk'] = icom.groupby('datadate')['test2'].apply(yu.uniformed_rank).values
icom['test2_bk'] = icom.groupby('datadate')['test2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['test2_bk'], 'test2') # mono: -6 +2
# yu.create_cn_3x3(icom, ['rq_dv_pv_bk'], 'rq_dv_pv') # 
# yu.create_cn_3x3(icom, ['adjret_o_c_t20d_bk'], 'adjret_o_c_t20d') # benchmark: mono: +3 -8 

icom['test_sgnl'] = np.nan
icom.loc[(icom['adjret_o_c_t20d_rk']<-0.8)&(icom['rq_dv_pv_rk']<-0.6), 'test_sgnl'] = 1
icom['test_sgnl'] = icom.groupby('ticker')['test_sgnl'].ffill(limit = 5)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2016-06-01','2019-12-31'))].\
                  dropna(subset=['test_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
                  'test_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.56 / 0.48





