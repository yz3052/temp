﻿#$%^&* pFlow_cn_nb__etl_v2_daily.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr  4 14:38:39 2023

@author: thzhang
"""


import pandas as pd
import numpy as np

import util as yu
import datetime

import os
from multiprocessing import Pool

# this is a script that gets daily hk holding and minimize sql usage
# this is for backfill only, not for production

# note: on a few dates, hk brokers have incomplete disclosure: 
# 20190102, 20190408, 20191125, 20190506, etc.
# in those cases, there is no way for us to differentiate incompelte disclosure and zero-holding
# HENCE, DO NOT FILLNA(0) AFTER THIS DATA IS MERGED INTO STATIC DATA!!!

# also dividend is not adjusted


#------------------------------------------------------------------------------
### ---1--- get dates_to_query
#------------------------------------------------------------------------------


### calendar

i_cal = yu.get_sql('''select distinct TradeDate_next as DataDate
                    from CNDBPROD.dbo.Calendar_Dates_CN''')
i_cal = i_cal.sort_values('DataDate')
i_cal = i_cal.reset_index(drop=True)
i_cal['T-1d'] = i_cal['DataDate'].shift()

today = pd.to_datetime(pd.to_datetime(datetime.datetime.today()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None).date())
i_cal_2018onw = i_cal[i_cal['DataDate'].ge('2018-07-10') & i_cal['DataDate'].le(today)]

### dates_to_query

i_existing = os.listdir('/dat/summit_capital/PROD/TZ/hk_holding/')
i_existing = [pd.to_datetime(d[:8],format='%Y%m%d') for d in i_existing]

dates_to_query = i_cal_2018onw[~i_cal_2018onw['DataDate'].isin(i_existing)]
dates_to_query = dates_to_query['DataDate'].tolist()


#------------------------------------------------------------------------------
### ---2--- prepare a static version of the data
#------------------------------------------------------------------------------




### get unique holder_enddate

if len(dates_to_query) > 0:

    t_start_14d = min(dates_to_query) - pd.to_timedelta('14 days')
    t_start_14d_str = t_start_14d.strftime('%Y-%m-%d')

else:
    print('empty dates to query')
    quit()

unique_dates = yu.get_sql_wind('''select distinct s_holder_enddate 
                                  from [WIND_PROD].[dbo].[SHSCMECHANISMOWNERSHIP]  
                                  with (nolock)
                                  where s_holder_enddate>='{0}' 
                               '''.format(t_start_14d_str))


### download data for each holder_enddate


i_hk = []
for d in unique_dates['s_holder_enddate'].tolist():        
    t_data = yu.get_sql_wind('''
                        select s_info_windcode as Ticker, s_holder_num, s_holder_quantity
                        from [WIND_PROD].[dbo].[SHSCMECHANISMOWNERSHIP] with (nolock)                        
                        where s_holder_enddate = '{0}' 
                        and ((s_info_windcode like '%SH') or (s_info_windcode like '%SZ'))
                        '''.format( d ))
    t_data['s_holder_enddate'] = pd.to_datetime(d,format='%Y%m%d')
    t_data = t_data.sort_values(['Ticker'])
    t_data['s_holder_quantity'] = t_data['s_holder_quantity'].astype('Int64')
    i_hk.append(t_data)
i_hk = pd.concat(i_hk, axis = 0)


### get holder-date mapping

i_hk_date = i_hk[['s_holder_enddate', 's_holder_num']].drop_duplicates()


### get close price and adj_factor

i_c = yu.get_sql_wind('''select substring(s_info_windcode,1,6) as Ticker, trade_dt,
                          s_dq_close as craw 
                          from wind_prod.dbo.ashareeodprices
                          where trade_dt > '{0}' '''.format(t_start_14d_str))
i_c['trade_dt'] = pd.to_datetime(i_c['trade_dt'], format = '%Y%m%d')


### float
                      
i_float = yu.get_sql_wind('''select substring(s_info_windcode,1,6) as Ticker, trade_dt,
                      FLOAT_A_SHR_TODAY*10000 as float
                      from wind_prod.dbo.ASHAREEODDERIVATIVEINDICATOR
                      where trade_dt > '{0}' '''.format(t_start_14d_str))
i_float['trade_dt'] = pd.to_datetime(i_float['trade_dt'], format = '%Y%m%d')





#------------------------------------------------------------------------------
### ---3--- query for a-share
#------------------------------------------------------------------------------



### calculate hk holding for each datadate


def get_hk_holding(dd):
        
    t0d_str = dd.strftime('%Y%m%d')
    #print(t0d_str, end=',')
    
    t1d = i_cal_2018onw.loc[i_cal_2018onw['DataDate'].eq(dd), 'T-1d'].iloc[0]
    t14d = t1d - pd.to_timedelta('14 days')
    t14d_str = t14d.strftime('%Y%m%d')
        
    # hk universe 
    
    i_hk_uni = yu.get_sql('''select Ticker FROM [CNDBPROD].[dbo].[UNIVERSE_HC] where datadate='{0}' 
                               '''.format(dd))
    i_hk_uni['flg_cndb_hk'] = 1
    
    # hk disclosure dates - most recent
    
    t_hk_date = i_hk_date[i_hk_date['s_holder_enddate'].lt(t0d_str) & i_hk_date['s_holder_enddate'].ge(t14d_str)]

    t_hk_date = t_hk_date.sort_values(['s_holder_num', 's_holder_enddate']).reset_index(drop = True)    
    t_hk_date_last1 = t_hk_date.groupby('s_holder_num')['s_holder_enddate'].max().reset_index()
        
    
    # get hk
    
    t_hk = i_hk[i_hk['s_holder_enddate'].lt(t0d_str) & i_hk['s_holder_enddate'].ge(t14d_str)]
    t_hk = t_hk.merge(t_hk_date_last1, on = ['s_holder_num', 's_holder_enddate'], how = 'inner')
    t_hk['hk_holder_type'] = t_hk['s_holder_num'].str[0]
    t_hk = t_hk[t_hk['hk_holder_type'].isin(['B', 'C'])]
    
    lst_bb = ['B01110', 'C00010', 'B01274', 'B01161', 'B01451', 'B01224']
    s_bb = t_hk[t_hk['s_holder_num'].isin(lst_bb)].groupby('Ticker')['s_holder_quantity'].sum().reset_index()
    s_bb = s_bb.rename(columns = {'s_holder_quantity': 'hk_shares'})
    s_bb['hk_holder_type'] = 'bb'
    s_bb = s_bb[['Ticker', 'hk_shares', 'hk_holder_type']]
    
    s_typ = t_hk.groupby(['Ticker','hk_holder_type'])['s_holder_quantity'].sum().reset_index()
    s_typ = s_typ.rename(columns = {'s_holder_quantity': 'hk_shares'})
    
    
    s_hk_agg = pd.concat([s_bb, s_typ], axis = 0)    
    s_hk_agg['Ticker'] = s_hk_agg['Ticker'].str[:6]    
    s_hk_agg = s_hk_agg.pivot_table(index = 'Ticker', columns = 'hk_holder_type', values = 'hk_shares')
    s_hk_agg = s_hk_agg.fillna(0)
    s_hk_agg = s_hk_agg[['B','C','bb']]
    s_hk_agg.columns = ['hk_b_shares', 'hk_c_shares', 'hk_bb_shares']
    s_hk_agg = s_hk_agg.reset_index(drop = False)
                
    
    # market close / float
    
    t_c = i_c[i_c['trade_dt'].eq(t1d)]
    t_c = t_c.drop(columns = ['trade_dt'])
    t_float = i_float[i_float['trade_dt'].eq(t1d)]
    t_float = t_float.drop(columns = ['trade_dt'])
                          
    
    # com
        
    tcom = s_hk_agg.merge(t_c, on = 'Ticker', how = 'left')
    tcom = tcom.merge(t_float, on = 'Ticker', how = 'left')
    tcom = tcom.merge(i_hk_uni, on = 'Ticker', how = 'left')
    tcom['DataDate'] = dd
    
    tcom.to_parquet('/dat/summit_capital/PROD/TZ/hk_holding/'+dd.strftime('%Y%m%d.parquet'))



for dd in dates_to_query:
    get_hk_holding(dd)


'''
if __name__ == '__main__':    
    with Pool(20) as p:
        p.map(get_hk_holding, dates_to_query)
'''

