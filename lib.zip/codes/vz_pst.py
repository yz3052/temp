﻿#$%^&* vz_pst.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  3 15:17:10 2023

@author: thzhang
"""

import pandas as pd
import numpy as np

import util as yu


### this proves where the position comes from


i_met = pd.read_excel('/dat/summit_capital/TZ/tmp/psteod20230203.xlsx')
i_met['Ticker'] = i_met['Security'].str[:6]
i_met = i_met.groupby('Ticker')[['Position','MV']].sum().reset_index()


i_tgt = yu.get_sql('''select  Ticker, opt_shr, opt_dollar 
                   from  cndbprod.dbo.SMTCN_POS_T2000_SLOW_TAR_FINAL
                   where DataDate = '2023-02-03' ''')
                   
                   
icom = i_met.merge(i_tgt, on = ['Ticker'], how = 'outer')
icom['opt_shr'] = icom['opt_shr'].fillna(0)
icom['Position'] = icom['Position'].fillna(0)

icom[['Position','opt_shr']].corr()



### show past performances of our pst (based on position table)
# pst * raw return 




startdt = '20220601'

i_pst = yu.get_sql('''(select  Ticker, DataDate, opt_shr  
                   from  cndbprod.dbo.SMTCN_POS_T2000_SLOW_TAR_FINAL
                   where DataDate>='{0}')
union
(select  Ticker, DataDate, opt_shr  
                   from  cndbprod.dbo.SMTCN_POS_T2000_SLOW_TAR_FINAL1
                   where DataDate>='{0}')
 '''.format(startdt))


i_cal = yu.get_cn_cal()
i_cal = pd.DataFrame(i_cal['TradeDate_next'].drop_duplicates().tolist(), columns = ['DataDate'])
i_cal = i_cal.sort_values('DataDate')
i_cal['DataDate_p1d'] = i_cal['DataDate'].shift(-1)


i_rawret = yu.get_sql_wind('''select s_info_windcode as Ticker, trade_dt as DataDate_p1d,  
                      s_dq_adjclose/s_dq_adjpreclose-1 as rawret, s_dq_adjclose as c, s_dq_close as craw 
                      from wind_prod.dbo.ashareeodprices
                      where trade_dt >= '{0}' '''.format(startdt))
i_rawret['DataDate_p1d'] = pd.to_datetime(i_rawret['DataDate_p1d'],format='%Y%m%d')
i_rawret['Ticker'] = i_rawret['Ticker'].str[:6]


icom = i_pst.merge(i_cal, on = 'DataDate', how = 'left')
icom = icom.merge(i_rawret, on = ['DataDate_p1d', 'Ticker'], how = 'left')

icom['ret_dollar'] = icom['opt_shr'] * icom['craw'] * icom['rawret']
icom['mv'] = icom['opt_shr'] * icom['craw']


icom.groupby('DataDate_p1d')['ret_dollar'].sum().cumsum().plot.bar()

icom.groupby('DataDate_p1d')[['ret_dollar','mv']].apply(lambda x: x['ret_dollar'].sum() / x['mv'].abs().sum() ).cumsum().plot()

t1 = icom.groupby('DataDate')['ret_dollar'].sum().cumsum()
t2 = icom.groupby('DataDa
te')['ret_dollar'].sum()










#------------------------------------------------------------------------------
### show past performances of our pst (based on FINAL table)
#------------------------------------------------------------------------------



import pandas as pd
import util as yu


startdt = '20230101'



i_sod_1 = yu.get_sql('''select  * from cndbprod.dbo.SMTCN_POS_T2000_SLOW_TAR_FINAL 
                   where datadate >= '{0}' '''.format(startdt))                   
i_sod_2 = yu.get_sql('''select  * from cndbprod.dbo.SMTCN_POS_T2000_SLOW_TAR_FINAL1 
                   where datadate >= '{0}' '''.format(startdt))                 
i_sod = pd.concat([i_sod_1, i_sod_2], axis = 0)                   
i_sod['pst'] = i_sod[[i for i in i_sod.columns if i[:7]=='opt_shr']].sum(axis = 1)


i_ret = yu.get_sql_wind('''select substring(s_info_windcode,1,6) as Ticker, trade_dt as DataDate,
                   s_dq_adjclose / s_dq_adjpreclose - 1 as rawret
                   from wind_prod.dbo.ashareeodprices
                   where trade_dt>='{0}' '''.format(startdt))
i_ret['DataDate'] = pd.to_datetime(i_ret['DataDate'], format='%Y%m%d')
              
i_sod = i_sod.merge(i_ret, on = ['Ticker','DataDate'], how='left')
i_sod['pnl'] = i_sod['rawret'] * i_sod['pst']


i_sod.groupby('DataDate')['pnl'].sum().cumsum().plot()

i_sod.groupby('DataDate')['pst'].apply(lambda x: x.abs().sum()).plot()
i_sod.groupby('DataDate')['pst'].apply(lambda x: x.sum()).plot()



#------------------------------------------------------------------------------
### show past performances of our pst (based on SOD table)
#------------------------------------------------------------------------------


import pandas as pd
import util as yu


startdt = '20230101'
i_sod_1 = yu.get_sql('''select  * from cndbprod.dbo.SMTCN_POS_T2000_SLOW_SOD
                   where datadate >= '{0}'
 '''.format(startdt))
i_sod_2 = yu.get_sql('''select  * from cndbprod.dbo.SMTCN_POS_T2000_SLOW_SOD1
                   where datadate >= '{0}' '''.format(startdt))
i_sod = pd.concat([i_sod_1,i_sod_2],axis=0)


i_sod['pst'] = i_sod[['SODShares_MS_HC', 'SODShares_MS_QFII', 'SODShares_JP_HC', 
                      'SODShares_JP_QFII', 'SODShares_ML_HC', 'SODShares_ML_QFII', 
                      'SODShares_CITI_HC', 'SODShares_UBS_HC', 'SODShares_UBS_QFII', 
                      'SODShares_GS_HC', 'SODShares_GS_QFII', 'SODShares_CITI_QFII']].sum(axis = 1)

i_ret = yu.get_sql_wind('''select substring(s_info_
windcode,1,6) as Ticker, trade_dt as DataDate,
                   s_dq_adjclose / s_dq_adjpreclose - 1 as rawret
                   from wind_prod.dbo.ashareeodprices
                   where trade_dt>='{0}' '''.format(startdt))
i_ret['DataDate'] = pd.to_datetime(i_ret['DataDate'], format='%Y%m%d')
              
i_sod = i_sod.merge(i_ret, on = ['Ticker','DataDate'], how='left')
i_sod['pnl'] = i_sod['rawret'] * i_sod['pst']


i_sod.groupby('DataDate')['pnl'].sum().cumsum().plot()
t1 = i_sod.groupby('DataDate')['pnl'].sum()
t1.mean() / t1.std() * np.sqrt(t1.count())


t1 = pd.read_csv('/dat/summit_capital/TZ/tmp/cnslow_ytd.csv')
t1['Ticker'] = t1['RIC'].str[:6]
t1['DataDate'] = pd.to_datetime(t1['RetDate'])
t1['pnl_outlook'] = t1['DTD TOTAL PNL']
t1 = t1.groupby(['Ticker', 'DataDate'])['pnl_outlook'].sum().reset_index()

i_sod = i_sod.merge(t1, on = ['Ticker','DataDate'], how = 'left')
i_sod[['pnl_outlook', 'pnl']].corr()


i_sod.groupby('DataDate')[['pnl','pnl_outlook']].sum().cumsum().plot()

i_sod.groupby('DataDate')[['pnl','pnl_outlook']].sum().cumsum().corr()

