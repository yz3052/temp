﻿#$%^&* ml_cn_linear_trailing_pnl_20221119.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 25 16:43:14 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import os
import gc

import util as yu
from sqlalchemy import create_engine
import urllib


conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))





### get ret


df_ret = pd.read_sql('''select  DataDate, Ticker, BarrRet_CLIP1d 
                         from CNDBPROD.dbo.BARRA_GEM3L_YRRET_CSI1800                         
                         '''.format(), conn)




### get universe


df_cd = pd.read_sql('''
                    select distinct TradeDate_next as DataDate
                    from CNDBPROD.dbo.Calendar_Dates_CN
                    where TradeDate_next >= '2015-01-01' 
                    ''',conn)
df_cd = df_cd.sort_values('DataDate')
df_cd = df_cd.reset_index(drop=True)
df_cd['T-1d'] = df_cd['DataDate'].shift(1)
df_cd['T-2d'] = df_cd['DataDate'].shift(2)
df_cd['DataDate_p1d'] = df_cd['DataDate'].shift(-1)
df_cd = df_cd.dropna()



df_universe_all = pd.read_sql('''
                        select DataDate as [T-1d], Ticker, avgPVadj_USD as avgPVadj, spread, 
                        cccny_vol_21d as [cc_vol_21d], SRISK
                        from CNDBPROD.dbo.universe_all_cn_gem3l 
                        '''.format(), conn)
df_universe_all = df_universe_all.drop_duplicates(subset=['Ticker','T-1d'],keep='last')
df_universe_1800 = pd.read_sql('''
                        select DataDate as [T-1d], Ticker 
                        from CNDBPROD.dbo.universe_csi1800
                        ''', conn)                        
df_universe_1800 = df_universe_1800.drop_duplicates(subset=['Ticker','T-1d'],keep='last')
df_universe = df_universe_1800.merge(df_universe_all, on = ['T-1d', 'Ticker'], how = 'left')
df_universe['clip'] = df_universe['avgPVadj'].apply(lambda x: min(1e6, x*0.01))
df_universe_all = None
df_universe_1800 = None
                        

                
df_universe = pd.merge(df_universe, df_cd, on=['T-1d'], how='inner')
df_universe = pd.merge(df_universe, df_ret, on=['DataDate', 'Ticker'], how='inner')
df_universe = df_universe.reset_index(drop=True)
df_cd = None
df_ret = None
gc.collect()






### get slow features 

root = '/export/dataprod/Feature_Pool_CN'
i_folders = os.li
stdir(root)
i_folders = [i for i in i_folders if 'smtprod_enrich_' in i ]

i_feature = []
for fd in i_folders:
    print(fd)
    t_feature = pd.concat([pd.read_parquet(os.path.join(root, fd, i)) for i in os.listdir(os.path.join(root, fd))], axis=0)
    t_feature = t_feature.drop_duplicates(subset=['Ticker','T-1d','DataDate'], keep='last')
    i_feature.append(t_feature)
    t_feature = None

i_all = pd.DataFrame(columns = ['Ticker', 'DataDate', 'T-1d'])
for ft in i_feature:
    i_all = i_all.merge(ft, on = ['Ticker', 'DataDate', 'T-1d'], how = 'outer')
    
i_feature = None
gc.collect()

cols_all = [i for i in i_all.columns.tolist() if not i in ['Ticker','DataDate','T-1d']]
cols_slow = [i for i in cols_all if '5d' not in i and '1d' not in i]

i_all_s2 = i_all[['Ticker','DataDate','T-1d']+cols_slow].merge(df_universe, on = ['T-1d', 'Ticker','DataDate'], how = 'inner')
i_all_s2['clip'] = i_all_s2['avgPVadj'].apply(lambda r: min([r*0.01,1e6]))
i_all_s2['wts'] = i_all_s2['clip']
i_all_s2= i_all_s2.dropna(subset = ['wts'])





### calc pnl, cov matrix, and signal

i_all_s3 = i_all_s2.sort_values(['Ticker', 'DataDate'])
i_all_s3['pnl_bc'] = i_all_s3['clip'] * 1e6 * i_all_s3['BarrRet_CLIP1d']



o_pst = []
o_w = []

dt_lst = i_all_s2['DataDate'].sort_values().drop_duplicates().tolist()

for d in range(486, len(dt_lst)):
    
    if dt_lst[d] >= pd.to_datetime('2018-01-01'):
        print(dt_lst[d].strftime('%Y%m%d'), end = ',')
    else:
        continue
    
    today = dt_lst[d]
    t_5d = dt_lst[d]
    
    valid_tk = i_all_s3.loc[i_all_s3['DataDate'].eq(today), 'Ticker'].tolist()
    
    t_all = i_all_s3[i_all_s3['DataDate'].le(t_5d) & i_all_s3['DataDate'].ge(t_5d - pd.to_timedelta('365 days'))]
    t_all = t_all[t_all['Ticker'].isin(valid_tk)]
        
    cols_sgnl = ['bar_t20d_orthgem3l_sgnl',
       'canc_t20d_orthgem3l_sgnl', 'cav_t20d_orthgem3l_sgnl',
       'act_t20d_orthgem3l_sgnl', 'd2m_t20d_orthgem3l_sgnl',
       'd3s_t20d_orthgem3l_sgnl', 'd60s_t20d_orthgem3l_sgnl', 'enft_sgnl',
       'enugdg_sgnl', 'gb_sgnl', 'jm_sgnl', 'lt_t20d_orthgem3l_sgnl',
       'st_t20d_orthgem3l_sgnl', 'nb_sgnl', 'pvar_t20d_orthgem3l_sgnl',
       'shsz_t20d_orthgem3l_sgnl']
    
    
    for f in cols_sgnl:
        t_all[f] = t_all[f] * t_all['clip'] * t_all['BarrRet_CLIP1d']
        t_all[f] = t_all[f].fillna(0)
        
    t_pnl = t_all.groupby('DataDate')[cols_sgnl].sum() 
    t_pnl = t_pnl.loc[:, (t_pnl!=0).any(axis=0)]
    
    t_pnl_cov = t_pnl.cov()
    t_pnl
_cov_inv = np.linalg.pinv(t_pnl_cov.values)
    t_pnl_mu = t_pnl.mean(axis=0)
    
    
    t_w = np.dot(t_pnl_cov_inv, t_pnl_mu.values.T)
    t_w[t_w<0] = 0
    t_w = t_w / np.sum(t_w)
    
    
    t_today = i_all_s3[i_all_s3['DataDate']==today]
    
    t_today_1 = t_today[['Ticker', 'DataDate']]
    t_today_2 = t_today[t_pnl_cov.columns.tolist()]
    t_today_2 = t_today_2.fillna(0)
    
    
    t_today_2_opt = np.dot(t_today_2.values, t_w)
    t_today_1['alpha_final'] = t_today_2_opt
    t_today_1['alpha_final_rk'] = yu.uniformed_rank(t_today_1['alpha_final'])
    
    t_w_dict = {t_pnl_mu.index.tolist()[i]:t_w[i] for i in range(len(t_w))}
    t_w_dict['DataDate'] = dt_lst[d]
    o_w.append(t_w_dict)
    o_pst.append(t_today_1)
    
o_pst = pd.concat(o_pst, axis = 0)

o_w = pd.DataFrame(o_w)


### show pnl

i_sd = yu.get_sd_cn_1800()
icom = i_sd.merge(o_pst, on = ['Ticker', 'DataDate'], how = 'inner')

o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2019-01-01', '2022-12-31')].\
            dropna(subset=['alpha_final_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'alpha_final_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)
    
o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2019-01-01', '2020-12-31') & icom['alpha_final_rk'].abs().gt(0.8)].\
            dropna(subset=['alpha_final_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'alpha_final_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)
