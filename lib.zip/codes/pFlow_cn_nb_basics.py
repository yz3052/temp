﻿#$%^&* pFlow_cn_nb_basics.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  5 16:42:11 2023

@author: thzhang
"""



import pandas as pd
import numpy as np

import datetime
import util as yu
import os


# this studies residual hk flow and correlation w.r.t. historical returns


# todo
# how to adjust holdings w.r.t. dividend shares?
    
# ideas:    
# hold large number but not in uni ... sell only
# after hong gu, hk holding will increase
# 


#---- sd 

i_sd = yu.get_sd_cn_1800()



#---- cal 

i_cal = yu.get_cn_cal()
i_cal = i_cal[['TradeDate_next']].sort_values('TradeDate_next').drop_duplicates()
i_cal = i_cal.rename(columns = {'TradeDate_next': 'DataDate'})
i_cal['T-1d'] = i_cal['DataDate'].shift()
i_cal = i_cal.dropna()




#---- hk uni 
#---- adj
# i_adj = yu.get_sql_wind('''
#                    select substring(s_info_windcode,1,6) as Ticker, trade_dt as [T-1d],
#                    s_dq_adjfactor as adj 
#                    from wind_prod.dbo.ashareeodprices
#                    ''')


#---- return and v

i_ret = yu.get_sql_wind('''select substring(s_info_windcode,1,6) as Ticker,
                   trade_dt as [T-1d], s_dq_close as c, s_dq_adjclose as cadj, 
                   s_dq_adjclose / s_dq_adjpreclose - 1 as rawret,
                   s_dq_volume*100 as v
                   from wind_prod.dbo.ashareeodprices
                   where trade_dt > '20180101'                   
                   ''')
i_ret['T-1d'] = pd.to_datetime(i_ret['T-1d'], format = '%Y%m%d')


#---- future return

i_futret = pd.read_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800.parquet')
i_futret = i_futret[['Ticker', 'DataDate']]

#---- o2c 

root = '/dat/summit_capital/TZ/PROD_FEATURES/featurepool_cn_desc_pv_reversal/'
files = os.listdir(root)
i_o2c = pd.concat([pd.read_parquet(root+f) for f in files], axis=0)

i_o2c = i_o2c.merge(i_cal, on = 'DataDate', how = 'left')
i_o2c = i_o2c.rename(columns = {'o2c_bret': 'o2c_bret+0d', 'DataDate': 'del', 'T-1d':'DataDate'})
i_o2c = i_o2c.drop(columns = ['del'])








#---- hk
# 'Ticker', 'hk_b_shares', 'hk_c_shares', 'hk_bb_shares', 'craw', 'float', 'flg_cndb_hk', 'DataDate'
root_hk = '/dat/summit_capital/PROD/TZ/hk_holding/'
files_hk = os.listdir(root_hk)
i_nb = pd.concat([pd.read_parquet(root_hk + f) for f in files_hk], axis = 0)
i_nb = i_nb.sort_values(['Ticker', 'DataDate']).reset_index(drop = True)
i_nb['hk_bb_diff'] = i_nb['hk_bb_shares'] - i_nb.groupby('Ticker')['hk_bb_shares
'].shift()
i_nb['hk_bb_diff_dv_so'] = i_nb['hk_bb_diff'] / i_nb['float']
i_nb['hk_bb_dv_so'] = i_nb['hk_bb_shares'] / i_nb['float']

i_nb['hk_c_diff'] = i_nb['hk_c_shares'] - i_nb.groupby('Ticker')['hk_c_shares'].shift()
i_nb['hk_c_diff_dv_so'] = i_nb['hk_c_diff'] / i_nb['float']
i_nb['hk_c_dv_so'] = i_nb['hk_c_shares'] / i_nb['float']

i_nb['hk_b_diff'] = i_nb['hk_b_shares'] - i_nb.groupby('Ticker')['hk_b_shares'].shift()
i_nb['hk_b_diff_dv_so'] = i_nb['hk_b_diff'] / i_nb['float']
i_nb['hk_b_dv_so'] = i_nb['hk_b_shares'] / i_nb['float']


# nb metrics - batch 1

i_nb_s2 = i_nb.merge(i_cal, on = 'DataDate', how = 'left')
i_nb_s2 = i_nb_s2.merge(i_ret[['Ticker', 'T-1d', 'rawret','v']], on = ['T-1d', 'Ticker'], how = 'left')
i_nb_s2 = i_nb_s2.sort_values(['Ticker', 'DataDate']).reset_index(drop = True)

t_corr = i_nb_s2.groupby('Ticker')[['rawret', 'hk_bb_diff_dv_so']].rolling(20,min_periods=15).corr()
i_nb_s2['corr_t1m'] = t_corr['rawret'].values.tolist()[1::2]
i_nb_s2['corr_t1m'] = i_nb_s2['corr_t1m'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
i_nb_s2.loc[i_nb_s2['corr_t1m']==0, 'corr_t1m'] = np.nan

i_nb_s2['hk_bb_dv_v'] = i_nb_s2['hk_bb_shares'] / i_nb_s2['v']









#---- test: hk_flow basics

i_nb_s3 = i_nb.groupby('DataDate')['hk_bb_shares'].apply(lambda x: x.abs().sum()).reset_index()
i_nb_s3.columns = ['DataDate', 'sum_abs_bb']

icom = i_sd.merge(i_nb_s2, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom.merge(i_o2c, on = ['DataDate', 'Ticker'], how = 'left')
icom = icom.merge(i_nb_s3, on = ['DataDate'], how = 'left')
icom = icom[icom['flg_cndb_hk']==1]
icom = icom.sort_values(['Ticker', 'DataDate'])


cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'DIVYILD', 
          'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
cols_i = [i for i in i_sd.columns.tolist() if i[:2]=='wd']
icom['ones'] = 1


icom['hk_bb_dv_so_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=20),on='DataDate',min_periods=10)['hk_bb_dv_so'].mean().values
icom['hk_bb_dv_so_t20d_rk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d'].apply(yu.uniformed_rank)
icom['hk_bb_dv_so_t20d_bk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['hk_bb_dv_so_t20d_orth'] = icom.groupby('DataDate')[cols_f+cols_i+['ones','hk_bb_dv_so_t20d']].apply(lambda x: yu.orthogonalize_cn_v3(x['hk_bb_dv_so_t20d'], x[cols_f], x[cols_i], x['ones'])).values
icom['hk_bb_dv_so_t20d_orth_bk'] = icom.groupby('DataDate')['hk_bb_dv_s
o_t20d_orth'].apply(lambda x: yu.pdqcut(x, bins=10)).values


icom['hk_bb_dv_v_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=20),on='DataDate',min_periods=10)['hk_bb_dv_v'].mean().values
icom['hk_bb_dv_v_t20d_rk'] = icom.groupby('DataDate')['hk_bb_dv_v_t20d'].apply(yu.uniformed_rank)
icom['hk_bb_dv_v_t20d_bk'] = icom.groupby('DataDate')['hk_bb_dv_v_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['hk_bb_dv_v_t20d_orth'] = icom.groupby('DataDate')[cols_f+cols_i+['ones','hk_bb_dv_v_t20d']].apply(lambda x: yu.orthogonalize_cn_v3(x['hk_bb_dv_v_t20d'], x[cols_f], x[cols_i], x['ones'])).values
icom['hk_bb_dv_v_t20d_orth_bk'] = icom.groupby('DataDate')['hk_bb_dv_v_t20d_orth'].apply(lambda x: yu.pdqcut(x, bins=10)).values


icom['hk_bb_dv_sumbb'] = icom['hk_bb_shares'] / icom['sum_abs_bb']
icom['hk_bb_dv_sumbb_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=20),on='DataDate',min_periods=10)['hk_bb_dv_sumbb'].mean().values
icom['hk_bb_dv_sumbb_t20d_rk'] = icom.groupby('DataDate')['hk_bb_dv_sumbb_t20d'].apply(yu.uniformed_rank)
icom['hk_bb_dv_sumbb_t20d_bk'] = icom.groupby('DataDate')['hk_bb_dv_sumbb_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['hk_bb_dv_sumbb_t20d_orth'] = icom.groupby('DataDate')[cols_f+cols_i+['ones','hk_bb_dv_sumbb_t20d']].apply(lambda x: yu.orthogonalize_cn_v3(x['hk_bb_dv_sumbb_t20d'], x[cols_f], x[cols_i], x['ones'])).values
icom['hk_bb_dv_sumbb_t20d_orth_bk'] = icom.groupby('DataDate')['hk_bb_dv_sumbb_t20d_orth'].apply(lambda x: yu.pdqcut(x, bins=10)).values


yu.create_cn_3x3_linux(icom, ['hk_bb_dv_so_t20d_orth_bk'], 'hk_bb_dv_so_t20d_orth') # less mono: -3.5 + 2 0
yu.create_cn_3x3_linux(icom, ['hk_bb_dv_v_t20d_orth_bk'], 'hk_bb_dv_v_t20d_orth') # random

yu.create_cn_3x3_linux(icom, ['hk_bb_dv_sumbb_t20d_bk'], 'hk_bb_dv_sumbb_t20d')  # -6 1 0
yu.create_cn_3x3_linux(icom, ['hk_bb_dv_sumbb_t20d_orth_bk'], 'hk_bb_dv_sumbb_t20d_orth') # 0 -1.5 +1 



icom['hk_bb_diff_dv_so_bk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3_linux(icom, ['hk_bb_diff_dv_so_bk'], 'hk_bb_diff_dv_so')  # 0.5 -3 +4
yu.create_cn_3x3_linux(icom, ['hk_bb_diff_dv_so_bk'], 'hk_bb_diff_dv_so', col_ret='BarrRet_CLIP_USD+0d') # -10 +17
yu.create_cn_3x3_linux(icom, ['hk_bb_diff_dv_so_bk'], 'hk_bb_diff_dv_so', col_ret='o2c_bret+0d') # +3 -0.5 +1 0




#---- test: hk_flow corr ret
# corr itself has no alpha

icom = i_sd.merge(i_nb_s2, on = ['Ticker', 'DataDate'
], how = 'left')
icom = icom[icom['DataDate'].le('2021-12-31')]
icom = icom.sort_values(['Ticker', 'DataDate'])

icom['corr_t1m_bk'] = icom.groupby('DataDate')['corr_t1m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom, ['corr_t1m_bk'], 'corr_t1m') # random


#---- test: hk_flow-ret corr + bret
# bret low + corr high -- no strong synergy

icom = i_sd.merge(i_nb_s2, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom[icom['flg_cndb_hk']==1]
icom = icom[icom['DataDate'].le('2021-12-31')]
icom = icom.sort_values(['Ticker', 'DataDate'])

icom['bret_t20d'] = icom.groupby('Ticker').rolling(20)['BarrRet_CLIP_USD-1d'].mean().values
icom['bret_t20d_rk'] = icom.groupby('DataDate')['bret_t20d'].apply(yu.uniformed_rank)
icom['bret_t20d_bk'] = icom.groupby('DataDate')['bret_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['corr_t1m_bk'] = icom.groupby('DataDate')['corr_t1m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom[icom['bret_t20d_rk']>0.6], ['corr_t1m_bk'], 'corr_t1m') # all negative 
yu.create_cn_3x3_linux(icom[icom['bret_t20d_rk']<-0.6], ['corr_t1m_bk'], 'corr_t1m') # +4 0 +4 -4

yu.create_cn_3x3_linux(icom, ['bret_t20d_bk'], 'bret_t20d') # mono: +6 -8
yu.create_cn_3x3_linux(icom[icom['corr_t1m_bk']<=7], ['bret_t20d_bk'], 'corr_t1m') # 
yu.create_cn_3x3_linux(icom[icom['corr_t1m_bk']==9], ['bret_t20d_bk'], 'corr_t1m') # 





#---- test: hk_flow + bret
# short only signals has high return

icom = i_sd.merge(i_nb, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom[icom['flg_cndb_hk']==1]
icom = icom[icom['DataDate'].le('2021-12-31')]
icom = icom.sort_values(['Ticker', 'DataDate'])

cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'DIVYILD', 
          'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
cols_i = [i for i in i_sd.columns.tolist() if i[:2]=='wd']
icom['ones'] = 1

icom['bret_t10d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=14),on='DataDate',min_periods=5)['BarrRet_CLIP_USD-1d'].mean().values
icom['bret_t10d_rk'] = icom.groupby('DataDate')['bret_t10d'].apply(yu.uniformed_rank)
icom['bret_t10d_bk'] = icom.groupby('DataDate')['bret_t10d'].apply(lambda x: yu.pdqcut(x, bins=10)).values

icom['bret_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=28),on='DataDate',min_periods=10)['BarrRet_CLIP_USD-1d'].mean().values
icom['bret_t20d_rk'] = icom.groupby('DataDate')['bret_t20d'].apply(yu.uniformed_rank)
icom['bret_t20d_bk'] = icom.groupby('DataDate'
)['bret_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values

icom['hk_bb_dv_so_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=28),on='DataDate',min_periods=10)['hk_bb_dv_so'].mean().values
icom['hk_bb_dv_so_t20d_rk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d'].apply(yu.uniformed_rank)
icom['hk_bb_dv_so_t20d_bk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['hk_bb_dv_so_t20d_orth'] = icom.groupby('DataDate')[cols_f+cols_i+['ones','hk_bb_dv_so_t20d']].apply(lambda x: yu.orthogonalize_cn_v3(x['hk_bb_dv_so_t20d'], x[cols_f], x[cols_i], x['ones'])).values
icom['hk_bb_dv_so_t20d_orth_bk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d_orth'].apply(lambda x: yu.pdqcut(x, bins=10)).values

icom['hk_bb_diff_dv_so_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=28),on='DataDate',min_periods=10)['hk_bb_diff_dv_so'].mean().values
icom['hk_bb_diff_dv_so_t20d_rk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so_t20d'].apply(yu.uniformed_rank)
icom['hk_bb_diff_dv_so_t20d_bk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['hk_bb_diff_dv_so_t20d_orth'] = icom.groupby('DataDate')[cols_f+cols_i+['ones','hk_bb_diff_dv_so_t20d']].apply(lambda x: yu.orthogonalize_cn_v3(x['hk_bb_diff_dv_so_t20d'], x[cols_f], x[cols_i], x['ones'])).values
icom['hk_bb_diff_dv_so_t20d_orth_bk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so_t20d_orth'].apply(lambda x: yu.pdqcut(x, bins=10)).values


yu.create_cn_3x3_linux(icom, ['hk_bb_dv_so_t20d_bk'], 'hk_bb_dv_so_t20d') # -6 +2 0
yu.create_cn_3x3_linux(icom, ['hk_bb_dv_so_t20d_orth_bk'], 'hk_bb_dv_so_t20d_orth') # -4 +2 0
yu.create_cn_3x3_linux(icom, ['hk_bb_diff_dv_so_t20d_bk'], 'hk_bb_diff_dv_so_t20d') # -1 -4 +5 +2
yu.create_cn_3x3_linux(icom, ['hk_bb_diff_dv_so_t20d_orth_bk'], 'hk_bb_diff_dv_so_t20d_orth') # -1 -4 +3
yu.create_cn_3x3_linux(icom[icom['hk_bb_dv_so_t20d_bk']==0], ['bret_t20d_bk'], 'bret_t20d') # -5 -20
yu.create_cn_3x3_linux(icom[icom['hk_bb_dv_so_t20d_bk']==9], ['bret_t20d_bk'], 'bret_t20d') # +2 -4
yu.create_cn_3x3_linux(icom[icom['hk_bb_diff_dv_so_t20d_bk']==0], ['bret_t20d_bk'], 'bret_t20d') # random
yu.create_cn_3x3_linux(icom[icom['hk_bb_diff_dv_so_t20d_bk']==9], ['bret_t20d_bk'], 'bret_t20d') # random +7 -6 +2



icom['sgnl1'] = np.nan
#icom.loc[icom['bret_t20d_bk'].eq(9) & icom['hk_bb_dv_so_t20d_bk'].eq(0), 'sgnl1'] = -1
icom.loc[icom['bret_t20d_rk'].ge(0.8) & icom['hk_bb_dv_so_t20d_
rk'].le(-0.8), 'sgnl1'] = -1
icom['sgnl1'] = icom.groupby('Ticker')['sgnl1'].ffill(5)
yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) 
# 2.1 / 1.6 / 1.0, 28%, but has some drawdowns
    
    


    
    
    
    
#---- test: hk_flow + bret + zigzag duration
# after adjusting holding period w.r.t zigzag, no big difference
    
i_zz = pd.read_parquet('/dat/summit_capital/TZ/tmp/pTA_cn_zigzag_featurepool7.parquet')
i_zz = i_zz[['Ticker', 'T-1d', 'seg_len_idx1', 'zz_curr_trend', 'seg_len_curr']]

icom = i_sd.merge(i_nb, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom.merge(i_zz, on = ['Ticker', 'T-1d'], how = 'left')
icom = icom[icom['flg_cndb_hk']==1]
icom = icom[icom['DataDate'].le('2021-12-31')]
icom = icom.sort_values(['Ticker', 'DataDate'])

cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'DIVYILD', 
          'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
cols_i = [i for i in i_sd.columns.tolist() if i[:2]=='wd']
icom['ones'] = 1
    
icom['bret_t10d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=14),on='DataDate',min_periods=5)['BarrRet_CLIP_USD-1d'].mean().values
icom['bret_t10d_rk'] = icom.groupby('DataDate')['bret_t10d'].apply(yu.uniformed_rank)
icom['bret_t10d_bk'] = icom.groupby('DataDate')['bret_t10d'].apply(lambda x: yu.pdqcut(x, bins=10)).values

icom['bret_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=28),on='DataDate',min_periods=10)['BarrRet_CLIP_USD-1d'].mean().values
icom['bret_t20d_rk'] = icom.groupby('DataDate')['bret_t20d'].apply(yu.uniformed_rank)
icom['bret_t20d_bk'] = icom.groupby('DataDate')['bret_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values

icom['hk_bb_dv_so_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=20),on='DataDate',min_periods=10)['hk_bb_dv_so'].mean().values
icom['hk_bb_dv_so_t20d_rk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d'].apply(yu.uniformed_rank)
icom['hk_bb_dv_so_t20d_bk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['hk_bb_dv_so_t20d_orth'] = icom.groupby('DataDate')[cols_f+cols_i+['ones','hk_bb_dv_so_t20d']].apply(lambda x: yu.orthogonalize_cn_v3(x['hk_bb_dv_so_t20d'], x[cols_f], x[cols_i], x['ones'])).values
icom['hk_bb_dv_so_t20d_orth_bk'] = icom.groupby('DataDate')['hk_bb_dv_so_t2
0d_orth'].apply(lambda x: yu.pdqcut(x, bins=10)).values


    
icom['sgnl1'] = np.nan
c1 = icom['zz_curr_trend'].eq(1) & icom['bret_t20d_rk'].ge(0.8) & icom['hk_bb_dv_so_t20d_rk'].le(-0.8)
icom.loc[c1, 'pulse1'] = -1
icom.loc[c1, 'pulse1_len'] = (icom.loc[c1, 'seg_len_curr']//2) * icom.loc[c1, 'pulse1']
icom.loc[icom['pulse1_len']>-20, 'pulse1_len'] = -20
icom['sgnl1'] = icom.groupby('Ticker')['pulse1_len'].apply(lambda x: pd.Series(yu.gen_sgnl_from_pulse(x.values)).to_frame()).values
yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) 
    #

icom[icom['sgnl1'].notnull()]['Ticker'].unique()
t1 = icom[icom['Ticker']=='600018']




#---- test: hk_flow + hk_holding
# when hk holding low, tickers with an outflow is even worse, so higher return
# when hk holding low, tickers with an inflow has no alpha
# when hk holding high, flow has no impact


icom = i_sd.merge(i_nb, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom[icom['flg_cndb_hk']==1]
icom = icom[icom['DataDate'].le('2021-12-31')]
icom = icom.sort_values(['Ticker', 'DataDate'])

cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'DIVYILD', 
          'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
cols_i = [i for i in i_sd.columns.tolist() if i[:2]=='wd']
icom['ones'] = 1

icom['bret_t10d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=14),on='DataDate',min_periods=5)['BarrRet_CLIP_USD-1d'].mean().values
icom['bret_t10d_rk'] = icom.groupby('DataDate')['bret_t10d'].apply(yu.uniformed_rank)
icom['bret_t10d_bk'] = icom.groupby('DataDate')['bret_t10d'].apply(lambda x: yu.pdqcut(x, bins=10)).values

icom['bret_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=28),on='DataDate',min_periods=10)['BarrRet_CLIP_USD-1d'].mean().values
icom['bret_t20d_rk'] = icom.groupby('DataDate')['bret_t20d'].apply(yu.uniformed_rank)
icom['bret_t20d_bk'] = icom.groupby('DataDate')['bret_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values

icom['hk_bb_dv_so_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=28),on='DataDate',min_periods=10)['hk_bb_dv_so'].mean().values
icom['hk_bb_dv_so_t20d_rk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d'].apply(yu.uniformed_rank)
icom['hk_bb_dv_so_t20d_bk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).
values
icom['hk_bb_dv_so_t20d_orth'] = icom.groupby('DataDate')[cols_f+cols_i+['ones','hk_bb_dv_so_t20d']].apply(lambda x: yu.orthogonalize_cn_v3(x['hk_bb_dv_so_t20d'], x[cols_f], x[cols_i], x['ones'])).values
icom['hk_bb_dv_so_t20d_orth_bk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d_orth'].apply(lambda x: yu.pdqcut(x, bins=10)).values

icom['hk_bb_diff_dv_so_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=28),on='DataDate',min_periods=10)['hk_bb_diff_dv_so'].mean().values
icom['hk_bb_diff_dv_so_t20d_rk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so_t20d'].apply(yu.uniformed_rank)
icom['hk_bb_diff_dv_so_t20d_bk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['hk_bb_diff_dv_so_t20d_orth'] = icom.groupby('DataDate')[cols_f+cols_i+['ones','hk_bb_diff_dv_so_t20d']].apply(lambda x: yu.orthogonalize_cn_v3(x['hk_bb_diff_dv_so_t20d'], x[cols_f], x[cols_i], x['ones'])).values
icom['hk_bb_diff_dv_so_t20d_orth_bk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so_t20d_orth'].apply(lambda x: yu.pdqcut(x, bins=10)).values


yu.create_cn_3x3_linux(icom[icom['hk_bb_dv_so_t20d_bk']==0], ['hk_bb_diff_dv_so_t20d_bk'], 'hk_bb_diff_dv_so_t20d') # -25 +18
yu.create_cn_3x3_linux(icom[icom['hk_bb_dv_so_t20d_bk']==1], ['hk_bb_diff_dv_so_t20d_bk'], 'hk_bb_diff_dv_so_t20d') # 0 -15 +10 0
yu.create_cn_3x3_linux(icom[icom['hk_bb_dv_so_t20d_bk']==2], ['hk_bb_diff_dv_so_t20d_bk'], 'hk_bb_diff_dv_so_t20d') # -6 2 -2
yu.create_cn_3x3_linux(icom[icom['hk_bb_dv_so_t20d_bk']<=3], ['hk_bb_diff_dv_so_t20d_bk'], 'hk_bb_diff_dv_so_t20d') # -7 +6 +3

yu.create_cn_3x3_linux(icom[icom['hk_bb_dv_so_t20d_bk']==8], ['hk_bb_diff_dv_so_t20d_bk'], 'hk_bb_diff_dv_so_t20d') # random
yu.create_cn_3x3_linux(icom[icom['hk_bb_dv_so_t20d_bk']==9], ['hk_bb_diff_dv_so_t20d_bk'], 'hk_bb_diff_dv_so_t20d') # random


icom['sgnl_bchmrk'] = np.nan
c1 = icom['hk_bb_dv_so_t20d_bk'].lt(3)
icom.loc[c1, 'sgnl_bchmrk'] = -1

yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl_bchmrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl_bchmrk','BarrRet_CLIP_USD+1d', static_data = i_sd) 
# 3.64 / 2.6 / -0.68, 8% gmvret

    

icom['sgnl1'] = np.nan
c1 = icom['hk_bb_dv_so_t20d_bk'].lt(3) & icom['hk_bb_diff_dv_so_t20d_bk'].eq(0)
icom.loc[c1, 'sgnl1'] = -1
c1 = icom['hk_bb_diff_dv_so_t20d_bk'].eq(9)
c2 = icom['bret_t20d_bk'].eq(0)
icom.loc[c1 | c2, 'sgnl1'] = 0

icom['sgnl1'] = icom.groupby('Ticker')['sgnl1'].ffill(limit=60)

yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) 
# 3.25 / 2.43 / 1.0, 17% gmvret


icom['sgnl2'] = np.nan
c1 = icom['hk_bb_dv_so_t20d_bk'].lt(3) & icom['hk_bb_diff_dv_so_t20d_bk'].eq(9)
icom.loc[c1, 'sgnl2'] = 1
icom['sgnl2'] = icom.groupby('Ticker')['sgnl2'].ffill(limit=20)

yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) 




    
#---- test: hk_flow + bret + zigzag height
# after adjusting holding period w.r.t zigzag, no big difference
    
i_zz = pd.read_parquet('/dat/summit_capital/TZ/tmp/pTA_cn_zigzag_featurepool7.parquet')
i_zz = i_zz[['Ticker', 'T-1d', 'seg_len_idx1', 'zz_curr_trend', 'seg_len_curr',
             'zz_vertex_1', 'zz_vertex_2', 'c']]

icom = i_sd.merge(i_nb, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom.merge(i_zz, on = ['Ticker', 'T-1d'], how = 'left')
icom = icom[icom['flg_cndb_hk']==1]
icom = icom[icom['DataDate'].le('2021-12-31')]
icom = icom.sort_values(['Ticker', 'DataDate'])

cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'DIVYILD', 
          'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
cols_i = [i for i in i_sd.columns.tolist() if i[:2]=='wd']
icom['ones'] = 1
    
icom['bret_t10d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=14),on='DataDate',min_periods=5)['BarrRet_CLIP_USD-1d'].mean().values
icom['bret_t10d_rk'] = icom.groupby('DataDate')['bret_t10d'].apply(yu.uniformed_rank)
icom['bret_t10d_bk'] = icom.groupby('DataDate')['bret_t10d'].apply(lambda x: yu.pdqcut(x, bins=10)).values

icom['bret_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=28),on='DataDate',min_periods=10)['BarrRet_CLIP_USD-1d'].mean().values
icom['bret_t20d_rk'] = icom.groupby('DataDate')['bret_t20d'].apply(yu.uniformed_rank)
icom['bret_t20d_bk'] = icom.groupby('DataDate')['bret_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values

icom['hk_bb_dv_so_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=20),on='DataDate',min_periods=10)['hk_bb_dv_so'].mean().values
icom['hk_bb_dv_so_t20d_rk'] = icom.groupby('DataDate')['hk_bb_dv_
so_t20d'].apply(yu.uniformed_rank)
icom['hk_bb_dv_so_t20d_bk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['hk_bb_dv_so_t20d_orth'] = icom.groupby('DataDate')[cols_f+cols_i+['ones','hk_bb_dv_so_t20d']].apply(lambda x: yu.orthogonalize_cn_v3(x['hk_bb_dv_so_t20d'], x[cols_f], x[cols_i], x['ones'])).values
icom['hk_bb_dv_so_t20d_orth_bk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d_orth'].apply(lambda x: yu.pdqcut(x, bins=10)).values


    
icom['sgnl1'] = np.nan
c1 = icom['zz_curr_trend'].eq(1) & icom['bret_t20d_rk'].ge(0.8) & icom['hk_bb_dv_so_t20d_rk'].le(-0.8)
icom.loc[c1, 'sgnl1'] = -1
icom['breakeven'] = icom['zz_vertex_1']*0.5 + icom['zz_vertex_2']*0.5
c2 = icom['zz_curr_trend'].eq(-1) & icom['c'].lt(icom['breakeven'])
icom.loc[c2, 'sgnl1'] = 0
icom['sgnl1'] = icom.groupby('Ticker')['sgnl1'].ffill(limit=10)
yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.7 / 2.2 / 1.6 / 35%



icom['sgnl1'] = np.nan
icom.loc[icom['bret_t20d_rk'].ge(0.8) & icom['hk_bb_dv_so_t20d_rk'].le(-0.8), 'sgnl1'] = -1
icom['sgnl1'] = icom.groupby('Ticker')['sgnl1'].ffill(10)
yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.9 / 2.4 / 1.6 / 31.6%

    
    
    
    

#---- test: B vs C
# bc and bbc almost the same
# b vs bb no alpha
# std of flow from bb and c has some alpha, but very weak


icom = i_sd.merge(i_nb_s2, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom[icom['flg_cndb_hk']==1]
icom = icom.sort_values(['Ticker', 'DataDate'])

cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'DIVYILD', 
          'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
cols_i = [i for i in i_sd.columns.tolist() if i[:2]=='wd']
icom['ones'] = 1

icom['hk_bb_dv_so_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=20),on='DataDate',min_periods=10)['hk_bb_dv_so'].mean().values
icom['hk_bb_dv_so_t20d_rk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d'].apply(yu.uniformed_rank)
icom['hk_bb_dv_so_t20d_bk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['hk_bb_dv_so_
t20d_orth'] = icom.groupby('DataDate')[cols_f+cols_i+['ones','hk_bb_dv_so_t20d']].apply(lambda x: yu.orthogonalize_cn_v3(x['hk_bb_dv_so_t20d'], x[cols_f], x[cols_i], x['ones'])).values
icom['hk_bb_dv_so_t20d_orth_rk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d_orth'].apply(yu.uniformed_rank)
icom['hk_bb_dv_so_t20d_orth_bk'] = icom.groupby('DataDate')['hk_bb_dv_so_t20d_orth'].apply(lambda x: yu.pdqcut(x, bins=10)).values

icom['hk_c_dv_so'] = icom['hk_c_shares'] / icom['float']
icom['hk_c_dv_so_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=20),on='DataDate',min_periods=10)['hk_c_dv_so'].mean().values
icom['hk_c_dv_so_t20d_rk'] = icom.groupby('DataDate')['hk_c_dv_so_t20d'].apply(yu.uniformed_rank)
icom['hk_c_dv_so_t20d_bk'] = icom.groupby('DataDate')['hk_c_dv_so_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['hk_c_dv_so_t20d_orth'] = icom.groupby('DataDate')[cols_f+cols_i+['ones','hk_c_dv_so_t20d']].apply(lambda x: yu.orthogonalize_cn_v3(x['hk_c_dv_so_t20d'], x[cols_f], x[cols_i], x['ones'])).values
icom['hk_c_dv_so_t20d_orth_rk'] = icom.groupby('DataDate')['hk_c_dv_so_t20d_orth'].apply(yu.uniformed_rank)
icom['hk_c_dv_so_t20d_orth_bk'] = icom.groupby('DataDate')['hk_c_dv_so_t20d_orth'].apply(lambda x: yu.pdqcut(x, bins=10)).values


icom['hk_b_dv_so'] = icom['hk_b_shares'] / icom['float']
icom['hk_b_dv_so_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=20),on='DataDate',min_periods=10)['hk_b_dv_so'].mean().values
icom['hk_b_dv_so_t20d_rk'] = icom.groupby('DataDate')['hk_b_dv_so_t20d'].apply(yu.uniformed_rank)
icom['hk_b_dv_so_t20d_bk'] = icom.groupby('DataDate')['hk_b_dv_so_t20d'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['hk_b_dv_so_t20d_orth'] = icom.groupby('DataDate')[cols_f+cols_i+['ones','hk_b_dv_so_t20d']].apply(lambda x: yu.orthogonalize_cn_v3(x['hk_b_dv_so_t20d'], x[cols_f], x[cols_i], x['ones'])).values
icom['hk_b_dv_so_t20d_orth_rk'] = icom.groupby('DataDate')['hk_b_dv_so_t20d_orth'].apply(yu.uniformed_rank)
icom['hk_b_dv_so_t20d_orth_bk'] = icom.groupby('DataDate')['hk_b_dv_so_t20d_orth'].apply(lambda x: yu.pdqcut(x, bins=10)).values


icom['bbc_diff'] = icom['hk_bb_dv_so_t20d_rk'] - icom['hk_c_dv_so_t20d_rk']
icom['bbc_diff_rk'] = icom.groupby('DataDate')['bbc_diff'].apply(yu.uniformed_rank)
icom['bbc_diff_bk'] = icom.groupby('DataDate')['bbc_diff'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['bbc_orth_diff'] = icom['hk_bb_dv_so_t20d_orth_rk'] - icom['hk_c_dv_so_t20d_orth_rk']
icom[
'bbc_orth_diff_bk'] = icom.groupby('DataDate')['bbc_orth_diff'].apply(lambda x: yu.pdqcut(x, bins=10)).values

yu.create_cn_3x3_linux(icom, ['bbc_diff_bk'], 'bbc_diff') # mono: -4.5 +4
yu.create_cn_3x3_linux(icom, ['bbc_orth_diff_bk'], 'bbc_orth_diff') # less mono
yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-01-01', '2021-12-31') ].\
            dropna(subset=['bbc_diff_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'bbc_diff_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)
# 3.48 / 2.3 / 0.8
# 40% corr with bb_dv_so signal



icom['bbb_diff'] = icom['hk_bb_dv_so_t20d_rk'] - icom['hk_b_dv_so_t20d_rk']
icom['bbb_diff_rk'] = icom.groupby('DataDate')['bbb_diff'].apply(yu.uniformed_rank)
icom['bbb_diff_bk'] = icom.groupby('DataDate')['bbb_diff'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['bbb_orth_diff'] = icom['hk_bb_dv_so_t20d_orth_rk'] - icom['hk_b_dv_so_t20d_orth_rk']
icom['bbb_orth_diff_bk'] = icom.groupby('DataDate')['bbb_orth_diff'].apply(lambda x: yu.pdqcut(x, bins=10)).values

yu.create_cn_3x3_linux(icom, ['bbb_diff_bk'], 'bbb_diff') # -random
yu.create_cn_3x3_linux(icom, ['bbb_orth_diff_bk'], 'bbb_orth_diff') # +1 +3 -2



icom['bc_diff'] = icom['hk_b_dv_so_t20d_rk'] - icom['hk_c_dv_so_t20d_rk']
icom['bc_diff_rk'] = icom.groupby('DataDate')['bc_diff'].apply(yu.uniformed_rank)
icom['bc_diff_bk'] = icom.groupby('DataDate')['bc_diff'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['bc_orth_diff'] = icom['hk_b_dv_so_t20d_orth_rk'] - icom['hk_c_dv_so_t20d_orth_rk']
icom['bc_orth_diff_bk'] = icom.groupby('DataDate')['bc_orth_diff'].apply(lambda x: yu.pdqcut(x, bins=10)).values

yu.create_cn_3x3_linux(icom, ['bc_diff_bk'], 'bc_diff') # mono -5 +3
yu.create_cn_3x3_linux(icom, ['bc_orth_diff_bk'], 'bc_orth_diff') # mono -3 +3



icom['hk_bb_dv_so_sd20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=20),on='DataDate',min_periods=10)['hk_bb_dv_so'].std().values
icom['hk_bb_dv_so_sd20d_rk'] = icom.groupby('DataDate')['hk_bb_dv_so_sd20d'].apply(yu.uniformed_rank)
icom['hk_c_dv_so_sd20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=20),on='DataDate',min_periods=10)['hk_c_dv_so'].std().values
icom['hk_c_dv_so_sd20d_rk'] = icom.groupby('DataDate')['hk_c_dv_so_sd20d'].apply(yu.uniformed_rank)

icom['bbc_std_diff'] = icom['hk_bb_dv_so_sd20d_rk'] - icom['hk_c_dv_so_sd20d_rk']
icom['bbc_std_diff_rk'] = icom.groupby('DataDate')['bbc_std_diff'].apply(yu.uniformed_rank)
icom['bbc_std_diff_b
k'] = icom.groupby('DataDate')['bbc_std_diff'].apply(lambda x: yu.pdqcut(x, bins=10)).values

yu.create_cn_3x3_linux(icom, ['bbc_std_diff_bk'], 'bbc_std_diff') # mono: -3 +3
yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-01-01', '2021-12-31') ].\
            dropna(subset=['bbc_std_diff_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'bbc_std_diff_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)
# 2.39 / -0.78 / -3.56






    
#---- test: hk holding - regular hk_flow


icom = i_sd.merge(i_nb, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom[icom['DataDate'].le('2021-12-31')]
icom = icom.sort_values(['Ticker', 'DataDate'])

(icom['hk_bb_diff_dv_so'].abs() / icom['hk_bb_dv_so']).replace(-np.inf,np.nan).replace(np.inf,np.nan).hist(bins=100)

(icom['hk_bb_diff_dv_so'].abs() / icom['hk_bb_dv_so']).quantile(0.25)

cols_barra = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'DIVYILD', 
              'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
for c in cols_barra:
    icom[c+'_exp'] = icom['hk_bb_shares']*icom['craw']*icom[c]
    
cols_wd = [c for c in i_sd.columns.tolist() if 'wd' in c]
for c in cols_wd:
    icom[c+'_exp'] = icom['hk_bb_shares']*icom['craw']*icom[c]

t1 = icom.groupby('DataDate')[[c+'_exp' for c in cols_wd]+['hk']].sum()
t1 = t1[[c+'_exp' for c in cols_wd]].divide(t1['hk'], axis=0)
icom['hk'] = icom['hk_bb_shares']*icom['craw']
t2 = icom.groupby('DataDate')['hk'].sum()
    




#---- test: hk modest holding + strong inflow

icom = i_sd.merge(i_nb, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom[icom['DataDate'].le('2021-12-31')]
icom = icom.sort_values(['Ticker', 'DataDate'])



icom['hk_bb_dv_so_rk'] = icom.groupby('DataDate')['hk_bb_dv_so'].apply(yu.uniformed_rank)

icom['hk_bb_dollar'] = icom['hk_bb_diff'] * icom['craw']
icom['hk_bb_dollar_t2d'] = icom.groupby('Ticker').rolling(2)['hk_bb_dollar'].mean().values
icom['hk_bb_dollar_t2d_rk'] = icom.groupby('DataDate')['hk_bb_dollar_t2d'].apply(yu.uniformed_rank)
icom['hk_bb_dollar_t3d'] = icom.groupby('Ticker').rolling(3)['hk_bb_dollar'].mean().values
icom['hk_bb_dollar_t3d_3d'] = icom.groupby('Ticker')['hk_bb_dollar_t3d'].shift(3)
icom['hk_bb_dollar_t3d_3d_rk'] = icom.groupby('DataDate')['hk_bb_dollar_t3d_3d'].apply(yu.uniformed_rank)

icom['hk_bb_diff_dv_so_t2d'] = icom.groupby('Ticker').rolling(2)['hk_bb_diff_dv_so'].mean().values
icom['hk_bb_diff_dv_so_t2d_rk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so_t2d'].apply(yu.uni
formed_rank)
icom['hk_bb_diff_dv_so_t3d'] = icom.groupby('Ticker').rolling(3)['hk_bb_diff_dv_so'].mean().values
icom['hk_bb_diff_dv_so_t3d_3d'] = icom.groupby('Ticker')['hk_bb_diff_dv_so_t3d'].shift(3)
icom['hk_bb_diff_dv_so_t3d_3d_rk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so_t3d_3d'].apply(yu.uniformed_rank)

icom['sgnl1'] = np.nan
c1 = icom['hk_bb_dv_so_rk'].between(0, 0.8) & icom['hk_bb_diff_dv_so_t2d_rk'].gt(0.8)\
     & icom['hk_bb_diff_dv_so_t3d_3d_rk'].gt(0.8)
icom.loc[c1, 'sgnl1'] = 1
icom['sgnl1'] = icom.groupby('Ticker')['sgnl1'].ffill(limit=4)

yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.2/-0.8


icom['sgnl2'] = np.nan
c1 = icom['hk_bb_dv_so_rk'].between(0, 0.8) & icom['hk_bb_dollar_t2d_rk'].gt(0.8)\
     & icom['hk_bb_dollar_t3d_3d_rk'].gt(0.8)
icom.loc[c1, 'sgnl2'] = 1
icom['sgnl2'] = icom.groupby('Ticker')['sgnl2'].ffill(limit=4)

yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.6/-2




    
#---- test: hk_flow vs large trade

i_lt = yu.get_sql('''select *
                    FROM [CNDBPROD].[dbo].[F001_LT_CN_FORMAT] where datadate = '20230410' ''')
