﻿#$%^&* pL2_cn_trod_twap_vwap_crossover.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue May 10 10:21:45 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime




### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])




### get data

i_tv_cross = yu.get_q('get `:/export/datadev/Data/SHSZ/TROD_metrics/trod_twap_vwap_crossover')

i_tv_cross['code'] = i_tv_cross['code'].str.decode('utf8')
c_sh = i_tv_cross['code'].str[0].isin(['6'])
c_sz = i_tv_cross['code'].str[0].isin(['0','3'])
i_tv_cross.loc[c_sh, 'ticker'] = i_tv_cross.loc[c_sh, 'code'] + '.SH'
i_tv_cross.loc[c_sz, 'ticker'] = i_tv_cross.loc[c_sz, 'code'] + '.SZ'
i_tv_cross['datadate'] = pd.to_datetime(i_tv_cross['date'])
i_tv_cross = i_tv_cross.sort_values(['ticker', 'datadate'])



### o_c return


# get o_c_ret

i_o_c_ret = pw.get_wind_mkt_data(col_list = ['ticker', 'datadate', 'adjret_o_c'])
i_o_c_ret = i_o_c_ret.sort_values(['ticker', 'datadate'])

i_o_c_ret['adjret_o_c_t20d'] = i_o_c_ret.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['adjret_o_c'].sum().values
i_o_c_ret['adjret_o_c_t40d'] = i_o_c_ret.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['adjret_o_c'].sum().values




### combine 

icom = i_sd.merge(i_tv_cross, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_o_c_ret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])



### cross + o2c as events

icom['adjret_o_c_t20d_rk'] = icom.groupby('datadate')['adjret_o_c_t20d'].apply(yu.uniformed_rank)

icom['flag_cross_sharp'] = np.nan
c1 = (icom['t_lt_v_am'].divide(icom['tv_cnt_am']) > 0.8) \
     & (icom['t_gt_v_pm'].divide(icom['tv_cnt_pm']) > 0.8) \
     & (icom['t_m_v_last_pm'] > 0) \
     & (icom['p_last_pm'] - icom['vwap_last_pm'] > 0.01)
icom.loc[c1, 'flag_cross_sharp'] = 1

c2 = (icom['adjret_o_c_t20d_rk']<-0.8) & (icom['flag_cross_sharp']==1)
icom.loc[c2, 'flag_cross_sharp_o2c'] = 1
icom['flag_cross_sharp_o2c'] = icom.groupby('ticker')['flag_cross_sharp_o2c'].ffill(limit = 100)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['flag_cross_sharp_o2c','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flag_cross_sharp_o2c','BarrRet_CLIP_USD+1d', static_data = i_sd) # not working





### cross as events


icom['flag_cross'] = np.nan
c1 = (icom['t_lt_v_am'].di
vide(icom['tv_cnt_am']) > 0.8) \
     & (icom['t_gt_v_pm'].divide(icom['tv_cnt_pm']) > 0.8) \
     & (icom['t_m_v_last_pm'] > 0)
icom.loc[c1, 'flag_cross'] = 1
c2 = (icom['t_gt_v_am'].divide(icom['tv_cnt_am']) > 0.8) \
     & (icom['t_lt_v_pm'].divide(icom['tv_cnt_pm']) > 0.8) \
     & (icom['t_m_v_last_pm'] < 0)
icom.loc[c2, 'flag_cross'] = -1

icom['flag_cross_sharp'] = np.nan
c1 = (icom['t_lt_v_am'].divide(icom['tv_cnt_am']) > 0.8) \
     & (icom['t_gt_v_pm'].divide(icom['tv_cnt_pm']) > 0.8) \
     & (icom['t_m_v_last_pm'] > 0) \
     & (icom['p_last_pm'] - icom['vwap_last_pm'] > 0.01)
icom.loc[c1, 'flag_cross_sharp'] = 1




icom['sgnl_cross_up'] = np.nan
icom['sgnl_cross_up'] = icom.groupby('ticker')['flag_cross'].ffill(limit = 5)
icom.loc[icom['sgnl_cross_up']<0, 'sgnl_cross_up'] = np.nan

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_cross_up','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_cross_up','BarrRet_CLIP_USD+1d', static_data = i_sd) # -0.26 / -3.51


icom['sgnl_cross_dn'] = np.nan
icom['sgnl_cross_dn'] = icom.groupby('ticker')['flag_cross'].ffill(limit = 5)
icom.loc[icom['sgnl_cross_dn']>0, 'sgnl_cross_dn'] = np.nan

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_cross_dn','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_cross_dn','BarrRet_CLIP_USD+1d', static_data = i_sd) # -0.67/-4.77


icom['sgnl_cross_sharp_up'] = np.nan
icom['sgnl_cross_sharp_up'] = icom.groupby('ticker')['flag_cross_sharp'].ffill(limit = 60)
icom.loc[icom['sgnl_cross_sharp_up']<0, 'sgnl_cross_sharp_up'] = np.nan

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_cross_sharp_up','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_cross_sharp_up','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.68 / -1.3






### number of cross over the past 3m 

icom['cross_up_cnt_t60d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=91),on='datadate')['flag_cross'].apply(lambda x: (x>0).sum()).values
icom['cross_up_cnt_t60d_bk'] = icom.groupby('datadate')['cross_up_cnt_t60d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['cross_up_cnt_t60d_bk'], 'cross_up_cnt_t60d') # 



