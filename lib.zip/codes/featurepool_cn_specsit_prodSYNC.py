﻿#$%^&* featurepool_cn_specsit_prodSYNC.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec 29 09:06:52 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import os

import datetime

from sqlalchemy import create_engine
import urllib
import pyodbc



#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------


save_path = '/dat/summit_capital/TZ/PROD_FEATURES_MINOR/featurepool_cn_desc_specsit'


conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
conn_wind = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=WIND_PROD;UID=svc_wind_dbo;PWD=DusONA3Habredl;TDS_Version=8.0;')

today = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
today = pd.to_datetime(today.date())
today_str = today.strftime('%Y%m%d')





#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------


i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()



#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------



dates_to_query = i_cal['DataDate'].dt.strftime('%Y%m%d.parquet').drop_duplicates().tolist()
dates_to_query = [d for d in dates_to_query if (d>='20170101.parquet') and (d<today.strftime('%Y%m%d.parquet'))]

existing_dates = os.listdir(save_path)

dates_to_query = [d for d in dates_to_query if d not in existing_dates]





#------------------------------------------------------------------------------
### metrics
#------------------------------------------------------------------------------

for i  in dates_to_query:

    # dates
    
    t_1d = pd.to_datetime(i, format='%Y%m%d.parquet')    
    t_1d_str = t_1d.strftime('%Y%m%d')
    t_182d_str = (t_1d - pd.to_timedelta('182 days')).strftime('%Y%m%d')    
    t_0d_str = i_cal.loc[i_c
al['T-1d']==t_1d, 'DataDate'].dt.strftime('%Y-%m-%d').iloc[0]
    t_7d_str = (t_1d - pd.to_timedelta('7 days')).strftime('%Y%m%d')
    t_30d_str = (t_1d - pd.to_timedelta('30 days')).strftime('%Y%m%d')
    t_182d_str = (t_1d - pd.to_timedelta('182 days')).strftime('%Y%m%d')
    t_365d_str = (t_1d - pd.to_timedelta('365 days')).strftime('%Y%m%d')
    
    
    
    ### date ticker mapping
    
    i_dtk = pd.read_sql('''select datadate as [T-1d], ticker as Ticker 
                        from cndbprod.dbo.universe_all_cn_gem3l 
                        with (nolock)
                        where datadate = '{0}'
                        '''.format(t_1d_str), conn)
    i_dtk = i_dtk.drop_duplicates(subset = ['T-1d', 'Ticker'], keep = 'last')
    
    
    
    ### days since ipo
    
    i_ipo_date = pd.read_sql('''select s_info_windcode as Ticker, min(trade_dt) as ipo_date 
                           from wind_prod.dbo.ashareeodprices  with (nolock)
                           group by s_info_windcode''', conn_wind)
    i_ipo_date['ipo_date'] = pd.to_datetime(i_ipo_date['ipo_date'], format = '%Y%m%d')
    i_ipo_date['Ticker'] = i_ipo_date['Ticker'].str[:6]
    
    
    ###??? suspension type data is available. perhaps more details here?
    
    ### has trading suspension 
    
    i_sus_1d = pd.read_sql('''select distinct s_info_windcode as Ticker 
                           from wind_prod.dbo.ASHAREEODPRICES  with (nolock)
                           where S_DQ_TRADESTATUScode = 0 
                           and trade_dt = '{0}' '''.format(t_1d_str), conn_wind)
    i_sus_1d['Ticker'] = i_sus_1d['Ticker'].str[:6]
    i_sus_1d['flg_has_sus_1d_sgnl'] = 1
    i_sus_1d = i_sus_1d[['Ticker', 'flg_has_sus_1d_sgnl']]
    
    i_sus_7d = pd.read_sql('''select distinct s_info_windcode as Ticker  
                           from wind_prod.dbo.ASHAREEODPRICES 
                           where S_DQ_TRADESTATUScode = 0 
                           and trade_dt <= '{0}'
                           and trade_dt >= '{1}' '''.format(t_1d_str,t_7d_str), conn_wind)
    i_sus_7d['Ticker'] = i_sus_7d['Ticker'].str[:6]
    i_sus_7d['flg_has_sus_7d_sgnl'] = 1    
    i_sus_7d = i_sus_7d[['Ticker', 'flg_has_sus_7d_sgnl']]
    
    i_sus_182d = pd.read_sql('''select s_info_windcode as Ticker, count(*) as cnt_182d   
                           from wind_prod.dbo.ASHAREEODPRICES 
                           where S_DQ_TRADESTATUScode = 0 
                           and trade_dt <= '{0}'
 
                          and trade_dt >= '{1}' 
                           group by s_info_windcode '''.format(t_1d_str,t_182d_str), conn_wind)
    i_sus_182d['Ticker'] = i_sus_182d['Ticker'].str[:6]
    i_sus_182d.loc[i_sus_182d['cnt_182d'].ge(5), 'flg_has_sus_182d_ge5_sgnl'] = 1
    i_sus_182d.loc[i_sus_182d['cnt_182d'].ge(20), 'flg_has_sus_182d_ge20_sgnl'] = 1
    i_sus_182d = i_sus_182d[['Ticker', 'flg_has_sus_182d_ge5_sgnl', 'flg_has_sus_182d_ge20_sgnl']]
    
    i_sus_365d = pd.read_sql('''select s_info_windcode as Ticker, count(*) as cnt_365d   
                           from wind_prod.dbo.ASHAREEODPRICES 
                           where S_DQ_TRADESTATUScode = 0 
                           and trade_dt <= '{0}'
                           and trade_dt >= '{1}' 
                           group by s_info_windcode '''.format(t_1d_str,t_365d_str), conn_wind)
    i_sus_365d['Ticker'] = i_sus_365d['Ticker'].str[:6]
    i_sus_365d.loc[i_sus_365d['cnt_365d'].ge(5), 'flg_has_sus_365d_ge5_sgnl'] = 1
    i_sus_365d.loc[i_sus_365d['cnt_365d'].ge(20), 'flg_has_sus_365d_ge20_sgnl'] = 1
    i_sus_365d = i_sus_365d[['Ticker', 'flg_has_sus_365d_ge5_sgnl', 'flg_has_sus_365d_ge20_sgnl']]
    
    
    ### has up / dn lmt 
    
    i_touch_up_1d = pd.read_sql('''select s_info_windcode as Ticker 
                           from wind_prod.dbo.ASHAREEODPRICES 
                           where S_DQ_TRADESTATUScode != 0 
                           and trade_dt = '{0}' 
                           and s_dq_limit = s_dq_high and s_dq_limit > s_dq_close
                           '''.format(t_1d_str), conn_wind)
    i_touch_up_1d['Ticker'] = i_touch_up_1d['Ticker'].str[:6]
    i_touch_up_1d['flg_touch_up_1d_sgnl'] = 1
            
    i_touch_dn_1d = pd.read_sql('''select s_info_windcode as Ticker 
                           from wind_prod.dbo.ASHAREEODPRICES 
                           where S_DQ_TRADESTATUScode != 0 
                           and trade_dt = '{0}' 
                           and s_dq_stopping = s_dq_low and s_dq_stopping < s_dq_close
                           '''.format(t_1d_str), conn_wind)
    i_touch_dn_1d['Ticker'] = i_touch_dn_1d['Ticker'].str[:6]
    i_touch_dn_1d['flg_touch_dn_1d_sgnl'] = 1
        
    i_close_up_1d = pd.read_sql('''select s_info_windcode as Ticker 
                           from wind_prod.dbo.ASHAREEODPRICES 
                           where S_DQ_TRADESTATUScode != 0 
                           and trade_dt = '{0}' 
           
                and s_dq_limit = s_dq_close
                           '''.format(t_1d_str), conn_wind)
    i_close_up_1d['Ticker'] = i_close_up_1d['Ticker'].str[:6]
    i_close_up_1d['flg_close_up_1d_sgnl'] = 1
            
    i_close_dn_1d = pd.read_sql('''select s_info_windcode as Ticker 
                           from wind_prod.dbo.ASHAREEODPRICES 
                           where S_DQ_TRADESTATUScode != 0 
                           and trade_dt = '{0}' 
                           and s_dq_stopping = s_dq_close 
                           '''.format(t_1d_str), conn_wind)
    i_close_dn_1d['Ticker'] = i_close_dn_1d['Ticker'].str[:6]
    i_close_dn_1d['flg_close_dn_1d_sgnl'] = 1
    
    i_close_up_30d = pd.read_sql('''select s_info_windcode as Ticker, count(*) as cnt_30d  
                           from wind_prod.dbo.ASHAREEODPRICES 
                           where S_DQ_TRADESTATUScode != 0 
                           and trade_dt <= '{0}'
                           and trade_dt >= '{1}' 
                           and s_dq_limit = s_dq_close
                           group by s_info_windcode '''.format(t_1d_str,t_30d_str), conn_wind)
    i_close_up_30d['Ticker'] = i_close_up_30d['Ticker'].str[:6]
    i_close_up_30d.loc[i_close_up_30d['cnt_30d'].ge(2), 'flg_has_uplmt_30d_gt2d_sgnl'] = 1
    i_close_up_30d.loc[i_close_up_30d['cnt_30d'].ge(5), 'flg_has_uplmt_30d_gt5d_sgnl'] = 1
    i_close_up_30d = i_close_up_30d[['Ticker','flg_has_uplmt_30d_gt2d_sgnl','flg_has_uplmt_30d_gt5d_sgnl']]
    
    i_close_dn_30d = pd.read_sql('''select s_info_windcode as Ticker, count(*) as cnt_30d  
                           from wind_prod.dbo.ASHAREEODPRICES 
                           where S_DQ_TRADESTATUScode != 0 
                           and trade_dt <= '{0}'
                           and trade_dt >= '{1}' 
                           and s_dq_stopping = s_dq_close
                           group by s_info_windcode '''.format(t_1d_str,t_30d_str), conn_wind)
    i_close_dn_30d['Ticker'] = i_close_dn_30d['Ticker'].str[:6]
    i_close_dn_30d.loc[i_close_dn_30d['cnt_30d'].ge(2), 'flg_has_dnlmt_30d_gt2d_sgnl'] = 1
    i_close_dn_30d.loc[i_close_dn_30d['cnt_30d'].ge(5), 'flg_has_dnlmt_30d_gt5d_sgnl'] = 1
    i_close_dn_30d = i_close_dn_30d[['Ticker', 'flg_has_dnlmt_30d_gt2d_sgnl', 'flg_has_dnlmt_30d_gt5d_sgnl']]
    
    
    i_close_up_182d = pd.read_sql('''select s_info_windcode as Ticker, count(*) as cnt_182d  
                           from wind_prod.dbo.ASHARE
EODPRICES 
                           where S_DQ_TRADESTATUScode != 0 
                           and trade_dt <= '{0}'
                           and trade_dt >= '{1}' 
                           and s_dq_limit = s_dq_close
                           group by s_info_windcode '''.format(t_1d_str,t_182d_str), conn_wind)
    i_close_up_182d['Ticker'] = i_close_up_182d['Ticker'].str[:6]
    i_close_up_182d.loc[i_close_up_182d['cnt_182d'].ge(5), 'flg_has_uplmt_182d_gt5d_sgnl'] = 1
    i_close_up_182d.loc[i_close_up_182d['cnt_182d'].ge(10), 'flg_has_uplmt_182d_gt10d_sgnl'] = 1
    i_close_up_182d = i_close_up_182d[['Ticker','flg_has_uplmt_182d_gt5d_sgnl','flg_has_uplmt_182d_gt10d_sgnl']]
    
    i_close_dn_182d = pd.read_sql('''select s_info_windcode as Ticker, count(*) as cnt_182d  
                           from wind_prod.dbo.ASHAREEODPRICES 
                           where S_DQ_TRADESTATUScode != 0 
                           and trade_dt <= '{0}'
                           and trade_dt >= '{1}' 
                           and s_dq_stopping = s_dq_close
                           group by s_info_windcode '''.format(t_1d_str,t_182d_str), conn_wind)
    i_close_dn_182d['Ticker'] = i_close_dn_182d['Ticker'].str[:6]
    i_close_dn_182d.loc[i_close_dn_182d['cnt_182d'].ge(5), 'flg_has_dnlmt_182d_gt5d_sgnl'] = 1
    i_close_dn_182d.loc[i_close_dn_182d['cnt_182d'].ge(10), 'flg_has_dnlmt_182d_gt10d_sgnl'] = 1
    i_close_dn_182d = i_close_dn_182d[['Ticker', 'flg_has_dnlmt_182d_gt5d_sgnl', 'flg_has_dnlmt_182d_gt10d_sgnl']]
    
    
    ###??? has weigui 
    
    ### has ST
    
    
    i_st = pd.read_sql('''select s_info_windcode as Ticker, begindate, enddate,
                          s_info_name as st_name 
                          from wind_prod.dbo.ASharePreviousName 
                          where (s_info_name like 'ST%' or s_info_name like '*ST%') 
                          and (enddate is null or enddate >= '{0}')
                          and (begindate <= '{0}') 
                       '''.format(t_1d_str), conn_wind)
    i_st['Ticker'] = i_st['Ticker'].str[:6]
    i_st['flg_has_st_sgnl'] = 1
    i_st = i_st[['Ticker', 'flg_has_st_sgnl']]
    
    
    
    
    
    
        
                       
    ### combine
    
    icom = i_dtk.merge(i_cal, on = 'T-1d', how = 'left')
                       
    icom = icom.merge(i_ipo_date, on = ['Ticker'], how = 'left')
    icom['days_since_ipo'] = (icom['T-1d'] - icom['ipo_date']).dt.days
    icom.loc[icom
['days_since_ipo'].ge(365), 'ipo_gt1y_sgnl'] = 1
    icom.loc[icom['days_since_ipo'].lt(365), 'ipo_gt1y_sgnl'] = 0
    icom = icom.drop(columns = ['days_since_ipo', 'ipo_date']) # ipo_gt1y_sgnl
    
    icom = icom.merge(i_sus_1d, on = 'Ticker', how = 'left')    
    icom['flg_has_sus_1d_sgnl'] = icom['flg_has_sus_1d_sgnl'].fillna(0) # flg_has_sus_1d_sgnl
    icom = icom.merge(i_sus_7d, on = 'Ticker', how = 'left')    
    icom['flg_has_sus_7d_sgnl'] = icom['flg_has_sus_7d_sgnl'].fillna(0) # flg_has_sus_7d_sgnl
    icom = icom.merge(i_sus_182d, on = 'Ticker', how = 'left')    
    icom['flg_has_sus_182d_ge5_sgnl'] = icom['flg_has_sus_182d_ge5_sgnl'].fillna(0) # flg_has_sus_182d_ge5_sgnl
    icom['flg_has_sus_182d_ge20_sgnl'] = icom['flg_has_sus_182d_ge20_sgnl'].fillna(0) # flg_has_sus_182d_ge20_sgnl
    icom = icom.merge(i_sus_365d, on = 'Ticker', how = 'left')
    icom['flg_has_sus_365d_ge5_sgnl'] = icom['flg_has_sus_365d_ge5_sgnl'].fillna(0) # flg_has_sus_365d_ge5_sgnl
    icom['flg_has_sus_365d_ge20_sgnl'] = icom['flg_has_sus_365d_ge20_sgnl'].fillna(0) # flg_has_sus_365d_ge20_sgnl
    
    icom = icom.merge(i_touch_up_1d, on = 'Ticker', how = 'left') # flg_touch_up_1d_sgnl
    icom['flg_touch_up_1d_sgnl'] = icom['flg_touch_up_1d_sgnl'].fillna(0)
    icom = icom.merge(i_touch_dn_1d, on = 'Ticker', how = 'left') # flg_touch_dn_1d_sgnl
    icom['flg_touch_dn_1d_sgnl'] = icom['flg_touch_dn_1d_sgnl'].fillna(0)
    icom = icom.merge(i_close_up_1d, on = 'Ticker', how = 'left') # flg_close_up_1d_sgnl
    icom['flg_close_up_1d_sgnl'] = icom['flg_close_up_1d_sgnl'].fillna(0)
    icom = icom.merge(i_close_dn_1d, on = 'Ticker', how = 'left') # flg_close_dn_1d_sgnl
    icom['flg_close_dn_1d_sgnl'] = icom['flg_close_dn_1d_sgnl'].fillna(0)
    icom = icom.merge(i_close_up_30d, on = 'Ticker', how = 'left') # flg_has_uplmt_30d_gt2d_sgnl flg_has_uplmt_30d_gt5d_sgnl
    icom['flg_has_uplmt_30d_gt2d_sgnl'] = icom['flg_has_uplmt_30d_gt2d_sgnl'].fillna(0)
    icom['flg_has_uplmt_30d_gt5d_sgnl'] = icom['flg_has_uplmt_30d_gt5d_sgnl'].fillna(0)
    icom = icom.merge(i_close_dn_30d, on = 'Ticker', how = 'left') # flg_has_dnlmt_30d_gt2d_sgnl flg_has_dnlmt_30d_gt5d_sgnl
    icom['flg_has_dnlmt_30d_gt2d_sgnl'] = icom['flg_has_dnlmt_30d_gt2d_sgnl'].fillna(0)
    icom['flg_has_dnlmt_30d_gt5d_sgnl'] = icom['flg_has_dnlmt_30d_gt5d_sgnl'].fillna(0)
    icom = icom.merge(i_close_up_182d, on = 'Ticker', how = 'left') # flg_has_uplmt_182d_gt5d_sgnl flg_has_uplmt_182d_gt10d_sgnl
    icom['f
lg_has_uplmt_182d_gt5d_sgnl'] = icom['flg_has_uplmt_182d_gt5d_sgnl'].fillna(0)
    icom['flg_has_uplmt_182d_gt10d_sgnl'] = icom['flg_has_uplmt_182d_gt10d_sgnl'].fillna(0)
    icom = icom.merge(i_close_dn_182d, on = 'Ticker', how = 'left') # flg_has_dnlmt_182d_gt5d_sgnl flg_has_dnlmt_182d_gt10d_sgnl
    icom['flg_has_dnlmt_182d_gt5d_sgnl'] = icom['flg_has_dnlmt_182d_gt5d_sgnl'].fillna(0)
    icom['flg_has_dnlmt_182d_gt10d_sgnl'] = icom['flg_has_dnlmt_182d_gt10d_sgnl'].fillna(0)
    
    icom = icom.merge(i_st, on = 'Ticker', how = 'left') # flg_has_st_sgnl
    icom['flg_has_st_sgnl'] = icom['flg_has_st_sgnl'].fillna(0)
    
    
    
    icom = icom[['DataDate', 'Ticker',
                 'ipo_gt1y_sgnl',
                 'flg_has_sus_1d_sgnl', 'flg_has_sus_7d_sgnl', 'flg_has_sus_182d_ge5_sgnl',
                 'flg_has_sus_182d_ge20_sgnl', 'flg_has_sus_365d_ge5_sgnl', 'flg_has_sus_365d_ge20_sgnl',
                 'flg_touch_up_1d_sgnl', 'flg_touch_dn_1d_sgnl', 'flg_close_up_1d_sgnl',
                 'flg_close_dn_1d_sgnl', 'flg_has_uplmt_30d_gt2d_sgnl', 'flg_has_uplmt_30d_gt5d_sgnl',
                 'flg_has_dnlmt_30d_gt2d_sgnl', 'flg_has_dnlmt_30d_gt5d_sgnl',
                 'flg_has_uplmt_182d_gt5d_sgnl', 'flg_has_uplmt_182d_gt10d_sgnl',
                 'flg_has_dnlmt_182d_gt5d_sgnl', 'flg_has_dnlmt_182d_gt10d_sgnl', 
                 'flg_has_st_sgnl'
                 ]]
            
    icom.to_parquet(os.path.join(save_path, i))
    
