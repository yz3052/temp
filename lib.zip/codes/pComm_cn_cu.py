﻿#$%^&* pComm_cn_cu.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Aug  9 14:36:42 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw


# This explores relationship between copper stocks and CU1
# stocks are leading indicators of CU1
# I believe the alpha is intraday. Not overnight.



### get cu1 price index

i_cu = pd.read_excel(r"S:\Data\China Data Hunt\cache\CU1.xlsx")
i_cu = i_cu.rename(columns = {'Date':'datadate', 'Open':'cu_o', 'High':'cu_h', 
                              'Low':'cu_l', 'Close':'cu_c', 'Open Interest':'cu_oi'})
i_cu = i_cu.sort_values('datadate')
i_cu = i_cu.reset_index(drop=True)

i_cu['cu_c_1d'] = i_cu['cu_c'].shift()
i_cu['cu_c_ret'] = i_cu['cu_c'] / i_cu['cu_c_1d'] -1


### get copper tickers 

cu_tk = ['600362.SH','000630.SZ','000878.SZ','601899.SH']

### get stock return

i_ret = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                   s_dq_adjclose as c, s_dq_adjpreclose as c_1d 
                   from wind_prod.dbo.ashareeodprices
                   where s_info_windcode in ('600362.SH','000630.SZ','000878.SZ','601899.SH') 
                   and trade_dt > '20140101' ''' )
i_ret['ret'] = i_ret['c'] / i_ret['c_1d'] - 1
i_ret['datadate'] = pd.to_datetime(i_ret['datadate'], format='%Y%m%d')


### combine

icom = i_ret.merge(i_cu, on = 'datadate', how = 'inner')
icom = icom.sort_values(['ticker', 'datadate'])

icom['ret_1d'] = icom.groupby('ticker')['ret'].shift()
icom['ret_p1d'] = icom.groupby('ticker')['ret'].shift(-1)
icom['cu_c_ret_1d'] = icom.groupby('ticker')['cu_c_ret'].shift()
icom['cu_c_ret_p1d'] = icom.groupby('ticker')['cu_c_ret'].shift(-1)
icom['stk_cu_p1d'] = icom['ret_p1d'] - icom['cu_c_ret_p1d']



# summary stats

icom[['cu_c_ret', 'ret']].corr() #35%
icom.groupby('ticker')[['cu_c_ret', 'ret']].apply(lambda x: x[['cu_c_ret', 'ret']].corr().values[0][1]) # all ~35%
icom.groupby('ticker')[['cu_c_ret', 'ret_1d']].apply(lambda x: x[['cu_c_ret', 'ret_1d']].corr().values[0][1]) # all ~10%
icom.groupby('ticker')[['cu_c_ret_1d', 'ret']].apply(lambda x: x[['cu_c_ret_1d', 'ret']].corr().values[0][1]) # all ~2%


# normalize return

icom['ret_slfrk'] = icom.groupby('ticker').rolling(250)['ret'].apply(lambda x: (252 - x.rank().values[-1])/252, raw = False).values
icom['cu_ret_slfrk'] = icom.groupby('ticker').rolling(250)['cu_c_ret'].apply(lambda x: (252 - x.rank().values[-1])/252, raw = False).values

icom['stk_cu'] = icom[
'ret_slfrk'] - icom['cu_ret_slfrk']
icom['stk_cu_bk'] = yu.pdqcut(icom['stk_cu'], bins=10)

icom.groupby(['stk_cu_bk'])['stk_cu_p1d'].mean().plot()

