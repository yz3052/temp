﻿#$%^&* pCNE5S_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Mar  5 07:10:55 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import os 

# date range
i_date_range = pd.DataFrame(pd.date_range(start = '2010-01-01', end = '2023-12-31'), columns=['date'])
i_date_range['y'] = i_date_range['date'].dt.year.astype(str).str.zfill(4)
i_date_range['m'] = i_date_range['date'].dt.month.astype(str).str.zfill(2)
i_date_range['d'] = i_date_range['date'].dt.day.astype(str).str.zfill(2)
i_date_range['ymd'] = i_date_range['y'].str[-2:] + i_date_range['m'] + i_date_range['d']

# read data
for i, r in i_date_range.iterrows():
    target_path = os.path.join(r'Z:\Barra\Models\China\ChinaDomestic_CNE\CNE5\Short-Term_CNE5S',r['y'],r['m'],r['d'],'CNE5S'+r['ymd']+'.RSK')
    target_path_id = os.path.join(r'Z:\Barra\Models\China\ChinaDomestic_CNE\CNE5',r['y'],r['m'],r['d'],'CNE5'+r['ymd']+'.IDS')
    
    # read rsk    
    if os.path.exists(target_path):
        t_cne5s = None
        t_cne5s = pd.read_csv(target_path, skiprows = 1)
        t_cne5s = t_cne5s.drop(columns = ['Unnamed: 27'])
        t_cne5s['DataDate'] = r['y']+'-'+r['m']+'-'+r['d']
        t_cne5s['DataDate'] = pd.to_datetime(t_cne5s['DataDate'])
        print(r['ymd'],end=' rsk ')
    else:
        print(r['ymd']+'  RSK X', end=',')
        continue
    
    # read id
    if os.path.exists(target_path_id):
        t_id = None
        t_id = pd.read_csv(target_path_id, skiprows = 1)
        print('ID', end=',')
    else:
        t_id = None
        t_id = pd.read_csv(r"Z:\Barra\Models\China\ChinaDomestic_CNE\CNE5\2012\08\01\CNE5120801.IDS", skiprows = 1)
        print('backfill ID', end=',')
    
    t_id = t_id.drop(columns=['Unnamed: 5'])
    yyyymmdd_int = int(r['y'])*10000+int(r['m'])*100+int(r['d'])
    t_id = t_id[(t_id['STARTDATE']<=yyyymmdd_int)&(t_id['ENDDATE']>=yyyymmdd_int)]
    t_id_isin = t_id[t_id['TYPE'].str[:4]=='ISIN']
    t_id_cusip = t_id[t_id['TYPE'].str[:5]=='CUSIP']
    t_id_sedol = t_id[t_id['TYPE'].str[:5]=='SEDOL']
    
    if (t_id_isin['BARRID'].duplicated().sum()>0) | (t_id_cusip['BARRID'].duplicated().sum()>0):
        raise Exception(r['ymd']+": duplicated ID")
    
    # merge rsk and id
    t_cne5s = t_cne5s.merge(t_id_isin[['BARRID','ID']].rename(columns={'ID':'ISIN'}), on = ['BARRID'], how = 'left')
    t_cne5s = t_cne5s.merge(t_id_cusip[['BARRID','ID']].rename(columns={'ID':'CUSIP'}), on = ['BARRID'], how = 'left')
    t_cne5s = t_cne5s.merge(t_id_sedol
[['BARRID','ID']].rename(columns={'ID':'SEDOL'}), on = ['BARRID'], how = 'left')
    t_cne5s = t_cne5s[['DataDate','ISIN','CUSIP','SEDOL','BARRID', 'SED-CUS', 'LOCID', 'NAME', 
                       'HBETA', 'PBETA', 'SRISK%', 'TRISK%', 'COUNTRY', 
                       'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 
                       'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL', 'INDNAME', 'IND',
                       'PRICE', 'CAPITALIZATION', 'YLD%', 'ESTU', 'ISOCURR', 'INTRA_MONTH_ADDITION']]
    t_cne5s.to_parquet(os.path.join(r'S:\Data\China Data Hunt\tmp', r['ymd']+'.parquet'))
    
    
# read tmp files
barra_files = os.listdir(r'S:\Data\China Data Hunt\tmp')
i_barra = pd.concat(pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\tmp',f)) for f in barra_files)

# formatting
for numeric_c in ['YLD%','HBETA']:
    i_barra[numeric_c] = pd.to_numeric(i_barra[numeric_c].str.strip())
for c in ['ISIN','CUSIP','SEDOL','BARRID','SED-CUS','LOCID','NAME','INDNAME','ISOCURR']:
    i_barra[c] = i_barra[c].str.strip()

# remove tmp files
for f in barra_files:
    os.remove(os.path.join(r'S:\Data\China Data Hunt\tmp', f))

# to csv
i_barra.to_csv(r'S:\Data\China Data Hunt\cache\barra_cne5s.csv', index = False)


'''
create table BARRA_CNE5S (
DataDate datetime, ISIN varchar(30), CUSIP varchar(30), SEDOL varchar(30), BARRID varchar(30), [SED-CUS] varchar(30), LOCID varchar(30),
NAME varchar(150), HBETA float, PBETA float, [SRISK%] float, [TRISK%] float, COUNTRY float, BETA float, 
MOMENTUM float, SIZE float, EARNYILD float, RESVOL float, GROWTH float, BTOP float, LEVERAGE float,
LIQUIDTY float, SIZENL float, INDNAME varchar(150), IND int, PRICE float, CAPITALIZATION float, [YLD%] float,
ESTU int, ISOCURR varchar(30), INTRA_MONTH_ADDITION int)

bcp [BackTest].[dbo].[BARRA_CNE5S] in "S:\Data\China Data Hunt\cache\barra_cne5s.csv" -c -t  , -S summitsqldb -U AD\thzhang -T -F 2 -e "S:/Data/China Data Hunt/error.txt"
'''
