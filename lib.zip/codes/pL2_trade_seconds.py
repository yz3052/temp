﻿#$%^&* pL2_trade_seconds.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Apr 14 06:47:16 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine

# This studies the filled orders that was submitted wihtin the first 2 seconds of each minute. 



### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])



### trod metrics


i_trod3s = yu.get_q('''(get `:/export/datadev/Data/SHSZ/TROD_metrics/i_trod_metrics_sh_lt2s),
                     (get `:/export/datadev/Data/SHSZ/TROD_metrics/i_trod_metrics_sz_lt2s) ''')

i_trod3s['code'] = i_trod3s['code'].str.decode('utf8')
c_sh = i_trod3s['code'].str[0].isin(['6'])
c_sz = i_trod3s['code'].str[0].isin(['0','3'])
i_trod3s.loc[c_sh, 'ticker'] = i_trod3s.loc[c_sh, 'code'] + '.SH'
i_trod3s.loc[c_sz, 'ticker'] = i_trod3s.loc[c_sz, 'code'] + '.SZ'
i_trod3s['datadate'] = pd.to_datetime(i_trod3s['date'])
i_trod3s = i_trod3s.sort_values(['ticker', 'datadate'])
i_trod3s = i_trod3s[i_trod3s['ticker'].notnull()]


### order book metrics

i_od3s = yu.get_q('''(get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sh_3s),
                     (get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sz_3s) ''')

i_od3s['code'] = i_od3s['code'].str.decode('utf8')
c_sh = i_od3s['code'].str[0].isin(['6'])
c_sz = i_od3s['code'].str[0].isin(['0','3'])
i_od3s.loc[c_sh, 'ticker'] = i_od3s.loc[c_sh, 'code'] + '.SH'
i_od3s.loc[c_sz, 'ticker'] = i_od3s.loc[c_sz, 'code'] + '.SZ'
i_od3s['datadate'] = pd.to_datetime(i_od3s['date'])
i_od3s = i_od3s.sort_values(['ticker', 'datadate'])
i_od3s = i_od3s[i_od3s['ticker'].notnull()]

i_od3s.loc[i_od3s['cnt_b_z_lt2']>1, 'flg_has_twap'] = 1






### combine

icom = i_sd.merge(i_od3s, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_trod3s, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['avgPVadjln'] = np.log(icom['avgPVadj'])
icom['avgPVadjln'] = icom['avgPVadjln'].replace(-np.inf,np.nan)
icom['spread_5bk'] = icom.groupby('datadate')['spread'].apply(lambda x: yu.pdqcut(x,bins=5)).values
icom['size_5bk'] = icom.groupby('datadate')['SIZE'].apply(lambda x: yu.pdqcut(x,bins=5)).values
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']


### od fill rate within first 2 seconds

icom['fill_lt2'] = icom['cnt_b_trd_tot_lt2s'].d
ivide(icom['cnt_b_od_tot_lt2s'])
icom['fill_lt2_bk'] = icom.groupby('datadate')['fill_lt2'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['fill_lt2_hastwap'] = np.nan
icom.loc[icom['flg_has_twap']==1, 'fill_lt2_hastwap'] = icom.loc[icom['flg_has_twap']==1, 'fill_lt2']
icom['fill_lt2_hastwap_bk'] = icom.groupby('datadate')['fill_lt2_hastwap'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['fill_lt2_bk'], 'fill_lt2') # v-shaped: 1 -2 +3
yu.create_cn_3x3(icom, ['fill_lt2_hastwap_bk'], 'fill_lt2_hastwap') # most +ve, t not good enough

icom['unfill'] = icom['cnt_b_od_tot_lt2s'] - icom['cnt_b_trd_tot_lt2s']
icom['unfill_dv_v'] = icom['unfill'].divide(icom['V_l1d'])
icom['unfill_dv_v_bk'] = icom.groupby('datadate')['unfill_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['unfill_dv_od'] = icom['unfill'].divide(icom['cnt_b_tot'])
icom['unfill_dv_od_bk'] = icom.groupby('datadate')['unfill_dv_od'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['unfill_dv_v_bk'], 'unfill_dv_v') # random
yu.create_cn_3x3(icom, ['unfill_dv_od_bk'], 'unfill_dv_od') # v-shape +3 -2 +1.5


### trade cnt 

icom['trd_lt2s_dv_tot'] = icom['cnt_b_trd_tot_lt2s'].divide(icom['cnt_b_trd_tot_daily'])
icom['trd_lt2s_dv_tot_bk'] = icom.groupby('datadate')['trd_lt2s_dv_tot'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['trd_lt2s_dv_tot_bk'], 'trd_lt2s_dv_tot') # less mono: 0 -1.5 + 3.5

icom['trd_lt2s_dv_tot_has_twap'] = np.nan
icom.loc[icom['flg_has_twap']==1, 'trd_lt2s_dv_tot_has_twap'] = icom.loc[icom['flg_has_twap']==1,'trd_lt2s_dv_tot']
icom['trd_lt2s_dv_tot_has_twap_bk'] = icom.groupby('datadate')['trd_lt2s_dv_tot_has_twap'].apply(lambda x:yu.pdqcut(x,bins=10)).values
icom['trd_lt2s_dv_tot_has_twap_rk'] = icom.groupby('datadate')['trd_lt2s_dv_tot_has_twap'].apply(yu.uniformed_rank).values
yu.create_cn_3x3(icom, ['trd_lt2s_dv_tot_has_twap_bk'], 'trd_lt2s_dv_tot_has_twap') # less mono, all +ve: 0 +8 +3 +8

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['trd_lt2s_dv_tot_has_twap_rk']>0)].\
            dropna(subset=['trd_lt2s_dv_tot_has_twap_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'trd_lt2s_dv_tot_has_twap_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.8 / -9


icom['trd_lt2s_dv_tot_has_twap_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['trd_lt2s_dv_tot_has_twap'].sum().values
icom['trd_lt2s_dv_tot_has_twap_t20d_
rk'] = icom.groupby('datadate')['trd_lt2s_dv_tot_has_twap_t20d'].apply(yu.uniformed_rank).values
icom['trd_lt2s_dv_tot_has_twap_t40d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['trd_lt2s_dv_tot_has_twap'].sum().values
icom['trd_lt2s_dv_tot_has_twap_t40d_rk'] = icom.groupby('datadate')['trd_lt2s_dv_tot_has_twap_t40d'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['trd_lt2s_dv_tot_has_twap_t20d_rk']>0)].\
            dropna(subset=['trd_lt2s_dv_tot_has_twap_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'trd_lt2s_dv_tot_has_twap_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.9 / 0.2
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['trd_lt2s_dv_tot_has_twap_t40d_rk']>0)].\
            dropna(subset=['trd_lt2s_dv_tot_has_twap_t40d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'trd_lt2s_dv_tot_has_twap_t40d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.4 / 0.8


### trade <2s / PV

icom['d_b_lt2s_dv_pv'] = icom['d_b_lt2s'].divide(icom['PV_l1d'])
icom['d_b_lt2s_dv_pv_bk'] = icom.groupby('datadate')['d_b_lt2s_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['d_b_lt2s_dv_pv_sprdbk'] = icom.groupby(['datadate','spread_5bk'])['d_b_lt2s_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['d_b_lt2s_dv_pv_sprdSizebk'] = icom.groupby(['datadate','spread_5bk','size_5bk'])['d_b_lt2s_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['d_b_lt2s_dv_pv_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['d_b_lt2s_dv_pv'].mean().values
icom['d_b_lt2s_dv_pv_t20d_bk'] = icom.groupby('datadate')['d_b_lt2s_dv_pv_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['d_b_lt2s_dv_pv_t20d_orth'] = icom.groupby('datadate')[COLS+['d_b_lt2s_dv_pv_t20d']].apply(lambda x: yu.orthogonalize_cn(x['d_b_lt2s_dv_pv_t20d'], x[COLS])).values
icom['d_b_lt2s_dv_pv_t20d_orth_bk'] = icom.groupby('datadate')['d_b_lt2s_dv_pv_t20d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['d_b_lt2s_dv_pv_t20d_sprdbk'] = icom.groupby(['datadate','spread_5bk'])['d_b_lt2s_dv_pv_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['d_b_lt2s_dv_pv_t60d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=84),on='datadate')['d_b_lt2s_dv_pv'].mean().values
icom['d_b_lt2s_dv_pv_t60d_bk'] = icom.groupby('datadate')['d_b_lt2s_dv_pv_t60d'].apply(lambda x: yu.
pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['d_b_lt2s_dv_pv_bk'], 'd_b_lt2s_dv_pv') # leaning positive rltn, random 
yu.create_cn_3x3(icom, ['d_b_lt2s_dv_pv_sprdbk'], 'd_b_lt2s_dv_pv') # random
yu.create_cn_3x3(icom, ['d_b_lt2s_dv_pv_sprdSizebk'], 'd_b_lt2s_dv_pv') # random
yu.create_cn_3x3(icom, ['d_b_lt2s_dv_pv_t20d_bk'], 'd_b_lt2s_dv_pv_t20d') # a-shape -0.5 +1 -3
yu.create_cn_3x3(icom, ['d_b_lt2s_dv_pv_t60d_bk'], 'd_b_lt2s_dv_pv_t60d') # a-shape -0.5 +1.5 -2.5
yu.create_cn_3x3(icom, ['d_b_lt2s_dv_pv_t20d_orth_bk'], 'd_b_lt2s_dv_pv_t20d_orth') # 
yu.create_cn_3x3(icom, ['d_b_lt2s_dv_pv_t20d_sprdbk'], 'd_b_lt2s_dv_pv_t20d') # a-shape


### trade <2s / PV, for tickers that have twap

icom['d_b_lt2s_sgnfct'] = np.nan
c1 = icom['flg_has_twap'] == 1
icom.loc[c1, 'd_b_lt2s_sgnfct'] = icom.loc[c1, 'd_b_lt2s']

icom['d_b_lt2s_agnfcnt_dv_pv'] = icom['d_b_lt2s_sgnfct'].divide(icom['PV_l1d'])
icom['d_b_lt2s_agnfcnt_dv_pv_bk'] = icom.groupby('datadate')['d_b_lt2s_agnfcnt_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['d_b_lt2s_agnfcnt_dv_pv_bk'], 'd_b_lt2s_agnfcnt_dv_pv') # random 

