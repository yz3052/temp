﻿#$%^&* pGraph_cn_coverage.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 23 06:28:10 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu



### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()


### coverage


i_con = yu.get_sql('''select stock_code as ticker, create_date, entrytime, report_year, report_quarter,
                   forecast_or as con_or, forecast_np as con_np, forecast_eps as con_eps,
                   report_type, organ_id, author_name, attention
                   from cndbdev.dbo.rpt_forecast_stk ''')

c_sh = i_con['ticker'].str[0].isin(['6'])
c_sz = i_con['ticker'].str[0].isin(['0', '3'])
i_con.loc[c_sh, 'ticker'] = i_con.loc[c_sh, 'ticker'] + '.SH'
i_con.loc[c_sz, 'ticker'] = i_con.loc[c_sz, 'ticker'] + '.SZ'

#i_con['datadate'] = pd.to_datetime(i_con['entrytime'].dt.date)
i_con['datadate'] = pd.to_datetime((i_con['entrytime'] - pd.to_timedelta('6 hours')).dt.date)
i_con['create_date'] = pd.to_datetime(i_con['create_date'])

i_con = i_con[i_con['report_type']!=21]

i_con.loc[i_con['attention']=='首份报告', 'first_coverage_cnt'] = 1

i_con = i_con.sort_values(['ticker','report_year','report_quarter','organ_id','author_name','create_date','datadate'])
i_con = i_con.reset_index(drop = True)



### loop over dates and get organid set

o_cov = []

for dt in pd.date_range(start = '2016-01-01', end = '2021-12-31').tolist():
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    t_con = i_con[(i_con['datadate']<=dt)&(i_con['create_date']>=dt-pd.to_timedelta('91 days'))]
    
    t_tk_organ_map = t_con.groupby('ticker')['organ_id'].apply(lambda x: set(x))
    t_tk_organ_map = t_tk_organ_map.reset_index()
    t_tk_organ_map['datadate'] = dt
    o_cov.append(t_tk_organ_map)
    
    
o_cov = pd.concat(o_cov, axis = 0)

o_cov['organ_id_sum'] = o_cov['organ_id'].apply(lambda x: len(x))
o_cov_sum = o_cov[['ticker','datadate','organ_id_sum']]


### calculate corr matrix

o_shared_organ_cnt = []

for dt in pd.date_range(start = '2016-02-01', end = '2021-11-01', freq='W'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    t_sd = i_sd[i_sd['datadate']==i_sd_dd[i_sd_dd<=dt].max()]
    t_tk_organ_map = o_cov[o_cov['datadate']==dt]
    t_tk_organ_map = t_tk_organ_map[t_tk_organ_map['ticker'].isin(t_sd['ticker'].tolist())]
        
    t_tkPair_organSet = pd.DataFrame((t_tk_organ_map['organ_id'].values[:, 
None] &\
                                      t_tk_organ_map['organ_id'].values))
    t_tkPair_organSet = t_tkPair_organSet.applymap(lambda x: len(x) )
    t_tkPair_organSet.columns = t_tk_organ_map['ticker'].values
    t_tkPair_organSet.index = t_tk_organ_map['ticker'].values
    t_tkPair_organSet.values[[np.arange(t_tkPair_organSet.shape[0])]*2] = 0
    
    t_sum1 = t_tkPair_organSet.mean(axis = 1)
    t_sum1 = t_sum1.reset_index()
    t_sum1.columns = ['ticker','shared_organCnt_mean']
    
    t_sum2 = t_tkPair_organSet.sum(axis = 1)
    t_sum2 = t_sum2.reset_index()
    t_sum2.columns = ['ticker','shared_organCnt_sum']
    
    t_sum = t_sum1.merge(t_sum2, on = 'ticker', how = 'outer')
    t_sum['datadate'] = dt
    
    o_shared_organ_cnt.append(t_sum)
    
o_shared_organ_cnt = pd.concat(o_shared_organ_cnt, axis = 0)

### combine 


icom = pd.merge_asof(i_sd, o_shared_organ_cnt, by='ticker', on='datadate')
icom = icom.merge(o_cov_sum, on = ['ticker','datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])

icom['shared_organCnt_mean_bk'] = icom.groupby('datadate')['shared_organCnt_mean'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['shared_organCnt_mean_rk'] = icom.groupby('datadate')['shared_organCnt_mean'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['shared_organCnt_bk'], 'shared_organCnt') # less mono: -1.5 +3 0.5


icom['shared_organCnt_dv_sum'] = icom['shared_organCnt_sum'].divide(icom['organ_id_sum'])
icom['shared_organCnt_dv_sum'] = icom['shared_organCnt_dv_sum'].replace(np.inf,np.nan)
icom['shared_organCnt_dv_sum_bk'] = icom.groupby('datadate')['shared_organCnt_dv_sum'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom,['shared_organCnt_dv_sum_bk'],'shared_organCnt_dv_sum') # mono +2 -0.5, <- opposite direction 

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['shared_organCnt_orth'] = icom.groupby('datadate')[COLS+['shared_organCnt']].apply(lambda x: yu.orthogonalize_cn(x['shared_organCnt'], x[COLS])).values
icom['shared_organCnt_orth_bk'] = icom.groupby('datadate')['shared_organCnt_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['shared_organCnt_orth_rk'] = icom.groupby('datadate')['shared_organCnt_orth'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['shared_organCnt_orth_bk'], 'shared_organCnt_orth') # mono: -2.5 +2


    
icom['orth_neg_sgnl'] = np.nan
icom.loc[icom['shared_organCnt_orth_rk']<-0.8, 'o
rth_neg_sgnl']  = -1
icom['orth_neg_sgnl'] = icom.groupby('ticker')['orth_neg_sgnl'].ffill(limit=5)

icom['orth_pos_sgnl'] = np.nan
icom.loc[icom['shared_organCnt_orth_rk']>0.5, 'orth_pos_sgnl']  = 1
icom['orth_pos_sgnl'] = icom.groupby('ticker')['orth_pos_sgnl'].ffill(limit=5)




o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['shared_organCnt_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'shared_organCnt_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['orth_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'orth_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['csi300_flag']==1)].\
            dropna(subset=['orth_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'orth_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['orth_pos_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'orth_pos_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
