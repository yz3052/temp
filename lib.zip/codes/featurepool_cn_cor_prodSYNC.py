﻿#$%^&* featurepool_cn_cor_prodSYNC.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  5 16:48:33 2022

@author: thzhang
"""

import sys
import os
import pandas as pd
import numpy as np

import datetime

from sqlalchemy import create_engine
import urllib


# this generates 1-D descriptors 
# to be scheduled on crontab
# parquet file name is T-1d

### SQL create 
# create table F001_COR_FORMAT (Ticker varchar(max), [T-1d] datetime, [DataDate] datetime, 
# pq_pct_corr_t20d float, pq_dpct_corr_t20d float)



#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------

source_path = '/export/dataprod2/CNL2/SHSZ/q_trade_pqcorr'
save_path = '/dat/summit_capital/TZ/PROD_FEATURES/featurepool_cn_desc_pv_trade_pqcorr'
conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))


today = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
today = pd.to_datetime(today.date())
today_str = today.strftime('%Y%m%d')




#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------

i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()



#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------



dates_to_query = i_cal['DataDate'].dt.strftime('%Y%m%d.parquet').drop_duplicates().tolist()
dates_to_query = [d for d in dates_to_query if (d>='20170101.parquet') and (d<today.strftime('%Y%m%d.parquet'))]

existing_dates = os.listdir(save_path)
dates_to_query = [d for d in dates_to_query if d not in existing_dates]








#------------------------------------------------------------------------------
### calculate descriptors
#------------------------------------------------------------------------------

dates_to_query.sort()
all_dates = os.listdir(source_path)
all_dates.sort()

fo
r i in range(len(dates_to_query)):
    
    # date string
    
    t_1d = pd.to_datetime(dates_to_query[i], format = '%Y%m%d.parquet')
    t_20d = all_dates[max(all_dates.index(t_1d.strftime('%Y.%m.%d.txt'))-19, 0)]        
        
    # q query results
    
    i_q_files = os.listdir(source_path)
    i_q_files = [i for i in i_q_files if t_20d<=i<=t_1d.strftime('%Y.%m.%d.txt')]
    i_q = pd.concat([pd.read_csv(os.path.join(source_path, f), sep = '|', ) for f in i_q_files], axis=0)
    
    i_q = i_q.rename(columns = {'code': 'Ticker', 'date': 'T-1d'})
    i_q['Ticker'] = i_q['Ticker'].astype(int).astype(str).str.zfill(6)
    i_q['T-1d'] = pd.to_datetime(i_q['T-1d'])
    
    # calculate trailing 20d intraday pqcorr
    
    s20 = i_q.groupby('Ticker').agg({'p_sum': sum,'p2_sum': sum,
                                    'q_pct_sum': sum,'q_dpct_sum': sum, 
                                    'q_pct2_sum': sum,'q_dpct2_sum': sum,  
                                    'pq_pct_sum': sum,'pq_dpct_sum': sum, 
                                    'i_cnt': sum})
    s20['p_mean'] = s20['p_sum'].divide(s20['i_cnt'])
    s20['q_pct_mean'] = s20['q_pct_sum'].divide(s20['i_cnt'])
    
    s20['corr_nom'] = s20['pq_pct_sum'] - s20['p_sum'].multiply(s20['q_pct_mean']) - s20['q_pct_sum'].multiply(s20['p_mean']) + s20['p_sum'].multiply(s20['q_pct_sum']).divide(s20['i_cnt'])
    s20['corr_denom_p'] = np.sqrt(s20['p2_sum'] - s20['p_mean'].pow(2).multiply(s20['i_cnt'])*2 + s20['p_mean'].pow(2).multiply(s20['i_cnt']))
    s20['corr_denom_q_pct'] = np.sqrt(s20['q_pct2_sum'] - s20['q_pct_mean'].pow(2).multiply(s20['i_cnt'])*2 + s20['q_pct_mean'].pow(2).multiply(s20['i_cnt']))    
    s20['pq_pct_corr_t20d'] = s20['corr_nom'].divide(s20['corr_denom_p']).divide(s20['corr_denom_q_pct'])
    
    s20['q_dpct_mean'] = s20['q_dpct_sum'].divide(s20['i_cnt'])
    s20['corr_nom'] = s20['pq_dpct_sum'] - s20['p_sum'].multiply(s20['q_dpct_mean']) - s20['q_dpct_sum'].multiply(s20['p_mean']) + s20['p_sum'].multiply(s20['q_dpct_sum']).divide(s20['i_cnt'])
    s20['corr_denom_p'] = np.sqrt(s20['p2_sum'] - s20['p_mean'].pow(2).multiply(s20['i_cnt'])*2 + s20['p_mean'].pow(2).multiply(s20['i_cnt']))
    s20['corr_denom_q_pct'] = np.sqrt(s20['q_dpct2_sum'] - s20['q_dpct_mean'].pow(2).multiply(s20['i_cnt'])*2 + s20['q_dpct_mean'].pow(2).multiply(s20['i_cnt']))    
    s20['pq_dpct_corr_t20d'] = s20['corr_nom'].divide(s20['corr_denom_p']).divide(s20['corr_denom_q_pct'])
    
    s20 = s20.reset_inde
x()
    s20['T-1d'] = t_1d
    s20 = s20[['Ticker', 'T-1d', 'pq_pct_corr_t20d','pq_dpct_corr_t20d']]   
    
    # combine
        
    icom = s20.merge(i_cal, on = ['T-1d'], how = 'left')
    
    icom['pq_pct_corr_t20d'] = icom['pq_pct_corr_t20d'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
    icom['pq_dpct_corr_t20d'] = icom['pq_dpct_corr_t20d'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
    icom[['Ticker', 'DataDate', 'pq_pct_corr_t20d', 'pq_dpct_corr_t20d']].to_parquet(os.path.join(save_path, dates_to_query[i]))

    


