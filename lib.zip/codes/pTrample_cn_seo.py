﻿#$%^&* pTrample_cn_seo.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue May 10 13:10:38 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime



### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])



### markt price & adj factor

i_mkt = yu.get_sql('''select trade_dt as datadate, s_info_windcode as ticker,
                    S_DQ_ADJFACTOR as adjf, s_dq_close as c
                    from wind_prod.dbo.ashareeodprices 
                    where trade_dt > '20150101' ''')
i_mkt['datadate'] = pd.to_datetime(i_mkt['datadate'], format = '%Y%m%d')
i_mkt = i_mkt.sort_values('datadate')



### SEO cancel

i_seo_cancel = yu.get_sql("select * from wind.dbo.ASHARESEOBT where s_fellow_progress in (4,12,21,22)")
i_seo_cancel['ANN_DT'] = pd.to_datetime(i_seo_cancel['ANN_DT'], format = '%Y%m%d')

i_seo_cancel['datadate'] = np.nan
c_close = (i_seo_cancel['ANN_DT'] - pd.to_datetime(i_seo_cancel['OPDATE'].dt.date)).dt.days==1
c_aft15 = i_seo_cancel['OPDATE'].dt.hour >= 15
i_seo_cancel.loc[c_close & c_aft15, 'datadate'] = pd.to_datetime(i_seo_cancel.loc[c_close & c_aft15, 'OPDATE'].dt.date)
c_close2 = (i_seo_cancel['ANN_DT'] - pd.to_datetime(i_seo_cancel['OPDATE'].dt.date)).dt.days==0
c_bfr9 = i_seo_cancel['OPDATE'].dt.hour <= 4
i_seo_cancel.loc[c_close2 & c_bfr9, 'datadate'] = i_seo_cancel.loc[c_close2 & c_bfr9, 'ANN_DT'] - pd.to_timedelta('1 day')
i_seo_cancel.loc[i_seo_cancel['datadate'].isnull(), 'datadate'] = i_seo_cancel.loc[i_seo_cancel['datadate'].isnull(), 'ANN_DT']
i_seo_cancel['datadate'] = pd.to_datetime(i_seo_cancel['datadate'])

i_seo_cancel = i_seo_cancel.rename(columns = {'S_INFO_WINDCODE': 'ticker'})
i_seo_cancel['flag_cancel'] = 1

i_seo_cancel = i_seo_cancel[['ticker', 'datadate', 'S_FELLOW_PROGRESS','flag_cancel','EVENT_ID']]
i_seo_cancel = i_seo_cancel.drop_duplicates()


### SEO

i_seo = yu.get_sql("select * from wind.dbo.ASHARESEOBT where s_fellow_price is not null  order by s_info_windcode, ann_dt")
i_seo = i_seo.rename(columns = {'S_INFO_WINDCODE': 'ticker', 'ANN_DT': 'datadate'})

#c1 = i_seo['datadate'].dt.hour<=4
#i_seo.loc[c1, 'datadate'] = i_seo.loc[c1, 'datadate'] - pd.to_timedelta('1 day')
i_seo['datadate'] = pd.to_datetime(i_seo['datadate'], format='%Y%m%d')

i_seo = i_seo[['datadate', 'ticker', 'S_FELLOW_PRICE']]
i_seo = i_seo.groupby('ticker').first()
i_seo = i_seo.reset_index()
i_seo = i_seo.sort_values('datadate')

i_
seo2 = pd.merge_asof(i_seo, i_mkt, by = 'ticker', on = 'datadate', tolerance = pd.to_timedelta('14 days'))
i_seo2 = i_seo2[i_seo2['c'].notnull()]
i_seo2 = i_seo2.rename(columns = {'c':'c_issue', 'adjf':'adjf_issue'})
i_seo2 = i_seo2.rename(columns = {'datadate': 'issue_date'})



### combine market and SEO 

icom = pd.merge_asof(i_mkt, i_seo2, by = 'ticker', left_on = 'datadate', right_on = 'issue_date')
icom = icom.sort_values(['ticker', 'datadate'])
icom['days_since_issue'] = (icom['datadate'] - icom['issue_date']).dt.days
icom['adjc'] = icom['c'].multiply(icom['adjf'])
icom['adjc_t60d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=91),on='datadate',min_periods=30)['adjc'].std().values
icom['adjc_issue'] = icom['c_issue'].multiply(icom['adjf_issue'])
icom['flag_below_issue'] = icom['adjc'] < icom['adjc_issue']
icom['issue_m_adjp'] = icom['c_issue'].multiply(icom['adjf_issue']) - icom['adjc']
icom['issue_m_adjp_dv_std'] = icom['issue_m_adjp'].divide(icom['adjc_t60d'])
icom['issue_m_adjp_dv_std'] = icom['issue_m_adjp_dv_std'].replace(np.inf, np.nan).replace(-np.inf, np.nan)

### combine 

icom2 = i_sd.merge(icom, on = ['ticker', 'datadate'], how = 'left')
icom2 = icom2.merge(i_seo_cancel, on = ['ticker', 'datadate'], how = 'left')
icom2 = icom2.sort_values(['ticker', 'datadate'])


# there is only a limited amount of alpha in trample


icom2['test'] = np.nan
icom2.loc[(icom2['issue_m_adjp_dv_std']>0.5)&(icom2['days_since_issue']<=180), 'test'] = 1
icom2.loc[icom2['issue_m_adjp_dv_std']<0, 'test'] = 0
icom2['test'] = icom2.groupby('ticker')['test'].ffill(limit = 60)

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-12-31')].\
            dropna(subset=['test','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test','BarrRet_CLIP_USD+1d', static_data = i_sd) # not very good < 1.0




# there is some alpha in cancel/stop 

icom2['test_cancel'] = np.nan
icom2.loc[icom2['flag_cancel']==1, 'test_cancel'] = -1
icom2['test_cancel'] = icom2.groupby('ticker')['test_cancel'].ffill(limit=2)

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-12-31')].\
            dropna(subset=['test_cancel','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test_cancel','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.06 / 1.42 





# qa

icom2.loc[icom2['test']==1, 'ticker'].unique()

TICKER='601360.SH'

t1 = icom2[icom2.ticker==TICKER]
t1 = t1[['datadate','test','adjc','adjc_issue','issue_m_adjp_dv_std']]


t2 = o_1[o_1.ticker==TICKER]
t2['pnl'] = t2['pnl_ac'].cumsum()
t2['pnl'].plot()


t3 = o_1.groupby('ticker')['pnl_ac'].sum()

