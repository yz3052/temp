﻿#$%^&* prodHKEX_tk_uni_02.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 21 09:55:55 2022

@author: thzhang
"""

import os
import datetime
import pandas as pd

import urllib


proxies = {'http':'http://svc_pm_summit_dev:Feng_001!@proxy.mlp.com:3128',
           'https':'https://svc_pm_summit_dev:Feng_001!@proxy.mlp.com:3128'}



### now    
    
NOW = pd.to_datetime(datetime.datetime.today()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
NOW_datestr = NOW.strftime('%Y%m%d')



### config before download

os.system('mkdir /export/datadev/Data/Scrapers/hkex/'+ NOW_datestr)

#create the object, assign it to a variable
obj_proxy = urllib.request.ProxyHandler(proxies)
# construct a new opener using your proxy settings
opener = urllib.request.build_opener(obj_proxy)
# install the openen on the module-level
urllib.request.install_opener(opener)



### Download

urllib.request.urlretrieve("https://www.hkex.com.hk/-/media/HKEX-Market/Mutual-Market/Stock-Connect/Eligible-Stocks/View-All-Eligible-Securities_xls/Change_of_SSE_Securities_Lists.xls?la=en", 
                           '/export/datadev/Data/Scrapers/hkex/' + NOW_datestr + '/Change_of_SSE_Securities_Lists.xls')

urllib.request.urlretrieve("https://www.hkex.com.hk/-/media/HKEX-Market/Mutual-Market/Stock-Connect/Eligible-Stocks/View-All-Eligible-Securities_xls/SSE_Securities.xls?la=en", 
                           '/export/datadev/Data/Scrapers/hkex/' + NOW_datestr + '/SSE_Securities.xls')

urllib.request.urlretrieve("https://www.hkex.com.hk/-/media/HKEX-Market/Mutual-Market/Stock-Connect/Eligible-Stocks/View-All-Eligible-Securities_xls/Special_SSE_Securities.xls?la=en", 
                           '/export/datadev/Data/Scrapers/hkex/' + NOW_datestr + '/Special_SSE_Securities.xls')

urllib.request.urlretrieve("https://www.hkex.com.hk/-/media/HKEX-Market/Mutual-Market/Stock-Connect/Eligible-Stocks/View-All-Eligible-Securities_xls/SSE_Securities_for_Margin_Trading.xls?la=en", 
                           '/export/datadev/Data/Scrapers/hkex/' + NOW_datestr + '/SSE_Securities_for_Margin_Trading.xls')

urllib.request.urlretrieve("https://www.hkex.com.hk/-/media/HKEX-Market/Mutual-Market/Stock-Connect/Eligible-Stocks/View-All-Eligible-Securities_xls/SSE_Securities_for_Short_Selling.xls?la=en", 
                           '/export/datadev/Data/Scrapers/hkex/' + NOW_datestr + '/SSE_Securities_for_Short_Selling.xls')

urllib.request.urlretrieve("https://www.hk
ex.com.hk/-/media/HKEX-Market/Mutual-Market/Stock-Connect/Eligible-Stocks/View-All-Eligible-Securities_xls/Change_of_SZSE_Securities_Lists.xls?la=en", 
                           '/export/datadev/Data/Scrapers/hkex/' + NOW_datestr + '/Change_of_SZSE_Securities_Lists.xls')

urllib.request.urlretrieve("https://www.hkex.com.hk/-/media/HKEX-Market/Mutual-Market/Stock-Connect/Eligible-Stocks/View-All-Eligible-Securities_xls/SZSE_Securities.xls?la=en", 
                           '/export/datadev/Data/Scrapers/hkex/' + NOW_datestr + '/SZSE_Securities.xls')

urllib.request.urlretrieve("https://www.hkex.com.hk/-/media/HKEX-Market/Mutual-Market/Stock-Connect/Eligible-Stocks/View-All-Eligible-Securities_xls/Special_SZSE_Securities.xls?la=en", 
                           '/export/datadev/Data/Scrapers/hkex/' + NOW_datestr + '/Special_SZSE_Securities.xls')

urllib.request.urlretrieve("https://www.hkex.com.hk/-/media/HKEX-Market/Mutual-Market/Stock-Connect/Eligible-Stocks/View-All-Eligible-Securities_xls/SZSE_Securities_for_Margin_Trading.xls?la=en", 
                           '/export/datadev/Data/Scrapers/hkex/' + NOW_datestr + '/SZSE_Securities_for_Margin_Trading.xls')

urllib.request.urlretrieve("https://www.hkex.com.hk/-/media/HKEX-Market/Mutual-Market/Stock-Connect/Eligible-Stocks/View-All-Eligible-Securities_xls/SZSE_Securities_for_Short_Selling.xls?la=en", 
                           '/export/datadev/Data/Scrapers/hkex/' + NOW_datestr + '/SZSE_Securities_for_Short_Selling.xls')


os.system('chgrp summittrading /export/datadev/Data/Scrapers/hkex/'+ NOW_datestr+' -R;')
os.system('chmod 770 /export/datadev/Data/Scrapers/hkex/'+ NOW_datestr+' -R;')
