﻿#$%^&* pWIND_strat_mutualfund_04.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Jan  9 17:03:53 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu



# this studies wind's ChinaMutualFundPosEstimation (仓位估算)

# all of the below didn't work 


### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['ticker','datadate'])
i_sd['adv_t20d'] = i_sd.groupby('ticker').rolling(20)['V_l1d'].mean().values
i_sd = i_sd.sort_values('datadate')

i_sd_dd = i_sd['datadate'].drop_duplicates()


### mf holding
# holding per disclosure date

i_mf_h = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_wind_holding_mf_q_est.parquet')
i_mf_h = i_mf_h[['datadate','s_info_compcode','ticker_fund','ticker','held_dollar']]

i_mf_h = i_mf_h.sort_values(['s_info_compcode','datadate','ticker'])
i_mf_h = i_mf_h.reset_index(drop=True)

i_mf_h['held_dollar_3bk'] = i_mf_h.groupby(['s_info_compcode', 'datadate'])['held_dollar'].apply(lambda x: yu.pdqcut(x,bins=3)).values
i_mf_h['held_dollar_3bk'] = pd.to_numeric(i_mf_h['held_dollar_3bk'])

i_mf_h = i_mf_h.sort_values('datadate')



### estimated position
# per tdate per ticker

i_estpos = yu.get_sql('''select a.s_info_windcode as ticker_fund, a.f_est_date as datadate,
                      a.f_est_largecapweg as pos_l, a.f_est_midcapweg as pos_m, 
                      a.f_est_smallcapweg as pos_s, a.f_est_position as pos,
                      a.f_est_nav, b.s_info_compcode
                      from wind.dbo.ChinaMutualFundPosEstimation a
                      left join wind.dbo.windcustomcode b
                      on a.s_info_windcode = b.s_info_windcode''') # left join is accurate, no dups

i_estpos['datadate'] = pd.to_datetime(i_estpos['datadate'], format = '%Y%m%d')

i_estpos = i_estpos.sort_values(['ticker_fund','datadate'])
i_estpos['pos_l_1d'] = i_estpos.groupby('ticker_fund')['pos_l'].shift()
i_estpos['pos_m_1d'] = i_estpos.groupby('ticker_fund')['pos_m'].shift()
i_estpos['pos_s_1d'] = i_estpos.groupby('ticker_fund')['pos_s'].shift()

i_estpos_compcode = i_estpos[['datadate','s_info_compcode','ticker_fund']].drop_duplicates(subset=['datadate','s_info_compcode'], keep='first')
i_estpos = i_estpos.merge(i_estpos_compcode, on = ['datadate','s_info_compcode','ticker_fund'], how = 'inner')


i_estpos_l = i_estpos[['datadate','s_info_compcode','pos_l','pos_l_1d']]
i_estpos_l = i_estpos_l.rename(columns={'pos_l':'pos','pos_l_1d':'p
os_1d'})
i_estpos_l['held_dollar_3bk'] = 2.0
i_estpos_m = i_estpos[['datadate','s_info_compcode','pos_m','pos_m_1d']]
i_estpos_m = i_estpos_l.rename(columns={'pos_m':'pos','pos_m_1d':'pos_1d'})
i_estpos_m['held_dollar_3bk'] = 1.0
i_estpos_s = i_estpos[['datadate','s_info_compcode','pos_s','pos_s_1d']]
i_estpos_s = i_estpos_l.rename(columns={'pos_s':'pos','pos_s_1d':'pos_1d'})
i_estpos_s['held_dollar_3bk'] = 0.0

i_estpos_s1 = i_estpos_l.append(i_estpos_m, sort = False)
i_estpos_s1 = i_estpos_s1.append(i_estpos_s, sort = False)
i_estpos_s1 = i_estpos_s1.sort_values('datadate')


### TNA
# per disclosure date

i_tna = yu.get_sql('''select a.s_info_windcode as ticker_fund,
                   a.f_prt_enddate as report_period,
                   a.F_PRT_STOCKVALUE as tna_stock,
                   a.F_PRT_NETASSET as tna_total,
                   a.f_ann_date as datadate,
                   b.s_info_compcode
                   from [WIND].[dbo].[CHINAMUTUALFUNDASSETPORTFOLIO] a
                   left join wind.dbo.windcustomcode b
                   on a.s_info_windcode = b.s_info_windcode
                   ''') # F_PRT_NETASSET
i_tna['datadate'] = pd.to_datetime(i_tna['datadate'])
i_tna['report_period'] = pd.to_datetime(i_tna['report_period'])

i_tna = i_tna.sort_values(['s_info_compcode','ticker_fund','report_period','datadate','tna_stock'])
i_tna = i_tna.drop_duplicates(subset = ['s_info_compcode','report_period','datadate'], keep = 'first')
i_tna = i_tna.reset_index(drop = True)
i_tna = i_tna[['s_info_compcode','datadate','tna_stock','tna_total']]
i_tna = i_tna.sort_values('datadate')



### generate daily flow

o_mf_flow = []

for dt in pd.date_range(start = '2016-01-01', end = '2021-11-01').tolist():
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    t_estpos = i_estpos_s1[i_estpos_s1['datadate']==dt]
    t_estpos = t_estpos.drop(columns=['datadate'])
    if len(t_estpos) == 0:
        continue
    
    t_tna = i_tna[(i_tna['datadate']<=dt)&(i_tna['datadate']>=dt-pd.to_timedelta('182 days'))]
    t_tna = t_tna.drop_duplicates(subset=['s_info_compcode'], keep = 'last')
    t_tna = t_tna.drop(columns=['datadate'])
    
    t_mf_h = i_mf_h[(i_mf_h['datadate']<=dt) & (i_mf_h['datadate']>=dt-pd.to_timedelta('182 days'))]
    t_mf_h_maxdd = t_mf_h.groupby('s_info_compcode')['datadate'].max().reset_index()
    t_mf_h = t_mf_h.merge(t_mf_h_maxdd, on = ['s_info_compcode','datadate'], how = 'inner')
    
    t_mf = t_mf_h.merge(t_estpos, on = ['s_info_compcode',
'held_dollar_3bk'], how = 'inner')
    t_mf = t_mf.merge(t_tna, on = ['s_info_compcode'], how = 'inner')
    t_mf['flow_lvlStk'] = t_mf['tna_stock'].multiply(t_mf['pos'] - t_mf['pos_1d'])
    t_mf['flow_lvlTotal'] = t_mf['tna_total'].multiply(t_mf['pos'] - t_mf['pos_1d'])
    
    t_mf_flow1 = t_mf.groupby('ticker')[['flow_lvlStk','flow_lvlTotal']].sum().reset_index()
    t_mf_flow2 = t_mf.groupby('ticker')['flow_lvlStk'].apply(lambda x: ((x>0).sum()-(x<0).sum())/len(x)).reset_index()
    t_mf_flow2 = t_mf_flow2.rename(columns={'flow_lvlStk':'fund_updn'})
    
    t_mf_flow = t_mf_flow1.merge(t_mf_flow2, on = 'ticker', how = 'outer')
    t_mf_flow['datadate'] = dt
    
    o_mf_flow.append(t_mf_flow)
    
o_mf_flow = pd.concat(o_mf_flow, axis = 0)


### combine

icom = i_sd.merge(o_mf_flow, on = ['ticker','datadate'], how = 'left')
icom['flow_lvlStk_dv_pv'] = icom['flow_lvlStk'].divide(icom['avgPVadj'])
icom['flow_lvlTotal_dv_pv'] = icom['flow_lvlTotal'].divide(icom['avgPVadj'])

icom = icom.sort_values(['ticker','datadate'])

### t1d MF flow

icom['flow_lvlStk_dv_pv_bk'] = icom.groupby('datadate')['flow_lvlStk_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['flow_lvlTotal_dv_pv_bk'] = icom.groupby('datadate')['flow_lvlTotal_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['flow_lvlStk_dv_pv_bk'], 'flow_lvlStk_dv_pv')
yu.create_cn_3x3(icom, ['flow_lvlTotal_dv_pv_bk'], 'flow_lvlTotal_dv_pv')


### t20d MF flow

icom['flow_lvlStk_dv_pv_t20d'] = icom.groupby('ticker').rolling(20)['flow_lvlStk_dv_pv'].mean().values
icom['flow_lvlStk_dv_pv_t20d_bk'] = icom.groupby('datadate')['flow_lvlStk_dv_pv_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['flow_lvlTotal_dv_pv_t20d'] = icom.groupby('ticker').rolling(20)['flow_lvlTotal_dv_pv'].mean().values
icom['flow_lvlTotal_dv_pv_t20d_bk'] = icom.groupby('datadate')['flow_lvlTotal_dv_pv_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['flow_lvlStk_dv_pv_t20d_bk'], 'flow_lvlStk_dv_pv_t20d')
yu.create_cn_3x3(icom, ['flow_lvlTotal_dv_pv_t20d_bk'], 'flow_lvlTotal_dv_pv_t20d')

### t20d MF turnover

icom['flow_lvlStk_abs_dv_pv_t20d'] = icom.groupby('ticker').rolling(20)['flow_lvlStk_dv_pv'].apply(lambda x: np.nanmean(np.abs(x))).values
icom['flow_lvlStk_abs_dv_pv_t20d_bk'] = icom.groupby('datadate')['flow_lvlStk_abs_dv_pv_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['flow_lvlStk_abs_dv_pv_t20d_bk'], 'flow_lvlStk_abs_dv_pv
_t20d')


### up fund - dn fund

icom['fund_updn_bk'] = icom.groupby('datadate')['fund_updn'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['fund_updn_t20d'] = icom.groupby('ticker').rolling(20)['fund_updn'].mean().values
icom['fund_updn_t20d_bk'] = icom.groupby('datadate')['fund_updn_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['fund_updn_bk'], 'fund_updn')
yu.create_cn_3x3(icom, ['fund_updn_t20d_bk'], 'fund_updn_t20d')
