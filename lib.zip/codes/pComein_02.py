﻿#$%^&* pComein_02.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Feb  9 13:16:55 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os



# this tests Liberty Metric's one-time history data since 2016 




### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values('datadate')



### HK calendar

i_hc_cal = yu.get_sql('''select distinct tradedate_last as tdate 
                      from [CNDBPROD].[dbo].[Calendar_Dates_HC]''')
i_hc_cal = i_hc_cal.sort_values(['tdate']).reset_index(drop=True)
i_hc_cal['tdate'] = i_hc_cal['tdate'].dt.strftime('%Y%m%d')
dict_hk_cal = {}
for i,r in i_hc_cal.iterrows():
    dict_hk_cal[r['tdate']] = i
    
i_hc_next_tdate = yu.get_sql('''select datadate , tradedate_next 
                             from [CNDBPROD].[dbo].[Calendar_Dates_HC]''')



### wind: name mapping

i_names = yu.get_sql('''select s_info_windcode, S_INFO_NAME as name from wind.dbo.ASharePreviousName
                     union
                     select s_info_windcode, S_INFO_NAME as name from wind.dbo.AShareDescription''')
i_names = i_names.drop_duplicates()
dict_names = {}
for i,r in i_names.iterrows():
    dict_names[r['name']] = r['s_info_windcode']
list_names = list(dict_names.keys())

def match_first34(i_str):
    if i_str[:4] in list_names:
        return dict_names[i_str[:4]]
    elif i_str[:3] in list_names:
        return dict_names[i_str[:3]]
    else:
        return np.nan
    
    
def match_bySep(i_str, sep):
    
    sep_l3 = i_str.split(sep)[0].strip()[:3]
    sep_l4 = i_str.split(sep)[0].strip()[:4]
    sep_r3 = i_str.split(sep)[1].strip()[:3]
    sep_r4 = i_str.split(sep)[1].strip()[:4]
    
    if (sep_l3 not in list_names) and (sep_l4 not in list_names) and (sep_r4 in list_names):
        return dict_names[sep_r4]
    elif (sep_l3 not in list_names) and (sep_l4 not in list_names) and (sep_r3 in list_names):
        return dict_names[sep_r3]
    elif (sep_r3 not in list_names) and (sep_r4 not in list_names) and (sep_l4 in list_names):
        return dict_names[sep_l4]
    elif (sep_r3 not in list_names) and (sep_r4 not in list_names) and (sep_l3 in list_names):
        return dict_names[sep_l3]
    else:
        return np.nan



### comein
# pagestart: page number
# id: main event id
# stime -> start_time_utc -> start_time_cn
# browsecount: no. of views
# membercount: number of people attending the meeting (in the "play" window)
# status 3: alr
eady happened; 210 not happened 
        
    
i_comein = yu.get_sql('''select * FROM [CNDBDEV].[dbo].[comein_hist]''')

i_comein['loaddt_cn'] = i_comein['stime_dt_cn'] - pd.to_timedelta('5 days')
i_comein.loc[i_comein['loaddt_cn'].dt.hour>=6, 'load_d_cn'] = pd.to_datetime(i_comein.loc[i_comein['loaddt_cn'].dt.hour>=6, 'loaddt_cn'].dt.date + pd.to_timedelta('1 day'))
i_comein.loc[i_comein['loaddt_cn'].dt.hour<6, 'load_d_cn'] = pd.to_datetime(i_comein.loc[i_comein['loaddt_cn'].dt.hour<6, 'loaddt_cn'].dt.date)
i_comein['stime_d_cn'] = pd.to_datetime(i_comein['stime_dt_cn'].dt.date)
i_comein = i_comein.merge(i_hc_next_tdate.rename(columns={'datadate':'load_d_cn','tradedate_next':'datadate_p1d'}),
                          on = 'load_d_cn', how = 'left')

i_comein = i_comein.drop(columns = ['logo','logowall','logoweb','authtag','isnotifi',
                                    'creator_company','browsecount','membercount','playcount',
                                    'presenturl','stime'])

# delete broker name from title
i_comein['uname'] = i_comein['uname'].fillna('')
i_comein['uname'] = i_comein['uname'].replace('zhongjinyanjiubu&gupiaoyewubu','cicc')

i_comein['title_x'] = i_comein.apply(lambda x: x['title'].replace(x['uname'][:4],''), axis=1)
i_comein['title_x'] = i_comein['title_x'].str.replace('zhengquan','').str.replace('shenwanhongyuan','').\
                        str.replace('zhongxinjiantou','').str.replace('guotaijunan','')
                        
i_comein = i_comein[~i_comein['title_x'].str.contains('fenghui')]
i_comein = i_comein[~i_comein['title_x'].str.contains('jidu|yejijiaoliu|niandu|shuominghui|zhongbao|nianbao')]
                        


# tagged tickers
i_comein['ticker'] = i_comein['title_x'].str.extract('[^0-9]([036]\d{5})[^0-9]')
c_sh = (i_comein['ticker'].notnull())&(i_comein['ticker'].str[0].isin(['6']))
c_sz = (i_comein['ticker'].notnull())&(i_comein['ticker'].str[0].isin(['0','3']))
i_comein.loc[c_sh, 'ticker'] = i_comein.loc[c_sh, 'ticker'] + '.SH'
i_comein.loc[c_sz, 'ticker'] = i_comein.loc[c_sz, 'ticker'] + '.SZ'


# no |
c_nol = (~i_comein['title_x'].str.contains('|', regex=False))&(~i_comein['title_x'].str.contains('｜'))&(i_comein['ticker'].isnull())
i_comein.loc[c_nol, 'ticker_nol'] = i_comein.loc[c_nol, 'title_x'].str.strip().apply(match_first34)

# with standard |
c_withl = (i_comein['title_x'].str.contains('|', regex=False)) & (i_comein['ticker'].isnull())
i_comein.loc[c_withl, 'ticker_wstdl'] = i_comein.loc[c_withl, 
'title_x'].apply(lambda x: match_bySep(x, '|'))

# with special |
c_withl2 = (i_comein['title_x'].str.contains('｜', regex=False)) & (i_comein['ticker'].isnull())
i_comein.loc[c_withl2, 'ticker_wspl'] = i_comein.loc[c_withl2, 'title_x'].apply(lambda x: match_bySep(x,'｜'))

# with -
c_withl2 = (i_comein['title_x'].str.contains('-', regex=False)) & (i_comein['ticker'].isnull())
i_comein.loc[c_withl2, 'ticker_wdash'] = i_comein.loc[c_withl2, 'title_x'].apply(lambda x: match_bySep(x,'-'))

# with standard :
c_withl2 = (i_comein['title_x'].str.contains(':', regex=False)) & (i_comein['ticker'].isnull())
i_comein.loc[c_withl2, 'ticker_wstdcolon'] = i_comein.loc[c_withl2, 'title_x'].apply(lambda x: match_bySep(x,':'))

# with special :
c_withl2 = (i_comein['title_x'].str.contains('：', regex=False)) & (i_comein['ticker'].isnull())
i_comein.loc[c_withl2, 'ticker_wspcolon'] = i_comein.loc[c_withl2, 'title_x'].apply(lambda x: match_bySep(x,'：'))


# combine tickers
i_comein.loc[i_comein['ticker'].isnull(),'ticker'] = i_comein.loc[i_comein['ticker'].isnull(),'ticker_wstdl']
i_comein.loc[i_comein['ticker'].isnull(),'ticker'] = i_comein.loc[i_comein['ticker'].isnull(),'ticker_nol']
i_comein.loc[i_comein['ticker'].isnull(),'ticker'] = i_comein.loc[i_comein['ticker'].isnull(),'ticker_wspl']
i_comein.loc[i_comein['ticker'].isnull(),'ticker'] = i_comein.loc[i_comein['ticker'].isnull(),'ticker_wdash']
i_comein.loc[i_comein['ticker'].isnull(),'ticker'] = i_comein.loc[i_comein['ticker'].isnull(),'ticker_wstdcolon']
i_comein.loc[i_comein['ticker'].isnull(),'ticker'] = i_comein.loc[i_comein['ticker'].isnull(),'ticker_wspcolon']
#i_comein[['id','title','ticker']].to_csv(r'S:\Data\China Data Hunt\cache\comein_ticker_tagging.csv') ###!!!

# select tagged rows
i_comein_s2 = i_comein[i_comein['ticker'].notnull()] # datadate same definition as my convention


### summarize meetings per tk + datadate

i_comein_sum = i_comein_s2.groupby(['ticker','datadate_p1d'])['id'].nunique().reset_index()

t1 = i_comein_sum.groupby('datadate_p1d')['ticker'].nunique()
t1 = i_comein[i_comein['datadate_p1d']=='2021-08-30']


### combine

icom = i_sd.merge(i_comein_sum, on = ['ticker','datadate_p1d'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])
icom.loc[icom['id'].notnull(), 'meeting_sgnl'] = 1

icom['meeting_sgnl_ffill1'] = icom.groupby('ticker')['meeting_sgnl'].ffill(limit = 1)
icom['meeting_sgnl_ffill2'] = icom.groupby('ticker')['meeting_sgnl'].ffill(limit = 2)
icom['meeting_sgnl_ffil
l3'] = icom.groupby('ticker')['meeting_sgnl'].ffill(limit = 3)
icom['meeting_sgnl_ffill4'] = icom.groupby('ticker')['meeting_sgnl'].ffill(limit = 4)
icom['meeting_sgnl_ffill5'] = icom.groupby('ticker')['meeting_sgnl'].ffill(limit = 5)


# yu.create_cn_decay(icom, 'meeting_sgnl')

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['meeting_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'meeting_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['meeting_sgnl_ffill1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'meeting_sgnl_ffill1','BarrRet_CLIP_USD+1d', static_data = i_sd)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['meeting_sgnl_ffill2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'meeting_sgnl_ffill2','BarrRet_CLIP_USD+1d', static_data = i_sd)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['meeting_sgnl_ffill3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'meeting_sgnl_ffill3','BarrRet_CLIP_USD+1d', static_data = i_sd)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['meeting_sgnl_ffill4','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'meeting_sgnl_ffill4','BarrRet_CLIP_USD+1d', static_data = i_sd)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['meeting_sgnl_ffill5','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'meeting_sgnl_ffill5','BarrRet_CLIP_USD+1d', static_data = i_sd)









### combine (comein)
# in 01, we only selected meetings that are disclosed more than 2 trading days ago 

icom = i_comein_s2.merge(i_hc_next_tdate, left_on='datadate', right_on = ['datadate'], how = 'left')
icom = icom.rename(columns = {''})
icom2 = i_sd.merge(icom, on = ['datadate_p1d','ticker'], how = 'left')
icom2 = icom2.sort_values(['ticker','datadate'])


### naive: long before events

icom2['naive_sgnl'] = np.nan
icom2.loc[icom2['td2m']>2, 'naive_sgnl'] = 1

icom2['naive_sgnl'] = icom2.groupby('ticker')['naive_sgnl'].ffill(limit=10)


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2021-12-31')].\
            dropna(subset=['naive_sgnl','BarrRet_CLIP_USD+1d']).drop_dupli
cates(subset=['ticker','datadate']),
            'naive_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #3.28/2.36, 6.69bp/d, 2.8e6

