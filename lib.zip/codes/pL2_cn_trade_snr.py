﻿#$%^&* pL2_cn_trade_snr.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  6 10:50:04 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine


#  This studies SNR intraday


### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])



### snr

i_snr = yu.get_q("get `:/export/datadev/Data/SHSZ/TRADE_metrics/trade_1min_snr")


#i_snr['code'] = i_snr['code'].str.decode('utf8')
#c_sh = i_snr['code'].str[0].isin(['6'])
#c_sz = i_snr['code'].str[0].isin(['0','3'])
#i_snr.loc[c_sh, 'ticker'] = i_snr.loc[c_sh, 'code'] + '.SH'
#i_snr.loc[c_sz, 'ticker'] = i_snr.loc[c_sz, 'code'] + '.SZ'
i_snr['ticker'] = i_snr['code'].str.decode('utf8')
i_snr['datadate'] = pd.to_datetime(i_snr['date'])
i_snr = i_snr.sort_values(['ticker', 'datadate'])




### combine 

icom = i_sd.merge(i_snr, on = ['ticker', 'datadate'], how = 'left')
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']

cs = ['snr_lv01', 'snr_lv12', 'snr_lv02', 'snr_lv01_xO',
       'snr_lv12_xO', 'snr_lv01_xOC', 'snr_lv12_xOC']

for c in cs:
    icom[c+'_bk'] = icom.groupby('datadate')[c].apply(lambda x: yu.pdqcut(x,bins=10)).values
    yu.create_cn_3x3(icom, [c+'_bk'], c)
    
for c in cs:
    icom[c+'_orth'] = icom.groupby('datadate')[COLS+[c]].apply(lambda x: yu.orthogonalize_cn(x[c], x[COLS])).values
    icom[c+'_orth_bk'] = icom.groupby('datadate')[c+'_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
    yu.create_cn_3x3(icom, [c+'_orth_bk'], c+'_orth')

icom['snr_lv02_sgnl'] = icom.groupby('datadate')['snr_lv02'].apply(yu.uniformed_rank).values
icom['snr_lv02_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['snr_lv02'].mean().values
icom['snr_lv02_t20d_sgnl'] = icom.groupby('datadate')['snr_lv02_t20d'].apply(yu.uniformed_rank).values

icom['snr_lv02_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['snr_lv02_orth'].mean().values
icom['snr_lv02_orth_t20d_sgnl'] = icom.groupby('datadate')['snr_lv02_orth_t20d'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['snr_lv02_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'snr_lv02_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.28-22
o_1 = yu.bt_cn_15(icom[(icom['d
atadate']<='2020-12-31')].\
            dropna(subset=['snr_lv02_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'snr_lv02_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 


icom['snr_lv01_xO_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['snr_lv01_xO_orth'].mean().values
icom['snr_lv01_xO_orth_t20d_bk'] = icom.groupby('datadate')['snr_lv01_xO_orth_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['snr_lv01_xO_orth_t20d_sgnl'] = icom.groupby('datadate')['snr_lv01_xO_orth_t20d'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['snr_lv01_xO_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'snr_lv01_xO_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.4/-27

