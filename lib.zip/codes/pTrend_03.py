﻿#$%^&* pTrend_03.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat Dec 19 08:46:01 2020

@author: thzhang
"""
import pandas as pd
import numpy as np 

from numba import njit

from hurst import compute_Hc

from yz.util import get_sd, tic, toc, ta_best_ma_period, ta_hurst, bt

# first find stocks whose bret pid is time persistent (i.e. very trendy)
# 

# get bret data
i_sd = get_sd(column_type = 'backtest') #T-1d -> datadate
i_sd = i_sd.sort_values(['ticker','datadate'])
i_sd['bret_pid'] = i_sd.groupby('ticker')['BarrRet_SRISK-1d'].cumsum() #verified -1d = datadate

# fillin missing datadates
pv_pid = i_sd.pivot_table(index = 'datadate', columns = 'ticker', values = 'bret_pid')
df_pid = pv_pid.reset_index().melt(id_vars = 'datadate', value_vars = pv_pid.columns.tolist(), value_name = 'bret_pid')
del pv_pid

# hurst #400s
df_pid['hurst'] = df_pid.rolling(440)['bret_pid'].apply(ta_hurst, raw = True) 

# optimal periods # 400s
df_pid['opt_ma_period'] = df_pid.groupby('ticker')['bret_pid'].rolling(90).\
                          apply(lambda x: ta_best_ma_period(x, lower_limit=30, upper_limit = 90), raw = True).values

# tk hash
df_pid['tk_hash'] = df_pid['ticker'].apply(hash)

# ema
# ['datadate', 'ticker', 'bret_pid', 'hurst', 'opt_ma_period', 'tk_hash']
df_pid['ema90'] = df_pid.groupby('ticker')['bret_pid'].transform(lambda x: x.ewm(halflife=90, min_periods=90).mean())
df_pid.loc[df_pid['bret_pid'].isnull(),'ema90'] = np.nan

c_top = (df_pid['tk_hash'] == df_pid['tk_hash'].shift()) & (df_pid['tk_hash'] == df_pid['tk_hash'].shift(-1)) &\
        (df_pid['ema90']>df_pid['ema90'].shift()) & (df_pid['ema90']>df_pid['ema90'].shift(-1))
c_bottom = (df_pid['tk_hash'] == df_pid['tk_hash'].shift()) & (df_pid['tk_hash'] == df_pid['tk_hash'].shift(-1)) &\
           (df_pid['ema90']<df_pid['ema90'].shift()) & (df_pid['ema90']<df_pid['ema90'].shift(-1))
df_pid.loc[c_top,'ema90_top'] = 1
df_pid.loc[c_bottom,'ema90_bottom'] = 1

df_pid['bret_pid_std'] = df_pid.groupby('ticker')['bret_pid'].rolling(90).std(skipna = False).values
df_pid['ema90+1std'] = df_pid['ema90'] + df_pid['bret_pid_std']
df_pid['ema90-1std'] = df_pid['ema90'] - df_pid['bret_pid_std']

# ema index
@njit
def ema_index(arr):
    o_index = [np.nan]*len(arr)
    for i in range(1, len(arr)):
        if arr[i] > arr[i-1]:
            if np.isnan(o_index[i-1]):
                o_index[i] = 1
            elif o_index[i-1]>0:
                o_index[i] = o_index[i-1]+1
            elif o_index[i-1]<0:
        
        o_index[i] = 1
        elif arr[i] < arr[i-1]:
            if np.isnan(o_index[i-1]):
                o_index[i] = -1
            elif o_index[i-1]>0:
                o_index[i] = -1
            elif o_index[i-1]<0:
                o_index[i] = o_index[i-1]-1
        elif arr[i] == arr[i-1]:
            if np.isnan(o_index[i-1]):
                o_index[i] = np.nan
            elif o_index[i-1]>0:
                o_index[i] = o_index[i-1]+1
            elif o_index[i-1]<0:
                o_index[i] = o_index[i-1]-1
    return np.array(o_index)
df_pid['ema90_index'] = df_pid.groupby('ticker')['ema90'].transform(lambda x: ema_index(x.values))
df_pid.loc[df_pid['bret_pid'].isnull(),'ema90_index'] = np.nan

df_pid.to_parquet(r'S:\Data\test\pTrend03_df_pid.parquet') ###!!!

#------------------------------------------------------------------------------
### vizualize helper
from bokeh.io import show
from bokeh.layouts import column, gridplot
from bokeh.models import ColumnDataSource, RangeTool, HoverTool, CustomJS, CrosshairTool, LinearAxis, Range1d
from bokeh.plotting import figure
def ptrend_viz(df_pid, TICKER):
    i_data = df_pid[df_pid.ticker==TICKER]
    # main chart
    p_main = figure(plot_height=400, plot_width=1600, tools="pan,wheel_zoom,reset", toolbar_location='right',
                   x_axis_type="datetime", x_axis_location="below", title = TICKER,
                   background_fill_color="#ffffff",
                   x_range=(i_data.datadate.min(), i_data.datadate.max()),
                   y_range=(min(-0.01, i_data['bret_pid'].min()),max(0.01, i_data['bret_pid'].max())) )
    p_main.xaxis.major_label_orientation = 3.1415/4
    p_main_p_index = ColumnDataSource(data=dict(date=i_data['datadate'], p_index = i_data.set_index('datadate')['bret_pid'] ))
    p_main.circle('date', 'p_index', source=p_main_p_index, fill_color = 'indigo', size = 4)
    p_main.yaxis.axis_label = 'bret_pid'
    p_main.xaxis[0].ticker.desired_num_ticks = 40
    if 'pstD' in i_data.columns:
        i_data['pstD'] = i_data['pstD'].fillna(0)
        i_pstD = ColumnDataSource(data=dict(date=i_data['datadate'], pstD = i_data['pstD'] ))
        p_main.varea(source=i_pstD, x="date", y1=0, y2="pstD",alpha=0.2, fill_color='#55FF88')    
    # main chart: boll
    boll_u = ColumnDataSource(data=dict(date=i_data['datadate'], boll_u=i_data['boll_u']))
    p_main.line('date', 'boll_u', source=boll_u, line_color = 'coral', line_width = 0.8, line_alpha = 0.7)
    boll_l = ColumnD
ataSource(data=dict(date=i_data['datadate'], boll_l=i_data['boll_l']))
    p_main.line('date', 'boll_l', source=boll_l, line_color = 'coral', line_width = 0.8, line_alpha = 0.7)
    p_main.add_tools(HoverTool(tooltips=[('date','@date{%F}'),('p_index','@{p_index}{0.3f}')],formatters ={'date':'datetime'}))
    # 2nd chart: macd
    p_2 = figure(x_axis_type="datetime", tools="pan,wheel_zoom,box_zoom,reset", plot_width=1600, plot_height = 150,
                 x_range = p_main.x_range)
    p_2.xaxis.major_label_orientation = 3.1415/4
    p_2.grid.grid_line_alpha=0.3
    p_2.xaxis[0].ticker.desired_num_ticks = 40
    i_data.loc[i_data['macd_hist']>=0,'macd_hist_positive']  = i_data.loc[i_data['macd_hist']>=0,'macd_hist']
    i_data.loc[i_data['macd_hist']<0,'macd_hist_negative']  = i_data.loc[i_data['macd_hist']<0,'macd_hist']
    macd_hist = ColumnDataSource(data=dict(date=i_data['datadate'], hist=i_data['macd_hist_positive']))
    macd_hist2 = ColumnDataSource(data=dict(date=i_data['datadate'], hist2=i_data['macd_hist_negative']))
    p_2.circle('date', 'hist', source=macd_hist,  size = 2, fill_color = 'green', line_color='green')
    p_2.circle('date', 'hist2', source=macd_hist2, size = 2, fill_color = 'red', line_color='red')
    p_2.add_tools(HoverTool(tooltips=[('date','@date{%F}'),('hist','@{hist}{0.55555f}'),('hist2','@{hist2}{0.55555f}')],formatters ={'date':'datetime'},mode='vline'))
    
    # 3rd chart: uo
    p_3 = figure(x_axis_type="datetime", tools="pan,wheel_zoom,box_zoom,reset", plot_width=1600, plot_height = 150,
                 x_range = p_main.x_range)
    p_3.xaxis.major_label_orientation = 3.1415/4
    p_3.grid.grid_line_alpha=0.3
    p_3.xaxis[0].ticker.desired_num_ticks = 40
    uo = ColumnDataSource(data=dict(date=i_data['datadate'], uo=i_data['uo']))
    p_3.line('date', 'uo', source=uo, line_color = 'orange', line_width = 0.8, line_alpha = 0.7)
    p_3.add_tools(HoverTool(tooltips=[('date','@date{%F}'),('uo','@{uo}{0.55555f}')],formatters ={'date':'datetime'},mode='vline'))
    # slider
    slider = figure(plot_height=40, plot_width=1600, #y_range=p_main.y_range,
                    x_axis_type="datetime", y_axis_type=None,
                    tools="", toolbar_location=None, background_fill_color="#efefef")        
    slider_range_tool = RangeTool(x_range=p_main.x_range)
    slider_range_tool.overlay.fill_color = "navy"
    slider_range_tool.overlay.fill_alpha = 0.2
    slider_c = ColumnDataSource(data=dict(date=i_data.datadate, s
lider_c=i_data['bret_pid']))
    slider.line('date', 'slider_c', source=slider_c, line_color = 'blue', line_width = 1)
    slider.ygrid.grid_line_color = None
    slider.add_tools(slider_range_tool)
    slider.toolbar.active_multi = slider_range_tool
    slider.axis.visible = False
    show(gridplot([[p_main],[p_2],[p_3], [slider]]))
ptrend_viz(df_pid,'ABMD')


#------------------------------------------------------------------------------
### strat 1: a quick test: truning -> retracement -> open

# identify turning point
@njit
def turning_point(x):
    if np.any(x<-90) and x[len(x)-1] > 10:
        return 1
    elif np.any(x>90) and x[len(x)-1] < -10:
        return -1
    else:
        return np.nan
df_pid['had_turning_point'] = df_pid.groupby('ticker')['ema_index'].rolling(180).apply(turning_point, raw=True).values

# identify open sngl
@njit
def sgnl_open(arr_pid, arr_ema, arr_has_turning_point, arr_tk_hash):
    o_open_sgnl = [np.nan] * len(arr_pid)
    for i in range(90, len(arr_pid)):
        if arr_tk_hash[i] != arr_tk_hash[i-90]:
            continue
        if arr_has_turning_point[i] == 1:
            if (arr_pid[i] - arr_ema[i] < np.std(arr_pid[i-90:i+1])*0.2) & np.any(arr_pid[i-20:i] - arr_ema[i-20:i] > np.std(arr_pid[i-90:i+1])*0.8):
                o_open_sgnl[i] = 1
        elif arr_has_turning_point[i] == -1:
            if (arr_ema[i] - arr_pid[i] < np.std(arr_pid[i-90:i+1])*0.2) & np.any(arr_ema[i-20:i] - arr_pid[i-20:i] > np.std(arr_pid[i-90:i+1])*0.8):
                o_open_sgnl[i] = -1
    return np.array(o_open_sgnl)
df_pid['sgnl_open'] = sgnl_open(df_pid['bret_pid'].values,df_pid['ema90'].values,
                                df_pid['had_turning_point'].values, df_pid['tk_hash'].values)

# pst
tic()
pst = [np.nan] * len(df_pid)
std_on_open = [np.nan] * len(df_pid)
pid_on_open = [np.nan] * len(df_pid)
bars_since_open = [0] * len(df_pid)
pnl_gt_1std = [np.nan] * len(df_pid)
for i in range(len(df_pid)):
    # tk same
    if df_pid['tk_hash'].values[i] != df_pid['tk_hash'].values[i-1]:
        continue
    # hold
    if pst[i-1]>0:
        pst[i] = pst[i-1]
        std_on_open[i] = std_on_open[i-1]
        pid_on_open[i] = pid_on_open[i-1]
        bars_since_open[i] = bars_since_open[i-1]+1
        if (df_pid['bret_pid'].values[i] - pid_on_open[i]) > std_on_open[i]:
            pnl_gt_1std[i] = 1
        else: 
            pnl_gt_1std[i] = pnl_gt_1std[i-1]
    elif pst[i-1]<0:
        pst[i] = pst[i-1]
        std_on_open[i] = std_on
_open[i-1]
        pid_on_open[i] = pid_on_open[i-1]
        bars_since_open[i] = bars_since_open[i-1]+1
        if (-df_pid['bret_pid'].values[i] + pid_on_open[i]) > std_on_open[i]:
            pnl_gt_1std[i] = 1
        else: 
            pnl_gt_1std[i] = pnl_gt_1std[i-1]
    # close
    if pst[i-1]>0: # + pst
        if (df_pid['bret_pid'].values[i] - pid_on_open[i]) > 3*std_on_open[i]  : # stop win
            pst[i] = 0
        elif (pnl_gt_1std[i] == 1) & ((df_pid['bret_pid'].values[i] - pid_on_open[i]) < -0.5 * std_on_open[i]): # scratch
            pst[i] = 0
        elif (df_pid['bret_pid'].values[i] - pid_on_open[i]) < -1.5 * std_on_open[i]: # stop loss
            pst[i] = 0
    elif pst[i-1]<0: # - pst
        if (-df_pid['bret_pid'].values[i] + pid_on_open[i]) > 3*std_on_open[i]: # stop win
            pst[i] = 0
        elif (pnl_gt_1std[i] == 1) & ((-df_pid['bret_pid'].values[i] + pid_on_open[i]) < -0.5*std_on_open[i]): # scratch
            pst[i] = 0
        elif (-df_pid['bret_pid'].values[i] + pid_on_open[i]) < -1.5*std_on_open[i]: # stop loss
            pst[i] = 0
    # open
    if (df_pid['sgnl_open'].values[i]==1)&((pst[i-1]<=0)|np.isnan(pst[i-1])):
        pst[i] = 1
        std_on_open[i] = max(df_pid['bret_pid_std'].values[i],0.04)
        pid_on_open[i] = df_pid['bret_pid'].values[i]
        bars_since_open[i] = 1
        pnl_gt_1std[i] = 0
    elif (df_pid['sgnl_open'].values[i]==-1)&((pst[i-1]>=0)|np.isnan(pst[i-1])):
        pst[i] = -1
        std_on_open[i] = max(df_pid['bret_pid_std'].values[i],0.04)
        pid_on_open[i] = df_pid['bret_pid'].values[i]
        bars_since_open[i] = 1
        pnl_gt_1std[i] = 0
toc()
df_pid['pst']=pst
df_pid['std_on_open']=std_on_open
df_pid['pid_on_open']=pid_on_open
df_pid['bars_since_open']=bars_since_open
df_pid['pnl_gt_1std']=pnl_gt_1std


sd_pid = df_pid.merge(i_sd[['datadate','ticker','BarrRet_SRISK+1d']],on=['datadate','ticker'],how='left')
o3 = bt(sd_pid[sd_pid.datadate<='2019-03-01'].dropna(subset=['pst','BarrRet_SRISK+1d']).drop_duplicates(subset=['ticker','datadate']),
                      'pst','BarrRet_SRISK+1d', sgnl_before_3pm = False)


#------------------------------------------------------------------------------
### strat2: change direction after a long trend

# the code below is still wrong
# stop win criteria wrong
# after stop win there needs to be a cooling period 

df_pid = pd.read_parquet(r'S:\Data\test\pTrend03_df_pid.parquet')

df_pid = df_pid.merge(i_sd[['datada
te','ticker','avgPV_l1d']],on=['datadate','ticker'],how='left')




# identify turning point
@njit
def turning_point(x):
    if np.any(x<-330) and np.any(x>60):
        return 1
    elif np.any(x>330) and np.any(x<-60):
        return -1
    else:
        return np.nan
df_pid['had_turning_point'] = df_pid.groupby('ticker')['ema_index'].rolling(120).apply(turning_point, raw=True).values

# identify open sngl
@njit
def sgnl_open(arr_pid, arr_ema, arr_has_turning_point, arr_tk_hash):
    o_open_sgnl = [np.nan] * len(arr_pid)
    for i in range(330, len(arr_pid)):
        if arr_tk_hash[i] != arr_tk_hash[i-330]:
            continue
        if arr_has_turning_point[i] == 1:
            if np.any(arr_pid[i-30:i] - arr_ema[i-30:i] > 0) & (arr_ema[i] - arr_pid[i] > np.std(arr_pid[i-90:i+1])*0.4):
                o_open_sgnl[i] = 1
        elif arr_has_turning_point[i] == -1:
            if np.any(arr_ema[i-20:i] - arr_pid[i-20:i] > 0) & (arr_pid[i] - arr_ema[i] > np.std(arr_pid[i-90:i+1])*0.4):
                o_open_sgnl[i] = -1
    return np.array(o_open_sgnl)
df_pid['sgnl_open'] = sgnl_open(df_pid['bret_pid'].values,df_pid['ema90'].values,
                                df_pid['had_turning_point'].values, df_pid['tk_hash'].values)

# pst
tic()
pst = [np.nan] * len(df_pid)
std_on_open = [np.nan] * len(df_pid)
pid_on_open = [np.nan] * len(df_pid)
bars_since_open = [0] * len(df_pid)
pnl_gt_1std = [np.nan] * len(df_pid)
stop_threshold = [np.nan] * len(df_pid)
for i in range(len(df_pid)):
    # tk same
    if df_pid['tk_hash'].values[i] != df_pid['tk_hash'].values[i-1]:
        continue
    # hold
    if pst[i-1]>0:
        pst[i] = pst[i-1]
        std_on_open[i] = std_on_open[i-1]
        pid_on_open[i] = pid_on_open[i-1]
        bars_since_open[i] = bars_since_open[i-1]+1
        stop_threshold[i] = stop_threshold[i-1]
        if (df_pid['bret_pid'].values[i] - pid_on_open[i]) > std_on_open[i]:
            pnl_gt_1std[i] = 1
        else: 
            pnl_gt_1std[i] = pnl_gt_1std[i-1]
    elif pst[i-1]<0:
        pst[i] = pst[i-1]
        std_on_open[i] = std_on_open[i-1]
        pid_on_open[i] = pid_on_open[i-1]
        bars_since_open[i] = bars_since_open[i-1]+1
        stop_threshold[i] = stop_threshold[i-1]
        if (-df_pid['bret_pid'].values[i] + pid_on_open[i]) > std_on_open[i]:
            pnl_gt_1std[i] = 1
        else: 
            pnl_gt_1std[i] = pnl_gt_1std[i-1]
    # close
    if pst[i-1]>0: # + pst
        if (df_pid['bret_pid_std'].values[i]>
pid_on_open[i]) and (df_pid['ema_index'].values[i-1]>=10) and (df_pid['ema_index'].values[i]<0): # stop win
            pst[i] = 0
        elif df_pid['bret_pid'].values[i] < stop_threshold[i]: # stop loss
            pst[i] = 0
    elif pst[i-1]<0: # - pst
        if (df_pid['bret_pid_std'].values[i]<pid_on_open[i]) and (df_pid['ema_index'].values[i-1]<=-10) and (df_pid['ema_index'].values[i]>0): # stop win
            pst[i] = 0
        elif df_pid['bret_pid'].values[i] > stop_threshold[i]: # stop loss
            pst[i] = 0
    # open
    if (df_pid['sgnl_open'].values[i]==1)&((pst[i-1]<=0)|np.isnan(pst[i-1])):
        pst[i] = min(df_pid['avgPV_l1d'].values[i]*0.01,1e6)
        std_on_open[i] = max(df_pid['bret_pid_std'].values[i],0.04)
        pid_on_open[i] = df_pid['bret_pid'].values[i]
        bars_since_open[i] = 1
        pnl_gt_1std[i] = 0
        stop_threshold[i] = np.min(df_pid['bret_pid'].values[i-300:i+1])
    elif (df_pid['sgnl_open'].values[i]==-1)&((pst[i-1]>=0)|np.isnan(pst[i-1])):
        pst[i] = -min(df_pid['avgPV_l1d'].values[i]*0.01,1e6)
        std_on_open[i] = max(df_pid['bret_pid_std'].values[i],0.04)
        pid_on_open[i] = df_pid['bret_pid'].values[i]
        bars_since_open[i] = 1
        pnl_gt_1std[i] = 0
        stop_threshold[i] = np.max(df_pid['bret_pid'].values[i-300:i+1])
toc()
df_pid['pstD']=pst
df_pid['std_on_open']=std_on_open
df_pid['pid_on_open']=pid_on_open
df_pid['bars_since_open']=bars_since_open
df_pid['pnl_gt_1std']=pnl_gt_1std
df_pid['stop_threshold'] = stop_threshold


sd_pid = df_pid.merge(i_sd[['datadate','ticker','BarrRet_SRISK+1d']],on=['datadate','ticker'],how='left')
sd_pid['pstC'] = sd_pid['pstD'].divide(sd_pid['avgPV_l1d']*0.01)
o3 = bt(sd_pid[sd_pid.datadate<='2019-03-01'].dropna(subset=['pstC','BarrRet_SRISK+1d']).drop_duplicates(subset=['ticker','datadate']),
                      'pstC','BarrRet_SRISK+1d', sgnl_before_3pm = False)

#------------------------------------------------------------------------------
### strat3: technical indicator quick test
# long when MACD hist >0; short when MACD hist <0

df_pid = pd.read_parquet(r'S:\Data\test\pTrend03_df_pid.parquet')
df_pid = df_pid.merge(i_sd[['datadate','ticker','avgPV_l1d']],on=['datadate','ticker'],how='left')

# MACD
df_pid['ema60'] = df_pid.groupby('ticker')['bret_pid'].transform(lambda x: x.ewm(halflife=60, min_periods=60).mean())
df_pid.loc[df_pid['bret_pid'].isnull(),'ema60'] = np.nan
df_pid['ema28'] = df_pid.groupby('ticker')['bret_pi
d'].transform(lambda x: x.ewm(halflife=28, min_periods=28).mean())
df_pid.loc[df_pid['bret_pid'].isnull(),'ema28'] = np.nan
df_pid['macd'] = df_pid['ema28'] - df_pid['ema60']
df_pid['macd_signal'] = df_pid.groupby('ticker')['macd'].transform(lambda x: x.ewm(halflife=9, min_periods=9).mean())
df_pid['macd_hist'] = df_pid['macd'] - df_pid['macd_signal']

# ultimate oscillator
df_pid['uo_bp_dv_tr'] = df_pid.groupby('ticker')['bret_pid'].rolling(5).apply(lambda x: (x[-1]-np.min(x))/(np.max(x)-np.min(x)),raw = True).values
df_pid['uo_a5'] = df_pid.groupby('ticker')['uo_bp_dv_tr'].rolling(5).mean().values
df_pid['uo_a10'] = df_pid.groupby('ticker')['uo_bp_dv_tr'].rolling(10).mean().values
df_pid['uo_a20'] = df_pid.groupby('ticker')['uo_bp_dv_tr'].rolling(20).mean().values
df_pid['uo'] = (df_pid['uo_a5']*4 + df_pid['uo_a10']*2 + df_pid['uo_a20'])/7

# boll
df_pid['std220'] = df_pid.groupby('ticker')['bret_pid'].rolling(220).std().values
df_pid['boll_u'] = df_pid['ema60'] + df_pid['std220']*2
df_pid['boll_l'] = df_pid['ema60'] - df_pid['std220']*2



# pst
tic()
pst = [np.nan] * len(df_pid)
std_on_open = [np.nan] * len(df_pid)
pid_on_open = [np.nan] * len(df_pid)
bars_since_open = [0] * len(df_pid)
pnl_gt_1std = [np.nan] * len(df_pid)
stop_threshold = [np.nan] * len(df_pid)
for i in range(300,len(df_pid)):
    # tk same
    if df_pid['tk_hash'].values[i] != df_pid['tk_hash'].values[i-1]:
        continue
    # hold
    if pst[i-1]>0:
        pst[i] = pst[i-1]
        std_on_open[i] = std_on_open[i-1]
        pid_on_open[i] = pid_on_open[i-1]
        bars_since_open[i] = bars_since_open[i-1]+1
        stop_threshold[i] = stop_threshold[i-1]
        if (df_pid['bret_pid'].values[i] - pid_on_open[i]) > std_on_open[i]:
            pnl_gt_1std[i] = 1
        else: 
            pnl_gt_1std[i] = pnl_gt_1std[i-1]
    elif pst[i-1]<0:
        pst[i] = pst[i-1]
        std_on_open[i] = std_on_open[i-1]
        pid_on_open[i] = pid_on_open[i-1]
        bars_since_open[i] = bars_since_open[i-1]+1
        stop_threshold[i] = stop_threshold[i-1]
        if (-df_pid['bret_pid'].values[i] + pid_on_open[i]) > std_on_open[i]:
            pnl_gt_1std[i] = 1
        else: 
            pnl_gt_1std[i] = pnl_gt_1std[i-1]
#    # close
#    if pst[i-1]>0: # + pst
#        if (df_pid['bret_pid_std'].values[i]>pid_on_open[i]) and (df_pid['ema_index'].values[i-1]>=10) and (df_pid['ema_index'].values[i]<0): # stop win
#            pst[i] = 0
#        elif df_pid['bret_pid'].values[i] < stop_t
hreshold[i]: # stop loss
#            pst[i] = 0
#    elif pst[i-1]<0: # - pst
#        if (df_pid['bret_pid_std'].values[i]<pid_on_open[i]) and (df_pid['ema_index'].values[i-1]<=-10) and (df_pid['ema_index'].values[i]>0): # stop win
#            pst[i] = 0
#        elif df_pid['bret_pid'].values[i] > stop_threshold[i]: # stop loss
#            pst[i] = 0
    # open
    if (df_pid['macd_hist'].values[i-1]<0)&(df_pid['macd_hist'].values[i]>0)&((pst[i-1]<=0)|np.isnan(pst[i-1])):
        pst[i] = min(df_pid['avgPV_l1d'].values[i]*0.01,1e6)
        std_on_open[i] = max(df_pid['bret_pid_std'].values[i],0.04)
        pid_on_open[i] = df_pid['bret_pid'].values[i]
        bars_since_open[i] = 1
        pnl_gt_1std[i] = 0
        stop_threshold[i] = np.min(df_pid['bret_pid'].values[i-300:i+1])
    elif (df_pid['macd_hist'].values[i-1]>0)&(df_pid['macd_hist'].values[i]<0)&((pst[i-1]>=0)|np.isnan(pst[i-1])):
        pst[i] = -min(df_pid['avgPV_l1d'].values[i]*0.01,1e6)
        std_on_open[i] = max(df_pid['bret_pid_std'].values[i],0.04)
        pid_on_open[i] = df_pid['bret_pid'].values[i]
        bars_since_open[i] = 1
        pnl_gt_1std[i] = 0
        stop_threshold[i] = np.max(df_pid['bret_pid'].values[i-300:i+1])
toc()
df_pid['pstD']=pst
df_pid['std_on_open']=std_on_open
df_pid['pid_on_open']=pid_on_open
df_pid['bars_since_open']=bars_since_open
df_pid['pnl_gt_1std']=pnl_gt_1std
df_pid['stop_threshold'] = stop_threshold


sd_pid = df_pid.merge(i_sd[['datadate','ticker','BarrRet_SRISK+1d']],on=['datadate','ticker'],how='left')
sd_pid['pstC'] = sd_pid['pstD'].divide(sd_pid['avgPV_l1d']*0.01)
o3 = bt(sd_pid[sd_pid.datadate<='2019-03-01'].dropna(subset=['pstC','BarrRet_SRISK+1d']).drop_duplicates(subset=['ticker','datadate']),
                      'pstC','BarrRet_SRISK+1d', sgnl_before_3pm = False)

#------------------------------------------------------------------------------
### strat4: technical indicator quick test
# long when MACD hist starts to increase; short when MACD hist starts to decrease

df_pid = pd.read_parquet(r'S:\Data\test\pTrend03_df_pid.parquet')
df_pid = df_pid.merge(i_sd[['datadate','ticker','avgPV_l1d']],on=['datadate','ticker'],how='left')

# MACD
df_pid['ema60'] = df_pid.groupby('ticker')['bret_pid'].transform(lambda x: x.ewm(halflife=60, min_periods=60).mean())
df_pid.loc[df_pid['bret_pid'].isnull(),'ema60'] = np.nan
df_pid['ema28'] = df_pid.groupby('ticker')['bret_pid'].transform(lambda x: x.ewm(halflife=28, min_periods=28).mean())
df_pid.
loc[df_pid['bret_pid'].isnull(),'ema28'] = np.nan
df_pid['macd'] = df_pid['ema28'] - df_pid['ema60']
df_pid['macd_signal'] = df_pid.groupby('ticker')['macd'].transform(lambda x: x.ewm(halflife=9, min_periods=9).mean())
df_pid['macd_hist'] = df_pid['macd'] - df_pid['macd_signal']

# ultimate oscillator
df_pid['uo_bp_dv_tr'] = df_pid.groupby('ticker')['bret_pid'].rolling(5).apply(lambda x: (x[-1]-np.min(x))/(np.max(x)-np.min(x)),raw = True).values
df_pid['uo_a5'] = df_pid.groupby('ticker')['uo_bp_dv_tr'].rolling(5).mean().values
df_pid['uo_a10'] = df_pid.groupby('ticker')['uo_bp_dv_tr'].rolling(10).mean().values
df_pid['uo_a20'] = df_pid.groupby('ticker')['uo_bp_dv_tr'].rolling(20).mean().values
df_pid['uo'] = (df_pid['uo_a5']*4 + df_pid['uo_a10']*2 + df_pid['uo_a20'])/7

# boll
df_pid['std220'] = df_pid.groupby('ticker')['bret_pid'].rolling(220).std().values
df_pid['boll_u'] = df_pid['ema60'] + df_pid['std220']*2
df_pid['boll_l'] = df_pid['ema60'] - df_pid['std220']*2



# pst
tic()
pst = [np.nan] * len(df_pid)
std_on_open = [np.nan] * len(df_pid)
pid_on_open = [np.nan] * len(df_pid)
bars_since_open = [0] * len(df_pid)
pnl_gt_1std = [np.nan] * len(df_pid)
stop_threshold = [np.nan] * len(df_pid)
for i in range(300,len(df_pid)):
    # tk same
    if df_pid['tk_hash'].values[i] != df_pid['tk_hash'].values[i-1]:
        continue
    # hold
    if pst[i-1]>0:
        pst[i] = pst[i-1]
        std_on_open[i] = std_on_open[i-1]
        pid_on_open[i] = pid_on_open[i-1]
        bars_since_open[i] = bars_since_open[i-1]+1
        stop_threshold[i] = stop_threshold[i-1]
        if (df_pid['bret_pid'].values[i] - pid_on_open[i]) > std_on_open[i]:
            pnl_gt_1std[i] = 1
        else: 
            pnl_gt_1std[i] = pnl_gt_1std[i-1]
    elif pst[i-1]<0:
        pst[i] = pst[i-1]
        std_on_open[i] = std_on_open[i-1]
        pid_on_open[i] = pid_on_open[i-1]
        bars_since_open[i] = bars_since_open[i-1]+1
        stop_threshold[i] = stop_threshold[i-1]
        if (-df_pid['bret_pid'].values[i] + pid_on_open[i]) > std_on_open[i]:
            pnl_gt_1std[i] = 1
        else: 
            pnl_gt_1std[i] = pnl_gt_1std[i-1]
    # close
    if pst[i-1]>0: # + pst
        if (df_pid['macd_hist'].values[i]<df_pid['macd_hist'].values[i-1]) &\
           (df_pid['macd_hist'].values[i-1]<df_pid['macd_hist'].values[i-2]): # stop win
            pst[i] = 0
    elif pst[i-1]<0: # - pst
        if (df_pid['macd_hist'].values[i]>df_pid['macd_hist'].values[i-1]) &\
        
   (df_pid['macd_hist'].values[i-1]>df_pid['macd_hist'].values[i-2]):
            pst[i] = 0

    # open
    if (df_pid['macd_hist'].values[i]>df_pid['macd_hist'].values[i-1])&\
        (df_pid['macd_hist'].values[i-1]>df_pid['macd_hist'].values[i-2])&\
        (df_pid['macd_hist'].values[i-2]<df_pid['macd_hist'].values[i-3])&\
        (df_pid['macd_hist'].values[i-3]<df_pid['macd_hist'].values[i-5])&\
        (df_pid['macd_hist'].values[i-5]<df_pid['macd_hist'].values[i-10])&\
        (df_pid['macd_hist'].values[i-3]<0)&\
        ((pst[i-1]<=0)|np.isnan(pst[i-1])):
        pst[i] = min(df_pid['avgPV_l1d'].values[i]*0.01,1e6)
        std_on_open[i] = max(df_pid['bret_pid_std'].values[i],0.04)
        pid_on_open[i] = df_pid['bret_pid'].values[i]
        bars_since_open[i] = 1
        pnl_gt_1std[i] = 0
        stop_threshold[i] = np.min(df_pid['bret_pid'].values[i-300:i+1])
    elif (df_pid['macd_hist'].values[i]<df_pid['macd_hist'].values[i-1])&\
        (df_pid['macd_hist'].values[i-1]<df_pid['macd_hist'].values[i-2])&\
        (df_pid['macd_hist'].values[i-2]>df_pid['macd_hist'].values[i-3])&\
        (df_pid['macd_hist'].values[i-3]>df_pid['macd_hist'].values[i-5])&\
        (df_pid['macd_hist'].values[i-5]>df_pid['macd_hist'].values[i-10])&\
        (df_pid['macd_hist'].values[i-3]>0)&\
        ((pst[i-1]>=0)|np.isnan(pst[i-1])):
        pst[i] = -min(df_pid['avgPV_l1d'].values[i]*0.01,1e6)
        std_on_open[i] = max(df_pid['bret_pid_std'].values[i],0.04)
        pid_on_open[i] = df_pid['bret_pid'].values[i]
        bars_since_open[i] = 1
        pnl_gt_1std[i] = 0
        stop_threshold[i] = np.max(df_pid['bret_pid'].values[i-300:i+1])
toc()
df_pid['pstD']=pst
df_pid['std_on_open']=std_on_open
df_pid['pid_on_open']=pid_on_open
df_pid['bars_since_open']=bars_since_open
df_pid['pnl_gt_1std']=pnl_gt_1std
df_pid['stop_threshold'] = stop_threshold


sd_pid = df_pid.merge(i_sd[['datadate','ticker','BarrRet_SRISK+1d']],on=['datadate','ticker'],how='left')
sd_pid['pstC'] = sd_pid['pstD'].divide(sd_pid['avgPV_l1d']*0.01)
o3 = bt(sd_pid[sd_pid.datadate<='2019-03-01'].dropna(subset=['pstC','BarrRet_SRISK+1d']).drop_duplicates(subset=['ticker','datadate']),
                      'pstC','BarrRet_SRISK+1d', sgnl_before_3pm = False)




#------------------------------------------------------------------------------
### strat5: technical indicator quick test
# long when MACD hist starts to increase; short when MACD hist starts to decrease
# avoid earnings
from yz.
util import get_ed_v2

df_pid = pd.read_parquet(r'S:\Data\test\pTrend03_df_pid.parquet')
df_pid = df_pid.merge(i_sd[['datadate','ticker','avgPV_l1d']],on=['datadate','ticker'],how='left')

df_ed = get_ed_v2(df_pid.ticker.unique().tolist())
df_pid = df_pid.merge(df_ed[['datadate','ticker','bd2e']], on = ['datadate','ticker'], how = 'left')

# MACD
df_pid['ema60'] = df_pid.groupby('ticker')['bret_pid'].transform(lambda x: x.ewm(halflife=60, min_periods=60).mean())
df_pid.loc[df_pid['bret_pid'].isnull(),'ema60'] = np.nan
df_pid['ema28'] = df_pid.groupby('ticker')['bret_pid'].transform(lambda x: x.ewm(halflife=28, min_periods=28).mean())
df_pid.loc[df_pid['bret_pid'].isnull(),'ema28'] = np.nan
df_pid['macd'] = df_pid['ema28'] - df_pid['ema60']
df_pid['macd_signal'] = df_pid.groupby('ticker')['macd'].transform(lambda x: x.ewm(halflife=9, min_periods=9).mean())
df_pid['macd_hist'] = df_pid['macd'] - df_pid['macd_signal']

# ultimate oscillator
df_pid['uo_bp_dv_tr'] = df_pid.groupby('ticker')['bret_pid'].rolling(7).apply(lambda x: (x[-1]-np.min(x))/(np.max(x)-np.min(x)),raw = True).values
df_pid['uo_a5'] = df_pid.groupby('ticker')['uo_bp_dv_tr'].rolling(7).mean().values
df_pid['uo_a10'] = df_pid.groupby('ticker')['uo_bp_dv_tr'].rolling(15).mean().values
df_pid['uo_a20'] = df_pid.groupby('ticker')['uo_bp_dv_tr'].rolling(30).mean().values
df_pid['uo'] = (df_pid['uo_a5']*4 + df_pid['uo_a10']*2 + df_pid['uo_a20'])/7

# boll
df_pid['std220'] = df_pid.groupby('ticker')['bret_pid'].rolling(220).std().values
df_pid['boll_u'] = df_pid['ema60'] + df_pid['std220']*2
df_pid['boll_l'] = df_pid['ema60'] - df_pid['std220']*2

# pst
tic()
pst = [np.nan] * len(df_pid)
std_on_open = [np.nan] * len(df_pid)
pid_on_open = [np.nan] * len(df_pid)
bars_since_open = [0] * len(df_pid)
pnl_gt_1std = [np.nan] * len(df_pid)
stop_threshold = [np.nan] * len(df_pid)
for i in range(300,len(df_pid)):
    # tk same
    if df_pid['tk_hash'].values[i] != df_pid['tk_hash'].values[i-1]:
        continue
    # hold
    if pst[i-1]>0:
        pst[i] = pst[i-1]
        std_on_open[i] = std_on_open[i-1]
        pid_on_open[i] = pid_on_open[i-1]
        bars_since_open[i] = bars_since_open[i-1]+1
        stop_threshold[i] = stop_threshold[i-1]
        if (df_pid['bret_pid'].values[i] - pid_on_open[i]) > std_on_open[i]:
            pnl_gt_1std[i] = 1
        else: 
            pnl_gt_1std[i] = pnl_gt_1std[i-1]
    elif pst[i-1]<0:
        pst[i] = pst[i-1]
        std_on_open[i] = std_on_open[i-1]
        p
id_on_open[i] = pid_on_open[i-1]
        bars_since_open[i] = bars_since_open[i-1]+1
        stop_threshold[i] = stop_threshold[i-1]
        if (-df_pid['bret_pid'].values[i] + pid_on_open[i]) > std_on_open[i]:
            pnl_gt_1std[i] = 1
        else: 
            pnl_gt_1std[i] = pnl_gt_1std[i-1]
    # close
    if pst[i-1]>0: # + pst
        if (df_pid['macd_hist'].values[i]<df_pid['macd_hist'].values[i-1]) &\
           (df_pid['macd_hist'].values[i-1]<df_pid['macd_hist'].values[i-2]): # stop win
            pst[i] = 0
        if (df_pid['bd2e'].values[i]==2):
            pst[i] = 0
    elif pst[i-1]<0: # - pst
        if (df_pid['macd_hist'].values[i]>df_pid['macd_hist'].values[i-1]) &\
           (df_pid['macd_hist'].values[i-1]>df_pid['macd_hist'].values[i-2]):
            pst[i] = 0
        if (df_pid['bd2e'].values[i]==2):
            pst[i] = 0

    # open
    if (df_pid['macd_hist'].values[i]>df_pid['macd_hist'].values[i-1])&\
        (df_pid['macd_hist'].values[i-1]>df_pid['macd_hist'].values[i-2])&\
        (df_pid['macd_hist'].values[i-2]<df_pid['macd_hist'].values[i-3])&\
        (df_pid['macd_hist'].values[i-3]<df_pid['macd_hist'].values[i-5])&\
        (df_pid['macd_hist'].values[i-5]<df_pid['macd_hist'].values[i-10])&\
        (df_pid['macd_hist'].values[i-10]<0)&\
        ((pst[i-1]<=0)|np.isnan(pst[i-1])) & (df_pid['bd2e'].values[i]>=10):
        pst[i] = min(df_pid['avgPV_l1d'].values[i]*0.01,1e6)
        std_on_open[i] = max(df_pid['bret_pid_std'].values[i],0.04)
        pid_on_open[i] = df_pid['bret_pid'].values[i]
        bars_since_open[i] = 1
        pnl_gt_1std[i] = 0
        stop_threshold[i] = np.min(df_pid['bret_pid'].values[i-300:i+1])
    elif (df_pid['macd_hist'].values[i]<df_pid['macd_hist'].values[i-1])&\
        (df_pid['macd_hist'].values[i-1]<df_pid['macd_hist'].values[i-2])&\
        (df_pid['macd_hist'].values[i-2]>df_pid['macd_hist'].values[i-3])&\
        (df_pid['macd_hist'].values[i-3]>df_pid['macd_hist'].values[i-5])&\
        (df_pid['macd_hist'].values[i-5]>df_pid['macd_hist'].values[i-10])&\
        (df_pid['macd_hist'].values[i-10]>0)&\
        ((pst[i-1]>=0)|np.isnan(pst[i-1])) & (df_pid['bd2e'].values[i]>=10):
        pst[i] = -min(df_pid['avgPV_l1d'].values[i]*0.01,1e6)
        std_on_open[i] = max(df_pid['bret_pid_std'].values[i],0.04)
        pid_on_open[i] = df_pid['bret_pid'].values[i]
        bars_since_open[i] = 1
        pnl_gt_1std[i] = 0
        stop_threshold[i] = np.max(df_pid['bret_pid'].va
lues[i-300:i+1])
toc()
df_pid['pstD']=pst
df_pid['std_on_open']=std_on_open
df_pid['pid_on_open']=pid_on_open
df_pid['bars_since_open']=bars_since_open
df_pid['pnl_gt_1std']=pnl_gt_1std
df_pid['stop_threshold'] = stop_threshold


sd_pid = df_pid.merge(i_sd[['datadate','ticker','BarrRet_SRISK+1d']],on=['datadate','ticker'],how='left')
sd_pid['pstC'] = sd_pid['pstD'].divide(sd_pid['avgPV_l1d']*0.01)
o3 = bt(sd_pid[sd_pid.datadate<='2019-03-01'].dropna(subset=['pstC','BarrRet_SRISK+1d']).drop_duplicates(subset=['ticker','datadate']),
                      'pstC','BarrRet_SRISK+1d', sgnl_before_3pm = False)

#------------------------------------------------------------------------------
### strat6: technical indicator 
# long when MACD hist starts to increase; short when MACD hist starts to decrease
# avoid earnings
# more sensitive in and out, out based on uo, not macd turn
from yz.util import get_ed_v2

df_pid = pd.read_parquet(r'S:\Data\test\pTrend03_df_pid.parquet')
df_pid = df_pid.merge(i_sd[['datadate','ticker','avgPV_l1d']],on=['datadate','ticker'],how='left')

df_ed = get_ed_v2(df_pid.ticker.unique().tolist())
df_pid = df_pid.merge(df_ed[['datadate','ticker','bd2e']], on = ['datadate','ticker'], how = 'left')

# MACD
df_pid['ema60'] = df_pid.groupby('ticker')['bret_pid'].transform(lambda x: x.ewm(halflife=60, min_periods=60).mean())
df_pid.loc[df_pid['bret_pid'].isnull(),'ema60'] = np.nan
df_pid['ema28'] = df_pid.groupby('ticker')['bret_pid'].transform(lambda x: x.ewm(halflife=28, min_periods=28).mean())
df_pid.loc[df_pid['bret_pid'].isnull(),'ema28'] = np.nan
df_pid['macd'] = df_pid['ema28'] - df_pid['ema60']
df_pid['macd_signal'] = df_pid.groupby('ticker')['macd'].transform(lambda x: x.ewm(halflife=9, min_periods=9).mean())
df_pid['macd_hist'] = df_pid['macd'] - df_pid['macd_signal']

# ultimate oscillator
df_pid['uo_bp_dv_tr'] = df_pid.groupby('ticker')['bret_pid'].rolling(7).apply(lambda x: (x[-1]-np.min(x))/(np.max(x)-np.min(x)),raw = True).values
df_pid['uo_a5'] = df_pid.groupby('ticker')['uo_bp_dv_tr'].rolling(7).mean().values
df_pid['uo_a10'] = df_pid.groupby('ticker')['uo_bp_dv_tr'].rolling(15).mean().values
df_pid['uo_a20'] = df_pid.groupby('ticker')['uo_bp_dv_tr'].rolling(30).mean().values
df_pid['uo'] = (df_pid['uo_a5']*4 + df_pid['uo_a10']*2 + df_pid['uo_a20'])/7

# boll
df_pid['std220'] = df_pid.groupby('ticker')['bret_pid'].rolling(220).std().values
df_pid['boll_u'] = df_pid['ema60'] + df_pid['std220']*2
df_pid['boll_l'] = df_pid['ema60'
] - df_pid['std220']*2

# turning point
c_upturn = (df_pid['tk_hash'] == df_pid['tk_hash'].shift(10)) &\
           (df_pid['macd_hist'] > df_pid['macd_hist'].shift()) &\
           (df_pid['macd_hist'].shift() < df_pid['macd_hist'].shift(2)) &\
           (df_pid['macd_hist'].shift(2) < df_pid['macd_hist'].shift(5)) &\
           (df_pid['macd_hist'].shift(5) < df_pid['macd_hist'].shift(10)) &\
           (df_pid['macd_hist'].shift(10) < 0)
df_pid.loc[c_upturn, 'macd_turn'] = 1
c_downturn = (df_pid['tk_hash'] == df_pid['tk_hash'].shift(10)) &\
             (df_pid['macd_hist'] < df_pid['macd_hist'].shift()) &\
             (df_pid['macd_hist'].shift() > df_pid['macd_hist'].shift(2)) &\
             (df_pid['macd_hist'].shift(2) > df_pid['macd_hist'].shift(5)) &\
             (df_pid['macd_hist'].shift(5) > df_pid['macd_hist'].shift(10)) &\
             (df_pid['macd_hist'].shift(10) > 0)
df_pid.loc[c_downturn, 'macd_turn'] = -1

# pst
tic()
pst = [np.nan] * len(df_pid)
std_on_open = [np.nan] * len(df_pid)
pid_on_open = [np.nan] * len(df_pid)
bars_since_open = [0] * len(df_pid)
pnl_gt_1std = [np.nan] * len(df_pid)
stop_threshold = [np.nan] * len(df_pid)
for i in range(300,len(df_pid)):
    # tk same
    if df_pid['tk_hash'].values[i] != df_pid['tk_hash'].values[i-1]:
        continue
    # hold
    if pst[i-1]>0:
        pst[i] = pst[i-1]
        std_on_open[i] = std_on_open[i-1]
        pid_on_open[i] = pid_on_open[i-1]
        bars_since_open[i] = bars_since_open[i-1]+1
        stop_threshold[i] = stop_threshold[i-1]
        if (df_pid['bret_pid'].values[i] - pid_on_open[i]) > std_on_open[i]:
            pnl_gt_1std[i] = 1
        else: 
            pnl_gt_1std[i] = pnl_gt_1std[i-1]
    elif pst[i-1]<0:
        pst[i] = pst[i-1]
        std_on_open[i] = std_on_open[i-1]
        pid_on_open[i] = pid_on_open[i-1]
        bars_since_open[i] = bars_since_open[i-1]+1
        stop_threshold[i] = stop_threshold[i-1]
        if (-df_pid['bret_pid'].values[i] + pid_on_open[i]) > std_on_open[i]:
            pnl_gt_1std[i] = 1
        else: 
            pnl_gt_1std[i] = pnl_gt_1std[i-1]
    # close
    if pst[i-1]>0: # + pst
        if (df_pid['macd_hist'].values[i]<df_pid['macd_hist'].values[i-1]) &\
           (df_pid['macd_hist'].values[i-1]<df_pid['macd_hist'].values[i-2]): # stop win
            pst[i] = 0
        if (df_pid['bd2e'].values[i]==2):
            pst[i] = 0
        if (df_pid['uo'].values[i]>0.8):
            pst[i] = 0
    elif pst[i-1]<0: # - ps
t
        if (df_pid['macd_hist'].values[i]>df_pid['macd_hist'].values[i-1]) &\
           (df_pid['macd_hist'].values[i-1]>df_pid['macd_hist'].values[i-2]):
            pst[i] = 0
        if (df_pid['bd2e'].values[i]==2):
            pst[i] = 0
        if (df_pid['uo'].values[i]<0.2):
            pst[i] = 0 

    # open
    if (df_pid['macd_turn'].values[i]==1)&\
        ((pst[i-1]<=0)|np.isnan(pst[i-1])) & (df_pid['bd2e'].values[i]>=10):
        pst[i] = min(df_pid['avgPV_l1d'].values[i]*0.01,1e6)
        std_on_open[i] = max(df_pid['bret_pid_std'].values[i],0.04)
        pid_on_open[i] = df_pid['bret_pid'].values[i]
        bars_since_open[i] = 1
        pnl_gt_1std[i] = 0
        stop_threshold[i] = np.min(df_pid['bret_pid'].values[i-300:i+1])
    elif (df_pid['macd_turn'].values[i]==-1)&\
        ((pst[i-1]>=0)|np.isnan(pst[i-1])) & (df_pid['bd2e'].values[i]>=10):
        pst[i] = -min(df_pid['avgPV_l1d'].values[i]*0.01,1e6)
        std_on_open[i] = max(df_pid['bret_pid_std'].values[i],0.04)
        pid_on_open[i] = df_pid['bret_pid'].values[i]
        bars_since_open[i] = 1
        pnl_gt_1std[i] = 0
        stop_threshold[i] = np.max(df_pid['bret_pid'].values[i-300:i+1])
toc()
df_pid['pstD']=pst
df_pid['std_on_open']=std_on_open
df_pid['pid_on_open']=pid_on_open
df_pid['bars_since_open']=bars_since_open
df_pid['pnl_gt_1std']=pnl_gt_1std
df_pid['stop_threshold'] = stop_threshold


sd_pid = df_pid.merge(i_sd[['datadate','ticker','BarrRet_SRISK+1d']],on=['datadate','ticker'],how='left')
sd_pid['pstC'] = sd_pid['pstD'].divide(sd_pid['avgPV_l1d']*0.01)
o3 = bt(sd_pid[sd_pid.datadate<='2019-03-01'].dropna(subset=['pstC','BarrRet_SRISK+1d']).drop_duplicates(subset=['ticker','datadate']),
                      'pstC','BarrRet_SRISK+1d', sgnl_before_3pm = False)


#------------------------------------------------------------------------------
### strat7: technical indicator 
# use uo as the main signal (entry when >.8 or <.2, but what about exit?)
# avoid earnings
from yz.util import get_ed_v2

df_pid = pd.read_parquet(r'S:\Data\test\pTrend03_df_pid.parquet')
df_pid = df_pid.merge(i_sd[['datadate','ticker','avgPV_l1d']],on=['datadate','ticker'],how='left')

df_ed = get_ed_v2(df_pid.ticker.unique().tolist())
df_pid = df_pid.merge(df_ed[['datadate','ticker','bd2e']], on = ['datadate','ticker'], how = 'left')

# MACD
df_pid['ema60'] = df_pid.groupby('ticker')['bret_pid'].transform(lambda x: x.ewm(halflife=60, min_periods=60).mean())
df_pid.loc[df_pid['bret_pid'
].isnull(),'ema60'] = np.nan
df_pid['ema28'] = df_pid.groupby('ticker')['bret_pid'].transform(lambda x: x.ewm(halflife=28, min_periods=28).mean())
df_pid.loc[df_pid['bret_pid'].isnull(),'ema28'] = np.nan
df_pid['macd'] = df_pid['ema28'] - df_pid['ema60']
df_pid['macd_signal'] = df_pid.groupby('ticker')['macd'].transform(lambda x: x.ewm(halflife=9, min_periods=9).mean())
df_pid['macd_hist'] = df_pid['macd'] - df_pid['macd_signal']

# ultimate oscillator
df_pid['uo_bp_dv_tr'] = df_pid.groupby('ticker')['bret_pid'].rolling(7).apply(lambda x: (x[-1]-np.min(x))/(np.max(x)-np.min(x)),raw = True).values
df_pid['uo_a5'] = df_pid.groupby('ticker')['uo_bp_dv_tr'].rolling(7).mean().values
df_pid['uo_a10'] = df_pid.groupby('ticker')['uo_bp_dv_tr'].rolling(15).mean().values
df_pid['uo_a20'] = df_pid.groupby('ticker')['uo_bp_dv_tr'].rolling(30).mean().values
df_pid['uo'] = (df_pid['uo_a5']*4 + df_pid['uo_a10']*2 + df_pid['uo_a20'])/7

# boll
df_pid['std220'] = df_pid.groupby('ticker')['bret_pid'].rolling(220).std().values
df_pid['boll_u'] = df_pid['ema60'] + df_pid['std220']*2
df_pid['boll_l'] = df_pid['ema60'] - df_pid['std220']*2

# turning point
c_upturn = (df_pid['tk_hash'] == df_pid['tk_hash'].shift(10)) &\
           (df_pid['macd_hist'] > df_pid['macd_hist'].shift()) &\
           (df_pid['macd_hist'].shift() < df_pid['macd_hist'].shift(2)) &\
           (df_pid['macd_hist'].shift(2) < df_pid['macd_hist'].shift(5)) &\
           (df_pid['macd_hist'].shift(5) < df_pid['macd_hist'].shift(10)) &\
           (df_pid['macd_hist'].shift(10) < 0)
df_pid.loc[c_upturn, 'macd_turn'] = 1
c_downturn = (df_pid['tk_hash'] == df_pid['tk_hash'].shift(10)) &\
             (df_pid['macd_hist'] < df_pid['macd_hist'].shift()) &\
             (df_pid['macd_hist'].shift() > df_pid['macd_hist'].shift(2)) &\
             (df_pid['macd_hist'].shift(2) > df_pid['macd_hist'].shift(5)) &\
             (df_pid['macd_hist'].shift(5) > df_pid['macd_hist'].shift(10)) &\
             (df_pid['macd_hist'].shift(10) > 0)
df_pid.loc[c_downturn, 'macd_turn'] = -1

# pst
tic()
pst = [np.nan] * len(df_pid)
std_on_open = [np.nan] * len(df_pid)
pid_on_open = [np.nan] * len(df_pid)
bars_since_open = [0] * len(df_pid)
pnl_gt_1std = [np.nan] * len(df_pid)
stop_threshold = [np.nan] * len(df_pid)
for i in range(300,len(df_pid)):
    # tk same
    if df_pid['tk_hash'].values[i] != df_pid['tk_hash'].values[i-1]:
        continue
    # hold
    if pst[i-1]>0:
        pst[i] = pst[i-1]
        std_on_open[i] = s
td_on_open[i-1]
        pid_on_open[i] = pid_on_open[i-1]
        bars_since_open[i] = bars_since_open[i-1]+1
        stop_threshold[i] = stop_threshold[i-1]
        if (df_pid['bret_pid'].values[i] - pid_on_open[i]) > std_on_open[i]:
            pnl_gt_1std[i] = 1
        else: 
            pnl_gt_1std[i] = pnl_gt_1std[i-1]
    elif pst[i-1]<0:
        pst[i] = pst[i-1]
        std_on_open[i] = std_on_open[i-1]
        pid_on_open[i] = pid_on_open[i-1]
        bars_since_open[i] = bars_since_open[i-1]+1
        stop_threshold[i] = stop_threshold[i-1]
        if (-df_pid['bret_pid'].values[i] + pid_on_open[i]) > std_on_open[i]:
            pnl_gt_1std[i] = 1
        else: 
            pnl_gt_1std[i] = pnl_gt_1std[i-1]
    # close
    if pst[i-1]>0: # + pst
        if (df_pid['uo'].values[i-1]>0.3) & (df_pid['uo'].values[i]<df_pid['uo'].values[i-1]): # stop win
            pst[i] = 0
        if (df_pid['bd2e'].values[i]==2):
            pst[i] = 0
        if (df_pid['uo'].values[i]>0.8):
            pst[i] = 0
    elif pst[i-1]<0: # - pst
        if (df_pid['uo'].values[i-1]<0.7) & (df_pid['uo'].values[i]>df_pid['uo'].values[i-1]):
            pst[i] = 0
        if (df_pid['bd2e'].values[i]==2):
            pst[i] = 0
        if (df_pid['uo'].values[i]<0.2):
            pst[i] = 0 

    # open
    if (df_pid['uo'].values[i]<0.2)&\
        ((pst[i-1]<=0)|np.isnan(pst[i-1])) & (df_pid['bd2e'].values[i]>=10):
        pst[i] = min(df_pid['avgPV_l1d'].values[i]*0.01,1e6)
        std_on_open[i] = max(df_pid['bret_pid_std'].values[i],0.04)
        pid_on_open[i] = df_pid['bret_pid'].values[i]
        bars_since_open[i] = 1
        pnl_gt_1std[i] = 0
        stop_threshold[i] = np.min(df_pid['bret_pid'].values[i-300:i+1])
    elif (df_pid['uo'].values[i]>0.8)&\
        ((pst[i-1]>=0)|np.isnan(pst[i-1])) & (df_pid['bd2e'].values[i]>=10):
        pst[i] = -min(df_pid['avgPV_l1d'].values[i]*0.01,1e6)
        std_on_open[i] = max(df_pid['bret_pid_std'].values[i],0.04)
        pid_on_open[i] = df_pid['bret_pid'].values[i]
        bars_since_open[i] = 1
        pnl_gt_1std[i] = 0
        stop_threshold[i] = np.max(df_pid['bret_pid'].values[i-300:i+1])
toc()
df_pid['pstD']=pst
df_pid['std_on_open']=std_on_open
df_pid['pid_on_open']=pid_on_open
df_pid['bars_since_open']=bars_since_open
df_pid['pnl_gt_1std']=pnl_gt_1std
df_pid['stop_threshold'] = stop_threshold


sd_pid = df_pid.merge(i_sd[['datadate','ticker','BarrRet_SRISK+1d']],on=['datadate','ticker'],how='left')
sd_pid
['pstC'] = sd_pid['pstD'].divide(sd_pid['avgPV_l1d']*0.01)
o3 = bt(sd_pid[sd_pid.datadate<='2019-03-01'].dropna(subset=['pstC','BarrRet_SRISK+1d']).drop_duplicates(subset=['ticker','datadate']),
                      'pstC','BarrRet_SRISK+1d', sgnl_before_3pm = False)






# inspection
['datadate', 'ticker', 'bret_pid', 'hurst', 'opt_ma_period', 'tk_hash',
       'ema90', 'ema90_top', 'ema90_bottom', 'ema_index']
df_pid['datadate_index'] = df_pid['datadate']
df_pid = df_pid.set_index('datadate_index')
df_pid = df_pid.sort_values(['ticker','datadate'])
t1 = df_pid[df_pid.ticker=='NFLX']
t1[['ema90','bret_pid']].plot()

i_mc = pd.read_parquet(r"S:\Infrastructure\backtester\data_cache\static_data_v2p0.parquet",
                       columns = ['Ticker','DataDate','MC_l1d'])
i_mc = i_mc.groupby('Ticker')['MC_l1d'].median()

# bt inspection
o_pair = o3.groupby('ticker')['pnl'].sum()
o_pair = pd.concat([o_pair, i_mc], axis = 1, join = 'inner')

TK = 'WLT'
o3[o3.ticker==TK].groupby('datadate')['pnl'].sum().cumsum().plot() #pnl plot

o_sharpe = o3.groupby('ticker')['pnl'].apply(lambda x: x.mean()/x.std()*np.sqrt(len(x)))

ptrend_viz(df_pid,'WLT')

t1 = df_pid[df_pid.ticker==TK]
t2 = o3[o3.ticker==TK]

