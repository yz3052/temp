﻿#$%^&* featurepool_cn_order_bidask_size_ratio_desc.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct  6 14:16:42 2022

@author: thzhang
"""

import sys
import os
import pandas as pd
import numpy as np

import datetime

from sqlalchemy import create_engine
import urllib


# to be scheduled on crontab at 5 am



### params

source_path = '/export/dataprod/Feature_Pool_CN/q_order_bidask_size_ratio'
save_path = '/export/dataprod/Feature_Pool_CN/featurepool_desc_order_bidask_size_ratio'

conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))

today = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
today = pd.to_datetime(today.date())
today_str = today.strftime('%Y%m%d')



### get calendar

i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()




### get dates to query

q_dates = os.listdir(source_path)
desc_dates = os.listdir(save_path)
query_dates = list(set(q_dates).difference(set(desc_dates)))




### query and calculate metrics

for f in query_dates:
    
    # get q query results
    
    i_ba = pd.read_csv(os.path.join(source_path, f), sep = '|', )
    
    i_ba = i_ba.rename(columns = {'code': 'Ticker', 'date': 'T-1d'})
    i_ba['Ticker'] = i_ba['Ticker'].astype(int).astype(str).str.zfill(6)
    i_ba['T-1d'] = pd.to_datetime(i_ba['T-1d'])
    i_ba['ba_ratio_1000'] = i_ba['avg_b_v_1000'].divide(i_ba['avg_a_v_1000'])
    i_ba['ba_ratio_1000'] = i_ba['ba_ratio_1000'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
                         
    # combine
                
    icom = i_ba.merge(i_cal, on = 'T-1d', how = 'left')
    
    file_name = f.replace('.txt','.parquet')
    icom[['T-1d', 'DataDate', 'Ticker', 'ba_ratio_1000']].to_parquet(os.path.join(save_path, file_name))
    
    os.system("chgrp summit_thzhang "+os.path.join(save_path, file_name)+";")
    os.system("chmod 770 "+os.path.join(save_path, file_name)+";")
    
    


