﻿#$%^&* pDataYes_recruit_FINAL.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 13 18:43:43 2021

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import zipfile
import csv

import jieba

import datetime



# this starts to fianlize all the findings so far



GSEC = {'10':'energy','15':'materials','20':'industrials','25':'consumer discretionary',
        '30':'consumer_staples','35':'healthcare','40':'financials','45':'IT',
        '50':'communication services','55':'utilities','60':'real estate'}

### get ind

i_ind = yu.get_sql('''select datadate, ticker, gsector, ggrop, gind, gsubind 
                   FROM [CNDBprod].[dbo].[UNIVERSE_ALL_CN]
                   where datadate >= '2016-01-01' ''')
c_sh = i_ind['ticker'].str[0].isin(['6'])
c_sz = i_ind['ticker'].str[0].isin(['3','0'])
i_ind.loc[c_sh, 'ticker'] = i_ind.loc[c_sh, 'ticker'] + '.SH'
i_ind.loc[c_sz, 'ticker'] = i_ind.loc[c_sz, 'ticker'] + '.SZ'


### get sd
i_sd = pw.get_ashare_hk_sd_v2()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','a50_300_flag','a50_flag']]

i_sd_map_300 =i_sd_map[i_sd_map['a50_300_flag']==1]
i_sd_datadate_sr = i_sd_map_300['datadate'].drop_duplicates()
i_sd_map_hk  = i_sd_map[i_sd_map['isin_hk_uni']==1]


i_sd = pw.get_ashare_t3000_sd() ###!!!


### get gross margin
i_gm = pw.get_sql('''select trade_dt, s_info_windcode as ticker, 
                  S_DFA_GROSSMARGIN_TTM, S_DFA_OR_TTM as rev, S_DFA_GC_TTM, S_DFA_COST_TTM, S_DFA_EXPENSE_TTM 
                  from wind.dbo.PITFinancialFactor where s_info_windcode in ('{0}')  '''.\
                  format( "','".join(i_sd.ticker.unique().tolist()) ))
i_gm['datadate'] = pd.to_datetime(i_gm['trade_dt'], format='%Y%m%d')

i_gm['prod_cost'] = i_gm['S_DFA_COST_TTM']
i_gm.loc[i_gm['prod_cost'].isnull(), 'prod_cost'] = i_gm.loc[i_gm['prod_cost'].isnull(), 'S_DFA_EXPENSE_TTM']
i_gm['exp_rev'] = i_gm['prod_cost'].divide(i_gm['rev'])



### get all non-txt features of jobs

i_p = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet')

i_raw = pd.DataFrame()
for p in i_p[:-1]:
    print(p)
    t_data = pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet', p))
        
    t_data = t_
data[t_data['source'].isin(['51job'])] ###!!!
    t_data = t_data[t_data['title'].notnull()]###!!!
    t_data = t_data[t_data['ticker_symbol'].notnull()]
    t_data = t_data[t_data['ticker_symbol'].str.contains('\d{6}')]
    
    t_data['datadate'] = pd.to_datetime(pd.to_datetime(t_data['published_at']).dt.date) + pd.to_timedelta('1 day')
    
    t_data.loc[t_data['ticker_symbol'].str.len()!=6, 'ticker_symbol'] = np.nan
    c_sh = t_data['ticker_symbol'].str[0].isin(['6'])
    c_sz = t_data['ticker_symbol'].str[0].isin(['0', '3'])
    t_data.loc[c_sh, 'ticker'] = t_data.loc[c_sh, 'ticker_symbol'] + '.SH'
    t_data.loc[c_sz, 'ticker'] = t_data.loc[c_sz, 'ticker_symbol'] + '.SZ'
    
    
    
    t_data['title3'] = t_data['title'].str.replace('\(.*\)','').str.replace('（.*）','').\
                     str.replace('\[.*\]','').str.replace('\【.*\】','').\
                     str.replace('\d[K|k|W|w|千|万]','').str.replace('\d','').\
                     str.replace('（|）|,|，|\.|。|:|：|;|；|\(|\)|\*|~|`|!|@|#|$|&|-|—|\+|\/|、|\?',' ').\
                     str.replace('职位编号','').\
                     str.strip().str.replace('[ ]+', ' ').\
                     str.upper()
    t_data = t_data[t_data['title3'].notnull() & (t_data['title3']!='')]
    
    
    
    t_data = t_data.merge(i_ind, on = ['ticker','datadate'], how = 'left')
    t_data = t_data.sort_values(['ticker','datadate'])
    t_data['gsector'] = t_data.groupby('ticker')['gsector'].ffill()
    t_data['ggrop'] = t_data.groupby('ticker')['ggrop'].ffill()
    t_data['gind'] = t_data.groupby('ticker')['gind'].ffill()
    t_data['gsubind'] = t_data.groupby('ticker')['gsubind'].ffill()
    
    i_raw = i_raw.append(t_data, sort = False)





### get title data for each job 
#   'id', 'source', 'datadate', 'title_seg', 'ticker'
i_title = pd.read_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_title_segs_alltk.parquet', columns = ['id','title_seg'])
    
# get ttm title seg for each ticker (all source)
i_title_segset = pd.read_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_daily_ttm_titleSegSet_per_tk.parquet')

# get ttm title seg for each ticker (51 job)
i_title_segset_51job = pd.read_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_daily_ttm_titleSegSet_per_tk_51job.parquet')



### get jd data for each job 
#   'id','ticker','datadate','jd_seg','source'
i_jd = pd.read_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_jd_segs.parquet', columns=['id','jd_seg','jd_len','jd_clean_senti']
)

# get ttm jd seg for each ticker (all source)
i_jd_segset = pd.read_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_monthly_ttm_jdSegSet_per_tk.parquet', columns=['ticker', 'jd_seg_set', 'datadate'])

# get ttm jd seg for each ticker (51 job)
i_jd_segset_51job = pd.read_parquet(r'S:\Data\China Data Hunt\cache\datayes_cache_monthly_ttm_jdSegSet_per_tk_51job.parquet', columns=['ticker', 'jd_seg_set', 'datadate'])



### Identify jobs whose title + JD segments that can be mapped to past [csi300, hkuni, a50]

i_raw_main_features = i_raw[['id','ticker','datadate','source', 'company_info_id', 'working_address', 'title','gsector','annual_salary_range_start', 'annual_salary_range_end']]
i_raw_main_features['datadate_l1y'] = i_raw_main_features['datadate'] - pd.to_timedelta('365 days')

tk_uni = i_sd_map[(i_sd_map['a50_300_flag']==1)|(i_sd_map['isin_hk_uni']==1)]['ticker'].unique().tolist()
i_raw_main_features = i_raw_main_features[i_raw_main_features['ticker'].isin(tk_uni)]

i_raw_main_features = i_raw_main_features.merge(i_jd, on = ['id'], how = 'inner')

i_raw_main_features = i_raw_main_features.sort_values('datadate')
i_jd_segset = i_jd_segset.sort_values('datadate')
i_raw_main_features = pd.merge_asof(i_raw_main_features, i_jd_segset.rename(columns={'jd_seg_set':'jd_segSet_alltk_1y'}),
                                    by='ticker', left_on='datadate_l1y', right_on='datadate', suffixes=['','_1y'], tolerance=pd.to_timedelta('40 days'))
i_raw_main_features = i_raw_main_features.drop(columns=['datadate_1y'])
i_jd_segset_51job = i_jd_segset_51job.sort_values('datadate')
i_raw_main_features = pd.merge_asof(i_raw_main_features, i_jd_segset_51job.rename(columns={'jd_seg_set':'jd_segSet_51job_1y'}),
                                    by='ticker', left_on='datadate_l1y', right_on='datadate', suffixes=['','_1y'], tolerance=pd.to_timedelta('40 days'))
i_raw_main_features = i_raw_main_features.drop(columns=['datadate_1y'])

i_raw_main_features = i_raw_main_features.merge(i_title, on = ['id'], how = 'inner')

i_title_segset = i_title_segset.sort_values('datadate')
i_raw_main_features = pd.merge_asof(i_raw_main_features, i_title_segset.rename(columns={'title_seg':'title_segSet_alltk_1y'}),
                                    by='ticker', left_on='datadate_l1y', right_on='datadate', suffixes=['','_1y'], tolerance=pd.to_timedelta('40 days'))
i_raw_main_features = i_raw_main_features.drop(columns=['datadate_1y'])

i_title_segset_51job = i_title_segset_51job.sort_val
ues('datadate')
i_raw_main_features = pd.merge_asof(i_raw_main_features, i_title_segset_51job.rename(columns={'title_seg':'title_segSet_51job_1y'}),
                                    by='ticker', left_on='datadate_l1y', right_on='datadate', suffixes=['','_1y'], tolerance=pd.to_timedelta('40 days'))
i_raw_main_features = i_raw_main_features.drop(columns=['datadate_1y'])


def helper6(title_seg_str, alltitle_seg_str):
    if pd.isnull(alltitle_seg_str):
        return np.nan
    else:
        return set(title_seg_str.split('@')).issubset(set(alltitle_seg_str.split('@')))
def helper7(jd_seg_str, alljd_seg_str):
    if pd.isnull(alljd_seg_str):
        return np.nan
    else:
        jd_set = set(jd_seg_str.split('@'))
        return len(jd_set.intersection(set(alljd_seg_str.split('@')))) / len(jd_set)

print('flag1')
i_raw_main_features['same_title_seg_alldata_flag'] = i_raw_main_features[['title_seg', 'title_segSet_alltk_1y']].\
                                    apply(lambda x: helper6(x['title_seg'],x['title_segSet_alltk_1y']), axis=1)
i_raw_main_features['same_title_seg_alldata_flag'] = i_raw_main_features['same_title_seg_alldata_flag'].replace(True,1).replace(False,0)
print('flag2')
i_raw_main_features['same_title_seg_51job_flag'] = i_raw_main_features[['title_seg', 'title_segSet_51job_1y']].\
                                    apply(lambda x: helper6(x['title_seg'],x['title_segSet_51job_1y']), axis=1)
i_raw_main_features['same_title_seg_51job_flag'] = i_raw_main_features['same_title_seg_51job_flag'].replace(True,1).replace(False,0)
print('flag3')
i_raw_main_features['jd_pct_match_alldata'] = i_raw_main_features[['jd_seg', 'jd_segSet_alltk_1y']].\
                                    apply(lambda x: helper7(x['jd_seg'],x['jd_segSet_alltk_1y']), axis=1)
print('flag4')
i_raw_main_features['jd_pct_match_51job'] = i_raw_main_features[['jd_seg', 'jd_segSet_51job_1y']].\
                                    apply(lambda x: helper7(x['jd_seg'],x['jd_segSet_51job_1y']), axis=1)



### calculate ttm job counts
                                    
                                
i_raw_main_features_dedup = i_raw_main_features.drop_duplicates(subset=['title','working_address','company_info_id','ticker','datadate'],keep='last')
i_raw_main_features_51job_dedup = i_raw_main_features[i_raw_main_features['source']=='51job'].drop_duplicates(subset=['title','working_address','company_info_id','ticker','datadate'],keep='last')


i_ttm_metrics = []
for dt in pd.date_rang
e(start='2017-01-01', end ='2020-05-31'):
    print('.', end='')
    

    t_raw_main_features = i_raw_main_features[i_raw_main_features['datadate'].between(dt-pd.to_timedelta('365 days'), dt)]
    t_raw_main_features_51job = t_raw_main_features[t_raw_main_features['source']=='51job']
    t_raw_main_features_51job_dedup = i_raw_main_features_51job_dedup[i_raw_main_features_51job_dedup['datadate'].between(dt-pd.to_timedelta('365 days'), dt)]
    t_raw_main_features_dedup = i_raw_main_features_dedup[i_raw_main_features_dedup['datadate'].between(dt-pd.to_timedelta('365 days'), dt)]
    
    t_median_salary = t_raw_main_features.groupby('gsector')['annual_salary_range_start'].median().reset_index()
    t_median_salary = t_median_salary.rename(columns={'annual_salary_range_start':'gsector_salary_median'})
    t_raw_main_features_51job_dedup = t_raw_main_features_51job_dedup.merge(t_median_salary,on='gsector',how='left')
    
    t_s1 = t_raw_main_features.groupby('ticker')['same_title_seg_alldata_flag'].sum()
    t_s2 = t_raw_main_features_51job.groupby('ticker')['same_title_seg_51job_flag'].sum()
    t_s3 = t_raw_main_features[t_raw_main_features['jd_pct_match_alldata']>0.8].groupby('ticker')['same_title_seg_alldata_flag'].sum()
    t_s4 = t_raw_main_features_51job[t_raw_main_features_51job['jd_pct_match_51job']>0.8].groupby('ticker')['same_title_seg_51job_flag'].sum()
    
    t_s5 = t_raw_main_features_51job.groupby('ticker')['id'].nunique()
    t_s6 = t_raw_main_features_51job_dedup.groupby('ticker')['id'].nunique()
    t_s7 = t_raw_main_features_dedup.groupby('ticker')['id'].nunique()
    t_s8 = t_raw_main_features.groupby('ticker')['id'].nunique()
    
    t_s9 = t_raw_main_features_51job_dedup[t_raw_main_features_51job_dedup['jd_pct_match_alldata']>0.8].groupby('ticker')['id'].nunique()
    t_s10 = t_raw_main_features.groupby('ticker')['jd_len'].sum()
    
    t_s11 = t_raw_main_features_51job.groupby('ticker')['jd_clean_senti'].mean()
    t_s12 = t_raw_main_features_51job[(t_raw_main_features_51job['jd_clean_senti']>0.9)&(t_raw_main_features_51job['jd_pct_match_51job']>0.8)].groupby('ticker')['same_title_seg_51job_flag'].sum()
    
    ttm_t1y_metrics = pd.concat([t_s1, t_s2, t_s3, t_s4, t_s5, t_s6, t_s7, t_s8, t_s9, t_s10,t_s11, t_s12], axis = 1)
    ttm_t1y_metrics.columns=['job_cnt_sameTitle_alldata','job_cnt_sameTitle_51job',
                             'job_cnt_sameTitle_80pct_alldata','job_cnt_sameTitle_80pct_51job', 
                            
 'job_cnt_51job','job_cnt_51job_dedup','job_cnt_alldata_dedup',
                             'job_cnt_alldata','job_cnt_sameTitle_80pct_51job_dedup','job_len_alldata',
                             'job_senti_mean', 'job_cnt_sameTitle_80pct_gdSenti_51job']
    ttm_t1y_metrics = ttm_t1y_metrics.reset_index()
    ttm_t1y_metrics = ttm_t1y_metrics.rename(columns={'index':'ticker'})
    
    ttm_t1y_metrics['datadate'] = dt
    i_ttm_metrics.append(ttm_t1y_metrics)

i_ttm_metrics = pd.concat(i_ttm_metrics, sort = False)
           
# calcualte ttm job counts as of 1 year ago
i_ttm_metrics['datadate_l1y'] = i_ttm_metrics['datadate'] - pd.to_timedelta('365 days')
i_ttm_metrics = i_ttm_metrics.merge(i_ttm_metrics, left_on=['ticker', 'datadate_l1y'], right_on= ['ticker', 'datadate'], how = 'left', suffixes=['','_1y'])
i_ttm_metrics = i_ttm_metrics.drop(columns=['datadate_l1y_1y','datadate_l1y'])



### calculate t1y metrics: unique seg cnt

i_t1y_segCnt = []
for dt in pd.date_range(start='2017-01-01', end ='2020-05-31'):
    print('.', end='')
    
    t_raw_main_features = i_raw_main_features[i_raw_main_features['datadate'].between(dt-pd.to_timedelta('365 days'), dt)]
    t_raw_main_features_51job = t_raw_main_features[t_raw_main_features['source']=='51job']
    
    t_raw_main_features['jd_seg'] = t_raw_main_features['jd_seg'].fillna('')
    t_raw_main_features_51job['jd_seg'] = t_raw_main_features_51job['jd_seg'].fillna('')
    t_s1 = t_raw_main_features.groupby('ticker')['jd_seg'].apply(lambda x: len(set('@'.join(x.tolist()).split('@'))) )
    t_s2 = t_raw_main_features_51job.groupby('ticker')['jd_seg'].apply(lambda x: len(set('@'.join(x.tolist()).split('@'))) )
    
    
    ttm_t1q_metrics = pd.concat([t_s1, t_s2], axis = 1)
    ttm_t1q_metrics.columns=['jd_seg_cnt_alldata','jd_seg_cnt_51job']
    ttm_t1q_metrics = ttm_t1q_metrics.reset_index()
    ttm_t1q_metrics = ttm_t1q_metrics.rename(columns={'index':'ticker'})
    
    ttm_t1q_metrics['datadate'] = dt
    i_t1y_segCnt.append(ttm_t1q_metrics)

i_t1y_segCnt = pd.concat(i_t1y_segCnt, sort = False)
           
# calcualte ttm job counts as of 1 year ago
i_t1y_segCnt['datadate_l1y'] = i_t1y_segCnt['datadate'] - pd.to_timedelta('365 days')
i_t1y_segCnt = i_t1y_segCnt.merge(i_t1y_segCnt, left_on=['ticker', 'datadate_l1y'], right_on= ['ticker', 'datadate'], how = 'left', suffixes=['','_1y'])
i_t1y_segCnt = i_t1y_segCnt.drop(columns=['datadate_l1y_1y','datadate_l1y'])


    
    

### mc

i_mc = yu.get_sql('''se
lect ticker, datadate, mc from [CNDB].[dbo].[UNIVERSE_ALL_CN] 
                    where ticker in ('{0}') '''.format("','".join( i_sd_map['ticker'].str[:6].unique().tolist() )))
i_mc['datadate_1y'] = i_mc['datadate'] - pd.to_timedelta('365 days')
i_mc['datadate_1q'] = i_mc['datadate'] - pd.to_timedelta('91 days')


i_mc = i_mc.sort_values('datadate')

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1q', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1q'})

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1y', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1y'})
i_mc = i_mc.drop(columns = ['datadate_1q', 'datadate_1y'])


c_sh = i_mc['ticker'].str[0].isin(['6'])
c_sz = i_mc['ticker'].str[0].isin(['0', '3'])
i_mc.loc[c_sz, 'ticker'] = i_mc.loc[c_sz, 'ticker'] + '.SZ'
i_mc.loc[c_sh, 'ticker'] = i_mc.loc[c_sh, 'ticker'] + '.SH'



### get sales growth

i_sales_yy = yu.get_sql('''select s_info_windcode as ticker, ann_dt as datadate,
                        report_period, TOT_OPER_REV as rev 
                        from wind.dbo.ashareincome 
                        where statement_type = '408001000' ''')
i_sales_yy = i_sales_yy[i_sales_yy['datadate'].notnull()]
i_sales_yy['datadate'] = pd.to_datetime(i_sales_yy['datadate'], format='%Y%m%d')

i_sales_yy['report_period'] = i_sales_yy['report_period'].astype(int)
i_sales_yy['report_period_1y'] = (i_sales_yy['report_period'] - 10000).astype(int)

i_sales_yy = i_sales_yy.sort_values('datadate')
i_sales_yy = pd.merge_asof(i_sales_yy, i_sales_yy[['ticker','datadate','report_period','rev']],
                           left_by = ['ticker','report_period_1y'], right_by = ['ticker', 'report_period'],
                           on = 'datadate', suffixes = ['', '_merge'])
i_sales_yy = i_sales_yy.drop(columns = ['report_period_merge','report_period_1y'])
i_sales_yy = i_sales_yy.rename(columns = {'rev_merge': 'rev_1y'})

i_sales_yy = i_sales_yy.sort_values(['ticker','datadate'])
i_sales_yy['max_report_date'] = i_sales_yy.groupby('ticker')['report_period'].cummax()
i_sales_yy = i_sales_yy[i_sales_yy['report_period']>=i_sales_yy['max_report_date']]

i_sales_yy['re
v_yy'] = i_sales_yy['rev'].divide(i_sales_yy['rev_1y'])
i_sales_yy['rev_yy'] = i_sales_yy['rev_yy'].replace(np.inf, np.nan).replace(-np.inf, np.nan)

i_sales_yy = i_sales_yy.drop(columns = ['report_period', 'max_report_date'])
i_sales_yy = i_sales_yy.sort_values('datadate')



### get factors
i_factor = pw.get_barra_factors(date_start='2016-06-01', date_end='2021-12-31')
c_sh = i_factor['code'].str[0].isin(['6'])
c_sz = i_factor['code'].str[0].isin(['0', '3'])
i_factor.loc[c_sh, 'ticker'] = i_factor.loc[c_sh, 'code'] + '.SH'
i_factor.loc[c_sz, 'ticker'] = i_factor.loc[c_sz, 'code'] + '.SZ'


###



i_own = yu.get_sql('''select a.S_INFO_COMPCODE, b.s_info_windcode as ticker, a.wind_sec_code as ownership from wind.dbo.AShareOwnership a 
                inner join wind.dbo.windcustomcode b
                on a.s_info_compcode = b.s_info_compcode
                where (b.s_info_windcode like '%.SH') or (b.s_info_windcode like '%.SZ')
                ''')
i_own = i_own[i_own['ticker'].isin(i_sd['ticker'].unique().tolist())]
i_own_tk = i_own.groupby('ticker')['ownership'].apply(lambda x: '@'.join(x.tolist())).reset_index()
tk_yangqi_lst = i_own_tk[i_own_tk['ownership']=='0805010100']['ticker'].unique().tolist()
tk_private_lst = i_own_tk[i_own_tk['ownership'].isin(['0805020000','0805030000','0805050000'])]['ticker'].unique().tolist()




#------------------------------------------------------------------------------
### combine



#icom = i_sd[i_sd['a50_300_flag']==1].merge(i_ttm_metrics, on =['ticker','datadate'], how = 'left')

icom = i_sd.merge(i_ttm_metrics, on =['ticker','datadate'], how = 'left')


icom = icom.merge(i_t1y_segCnt, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_factor, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(i_mc, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_gm[['ticker','datadate','exp_rev']], on = ['ticker', 'datadate'], how = 'left')

#icom = icom.sort_values('datadate')
#i_sales_yy = i_sales_yy.sort_values('datadate')
#icom = pd.merge_asof(icom, i_sales_yy[['ticker','datadate','rev_yy']], by='ticker', on = 'datadate')
icom = icom.sort_values(['ticker','datadate'])

#icom['rev_yy_rk'] = icom.groupby('datadate')['rev_yy'].apply(yu.uniformed_rank).values
#icom['rev_yy_5bk'] = icom.groupby('datadate')['rev_yy'].apply(lambda x: yu.pdqcut(x,bins=5)).values
icom['mc_1y_rk'] = icom.groupby('datadate')['mc_1y'].apply(yu.uniformed_rank).values
icom['mc_1y_5bk'] = icom.groupby('datadate')['mc_1y'
].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom['job_cnt_51job_dv_mc'] = icom['job_cnt_51job'].divide(icom['mc_1y'])
icom['job_cnt_51job_dv_mc_5bk'] = icom.groupby('datadate')['job_cnt_51job_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom['growth_rk'] = -icom.groupby('datadate')['GROWTH'].apply(yu.uniformed_rank).values # higher = worse
icom['leverage_rk'] = icom.groupby('datadate')['LEVERAGE'].apply(yu.uniformed_rank).values # higher = worse


icom2 = icom.copy()


#------------------------------------------------------------------------------
### backtest






# job cnt growth - 51job, sameTitle, good sentiment

icom2['job_cnt_df1y_51job'] = icom2['job_cnt_sameTitle_80pct_gdSenti_51job'] - icom2['job_cnt_sameTitle_80pct_gdSenti_51job_1y']
icom2['job_cnt_df1y_51job_dv_mc']  = icom2['job_cnt_df1y_51job'].divide(icom2['mc_1y'])
icom2['job_cnt_df1y_51job_dv_mc_bk'] = icom2.groupby('datadate')['job_cnt_df1y_51job_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['job_cnt_df1y_51job_dv_mc_rk'] = icom2.groupby('datadate')['job_cnt_df1y_51job_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_cnt_df1y_51job_dv_mc_secrk'] = icom2.groupby(['datadate','GSECTOR'])['job_cnt_df1y_51job_dv_mc'].apply(yu.uniformed_rank).values


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_cnt_df1y_51job_dv_mc_rk']>0.6)].\
            dropna(subset=['job_cnt_df1y_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_cnt_df1y_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.59 / 2.31 // 2.16 / 1.7

icom2['test'] = icom2.groupby('datadate')['job_senti_mean'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['test']>0.8)].\
            dropna(subset=['test','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.59 / 2.31 // 2.16 / 1.7




# jon cnt growth - 51job, sameTitle

cols_factor = ['bf_LIQUIDTY', 'bf_LEVERAGE', 'bf_BTOP', 'bf_SIZE', 
                   'bf_MOMENTUM', 'bf_SRISK', 'bf_SPREAD', 'bf_AVGPVADJ', 'bf_RESVOL', 'bf_TURNOVER', 
                   'G_45', 'G_20', 'G_25', 'G_35', 'G_15', 'G_55', 'G_30', 'G_40', 'G_60', 'G_10', 'G_50']
icom2['job_sameCnt_df1y_80pct_51job'] = icom2['job_cnt_sameTitle_80pct_51job'] - icom2['job_cnt_sameTitle_80pct_51job_1y']
icom2['job_sameCnt_df1y_80pct_51job_orth']  = icom2.groupby('datadate')[cols_factor+
['job_sameCnt_df1y_80pct_51job']].apply(lambda x: yu.orthogonalize_cn(x['job_sameCnt_df1y_80pct_51job'],x[cols_factor], method='raw')).values

icom2['job_sameCnt_df1y_80pct_51job_dv_mc']  = icom2['job_sameCnt_df1y_80pct_51job'].divide(icom2['mc_1y'])
icom2['job_sameCnt_df1y_80pct_51job_dv_mc_orth']  = icom2.groupby('datadate')[cols_factor+['job_sameCnt_df1y_80pct_51job_dv_mc']].apply(lambda x: yu.orthogonalize_cn(x['job_sameCnt_df1y_80pct_51job_dv_mc'],x[cols_factor], method='raw')).values

icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk'] = icom2.groupby('datadate')['job_sameCnt_df1y_80pct_51job_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_sameCnt_df1y_80pct_51job_orth_rk'] = icom2.groupby('datadate')['job_sameCnt_df1y_80pct_51job_orth'].apply(yu.uniformed_rank).values
icom2['job_sameCnt_df1y_80pct_51job_dv_mc_orth_rk'] = icom2.groupby('datadate')['job_sameCnt_df1y_80pct_51job_dv_mc_orth'].apply(yu.uniformed_rank).values
icom2['job_sameCnt_df1y_80pct_51job_dv_mc_bk'] = icom2.groupby('datadate')['job_sameCnt_df1y_80pct_51job_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['job_sameCnt_df1y_80pct_51job_dv_mc_secrk'] = icom2.groupby(['datadate','GSECTOR'])['job_sameCnt_df1y_80pct_51job_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_sameCnt_df1y_80pct_51job_dv_mc_mcrk'] = icom2.groupby(['datadate','mc_1y_5bk'])['job_sameCnt_df1y_80pct_51job_dv_mc'].apply(yu.uniformed_rank).values




o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.41 / 2.01 // 1.17 / 1.13


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.59 / 2.31 // 2.16 / 1.7


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['LEVERAGE']>0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', s
tatic_data = i_sd) # 0.87/0.5 // 0.22/-0.17
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['LEVERAGE']<0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.5/2.32 // 2.29 / 1.89


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['exp_rev_secrk']>0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.5/1.31 // 2.17 / 1.8
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['exp_rev_secrk']<0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.06/1.86 // 1.11 / 0.75


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['corr']>0.5)&(icom2['exp_rev_secrk']>0.5)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.18/1.06 // 1.21 / 0.96
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['corr']>0.5)&(icom2['exp_rev_secrk']<0.5)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.56/0.38 // 0.3 / 0.1
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['corr']>0.5)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker'
,'datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.09 / 0.89 // 1.01 / 0.71
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        ((icom2['corr']<0.5)| icom2['corr'].isnull())].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.5 / 2.24 // 2.04 / 1.61


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['GROWTH']>0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # ?/? // 2.26 / 1.87
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['GROWTH']<=0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # ?/? // 0.44 / 0.05




o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['STAFFNUM_yy']<0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.22 / 0.02 //
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['STAFFNUM_yy']>0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.55 / 2.29 //



###!!!
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['growth_rk']<0) & (icom2['leverage_rk']<0)].\
            dropna(subset=['job_sameCnt_df1y_80pc
t_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.77 / 2.61 // 1.92 / 1.63
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['growth_rk']<0) & (icom2['leverage_rk']<0.5)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.36 / 2.17 // 2.66 / 2.3


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_orth_rk']>0.6)&\
                        (icom2['growth_rk']<0) & (icom2['leverage_rk']<0.5)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # ? / ? // 2.07 / 1.33

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_orth_rk']>0.6)&\
                        (icom2['growth_rk']<0) & (icom2['leverage_rk']<0.5)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # ? / ? // 1.05 / 0.22


yu.create_cn_3x3(icom2, ['job_sameCnt_df1y_80pct_51job_dv_mc_bk'], 'job_sameCnt_df1y_80pct_51job_dv_mc')

for s in GSEC.keys():
    print(GSEC[s])
    try:
        o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                            (icom2['growth_rk']<0) & (icom2['leverage_rk']<0.5) & (icom2['GSECTOR']==s)].\
                dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
                'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) 
    except ValueError:
        print(GSEC[s] + ' wrong')



o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['prod_expansion_score_rk']>0.6)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job
_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # ?/? // 1.74/1.39
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['prod_expansion_score_rk'].between(0.2,0.6))].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # ?/? // 0.79 / 0.36
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['prod_expansion_score_rk'].between(-0.2,0.2))].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # ?/? // 0.46 / 0.14
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['prod_expansion_score_rk'].between(-0.6,-0.2))].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # ?/? // 1.04/0.67
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['prod_expansion_score_rk']<=-0.6)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # ?/? // 1.13/0.83
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['prod_expansion_score_rk']<0.5)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # ?/? // 1.9 / 1.48





o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_
dv_mc_rk']>0.6)&\
                        (icom2['rev_yy_rk']>0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.11 / 1.83 // 2.63 / 2.24

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&\
                        (icom2['rev_yy_rk']<0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.38 / 1.07 // 0.03 / -0.38

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&(icom2['mc_1y_rk']<0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.55 / 3.27 // 0.82 / 0.3

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&(icom2['mc_1y_rk']>0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # -0.85 / -1.21 // 2.33 / 1.87


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0)&(icom2['mc_1y_rk']<0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.67 / 3.39 // 0.67 / 0.14

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0)&(icom2['mc_1y_rk']>0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # ? / ? // 2.6 / 2.07







icom2['job_sameCnt_df1y_51job'] = icom2['job_cnt_sameTitle_51job'] - icom2['job_cnt_sameTitle_51job_1y']
icom2['job_sameCnt_df1y_51job_dv_mc']  = ico
m2['job_sameCnt_df1y_51job'].divide(icom2['mc_1y'])
icom2['job_sameCnt_df1y_51job_dv_mc_bk'] = icom2.groupby('datadate')['job_sameCnt_df1y_51job_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['job_sameCnt_df1y_51job_dv_mc_rk'] = icom2.groupby('datadate')['job_sameCnt_df1y_51job_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_sameCnt_df1y_51job_dv_mc_secrk'] = icom2.groupby(['datadate','GSECTOR'])['job_sameCnt_df1y_51job_dv_mc'].apply(yu.uniformed_rank).values


icom2['job_sameCnt_df1y_alldata'] = icom2['job_cnt_sameTitle_alldata'] - icom2['job_cnt_sameTitle_alldata_1y']
icom2['job_sameCnt_df1y_alldata_dv_mc']  = icom2['job_sameCnt_df1y_alldata'].divide(icom2['mc_1y'])
icom2['job_sameCnt_df1y_alldata_dv_mc_bk'] = icom2.groupby('datadate')['job_sameCnt_df1y_alldata_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['job_sameCnt_df1y_alldata_dv_mc_rk'] = icom2.groupby('datadate')['job_sameCnt_df1y_alldata_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_sameCnt_df1y_alldata_dv_mc_secrk'] = icom2.groupby(['datadate','GSECTOR'])['job_sameCnt_df1y_alldata_dv_mc'].apply(yu.uniformed_rank).values

icom2['job_sameCnt_df1y_80pct_alldata'] = icom2['job_cnt_sameTitle_80pct_alldata'] - icom2['job_cnt_sameTitle_80pct_alldata_1y']
icom2['job_sameCnt_df1y_80pct_alldata_dv_mc']  = icom2['job_sameCnt_df1y_80pct_alldata'].divide(icom2['mc_1y'])
icom2['job_sameCnt_df1y_80pct_alldata_dv_mc_bk'] = icom2.groupby('datadate')['job_sameCnt_df1y_80pct_alldata_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['job_sameCnt_df1y_80pct_alldata_dv_mc_rk'] = icom2.groupby('datadate')['job_sameCnt_df1y_80pct_alldata_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_sameCnt_df1y_80pct_alldata_dv_mc_secrk'] = icom2.groupby(['datadate','GSECTOR'])['job_sameCnt_df1y_80pct_alldata_dv_mc'].apply(yu.uniformed_rank).values

icom2['job_sameCnt_df1y_80pct_51jobDD_hWage'] = icom2['job_cnt_sameTitle_80pct_51job_dedup_hWage'] - icom2['job_cnt_sameTitle_80pct_51job_dedup_hWage_1y']
icom2['job_sameCnt_df1y_80pct_51jobDD_hWage_dv_mc']  = icom2['job_sameCnt_df1y_80pct_51jobDD_hWage'].divide(icom2['mc_1y'])
icom2['job_sameCnt_df1y_80pct_51jobDD_hWage_dv_mc_bk'] = icom2.groupby('datadate')['job_sameCnt_df1y_80pct_51jobDD_hWage_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['job_sameCnt_df1y_80pct_51jobDD_hWage_dv_mc_rk'] = icom2.groupby('datadate')['job_sameCnt_df1y_80pct_51jobDD_hWage_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_sameCnt_df1y_80pct_51jobDD
_hWage_dv_mc_secrk'] = icom2.groupby(['datadate','GSECTOR'])['job_sameCnt_df1y_80pct_51jobDD_hWage_dv_mc'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51jobDD_hWage_dv_mc_rk']>0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51jobDD_hWage_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51jobDD_hWage_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.62 / 2.29

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51jobDD_hWage_dv_mc_rk']>0)&(icom2['mc_1y_rk']<0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51jobDD_hWage_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51jobDD_hWage_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.62 / 2.29







yu.create_cn_3x3(icom2, ['job_cnt_df1y_alldata_dv_mc_bk'], 'job_cnt_df1y_alldata_dv_mc')
yu.create_cn_3x3(icom2, ['job_cnt_df1y_51job_dv_mc_bk'], 'job_cnt_df1y_51job_dv_mc')
yu.create_cn_3x3(icom2, ['job_cnt_df1y_51jobDD_dv_mc_bk'], 'job_cnt_df1y_51jobDD_dv_mc')
yu.create_cn_3x3(icom2, ['job_sameCnt_df1y_51job_dv_mc_bk'], 'job_sameCnt_df1y_51job_dv_mc')
yu.create_cn_3x3(icom2, ['job_cnt_df1y_alldata_dv_mc_bk'], 'job_cnt_df1y_alldata_dv_mc')
yu.create_cn_3x3(icom2, ['job_cnt_df1y_80pct_alldata_dv_mc_bk'], 'job_cnt_df1y_80pct_alldata_dv_mc')
yu.create_cn_3x3(icom2, ['job_cnt_df1y_80pct_51job_dv_mc_bk'], 'job_cnt_df1y_80pct_51job_dv_mc')
yu.create_cn_3x3(icom2, ['job_sameCnt_df1y_80pct_51job_dv_mc_bk'], 'job_sameCnt_df1y_80pct_51job_dv_mc')

yu.create_cn_3x3(icom2[icom2['rev_yy_rk']<0], ['job_sameCnt_df1y_80pct_51job_dv_mc_bk'], 'job_sameCnt_df1y_80pct_51job_dv_mc')
yu.create_cn_3x3(icom2[icom2['rev_yy_5bk']==0], ['job_sameCnt_df1y_80pct_51job_dv_mc_bk'], 'job_sameCnt_df1y_80pct_51job_dv_mc')

yu.create_cn_3x3(icom2[icom2['mc_1y_rk']>0], ['job_sameCnt_df1y_80pct_51job_dv_mc_bk'], 'job_sameCnt_df1y_80pct_51job_dv_mc')
yu.create_cn_3x3(icom2[icom2['mc_1y_rk']<0], ['job_sameCnt_df1y_80pct_51job_dv_mc_bk'], 'job_sameCnt_df1y_80pct_51job_dv_mc')



o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['job_sameCnt_df1y_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.03 / 1.51

o_1 = 
yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_51job_dv_mc_rk']>=0)].\
            dropna(subset=['job_sameCnt_df1y_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.17 / 1.8



o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['job_sameCnt_df1y_80pct_alldata_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_alldata_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.51 / 2.01

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_alldata_dv_mc_rk']>0.6)].\
            dropna(subset=['job_sameCnt_df1y_80pct_alldata_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_alldata_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.2 / 1.88




o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_mcrk']>0)].\
            dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_mcrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_sameCnt_df1y_80pct_51job_dv_mc_mcrk','BarrRet_CLIP_USD+1d', static_data = i_sd) # ?/? // 2.58 / 1.95


for i in range(5):
    
    o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_sameCnt_df1y_80pct_51job_dv_mc_rk']>0.6)&(icom2['job_cnt_51job_dv_mc_5bk']==i)].\
                dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
                'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.56 / 2.23 // 2.16 / 1.7
    

for s in GSEC.keys():
    print (GSEC[s])
    
    o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['GSECTOR']==s)].\
                dropna(subset=['job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
                'job_sameCnt_df1y_80pct_51job_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.38 / 1.88


    

# the IT idea
# 'job_cnt_51job_hWage', 'job_cnt_51job_dedup_hWage', 'job_cnt_51job_sameTitle_80pct_dedup_hWage'

icom2 = icom.copy()

icom2['job_cnt_df1y'] = icom2['job_cnt_51job_dedup_hWage'] - icom2['job_cnt_51job_dedup_hWage_1y']
icom2['job_cnt_df1y_
dv_ta'] = icom2['job_cnt_df1y'].divide(icom2['t_asset'])
icom2['job_cnt_df1y_dv_ta_secrk'] = icom2.groupby(['datadate','GSECTOR'])['job_cnt_df1y_dv_ta'].apply(yu.uniformed_rank).values
icom2['job_cnt_df1y_dv_ta_bk'] = icom2.groupby('datadate')['job_cnt_df1y_dv_ta'].apply(lambda x: yu.pdqcut(x,bins=10)).values


icom2['job_cnt_sameTitle_80pct_51job_dedup_hWage_df1y'] = icom2['job_cnt_sameTitle_80pct_51job_dedup_hWage'] - icom2['job_cnt_sameTitle_80pct_51job_dedup_hWage_1y']
icom2['job_cnt_sameTitle_80pct_51job_dedup_hWage_df1y_dv_mc'] = icom2['job_cnt_sameTitle_80pct_51job_dedup_hWage_df1y'].divide(icom2['mc_1y'])
icom2['job_cnt_sameTitle_80pct_51job_dedup_hWage_df1y_dv_mc_secrk'] = icom2.groupby(['datadate','GSECTOR'])['job_cnt_sameTitle_80pct_51job_dedup_hWage_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_cnt_sameTitle_80pct_51job_dedup_hWage_df1y_dv_mc_bk'] = icom2.groupby('datadate')['job_cnt_sameTitle_80pct_51job_dedup_hWage_df1y_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['GSECTOR']=='45')&(icom2['job_cnt_df1y_dv_ta_secrk']>0.8)].\
            dropna(subset=['job_cnt_df1y_dv_ta_secrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_cnt_df1y_dv_ta_secrk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.15 / 1.01


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['job_cnt_df1y_dv_ta_secrk']>0.8)].\
            dropna(subset=['job_cnt_df1y_dv_ta_secrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_cnt_df1y_dv_ta_secrk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.15 / 1.01


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['GSECTOR']=='45')&(icom2['job_cnt_sameTitle_80pct_51job_dedup_hWage_df1y_dv_mc_secrk']>0.8)].\
            dropna(subset=['job_cnt_sameTitle_80pct_51job_dedup_hWage_df1y_dv_mc_secrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_cnt_sameTitle_80pct_51job_dedup_hWage_df1y_dv_mc_secrk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.26 / 1.19



# the actual employment idea 
# not working
