﻿#$%^&* pL2_cn_trod_vwap_spike.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 29 21:52:28 2022

@author: thzhang
"""




import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime



#  This studies TWAP capture data (1min spikes)



### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])




### get VWAP capture data 

i_capvwap = yu.get_q('''get `:/export/datadev/Data/SHSZ/TRADE_metrics/i_trd_spikes''')

i_capvwap['code'] = i_capvwap['code'].str.decode('utf8')
c_sh = i_capvwap['code'].str[0].isin(['6'])
c_sz = i_capvwap['code'].str[0].isin(['0','3'])
i_capvwap.loc[c_sh, 'ticker'] = i_capvwap.loc[c_sh, 'code'] + '.SH'
i_capvwap.loc[c_sz, 'ticker'] = i_capvwap.loc[c_sz, 'code'] + '.SZ'
i_capvwap['datadate'] = pd.to_datetime(i_capvwap['date'])
i_capvwap = i_capvwap.sort_values(['ticker', 'datadate'])
i_capvwap = i_capvwap[i_capvwap['ticker'].notnull()]


### combine

icom = i_sd.merge(i_capvwap, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])


COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']

'b_dcSPK_d_pctSelf', 'b_dcSPK_cnt_pctSelf',
'b_dcLoneSPK_d_pctSelf', 'b_dcLoneSPK_cnt_pctSelf', 's_dcSPK_d_pctSelf',
's_dcSPK_cnt_pctSelf', 's_dcLoneSPK_d_pctSelf',
's_dcLoneSPK_cnt_pctSelf'


### bar charts

icom['b_dcSPK_d_pctSelf'] = icom['b_dcSPK_d_pctSelf'].replace(0, np.nan)
icom['b_dcSPK_d_pctSelf_bk'] = icom.groupby('datadate')['b_dcSPK_d_pctSelf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['s_dcSPK_d_pctSelf'] = icom['s_dcSPK_d_pctSelf'].replace(0, np.nan)
icom['s_dcSPK_d_pctSelf_bk'] = icom.groupby('datadate')['s_dcSPK_d_pctSelf'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['b_dcSPK_d_pctSelf_bk'], 'b_dcSPK_d_pctSelf') # less mono: +1 +1.5 -5
yu.create_cn_3x3(icom, ['s_dcSPK_d_pctSelf_bk'], 's_dcSPK_d_pctSelf') # mono: +2 -4.5

icom['b_dcLoneSPK_d_pctSelf'] = icom['b_dcLoneSPK_d_pctSelf'].replace(0, np.nan)
icom['b_dcLoneSPK_d_pctSelf_bk'] = icom.groupby('datadate')['b_dcLoneSPK_d_pctSelf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['s_dcLoneSPK_d_pctSelf'] = icom['s_dcLoneSPK_d_pctSelf'].replace(0, np.nan)
icom['s_dcLoneSPK_d_pctSelf_bk'] = icom.groupby('datadate')['s_dcLoneSPK_d_pctSelf'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['b_dcLoneSPK_d_pctSelf_bk'], 'b_dcLoneSPK_d_pctSelf') # random
yu.cr
eate_cn_3x3(icom, ['s_dcLoneSPK_d_pctSelf_bk'], 's_dcLoneSPK_d_pctSelf') # random


icom['b_dcSPK_cnt_pctSelf'] = icom['b_dcSPK_cnt_pctSelf'].replace(0, np.nan)
icom['b_dcSPK_cnt_pctSelf_bk'] = icom.groupby('datadate')['b_dcSPK_cnt_pctSelf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['s_dcSPK_cnt_pctSelf'] = icom['s_dcSPK_cnt_pctSelf'].replace(0, np.nan)
icom['s_dcSPK_cnt_pctSelf_bk'] = icom.groupby('datadate')['s_dcSPK_cnt_pctSelf'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['b_dcSPK_cnt_pctSelf_bk'], 'b_dcSPK_cnt_pctSelf') # less mono: +1 +1.5 -3
yu.create_cn_3x3(icom, ['s_dcSPK_cnt_pctSelf_bk'], 's_dcSPK_cnt_pctSelf') # mono: +2 -6



###

icom['s_dcSPK_cnt_pctSelf_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['s_dcSPK_cnt_pctSelf'].mean().values
icom['s_dcSPK_cnt_pctSelf_t20d_orth'] = icom.groupby('datadate')[['s_dcSPK_cnt_pctSelf_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['s_dcSPK_cnt_pctSelf_t20d'], x[COLS])).values
icom['s_dcSPK_cnt_pctSelf_t20d_orth_sgnl'] = - icom.groupby('datadate')['s_dcSPK_cnt_pctSelf_t20d_orth'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['s_dcSPK_cnt_pctSelf_t20d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            's_dcSPK_cnt_pctSelf_t20d_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.83 / 0.49
