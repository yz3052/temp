﻿#$%^&* pSYNC_cn_genalpha_v20230808.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Apr 29 08:47:28 2023

@author: thzhang
"""

import pandas as pd
import numpy as np

import datetime
import os

import pSYNC_ml as syncml

import util as yu
from multiprocessing import Pool

import xgboost as xgb

# in production mode, generate model and alpha 
# 0808 uses CNDBPROD's xgb tables as features, 0807 uses my proprietary features



VERSION = '20230808'


#------------------------------------------------------------------------------
### helpder
#------------------------------------------------------------------------------

import scipy.stats as ss

def Rank2Uni(x,m=float('inf')):
    r = x.rank(method = 'min')
    rmax = r.max()
    if ~np.isfinite(m):
        r = r/(rmax+1)
        return r
    else:
        p = ss.norm.cdf(m)
        r = r/(rmax-1)
        r = r - (r.max()-1)
        r = (2*p-1)*r+(1-p)
        return r
def Winsorize(x,m):
    x[x>m]=m
    x[x<-m]=-m
    return x
def renorm(r):
    rindex = r.index
    res = Winsorize(ss.norm.ppf(Rank2Uni(r, 3)),3)
    rdf = pd.DataFrame(res)
    rdf = rdf.set_index(rindex)
    return rdf



#------------------------------------------------------------------------------
### param
#------------------------------------------------------------------------------

today = pd.to_datetime(datetime.datetime.today()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
today = pd.to_datetime(today.date())
today_p7d = today+pd.to_timedelta('7 days')
today_p7d_str = today_p7d.strftime('%Y-%m-%d')
today_str = today.strftime('%Y-%m-%d')

today_currmonthstart = pd.to_datetime(today.strftime('%Y-%m-01'))
today_prevmonth_str = (today_currmonthstart - pd.to_timedelta('1 day')).strftime('%Y%m')

cal_since_2019 = pd.DataFrame({'date': pd.date_range(start='2019-01-01',end=today)})
cal_since_2019['month_start'] = pd.to_datetime(cal_since_2019['date'].dt.strftime('%Y-%m-01'))
cal_since_2019['model'] = (cal_since_2019['month_start'] - pd.to_timedelta('1 day')).dt.strftime('%Y%m')



#------------------------------------------------------------------------------
### determine the model to be trained
#------------------------------------------------------------------------------

root_model = '/dat/summit_capital/TZ/PROD_MODEL/xgb_'+VERSION
if not os.path.exists(root_model):
    os.mkdir(root_model)   

existing_models = os.listdir(root_model)
required_models = cal_since_2019['model'].drop
_duplicates().sort_values().tolist()[:-1]
models_to_train = [i for i in required_models if i not in existing_models]





#------------------------------------------------------------------------------
### train models - load data
#------------------------------------------------------------------------------

if len(models_to_train) > 0:
    
    
    i_feat = yu.get_sql('''
                          select a1.DataDate, a1.Ticker, a1.alpha as a1_sgnl, a2.alpha as a2_sgnl,
  a3.alpha as a3_sgnl, a4.alpha as a4_sgnl, a5.alpha as a5_sgnl,
  a6.alpha as a6_sgnl, a10.alpha as a10_sgnl, a11.alpha as a11_sgnl   
  from cndbprod.dbo.SMTCN_CHILDALPHA_F001_XGB_CSI1800 a1 
  inner join cndbprod.dbo.SMTCN_CHILDALPHA_F002_XGB_CSI1800 a2
  on a1.DataDate=a2.DataDate and a1.Ticker=a2.Ticker
  inner join cndbprod.dbo.SMTCN_CHILDALPHA_F003_XGB_CSI1800 a3
  on a1.DataDate=a3.DataDate and a1.Ticker=a3.Ticker
  inner join cndbprod.dbo.SMTCN_CHILDALPHA_F004_XGB_CSI1800 a4
  on a1.DataDate=a4.DataDate and a1.Ticker=a4.Ticker
  inner join cndbprod.dbo.SMTCN_CHILDALPHA_F005_XGB_CSI1800 a5
  on a1.DataDate=a5.DataDate and a1.Ticker=a5.Ticker
  inner join cndbprod.dbo.SMTCN_CHILDALPHA_F006_XGB_CSI1800 a6
  on a1.DataDate=a6.DataDate and a1.Ticker=a6.Ticker
  inner join cndbprod.dbo.SMTCN_CHILDALPHA_F010_XGB_CSI1800 a10
  on a1.DataDate=a10.DataDate and a1.Ticker=a10.Ticker
  inner join cndbprod.dbo.SMTCN_CHILDALPHA_F011_XGB_CSI1800 a11
  on a1.DataDate=a11.DataDate and a1.Ticker=a11.Ticker 
                        ''')
    
    
    
    
        
    df_cd = yu.get_sql('''
                        select distinct TradeDate_next as DataDate
                        from CNDBPROD.dbo.Calendar_Dates_CN
                        where TradeDate_next >= '2015-01-01' and TradeDate_next<= '{0}'
                        order by TradeDate_next
                        '''.format(today_p7d_str))
    df_cd['T-1d'] = df_cd['DataDate'].shift(1)
    df_cd['DataDate_p1d'] = df_cd['DataDate'].shift(-1)
    df_cd = df_cd.dropna()


    
    df_universe_all = yu.get_sql('''
                            select DataDate as [T-1d], Ticker, avgPVadj_USD as avgPVadj 
                            from CNDBPROD.dbo.universe_all_cn_gem3l 
                            where DataDate <= '{0}'
                            and DataDate >= '2015-01-01'
                            '''.format(today_p7d_str))
    df_universe_all = df_universe_all.drop_duplicates(subset=['Ticker','T-1d'],keep='last')
    df_universe_1800 =
 yu.get_sql('''
                            select DataDate as [T-1d], Ticker 
                            from CNDBPROD.dbo.universe_csi1800
                            where DataDate <= '{0}'
                            and DataDate >= '2015-01-01'
                            '''.format(today_p7d_str))
    df_universe_1800 = df_universe_1800.drop_duplicates(subset=['Ticker','T-1d'],keep='last')
    df_universe = df_universe_1800.merge(df_universe_all, on = ['T-1d', 'Ticker'], how = 'left')
    del df_universe_all, df_universe_1800
                        
        
    df_ret_20d = yu.get_sql('''select  DataDate, Ticker, BarrRet_CLIP20d
                             from CNDBPROD.dbo.BARRA_GEM3L_YRRET_CSI1800
                             where DataDate <= '{0}' 
                             and DataDate >= '2015-01-01' 
                             '''.format(today_p7d_str))
    
    
                    
    df_universe = pd.merge(df_universe, df_cd, on=['T-1d'], how='inner')
    df_universe = pd.merge(df_universe, df_ret_20d, on=['DataDate','Ticker'], how='left')
    df_universe = df_universe.reset_index(drop=True)
    del df_ret_20d
    
    df_universe['BarrRet_CLIP20d_renorm'] = df_universe.groupby('DataDate')['BarrRet_CLIP20d'].apply(renorm)
    
        
    i_all = i_feat.merge(df_universe, on = ['Ticker', 'DataDate'], how = 'inner')
    i_all['clip'] = i_all['avgPVadj'].apply(lambda r: min([r*0.01,1e6]))
    i_all['wts'] = i_all['clip']
    i_all= i_all.dropna(subset = ['wts'])


    
    df_cd = yu.get_sql('''select distinct TradeDate_next as DataDate
                        from CNDBPROD.dbo.Calendar_Dates_CN
                        order by TradeDate_next''')
    df_calendars = df_cd['DataDate'].tolist()
    
        
    config_feature = i_all.columns.tolist()
    config_feature = [i for i in config_feature if i.endswith('sgnl')]    
    config_mono = {i:1 for i in config_feature if i[:3]!='flg' and i[:3]!='ipo'}
    
    configs = {
             'data_name': 'df_data',
             'universe_name': 'df_universe',
             'wts_type': 'clip',
             'feature_tables': [],
             'universe_table_name': 'UNIVERSE_T1800_CN_GEM3L',
             'ret_table_name': 'BARRA_GEM3L_YRRET',
             'startdate': '20160101',
             'enddate': '20221231',
             'used_ret_col': 'BarrRet_CLIP20d_renorm',
             'fold': 10,
             'purged_days': 22,
             'rolling_days': 504,
             'features': config_fe
ature, 
             'monotone_features': config_mono,
             'metric_method': 'rscore', #'nll' for reg:logistic, 'rscore' for reg:sqaurederror
             'loss_function': 'reg:squarederror', #'reg:logistic','reg:squarederror'
             'eta_min': 0.01,
             'eta_max': 0.5,
             'gamma_min': 0,
             'gamma_max': 1000,
             'md_min': 5,
             'md_max': 15,
             'mcw_min': 1 ,
             'mcw_max': 1000,
             'subsample_min': 0.5,
             'subsample_max': 1,
             'colsample_bytree_min': 0.5,
             'colsample_bytree_max': 1,
             'colsample_bylevel_min': 0.5,
             'colsample_bylevel_max': 1,
             'colsample_bynode_min': 0.5,
             'colsample_bynode_max': 1,
             'lambda_min': 0,
             'lambda_max': 1000,
             'alpha_min': 0,
             'alpha_max': 1000,
             'esr': 100,
             'n_trials': 20,
             'tot_waittime': 12000,
             'grow_policy': 'depthwise',
             'learning_method':'gbtree',
             'missing_data':'NaN',
             'importance_type': 'gain',
             'lookback_method': 'rolling',  # 'rolling' or 'expanded'
             'interaction_features':[]
             }

 


#------------------------------------------------------------------------------
### train models 
#------------------------------------------------------------------------------

# create folders

save_model_root = '/dat/summit_capital/TZ/PROD_MODEL/xgb_'+VERSION+'/'
if not os.path.exists(save_model_root):
    os.mkdir(save_model_root)

# helpder function

def helper_model(m):
    
    # parmas
    
    #year = m[:4]
    #month = m[-2:]
        
    # create folders
    
    save_model_path = save_model_root+m
    if not os.path.exists(save_model_path):
        os.mkdir(save_model_path)

    # get alppha dates
    
    date_windows = df_cd[['DataDate']]
    alphadates = date_windows[ date_windows['DataDate'].dt.strftime('%Y%m')==m]
    alphadates = alphadates['DataDate'].tolist()
    alphadates.sort()
    
    # the model
    
    syncml.prepare_monthly_models(i_all, df_universe, df_calendars, alphadates, configs, save_model_path)
    


if __name__ == '__main__':
    
    with Pool(32) as p:        
        p.map(helper_model, models_to_train)
        



#------------------------------------------------------------------------------
### get alphadates to query
#------------------------------------
------------------------------------------

if not os.path.exists('/dat/summit_capital/TZ/PROD_PST/desired_pst_'+VERSION):
    os.mkdir('/dat/summit_capital/TZ/PROD_PST/desired_pst_'+VERSION)

alphadates_existing = os.listdir('/dat/summit_capital/TZ/PROD_PST/desired_pst_'+VERSION)

i_cal = yu.get_sql('''select distinct TradeDate_next as DataDate 
                   FROM [CNDBPROD].[dbo].[Calendar_Dates_CN] 
                   where TradeDate_next<='{0}' and DataDate>='2016-01-01'
                   order by TradeDate_next '''.format(today_str))
i_cal['T-1d'] = i_cal['DataDate'].shift()
i_cal['parq'] = i_cal['DataDate'].dt.strftime('%Y%m%d.parquet')
i_cal = i_cal[i_cal['DataDate']>='2019-01-01']

alphadates_to_query = [i for i in i_cal['parq'].tolist() if i not in alphadates_existing]





#------------------------------------------------------------------------------
### generate alpha
#------------------------------------------------------------------------------


root_alpha = '/dat/summit_capital/TZ/PROD_ALPHA'
if not os.path.exists(os.path.join(root_alpha, 'alpha_'+VERSION)):
    os.mkdir(os.path.join(root_alpha, 'alpha_'+VERSION))


for dd in alphadates_to_query:
    d = pd.to_datetime(dd, format = '%Y%m%d.parquet')
    d_lastmonth_str = (pd.to_datetime(d.strftime('%Y-%m-01'))-pd.to_timedelta('33 days')).strftime('%Y%m')
    t1d = pd.to_datetime(i_cal.loc[i_cal['DataDate'].eq(d), 'T-1d'].values[0])
    
    # sanity check
    if d_lastmonth_str<'202005':
        continue
    
    # load model
    root_model = '/dat/summit_capital/TZ/PROD_MODEL/xgb_'+VERSION+'/'+d_lastmonth_str
    models = os.listdir(root_model)
    models = [i for i in models if 'fscore' not in i]
        
    # load descriptors    
    
    i_enrich = i_feat[i_feat['DataDate'].eq(d)]
    i_enrich_key = i_enrich[['Ticker', 'DataDate']].copy()
    i_enrich = i_enrich.drop(columns = ['Ticker', 'DataDate'])
    
        
    
    # calculate alpha
    
    yhats = []
    for model in models:        
        dtest = xgb.DMatrix(i_enrich,missing=np.NaN)        
        xgbbooster = xgb.Booster()
        xgbbooster.load_model(os.path.join(root_model, model))
        yhat = xgbbooster.predict(dtest)        
        yhats.append(yhat)
    yhats = np.mean(yhats,axis=0)
    
    df_alpha = pd.DataFrame(yhats,columns=['yhat'])
    df_alpha['Ticker'] = i_enrich_key['Ticker'].values
    df_alpha['DataDate'] = dd
    df_alpha = df_alpha[['DataDate','Ticker','yhat']]
    
    
    # output alpha
  
  df_alpha.to_parquet(os.path.join(root_alpha, 'alpha_'+VERSION, dd))
    
    
    



#------------------------------------------------------------------------------
### generate position
# this generates daily pst from optimization
#------------------------------------------------------------------------------



import pandas as pd
import numpy as np
import scipy.stats as ss

import os
import datetime

import util as yu
import opt_cn_lib as opt


i_sd = yu.get_sd_cn_1800()

### get alpha

# option 1
root = '/dat/summit_capital/TZ/PROD_ALPHA/alpha_20230808/'
i_alpha = pd.concat([pd.read_parquet(root+f) for f in os.listdir(root)], axis = 0)
i_alpha['DataDate'] = pd.to_datetime(i_alpha['DataDate'], format = '%Y%m%d.parquet')

# option 2 -> this gives us the best -pre-cost sharpe: 4.2
i_alpha = yu.get_sql(''' select Ticker, DataDate, alpha  
                     from cndbprod.dbo.SMTCN_ALPHA_CSI1800_N12_ICC ''')
#i_alpha.loc[i_alpha['alpha']<-0.05,'alpha']=-0.05
#i_alpha.loc[i_alpha['alpha']>0.05,'alpha']=0.05
i_alpha = i_alpha.sort_values(['Ticker','DataDate'])
#i_alpha['alpha'] = i_alpha.groupby('Ticker').rolling(5)['alpha'].mean().values
i_alpha['alpha'] = i_alpha.groupby('DataDate')['alpha'].apply(yu.uniformed_rank)

# option 3 
i_alpha = yu.get_sql(''' select Ticker, DataDate, alpha  
                     from cndbprod.dbo.SMTCN_ALPHA_CSI1800_XGB_V1 ''')
i_alpha['alpha'] = i_alpha.groupby('DataDate')['alpha'].apply(yu.renorm)


### combine

icom = i_sd.merge(i_alpha, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom.sort_values(['Ticker', 'DataDate'])
icom = icom.drop_duplicates(subset=['Ticker', 'DataDate'], keep = 'last')

icom['yhat_t10d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=14),on='DataDate',min_periods=1)['yhat'].mean().values
icom['yhat_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=28),on='DataDate',min_periods=10)['yhat'].mean().values
icom['alpha'] = icom.groupby('DataDate')['yhat_t20d'].apply(yu.uniformed_rank)

icom.loc[icom['alpha'].abs()<0.5, 'alpha'] = np.nan # not working
icom['alpha'] = icom.groupby('DataDate')['alpha'].apply(yu.renorm)


icom['alpha'] = icom.groupby('Ticker').rolling(5)['alpha'].mean().values
icom['alpha'] = icom.groupby('DataDate')['alpha'].apply(yu.uniformed_rank)

o_1 = yu.bt_cn_15_linux(icom[ icom['DataDate'].between('2022-01-01', '2023-07-31')\
                             & icom['alpha'].abs().gt(0.6) ].\
            dropna(subset=['alpha','BarrRet_CLIP_USD+1d']).drop_d
uplicates(subset=['Ticker','DataDate']),
            'alpha','BarrRet_CLIP_USD+1d', static_data = i_sd)


opt.serchopt(1e8, 0.5, 0.3, True, True, '20230101', '20230731', icom , False)
#opt.serchopt(1e8, 0.5, 0.3, True, True, '20220101', '20230731', icom , False)











