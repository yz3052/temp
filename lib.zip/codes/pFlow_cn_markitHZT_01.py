﻿#$%^&* pFlow_cn_markitHZT_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 18 11:10:47 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime



### get sd


i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])


### reversal


i_pastret = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet',
                            columns = ['ticker', 'datadate', 'twap1000_2c_bret','twap1000_2c_bret_t4w'])
i_pastret = i_pastret.sort_values(['ticker','datadate'])



### hzt - H Share

#i_ah_map = pd.read_excel(r'S:\TZ\China Data Hunt\AH_ticker_mapping.xlsx')
#i_ah_map = i_ah_map[['ashare','hk']]
#i_ah_map.columns = ['ticker', 'Ticker']
#i_ah_map['Ticker'] = i_ah_map['Ticker'].str.replace('HK','').astype(int).astype(str) + ' HK'
#i_ah_map['ticker'] = i_ah_map['ticker'].astype(int).astype(str).str.zfill(6)
#c_sh = i_ah_map['ticker'].str[0].isin(['6'])
#c_sz = i_ah_map['ticker'].str[0].isin(['0', '3'])
#i_ah_map.loc[c_sh, 'ticker'] = i_ah_map.loc[c_sh, 'ticker'] + '.SH'
#i_ah_map.loc[c_sz, 'ticker'] = i_ah_map.loc[c_sz, 'ticker'] + '.SZ'
#
#
#i_hzt_hk = pd.read_parquet('S:/TZ/China Data Hunt/cache/pFlow_cn_markit_etl_hk_ls_fund_cnt.parquet')
#i_hzt_hk = i_hzt_hk[(i_hzt_hk['Ticker'].notnull()) & i_hzt_hk['Ticker'].str.contains(' HK')]
#i_hzt_hk = i_hzt_hk.merge(i_ah_map, on = 'Ticker', how = 'left')
#
#s_sum_hk_ls = i_hzt_hk[i_hzt_hk['Strategy']=='Equity LS']\
#            .groupby(['ticker', 'datadate'])[['Long Fund Count', 'Short Fund Count']].sum().reset_index()
#s_sum_hk_ls = s_sum_hk_ls.rename(columns = {'Long Fund Count':'Long Fund Count_h_ls', 
#                                            'Short Fund Count':'Short Fund Count_h_ls'})
#s_sum_hk_ls['ls_ratio_hk'] = (s_sum_hk_ls['Long Fund Count_h_ls'] - s_sum_hk_ls['Short Fund Count_h_ls']) / (s_sum_hk_ls['Long Fund Count_h_ls'] + s_sum_hk_ls['Short Fund Count_h_ls'])
#s_sum_hk_ls['ls_ratio_hk_hkrk'] = s_sum_hk_ls.groupby('datadate')['ls_ratio_hk'].apply(yu.uniformed_rank)





### hzt - A Share

i_hzt = yu.get_sql('''select * FROM [CNDBPROD].[dbo].[HZT_RAW]''')

i_hzt['ticker'] = i_hzt['Ticker'].str[:6]
c_sh = i_hzt['ticker'].str[0].isin(['6'])
c_sz = i_hzt['ticker'].str[0].isin(['0','3'])
i_hzt.loc[c_sh, 'ticker'] = i_hzt.loc[c_sh, 'ticker'] + '.SH'
i_hzt.loc[c_sz, 'ticker'] = i_hzt.loc[c_sz, 'ticker'] + '.SZ'

i_hzt['datadate_p1d'] = i_hzt['DataDate']
i_hzt = i_hzt.drop(columns = 
['DataDate', 'Ticker'])\




# inspection

t1 = i_hzt[i_hzt['ticker'].str[:4]=='0000']
t1 = t1[['datadate_p1d','ticker','Strategy','Gross Fund Count']]
t1 = t1.pivot_table(index=['datadate_p1d','ticker'],columns='Strategy',values='Gross Fund Count')
t1 = t1.reset_index()
t1 = t1.sort_values(['ticker','datadate_p1d'])


# hzt metrics
#
#['Position Date', 'Asset ID', 'Strategy', 'SEDOL', 'Gross Fund Count',
#       'Fund GMV Percentage Of Strategy GMV',
#       'Long Quantity Percentage Of Gross Quantity',
#       'Long Quantity Short Quantity Ratio', 'Long Fund Count Score',
#       'Short Fund Count Score', 'Long MV Score', 'Short MV Score',
#       'Long Quantity DoD Percentage Change',
#       'Short Quantity DoD Percentage Change',
#       'Net Quantity DoD Percentage Change',
#       'Cash Quantity Percentage Of Gross Quantity',
#       'Long Cash Quantity Percentage Of Gross Cash Quantity',
#       'Short Cash Quantity Percentage Of Gross Cash Quantity',
#       'Swap Quantity Percentage Of Gross Quantity',
#       'Long Swap Quantity Percentage Of Gross Swap Quantity',
#       'Short Swap Quantity Percentage Of Gross Swap Quantity',
#       'Long MV Percentage Of Fund GMV Mean',
#       'Long MV Percentage Of Fund GMV Median',
#       'Long MV Percentage Of Fund GMV Std Dev',
#       'Short MV Percentage Of Fund GMV Mean',
#       'Short MV Percentage Of Fund GMV Median',
#       'Short MV Percentage Of Fund GMV Std Dev', 'Internalization Ratio Min',
#       'Internalization Ratio Max', 'Internalization Ratio Mean',
#       'Internalization Ratio Median',
#       'Internalization MV Weighted Ratio Mean',
#       'Internalization MV Weighted Ratio Median',
#       'Internalization Broker Count', 'Long Fund Count', 'Short Fund Count',
#       'Long MV Percentage Of Strategy GMV',
#       'Short MV Percentage Of Strategy GMV', 'Buy Count', 'Long Buy Count',
#       'Buy Conviction Count', 'Long Buy Conviction Count',
#       'Buy MV Percentage Of Strategy GMV',
#       'Long Buy MV Percentage Of Strategy GMV',
#       'Buy Conviction MV Percentage Of Strategy GMV',
#       'Long Buy Conviction MV Percentage Of Strategy GMV',
#       'Buy MV Percentage Of Fund GMV Mean',
#       'Long Buy MV Percentage Of Fund GMV Mean', 'Sell Count',
#       'Short Sell Count', 'Sell Conviction Count',
#       'Short Sell Conviction Count', 'Sell MV Percentage Of Strategy GMV',
#       'Short Sell MV Percentage Of Strategy GMV',
#       'Sell Conviction MV Percentage Of
 Strategy GMV',
#       'Short Sell Conviction MV Percentage Of Strategy GMV',
#       'Sell MV Percentage Of Fund GMV Mean',
#       'Short Sell MV Percentage Of Fund GMV Mean',
#       'Buy MV Percentage Of Strategy Buy MV Squared Sum',
#       'Sell MV Percentage Of Strategy Sell MV Squared Sum',
#       'Long Buy MV Percentage Of Strategy Long Buy MV Squared Sum',
#       'Short Sell MV Percentage Of Strategy Short Sell MV Squared Sum',
#       'ticker', 'datadate']


s_sum = i_hzt.groupby(['ticker', 'datadate_p1d'])[['Fund GMV Percentage Of Strategy GMV', 'Gross Fund Count',
                     'Long Fund Count', 'Short Fund Count',
                     'Long MV Percentage Of Strategy GMV', 'Short MV Percentage Of Strategy GMV',
                     'Buy Count', 'Sell Count', 'Long Buy Count', 'Short Sell Count',
                     'Buy Conviction Count', 'Sell Conviction Count',
                     'Long Buy Conviction Count', 'Short Sell Conviction Count',
                     'Buy MV Percentage Of Strategy Buy MV Squared Sum',
                    'Long Buy MV Percentage Of Strategy Long Buy MV Squared Sum',
                    'Sell MV Percentage Of Strategy Sell MV Squared Sum',
                    'Short Sell MV Percentage Of Strategy Short Sell MV Squared Sum',
                    'Buy MV Percentage Of Strategy GMV',
                    'Long Buy MV Percentage Of Strategy GMV',
                    'Buy Conviction MV Percentage Of Strategy GMV',
                    'Long Buy Conviction MV Percentage Of Strategy GMV',
                    'Buy MV Percentage Of Fund GMV Mean',
                    'Long Buy MV Percentage Of Fund GMV Mean',
                    'Sell MV Percentage Of Strategy GMV',
                    'Short Sell MV Percentage Of Strategy GMV',
                    'Sell Conviction MV Percentage Of Strategy GMV',
                    'Short Sell Conviction MV Percentage Of Strategy GMV',
                    'Sell MV Percentage Of Fund GMV Mean',
                    'Short Sell MV Percentage Of Fund GMV Mean',
                    'Cash Quantity Percentage Of Gross Quantity',
                    'Swap Quantity Percentage Of Gross Quantity']].sum().reset_index()



s_sum_multistrat = i_hzt[i_hzt['Strategy']=='Multi Strat']\
                    .groupby(['ticker', 'datadate_p1d'])[['Long Fund Count', 'Short Fund Count']].sum().reset_index()
s_sum_multistrat = s_sum_multistrat.rename(columns = {'Long Fund Count':'Long Fund Count_ms', 
   
                                                   'Short Fund Count':'Short Fund Count_ms'})

s_sum_quant = i_hzt[i_hzt['Strategy']=='Quant']\
                .groupby(['ticker', 'datadate_p1d'])[['Long Fund Count', 'Short Fund Count']].sum().reset_index()
s_sum_quant = s_sum_quant.rename(columns = {'Long Fund Count':'Long Fund Count_q', 
                                                      'Short Fund Count':'Short Fund Count_q'})

s_sum_all = i_hzt[i_hzt['Strategy']=='ALL']\
            .groupby(['ticker', 'datadate_p1d'])[['Long Fund Count', 'Short Fund Count']].sum().reset_index()
s_sum_all = s_sum_all.rename(columns = {'Long Fund Count':'Long Fund Count_all', 
                                        'Short Fund Count':'Short Fund Count_all'})

s_sum_ls = i_hzt[i_hzt['Strategy']=='Equity LS']\
            .groupby(['ticker', 'datadate_p1d'])[['Long Fund Count', 'Short Fund Count',
            'Long Quantity Percentage Of Gross Quantity',
            'Long MV Percentage Of Strategy GMV',
            'Short MV Percentage Of Strategy GMV']].sum().reset_index()
s_sum_ls = s_sum_ls.rename(columns = {'Long Fund Count':'Long Fund Count_ls', 
                                      'Short Fund Count':'Short Fund Count_ls',
                                      'Long Quantity Percentage Of Gross Quantity':'Long Quantity Percentage Of Gross Quantity_ls',
                                      'Long MV Percentage Of Strategy GMV':'Long MV Percentage Of Strategy GMV_ls',
                                      'Short MV Percentage Of Strategy GMV':'Short MV Percentage Of Strategy GMV_ls'})

s_sum_rv = i_hzt[i_hzt['Strategy']=='RV']\
            .groupby(['ticker', 'datadate_p1d'])[['Long Fund Count', 'Short Fund Count']].sum().reset_index()
s_sum_rv = s_sum_rv.rename(columns = {'Long Fund Count':'Long Fund Count_rv', 
                                      'Short Fund Count':'Short Fund Count_rv'})


s_avg = i_hzt.groupby(['ticker', 'datadate_p1d'])\
                    ['Long Quantity Percentage Of Gross Quantity',
                     'Long Fund Count Score',
                     'Long MV Score',
                     'Internalization Ratio Mean',
                     'Internalization MV Weighted Ratio Mean',
                     'Long Quantity DoD Percentage Change',
                     'Short Quantity DoD Percentage Change'].mean().reset_index()
s_avg = s_avg.rename(columns = {'Long Quantity Percentage Of Gross Quantity': 'Long Quantity Percentage Of Gross Quantit
y_avg',
                                'Long Fund Count Score':'Long Fund Count Score_avg',
                                'Long MV Score':'Long MV Score_avg',
                                'Internalization Ratio Mean':'Internalization Ratio Mean_avg',
                                'Internalization MV Weighted Ratio Mean':'Internalization MV Weighted Ratio Mean_avg',
                                'Long Quantity DoD Percentage Change': 'Long Quantity DoD Percentage Change_avg',
                                'Short Quantity DoD Percentage Change': 'Short Quantity DoD Percentage Change_avg'})

s_avg_ls = i_hzt[i_hzt['Strategy']=='Equity LS'].groupby(['ticker', 'datadate_p1d'])\
            [['Long Quantity Percentage Of Gross Quantity',
              'Long MV Percentage Of Fund GMV Mean',
              'Short MV Percentage Of Fund GMV Mean',
              'Internalization Ratio Mean',
              'Internalization MV Weighted Ratio Mean',
              'Long Quantity DoD Percentage Change',
              'Short Quantity DoD Percentage Change']].mean().reset_index()
s_avg_ls = s_avg_ls.rename(columns = {'Long Quantity Percentage Of Gross Quantity': 'Long Quantity Percentage Of Gross Quantity_avg_ls',
                                      'Long MV Percentage Of Fund GMV Mean': 'Long MV Percentage Of Fund GMV Mean_avg_ls',
                                      'Short MV Percentage Of Fund GMV Mean': 'Short MV Percentage Of Fund GMV Mean_avg_ls',
                                      'Internalization Ratio Mean':'Internalization Ratio Mean_avg_ls',
                                      'Internalization MV Weighted Ratio Mean':'Internalization MV Weighted Ratio Mean_avg_ls',
                                      'Long Quantity DoD Percentage Change': 'Long Quantity DoD Percentage Change_avg_ls',
                                      'Short Quantity DoD Percentage Change': 'Short Quantity DoD Percentage Change_avg_ls'})



s_max_ls = i_hzt[i_hzt['Strategy']=='Equity LS']\
            .groupby(['ticker', 'datadate_p1d'])[['Long Fund Count', 'Short Fund Count']].max().reset_index()
s_max_ls = s_max_ls.rename(columns = {'Long Fund Count':'Long Fund Count_max_ls', 
                                      'Short Fund Count':'Short Fund Count_max_ls'})





### HZT - fill missing values

#i_hzt_re = pd.DataFrame(index = pd.MultiIndex.from_product([i_hzt['Asset ID'].unique().tolist(), 
#           i_hzt['datadate_p1d'].unique().tolist()], names = ["Asset ID", "da
tadate_p1d"])).reset_index()
#i_hzt_re['datadate_p1d'] = pd.to_datetime(i_hzt_re['datadate_p1d'])

i_hzt_tk_map = i_hzt[['Asset ID', 'ticker']].drop_duplicates()

i_hzt_pvt = i_hzt.rename(columns={'Gross Fund Count':'g_cnt','Long Fund Count':'l_cnt', 'Short Fund Count':'s_cnt'})\
            .pivot_table(index=['Asset ID','datadate_p1d'],columns = 'Strategy', values = ['g_cnt','l_cnt','s_cnt'])
i_hzt_pvt.columns = i_hzt_pvt.columns.to_series().apply(lambda x: '{0}_{1}'.format(*x)).values
i_hzt_pvt.columns = [i.replace('Equity LS','ls').replace('ALL','allstrat').replace('Multi Strat','multistrat')\
                     .replace('Quant','qnt').replace('RV','rv') for i in i_hzt_pvt.columns.tolist()]
i_hzt_pvt = i_hzt_pvt.reset_index()

#i_hzt_pvt = i_hzt_re.merge(i_hzt_pvt, on = ['Asset ID', 'datadate_p1d'], how = 'left')

# fill nans by zeros
for strat in ['allstrat','ls','multistrat','qnt','rv']:
    c1 = i_hzt_pvt['g_cnt_'+strat] == i_hzt_pvt['l_cnt_'+strat]
    i_hzt_pvt.loc[c1, 's_cnt_'+strat] = 0
    c1 = i_hzt_pvt['g_cnt_'+strat] == i_hzt_pvt['s_cnt_'+strat]
    i_hzt_pvt.loc[c1, 'l_cnt_'+strat] = 0

# fill nans caused by thresholds
i_hzt_pvt = i_hzt_pvt.sort_values(['Asset ID', 'datadate_p1d'])
for c in [i for i in i_hzt_pvt.columns.tolist() if i not in ['Asset ID','datadate_p1d']]:
    i_hzt_pvt[c+'_1d'] = i_hzt_pvt.groupby('Asset ID')[c].shift()

i_hzt_pvt['l_cnt_ls_infer'] = np.nan
for i in range(100):
    c1 = i_hzt_pvt['l_cnt_ls'].isnull() & i_hzt_pvt['l_cnt_ls_1d'].gt(0)
    c2 = i_hzt_pvt['l_cnt_allstrat'].lt(i_hzt_pvt['l_cnt_allstrat_1d']) 
    c3 = i_hzt_pvt['l_cnt_multistrat'].eq(i_hzt_pvt['l_cnt_multistrat_1d']) | (i_hzt_pvt['l_cnt_multistrat'].isnull() & i_hzt_pvt['l_cnt_multistrat_1d'].isnull())
    c4 = i_hzt_pvt['l_cnt_qnt'].eq(i_hzt_pvt['l_cnt_qnt_1d']) | (i_hzt_pvt['l_cnt_qnt'].isnull() & i_hzt_pvt['l_cnt_qnt_1d'].isnull())
    c5 = i_hzt_pvt['l_cnt_rv'].eq(i_hzt_pvt['l_cnt_rv_1d']) | (i_hzt_pvt['l_cnt_rv'].isnull() & i_hzt_pvt['l_cnt_rv_1d'].isnull())
    c6 = c1 & c2 & c3 & c4 & c5    
    i_hzt_pvt.loc[c6, 'l_cnt_ls'] = i_hzt_pvt.loc[c6, 'l_cnt_ls_1d'] + i_hzt_pvt.loc[c6, 'l_cnt_allstrat'] - i_hzt_pvt.loc[c6, 'l_cnt_allstrat_1d']
    i_hzt_pvt.loc[c6, 'l_cnt_ls_infer'] = 1
    
    c7 = i_hzt_pvt['s_cnt_ls'].isnull()
    i_hzt_pvt.loc[c6 & c7, 's_cnt_ls'] = i_hzt_pvt.loc[c6 & c7, 's_cnt_ls_1d'] 
    
    c1 = i_hzt_pvt['l_cnt_ls'].isnull() & i_hzt_pvt.groupby('Asset ID')['l_cnt_ls'].shift().gt(0)
    c2 = i_hzt_pvt.groupby('Asset I
D')['l_cnt_ls_infer'].shift().eq(1)
    c7 = c1 & c2
    i_hzt_pvt.loc[c7, 'l_cnt_ls'] = i_hzt_pvt.groupby('Asset ID')['l_cnt_ls'].shift().loc[c7]
    i_hzt_pvt.loc[c7, 'l_cnt_ls_infer'] = 1
    
i_hzt_pvt['s_cnt_ls_infer'] = np.nan
for i in range(100):
    c1 = i_hzt_pvt['s_cnt_ls'].isnull() & i_hzt_pvt['s_cnt_ls_1d'].gt(0)
    c2 = i_hzt_pvt['s_cnt_allstrat'].lt(i_hzt_pvt['s_cnt_allstrat_1d']) 
    c3 = i_hzt_pvt['s_cnt_multistrat'].eq(i_hzt_pvt['s_cnt_multistrat_1d']) | (i_hzt_pvt['s_cnt_multistrat'].isnull() & i_hzt_pvt['s_cnt_multistrat_1d'].isnull())
    c4 = i_hzt_pvt['s_cnt_qnt'].eq(i_hzt_pvt['s_cnt_qnt_1d']) | (i_hzt_pvt['s_cnt_qnt'].isnull() & i_hzt_pvt['s_cnt_qnt_1d'].isnull())
    c5 = i_hzt_pvt['s_cnt_rv'].eq(i_hzt_pvt['s_cnt_rv_1d']) | (i_hzt_pvt['s_cnt_rv'].isnull() & i_hzt_pvt['s_cnt_rv_1d'].isnull())
    c6 = c1 & c2 & c3 & c4 & c5    
    i_hzt_pvt.loc[c6, 's_cnt_ls'] = i_hzt_pvt.loc[c6, 's_cnt_ls_1d'] + i_hzt_pvt.loc[c6, 's_cnt_allstrat'] - i_hzt_pvt.loc[c6, 's_cnt_allstrat_1d']
    i_hzt_pvt.loc[c6, 's_cnt_ls_infer'] = 1
    
    c7 = i_hzt_pvt['l_cnt_ls'].isnull()
    i_hzt_pvt.loc[c6 & c7, 'l_cnt_ls'] = i_hzt_pvt.loc[c6 & c7, 'l_cnt_ls_1d'] 
    
    c1 = i_hzt_pvt['s_cnt_ls'].isnull() & i_hzt_pvt.groupby('Asset ID')['s_cnt_ls'].shift().gt(0)
    c2 = i_hzt_pvt.groupby('Asset ID')['s_cnt_ls_infer'].shift().eq(1)
    c7 = c1 & c2
    i_hzt_pvt.loc[c7, 's_cnt_ls'] = i_hzt_pvt.groupby('Asset ID')['s_cnt_ls'].shift().loc[c7]
    i_hzt_pvt.loc[c7, 's_cnt_ls_infer'] = 1
    
    
    
    
i_hzt_pvt = i_hzt_pvt.merge(i_hzt_tk_map, on = 'Asset ID', how = 'left')

s_hzt_pvt = i_hzt_pvt.groupby(['ticker', 'datadate_p1d'])[['l_cnt_ls', 's_cnt_ls']].sum().reset_index()

# only some minor upgrades

#icom = i_sd.merge(s_hzt_pvt, on = ['ticker', 'datadate_p1d'], how = 'left')
#c1 = 'l_cnt_ls'
#c2 = 's_cnt_ls'
#icom[c1] = icom[c1].fillna(0)
#icom[c2] = icom[c2].fillna(0)
#icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
#icom['bs_ratio6_bk'] = icom.groupby('datadate')['bs_ratio6'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#icom['flg_high_ls'] = np.nan
#icom.loc[(icom['bs_ratio6']>=0.8), 'flg_high_ls'] = 1
#icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)
#
#yu.create_cn_3x3(icom, ['bs_ratio6_bk'], 'bs_ratio6') # less mono: -2 +5 0 +6, all +ve when bs>0
#o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
#            dropna(subset=['flg_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=[
'ticker','datadate']),
#            'flg_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.4 / 1.36
#o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2022-06-30')].\
#            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
#            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.78 / 2.28, 9.2%, 3.0e7




### combine


icom = i_sd.merge(s_sum, on = ['ticker', 'datadate_p1d'], how = 'left')
icom = icom.merge(s_sum_multistrat, on = ['ticker', 'datadate_p1d'], how = 'left')
icom = icom.merge(s_sum_quant, on = ['ticker', 'datadate_p1d'], how = 'left')
icom = icom.merge(s_sum_all, on = ['ticker', 'datadate_p1d'], how = 'left')
icom = icom.merge(s_sum_ls, on = ['ticker', 'datadate_p1d'], how = 'left')
icom = icom.merge(s_sum_rv, on = ['ticker', 'datadate_p1d'], how = 'left')
icom = icom.merge(s_avg, on = ['ticker', 'datadate_p1d'], how = 'left')
icom = icom.merge(s_avg_ls, on = ['ticker', 'datadate_p1d'], how = 'left')
icom = icom.merge(s_max_ls, on = ['ticker', 'datadate_p1d'], how = 'left')



#icom = icom.merge(s_sum_hk_ls, on = ['ticker', 'datadate'], how = 'left')

icom = icom.merge(i_pastret , on = ['ticker', 'datadate'], how = 'left')

icom = icom.sort_values(['ticker', 'datadate'])







#------------------------------------------------------------------------------
### Idea 1: gmv
#------------------------------------------------------------------------------

icom['gmv_rk'] = icom.groupby('datadate')['Fund GMV Percentage Of Strategy GMV'].apply(yu.uniformed_rank)
icom['mc_rk'] = icom.groupby('datadate')['MC_l1d'].apply(yu.uniformed_rank)
icom.loc[icom['gmv_rk'].notnull(), 'MC_l1d_v2'] = icom.loc[icom['gmv_rk'].notnull(), 'MC_l1d']
icom['MC_l1d_v2_rk'] = icom.groupby('datadate')['MC_l1d_v2'].apply(yu.uniformed_rank)

icom['gmv_mc_rkdf'] = icom['gmv_rk'] - icom['mc_rk']
icom['gmv_mc_rkdf_bk'] = icom.groupby('datadate')['gmv_mc_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['gmv_mc_rkdf_bk'] , 'gmv_mc_rkdf') # leaning +ve: 2 0 2.5 4 4.5

icom['gmv_mc_rkdf2'] = icom['gmv_rk'] - icom['MC_l1d_v2_rk']
icom['gmv_mc_rkdf2_bk'] = icom.groupby('datadate')['gmv_mc_rkdf2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['gmv_mc_rkdf2_bk'] , 'gmv_mc_rkdf2') # less mono: 1 -1.5 +5.5

COLS = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL','GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']
icom['gmv_orth'] = icom.groupby('datadate')[COLS+
['SRISK']+['Fund GMV Percentage Of Strategy GMV']].apply(lambda x: yu.orthogonalize_cn_v2(x['Fund GMV Percentage Of Strategy GMV'], x[COLS], x['SRISK'])).values
icom['gmv_orth_bk'] = icom.groupby('datadate')['gmv_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['gmv_orth_bk'] , 'gmv_orth') # not mono -> I feel that monotonicity more depends on how I normalize the gmv here ... 

icom['long_bk'] = icom.groupby('datadate')['long_holding'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['long_rk'] = icom.groupby('datadate')['long_holding'].apply(yu.uniformed_rank)
# yu.create_cn_3x3(icom, ['long_bk'], 'long_holding') # random

icom['gmv_mc_rkdf2'] = icom['long_rk'] - icom['MC_l1d_v2_rk']
icom['gmv_mc_rkdf2_bk'] = icom.groupby('datadate')['gmv_mc_rkdf2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['gmv_mc_rkdf2_bk'] , 'gmv_mc_rkdf2') # less mono: -1 +4




#------------------------------------------------------------------------------
### Idea 2: fund count
#------------------------------------------------------------------------------


icom['fund_cnt_bk'] = icom.groupby('datadate')['Gross Fund Count'].apply(lambda x: yu.pdqcut(x,bins=5)).values
yu.create_cn_3x3(icom, ['fund_cnt_bk'], 'Gross Fund Count') # random, most positive 

icom['mc_rk'] = icom.groupby('datadate')['MC_l1d'].apply(yu.uniformed_rank)
c1 = icom['Gross Fund Count'] > 15
c2 = icom['mc_rk'] < 0
icom['sgnl_fund_cnt_high'] = np.nan
icom.loc[c1 & c2, 'sgnl_fund_cnt_high'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_fund_cnt_high','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_fund_cnt_high','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0




#------------------------------------------------------------------------------
### Idea 3: portfolio
#------------------------------------------------------------------------------


c1= 'Long Quantity Percentage Of Gross Quantity_ls'
icom[c1] = icom[c1].replace(0,np.nan)
icom['long_wgt_ls_bk'] = icom.groupby('datadate')[c1].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['long_wgt_ls_bk'], c1) # all +ve, les mono, +1 +7 +6



c1 = 'Long MV Percentage Of Strategy GMV'
c2 = 'Short MV Percentage Of Strategy GMV'
icom[c1] = icom[c1].replace(0,np.nan)
icom[c2] = icom[c2].replace(0,np.nan)

icom['net_weight'] = icom[c1] - icom[c2]
icom['net_weight_bk'] = icom.groupby('datadate')['net_weight'].ap
ply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['net_weight_bk'], 'net_weight') # not mono: 0 -3 +2 +2

icom['long_bk'] = icom.groupby('datadate')[c1].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['long_bk'], c1) # less mono: -0.5 +2

icom['net_weight2'] = icom.groupby('datadate')[c1].apply(lambda x: x/ x.sum()).values
icom['net_weight2_bk'] = icom.groupby('datadate')['net_weight2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['net_weight2_bk'], 'net_weight2') # less mono: -0.5 +3 +2


#------------------------------------------------------------------------------
### Idea 4: LS
# this works
#------------------------------------------------------------------------------

icom['ls_ratio'] = (icom['Long Fund Count'] - icom['Short Fund Count']) / (icom['Long Fund Count'] + icom['Short Fund Count'])
icom['ls_ratio_bk'] = icom.groupby('datadate')['ls_ratio'].apply(lambda x: yu.pdqcut(x,bins=5))

yu.create_cn_3x3(icom, ['ls_ratio_bk'], 'ls_ratio') #  1 -0.5 +3.5


icom['flg_high_ls'] = np.nan
icom.loc[icom['ls_ratio']>0.8, 'flg_high_ls'] = 1
yu.create_cn_decay(icom, 'flg_high_ls') # 

icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.7 /2.1, 6.9%





icom['ls_mv_ratio'] = (icom['Long MV Percentage Of Strategy GMV'] - icom['Short MV Percentage Of Strategy GMV']) / (icom['Long MV Percentage Of Strategy GMV'] + icom['Short MV Percentage Of Strategy GMV'])
icom['ls_mv_ratio_bk'] = icom.groupby('datadate')['ls_mv_ratio'].apply(lambda x: yu.pdqcut(x,bins=5))

yu.create_cn_3x3(icom, ['ls_mv_ratio_bk'], 'ls_mv_ratio') #  

icom['flg_high_ls'] = np.nan
icom.loc[icom['ls_mv_ratio']>0.8, 'flg_high_ls'] = 1
yu.create_cn_decay(icom, 'flg_high_ls') # 

icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.4 / 1.8, 3.9%





icom['bs_ratio'] = (icom['Buy Count'] - icom['Sell Count']) / (icom['Buy Count'] + icom['Sell Count'])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ra
tio']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.14 / 1.4, 2.75%



icom['bs_ratio2'] = (icom['Long Buy Count'] - icom['Short Sell Count']) / (icom['Long Buy Count'] + icom['Short Sell Count'])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio2']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.16 / 1.63. 3.1%



icom['bs_ratio3'] = (icom['Buy Conviction Count'] - icom['Sell Conviction Count']) / (icom['Buy Conviction Count'] + icom['Sell Conviction Count'])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio3']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd)  # 2.07 / 1.4, 1.6%



icom['bs_ratio4'] = (icom['Long Buy Conviction Count'] - icom['Short Sell Conviction Count']) / (icom['Long Buy Conviction Count'] + icom['Short Sell Conviction Count'])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio4']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.19 / 1.67, 3.15%



icom['bs_ratio5'] = (icom['Buy MV Percentage Of Strategy Buy MV Squared Sum'] - icom['Sell MV Percentage Of Strategy Sell MV Squared Sum']) / (icom['Buy MV Percentage Of Strategy Buy MV Squared Sum'] + icom['Sell MV Percentage Of Strategy Sell MV Squared Sum'])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio5']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ff
ill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.15 / 1.38, 2.76%


icom['bs_ratio6'] = (icom['Long Buy MV Percentage Of Strategy Long Buy MV Squared Sum'] - icom['Short Sell MV Percentage Of Strategy Short Sell MV Squared Sum']) / (icom['Long Buy MV Percentage Of Strategy Long Buy MV Squared Sum'] + icom['Short Sell MV Percentage Of Strategy Short Sell MV Squared Sum'])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio6']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.2 / 1.64, 3.11%


c1 = 'Buy MV Percentage Of Strategy GMV'
c2 = 'Sell MV Percentage Of Strategy GMV'
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio6']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.17 / 1.65, 3%



c1 = 'Long Buy MV Percentage Of Strategy GMV'
c2 = 'Short Sell MV Percentage Of Strategy GMV'
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio6']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.14 / 1.63, 3%


c1 = 'Buy Conviction MV Percentage Of Strategy GMV'
c2 = 'Sell Conviction MV Percentage Of Strategy GMV'
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio6']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1
 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.12 / 1.59, 2.9%




c1 = 'Long Buy Conviction MV Percentage Of Strategy GMV'
c2 = 'Short Sell Conviction MV Percentage Of Strategy GMV'
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio6']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.16 / 1.65, 3.1%




c1 = 'Buy MV Percentage Of Fund GMV Mean'
c2 = 'Short Sell MV Percentage Of Fund GMV Mean'
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio6']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.2 / 1.7, 3.1%




c1 = 'Long Buy MV Percentage Of Fund GMV Mean'
c2 = 'Sell MV Percentage Of Fund GMV Mean'
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio6']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.18 / 1.62, 3.06%




c1 = 'Long Fund Count_ms'
c2 = 'Short Fund Count_ms'
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio6']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            's
gnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.34 / 0.98, 4.6%




c1 = 'Long Fund Count_q'
c2 = 'Short Fund Count_q'
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio6']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd)  #1.8 / 1.2, 4%



c1 = 'Long Fund Count_all'
c2 = 'Short Fund Count_all'
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio6']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd)  # 3.17 / 2.32, 5.6%, 3.6e7




c1 = 'Long Fund Count_rv'
c2 = 'Short Fund Count_rv'
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio6']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.04 /1.0, 24%, small sample





c1 = 'Long Fund Count_ls'
c2 = 'Short Fund Count_ls'
icom[c1] = icom[c1].fillna(0)
icom[c2] = icom[c2].fillna(0)
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
icom['bs_ratio6_bk'] = icom.groupby('datadate')['bs_ratio6'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['flg_high_ls'] = np.nan
icom.loc[(icom['bs_ratio6']>=0.8), 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

yu.create_cn_3x3(icom, ['bs_ratio6_bk'], 'bs_ratio6') # less mono: -2 +5 0 +6, all +ve when bs>0
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['flg_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_high_ls','BarrRet_CLIP_USD+1d', stati
c_data = i_sd) # 2.4 / 1.36
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2022-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.78 / 2.28, 9.2%, 3.0e7 ###!!!



icom['t'] = icom['Long Fund Count_ls'] + icom['Short Fund Count_ls']
icom.groupby('datadate')['t'].mean().plot()
icom['t'].value_counts() / icom['t'].value_counts().sum()

icom.loc[icom['bs_ratio6_bk']==0, 'bs_ratio6'].mean()
icom.loc[icom['t']==0, 'bs_ratio6'].value_counts()


c1 = 'Long Fund Count_max_ls'
c2 = 'Short Fund Count_max_ls'
icom[c1] = icom[c1].fillna(0)
icom[c2] = icom[c2].fillna(0)
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])

icom['flg_high_ls'] = np.nan
icom.loc[(icom['bs_ratio6']>0.8), 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
# 2.77 / 2.28, 9.27%, 3.0e7






c1 = 'Long Fund Count_ls'
c2 = 'Short Fund Count_ls'
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
icom['bs_ratio6_t5d'] = icom.groupby('ticker')['bs_ratio6'].shift(5)
icom['flg_reachhigh_ls'] = np.nan
icom.loc[(icom['bs_ratio6']>=0.8)&(icom['bs_ratio6_t5d']<0.8), 'flg_reachhigh_ls'] = 1
icom['sgnl_reachhigh_ls'] = icom.groupby('ticker')['flg_reachhigh_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_reachhigh_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_reachhigh_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 




c1 = 'Long Fund Count_ls'
c2 = 'Short Fund Count_ls'
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
c1 = 'Long Fund Count_h_ls'
c2 = 'Short Fund Count_h_ls'
icom['bs_ratio6h'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])

icom['bs_ratio6_aug'] = icom['bs_ratio6']
icom.loc[icom['bs_ratio6h'].notnull(), 'bs_ratio6_aug'] = icom.loc[icom['bs_ratio6h'].notnull(),['bs_ratio6h','bs_ratio6']].mean(axis=1)

icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio6_aug']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate'
]<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.41 / 1.99, 9.4%











icom['ls_ratio_hk_hkrk_bk'] = (icom['ls_ratio_hk_hkrk']+1.19999)//0.2
yu.create_cn_3x3(icom, ['ls_ratio_hk_hkrk_bk'], 'ls_ratio_hk_hkrk') # random

icom['bs_ratio6h_bk'] = icom.groupby('datadate')['bs_ratio6h'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['bs_ratio6h_bk'], 'bs_ratio6h') # 0 +8 -2 +2 -4





icom['long_pct_bk'] = icom.groupby('datadate')['Long Quantity Percentage Of Gross Quantity_avg'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['long_pct_rk'] = icom.groupby('datadate')['Long Quantity Percentage Of Gross Quantity_avg'].apply(yu.uniformed_rank)
yu.create_cn_3x3(icom, ['long_pct_bk'], 'Long Quantity Percentage Of Gross Quantity_avg')
icom['sgnl_long_pct'] = np.nan
icom.loc[icom['long_pct_bk'] == 9, 'sgnl_long_pct'] = 1
icom['sgnl_long_pct'] = icom.groupby('ticker')['sgnl_long_pct'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_long_pct','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_long_pct','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.53 / 1.91, 7%



icom['long_pct_rk'] = icom.groupby('datadate')['Long Quantity Percentage Of Gross Quantity_avg_ls'].apply(yu.uniformed_rank)
icom['sgnl_long_pct'] = np.nan
icom.loc[icom['long_pct_rk'] > 0.8, 'sgnl_long_pct'] = 1
icom['sgnl_long_pct'] = icom.groupby('ticker')['sgnl_long_pct'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_long_pct','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_long_pct','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.72 / 2.27, 10%, 2.2e7



c1 = 'Long MV Percentage Of Fund GMV Mean_avg_ls'
c2 = 'Short MV Percentage Of Fund GMV Mean_avg_ls'
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio6']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.42 / 1.
03




#------------------------------------------------------------------------------
### Idea 4.1: LS + reversal
#------------------------------------------------------------------------------

icom['o2c_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)


c1 = 'Long Fund Count_ls'
c2 = 'Short Fund Count_ls'
c3 = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2]) > 0.8
c4 = icom['o2c_t4w_rk'] < -0.8
icom['flg_high_ls'] = np.nan
icom.loc[c3 & c4, 'flg_high_ls'] = 1
c5 = icom['o2c_t4w_rk'] > 0.8
icom.loc[c5, 'flg_high_ls'] = 0
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 10)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2022-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) 
# 2.55 / 2.21. 24%, but there is a drawdown in 2Q21
###???


icom['Long Fund Count Score_avg'].quantile(0.5)
icom['Long MV Score_avg'].hist()


c1 = 'Long Fund Count_ls'
c2 = 'Short Fund Count_ls'
c3 = ((icom[c1] - icom[c2]) / (icom[c1] + icom[c2]) > 0.8) & (icom['Long Fund Count Score_avg']<=2)
c4 = icom['o2c_t4w_rk'] < -0.8
icom['flg_high_ls'] = np.nan
icom.loc[c3 & c4, 'flg_high_ls'] = 1
c5 = icom['o2c_t4w_rk'] > 0.8
icom.loc[c5, 'flg_high_ls'] = 0
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd)  #1.64 /1.31





#------------------------------------------------------------------------------
### Idea 4.2: LS difference
#------------------------------------------------------------------------------


c1 = 'Long Fund Count_ls'
c2 = 'Short Fund Count_ls'
icom['bs_ratio6'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
icom['bs_ratio6_df1q'] = icom['bs_ratio6'] - icom.groupby('ticker')['bs_ratio6'].shift(63)
icom['bs_ratio6_df1q_bk'] = icom.groupby('datadate')['bs_ratio6_df1q'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['flg_highdf_ls'] = np.nan
icom.loc[icom['bs_ratio6_df1q_bk']==9, 'flg_highdf_ls'] = 1
icom['sgnl_highdf_ls'] = icom.groupby('ticker')['flg_highdf_ls'].ffill(limit = 20)

#yu.create_cn_3x3(icom, ['bs_ratio6_df1q_bk'], 'bs_ratio6_df1q') # less mono: -1 +3 0 +4 1 +8
o_1 = yu.bt_cn_15(icom[(icom['dat
adate']<='2021-06-30')].\
            dropna(subset=['sgnl_highdf_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_highdf_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.53 / 1.21

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['flg_highdf_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_highdf_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.63 / 0.37




#------------------------------------------------------------------------------
### Idea 4.2: LS restart position
#------------------------------------------------------------------------------

icom['Long Fund Count_ls_cnt20d'] = icom.groupby('ticker').rolling(20)['Long Fund Count_ls'].count().values

icom.loc[icom['Long Fund Count_ls_cnt20d'] == 1,'flg_restart_pst'] = 1
icom['sgnl_restart_pst'] = icom.groupby('ticker')['flg_restart_pst'].ffill(limit=20)

yu.create_cn_decay(icom, 'flg_restart_pst')
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_restart_pst','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_restart_pst','BarrRet_CLIP_USD+1d', static_data = i_sd)  # 2.42, 1.2, 3.9%








#------------------------------------------------------------------------------
### Idea 5: Internalization
# only highly internalized after rally
#------------------------------------------------------------------------------

icom['intern_avg_bk'] = icom.groupby('datadate')['Internalization Ratio Mean_avg'].apply(lambda x: yu.pdqcut(x,bins=10))
icom['intern_wavg_bk'] = icom.groupby('datadate')['Internalization MV Weighted Ratio Mean_avg'].apply(lambda x: yu.pdqcut(x,bins=10))
                     
yu.create_cn_3x3(icom, ['intern_avg_bk'], 'Internalization Ratio Mean_avg')
yu.create_cn_3x3(icom, ['intern_wavg_bk'], 'Internalization MV Weighted Ratio Mean_avg') # random

icom.loc[icom['intern_wavg_bk'] == 9 , 'flg_internH'] = 1
yu.create_cn_decay(icom , 'flg_internH')

icom['sgnl_internH'] = icom.groupby('ticker')['flg_internH'].ffill(limit=10)
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_internH','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_internH','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.03 / -0.17



icom['o2c_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)
icom['flg_intern
H_retL'] = np.nan
c1 = (icom['intern_wavg_bk'] == 9) & (icom['o2c_t4w_rk']<-0.8)
icom.loc[c1, 'flg_internH_retL'] = 1
icom['sgnl_internH_retL'] = icom.groupby('ticker')['flg_internH_retL'].ffill(limit=10)
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_internH_retL','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_internH_retL','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.93 / 0.47




#------------------------------------------------------------------------------
### Idea 6: cash / swap
#------------------------------------------------------------------------------

c1 = 'Cash Quantity Percentage Of Gross Quantity'
c2 = 'Swap Quantity Percentage Of Gross Quantity'
icom['cash_swap'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])
icom['cash_swap_bk'] = icom.groupby('datadate')['cash_swap'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['cash_swap_bk'], 'cash_swap') # not working




#------------------------------------------------------------------------------
### Idea 7: dod
#------------------------------------------------------------------------------


icom['long_dod_bk'] = icom.groupby('datadate')['Long Quantity DoD Percentage Change_avg'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['ls_dod'] = icom['Long Quantity DoD Percentage Change_avg'] - icom['Short Quantity DoD Percentage Change_avg']
icom['ls_dod_bk'] = icom.groupby('datadate')['ls_dod'].apply(lambda x: yu.pdqcut(x,bins=10)).values


yu.create_cn_3x3(icom, ['long_dod_bk'], 'Long Quantity DoD Percentage Change_avg') # -0.5 +3 2
yu.create_cn_3x3(icom, ['ls_dod_bk'], 'ls_dod') # random , +ve ~2



#------------------------------------------------------------------------------
### Idea 8: residual holding  against northbound
#------------------------------------------------------------------------------


i_mf = pw.get_wind_holding_mf_q_est()
i_mf = i_mf[['ticker', 'datadate', 'pctOfSO_active','fundActiveNum','pctOfMFSTK_mean']]

i_so = pw.get_wind_float()
i_so = i_so.sort_values('datadate')
i_h = pd.read_parquet(r'S:\Data\China Data Hunt\cache\prepare_northbound_holding_bb.parquet')
i_h = i_h.groupby(['datadate_p1d','ticker'])['bb_shares'].sum().reset_index()
i_h = i_h.sort_values('datadate_p1d')
i_h = pd.merge_asof(i_h, i_so, by = 'ticker', left_on = 'datadate_p1d', right_on = 'datadate', allow_exact_matches = False)
i_h['bb_pctSO'] = i_h['bb_shares'] / i_h['float_guben']
i_h = i_
h[['ticker', 'datadate_p1d', 'bb_pctSO']]

#tcom = pd.merge_ordered(i_sd, i_mf, left_by='datadate', on='ticker', fill_method='ffill', how='left')
tcom = pd.merge_asof(i_sd, i_mf, by='ticker', on='datadate', tolerance=pd.to_timedelta('182 days'))
tcom = tcom.merge(i_h, on = ['ticker', 'datadate_p1d'], how = 'left')
#tcom = tcom.merge(s_sum, on = ['ticker', 'datadate_p1d'], how = 'left')
tcom = tcom.merge(s_sum_ls, on = ['ticker', 'datadate_p1d'], how = 'left')
#tcom = tcom.merge(i_pastret , on = ['ticker', 'datadate'], how = 'left')

tcom = tcom.sort_values(['ticker', 'datadate'])
tcom['ones'] = 1


c1 = 'Long Fund Count_ls'
c2 = 'Short Fund Count_ls'
tcom['bs_ratio'] = (tcom[c1] - tcom[c2]) / (tcom[c1] + tcom[c2])
tcom = tcom[tcom[['bs_ratio','bb_pctSO','pctOfSO_active']].notnull().all(axis=1)]
tcom2 = tcom[tcom.datadate>='2019-01-01']
COLS = ['bb_pctSO','pctOfSO_active']
tcom2['bs_ratio_orth'] = tcom2.groupby('datadate')[COLS+['ones']+['bs_ratio']].apply(lambda x: yu.orthogonalize_cn_v2(x['bs_ratio'], x[COLS], x['ones'],normal_y = True)).values
tcom2['bs_ratio_orth_bk'] = tcom2.groupby('datadate')['bs_ratio_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(tcom2, ['bs_ratio_orth_bk'], 'bs_ratio_orth') # mono -1 +6





tcom2['flg_high_ls'] = np.nan
tcom2.loc[tcom2['bs_ratio_orth_bk']>=4, 'flg_high_ls'] = 1
#yu.create_cn_decay(icom, 'flg_high_ls') # 
tcom2['sgnl_high_ls'] = tcom2.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(tcom2[(tcom2['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) 
#? why the following result cannot be replicated? 
# 2.37 / 2.04, 15.48%




#------------------------------------------------------------------------------
### Idea 8.1: residual holding: LS vs Quant
#------------------------------------------------------------------------------



icom['ones'] = 1

c1 = 'Long Fund Count_ls'
c2 = 'Short Fund Count_ls'
icom['bs_ratio_ls'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])

c1 = 'Long Fund Count_q'
c2 = 'Short Fund Count_q'
icom['bs_ratio_q'] = (icom[c1] - icom[c2]) / (icom[c1] + icom[c2])

icom['bs_ratio_orth'] = icom.groupby('datadate')[['ones']+['bs_ratio_ls','bs_ratio_q']].apply(lambda x: yu.orthogonalize_cn_v2(x['bs_ratio_ls'], x[['bs_ratio_q']], x['ones'],normal_y = True)).values
icom['bs_ratio_orth_bk'] = icom.groupb
y('datadate')['bs_ratio_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values


yu.create_cn_3x3(icom, ['bs_ratio_orth_bk'], 'bs_ratio_orth') # less mono: -2 +7 +3.5






#------------------------------------------------------------------------------
### Idea 9: conviction
#------------------------------------------------------------------------------


c1 = 'Long Buy Conviction MV Percentage Of Strategy GMV'
c2 = 'Short Sell Conviction MV Percentage Of Strategy GMV'
icom['net_convic'] = icom[c1] - icom[c2]
icom['net_convic_bk'] = icom.groupby('datadate')['net_convic'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['net_convic_bk'], 'net_convic') # random

icom['net_convic_ma20d'] = icom.groupby('ticker').rolling(20)['net_convic'].mean().values
icom['net_convic_ma20d_bk'] = icom.groupby('datadate')['net_convic_ma20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['net_convic_ma20d_bk'], 'net_convic_ma20d') # ransom

icom['long_convic_bk'] = icom.groupby('datadate')[c1].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['long_convic_bk'], c1) # random



icom['flg_high_ls'] = np.nan
icom.loc[icom['bs_ratio6']>0.8, 'flg_high_ls'] = 1
icom['sgnl_high_ls'] = icom.groupby('ticker')['flg_high_ls'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subset=['sgnl_high_ls','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_ls','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.16 / 1.65, 3.1%
