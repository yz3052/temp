﻿#$%^&* pTrend_02.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 12 11:30:32 2020

@author: thzhang
"""

import pandas as pd 
import numpy as np
from numba import njit
from yz import get_sql, tic, toc, bt

# the idea is .. if sharpe increases above 1.5 or decreases below -1.5, reverse position

#------------------------------------------------------------------------------
### import data

tic()
i_sd = pd.read_parquet(r"S:\Infrastructure\backtester\data_cache\static_data_v2p0.parquet",
                       columns= ['DataDate', 'T-1d', 'Ticker','MC_l1d', 'GSECTOR', 'GGROP',
                                 'avgPV_l1d','spread','volatility',
                                 'SRISK_USE4', 'BETA_USE4', 'BTOP_USE4', 'EARNYILD_USE4', 'GROWTH_USE4', 
                                 'LEVERAGE_USE4', 'LIQUIDTY_USE4', 'MOMENTUM_USE4', 'MOMENTUM_FAST', 'SIZE_USE4',
                                 'time_of_day', 'next_ed', 'last_time_of_day', 'last_ed', 'd2nexted','d2preed', 
                                 'RawRet-1d', 'RawRet+0d', 'RawRet+1d', 'RawRet+2d',
                                 'BarrRet-1d', 'BarrRet+0d', 'BarrRet+1d', 'BarrRet+2d',
                                 'BarrRet_SRISK-1d', 'BarrRet_SRISK+0d', 'BarrRet_SRISK+1d', 'BarrRet_SRISK+2d'])
i_sd = i_sd.rename(columns={'T-1d':'datadate','DataDate':'datadate_p1d','Ticker':'ticker'})
toc()

i_tk = "','".join(i_sd.Ticker.unique().tolist())

tic()
i_bbg = get_sql("select distinct datadate, ticker FROM [BackTest].[dbo].[BBG_MktData_Hist] where ticker in ('{0}')".format(i_tk))
toc()

i0 = i_sd.merge(i_bbg, how='right', on = ['ticker','datadate'])
i0 = i0.sort_values(['ticker','datadate'])

#------------------------------------------------------------------------------
### sgnl1 - contrarian, 1 day

i1 = i0.copy()

@njit
def rolling_sharpe(x):
    if np.any(np.isnan(x)):
        return np.nan
    else:
        return x.mean()/x.std()*np.sqrt(len(x))
i1['bret_sharpe'] = i1.groupby('ticker')['BarrRet+0d'].rolling(22).apply(rolling_sharpe, raw=True).values

i1['sgnl'] = np.nan
cond_l = (i1['bret_sharpe']>1.5) & (i1['bret_sharpe'].shift(1)<1.5) & (i1['bret_sharpe'].shift(2)<i1['bret_sharpe'].shift(1)) &\
         (i1['ticker']==i1['ticker'].shift())
i1.loc[cond_l,'sgnl']= -1
cond_s = (i1['bret_sharpe']<-1.5) & (i1['bret_sharpe'].shift(1)>-1.5) & (i1['bret_sharpe'].shift(2)>i1['bret_sharpe'].shift(1)) &\
         (i1['ticker']==i1['ticker'].shift())
i1.loc[cond_s,'sgnl']=1


o3 = bt(i1.dropna(subset
=['sgnl','BarrRet_SRISK+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_SRISK+1d', sgnl_before_3pm=False) #0.8 sharpe, per trade pnl too low


#------------------------------------------------------------------------------
### sgnl1 - contrarian, 5/15 day


i1 = i0.copy()
@njit
def rolling_sharpe(x):
    if np.any(np.isnan(x)):
        return np.nan
    else:
        return x.mean()/x.std()*np.sqrt(len(x))
i1['bret_sharpe'] = i1.groupby('ticker')['BarrRet+0d'].rolling(22).apply(rolling_sharpe, raw=True).values

i1['sgnl'] = np.nan
cond_l = (i1['bret_sharpe']>2) & (i1['bret_sharpe'].shift(1)<2) & (i1['bret_sharpe'].shift(2)<i1['bret_sharpe'].shift(1)) &\
         (i1['ticker']==i1['ticker'].shift())
i1.loc[cond_l,'sgnl']= -1
cond_s = (i1['bret_sharpe']<-2) & (i1['bret_sharpe'].shift(1)>-2) & (i1['bret_sharpe'].shift(2)>i1['bret_sharpe'].shift(1)) &\
         (i1['ticker']==i1['ticker'].shift())
i1.loc[cond_s,'sgnl']=1

i1['sgnl'] = i1.groupby('ticker')['sgnl'].fillna(method='ffill',limit = 15)

o3 = bt(i1[i1.datadate<='2019-06-01'].dropna(subset=['sgnl','BarrRet_SRISK+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_SRISK+1d', sgnl_before_3pm=False)


#------------------------------------------------------------------------------
### sgnl1 - contrarian,5 day


i1 = i0.copy()
@njit
def rolling_sharpe(x):
    if np.any(np.isnan(x)):
        return np.nan
    else:
        return x.mean()/x.std()*np.sqrt(len(x))
i1['bret_sharpe'] = i1.groupby('ticker')['BarrRet+0d'].rolling(22).apply(rolling_sharpe, raw=True).values

i1['sgnl'] = np.nan
cond_l = (i1['bret_sharpe'].between(1.5,2)) & (i1['bret_sharpe'].shift(1)<1.5) & (i1['bret_sharpe'].shift(2)<i1['bret_sharpe'].shift(1)) &\
         (i1['ticker']==i1['ticker'].shift())
i1.loc[cond_l,'sgnl']= -1
cond_s = (i1['bret_sharpe'].between(-2,-1.5)) & (i1['bret_sharpe'].shift(1)>-1.5) & (i1['bret_sharpe'].shift(2)>i1['bret_sharpe'].shift(1)) &\
         (i1['ticker']==i1['ticker'].shift())
i1.loc[cond_s,'sgnl']=1

i1['sgnl'] = i1.groupby('ticker')['sgnl'].fillna(method='ffill',limit = 5)

o3 = bt(i1[i1.datadate<='2019-06-01'].dropna(subset=['sgnl','BarrRet_SRISK+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_SRISK+1d', sgnl_before_3pm=False)



#------------------------------------------------------------------------------
### sgnl1 - contrarian,5 day


i1 = i0.copy()
@njit
def rolling_sharpe(x):
    if np.any(np.isnan(x)):
        re
turn np.nan
    else:
        return x.mean()/x.std()*np.sqrt(len(x))
i1['bret_sharpe'] = i1.groupby('ticker')['BarrRet-1d'].rolling(22).apply(rolling_sharpe, raw=True).values

i1['sgnl'] = np.nan
cond_l = (i1['bret_sharpe'].between(1.5,2)) & (i1['bret_sharpe'].shift(1)<1.5) & (i1['bret_sharpe'].shift(2)<i1['bret_sharpe'].shift(1)) &\
         (i1['ticker']==i1['ticker'].shift())
i1.loc[cond_l,'sgnl']= -1
cond_s = (i1['bret_sharpe'].between(-2,-1.5)) & (i1['bret_sharpe'].shift(1)>-1.5) & (i1['bret_sharpe'].shift(2)>i1['bret_sharpe'].shift(1)) &\
         (i1['ticker']==i1['ticker'].shift())
i1.loc[cond_s,'sgnl']= 1

i1['sgnl'] = i1.groupby('ticker')['sgnl'].fillna(method='ffill',limit = 5)

o3 = bt(i1[i1.datadate<='2019-06-01'].dropna(subset=['sgnl','BarrRet_SRISK+0d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_SRISK+0d', sgnl_before_3pm=False)

t1 = o3[o3.ticker=='ABMD']

