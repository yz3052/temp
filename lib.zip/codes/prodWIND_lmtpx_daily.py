﻿#$%^&* prodWIND_lmtpx_daily.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 17 14:22:22 2022

@author: thzhang
"""

import pandas as pd 

from sqlalchemy import create_engine
import urllib

import datetime
import pytz


# This code ingests WIND's daily limit up and limit down prices. 


# helper

def get_sql_wind(query):
    
    engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_wind_dbo;PWD=DusONA3Habredl;''TDS_Version=8.0;')))
    
    return pd.read_sql_query(query, con=engine)


def get_sql(query):
    
    engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))

    return pd.read_sql_query(query, con=engine)



# calculate yesterday

today = datetime.datetime.now(pytz.timezone('Asia/Shanghai')).date()
todaystr = str( today.year * 10000 + today.month * 100 + today.day)
sql = '''
      select distinct TradeDate_next as TradeDate
      from CNDBPROD.dbo.Calendar_Dates_CN where TradeDate_next < todaystr
      '''
sql = sql.replace('todaystr', '\'' + todaystr + '\'')
cd = get_sql(sql)
cd = cd.sort_values('TradeDate')
cd = cd['TradeDate'].tolist()
yesterday = cd[-1]
yesterdaystr = str(int(yesterday.year*10000 + yesterday.month*100 + yesterday.day))
yesterdaystr2 = yesterdaystr[:4]+'.'+yesterdaystr[4:6]+'.'+yesterdaystr[6:]



# get wind data

i_wind = get_sql_wind('''select trade_dt as DataDate, s_info_windcode as Ticker,
                                S_DQ_TRADESTATUSCODE, 
                                S_DQ_PRECLOSE, S_DQ_CLOSE, 
                                S_DQ_LIMIT, S_DQ_STOPPING 
                         from wind_prod.dbo.ashareeodprices
                         where trade_dt = '{0}' '''.format( yesterdaystr ))



# format wind data

c_sh = i_wind['Ticker'].str.endswith('SH') & i_wind['Ticker'].str[0].isin(['6'])
c_sz = i_wind['Ticker'].str.endswith('SZ') & i_wind['Ticker'].str[0].isin(['0', '3'])
i_wind = i_wind[c_sh | c_sz]
i_wind['Ticker'] = i_wind['Ticker'].str.split('.').str[0]

i_wind['DataDate'] = pd.to_datetime(i_wind['DataDate'], format = '%Y%m%d')

for c in ['S_DQ_TRADESTATUSCODE', 'S_DQ_PRECLOSE', 'S_DQ_CLOSE', 'S_DQ_LIMIT', 'S_DQ_STOPPING']:
    i_wind[c] = pd.to_numeric(i_wind[c])
    

# to csv

i_wind.to_csv('/export/datadev2/Data/SHSZ/WIND_LMTUPDN/'+yesterdaystr+'.txt', 
sep = '|', index  = False)



