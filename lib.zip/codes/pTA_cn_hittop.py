﻿#$%^&* pTA_cn_hittop.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  3 05:36:27 2023

@author: thzhang
"""


import pandas as pd
import numpy as np

import util as yu
import os
import datetime



### get sd

i_sd = yu.get_sd_cn_1800()


### q

i_q = yu.get_q("get `:/export/datadev/Data/SHSZ/ORDER_metrics/orderbook_metrics_batch1_08")

i_q['code'] = i_q['code'].str.decode('utf8')
i_q = i_q.rename(columns = {'date':'T-1d', 'code':'Ticker'})


### combine

icom = i_sd.merge(i_q, on = ['Ticker', 'T-1d'], how = 'left')
icom = icom.sort_values(['Ticker', 'DataDate'])

icom['ones'] = 1
cols_i = [c for c in i_sd.columns.tolist() if c[:2]=='wd']
if len(cols_i) == 0:
    icom = pd.concat([icom, pd.get_dummies(icom['GIND'])], axis = 1)
    cols_i = icom['GIND'].dropna().unique().tolist()
if len(cols_i) == 0:
    cols_i = ['AIRLINES', 'AUTOCOMP', 'BANKS   ', 'BIOTECH ', 'CAPGOODS', 'CHEMICAL',
       'COMMSVCS', 'COMMUNIC', 'COMPUTER', 'CONSDUR ', 'CONSTPP ', 'CONSVCS ',
       'DIVFINAN', 'DIVMETAL', 'ENERGY  ', 'FOODPRD ', 'FOODRETL', 'HEALTH  ',
       'HSHLDPRD', 'INSURAN ', 'INTERNET', 'MEDIA   ', 'OILEXPL ', 'OILGAS  ',
       'PHARMAC ', 'PRECMETL', 'REALEST ', 'RETAIL  ', 'SEMICOND', 'SOFTWARE',
       'STEEL   ', 'TELECOM ', 'TRANSPRT', 'UTILITY ']
    
    
cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'DIVYILD', 
          'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']


### sum of ontop v / tot

icom['ontop_dv_tot'] = (icom['v_buy_ontop'] + icom['v_sell_ontop'])/(icom['v_buy_tot'] + icom['v_sell_tot'])
icom['ontop_dv_tot_orth'] = icom.groupby('DataDate')[cols_i + cols_f + ['ontop_dv_tot', 'ones']].apply(lambda x: yu.orthogonalize_cn_v3(x['ontop_dv_tot'], x[cols_f], x[cols_i], x['ones'])).values
icom['ontop_dv_tot_orth_rk'] = icom.groupby('DataDate')['ontop_dv_tot_orth'].apply(yu.uniformed_rank)
icom['ontop_dv_tot_orth_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=28),min_periods=5,on='DataDate')['ontop_dv_tot_orth'].mean().values
icom['ontop_dv_tot_orth_t20d_rk'] = icom.groupby('DataDate')['ontop_dv_tot_orth_t20d'].apply(yu.uniformed_rank)

icom['onsolidtop_dv_tot'] = (icom['v_buy_onsolidtop'] + icom['v_sell_onsolidtop'])/(icom['v_buy_tot'] + icom['v_sell_tot'])
icom['onsolidtop_dv_tot_orth'] = icom.groupby('DataDate')[cols_i + cols_f + ['onsolidtop_dv_tot', 'ones']].apply(lambda x: yu.orthogonalize_cn_v3(x['onsolidtop_dv_tot'], x[cols_f], x[cols_i], x['ones'])).values
icom['onsolidtop_d
v_tot_orth_rk'] = icom.groupby('DataDate')['onsolidtop_dv_tot_orth'].apply(yu.uniformed_rank)
icom['onsolidtop_dv_tot_orth_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=28),min_periods=5,on='DataDate')['onsolidtop_dv_tot_orth'].mean().values
icom['onsolidtop_dv_tot_orth_t20d_rk'] = icom.groupby('DataDate')['onsolidtop_dv_tot_orth_t20d'].apply(yu.uniformed_rank)


for c in ['ontop_dv_tot_orth', 'onsolidtop_dv_tot_orth']:
    icom[c+'_bk'] = icom.groupby('DataDate')[c].apply(lambda x: yu.pdqcut(x,bins=10)).values
    yu.create_cn_3x3_linux(icom, [c+'_bk'], c)
    
o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ].\
            dropna(subset=['ontop_dv_tot_orth_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'ontop_dv_tot_orth_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.0 / 2.3
o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ].\
            dropna(subset=['onsolidtop_dv_tot_orth_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'onsolidtop_dv_tot_orth_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.8 /2.0
    
    
    
### count of ontop v / tot

icom['ontop_dv_tot'] = (icom['c_buy_ontop'] + icom['c_sell_ontop'])/(icom['c_buy_tot'] + icom['c_sell_tot'])
icom['ontop_dv_tot_orth'] = icom.groupby('DataDate')[cols_i + cols_f + ['ontop_dv_tot', 'ones']].apply(lambda x: yu.orthogonalize_cn_v3(x['ontop_dv_tot'], x[cols_f], x[cols_i], x['ones'])).values
icom['ontop_dv_tot_orth_rk'] = icom.groupby('DataDate')['ontop_dv_tot_orth'].apply(yu.uniformed_rank)
icom['ontop_dv_tot_orth_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=28),min_periods=5,on='DataDate')['ontop_dv_tot_orth'].mean().values
icom['ontop_dv_tot_orth_t20d_rk'] = icom.groupby('DataDate')['ontop_dv_tot_orth_t20d'].apply(yu.uniformed_rank)

icom['onsolidtop_dv_tot'] = (icom['c_buy_onsolidtop'] + icom['c_sell_onsolidtop'])/(icom['c_buy_tot'] + icom['c_sell_tot'])
icom['onsolidtop_dv_tot_orth'] = icom.groupby('DataDate')[cols_i + cols_f + ['onsolidtop_dv_tot', 'ones']].apply(lambda x: yu.orthogonalize_cn_v3(x['onsolidtop_dv_tot'], x[cols_f], x[cols_i], x['ones'])).values
icom['onsolidtop_dv_tot_orth_rk'] = icom.groupby('DataDate')['onsolidtop_dv_tot_orth'].apply(yu.uniformed_rank)
icom['onsolidtop_dv_tot_orth_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=28),min_periods=5,on='DataDate'
)['onsolidtop_dv_tot_orth'].mean().values
icom['onsolidtop_dv_tot_orth_t20d_rk'] = icom.groupby('DataDate')['onsolidtop_dv_tot_orth_t20d'].apply(yu.uniformed_rank)


for c in ['ontop_dv_tot_orth', 'onsolidtop_dv_tot_orth']:
    icom[c+'_bk'] = icom.groupby('DataDate')[c].apply(lambda x: yu.pdqcut(x,bins=10)).values
    yu.create_cn_3x3_linux(icom, [c+'_bk'], c)
    
o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ].\
            dropna(subset=['ontop_dv_tot_orth_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'ontop_dv_tot_orth_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.5/1.8
o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ].\
            dropna(subset=['onsolidtop_dv_tot_orth_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'onsolidtop_dv_tot_orth_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.6/1.7
