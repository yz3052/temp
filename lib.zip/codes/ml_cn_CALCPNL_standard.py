﻿#$%^&* ml_cn_CALCPNL_standard.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 20 15:10:42 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import util as yu

import os

import datetime

# This reads the "yhat" from ML results and then plot pnl




### sd

i_sd = yu.get_sd_cn_1800()
#i_sd = yu.get_sd_cn_50()
#i_sd = yu.get_sd_cn_500()



### get ML signals


root = '/dat/summit_capital/TZ/backtester/xg'

i_folders = os.listdir(root)
i_folders = [i for i in i_folders if i in ['test_enrich_20230509_immretv1p3_notrenorm']]
i_txt = []
for fd in i_folders:
    for f in os.listdir(os.path.join(root, fd)):
        if f.endswith('.txt') & (not 'fscore' in f):
            i_txt.append(os.path.join(root, fd, f))

i_xg = pd.concat(pd.read_csv(f,sep='|') for f in i_txt)

i_xg['Ticker']  = i_xg['Ticker'].astype(str).str.zfill(6)
i_xg['DataDate'] = pd.to_datetime(i_xg['DataDate'])



### combine 


icom = i_sd.merge(i_xg, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom.sort_values(['Ticker', 'DataDate'])





### naive


icom['yhat_rk'] = icom.groupby('DataDate')['yhat'].apply(yu.uniformed_rank)
icom['yhat_0rk'] = icom.groupby('DataDate')['yhat'].apply(lambda x: yu.uniformed_rank(x, 'zero_cutoff'))
icom['yhat_t5d'] = icom.groupby('Ticker').rolling(5)['yhat'].mean().values
icom['yhat_t5d_rk'] = icom.groupby('DataDate')['yhat_t5d'].apply(yu.uniformed_rank)
icom['yhat_t10d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=14),on='DataDate',min_periods=1)['yhat'].mean().values
icom['yhat_t10d_rk'] = icom.groupby('DataDate')['yhat_t10d'].apply(yu.uniformed_rank)



o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2019-01-01', '2021-12-31') ].\
            dropna(subset=['yhat','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'yhat','BarrRet_CLIP_USD+1d', static_data = i_sd) # 


o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2019-01-01', '2021-12-31') ].\
            dropna(subset=['yhat_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'yhat_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

    
o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2019-01-01', '2021-12-31')].\
            dropna(subset=['yhat_t10d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'yhat_t10d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)


o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2019-01-01
', '2021-12-31') & icom['yhat_t10d_rk'].abs().gt(0.8)].\
            dropna(subset=['yhat_t10d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'yhat_t10d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)
    

# all 1900 uni, mono defined
# 1020b: prod features, 20d, 4.86 / 4.13 / 2.87, 17.5%ret, 10%to, 11e7 9.5e7; extreme decile: 6.92 / 4.62 / 3.65, 30.2%, 19%to
# 1020c: prod features, 20d_rerank, 4.39 / 3.8 / 2.71, 17.7%ret, 10%to, extreme decile: 4.55 / 3.68 / 3.0, 28.2%, 17%to
# 1020d: prod features, 20d_winsor, 4.81 / 4.14 / 2.96, 18.3%ret, 10%to, 7.2e7 extreme decile: 5.01 / 4.05 / 3.3, 29.9%, 18%to, 4.9e7
# 1020e: 27 feature pool, 20d, 13.8%gmvret, extreme decile:24%gmvret 3.5e7
# 1021a: 27 feature pool, exl. odbk and events,  20d, 5.18 / 3.7 / 2.15, 14.06%ret, 18%to, 11e7, 8e7;

# 1023b: prod features, 20d, y is 3-class, (worse)

# 1024a: 27 pool 1D, Y1D, then ma10d, 6.18 / 5.04 / 3.51, 18.0% gmvret, 14%to, 1.5e8, 1.2e8;
# 1024b: 27 pool 20D, Y1D, 14.8% gmvret, 19%to, 12e7, 8.2e7;
# 1024c: 27 pool 1D20D, Y1D, then ma10d, 5.75/4.96/3.4, 18.3%gmvret, 10%to, 1.38e8 1.19e8; ma1d: 6.46 / 3.4 /1.86, 12.9%gmvret, 34%to, 1.33e8 0.7e8

# 1027a: 27 pool 20D, Y20D_rk, 16.9% gmvret, 16%to, 1.2e8 0.92e8; not superior
# 1103: prod feature incl earnings
# 1105: prod feature incl earnings, orth


    
### get rid tickers with high std in yhat


icom['yhat_rk'] = icom.groupby('DataDate')['yhat'].apply(yu.uniformed_rank)

icom['yhat_t10d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=14),on='DataDate',min_periods=1)['yhat'].mean().values 
icom['yhat_t10d_rk'] = icom.groupby('DataDate')['yhat_t10d'].apply(yu.uniformed_rank)

icom['yhat_rk_sd20d'] = icom.groupby('Ticker').rolling(20)['yhat_rk'].std().values
icom['yhat_rk_sd20d_rk'] = icom.groupby('DataDate')['yhat_rk_sd20d'].apply(yu.uniformed_rank)

o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-01-01', '2020-12-31') & icom['yhat_rk_sd20d_rk'].le(-0.2)].\
            dropna(subset=['yhat_t10d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'yhat_t10d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)


### ewm

icom['yhat_rk'] = icom.groupby('DataDate')['yhat'].apply(yu.uniformed_rank)

icom['yhat_ewm10d'] = icom.groupby('Ticker')['yhat'].transform(lambda x: x.ewm(halflife=10).mean()).values
icom['yhat_ewm10d_rk'] = icom.groupby('DataDate')['yhat_ewm10d'].apply(yu.uniformed_rank)

o_1 = yu.bt_cn_15_linux(icom[icom['DataDat
e'].between('2018-01-01', '2020-12-31') ].\
            dropna(subset=['yhat_ewm10d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'yhat_ewm10d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)



    

### overwrite with events

icom = icom.merge(i_overwrite, on = ['Ticker', 'DataDate'], how = 'left')
c1  = icom['event_sgnl'].abs()>0
icom = icom.assign(yhat_rk2 = icom['yhat_rk'])
icom.loc[c1, 'yhat_rk2'] = icom.loc[c1, 'event_sgnl']

    
o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-07-01', '2020-12-31') ].\
            dropna(subset=['yhat_rk2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'yhat_rk2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 





### signals that are not working 

icom['yhat_rk'] = icom.groupby('DataDate')['yhat'].apply(yu.uniformed_rank)

icom['yhat_t10d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=14),on='DataDate',min_periods=1)['yhat'].mean().values 
icom['yhat_t10d_rk'] = icom.groupby('DataDate')['yhat_t10d'].apply(yu.uniformed_rank)

icom['BarrRet_CLIP_USD-1d_rk'] = icom.groupby('DataDate')['BarrRet_CLIP_USD-1d'].apply(yu.uniformed_rank)

icom['yhat_t10d_rk_2d'] = icom.groupby('Ticker')['yhat_t10d_rk'].shift(2)
c1 = icom['yhat_t10d_rk_2d']>0.8
c2 = icom['BarrRet_CLIP_USD-1d_rk']<-0.8
icom.loc[c1 & c2, ['BarrRet_CLIP_USD+1d']].mean()


### std of alpha
# not working

icom['yhat_t10d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=14),on='DataDate',min_periods=1)['yhat'].mean().values 
icom['yhat_t10d_rk'] = icom.groupby('DataDate')['yhat_t10d'].apply(yu.uniformed_rank)

icom['yhat_rk_sd20d'] = icom.groupby('Ticker').rolling(20)['yhat_rk'].std().values
icom['yhat_rk_sd20d_bk'] = icom.groupby('DataDate')['yhat_rk_sd20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom[icom['yhat_t10d_rk']>0.5], ['yhat_rk_sd20d_bk'], 'yhat_rk_sd20d') # 


### DMA of alpha
# if golden cross when alpha < 0, the return is still negative

icom['yhat_rk'] = icom.groupby('DataDate')['yhat'].apply(yu.uniformed_rank)

icom['yhat_rk_ma5d'] = icom.groupby('Ticker').rolling(5)['yhat_rk'].mean().values
icom['yhat_rk_ma20d'] = icom.groupby('Ticker').rolling(20)['yhat_rk'].mean().values

icom['sgnl'] = np.nan
c1 = icom['yhat_rk_ma5d'] > icom['yhat_rk_ma20d']
c2 = icom['yhat_rk_ma5d'] < 0
icom.loc[c1 & c2, 'sgnl'] = 1
c1 = icom['yhat_rk_ma5d'] < icom['yhat_rk_ma20d']
c2 = icom['yhat_rk_ma5d'] > 0
icom.loc[c1 & c2, 'sgnl'] = -1


o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-07-01', '2020-12-31') ].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) 


### 5d difference of MA(alpha)






### 5d difference of alpha
# +ve monotonic 
# but when added to alpha, turnover gets a lot higher

icom['yhat_rk'] = icom.groupby('DataDate')['yhat'].apply(yu.uniformed_rank)
icom['yhat_bk'] = icom.groupby('DataDate')['yhat'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['yhat_rk_df5d'] = icom['yhat_rk'] - icom.groupby('Ticker')['yhat_rk'].shift(5)
icom['yhat_rk_df5d_bk'] = icom.groupby('DataDate')['yhat_rk_df5d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3_linux(icom, ['yhat_bk'], 'yhat')
yu.create_cn_3x3_linux(icom, ['yhat_rk_df5d_bk'], 'yhat_rk_df5d')
yu.create_cn_3x3_linux(icom[icom['yhat_rk_df5d_bk']>7], ['yhat_bk'], 'yhat')
yu.create_cn_3x3_linux(icom[icom['yhat_rk_df5d_bk']==1], ['yhat_bk'], 'yhat')


icom = icom.assign(yhat_rk_s2 = icom['yhat_rk'])
c1 = (icom['yhat_rk_s2']>0.2) & (icom['yhat_rk_df5d_bk']<=1)
icom.loc[c1, 'yhat_rk_s2'] = np.nan
c1 = (icom['yhat_rk_s2']<-0.2) & (icom['yhat_rk_df5d_bk']>=8)
icom.loc[c1, 'yhat_rk_s2'] = np.nan

o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-07-01', '2020-12-31') ].\
            dropna(subset=['yhat_rk_s2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'yhat_rk_s2','BarrRet_CLIP_USD+1d', static_data = i_sd) 

o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-07-01', '2020-12-31') ].\
            dropna(subset=['yhat_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'yhat_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) 

    
    
    
icom['yhat_rk_df5d_rk'] = icom.groupby('DataDate')['yhat_rk_df5d'].apply(yu.uniformed_rank)
icom['test'] = icom['yhat_rk'] + icom['yhat_rk_df5d_rk']
icom['test_rk'] = icom.groupby('DataDate')['test'].apply(yu.uniformed_rank)

o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-07-01', '2020-12-31') ].\
            dropna(subset=['test_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'test_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) 


### accelerate of alpha
# after acceleration, we get negative return from positive / negative alphas

icom['yhat_rk'] = icom.groupby('DataDate')['yhat'].apply(yu.uniformed_rank)
icom['yhat
_rk_1d'] = icom.groupby('Ticker')['yhat_rk'].shift(1)
icom['yhat_rk_2d'] = icom.groupby('Ticker')['yhat_rk'].shift(2)

icom['sgnl'] = np.nan
c1 = (icom['yhat_rk'] - icom['yhat_rk_1d']) > (icom['yhat_rk_1d'] - icom['yhat_rk_2d'])
c2 = (icom['yhat_rk'] - icom['yhat_rk_1d']) > 0 
c2b = (icom['yhat_rk_1d'] - icom['yhat_rk_2d']) > 0
c3 = icom['yhat_rk'] > 0.6
icom.loc[c1 & c2 & c2b, 'sgnl'] = 1
icom['sgnl'] = icom.groupby('Ticker')['sgnl'].ffill(15)

o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-07-01', '2020-12-31') ].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) 

    

icom['sgnl2'] = np.nan
c1 = (icom['yhat_rk'] - icom['yhat_rk_1d']) < (icom['yhat_rk_1d'] - icom['yhat_rk_2d'])
c2 = (icom['yhat_rk'] - icom['yhat_rk_1d']) < 0 
c2b = (icom['yhat_rk_1d'] - icom['yhat_rk_2d']) < 0
c3 = icom['yhat_rk'] < -0.6
icom.loc[c1 & c2 & c2b, 'sgnl'] = -1
icom['sgnl'] = icom.groupby('Ticker')['sgnl'].ffill(5)

o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-07-01', '2020-12-31') ].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) 





### autocorr of alpha
# not working

icom['yhat_rk'] = icom.groupby('DataDate')['yhat'].apply(yu.uniformed_rank)
icom['yhat_rk_1d'] = icom.groupby('Ticker')['yhat_rk'].shift()
icom['yhat_rk_autocorr'] = icom.groupby('Ticker').rolling(20)['yhat_rk'].apply(lambda x: x.autocorr(), raw=False).values

icom['yhat_rk_autocorr_bk'] = icom.groupby('DataDate')['yhat_rk_autocorr'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom, ['yhat_rk_autocorr_bk'], 'yhat_rk_autocorr') # 



### ts frcst of alpha
# not much difference

icom['yhat_rk'] = icom.groupby('DataDate')['yhat'].apply(yu.uniformed_rank)
icom['yhat_rk_frcst'] = icom.groupby('Ticker').rolling(5)['yhat_rk'].apply(yu.ols_forecast_ts,raw=True).values
icom['yhat_rk_frcst_rk'] = icom.groupby('DataDate')['yhat_rk_frcst'].apply(yu.uniformed_rank)

o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-07-01', '2020-12-31') ].\
            dropna(subset=['yhat_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'yhat_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) 

o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-07-01', '2020-12-31') ].\
            dropna(subset
=['yhat_rk_frcst_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'yhat_rk_frcst_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) 




    


### dampen signals - trailing window higher when sgnl std higher
# not working

icom_dampen = []

for dt in icom['DataDate'].sort_values().drop_duplicates().tolist():
    if (dt.strftime('%Y%m%d') < '20180101') or (dt.strftime('%Y%m%d') > '20210101'):
        continue
    print(dt.strftime('%Y%m%d'), end=',')
    
    tdata_t30d = icom[icom['DataDate'].le(dt) & icom['DataDate'].ge(dt - pd.to_timedelta('42 days'))]    
    tdata_t10d = tdata_t30d[tdata_t30d['DataDate'].le(dt) & tdata_t30d['DataDate'].ge(dt - pd.to_timedelta('14 days'))]
    tdata_t5d = tdata_t10d[tdata_t10d['DataDate'].le(dt) & tdata_t10d['DataDate'].ge(dt - pd.to_timedelta('7 days'))]
    
    s_t10d = tdata_t10d.groupby('Ticker')['yhat'].std().reset_index()
    s_t10d['yhat_std_bk'] = yu.pdqcut(s_t10d['yhat'],bins=10)
    s_t10d['yhat_std_bk'] = pd.to_numeric(s_t10d['yhat_std_bk'])
    s_t10d.loc[s_t10d['yhat_std_bk'].isnull(),'yhat_std_bk'] = 0
    s_t10d.loc[s_t10d['yhat_std_bk']<=8,'yhat_std_bk'] = 0
    s_t10d.loc[s_t10d['yhat_std_bk']>8,'yhat_std_bk'] = 1
    
    tk_low_std = s_t10d.loc[s_t10d['yhat_std_bk']==0, 'Ticker'].tolist()
    tk_high_std = s_t10d.loc[s_t10d['yhat_std_bk']==1, 'Ticker'].tolist()
    
    s_low = tdata_t10d[tdata_t10d.Ticker.isin(tk_low_std)].groupby('Ticker')['yhat'].mean().reset_index()
    s_high = tdata_t5d[tdata_t5d.Ticker.isin(tk_high_std)].groupby('Ticker')['yhat'].mean().reset_index()
    s = s_low.append(s_high, sort = False)
    s = s.rename(columns = {'yhat': 'yhat_dampened'})
    s['DataDate'] = dt
    icom_dampen.append(s)


icom_dampen = pd.concat(icom_dampen, axis = 0)
icom2 = i_sd.merge(icom_dampen, on = ['Ticker', 'DataDate'], how = 'left')
icom2 = icom2.sort_values(['Ticker', 'DataDate'])

icom2['yhat_dampened_rk'] = icom2.groupby('DataDate')['yhat_dampened'].apply(yu.uniformed_rank)
    
o_1 = yu.bt_cn_15_linux(icom2[icom2['DataDate'].between('2018-07-01', '2020-12-31') ].\
            dropna(subset=['yhat_dampened_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'yhat_dampened_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
    
    
    

icom['yhat_rk'] = icom.groupby('DataDate')['yhat'].apply(yu.uniformed_rank)
icom['yhat_rk_1d'] = icom.groupby('Ticker')['yhat_rk'].shift()
icom['yhat_rk_sd20d'] = icom.groupby('Ticker').rol
ling(datetime.timedelta(days=14),on='DataDate',min_periods=3)['yhat_rk'].std().values


    


icom['bk'] = icom.groupby('DataDate')['yhat'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom, ['bk'], 'yhat')
    

o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2018-07-01', '2020-12-31') & icom['yhat_0rk'].abs().ge(0.8) ].\
            dropna(subset=['yhat_0rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'yhat_0rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

    
#------------------------------------------------------------------------------
# bar chart
#------------------------------------------------------------------------------

features = ['SMTCN_CHILDALPHA_F001_ACT_CSI1800_SLOW_LS',
            'SMTCN_CHILDALPHA_F001_BAR_CSI1800_SLOW_LS',
            'SMTCN_CHILDALPHA_F001_CANC_CSI1800_SLOW_LS',
            'SMTCN_CHILDALPHA_F001_CAV_CSI1800_SLOW_LS',
            'SMTCN_CHILDALPHA_F001_LT_CSI1800_SLOW_LS',
            'SMTCN_CHILDALPHA_F001_PVAR_CSI1800_SLOW_LS', 
            'SMTCN_CHILDALPHA_F001_SHSZ_CSI1800_SLOW_LS',
            'SMTCN_CHILDALPHA_F001_ST_CSI1800_SLOW_LS',
            'SMTCN_CHILDALPHA_F001_TWAP2M_CSI1800_SLOW_LS',
            'SMTCN_CHILDALPHA_F001_TWAP3SV2_CSI1800_SLOW_LS', 
            'SMTCN_CHILDALPHA_F001_TWAP60SV2_T2000_SLOW_LS',
            'SMTCN_CHILDALPHA_F002_GB_CSI1800_SLOW_LS',
            'SMTCN_CHILDALPHA_F004_NB_CSI1800_SLOW_LS',
            'SMTCN_CHILDALPHA_F007_JM5d_CSI1800_LO']


for f in features:        
    t_data = yu.get_sql('''select DataDate, Ticker, alpha 
                         from cndbprod.dbo.{0} 
                         where DataDate <= '20201231' 
                         and DataDate >= '20200101' 
                         '''.format(f))
    tcom = i_sd.merge(t_data, on = ['DataDate', 'Ticker'])
    tcom['alpha_bk'] = tcom.groupby('DataDate')['alpha'].apply(lambda x: yu.pdqcut(x,bins=10)).values
    yu.create_cn_3x3_linux(tcom, ['alpha_bk'], 'alpha')
    print(f)



fd = ''
print(fd)
root = '/export/dataprod/Feature_Pool_CN/'+fd
t1 = pd.concat([pd.read_parquet(os.path.join(root, i)) for i in os.listdir(root)],axis=0)
col = [i for i in t1.columns.tolist() if not i in ['Ticker','DataDate','T-1d']][0]
tcom = i_sd[i_sd.DataDate.dt.year==2020].merge(t1, on = ['DataDate', 'Ticker'])
tcom['alpha_bk'] = tcom.groupby('DataDate')[col].apply(lambda x: yu.pdqcut(x,bins=2)).values
yu.create_cn_3x3_linux(tcom, ['alpha_bk'], col)
    




for fd in [i for i in os.listdir('/export/dataprod/Feature_Pool_CN') if 'featurepool_enrich_' in i ]:
    print (fd)
    if fd in ['featurepool_enrich_trade_pqcorr',
            'featurepool_enrich_earn_frcst',
            'featurepool_enrich_guba',
            'featurepool_enrich_suntime_ugdg_e',
            'featurepool_enrich_trod_apb',
            'featurepool_enrich_order_3s',
            'featurepool_enrich_order_60s',
            'featurepool_enrich_trade_large',
            'featurepool_enrich_corpact_unlock',
            'featurepool_enrich_order_0920cancel',
            'featurepool_enrich_suntime_coverage',
            'featurepool_enrich_graph_ret_corr',
            'featurepool_enrich_nb_pctofso',
            'featurepool_enrich_trade_mktc',
            'featurepool_enrich_earn_ugdg',
            'featurepool_enrich_trade_small',
            'featurepool_enrich_mf_holding']:
        continue
    
    root = '/export/dataprod/Feature_Pool_CN/'+fd
    t1 = pd.concat([pd.read_parquet(os.path.join(root, i)) for i in os.listdir(root)],axis=0)
    col = [i for i in t1.columns.tolist() if not i in ['Ticker','DataDate','T-1d']][0]
    tcom = i_sd[i_sd.DataDate.dt.year==2020].merge(t1, on = ['DataDate', 'Ticker'])
    tcom['alpha_bk'] = tcom.groupby('DataDate')[col].apply(lambda x: yu.pdqcut(x,bins=2)).values
    yu.create_cn_3x3_linux(tcom, ['alpha_bk'], col)
