﻿#$%^&* pChoice_concept_02.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Jan  2 10:05:46 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime as dd



# this studies tickers that share the same concept 
# long tickers whose same-concpet peers rally




### get sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['ticker','datadate'])
i_sd['bret_t5d'] = i_sd.groupby('ticker').rolling(dd.timedelta(days=7), on = 'datadate', min_periods = 4)['BarrRet_SRISK_USD-1d'].sum().values
i_sd['bret_t20d'] = i_sd.groupby('ticker').rolling(dd.timedelta(days=28), on = 'datadate', min_periods = 10)['BarrRet_SRISK_USD-1d'].sum().values
i_sd['bret_t60d'] = i_sd.groupby('ticker').rolling(dd.timedelta(days=84), on = 'datadate', min_periods = 30)['BarrRet_SRISK_USD-1d'].sum().values
i_sd = i_sd.sort_values('datadate')

i_sd_dd = i_sd['datadate'].drop_duplicates()



### get Choice concept 

# list of concepts
i_concept_list = yu.get_sql_choice('''select * from [Choice].[dbo].[v_CDSY_KP_PUBLISHINDEX] ''')
i_concept_list_s = i_concept_list[['PUBLISHCODE','PUBLISHNAME','ENDDATE','STARTDATE','EITIME','EUTIME','EISDEL']]

# the reason why a ticker is assigned to a concept
i_concept_reason = yu.get_sql_choice('''select * from [Choice].[dbo].[v_CDSY_KP_PUBLISHREASON] ''')

# parent-child-concept relation
i_concept_relation = yu.get_sql_choice('''select * from [Choice].[dbo].[v_CDSY_KP_PUBLISHRELATION] ''')

# concept-ticker relation 2
i_concept_relation2 = yu.get_sql_choice('''select * from [Choice].[dbo].[v_CDSY_KP_PUBLISHSTOCK] ''')
i_concept_relation2 = i_concept_relation2[['PUBLISHCODE','MSECUCODE','SECURITYNAME','EID','EITIME','EUTIME','EISDEL']]

i_concept_relation3 = i_concept_relation2.merge(i_concept_list_s, on = ['PUBLISHCODE'], how = 'left', suffixes=['','cpt'])
i_concept_relation4 = i_concept_relation3[i_concept_relation3['PUBLISHNAME'].notnull()]
i_concept_relation4['EIDATE'] = pd.to_datetime(i_concept_relation4['EITIME'].dt.date)

i_concept_relation4 = i_concept_relation4.rename(columns = {'MSECUCODE':'ticker'})



### loop for shared choice concept count

o_shared_cpt_hk_bret = []

for dt in pd.date_range(start = '2016-05-01', end = '2021-11-01', freq='W'):
#for dt in pd.date_range(start = '2016-05-01', end = '2021-11-01'):
    print(dt.strftime('%Y%m%d'),end=' ')
    
    # select data
    t_sd = i_sd[i_sd['datadate']==i_sd_dd[i_sd_dd<=dt].max()][['ticker','bret_t20d
']]
    
    t_cpt = i_concept_relation4[i_concept_relation4['EIDATE']<=dt]
    t_cpt = t_cpt[t_cpt['ticker'].isin(t_sd['ticker'].tolist())]
    
    # concept set for each ticker
    t_tk_cptSet = t_cpt.groupby('ticker')['PUBLISHCODE'].apply(lambda x: set(x.tolist()))
    
    # pairwise concept intersection 
    t_tkPair_cptSet = pd.DataFrame((t_tk_cptSet.values[:, None] & t_tk_cptSet.values))
    
    #t_tkPair_cptCnt = t_tkPair_cptSet.applymap(lambda x: 1.1**len(x) )
    # 1.1^len(x) if let it be 0 when len(x) = 1, we get worse results 
    t_tkPair_cptCnt = t_tkPair_cptSet.applymap(lambda x: np.log(len(x)+2) )
    #t_tkPair_cptCnt = t_tkPair_cptSet.applymap(lambda x: len(x) + 1 )
    # next: try np.log(len(x)+1)
    t_tkPair_cptCnt.columns = t_tk_cptSet.index.values
    t_tkPair_cptCnt.index = t_tk_cptSet.index.values
    t_tkPair_cptCnt.values[[np.arange(t_tkPair_cptCnt.shape[0])]*2] = 0
    
    
    # 
    t_bret = pd.DataFrame({'ticker':t_tk_cptSet.index.values})
    t_bret = t_bret.merge(t_sd, on = 'ticker', how = 'left')
    t_bret = t_bret.set_index('ticker')
    
    t_tkPair_cptCnt_wt_bret = t_tkPair_cptCnt.\
                            multiply(t_bret.values, axis = 0).\
                            sum(axis = 0).\
                            divide(t_tkPair_cptCnt.sum(axis = 0).values)
    t_tkPair_cptCnt_wt_bret = t_tkPair_cptCnt_wt_bret.reset_index()
    t_tkPair_cptCnt_wt_bret = t_tkPair_cptCnt_wt_bret.rename(columns={0:'sharedCptWt_bret','index':'ticker'})
    t_tkPair_cptCnt_wt_bret['sharedCptWt_bret'] = t_tkPair_cptCnt_wt_bret['sharedCptWt_bret'].replace(np.inf, np.nan).replace(-np.inf,np.nan)
    
    t_tkPair_cptCnt_wt_bret['datadate'] = dt
    
    o_shared_cpt_hk_bret.append(t_tkPair_cptCnt_wt_bret)


o_shared_cpt_hk_bret = pd.concat(o_shared_cpt_hk_bret, axis = 0)
o_shared_cpt_hk_bret = o_shared_cpt_hk_bret.sort_values('datadate')
    



### combine

#icom = i_sd.merge(o_shared_cpt_hk_bret, on = ['ticker','datadate'], how = 'left')
icom = pd.merge_asof(i_sd, o_shared_cpt_hk_bret, by='ticker', on='datadate', tolerance=pd.to_timedelta('7 days'))
icom = icom.sort_values(['ticker','datadate'])

icom['RawRet_USD-1d'] = icom.groupby('ticker')['RawRet_USD+0d'].shift()
icom['rawret_t20d'] = icom.groupby('ticker').rolling(dd.timedelta(days=28), on = 'datadate', min_periods = 10)['RawRet_USD-1d'].sum().values


icom['sharedCptWt_bret_bk'] = icom.groupby('datadate')['sharedCptWt_bret'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['shar
edCptWt_bret_rk'] = icom.groupby('datadate')['sharedCptWt_bret'].apply(yu.uniformed_rank).values

icom['bret_t20d_rk'] = icom.groupby('datadate')['bret_t20d'].apply(yu.uniformed_rank).values
icom['bret_t20d_bk'] = icom.groupby('datadate')['bret_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['sharedCptWt_bret_rkdf'] = icom['sharedCptWt_bret_rk']- icom['bret_t20d_rk']
icom['sharedCptWt_bret_rkdf_bk'] = icom.groupby('datadate')['sharedCptWt_bret_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['sharedCptWt_bret_rkdf_rk'] = icom.groupby('datadate')['sharedCptWt_bret_rkdf'].apply(yu.uniformed_rank).values

#yu.create_cn_3x3(icom, ['sharedCptWt_bret_rkdf_bk'], 'sharedCptWt_bret_rkdf') # mono: -3, +3




icom['sharedCptWt_bret_rkdf_sgnl'] = np.nan
icom.loc[(icom['sharedCptWt_bret_rkdf_rk']>0.8)&(icom['bret_t20d_rk']<-0.8), 'sharedCptWt_bret_rkdf_sgnl'] = 1
icom.loc[icom['sharedCptWt_bret_rkdf_rk']<-0.8, 'sharedCptWt_bret_rkdf_sgnl'] = -1
icom['sharedCptWt_bret_rkdf_sgnl'] = icom.groupby('ticker')['sharedCptWt_bret_rkdf_sgnl'].ffill(limit = 20)

#!
icom['sharedCptWt_bret_rkdf_sgnl2'] = np.nan
icom.loc[(icom['sharedCptWt_bret_rk']>0.5)&(icom['bret_t20d_rk']<-0.8), 'sharedCptWt_bret_rkdf_sgnl2'] = 1
icom.loc[icom['sharedCptWt_bret_rkdf_rk']<-0.8, 'sharedCptWt_bret_rkdf_sgnl2'] = -1
icom['sharedCptWt_bret_rkdf_sgnl2'] = icom.groupby('ticker')['sharedCptWt_bret_rkdf_sgnl2'].ffill(limit = 20)


icom['sharedCptWt_bret_rkdf_sgnl2s'] = np.nan
icom.loc[(icom['sharedCptWt_bret_rk']<-0.5)&(icom['bret_t20d_rk']>0.8), 'sharedCptWt_bret_rkdf_sgnl2s'] = -1
icom.loc[icom['sharedCptWt_bret_rkdf_rk']>0.8, 'sharedCptWt_bret_rkdf_sgnl2s'] = 1
icom['sharedCptWt_bret_rkdf_sgnl2s'] = icom.groupby('ticker')['sharedCptWt_bret_rkdf_sgnl2s'].ffill(limit = 20)



icom['sharedCptWt_bret_rkdf_sgnl3'] = np.nan
icom.loc[(icom['sharedCptWt_bret_rk']<-0.8)&(icom['bret_t20d_rk']>0.8), 'sharedCptWt_bret_rkdf_sgnl3'] = -1
icom.loc[(icom['sharedCptWt_bret_rk']>0.8)&(icom['bret_t20d_rk']<-0.8), 'sharedCptWt_bret_rkdf_sgnl3'] = 1
icom['sharedCptWt_bret_rkdf_sgnl3'] = icom.groupby('ticker')['sharedCptWt_bret_rkdf_sgnl3'].ffill(limit = 20)


o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-01-01'))&(icom['sharedCptWt_bret_rkdf_rk']>0)].\
            dropna(subset=['sharedCptWt_bret_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sharedCptWt_bret_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) 

o_1 = yu.bt_cn_15(icom[(i
com['datadate'].between('2017-01-01','2020-01-01'))&(icom['sharedCptWt_bret_rkdf_sgnl2']>0)].\
            dropna(subset=['sharedCptWt_bret_rkdf_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sharedCptWt_bret_rkdf_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) #3.16/2.26

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-01-01'))&(icom['sharedCptWt_bret_rkdf_sgnl2s']<0)].\
            dropna(subset=['sharedCptWt_bret_rkdf_sgnl2s','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sharedCptWt_bret_rkdf_sgnl2s','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.95/2.14

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-01-01'))].\
            dropna(subset=['sharedCptWt_bret_rkdf_sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sharedCptWt_bret_rkdf_sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) # 


### benchmark

icom['bret_t20d_sgnl'] = np.nan
icom['bret_t20d_sgnl'] = - icom['bret_t20d_rk']

icom['bret_t20d_sgnl2'] = np.nan
icom.loc[icom['bret_t20d_rk']<-0.8, 'bret_t20d_sgnl2'] = 1
icom.loc[icom['bret_t20d_rk']>0.8, 'bret_t20d_sgnl2'] = -1
icom['bret_t20d_sgnl2'] = icom.groupby('ticker')['bret_t20d_sgnl2'].ffill(limit=20)


yu.create_cn_3x3(icom, ['bret_t20d_bk'], 'bret_t20d') # mono: -3, -3

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-01-01'))].\
            dropna(subset=['bret_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'bret_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd)  # 1.59 / -0.87, turnover 29%

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-01-01'))].\
            dropna(subset=['bret_t20d_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'bret_t20d_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd)  # 1.8/0.65


