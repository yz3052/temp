﻿#$%^&* pIntra_cn_1800uni_01_wpst.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 13 03:28:27 2023

@author: thzhang
"""

import pandas as pd
import numpy as np

import os
import util as yu
import util_intra as yui

from multiprocessing import Pool


### get sd 

i_sd = yui.get_intra_sd()


### get team pst

i_cal = yu.get_sql('''select distinct tradedate_next as tm0d 
                   from cndbprod.dbo.Calendar_Dates_CN order by tradedate_next''')
i_cal['tm1d'] = i_cal['tm0d'].shift()
i_cal = i_cal.dropna()
i_eod = yu.get_sql('''select datadate as tm1d, Ticker, 
                   [Prev Mark],EODShares_Long_MS,EODShares_Long_jp,EODShares_Long_Ml,EODShares_Long_citi,EODShares_Long_ubs,EODShares_Long_gs 
                   from cndbprod.dbo.SMTCN_POS_SLOW_EOD ''')
i_eod['pstD_eod'] = i_eod['Prev Mark'] * (i_eod['EODShares_Long_MS']+i_eod['EODShares_Long_jp']+i_eod['EODShares_Long_Ml']+i_eod['EODShares_Long_citi']+i_eod['EODShares_Long_ubs']+i_eod['EODShares_Long_gs'])
i_eod = i_eod[i_eod['pstD_eod'].gt(0)]
i_sod = yu.get_sql('''select datadate as tm0d, Ticker, 
                   [Prev Mark],SODShares_Long_MS,SODShares_Long_jp,SODShares_Long_Ml,SODShares_Long_citi,SODShares_Long_ubs,SODShares_Long_gs 
                   from cndbprod.dbo.SMTCN_POS_SLOW_SOD ''')
i_sod['pstD_sod'] = i_sod['Prev Mark'] * (i_sod['SODShares_Long_MS']+i_sod['SODShares_Long_jp']+i_sod['SODShares_Long_Ml']+i_sod['SODShares_Long_citi']+i_sod['SODShares_Long_ubs']+i_sod['SODShares_Long_gs'])
i_sod = i_sod[i_sod['pstD_sod'].gt(0)]

i_pst = i_eod[['Ticker','tm1d','pstD_eod']].merge(i_cal, on = 'tm1d', how = 'left')
i_pst = i_pst.merge(i_sod[['Ticker','tm0d','pstD_sod']], on = ['tm0d', 'Ticker'], how = 'left')
i_pst['pstD_sod'] = i_pst['pstD_sod'].fillna(0)
i_pst['pstD_eod'] = i_pst['pstD_eod'].fillna(0)
i_pst['quota'] = i_pst[['pstD_sod', 'pstD_eod']].min(axis = 1)
i_pst = i_pst[i_pst['quota']>0]
i_pst = i_pst[['Ticker','tm1d','tm0d','quota']]



### get feature

if __name__=='__main__':
    
    root1 = '/dat/summit_capital/TZ/PROD_Q/q_intraday_trd_act/'
    with Pool(20) as pool:
        i_feat_act = pool.map(yui.get_feat_act, [root1+f for f in os.listdir(root1)])
    i_feat_act = pd.concat(i_feat_act, axis = 0)

if __name__=='__main__':
    
    root2 = '/dat/summit_capital/TZ/PROD_Q/q_intraday_trd_ls/'
    with Pool(20) as pool:
        i_feat_ls = pool.map(yui.get_feat_ls, [root2+f for f in os.listdir(root2)])
    i_feat_ls = pd.concat(i_feat_ls, a
xis = 0)

if __name__=='__main__':

    root3 = '/dat/summit_capital/TZ/PROD_Q/q_intraday_odbk_imb/'
    with Pool(20) as pool:
        i_feat_imb = pool.map(yui.get_feat_imb, [root3+f for f in os.listdir(root3)])
    i_feat_imb = pd.concat(i_feat_imb, axis = 0)



### combine


icom = i_sd.merge(i_pst, on = ['tm1d', 'Ticker'], how = 'inner')
icom = icom.merge(i_feat_act, on = ['Ticker', 'tm1d', 'ts15m_s'], how = 'left')
icom = icom.merge(i_feat_ls, on = ['Ticker', 'tm1d', 'ts15m_s'], how = 'left')
icom = icom.merge(i_feat_imb, on = ['Ticker', 'tm1d', 'ts15m_s'], how = 'left')
icom = icom.sort_values(['Ticker', 'tm1d', 'ts15m_s'])



#---- bar chart - active 

icom['d_actB_nmsm15m'] = icom['d_actB_sm15m'] / icom['d_tot_sm15m']
icom['d_actB_nmsm15m_bk'] = icom.groupby(['tm1d', 'ts15m_s'])['d_actB_nmsm15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['d_actB_nmsm60m'] = icom['d_actB_sm60m'] / icom['d_tot_sm60m']
icom['d_actB_nmsm60m_bk'] = icom.groupby(['tm1d', 'ts15m_s'])['d_actB_nmsm60m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['d_actB_nmsmsod'] = icom['d_actB_sinceO'] / icom['d_tot_sinceO']
icom['d_actB_nmsmsod_bk'] = icom.groupby(['tm1d', 'ts15m_s'])['d_actB_nmsmsod'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['d_actS_nmsm15m'] = icom['d_actS_sm15m'] / icom['d_tot_sm15m']
icom['d_actN_nmsm15m'] = icom['d_actB_nmsm15m'] - icom['d_actS_nmsm15m']
icom['d_actN_nmsm15m_bk'] = icom.groupby(['tm1d','ts15m_s'])['d_actN_nmsm15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yui.plot_barchart_cn(icom, 'd_actN_nmsm15m_bk', 'd_actN_nmsm15m', col_ret = 'rawret_p15m_rk') # mono
yui.plot_barchart_cn(icom, 'd_actN_nmsm15m_bk', 'd_actN_nmsm15m', col_ret = 'rawret_p15m') # -3.9 +6.4

icom['d_actN_nmsm15m_rk'] = icom.groupby('tm1d')['d_actN_nmsm15m'].apply(yu.uniformed_rank)
icom['d_actN_nmsm15m_sgnl'] = - icom['d_actN_nmsm15m_rk']
icom.loc[icom['d_actN_nmsm15m_sgnl'].abs()<0.95, 'd_actN_nmsm15m_sgnl'] = np.nan
yui.plot_pnl_cn(icom, col_sgnl = 'd_actN_nmsm15m_sgnl', col_ret = 'rawret_p60m')
yui.plot_pnl_cn_wquota(icom, col_sgnl = 'd_actN_nmsm15m_sgnl', col_ret = 'rawret_p60m')
# 6.4 / 1.1, very flat





#---- bar chart - ls

icom['sell_small_sm15m_pct'] = icom['sell_small_sm15m'] / icom['sell_all_sm15m']
icom['sell_small_sm15m_pct_bk'] = icom.groupby(['tm1d','ts15m_s'])['sell_small_sm15m_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'sell_small_sm15m_pct_bk', 'sell_small_sm15m_pct', col_ret = 'rawret_p15m_rk') # -ve 
mono
yui.plot_barchart_cn(icom, 'sell_small_sm15m_pct_bk', 'sell_small_sm15m_pct', col_ret = 'rawret_p15m') # 0 1.0 -1.8

icom['sell_small_sod_pct'] = icom['sell_small_sod'] / icom['sell_all_sod']
icom['sell_small_sod_pct_bk'] = icom.groupby(['tm1d','ts15m_s'])['sell_small_sod_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'sell_small_sod_pct_bk', 'sell_small_sod_pct', col_ret = 'rawret_p15m_rk') # -ve mono
yui.plot_barchart_cn(icom, 'sell_small_sod_pct_bk', 'sell_small_sod_pct', col_ret = 'rawret_p15m') # +0.5 +0.2

icom['buy_small_sm15m_pct'] = icom['buy_small_sm15m'] / icom['buy_all_sm15m']
icom['buy_small_sm15m_pct_bk'] = icom.groupby(['tm1d','ts15m_s'])['buy_small_sm15m_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'buy_small_sm15m_pct_bk', 'buy_small_sm15m_pct', col_ret = 'rawret_p15m_rk') # +ve mono
yui.plot_barchart_cn(icom, 'buy_small_sm15m_pct_bk', 'buy_small_sm15m_pct', col_ret = 'rawret_p15m') # -ve mono: +2.5 -0.6


# bar chart - ls
# its weired rawret_rk and rawret's relationship with the feature are opposite
# this is because alpha itself has negative correlation with past return

icom['net_small_sm15m'] = (icom['buy_small_sm15m']-icom['sell_small_sm15m']) / (icom['buy_all_sod'] + icom['sell_all_sod']) * 2
icom['net_small_sm15m_bk'] = icom.groupby(['tm1d','ts15m_s'])['net_small_sm15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yui.plot_barchart_cn(icom, 'net_small_sm15m_bk', 'net_small_sm15m', col_ret = 'rawret_p15m_rk') # +ve relation
yui.plot_barchart_cn(icom, 'net_small_sm15m_bk', 'net_small_sm15m', col_ret = 'rawret_p15m') # -ve relation
yui.plot_barchart_cn(icom, 'net_small_sm15m_bk', 'net_small_sm15m', col_ret = 'rawret_p15m_demean') # -ve relation



icom.loc[icom['clip15m'].lt(1e5) & icom['net_small_sm15m_bk'].eq(0), 'rawret_p15m'].mean() #-0.038
icom.loc[icom['clip15m'].lt(1e5) & icom['net_small_sm15m_bk'].eq(0), 'rawret_p15m_rk'].mean() #-0.0002

icom.loc[icom['clip15m'].gt(5e5) & icom['net_small_sm15m_bk'].eq(0), 'rawret_p15m'].mean() #0.0004
icom.loc[icom['clip15m'].gt(5e5) & icom['net_small_sm15m_bk'].eq(0), 'rawret_p15m_rk'].mean() #-0.0038


#!
icom.loc[icom['net_small_sm15m_bk'].eq(0), 'rawret_p15m'].hist(bins=100)
icom.loc[icom['net_small_sm15m_bk'].eq(0), 'rawret_p15m'].mean()
icom.loc[icom['net_small_sm15m_bk'].eq(9), 'rawret_p15m'].mean()
icom['net_small_sm15m_rk'] = icom.groupby(['tm1d','ts15m_s'])['net_small_sm15m'].apply(yu.uniformed_rank)
yui.plot_pnl_
cn(icom, col_sgnl = 'net_small_sm15m_rk', col_ret = 'rawret_p15m')
#!


#---- bar chart - imb

icom['baratio_avg15m_bk'] = icom.groupby(['tm1d','ts15m_s'])['baratio_avg15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'baratio_avg15m_bk', 'baratio_avg15m', col_ret = 'rawret_p15m_rk') # +ve mono 

icom['baratio_avg15m_rk'] = icom.groupby(['tm1d','ts15m_s'])['baratio_avg15m'].apply(yu.uniformed_rank)
icom['baratio_avg15m_sgnl2'] = np.nan
c1 = icom['baratio_avg15m_rk'].abs()>0.99
icom.loc[c1, 'baratio_avg15m_sgnl2'] = icom.loc[c1, 'baratio_avg60m_rk']
yui.plot_pnl_cn(icom, col_sgnl = 'baratio_avg15m_sgnl2', col_ret = 'rawret_p60m') 

icom['baratio_avg60m_rk'] = icom.groupby(['tm1d','ts15m_s'])['baratio_avg60m'].apply(yu.uniformed_rank)
icom['baratio_avg60m_sgnl2'] = np.nan
c1 = icom['baratio_avg60m_rk'].abs()>0.95
icom.loc[c1, 'baratio_avg60m_sgnl2'] = - icom.loc[c1, 'baratio_avg60m_rk']
yui.plot_pnl_cn(icom, col_sgnl = 'baratio_avg60m_sgnl2', col_ret = 'rawret_p60m') 
yui.plot_pnl_cn_wquota(icom, col_sgnl = 'baratio_avg60m_sgnl2', col_ret = 'rawret_p60m') 
# no alpha



#---- bar chart - reversal
# 2023 very flat

icom['rawret_m15m_bk'] = icom.groupby(['tm1d','ts15m_e'])['rawret_m15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'rawret_m15m_bk', 'rawret_m15m', col_ret = 'rawret_p15m_rk') # a-shaped, right side high t
yui.plot_barchart_cn(icom, 'rawret_m15m_bk', 'rawret_m15m', col_ret = 'rawret_p60m_rk') # a-shaped, right side high t

icom['rawret_sod_bk'] = icom.groupby(['tm1d','ts15m_e'])['rawret_sod'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'rawret_sod_bk', 'rawret_sod', col_ret = 'rawret_eod_rk') 

icom['rawret_sod_rk'] = icom.groupby(['tm1d','ts15m_s'])['rawret_sod'].apply(yu.uniformed_rank)
icom['rawret_sod_sgnl2'] = np.nan
c1 = icom['rawret_sod_rk'].abs().gt(0.95) #& icom['ts15m_e'].dt.hour.ge(13)
icom.loc[c1, 'rawret_sod_sgnl2'] = - icom.loc[c1, 'rawret_sod_rk']
yui.plot_pnl_cn(icom, col_sgnl = 'rawret_sod_sgnl2', col_ret = 'rawret_eod') 
yui.plot_pnl_cn_wquota(icom, col_sgnl = 'rawret_sod_sgnl2', col_ret = 'rawret_eod') 
