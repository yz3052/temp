﻿#$%^&* pGraph_cn_supply_etl.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 24 13:55:16 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import zipfile
from zipfile import ZipFile as zf

import shutil



### inspections

# SC: read all files = full + incremental files

o_all_files = []

for r,p,fs in os.walk(r'Z:\Factset\SupplyChain\ent_supply_chain'):
    for f in fs:
        if f.endswith('.zip'):
            o_all_files.append([r, f, os.path.join(r, f), os.path.getsize(os.path.join(r, f))])
   
o_all_files = pd.DataFrame(o_all_files, columns = ['r','f','p','szie'])         

   


# SC hub: read all files

o_schub_files = []

for r,p,fs in os.walk(r'Z:\Factset\SupplyChain\ent_supply_chain_hub'):
    for f in fs:
        if f.endswith('.zip'):
            o_schub_files.append([r, f, os.path.join(r, f), os.path.getsize(os.path.join(r, f))])
   
o_schub_files = pd.DataFrame(o_schub_files, columns = ['r','f','p','szie'])


# SC parent: read all files

o_scpar_files = []

for r,p,fs in os.walk(r'Z:\Factset\SupplyChain\ent_supply_chain_parent'):
    for f in fs:
        if f.endswith('.zip'):
            o_scpar_files.append([r, f, os.path.join(r, f), os.path.getsize(os.path.join(r, f))])
   
o_scpar_files = pd.DataFrame(o_scpar_files, columns = ['r','f','p','szie'])



# add delete dynamics

#t1 = pd.read_csv(zipfile.ZipFile(r'Z:\Factset\SupplyChain\ent_supply_chain\2019\07\13\ent_supply_chain_v1_1646.zip').open('ent_scr_relationships_delete.txt'),sep='|')
#t2 = pd.read_csv(zipfile.ZipFile(r'Z:\Factset\SupplyChain\ent_supply_chain\2019\07\13\ent_supply_chain_v1_1646.zip').open('ent_scr_relationships_update.txt'),sep='|')
#t3 = pd.read_csv(zipfile.ZipFile(r'Z:\Factset\SupplyChain\ent_supply_chain\2019\07\13\ent_supply_chain_v1_full_1646.zip').open('ent_scr_relationships.txt'),sep='|')
#
#t3b = t3[t3['ID'].isin(t2['ID'].tolist())]
#t3b = t3b[t3b['ID'].isin(t3b[t3b.duplicated(subset=['ID'])]['ID'].tolist() )]
#
#t3b = t3[t3['ID'].isin(t1['ID'].tolist())]


# symb: ticker exchange

t1 = pd.read_csv(zipfile.ZipFile(r'Z:\Factset\Symbology\sym_ticker\2019\06\15\sym_ticker_v1_full_2644.zip').open('sym_ticker_exchange.txt'),sep='|')
t1b = t1[t1['TICKER_EXCHANGE'].str.contains('002202')]

'SSC','SHG','SEC','SHE'




#------------------------------------------------------------------------------
### extract a snapshot dataset on the last available day on mdwarehouse
# this is the old pr
ocess. IGNORE.

# determine dates that have "full" files

o_full_dates = []

for r,p,fs in os.walk(r'Z:\Factset\SupplyChain\ent_supply_chain'):
    for f in fs:
        if ('_full' in f.lower()) and f.endswith('.zip'):
            r_split = r.split('\\')
            o_full_dates.append([r_split[-3],r_split[-2],r_split[-1]])
 
# get data           

dt = o_full_dates[120]

r_supplychain = os.path.join(r'Z:\Factset\SupplyChain\ent_supply_chain',dt[0],dt[1],dt[2])
f_supplychain = [f for f in os.listdir(r_supplychain) if '_full_' in f][0]
f_supplychain = os.path.join(r_supplychain, f_supplychain)
df_supplychain = pd.read_csv(zipfile.ZipFile(f_supplychain,'r').open('ent_scr_supply_chain.txt'),sep='|')

df_relation = pd.read_csv(zipfile.ZipFile(f_supplychain,'r').open('ent_scr_relationships.txt'),sep='|')



r_hub = os.path.join(r'Z:\Factset\SupplyChain\ent_supply_chain_hub',dt[0],dt[1],dt[2])
f_hub = [f for f in os.listdir(r_hub) if '_full_' in f][0]
f_hub = os.path.join(r_hub, f_hub)
df_hub = pd.read_csv(zipfile.ZipFile(f_hub,'r').open('ent_scr_sec_entity.txt'),sep='|')

df_hub_hist = pd.read_csv(zipfile.ZipFile(f_hub,'r').open('ent_scr_sec_entity_hist.txt'),sep='|')

r_ticker_s = os.path.join(r'Z:\Factset\Symbology\sym_hub',dt[0],dt[1],dt[2])
f_ticker_s = [f for f in os.listdir(r_ticker_s) if '_full_' in f][0]
f_ticker_s = os.path.join(r_ticker_s, f_ticker_s)
df_ticker_s = pd.read_csv(zipfile.ZipFile(f_ticker_s,'r').open('sym_coverage.txt'),sep='|',usecols=['FSYM_ID','FSYM_PRIMARY_LISTING_ID']) 
df_ticker_s = df_ticker_s[df_ticker_s['FSYM_ID'].str[-2:]=='-S']
df_ticker_s = df_ticker_s[df_ticker_s['FSYM_PRIMARY_LISTING_ID'].notnull()]
df_ticker_s = df_ticker_s[['FSYM_ID','FSYM_PRIMARY_LISTING_ID']]

r_ticker_r = os.path.join(r'Z:\Factset\Symbology\sym_ticker',dt[0],dt[1],dt[2])
f_ticker_r = [f for f in os.listdir(r_ticker_r) if '_full_' in f][0]
f_ticker_r = os.path.join(r_ticker_r, f_ticker_r)
df_ticker_r = pd.read_csv(zipfile.ZipFile(f_ticker_r,'r').open('sym_ticker_region.txt'),sep='|')
df_ticker_r = df_ticker_r[['FSYM_ID','TICKER_REGION']]

com_ticker = df_hub_hist.merge(df_ticker_s, on = 'FSYM_ID', how = 'inner')
com_ticker = com_ticker.merge(df_ticker_r, left_on = 'FSYM_PRIMARY_LISTING_ID', right_on = 'FSYM_ID', suffixes=['','_tkregion'], how = 'inner')
com_ticker = com_ticker[com_ticker['TICKER_REGION'].str.endswith('-CN')]
com_ticker = com_ticker[['FACTSET_ENTITY_ID','FSYM_ID','TICKER_REGION']].drop_duplicates()


i_relation = df_relation.merge(com_tic
ker, left_on='SOURCE_FACTSET_ENTITY_ID', right_on='FACTSET_ENTITY_ID', how='left',suffixes=['','_m'])
i_relation = i_relation.drop(columns=['FACTSET_ENTITY_ID','FSYM_ID'])
i_relation = i_relation.rename(columns={'TICKER_REGION':'ticker_source'})
i_relation = i_relation.merge(com_ticker, left_on='TARGET_FACTSET_ENTITY_ID', right_on='FACTSET_ENTITY_ID', how='left',suffixes=['','_m'])
i_relation = i_relation.drop(columns=['FACTSET_ENTITY_ID','FSYM_ID'])
i_relation = i_relation.rename(columns={'TICKER_REGION':'ticker_target'})

i_relation = i_relation[i_relation['ticker_source'].notnull() | i_relation['ticker_target'].notnull()]
i_relation.to_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_supply_etl_i_relation.parquet')



i_supply = df_supplychain.merge(com_ticker, left_on='SUPPLIER_FACTSET_ENTITY_ID', right_on='FACTSET_ENTITY_ID', how='left',suffixes=['','_m'])
i_supply = i_supply.drop(columns=['FACTSET_ENTITY_ID','FSYM_ID'])
i_supply = i_supply.rename(columns={'TICKER_REGION':'ticker_supplier'})
i_supply = i_supply.merge(com_ticker, left_on='CUSTOMER_FACTSET_ENTITY_ID', right_on='FACTSET_ENTITY_ID', how='left',suffixes=['','_m'])
i_supply = i_supply.drop(columns=['FACTSET_ENTITY_ID','FSYM_ID'])
i_supply = i_supply.rename(columns={'TICKER_REGION':'ticker_customer'})

i_supply = i_supply[i_supply['ticker_supplier'].notnull() | i_supply['ticker_customer'].notnull()]
i_supply.to_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_supply_etl_i_supply.parquet')




#------------------------------------------------------------------------------
### read full files, and save them as parqeuts
# except for: scr_relationships_keyword

# ent_supply_chain -> full.zip -> ent_scr_coverage
for r,p,fs in os.walk(r'Z:\Factset\SupplyChain\ent_supply_chain'):
    for f in fs:
        if f.endswith('.zip') and ('_full_' in f):
            yyyy = r.split('\\')[-3]
            mm = r.split('\\')[-2]
            dd = r.split('\\')[-1]
            print(yyyy+mm+dd, end = ' ')
            t_data = pd.read_csv(zf(os.path.join(r,f)).open('ent_scr_coverage.txt'),sep='|')
            t_data['modified_ts_est'] = pd.to_datetime(os.path.getmtime(os.path.join(r,f)), unit = 's')
            t_data['datadate'] = pd.to_datetime(yyyy+'-'+mm+'-'+dd)
            t_data.to_parquet(os.path.join(r'S:\Data\Factset\raw_weekly_full_files\ent_supply_chain\ent_scr_coverage', yyyy+mm+dd+'.parquet'))
            
# ent_supply_chain -> full.zip -> ent_scr_relationships
for r,p,fs in os.walk(r'Z:\Factset\Su
pplyChain\ent_supply_chain'):
    for f in fs:
        if f.endswith('.zip') and ('_full_' in f):
            yyyy = r.split('\\')[-3]
            mm = r.split('\\')[-2]
            dd = r.split('\\')[-1]
            print(yyyy+mm+dd, end = ' ')
            t_data = pd.read_csv(zf(os.path.join(r,f)).open('ent_scr_relationships.txt'),sep='|')
            t_data['modified_ts_est'] = pd.to_datetime(os.path.getmtime(os.path.join(r,f)), unit = 's')
            t_data['datadate'] = pd.to_datetime(yyyy+'-'+mm+'-'+dd)
            t_data.to_parquet(os.path.join(r'S:\Data\Factset\raw_weekly_full_files\ent_supply_chain\ent_scr_relationships', yyyy+mm+dd+'.parquet'))            

# ent_supply_chain -> full.zip -> ent_scr_supply_chain
for r,p,fs in os.walk(r'Z:\Factset\SupplyChain\ent_supply_chain'):
    for f in fs:
        if f.endswith('.zip') and ('_full_' in f):
            yyyy = r.split('\\')[-3]
            mm = r.split('\\')[-2]
            dd = r.split('\\')[-1]
            print(yyyy+mm+dd, end = ' ')
            t_data = pd.read_csv(zf(os.path.join(r,f)).open('ent_scr_supply_chain.txt'),sep='|')
            t_data['modified_ts_est'] = pd.to_datetime(os.path.getmtime(os.path.join(r,f)), unit = 's')
            t_data['datadate'] = pd.to_datetime(yyyy+'-'+mm+'-'+dd)
            t_data.to_parquet(os.path.join(r'S:\Data\Factset\raw_weekly_full_files\ent_supply_chain\ent_scr_supply_chain', yyyy+mm+dd+'.parquet'))

# ent_supply_chain -> full.zip -> scr_relationships_summary
for r,p,fs in os.walk(r'Z:\Factset\SupplyChain\ent_supply_chain'):
    for f in fs:
        if f.endswith('.zip') and ('_full_' in f):
            yyyy = r.split('\\')[-3]
            mm = r.split('\\')[-2]
            dd = r.split('\\')[-1]
            print(yyyy+mm+dd, end = ' ')
            t_data = pd.read_csv(zf(os.path.join(r,f)).open('scr_relationships_summary.txt'),sep='|')
            t_data['modified_ts_est'] = pd.to_datetime(os.path.getmtime(os.path.join(r,f)), unit = 's')
            t_data['datadate'] = pd.to_datetime(yyyy+'-'+mm+'-'+dd)
            t_data.to_parquet(os.path.join(r'S:\Data\Factset\raw_weekly_full_files\ent_supply_chain\scr_relationships_summary', yyyy+mm+dd+'.parquet'))
            
# ent_supply_chain_hub -> full.zip -> ent_scr_sec_entity
for r,p,fs in os.walk(r'Z:\Factset\SupplyChain\ent_supply_chain_hub'):
    for f in fs:
        if f.endswith('.zip') and ('_full_' in f):
            yyyy = r.split('\\')[-3]
            mm = r.split('\\')[-2]
            dd = r
.split('\\')[-1]
            print(yyyy+mm+dd, end = ' ')
            t_data = pd.read_csv(zf(os.path.join(r,f)).open('ent_scr_sec_entity.txt'),sep='|')
            t_data['modified_ts_est'] = pd.to_datetime(os.path.getmtime(os.path.join(r,f)), unit = 's')
            t_data['datadate'] = pd.to_datetime(yyyy+'-'+mm+'-'+dd)
            t_data.to_parquet(os.path.join(r'S:\Data\Factset\raw_weekly_full_files\ent_supply_chain_hub\ent_scr_sec_entity', yyyy+mm+dd+'.parquet'))

# ent_supply_chain_hub -> full.zip -> ent_scr_sec_entity_hist
for r,p,fs in os.walk(r'Z:\Factset\SupplyChain\ent_supply_chain_hub'):
    for f in fs:
        if f.endswith('.zip') and ('_full_' in f):
            yyyy = r.split('\\')[-3]
            mm = r.split('\\')[-2]
            dd = r.split('\\')[-1]
            print(yyyy+mm+dd, end = ' ')
            t_data = pd.read_csv(zf(os.path.join(r,f)).open('ent_scr_sec_entity_hist.txt'),sep='|')
            t_data['modified_ts_est'] = pd.to_datetime(os.path.getmtime(os.path.join(r,f)), unit = 's')
            t_data['datadate'] = pd.to_datetime(yyyy+'-'+mm+'-'+dd)
            t_data.to_parquet(os.path.join(r'S:\Data\Factset\raw_weekly_full_files\ent_supply_chain_hub\ent_scr_sec_entity_hist', yyyy+mm+dd+'.parquet'))

# ent_supply_chain_parent -> full.zip -> ent_scr_parent
for r,p,fs in os.walk(r'Z:\Factset\SupplyChain\ent_supply_chain_parent'):
    for f in fs:
        if f.endswith('.zip') and ('_full_' in f):
            yyyy = r.split('\\')[-3]
            mm = r.split('\\')[-2]
            dd = r.split('\\')[-1]
            print(yyyy+mm+dd, end = ' ')
            t_data = pd.read_csv(zf(os.path.join(r,f)).open('ent_scr_parent.txt'),sep='|')
            t_data['modified_ts_est'] = pd.to_datetime(os.path.getmtime(os.path.join(r,f)), unit = 's')
            t_data['datadate'] = pd.to_datetime(yyyy+'-'+mm+'-'+dd)
            t_data.to_parquet(os.path.join(r'S:\Data\Factset\raw_weekly_full_files\ent_supply_chain_parent\ent_scr_parent', yyyy+mm+dd+'.parquet'))
           
# ent_supply_relevance_rank -> full.zip -> scr_relevance_rank
for r,p,fs in os.walk(r'Z:\Factset\SupplyChain\ent_scr_relevance_rank'):
    for f in fs:
        if f.endswith('.zip') and ('_full_' in f):
            yyyy = r.split('\\')[-3]
            mm = r.split('\\')[-2]
            dd = r.split('\\')[-1]
            print(yyyy+mm+dd, end = ' ')
            t_data = pd.read_csv(zf(os.path.join(r,f)).open('scr_relevance_rank.txt'),sep='|')
            t_data['modified_ts_es
t'] = pd.to_datetime(os.path.getmtime(os.path.join(r,f)), unit = 's')
            t_data['datadate'] = pd.to_datetime(yyyy+'-'+mm+'-'+dd)
            t_data.to_parquet(os.path.join(r'S:\Data\Factset\raw_weekly_full_files\ent_scr_relevance_rank\scr_relevance_rank', yyyy+mm+dd+'.parquet'))

# Symbology -> sym_hub -> full.zip -> sym_coverage
# only kept stocks
for r,p,fs in os.walk(r'Z:\Factset\Symbology\sym_hub'):
    for f in fs:
        if f.endswith('.zip') and ('_full_' in f):
            yyyy = r.split('\\')[-3]
            mm = r.split('\\')[-2]
            dd = r.split('\\')[-1]
            print(yyyy+mm+dd, end = ' ')
            t_data = pd.read_csv(zf(os.path.join(r,f)).open('sym_coverage.txt'),sep='|',encoding='latin-1')
            t_data = t_data[~t_data['FREF_SECURITY_TYPE'].isin(['WARRANT','MF_O','STRUCT','MF_C','ETF_ETF','PREF','TEMP','RIGHT','UNIT','PREFEQ','ALIEN','ETF_UVI','ETF_NAV'])]
            t_data['modified_ts_est'] = pd.to_datetime(os.path.getmtime(os.path.join(r,f)), unit = 's')
            t_data['datadate'] = pd.to_datetime(yyyy+'-'+mm+'-'+dd)
            t_data.to_parquet(os.path.join(r'S:\Data\Factset\raw_weekly_full_files\sym_hub\sym_coverage', yyyy+mm+dd+'.parquet'),allow_truncated_timestamps=True)
           
# Symbology -> sym_ticker -> full.zip -> sym_ticker_exchange 
for r,p,fs in os.walk(r'Z:\Factset\Symbology\sym_ticker'):
    for f in fs:
        if f.endswith('.zip') and ('_full_' in f):
            yyyy = r.split('\\')[-3]
            mm = r.split('\\')[-2]
            dd = r.split('\\')[-1]
            print(yyyy+mm+dd, end = ' ')
            t_data = pd.read_csv(zf(os.path.join(r,f)).open('sym_ticker_exchange.txt'),sep='|')
            t_data['modified_ts_est'] = pd.to_datetime(os.path.getmtime(os.path.join(r,f)), unit = 's')
            t_data['datadate'] = pd.to_datetime(yyyy+'-'+mm+'-'+dd)
            t_data.to_parquet(os.path.join(r'S:\Data\Factset\raw_weekly_full_files\sym_ticker\sym_ticker_exchange', yyyy+mm+dd+'.parquet'),allow_truncated_timestamps=True)

# Symbology -> sym_ticker -> full.zip -> sym_ticker_region 
for r,p,fs in os.walk(r'Z:\Factset\Symbology\sym_ticker'):
    for f in fs:
        if f.endswith('.zip') and ('_full_' in f):
            yyyy = r.split('\\')[-3]
            mm = r.split('\\')[-2]
            dd = r.split('\\')[-1]
            print(yyyy+mm+dd, end = ' ')
            t_data = pd.read_csv(zf(os.path.join(r,f)).open('sym_ticker_region.txt'),sep='|')
            t_data['modified_ts
_est'] = pd.to_datetime(os.path.getmtime(os.path.join(r,f)), unit = 's')
            t_data['datadate'] = pd.to_datetime(yyyy+'-'+mm+'-'+dd)
            t_data.to_parquet(os.path.join(r'S:\Data\Factset\raw_weekly_full_files\sym_ticker\sym_ticker_region', yyyy+mm+dd+'.parquet'),allow_truncated_timestamps=True)

# Symbology -> sym_entity -> full.zip -> sym_entity
for r,p,fs in os.walk(r'Z:\Factset\Symbology\sym_entity'):
    for f in fs:
        if f.endswith('.zip') and ('_full_' in f):
            yyyy = r.split('\\')[-3]
            mm = r.split('\\')[-2]
            dd = r.split('\\')[-1]
            print(yyyy+mm+dd, end = ' ')
            t_data = pd.read_csv(zf(os.path.join(r,f)).open('sym_entity.txt'),sep='|',encoding='latin-1')
            t_data['modified_ts_est'] = pd.to_datetime(os.path.getmtime(os.path.join(r,f)), unit = 's')
            t_data['datadate'] = pd.to_datetime(yyyy+'-'+mm+'-'+dd)
            t_data.to_parquet(os.path.join(r'S:\Data\Factset\raw_weekly_full_files\sym_entity\sym_entity', yyyy+mm+dd+'.parquet'),allow_truncated_timestamps=True)





#------------------------------------------------------------------------------
### The new data-loading process, as of 2022.01.01, not PIT

# prepare ticker mapping
# this links any entity_id to stock tickers

i_ent_scr_sec_entity = pd.read_parquet(r"S:\Data\Factset\raw_weekly_full_files\ent_supply_chain_hub\ent_scr_sec_entity\20220101.parquet",
                                       columns = ['FSYM_ID', 'FACTSET_ENTITY_ID']) # 1 entity <> multiple fsym

i_sym_coverage = pd.read_parquet(r"S:\Data\Factset\raw_weekly_full_files\sym_hub\sym_coverage\20220212.parquet",
                                 columns = ['FSYM_ID', 'PROPER_NAME', 'FSYM_PRIMARY_EQUITY_ID', 
                                            'FSYM_PRIMARY_LISTING_ID', 'FSYM_REGIONAL_ID', 'FSYM_SECURITY_ID'])
i_sym_coverage = i_sym_coverage[i_sym_coverage['FSYM_ID']==i_sym_coverage['FSYM_PRIMARY_EQUITY_ID']]
    
i_sym_ticker_region = pd.read_parquet(r"S:\Data\Factset\raw_weekly_full_files\sym_ticker\sym_ticker_region\20220101.parquet",
                                      columns = ['FSYM_ID','TICKER_REGION'])

i_tk_map = i_ent_scr_sec_entity.merge(i_sym_coverage, on = 'FSYM_ID', how = 'inner')
i_tk_map = i_tk_map.merge(i_sym_ticker_region, left_on = 'FSYM_PRIMARY_LISTING_ID', right_on = 'FSYM_ID', 
                          how = 'inner', suffixes = ['', '_region'])
i_tk_map = i_tk_map.drop(columns = ['FSYM_ID_region'])
i_tk_m
ap = i_tk_map[['FACTSET_ENTITY_ID','TICKER_REGION','PROPER_NAME']]


# get supply chain data

i_ent_sc = pd.read_parquet(r"S:\Data\Factset\raw_weekly_full_files\ent_supply_chain\ent_scr_supply_chain\20220101.parquet")


# left join tickers into supply chain

i_ent_sc_s2 = i_ent_sc.merge(i_tk_map, left_on = 'SUPPLIER_FACTSET_ENTITY_ID', right_on = 'FACTSET_ENTITY_ID', how = 'left')
i_ent_sc_s2 = i_ent_sc_s2.drop(columns = ['FACTSET_ENTITY_ID'])\
                         .rename(columns = {'TICKER_REGION':'TICKER_REGION_supplier','PROPER_NAME':'NAME_supplier'})
i_ent_sc_s2 = i_ent_sc_s2.merge(i_tk_map, left_on = 'CUSTOMER_FACTSET_ENTITY_ID', right_on = 'FACTSET_ENTITY_ID', how = 'left')
i_ent_sc_s2 = i_ent_sc_s2.drop(columns = ['FACTSET_ENTITY_ID'])\
                         .rename(columns = {'TICKER_REGION':'TICKER_REGION_customer','PROPER_NAME':'NAME_customer'})

# we can also left join tickers into the relationship table

