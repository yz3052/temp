﻿#$%^&* pCorpAct_cn_dealoffer.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 12 09:21:25 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime
import os

# yes we hc gud ret, but sample too small


### sd


i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])



### get data from exchange

i_sh = pd.read_excel(r"S:\TZ\China Data Hunt\deal_offer\shanghai_deal_offer.xlsx")
i_sh.columns = ['ticker', 'name', 'acquirer', 'start', 'end', 'remaining']
i_sh['ticker'] = i_sh['ticker'].astype(int).astype(str) + '.SH'
i_sh['start'] = pd.to_datetime(i_sh['start'])
i_sh['end'] = pd.to_datetime(i_sh['end'])

i_sz = pd.read_excel(r"S:\TZ\China Data Hunt\deal_offer\shenzhen_deal_offer.xlsx")
i_sz.columns = ['id','ticker', 'name', 'start', 'end', ]
i_sz['ticker'] = i_sz['ticker'].astype(int).astype(str).str.zfill(6) + '.SZ'
i_sz['start'] = pd.to_datetime(i_sz['start'])
i_sz['end'] = pd.to_datetime(i_sz['end'])

i_deal = i_sh[['ticker','start','end']].append(i_sz[['ticker','start','end']], sort=False)
i_deal['datadate'] = i_deal['start']
i_deal = i_deal.sort_values('datadate')


### get data from wind 

i_deal = yu.get_sql('''select a.s_info_compcode, b.s_info_windcode as ticker,
                    a.acquirer_name, start_date, end_date, a.is_privatization, 
                    a.purchasing_price
                    from wind.dbo.AshareOfferforoffer a
                    inner join wind_prod.dbo.windcustomcode b
                    on a.s_info_compcode=b.s_info_compcode
                    where a.purchasing_price is not null 
                    and b.s_info_securitiestypes = 'A'
                    ''')

i_deal = i_deal[i_deal['end_date'].notnull()]
i_deal['end_date'] = pd.to_datetime(i_deal['end_date'], format = '%Y%m%d')

i_deal = i_deal[i_deal['start_date'].notnull()]
i_deal['datadate'] = pd.to_datetime(i_deal['start_date'], format='%Y%m%d')
i_deal['start_date'] = pd.to_datetime(i_deal['start_date'], format='%Y%m%d')
i_deal = i_deal.sort_values('datadate')


### get data from EM


i_td = yu.get_sql_prod('''select datadate as impact_cdate, tradedate_next from cndbprod.dbo.Calendar_Dates_CN
                     order by datadate''')

i_files = os.listdir(r'S:\TZ\China Data Hunt\ann_em')
i_ann = pd.concat([pd.read_parquet(os.path.join(r'S:\TZ\China Data Hunt\ann_em', i)) for i in i_files], sort=False)

i_ann['eiTime'] = pd.to_datetime(i_ann['eiTime'], format = '%Y-%m-%d 
%H:%M:%S:%f', errors='coerce')
i_ann['datadate'] = pd.to_datetime((i_ann['eiTime'] - pd.to_timedelta('3 hours')).dt.date)
i_ann['notice_date'] = pd.to_datetime(i_ann['notice_date'])


i_ann_s2 = i_ann[i_ann['title'].str.contains('要约') | i_ann['ann_type_desc'].str.contains('要约')]

i_ann_s2 = i_ann_s2.drop(columns = ['title_ch', 'new_column_code', 'notice_date'])

c_sh = i_ann_s2['ticker'].str[0].isin(['6'])
c_sz = i_ann_s2['ticker'].str[0].isin(['0','3'])
i_ann_s2.loc[c_sh, 'ticker'] = i_ann_s2.loc[c_sh, 'ticker']+ '.SH'
i_ann_s2.loc[c_sz, 'ticker'] = i_ann_s2.loc[c_sz, 'ticker']+ '.SZ'

c1 = i_ann_s2['eiTime'].dt.strftime('%H%M')<='1450'
c2 = i_ann_s2['eiTime'].dt.strftime('%H%M')>'1450'
i_ann_s2.loc[c1, 'impact_cdate'] = pd.to_datetime(i_ann_s2.loc[c1, 'eiTime'].dt.date)
i_ann_s2.loc[c2, 'impact_cdate'] = pd.to_datetime(i_ann_s2.loc[c2, 'eiTime'].dt.date) + pd.to_timedelta('1 day')
i_ann_s2 = i_ann_s2.merge(i_td, on = 'impact_cdate', how = 'left')
i_ann_s2 = i_ann_s2.rename(columns = {'tradedate_next': 'impact_tdate'})

i_ann_s2 = i_ann_s2[['eiTime', 'title', 'ann_type_desc','ticker',  'impact_tdate']]
i_ann_s2 = i_ann_s2.sort_values(['ticker','impact_tdate'])
i_ann_s2 = i_ann_s2.reset_index(drop = True)





### get c

i_c = yu.get_sql('''select s_info_windcode as ticker, trade_Dt as datadate,
                 s_dq_close as c from wind_prod.dbo.ashareeodprices
                 where trade_dt>'20160101' ''')
i_c['datadate']  = pd.to_datetime(i_c['datadate'], format='%Y%m%d')


### abnml

i_abnml = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_abnormal_move.parquet')



### pastret

i_pastret = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet',
                            columns = ['ticker','datadate','twap1000_2c_bret','twap1000_2c_bret_t4w'])
i_pastret = i_pastret.sort_values(['ticker', 'datadate'])
i_pastret['twap1000_2c_bret_t1w'] = i_pastret.groupby('ticker').rolling(datetime.timedelta(days=7),on='datadate')['twap1000_2c_bret'].mean().values






#------------------------------------------------------------------------------
### combine （between start and end) 

icom = pd.merge_asof(i_sd, i_deal, by='ticker', on='datadate')
icom = icom.merge(i_abnml, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_pastret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_c, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])



### Idea 1: long
 2 weeks before the end

icom['days2end'] = (icom['end_date'] - icom['datadate']).dt.days


icom['sgnl_preend'] = np.nan
c1 = icom['days2end'].between(3, 14)
icom.loc[c1, 'sgnl_preend'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl_preend','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_preend','BarrRet_CLIP_USD+1d', static_data = i_sd) # -ve


### Idea 2: Long the whole start-2-end period

icom['sgnl_startend'] = np.nan
c1 = icom['days2end']>=3
icom.loc[c1, 'sgnl_startend'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl_startend','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_startend','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.35 / 0.27



### Idea 2.1: Long the whole start-2-end period, consider purchase_price
# this works 

icom['days2end'] = yu.get_tdate_cnt(icom['datadate'], icom['end_date'])
icom['daysSstart'] = yu.get_tdate_cnt(icom['start_date'], icom['datadate'])

icom['sgnl_startend'] = np.nan
c1 = icom['days2end'].between(2,10)
c2 = icom['purchasing_price'] > icom['c']*1.02
icom.loc[c1 & c2, 'sgnl_startend'] = 1

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_startend','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_startend','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.24 / 3.03 ###!!!


t1 = o_1.groupby('ticker')['pnl_ac'].sum().sort_values()
yu.ta_plot(icom, '600315.SH', 'sgnl_startend')



### Idea 2.2: Long the whole start-2-end period, consider purchase_price, o2c ret
# this works 

icom['days2end'] = yu.get_tdate_cnt(icom['datadate'], icom['end_date'])
icom['daysSstart'] = yu.get_tdate_cnt(icom['start_date'], icom['datadate'])

icom['o2c_t1w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t1w'].apply(yu.uniformed_rank)

icom['sgnl_3'] = np.nan
c1 = icom['o2c_t1w_rk'] < -0.8
c2 = icom['daysSstart'].notnull() & icom['days2end'].between(3,30)
icom.loc[c1 & c2, 'sgnl_3'] = 1
c3 = icom['days2end'].eq(2)
c4 = icom['purchasing_price'] < icom['c']*0.9
icom.loc[c3 | c4, 'sgnl_3'] = 0
icom['sgnl_3'] = icom.groupby('ticker')['sgnl_3'].ffill(limit=30)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['sgnl_3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_3','BarrRet_CLIP_USD+1d', static_data = i_sd
) # 3.12 / 2.94, 140k

t1 = o_1.groupby('ticker')['pnl_ac'].sum().sort_values()
yu.ta_plot(icom, '600966.SH', 'sgnl_3')



### Idea 3: Long the start-2-2W before period


icom['o2c_t1w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t1w'].apply(yu.uniformed_rank)

icom['sgnl_startend'] = np.nan
c1 = icom['days2end']>=7
c2 = icom['abnml_cnt_t1y'].lt(5) | icom['abnml_cnt_t1y'].isnull()
icom.loc[c1 & c2, 'sgnl_startend'] = 1
c1 = icom['o2c_t1w_rk']>0.8
icom.loc[c1, 'sgnl_startend'] = 0

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl_startend','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_startend','BarrRet_CLIP_USD+1d', static_data = i_sd) # 





#------------------------------------------------------------------------------
### combine (use raw ann)

i_ann_init = i_ann_s2.rename(columns = {'impact_tdate': 'datadate'})
i_ann_init['title'] = i_ann_init['title'].fillna('@')
i_ann_init.loc[i_ann_init['title'].str.contains('要约收购报告'), 'flg_init_notice'] = 1
i_ann_init = i_ann_init.drop_duplicates(subset= ['ticker','datadate'], keep = 'first')

i_ann_1st = i_ann_s2.rename(columns = {'impact_tdate': 'datadate'})
i_ann_1st['title'] = i_ann_1st['title'].fillna('@')
i_ann_1st.loc[i_ann_1st['title'].str.contains('要约收购.*第一次'), 'flg_1st_notice'] = 1
i_ann_1st = i_ann_1st.drop_duplicates(subset= ['ticker','datadate'], keep = 'first')

i_ann_2nd = i_ann_s2.rename(columns = {'impact_tdate': 'datadate'})
i_ann_2nd['title'] = i_ann_2nd['title'].fillna('@')
i_ann_2nd.loc[i_ann_2nd['title'].str.contains('要约收购.*第二次'), 'flg_2nd_notice'] = 1
i_ann_2nd = i_ann_2nd.drop_duplicates(subset= ['ticker','datadate'], keep = 'first')

i_ann_3rd = i_ann_s2.rename(columns = {'impact_tdate': 'datadate'})
i_ann_3rd['title'] = i_ann_3rd['title'].fillna('@')
i_ann_3rd.loc[i_ann_3rd['title'].str.contains('要约收购.*第三次'), 'flg_3rd_notice'] = 1
i_ann_3rd = i_ann_3rd.drop_duplicates(subset= ['ticker','datadate'], keep = 'first')



icom = i_sd.merge(i_ann_init, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_ann_1st, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_ann_2nd, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_ann_3rd, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])




### viz

icom['viz'] = np.nan
icom.loc[icom['flg_1st_notice']==1, 'viz'] = 1
icom.loc[icom['flg_2nd_notice']==1, 'viz'] = 2
icom.loc[icom['flg_3rd_not
ice']==1, 'viz'] = 3

tk = icom[icom['viz'].notnull()]['ticker'].unique().tolist()
import random

yu.ta_plot(icom, random.choice(tk), 'flg_1st_notice','viz')




### init - 2nd

icom['sgnl_1'] = np.nan
icom.loc[icom['flg_init_notice'].eq(1),'sgnl_1'] = 1
icom.loc[icom['flg_2nd_notice'].eq(1),'sgnl_1'] = 0

icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit = 100)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd) 


### 1st - 2nd

icom['flg_2nd_notice_3d'] = icom.groupby('ticker')['flg_2nd_notice'].shift(3)

icom['sgnl_1'] = np.nan
icom.loc[icom['flg_1st_notice'].eq(1),'sgnl_1'] = 1
icom.loc[icom['flg_2nd_notice_3d'].eq(1),'sgnl_1'] = 0

icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit = 100)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd) 


### 2nd - end


icom['flg_2nd_notice_1d'] = icom.groupby('ticker')['flg_2nd_notice'].shift(1)
icom['flg_3rd_notice_3d'] = icom.groupby('ticker')['flg_3rd_notice'].shift(3)

icom['sgnl_1'] = np.nan
icom.loc[icom['flg_2nd_notice_1d'].eq(1),'sgnl_1'] = 1
icom.loc[icom['flg_3rd_notice_3d'].eq(1),'sgnl_1'] = 0

icom['sgnl_1'] = icom.groupby('ticker')['sgnl_1'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl_1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_1','BarrRet_CLIP_USD+1d', static_data = i_sd) 

o_1.groupby('ticker')['pnl_ac'].sum().sort_values()
yu.ta_plot(icom, '000935.SZ', 'sgnl_1')

