﻿#$%^&* ciis_l2_trade_newfiles_daily.sh #$%^&*
#!/bin/bash
datestr=$(TZ=Asia/Shanghai date -d "1 day ago"  +%Y%m%d)
$HOME/q/l64/q /export/datadev2/Data/SHH/scripts/ciis_l2_trade_newfiles_daily.q $datestr

