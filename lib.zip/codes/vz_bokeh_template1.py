﻿#$%^&* vz_bokeh_template1.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri May 29 17:20:58 2020

@author: thzhang
"""
import bokeh

import numpy as np

from bokeh.layouts import gridplot
from bokeh.plotting import figure, output_file, show



data = o1['cumpnl_tk']['DXCM']

p1 = figure(x_axis_type="datetime", plot_width = 1600, plot_height = 400)
p1.grid.grid_line_alpha=0.3
p1.xaxis.axis_label = 'Date'

p1.line(data.index, data.values, color='#A6CEE3')
p1.legend.location = "top_left"

show(p1)  # open a browser





import numpy as np

from bokeh.io import show
from bokeh.layouts import column
from bokeh.models import ColumnDataSource, RangeTool
from bokeh.plotting import figure


dates = o1['cumpnl_tk']['DXCM'].index
source = ColumnDataSource(data=dict(date=dates, close=o1['cumpnl_tk']['DXCM'].values))

p_main = figure(plot_height=400, plot_width=1600, tools="xpan", toolbar_location=None,
           x_axis_type="datetime", x_axis_location="below",
           background_fill_color="#efefef",x_range=(dates[0], dates[-1]))

p_main.line('date', 'close', source=source)
p_main.yaxis.axis_label = 'Price'

slider = figure(plot_height=50, plot_width=1600, y_range=p_main.y_range,
                x_axis_type="datetime", y_axis_type=None,
                tools="", toolbar_location=None, background_fill_color="#efefef")

slider_range_tool = RangeTool(x_range=p_main.x_range)
slider_range_tool.overlay.fill_color = "navy"
slider_range_tool.overlay.fill_alpha = 0.2

slider.line('date', 'close', source=source)
slider.ygrid.grid_line_color = None
slider.add_tools(slider_range_tool)
slider.toolbar.active_multi = slider_range_tool

show(column(p_main, slider))



'''
everything here should be cdate x tk
input_dict = {'date':[],
            'price' : o1[''],\}
