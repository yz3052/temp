﻿#$%^&* pL2_cn_orderbook_02.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  4 09:51:41 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine


# This studies large distant orders on order book 
# next step: I need to exclude ask orders at limit-up. 
#            Also need to see how far large orders are near market close.


### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])



### order book metrics

i_odbk2 = yu.get_q("get `:/export/datadev/Data/SHSZ/ORDER_metrics/orderbook_metrics_batch1_02")

i_odbk2['code'] = i_odbk2['code'].str.decode('utf8')
c_sh = i_odbk2['code'].str[0].isin(['6'])
c_sz = i_odbk2['code'].str[0].isin(['0','3'])
i_odbk2.loc[c_sh, 'ticker'] = i_odbk2.loc[c_sh, 'code'] + '.SH'
i_odbk2.loc[c_sz, 'ticker'] = i_odbk2.loc[c_sz, 'code'] + '.SZ'
i_odbk2['datadate'] = pd.to_datetime(i_odbk2['date'])
i_odbk2 = i_odbk2.sort_values(['ticker', 'datadate'])




### combine

icom = i_sd.merge(i_odbk2, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']

icom['ask_1st_highestV_perP_highV_avgp_dv_p'] = icom['ask_1st_highestV_perP_highV_avgp_dv_p'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
icom['ask_1st_highestV_perP_highV_avgp_dv_p'] = icom['ask_1st_highestV_perP_highV_avgp_dv_p'].replace(1,np.nan)
icom['ask_1st_highestV_perP_highV_avgp_dv_p_bk'] = icom.groupby('datadate')['ask_1st_highestV_perP_highV_avgp_dv_p'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask_1st_highestV_perP_highV_avgp_dv_p_orth'] = icom.groupby('datadate')[COLS+['ask_1st_highestV_perP_highV_avgp_dv_p']].apply(lambda x: yu.orthogonalize_cn(x['ask_1st_highestV_perP_highV_avgp_dv_p'], x[COLS])).values
icom['ask_1st_highestV_perP_highV_avgp_dv_p_orth_bk'] = icom.groupby('datadate')['ask_1st_highestV_perP_highV_avgp_dv_p_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ask_1st_highestV_perP_highV_avgp_dv_p_bk'], 'ask_1st_highestV_perP_highV_avgp_dv_p')
# yu.create_cn_3x3(icom, ['ask_1st_highestV_perP_highV_avgp_dv_p_orth_bk'], 'ask_1st_highestV_perP_highV_avgp_dv_p_orth')

icom['ask_1st_highestV_perP_highV_minp_dv_p'] = icom['ask_1st_highestV_perP_highV_minp_dv_p'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
icom['ask_1st_highest
V_perP_highV_minp_dv_p'] = icom['ask_1st_highestV_perP_highV_minp_dv_p'].replace(1, np.nan)
icom['ask_1st_highestV_perP_highV_minp_dv_p_bk'] = icom.groupby('datadate')['ask_1st_highestV_perP_highV_minp_dv_p'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask_1st_highestV_perP_highV_minp_dv_p_orth'] = icom.groupby('datadate')[COLS+['ask_1st_highestV_perP_highV_minp_dv_p']].apply(lambda x: yu.orthogonalize_cn(x['ask_1st_highestV_perP_highV_minp_dv_p'], x[COLS])).values
icom['ask_1st_highestV_perP_highV_minp_dv_p_orth_bk'] = icom.groupby('datadate')['ask_1st_highestV_perP_highV_minp_dv_p_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask_1st_highestV_perP_highV_minp_dv_p_orth_t5d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=7),on='datadate')['ask_1st_highestV_perP_highV_minp_dv_p_orth'].mean().values
icom['ask_1st_highestV_perP_highV_minp_dv_p_orth_t5d_bk'] = icom.groupby('datadate')['ask_1st_highestV_perP_highV_minp_dv_p_orth_t5d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask_1st_highestV_perP_highV_minp_dv_p_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ask_1st_highestV_perP_highV_minp_dv_p_orth'].mean().values
icom['ask_1st_highestV_perP_highV_minp_dv_p_orth_t20d_bk'] = icom.groupby('datadate')['ask_1st_highestV_perP_highV_minp_dv_p_orth_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['ask_1st_highestV_perP_highV_minp_dv_p_bk'], 'ask_1st_highestV_perP_highV_minp_dv_p')
#yu.create_cn_3x3(icom, ['ask_1st_highestV_perP_highV_minp_dv_p_orth_bk'], 'ask_1st_highestV_perP_highV_minp_dv_p_orth')
# mono +3 -3, the others worse than this 
yu.create_cn_3x3(icom, ['ask_1st_highestV_perP_highV_minp_dv_p_orth_t5d_bk'], 'ask_1st_highestV_perP_highV_minp_dv_p_orth_t5d')
# mono +2 -4.5
yu.create_cn_3x3(icom, ['ask_1st_highestV_perP_highV_minp_dv_p_orth_t20d_bk'], 'ask_1st_highestV_perP_highV_minp_dv_p_orth_t20d')
# mono +1 +2 -5


icom['ask_1st_highestV_perP_highV_minp_dv_p_orth_sgnl'] = - icom.groupby('datadate')['ask_1st_highestV_perP_highV_minp_dv_p_orth'].apply(yu.uniformed_rank).values
icom['ask_1st_highestV_perP_highV_minp_dv_p_orth_t5d_sgnl'] = - icom.groupby('datadate')['ask_1st_highestV_perP_highV_minp_dv_p_orth_t5d'].apply(yu.uniformed_rank).values
icom['ask_1st_highestV_perP_highV_minp_dv_p_orth_t20d_sgnl'] = - icom.groupby('datadate')['ask_1st_highestV_perP_highV_minp_dv_p_orth_t20d'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['data
date']<='2020-12-31')].\
            dropna(subset=['ask_1st_highestV_perP_highV_minp_dv_p_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_1st_highestV_perP_highV_minp_dv_p_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd)
# 2.38/-15.11
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ask_1st_highestV_perP_highV_minp_dv_p_orth_t5d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_1st_highestV_perP_highV_minp_dv_p_orth_t5d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd)
# 2.22/-2.29
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ask_1st_highestV_perP_highV_minp_dv_p_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_1st_highestV_perP_highV_minp_dv_p_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd)
#1.75/0.45



# to sql
icom['Ticker'] = icom['ticker'].str[:6]
icom['DataDate'] = icom['datadate']
param_engine = create_engine('mssql+pyodbc://summitsqldb_cndbdev') 
icom[['Ticker','DataDate','ask_1st_highestV_perP_highV_minp_dv_p_orth_sgnl']].to_sql('F001_ODBK_largeDistantAsk_LS_1D', param_engine , index = False, if_exists = 'replace', chunksize = 10000)


