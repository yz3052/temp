﻿#$%^&* pCNINFO_unlock_idds.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Apr  8 09:54:09 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime




### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])



### get adjf

i_adjf = yu.get_sql('''select trade_dt as datadate, s_info_windcode as ticker,
                    S_DQ_ADJFACTOR as adjf 
                    from wind.dbo.ashareeodprices''')
i_adjf['datadate'] = pd.to_datetime(i_adjf['datadate'], format = '%Y%m%d')
i_adjf = i_adjf.sort_values('datadate')

### get adjf

i_adjf = yu.get_sql('''select trade_dt as datadate, s_info_windcode as ticker,
                    S_DQ_ADJFACTOR as adjf 
                    from wind_prod.dbo.ashareeodprices''')
i_adjf['datadate'] = pd.to_datetime(i_adjf['datadate'], format = '%Y%m%d')
i_adjf = i_adjf.sort_values('datadate')


### calendar
i_cal = [] 
i_ticker = i_adjf['ticker'].unique().tolist()
for dt in pd.date_range(start='2014-01-01',end='2021-12-31'):
    print('.', end='')
    t_cal = pd.DataFrame({'datadate':dt, 'ticker':i_ticker})
    i_cal.append(t_cal)
i_cal = pd.concat(i_cal, axis = 0)
i_cal = i_cal.sort_vaues('datadate')

# adjf on each calendar date
i_adjf = pd.merge_asof(i_cal, i_adjf, on = 'datadate', by = 'ticker')


### get idds unlock data
# ann_dt 原截止日期（上市流通方案公布日期）, 公告日期
# frcst_unlock_dt 预计解除限售日期
# frcst_unlock_shares 预计解除限售数量
# frcst_unlock_pct 预计解除限售比例
# actual_unlock_dt 实际解除限售日期
# actual_unlock_pct 实际解除限售比例
# unlock_reason 限售原因
# ts_mod 修改时间
# ts_rec 录入时间



i_org = yu.get_sql_idds('''select distinct ob_secid_0007 as org_id, ob_seccode_0007 as ticker, 
                           F003V_0007 as security_type  
                           FROM [IDDS].[dbo].[TB_PUBLIC_0007] ''')
i_org = i_org[i_org['security_type']=='A股']
i_org = i_org[i_org['ticker'].str[0].isin(['0','3','6'])]
c_sh = i_org['ticker'].str[0].isin(['6'])
c_sz = i_org['ticker'].str[0].isin(['0', '3'])
i_org.loc[c_sh, 'ticker'] = i_org.loc[c_sh, 'ticker'] + '.SH'
i_org.loc[c_sz, 'ticker'] = i_org.loc[c_sz, 'ticker'] + '.SZ'
i_org = i_org[['org_id', 'ticker']]

i_unlock = yu.get_sql_idds('''select ob_orgid_0362 as org_id, ob_enddate_0362 as ann_dt,
                               f002d_0362 as frcst_unlock_dt, f003n_0362 as frcst_unlock_shares,
                               f006n_0362 as frcst_unlock_pct, f007d_0362 as actual_unlock_dt,
                             
  f009n_0362 as actual_unlock_pct, f004V_0362 as unlock_reason,
                               ob_modtime_0362 as ts_mod, ob_rectime_0362 as ts_rec 
                               FROM [IDDS].[dbo].[TB_COMPANY_0362] ''')
i_unlock = i_unlock.merge(i_org, on = ['org_id'], how = 'left')

i_unlock = i_unlock[i_unlock['ticker'].notnull()]
i_unlock['ann_dt'] = pd.to_datetime(i_unlock['ann_dt'].dt.date)
i_unlock = i_unlock[i_unlock['frcst_unlock_dt']>='2015-06-01']

i_unlock = i_unlock.sort_values(['ann_dt'])
i_unlock = pd.merge_asof(i_unlock, i_adjf.rename(columns = {'datadate':'ann_dt'}), on = 'ann_dt', by = 'ticker')
i_unlock['adjf'] = i_unlock['adjf'].fillna(1)






### get longer-term adv

i_adv = pw.get_wind_adv()


### Calculate distance to next 2 unlocks, PIT
# Key: for each issuance, find out its announcement date, and forecasted unlock date


i_unlock_metrics = []

for dt in pd.date_range(start='2016-01-01', end='2020-12-31'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    t_unlock = i_unlock[(i_unlock['ann_dt']<=dt)\
                        &(i_unlock['frcst_unlock_dt']>dt+pd.to_timedelta('3 days'))\
                        &(i_unlock['frcst_unlock_dt']<dt+pd.to_timedelta('120 days'))]
    
    t_adjf = i_adjf[i_adjf['datadate']==dt]
    t_adjf = t_adjf.rename(columns = {'adjf':'adjf_recent'})
    t_unlock = t_unlock.merge(t_adjf, on = ['ticker'], how = 'left')
    
    t_unlock = t_unlock.groupby(['ticker','frcst_unlock_dt'])[['frcst_unlock_shares','adjf','adjf_recent']].apply(lambda x: x['frcst_unlock_shares'].divide(x['adjf']).multiply(x['adjf_recent']).sum())
    t_unlock = t_unlock.reset_index()
    t_unlock = t_unlock.rename(columns={0: 'frcst_unlock_shares'})
    
    t_unlock = t_unlock.sort_values(['ticker','frcst_unlock_dt'])
    t_unlock = t_unlock.groupby('ticker').head(2)
    t_unlock['unlock_batch_no'] = t_unlock.groupby('ticker')['frcst_unlock_dt'].cumcount()
    t_unlock['datadate'] = dt
    
    t_unlock_n1 = t_unlock[t_unlock['unlock_batch_no']==0]
    t_unlock_n1['d2unlock_n1'] = (t_unlock_n1['frcst_unlock_dt']-t_unlock_n1['datadate']).dt.days
    t_unlock_n1 = t_unlock_n1.rename(columns={'frcst_unlock_shares':'frcst_unlock_shares_n1'})
    
    t_unlock_n2 = t_unlock[t_unlock['unlock_batch_no']==1]
    t_unlock_n2['d2unlock_n2'] = (t_unlock_n2['frcst_unlock_dt']-t_unlock_n2['datadate']).dt.days
    t_unlock_n2 = t_unlock_n2.rename(columns={'frcst_unlock_shares':'frcst_unlock_shares_n2'})
    
    o_unlock = t_unlock_n1[['tick
er','datadate','d2unlock_n1','frcst_unlock_shares_n1']]\
               .merge(t_unlock_n2[['ticker','datadate','d2unlock_n2','frcst_unlock_shares_n2']],
                      on=['ticker','datadate'], how = 'left')
    i_unlock_metrics.append(o_unlock)
    

i_unlock_metrics = pd.concat(i_unlock_metrics, axis = 0)    



### combine

HOLD = 60

icom = i_sd.merge(i_unlock_metrics, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_adv, on = ['ticker', 'datadate'], how = 'left')

icom['unlock1_dv_adv'] = icom['frcst_unlock_shares_n1'].divide(icom['adv_t130d'])
icom.loc[icom['unlock1_dv_adv']>1, 'unlock1_dv_adv'] = 1
icom['unlock2_dv_adv'] = icom['frcst_unlock_shares_n2'].divide(icom['adv_t130d'])
icom.loc[icom['unlock2_dv_adv']>1, 'unlock2_dv_adv'] = 1

c1 = icom['d2unlock_n1'].between(3, HOLD)
icom['unlock1_dv_v_sgnl'] = np.nan
icom.loc[c1, 'unlock1_dv_v_sgnl'] = - icom.loc[c1, 'unlock1_dv_adv']*(HOLD - icom['d2unlock_n1'])/HOLD

c1 = icom['d2unlock_n2'].between(3, HOLD)
icom['unlock2_dv_v_sgnl'] = np.nan
icom.loc[c1, 'unlock2_dv_v_sgnl'] = - icom.loc[c1, 'unlock2_dv_adv']*(HOLD - icom['d2unlock_n1'])/HOLD

icom['unlock12_dv_v_sgnl1'] = icom[['unlock1_dv_v_sgnl','unlock2_dv_v_sgnl']].min(axis=1)


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['unlock12_dv_v_sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'unlock12_dv_v_sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) 


# 30d holding 3.07/2.12, 0.8e7
# 60d holding 2.94/2.2, 1.25e7
# 90d holding 2.48/1.82, 1.25e7

# 60d holding, increasing position: 3.5/2.63, 0.8e7
# 90d holding, increasing position: 3.24/2.51, 1.0e7



i_forecast_unlock_raw = pd.read_parquet(r'S:\Data\China Data Hunt\cache\cninfo_forecast_unlock_date.parquet')
'''
ORGNAME	机构名称			
SECCODE	证券代码			
SECNAME	证券简称			
DECLAREDATE	公告日期			
F001V	股东名称	varchar		
F002D	预计解除限售日期	date		
F003N	预计解除限售数量	decimal		单位：股
F005V	限售原因编码	varchar		
F006N	序号	decimal		序号 用于区分同一天存在同一股东多个受限股份流通上市
F004V	限售原因	varchar		通过p_public0006可获取，总类编码为100
'''
i_forecast_unlock_raw = i_forecast_unlock_raw[['F001V','F002D','F003N','F004V','ticker','release_date']]
i_forecast_unlock_raw = i_forecast_unlock_raw.\
                        rename(columns={'F002D':'frcst_date','F003N':'unlock_shares',
                                        'F004V':'unlock_reason','F001V':'shareholder'})
t1 = i_forecast_unlock_raw[i_forecast_unlock_raw['ticker']=='600172.SH']

