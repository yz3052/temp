﻿#$%^&* cninfo_l2_order_prod.sh #$%^&*
#!/bin/bash
datestr=$(TZ=Asia/Shanghai date -d "1 day ago"  +%Y%m%d)
$HOME/q/l64/q /export/dataprod2/CNL2/scripts/cninfo_l2_order_prod.q $datestr

