﻿#$%^&* featurepool_cn_apb_prod2.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  5 16:48:33 2022

@author: thzhang
"""

import sys
import os
import pandas as pd
import numpy as np

import datetime

from sqlalchemy import create_engine
import urllib


# this generates 1-D descriptors 
# to be scheduled on crontab
# parquet file name is T-1d


### SQL create 
# create table F001_APB_FORMAT (Ticker varchar(max), [DataDate] datetime, [T-1d] datetime, descriptor float)



#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------

source_path = '/export/dataprod2/CNL2/SHSZ/q_trod_apb'

conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))




#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------

q_dates = os.listdir(source_path)
q_dates = [i.replace('.txt','') for i in q_dates]


existing_dates = pd.read_sql('''select distinct [T-1d] from CNDBDEV.dbo.F001_APB_FORMAT''', conn)
if len(existing_dates) > 0:
    existing_dates['T-1d'] = existing_dates['T-1d'].dt.strftime('%Y.%m.%d')
    existing_dates = existing_dates['T-1d'].tolist()
else: 
    existing_dates = []

query_dates = list(set(q_dates).difference(set(existing_dates)))





#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------

i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()



#------------------------------------------------------------------------------
### calculate descriptors
#------------------------------------------------------------------------------

for f in query_dates:
    
    # date string
    
    t_1d_str = f.replace('.','')
    
    # get q query results
    
    i_q = pd.read_csv(os.path.join(source_path, f+'.txt'), sep = '|', )    
    i_q = i_q.rename(columns = {'code': 'Ticker', 'date': 'T-1d'})
    i_q['Ticker'] = i_
q['Ticker'].astype(int).astype(str).str.zfill(6)
    i_q['T-1d'] = pd.to_datetime(i_q['T-1d'])    
    
    # get twap
    
    i_twap = pd.read_sql('''select Ticker, AVG(PV/Volume) as twap 
                         FROM [CNDBPROD].[dbo].[TRTH_CN_TRADE_{0}] 
                         where hour*100+min>=930 and hour*100+min<=1500 
                         and volume!=0 
                         and DataDate = '{1}'
                         group by datadate, ticker
                         '''.format(t_1d_str[2:4], t_1d_str), conn)
    i_twap['Ticker'] = i_twap['Ticker'].str[:6]
    
    # combine
    
    icom = i_q.merge(i_twap, on = ['Ticker'], how = 'left')
    icom = icom.merge(i_cal, on = ['T-1d'], how = 'left')
    
    icom['descriptor'] = icom['twap'].divide(icom['odB_pTRD_vwap'])    
    icom['descriptor'] = icom['descriptor'].replace(0, np.nan).replace(np.inf, np.nan).replace(-np.inf, np.nan)
    icom['descriptor'] = np.log(icom['descriptor'])
   
    
    icom[['Ticker', 'DataDate', 'T-1d', 'descriptor']].to_sql('F001_APB_FORMAT', 
                                                                   index=False,
                                                                   if_exists = 'append',
                                                                   con = conn)
    



