﻿#$%^&* pCorpAct_cn_explore.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat May  7 15:47:00 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime


# split has no impact on stock returns
# this is a quick exploration 


### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])


### barra return

i_bret = i_sd[['ticker', 'datadate', 'BarrRet_SRISK_USD+0d']]
i_bret = i_bret.rename(columns = {'BarrRet_SRISK_USD+0d': 'bret'})
i_bret = i_bret.sort_values(['ticker', 'datadate'])

i_bret['bret_t5d'] = i_bret.groupby('ticker').rolling(datetime.timedelta(days=7),on='datadate',min_periods=3)['bret'].mean().values
i_bret['bret_t5d_1d'] = i_bret.groupby('ticker')['bret_t5d'].shift()

i_bret['bret_n5d'] = i_bret.groupby('ticker')['bret'].apply(lambda x: (x+x.shift(-1)+x.shift(-2)+x.shift(-3)+x.shift(-4))/5)
i_bret['bret_n5d_p1d'] = i_bret.groupby('ticker')['bret'].apply(lambda x: (x.shift(-1)+x.shift(-2)+x.shift(-3)+x.shift(-4)+x.shift(-5))/5)

i_bret_s2 = i_bret.drop(columns = ['bret'])
i_bret_s2 = i_bret_s2.sort_values('datadate')


### price

i_px = yu.get_sql_prod('''select s_info_windcode as ticker, trade_dt as datadate,
                                 s_dq_close as c  
                          from wind_prod.dbo.ashareeodprices 
                          where trade_dt >= '20160101'  ''')
i_px['datadate'] = pd.to_datetime(i_px['datadate'], format = '%Y%m%d')
i_px = i_px.sort_values('datadate')


### dividend

#i_xd = yu.get_sql("select * from wind.dbo.AShareEXRightDividendRecord")
#
#i_xd = i_xd[i_xd['EX_TYPE']=='分红']
#i_xd = i_xd.rename(columns = {'S_INFO_WINDCODE':'ticker'})
#i_xd['EX_DATE'] = pd.to_datetime(i_xd['EX_DATE'], format = '%Y%m%d')
#
#i_xd_more_shares = i_xd[(i_xd['BONUS_SHARE_RATIO']>0)|(i_xd['CONVERSED_RATIO']>0)]
#i_xd_more_shares['dilution_factor'] = i_xd_more_shares['BONUS_SHARE_RATIO'] + i_xd_more_shares['CONVERSED_RATIO']
#i_xd_more_shares['datadate'] = i_xd_more_shares['EX_DATE']


i_dvd = yu.get_sql('''select S_INFO_WINDCODE as ticker, stk_dvd_per_sh, cash_dvd_per_sh_pre_tax as cash_dvd_per_sh, 
                      EQY_RECORD_DT as dengji_dt, ex_dt, DVD_PAYOUT_DT as dvd_pay_dt, S_DIV_PRELANDATE as plan_dt, 
                      dvd_ann_dt, report_period 
                      from wind.dbo.AShareDividend 
                      where (report_period >= '20160601') and (report_period<='20201231') 
                      and (S
TK_DVD_PER_SH + CASH_DVD_PER_SH_PRE_TAX>0) 
                      order by s_info_windcode, report_period ''')

for c in ['dengji_dt', 'ex_dt', 'dvd_pay_dt', 'plan_dt', 'dvd_ann_dt']:
    i_dvd.loc[i_dvd[c].notnull(), c] = pd.to_datetime(i_dvd.loc[i_dvd[c].notnull(), c], format='%Y%m%d')
    i_dvd[c] = pd.to_datetime(i_dvd[c])
    i_dvd[c] = i_dvd[c].fillna(pd.to_datetime('2050-01-01'))


i_dvd = i_dvd.sort_values('dengji_dt')
i_dvd_s2 = pd.merge_asof(i_dvd, i_bret_s2, by = 'ticker', left_on = 'dengji_dt', right_on = 'datadate', tolerance =pd.to_timedelta('2 days'))
i_dvd_s2 = i_dvd_s2.rename(columns = {'bret_t5d':'dengji_bret_t5d', 
                                      'bret_t5d_1d':'dengji_bret_t5d_1d', 
                                      'bret_n5d':'dengji_bret_n5d', 
                                      'bret_n5d_p1d':'dengji_bret_n5d_p1d'})
i_dvd_s2 = i_dvd_s2.drop(columns = 'datadate')
i_dvd_s2 = i_dvd_s2.sort_values('ex_dt')
i_dvd_s2 = pd.merge_asof(i_dvd_s2, i_bret_s2, by = 'ticker', left_on = 'ex_dt', right_on = 'datadate', tolerance =pd.to_timedelta('2 days'))
i_dvd_s2 = i_dvd_s2.rename(columns = {'bret_t5d':'ex_bret_t5d', 
                                      'bret_t5d_1d':'ex_bret_t5d_1d', 
                                      'bret_n5d':'ex_bret_n5d', 
                                      'bret_n5d_p1d':'ex_bret_n5d_p1d'})
i_dvd_s2 = i_dvd_s2.drop(columns = 'datadate')
i_dvd_s2 = i_dvd_s2.sort_values('plan_dt')
i_dvd_s2 = pd.merge_asof(i_dvd_s2, i_bret_s2, by = 'ticker', left_on = 'plan_dt', right_on = 'datadate', tolerance =pd.to_timedelta('2 days'))
i_dvd_s2 = i_dvd_s2.rename(columns = {'bret_t5d':'plan_bret_t5d', 
                                      'bret_t5d_1d':'plan_bret_t5d_1d', 
                                      'bret_n5d':'plan_bret_n5d', 
                                      'bret_n5d_p1d':'plan_bret_n5d_p1d'})
i_dvd_s2 = i_dvd_s2.drop(columns = 'datadate')
i_dvd_s2 = i_dvd_s2.sort_values('dvd_ann_dt')
i_dvd_s2 = pd.merge_asof(i_dvd_s2, i_bret_s2, by = 'ticker', left_on = 'dvd_ann_dt', right_on = 'datadate', tolerance =pd.to_timedelta('2 days'))
i_dvd_s2 = i_dvd_s2.rename(columns = {'bret_t5d':'ann_bret_t5d', 
                                      'bret_t5d_1d':'ann_bret_t5d_1d', 
                                      'bret_n5d':'ann_bret_n5d', 
                                      'bret_n5d_p1d':'ann_bret_n5d_p1d'})
i_dvd_s2 = i_dvd_s2.drop(columns = 'datadate')
i_dvd_s2 = i_dvd_s2.sort_values('dvd_pay_dt')
i_dvd_s2 
= pd.merge_asof(i_dvd_s2, i_bret_s2, by = 'ticker', left_on = 'dvd_pay_dt', right_on = 'datadate', tolerance =pd.to_timedelta('2 days'))
i_dvd_s2 = i_dvd_s2.rename(columns = {'bret_t5d':'dvd_pay_bret_t5d', 
                                      'bret_t5d_1d':'dvd_pay_bret_t5d_1d', 
                                      'bret_n5d':'dvd_pay_bret_n5d', 
                                      'bret_n5d_p1d':'dvd_pay_bret_n5d_p1d'})
i_dvd_s2 = i_dvd_s2.drop(columns = 'datadate') 
i_dvd_s2 = pd.merge_asof(i_dvd_s2, i_px, by = 'ticker', left_on = 'dvd_pay_dt', right_on = 'datadate', tolerance =pd.to_timedelta('2 days'))
i_dvd_s2 = i_dvd_s2.drop(columns = 'datadate')
i_dvd_s2['dvd_ret'] = i_dvd_s2['cash_dvd_per_sh'].divide(i_dvd_s2['c'])


# summary stats
# best opportunity: before dengji date (higher dividend), after dengji, 5 days after ex, after plan


for c in [i for i in i_dvd_s2.columns.tolist() if '_bret_' in i]:
    print (c, end = ': ')
    print (i_dvd_s2[c].mean()/i_dvd_s2[c].std()*np.sqrt(i_dvd_s2[c].count()), end = ' ')
    t_dvd_s2 = i_dvd_s2[i_dvd_s2['dvd_ret']>0.01]
    print (t_dvd_s2[c].mean()/t_dvd_s2[c].std()*np.sqrt(t_dvd_s2[c].count()))
    



### combine for dengji ri


i_dvd_dengji = i_dvd_s2[['ticker','dengji_dt','dvd_ret']]
i_dvd_dengji = i_dvd_dengji[i_dvd_dengji['dvd_ret'].notnull()]
i_dvd_dengji['flg_dengji'] = 1
i_dvd_dengji.loc[i_dvd_dengji['dvd_ret']>=0.005, 'flg_dengji_highD'] = 1
i_dvd_dengji = i_dvd_dengji.rename(columns = {'dengji_dt':'datadate'})

icom_dj = i_sd.merge(i_dvd_dengji, on = ['ticker', 'datadate'], how = 'left')
icom_dj = icom_dj.sort_values(['ticker', 'datadate'])

icom_dj['flg_pre_dengji'] = icom_dj.groupby('ticker')['flg_dengji'].bfill(limit=3)
icom_dj.loc[icom_dj['flg_dengji']==1, 'flg_pre_dengji'] = np.nan
icom_dj['flg_pre_dengji_exdj']  = icom_dj.groupby('ticker')['flg_pre_dengji'].shift(-1)
icom_dj['flg_post_dengji'] = icom_dj.groupby('ticker')['flg_dengji'].ffill(limit=5)
icom_dj.loc[icom_dj['flg_dengji']==1, 'flg_post_dengji'] = np.nan

icom_dj['flg_pre_dengji_highD'] = icom_dj.groupby('ticker')['flg_dengji_highD'].bfill(limit=5)
icom_dj.loc[icom_dj['flg_dengji_highD']==1, 'flg_pre_dengji_highD'] = np.nan
icom_dj['flg_post_dengji_highD'] = icom_dj.groupby('ticker')['flg_dengji_highD'].ffill(limit=5)
icom_dj.loc[icom_dj['flg_dengji_highD']==1, 'flg_post_dengji_highD'] = np.nan


# pre dengji

o_1 = yu.bt_cn_15(icom_dj[(icom_dj['datadate']<='2020-12-31')].\
            dropna(subset=['flg_pre_dengji','BarrRet
_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_pre_dengji','BarrRet_CLIP_USD+1d', static_data = i_sd) 

o_1 = yu.bt_cn_15(icom_dj[(icom_dj['datadate']<='2020-12-31')].\
            dropna(subset=['flg_pre_dengji','RawRet_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_pre_dengji','RawRet_USD+1d', static_data = i_sd) 

o_1 = yu.bt_cn_15(icom_dj[(icom_dj['datadate']<='2020-12-31')].\
            dropna(subset=['flg_pre_dengji_exdj','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_pre_dengji_exdj','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.56 / 1.49



o_1 = yu.bt_cn_15(icom_dj[(icom_dj['datadate']<='2020-12-31')].\
            dropna(subset=['flg_pre_dengji_highD','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_pre_dengji_highD','BarrRet_CLIP_USD+1d', static_data = i_sd) 

# post dengji

o_1 = yu.bt_cn_15(icom_dj[(icom_dj['datadate']<='2020-12-31')].\
            dropna(subset=['flg_post_dengji','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_post_dengji','BarrRet_CLIP_USD+1d', static_data = i_sd) 



yu.explore(icom_dj, 'flg_pre_dengji')
o_1.groupby('ticker')['pnl_ac'].sum().sort_values()
t2 = o_1[o_1.ticker=='600703.SH']
yu.plot_sgnl('002458.SZ')



### combine 

icom = i_sd.merge(i_xd_more_shares, on = ['ticker', 'datadate'], how = 'left')

icom['test'] = np.nan
icom.loc[icom['dilution_factor']>0.5, 'test'] = -1
icom['test'] = icom.groupby('ticker')['test'].ffill(limit = 20)

yu.create_cn_decay(icom, 'test') # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['test','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test','BarrRet_CLIP_USD+1d', static_data = i_sd) 




# split -> rally 
