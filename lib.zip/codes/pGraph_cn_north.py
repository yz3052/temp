﻿#$%^&* pGraph_cn_north.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 23 06:23:29 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime




### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()


### holder data


