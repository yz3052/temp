﻿#$%^&* pFlow_cn_hk_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat Oct 30 11:19:42 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import datetime

# This studies  - northbound stock holding

# name conventions:
# % of portfolio held by hk within 300 uni: pct_within_HK300, pct_within_HKall
# % of company held by HK participants: pct_ofComp


### sd 

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['ticker', 'datadate'])
i_sd['V_t30d'] = i_sd.groupby('ticker').rolling(30)['V_l1d'].mean().values

i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d','WIND_V_l1d','PV_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','csi300_flag']]
i_sd_map_300 =i_sd_map[i_sd_map['csi300_flag']==1]


### get float SO

i_so = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate, 
               FLOAT_A_SHR_TODAY*10000 as so 
               from wind_prod.dbo.AShareEODDerivativeIndicator
               where trade_Dt > '20160101' ''')
i_so['datadate'] = pd.to_datetime(i_so['datadate'], format = '%Y%m%d')
i_so = i_so.sort_values('datadate')


i_so2 = yu.get_sql('''select ticker, [T-1d] as datadate, SO_l1d as so
               from [CNDBPROD].[dbo].[Static_Data_HC_GEM3L]
               where [T-1d] > '20160101' ''')
c_sh = i_so2['ticker'].str[0].isin(['6'])
c_sz = i_so2['ticker'].str[0].isin(['0','3'])
i_so2.loc[c_sh, 'ticker'] = i_so2.loc[c_sh, 'ticker'] + '.SH'
i_so2.loc[c_sz, 'ticker'] = i_so2.loc[c_sz, 'ticker'] + '.SZ'


### a-share uni

i_uni = yu.get_sql('''select ticker, datadate from cndbprod.dbo.UNIVERSE_ALL_CN_GEM3L
                   where datadate >= '2016-06-29' ''')
c_sh = i_uni['ticker'].str[0].isin(['6'])
c_sz = i_uni['ticker'].str[0].isin(['0','3'])
i_uni.loc[c_sh, 'ticker'] = i_uni.loc[c_sh, 'ticker'] + '.SH'
i_uni.loc[c_sz, 'ticker'] = i_uni.loc[c_sz, 'ticker'] + '.SZ'
i_uni = i_uni.sort_values(['ticker','datadate'])


### c
i_c = yu.get_sql('''select s_info_windcode as ticker, trade_Dt as datadate, s_dq_close as c  
                 from wind_prod.dbo.AShareEODPrices''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format = '%Y%m%d')


### ed
i_ed = pw.get_wind_ed_calendar_pit()

i_ed = yu.get_sql('''select datadate, ticker, ped, next_ed from [CNDBPROD]
.[dbo].[CNINFO_ED_SNAP]''')
c_sh = i_ed['ticker'].str[0].isin(['6'])
c_sz = i_ed['ticker'].str[0].isin(['0','3'])
i_ed.loc[c_sh, 'ticker'] = i_ed.loc[c_sh, 'ticker'] + '.SH'
i_ed.loc[c_sz, 'ticker'] = i_ed.loc[c_sz, 'ticker'] + '.SZ'
i_ed['cd2e'] = (i_ed['next_ed']-i_ed['datadate']).dt.days
i_ed['rpt_period'] = i_ed['ped'].dt.year*10 + i_ed['ped'].dt.month/3


### early ed
i_early_ed = yu.get_sql('''select stock_Code as ticker, report_year*10+report_period as rpt_period, declare_date 
                        from [CNDBDEV].[dbo].[fin_performance_forecast] ''')
c_sh = i_early_ed['ticker'].str[0].isin(['6'])
c_sz = i_early_ed['ticker'].str[0].isin(['0','3'])
i_early_ed.loc[c_sh, 'ticker'] = i_early_ed.loc[c_sh, 'ticker'] + '.SH'
i_early_ed.loc[c_sz, 'ticker'] = i_early_ed.loc[c_sz, 'ticker'] + '.SZ'
i_early_ed['rpt_period'] = pd.to_numeric(i_early_ed['rpt_period'])

i_ed = i_ed.merge(i_early_ed, on = ['ticker','rpt_period'], how = 'left')
i_ed.loc[i_ed['declare_date']>=i_ed['datadate'], 'flag_pre_ann'] = 1


### 中央结算系统持股量
# 根据hkex，分母为：已发行股份总数（AB股和其他非流通股份）

i_h = yu.get_sql('''
           select s_info_windcode as ticker, 
                   trade_dt as datadate,
                   s_quantity as sharesHeld_hk, 
                   s_ratio as pctOfComp_hk2 
           from wind_prod.dbo.SHSCChannelholdings 
           where s_info_windcode not like '%HK' 
           order by s_info_windcode, trade_dt ''')
i_h['datadate'] = pd.to_datetime(i_h['datadate'], format='%Y%m%d')

i_h = i_uni.merge(i_h, on = ['datadate', 'ticker'], how = 'left')
i_h = i_h.merge(i_so, on = ['datadate', 'ticker'], how = 'left')
i_h = i_h.merge(i_c, on = ['datadate', 'ticker'], how = 'left')

i_h['c'] = i_h.groupby('ticker')['c'].ffill()
i_h['sharesHeld_hk'] = i_h['sharesHeld_hk'].fillna(0)
i_h['pctOfComp_hk2'] = i_h['pctOfComp_hk2'].fillna(0)

t_daily_count = i_h.groupby('datadate')['sharesHeld_hk'].apply(lambda x: (x!=0).sum())
i_h.loc[i_h['datadate'].isin(t_daily_count[t_daily_count==0].index.tolist()), 'sharesHeld_hk'] = np.nan
i_h.loc[i_h['datadate'].isin(t_daily_count[t_daily_count==0].index.tolist()), 'pctOfComp_hk2'] = np.nan
i_h['sharesHeld_hk'] = i_h.groupby('ticker')['sharesHeld_hk'].ffill(limit = 5)
i_h['pctOfComp_hk2'] = i_h.groupby('ticker')['pctOfComp_hk2'].ffill(limit = 5)

i_h['pctOfComp_hk'] = i_h['sharesHeld_hk'].divide(i_h['so'])

i_h['pctOfComp_hk_df1d'] = i_h.groupby('ticker')['pctOfComp_hk'].apply(lambda x: x-x.shift()).values
i_h['pctOfComp_hk_df1d_allrk'] = i_h.gro
upby('datadate')['pctOfComp_hk_df1d'].apply(yu.uniformed_rank).values

i_h['pctOfComp_hk_df20d'] = i_h.groupby('ticker')['pctOfComp_hk'].apply(lambda x: x-x.shift(20))
i_h['pctOfComp_hk_df20d_ma20'] = i_h.groupby('ticker').rolling(20)['pctOfComp_hk_df20d'].mean().values
i_h['pctOfComp_hk_df20d_ma5'] = i_h.groupby('ticker').rolling(5)['pctOfComp_hk_df20d'].mean().values

i_h['pctOfComp_hk_df60d'] = i_h.groupby('ticker')['pctOfComp_hk'].apply(lambda x: x-x.shift(60)).values
i_h['pctOfComp_hk_df60d_ma20'] = i_h.groupby('ticker').rolling(20)['pctOfComp_hk_df60d'].mean().values
i_h['pctOfComp_hk_df60d_ma5'] = i_h.groupby('ticker').rolling(5)['pctOfComp_hk_df60d'].mean().values

i_h['pctOfComp_hk2_df20d'] = i_h.groupby('ticker')['pctOfComp_hk2'].apply(lambda x: x-x.shift(20)).values
i_h['pctOfComp_hk2_df20d_ma5'] = i_h.groupby('ticker').rolling(5)['pctOfComp_hk2_df20d'].mean().values

i_h['pctOfComp_hk2_df60d'] = i_h.groupby('ticker')['pctOfComp_hk2'].apply(lambda x: x-x.shift(60)).values
i_h['pctOfComp_hk2_df60d_ma5'] = i_h.groupby('ticker').rolling(5)['pctOfComp_hk2_df60d'].mean().values

i_h['sharesHeld_hk_df1d'] = i_h.groupby('ticker')['sharesHeld_hk'].apply(lambda x: x-x.shift()).values

i_h['dollarHeld_hk'] = i_h['sharesHeld_hk'].multiply(i_h['c'])
i_h['flowDollar_hk'] = i_h.groupby('ticker')['dollarHeld_hk'].apply(lambda x: x-x.shift()).values
i_h['flowOfComp_hk'] = i_h.groupby('ticker')['pctOfComp_hk'].apply(lambda x: x-x.shift()).values

i_h['pctOfHK'] = i_h.groupby('datadate')['dollarHeld_hk'].apply(lambda x: x/x.sum())



### 持股量（机构类型）

i_h_type = yu.get_sql('''
                      select * from wind_prod.dbo.HKShareAgencyHoldings
                      ''')
i_h_type['ticker'] = i_h_type['S_INFO_WINDCODE']
i_h_type['datadate'] = pd.to_datetime(i_h_type['TRADE_DT'], format='%Y%m%d')

### holding from brokers
# holder list: https://www.hkexnews.hk/sdw/search/partlist.aspx#

i_h_broker = yu.get_sql('''select s_info_windcode as ticker, s_holder_enddate as datadate, 
                      sum(s_holder_quantity) as b_shares 
                      from wind_prod.dbo.SHSCmechanismownership 
                      where (S_INFO_WINDCODE like '%SH' or S_INFO_WINDCODE like '%SZ') 
                          and s_holder_num like 'B%'
                      group by s_info_windcode, s_holder_enddate ''')
i_h_broker['datadate'] = pd.to_datetime(i_h_broker['datadate'], format='%Y%m%d')
i_h_broker = i_h_broker.sort_values(['ticker','datadate'])


### holding from BB



i_h_bb_raw = yu.get_sql('''select s_info_windcode as ticker, s_holder_enddate as datadate, 
                        sum(case when s_holder_num in ('B01451', 'B01161', 'B01274', 'B01110', 'B01491', 'B01224') then s_holder_quantity else 0 end) as sharesHeld_bb , 
                        sum(case when (s_holder_num not in ('B01451', 'B01161', 'B01274', 'B01110', 'B01491', 'B01224')) and (s_holder_num like 'B%') then s_holder_quantity else 0 end) as sharesHeld_bexb , 
                        sum(case when s_holder_num like 'C%' then s_holder_quantity else 0 end) as sharesHeld_c 
                    from wind_prod.dbo.SHSCmechanismownership 
                    where (S_INFO_WINDCODE like '%SH' or S_INFO_WINDCODE like '%SZ') 
                    group by s_info_windcode, s_holder_enddate ''')
i_h_bb_raw['datadate'] = pd.to_datetime(i_h_bb_raw['datadate'], format='%Y%m%d')

i_h_bb = i_h[i_h['datadate']>='2018-07-01'][['ticker','datadate']].merge(i_h_bb_raw, on = ['datadate', 'ticker'], how = 'left')
i_h_bb = i_h_bb.merge(i_c, on = ['datadate', 'ticker'], how = 'left')
i_h_bb = i_h_bb.merge(i_so, on = ['datadate', 'ticker'], how = 'left')

i_h_bb['c'] = i_h_bb.groupby('ticker')['c'].ffill()
i_h_bb['sharesHeld_bb'] = i_h_bb['sharesHeld_bb'].fillna(0)
i_h_bb['sharesHeld_bexb'] = i_h_bb['sharesHeld_bexb'].fillna(0)
i_h_bb['sharesHeld_c'] = i_h_bb['sharesHeld_c'].fillna(0)

t_daily_count = i_h_bb.groupby('datadate')['sharesHeld_bb'].apply(lambda x: (x!=0).sum())
i_h_bb.loc[i_h_bb['datadate'].isin(t_daily_count[t_daily_count==0].index.tolist()), 'sharesHeld_bb'] = np.nan
i_h_bb['sharesHeld_bb'] = i_h_bb.groupby('ticker')['sharesHeld_bb'].ffill(limit = 5)
t_daily_count = i_h_bb.groupby('datadate')['sharesHeld_bexb'].apply(lambda x: (x!=0).sum())
i_h_bb.loc[i_h_bb['datadate'].isin(t_daily_count[t_daily_count==0].index.tolist()), 'sharesHeld_bexb'] = np.nan
i_h_bb['sharesHeld_bexb'] = i_h_bb.groupby('ticker')['sharesHeld_bexb'].ffill(limit = 5)
t_daily_count = i_h_bb.groupby('datadate')['sharesHeld_c'].apply(lambda x: (x!=0).sum())
i_h_bb.loc[i_h_bb['datadate'].isin(t_daily_count[t_daily_count==0].index.tolist()), 'sharesHeld_c'] = np.nan
i_h_bb['sharesHeld_c'] = i_h_bb.groupby('ticker')['sharesHeld_c'].ffill(limit = 5)

i_h_bb['pctOfComp_bb'] = i_h_bb['sharesHeld_bb'].divide(i_h_bb['so'])
i_h_bb['flowOfComp_bb'] = i_h_bb.groupby('ticker')['pctOfComp_bb'].apply(lambda x: x-x.shift()).values
i_h_bb['flowOfComp_bb_t5d'] = i_h_bb.groupby('ticker').rolling(5)['flowOfComp_bb
'].sum().values
i_h_bb['flowOfComp_bb_t20d'] = i_h_bb.groupby('ticker').rolling(20)['flowOfComp_bb'].sum().values
i_h_bb['flowOfComp_bb_t60d'] = i_h_bb.groupby('ticker').rolling(60)['flowOfComp_bb'].sum().values

i_h_bb['dollarHeld_bb'] = i_h_bb['sharesHeld_bb'].multiply(i_h_bb['c'])
i_h_bb['flowDollar_bb'] = i_h_bb.groupby('ticker')['dollarHeld_bb'].apply(lambda x: x-x.shift()).values
i_h_bb['flowDollar_bb_t5d'] = i_h_bb.groupby('ticker').rolling(5)['flowDollar_bb'].sum().values
i_h_bb['flowDollar_bb_t20d'] = i_h_bb.groupby('ticker').rolling(20)['flowDollar_bb'].sum().values
i_h_bb['flowDollar_bb_t60d'] = i_h_bb.groupby('ticker').rolling(60)['flowDollar_bb'].sum().values

i_h_bb['pctOfComp_bexb'] = i_h_bb['sharesHeld_bexb'].divide(i_h_bb['so'])
i_h_bb['flowOfComp_bexb'] = i_h_bb.groupby('ticker')['pctOfComp_bexb'].apply(lambda x: x-x.shift()).values

i_h_bb['pctOfComp_c'] = i_h_bb['sharesHeld_c'].divide(i_h_bb['so'])
i_h_bb['flowOfComp_c'] = i_h_bb.groupby('ticker')['pctOfComp_c'].apply(lambda x: x-x.shift()).values

i_h_bb['dollarHeld_bexb'] = i_h_bb['sharesHeld_bexb'].multiply(i_h_bb['c'])
i_h_bb['flowDollar_bexb'] = i_h_bb.groupby('ticker')['dollarHeld_bexb'].apply(lambda x: x-x.shift()).values

i_h_bb['dollarHeld_c'] = i_h_bb['sharesHeld_c'].multiply(i_h_bb['c'])
i_h_bb['flowDollar_c'] = i_h_bb.groupby('ticker')['dollarHeld_c'].apply(lambda x: x-x.shift()).values

i_h_bb = i_h_bb.drop(columns = ['c', 'so'])


#i_h_bb[(i_h_bb.ticker=='000002.SZ')&(i_h_bb['sharesHeld_bb']==0)]
#t1 = i_h_bb_raw[i_h_bb_raw.datadate=='2018-10-31']
#i_h_bb[(i_h_bb.ticker=='000001.SZ')].set_index('datadate')['sharesHeld_bb'].plot()


### V
i_v = yu.get_sql('''select avgVadj, ticker, datadate  FROM [CNDBprod].[dbo].[UNIVERSE_ALL_CN] ''')
c_sh = i_v['ticker'].str[0].isin(['6'])
c_sz = i_v['ticker'].str[0].isin(['0','3'])
i_v.loc[c_sh, 'ticker'] = i_v.loc[c_sh, 'ticker'] + '.SH'
i_v.loc[c_sz, 'ticker'] = i_v.loc[c_sz, 'ticker'] + '.SZ'




### 300/500 index weight
#   according to Rime's folder on Z, a file with "modified date" = 2020.06.01 10:51am ET 
#   has "date of portfolio" = 2020.06.01
i_300 = yu.get_sql('''select ticker, [Date of Portfolio] as datadate,
                   [total return investible weight] as w300 
                   from [CNDBprod].[dbo].[index_constituent_rime_csi300]''')
c_sh = i_300['ticker'].str[0].isin(['6'])
c_sz = i_300['ticker'].str[0].isin(['0', '3'])
i_300.loc[c_sh, 'ticker'] = i_300.loc[c_sh, 'ticker'] + '.SH'
i_300.loc[c_sz, 'ticker'] = i_300
.loc[c_sz, 'ticker'] + '.SZ'
i_500 = yu.get_sql('''select ticker, [Date of Portfolio] as datadate,
                   [total return investible weight] as w500 
                   from [CNDBprod].[dbo].[index_constituent_rime_csi500]''')
c_sh = i_500['ticker'].str[0].isin(['6'])
c_sz = i_500['ticker'].str[0].isin(['0', '3'])
i_500.loc[c_sh, 'ticker'] = i_500.loc[c_sh, 'ticker'] + '.SH'
i_500.loc[c_sz, 'ticker'] = i_500.loc[c_sz, 'ticker'] + '.SZ'


### o2c


i_o_c_ret = pw.get_wind_mkt_data(col_list = ['ticker', 'datadate', 'adjret_o_c'])
i_o_c_ret = i_o_c_ret.sort_values(['ticker', 'datadate'])

i_o_c_ret['adjret_o_c_t10d'] = i_o_c_ret.groupby('ticker').rolling(datetime.timedelta(days=14), on = 'datadate', min_periods=7)['adjret_o_c'].sum().values
i_o_c_ret['adjret_o_c_t20d'] = i_o_c_ret.groupby('ticker').rolling(datetime.timedelta(days=28), on = 'datadate', min_periods=14)['adjret_o_c'].sum().values
i_o_c_ret['adjret_o_c_t63d'] = i_o_c_ret.groupby('ticker').rolling(datetime.timedelta(days=91), on = 'datadate', min_periods=45)['adjret_o_c'].sum().values
i_o_c_ret['adjret_o_c_t60d'] = i_o_c_ret.groupby('ticker').rolling(datetime.timedelta(days=60), on = 'datadate', min_periods=21)['adjret_o_c'].sum().values





### daily PV and V

i_daily_pv = yu.get_sql('''
                (select datadate, ticker, sum (PV) as pv, sum(Volume) as v FROM [CNDBprod].[dbo].[TRTH_CN_TRADE_16] group by datadate, ticker)                
                union
                (select datadate, ticker, sum (PV) as pv, sum(Volume) as v FROM [CNDBprod].[dbo].[TRTH_CN_TRADE_17] group by datadate, ticker)
                union
                (select datadate, ticker, sum (PV) as pv, sum(Volume) as v FROM [CNDBprod].[dbo].[TRTH_CN_TRADE_18] group by datadate, ticker)
                union
                (select datadate, ticker, sum (PV) as pv, sum(Volume) as v FROM [CNDBprod].[dbo].[TRTH_CN_TRADE_19] group by datadate, ticker)
                union
                (select datadate, ticker, sum (PV) as pv, sum(Volume) as v FROM [CNDBprod].[dbo].[TRTH_CN_TRADE_20] group by datadate, ticker)
                ''')
i_daily_pv['ticker'] = i_daily_pv['ticker'].str.replace('.SS','.SH')



### wind L2

i_flow_wind = yu.get_sql('''select S_INFO_WINDCODE as ticker, trade_dt as datadate, 
                  VALUE_DIFF_LARGE_TRADER as large_net_amt,
                  VALUE_DIFF_INSTITUTE as inst_net_amt,
                  VALUE_DIFF_LARGE_TRADER + VALUE_DIFF_INSTITUTE as larger_net_amt 
           
       from wind.dbo.ASHAREMONEYFLOW
                  where trade_dt > = '20140101' and trade_dt <= '20211231' ''')

i_flow_wind['datadate'] = pd.to_datetime(i_flow_wind['datadate'], format='%Y%m%d')
i_flow_wind = i_flow_wind[i_flow_wind['ticker'].isin(i_h['ticker'].unique().tolist())]



### concept

i_cpt = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pChinaScope_strat_concept_01.parquet')




### |------
### combine

icom = i_sd_map.merge(i_h, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_daily_pv, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_300, on = ['ticker', 'datadate'], how = 'left')
#icom = icom.merge(i_500, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_o_c_ret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_v, on = ['ticker', 'datadate'], how = 'left')
#icom = icom.merge(i_h_broker, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_h_bb, on = ['ticker', 'datadate'], how = 'left')
#icom = icom.merge(i_flow_wind, on = ['ticker', 'datadate'], how = 'left')

#icom = icom.merge(i_ed, on = ['ticker','datadate'], how = 'left')


#icom = icom.merge(i_cpt, on = ['ticker','datadate'], how = 'left')

icom['turnover'] = icom['WIND_V_l1d'].divide(icom['so'])

icom = icom.sort_values(['ticker', 'datadate'])




### Turnover of (BB dollar flow / PV)
# dollar flow alone worse
# BB dollar flow itself has a V-shaped bar chart

icom['flowDollar_bb_dv_pv'] = icom['flowDollar_bb'].divide(icom['avgPVadj']).abs()
icom['flowDollar_bb_dv_pv_t10d'] = icom.groupby('ticker').rolling(10)['flowDollar_bb_dv_pv'].mean().values
icom['flowDollar_bb_dv_pv_t10d_bk'] = icom.groupby('datadate')['flowDollar_bb_dv_pv_t10d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['hkBBFlow_dv_pv'] = icom['hkBBFlow'].divide(icom['pv'])
icom['hkBBFlow_dv_pv_t5d'] = icom.groupby('ticker').rolling(5)['hkBBFlow_dv_pv'].mean().values
icom['hkBBFlow_dv_pv_t5d_bk'] = icom.groupby('datadate')['hkBBFlow_dv_pv_t5d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['hkBBFlow_dv_pv_abs'] = icom['hkBBFlow_dv_pv'].abs()
icom['hkBBFlow_dv_pv_abs_t5d'] = icom.groupby('ticker').rolling(5)['hkBBFlow_dv_pv_abs'].mean().values
icom['hkBBFlow_dv_pv_abs_t5d_rk'] = icom.groupby('datadate')['hkBBFlow_dv_pv_abs_t5d'].apply(yu.uniformed_rank).values
icom['hkBBFlow_dv_pv_abs_t5d_bk'] = icom.groupby('datadate')['hkBBFlow_dv_pv_abs_t5d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['hkBBFlow_dv_pv_abs_t20d'] = icom.groupby('ticker'
).rolling(20)['hkBBFlow_dv_pv_abs'].mean().values
icom['hkBBFlow_dv_pv_abs_t20d_rk'] = icom.groupby('datadate')['hkBBFlow_dv_pv_abs_t20d'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icom, ['flowDollar_bb_dv_pv_t10d_bk'], 'flowDollar_bb_dv_pv_t10d') # -8 +3 0
yu.create_cn_3x3(icom, ['hkBBFlow_dv_pv_abs_t5d_bk'], 'hkBBFlow_dv_pv_abs_t5d') # -9.5 +4 +1

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['hkBBFlow_dv_pv_abs_t5d_rk']<-0.8)].\
            dropna(subset=['hkBBFlow_dv_pv_abs_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'hkBBFlow_dv_pv_abs_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 5.69/2.69, short doesn't work for csi300

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['hkBBFlow_dv_pv_abs_t20d_rk']<-0.8)].\
            dropna(subset=['hkBBFlow_dv_pv_abs_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'hkBBFlow_dv_pv_abs_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.89/3.67 short doesn't work for csi300

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['hkBBFlow_dv_pv_abs_t20d_rk']>0)].\
            dropna(subset=['hkBBFlow_dv_pv_abs_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'hkBBFlow_dv_pv_abs_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.31/1.38




### Turnover of (BB pctOfComp) GF version 1

icom['turnoverOfComp_bb'] = icom['flowOfComp_bb'].abs()
icom['turnoverOfComp_bb_bk'] = icom.groupby('datadate')['turnoverOfComp_bb'].apply(lambda x: yu.pdqcut(x,bins=5)).values
icom['turnoverOfComp_bb_rk'] = icom.groupby('datadate')['turnoverOfComp_bb'].apply(yu.uniformed_rank).values

icom['turnoverOfComp_bb_t20d'] = icom.groupby('ticker').rolling(20)['turnoverOfComp_bb'].mean().values
icom['turnoverOfComp_bb_t20d_rk'] = icom.groupby('datadate')['turnoverOfComp_bb_t20d'].apply(yu.uniformed_rank).values
icom['turnoverOfComp_bb_t20d_bk'] = icom.groupby('datadate')['turnoverOfComp_bb_t20d'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom['turnover_t20d'] = icom.groupby('ticker').rolling(20)['turnover'].mean().values
icom['turnover_t20d_rk'] = icom.groupby('datadate')['turnover_t20d'].apply(yu.uniformed_rank).values
icom['turnover_t20d_bk'] = icom.groupby('datadate')['turnover_t20d'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom['turnoverOfComp_bb_t20d_turnbk'] = icom.groupby(['datadate','turnover_t20d_bk'])['turnoverOfComp_bb_t20d'].apply(lam
bda x: yu.pdqcut(x,bins=5)).values
icom['turnoverOfComp_bb_t20d_turnrk'] = icom.groupby(['datadate','turnover_t20d_bk'])['turnoverOfComp_bb_t20d'].apply(yu.uniformed_rank).values
icom['turnover_t20d_bbbk'] = icom.groupby(['datadate','turnoverOfComp_bb_t20d_bk'])['turnover_t20d'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom, ['turnoverOfComp_bb_bk'], 'turnoverOfComp_bb')
yu.create_cn_3x3(icom[icom['bd2e']<=20], ['turnoverOfComp_bb_bk'], 'turnoverOfComp_bb')
yu.create_cn_3x3(icom[(icom['bd2e']<=20)|(icom['bdae']<=10)], ['turnoverOfComp_bb_bk'], 'turnoverOfComp_bb')

yu.create_cn_3x3(icom, ['turnoverOfComp_bb_t20d_bk'], 'turnoverOfComp_bb_t20d')
yu.create_cn_3x3(icom[(icom['bd2e']<=20)], ['turnoverOfComp_bb_t20d_bk'], 'turnoverOfComp_bb_t20d')

yu.create_cn_3x3(icom, ['turnoverOfComp_bb_t20d_turnbk'], 'turnoverOfComp_bb_t20d') #mono -5 +2.5
yu.create_cn_3x3(icom[icom['turnover_t20d_bk']==4], ['turnoverOfComp_bb_t20d_turnbk'], 'turnoverOfComp_bb_t20d') # -10, +4
yu.create_cn_3x3(icom[(icom['turnover_t20d_bk']==4)&(icom['bd2e']<=20)], ['turnoverOfComp_bb_t20d_turnbk'], 'turnoverOfComp_bb_t20d') # -10, +6

yu.create_cn_3x3(icom, ['turnover_t20d_bbbk'], 'turnover_t20d') #less mono 0 +3 -4
yu.create_cn_3x3(icom[icom['turnoverOfComp_bb_t20d_turnbk']==4], ['turnover_t20d_bbbk'], 'turnover_t20d') # random

yu.create_cn_3x3(icom[icom['turnover_t20d_bk']==4], ['turnoverOfComp_bb_t20d_bk'], 'turnoverOfComp_bb_t20d')
yu.create_cn_3x3(icom[icom['turnoverOfComp_bb_t20d_bk']==4], ['turnover_t20d_bk'], 'turnover_t20d')
yu.create_cn_3x3(icom[icom['turnoverOfComp_bb_t20d_bk']==0], ['turnover_t20d_bk'], 'turnover_t20d')


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['turnover_t20d_bk']==4)].\
            dropna(subset=['turnoverOfComp_bb_t20d_turnrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'turnoverOfComp_bb_t20d_turnrk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.47/1.24

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['turnover_t20d_bk']==4)&(icom['bd2e']<=20)].\
            dropna(subset=['turnoverOfComp_bb_t20d_turnrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'turnoverOfComp_bb_t20d_turnrk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.17 / 1.59



### Turnover of (BB pctOfComp) GF version 2

icom['cpt_rk'] = icom.groupby('datadate')['cpt_cnt_t2y'].apply(yu.uniformed_rank).values

icom['turnoverOfComp_bb'] = icom['flowOfComp_bb'].abs(
)

icom['turnoverOfComp_bb_t20d'] = icom.groupby('ticker').rolling(20)['turnoverOfComp_bb'].mean().values
icom['turnoverOfComp_bb_t20d_rk'] = icom.groupby('datadate')['turnoverOfComp_bb_t20d'].apply(yu.uniformed_rank).values
icom['turnoverOfComp_bb_t20d_bk'] = icom.groupby('datadate')['turnoverOfComp_bb_t20d'].apply(lambda x: yu.pdqcut(x,bins=3)).values
icom['turnoverOfComp_bb_t20d_5bk'] = icom.groupby('datadate')['turnoverOfComp_bb_t20d'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom['turnover_t20d'] = icom.groupby('ticker').rolling(20)['turnover'].mean().values
icom['turnover_t20d_rk'] = icom.groupby('datadate')['turnover_t20d'].apply(yu.uniformed_rank).values
icom['turnover_t20d_bk'] = icom.groupby('datadate')['turnover_t20d'].apply(lambda x: yu.pdqcut(x,bins=3)).values
icom['turnover_t20d_5bk'] = icom.groupby('datadate')['turnover_t20d'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom, ['turnover_t20d_5bk'], 'turnover_t20d')
yu.create_cn_3x3(icom, ['turnoverOfComp_bb_t20d_5bk'], 'turnoverOfComp_bb_t20d')

icom['sgnl1'] = np.nan
c1 = (icom['turnover_t20d_bk']==0)&(icom['turnoverOfComp_bb_t20d_bk']==2)
icom.loc[c1, 'sgnl1'] = 1

icom['sgnl2'] = np.nan
c1 = (icom['turnover_t20d_bk']==2)&(icom['turnoverOfComp_bb_t20d_bk']==0)
icom.loc[c1, 'sgnl2'] = -1

icom['sgnl3'] = np.nan
icom.loc[(icom['cd2e']<=5)&(icom['flag_pre_ann']!=1), 'sgnl3'] = 1

icom['sgnl3'] = np.nan
icom.loc[(icom['cd2e']<=5), 'sgnl3'] = 1



o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['bd2e']<=20)].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['bd2e']<=20)].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(sub
set=['sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) # 


### Turnover of (BB pctOfComp)

icom['turnoverOfComp_bb'] = icom['flowOfComp_bb'].abs()
icom['turnoverOfComp_bb_t20d'] = icom.groupby('ticker').rolling(20)['turnoverOfComp_bb'].mean().values
icom['turnoverOfComp_bb_t20d_rk'] = icom.groupby('datadate')['turnoverOfComp_bb_t20d'].apply(yu.uniformed_rank).values
icom['turnoverOfComp_bb_t20d_bk'] = icom.groupby('datadate')['turnoverOfComp_bb_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['turnoverOfComp_bb_t10d'] = icom.groupby('ticker').rolling(10)['turnoverOfComp_bb'].mean().values
icom['turnoverOfComp_bb_t10d_rk'] = icom.groupby('datadate')['turnoverOfComp_bb_t10d'].apply(yu.uniformed_rank).values

icom['turnover_t20d'] = icom.groupby('ticker').rolling(20)['turnover'].mean().values
icom['turnover_t20d_rk'] = icom.groupby('datadate')['turnover_t20d'].apply(yu.uniformed_rank).values
icom['turnover_t20d_bk'] = icom.groupby('datadate')['turnover_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['turnover_t10d'] = icom.groupby('ticker').rolling(10)['turnover'].mean().values
icom['turnover_t10d_rk'] = icom.groupby('datadate')['turnover_t10d'].apply(yu.uniformed_rank).values

icom['turnover_bbOfComp_sd_t20d_df'] = icom['turnoverOfComp_bb_t20d_rk'] - icom['turnover_t20d_rk']
icom['turnover_bbOfComp_sd_t20d_df_rk'] = icom.groupby('datadate')['turnover_bbOfComp_sd_t20d_df'].apply(yu.uniformed_rank).values
icom['turnover_bbOfComp_sd_t20d_df_bk'] = icom.groupby('datadate')['turnover_bbOfComp_sd_t20d_df'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['turnover_bbOfComp_sd_t20d_df_t5d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=5),on='datadate')['turnover_bbOfComp_sd_t20d_df'].mean().values
icom['turnover_bbOfComp_sd_t20d_df_t5d_rk'] = icom.groupby('datadate')['turnover_bbOfComp_sd_t20d_df_t5d'].apply(yu.uniformed_rank).values

icom['turnover_bbOfComp_sd_t10d_df'] = icom['turnoverOfComp_bb_t10d_rk'] - icom['turnover_t10d_rk']
icom['turnover_bbOfComp_sd_t10d_df_rk'] = icom.groupby('datadate')['turnover_bbOfComp_sd_t10d_df'].apply(yu.uniformed_rank).values
icom['turnover_bbOfComp_sd_t10d_df_bk'] = icom.groupby('datadate')['turnover_bbOfComp_sd_t10d_df'].apply(lambda x: yu.pdqcut(x,bins=10)).values


yu.create_cn_3x3(icom, ['turnoverOfComp_bb_t20d_bk'], 'turnoverOfComp_bb_t20d') # mono: -3 + 3
yu.create_cn_3x3(icom, ['turnover_t20d_bk'], 't
urnover_t20d') #  -1 +2 -3
yu.create_cn_3x3(icom, ['turnover_bb_sd_df_bk'], 'turnover_bb_sd_df') # mono: -8 +4 +1
yu.create_cn_3x3(icom, ['turnover_bbOfComp_sd_t10d_df_bk'], 'turnover_bbOfComp_sd_t10d_df') # -8 +4 +1


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['turnoverOfComp_bb_t20d_rk']>0)].\
            dropna(subset=['turnoverOfComp_bb_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'turnoverOfComp_bb_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.02/0.75, 0.55bp/d

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['turnoverOfComp_bb_t20d_rk']<-0.8)].\
            dropna(subset=['turnoverOfComp_bb_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'turnoverOfComp_bb_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.69/1.39, 2.2 bp/d

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['turnover_bbOfComp_sd_t20d_df_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'turnover_bbOfComp_sd_t20d_df_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.35/1.83, 1.6bp/d
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['turnover_bbOfComp_sd_t20d_df_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'turnover_bbOfComp_sd_t20d_df_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.1/2.18, 1.89bp/d, 2.1e7 ###!!!
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['turnover_bbOfComp_sd_t20d_df_t5d_rk']>0)].\
            dropna(subset=['turnover_bbOfComp_sd_t20d_df_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'turnover_bbOfComp_sd_t20d_df_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.29/1.47

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['cpt_rk']<0)&(icom['turnover_bbOfComp_sd_t20d_df_t5d_rk']>0)].\
            dropna(subset=['turnover_bbOfComp_sd_t20d_df_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'turnover_bbOfComp_sd_t20d_df_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.29/1.47




o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['bd2e'].between(0,20)|icom['bdae'].between(0,10))].\
            dropna(subset=['turnover_bbOfComp_sd_t20d_df_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'turnover_bbO
fComp_sd_t20d_df_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.16/2.24, 2.22bp/d, 1.5e7 ###!!!
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['bd2e'].between(0,60))].\
            dropna(subset=['turnover_bbOfComp_sd_t20d_df_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'turnover_bbOfComp_sd_t20d_df_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.16/2.24, 2.22bp/d, 1.5e7 ###!!!

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['bd2e'].between(0,20)|icom['bdae'].between(0,10))&(icom['turnover_bbOfComp_sd_t20d_df_t5d_rk']>0)].\
            dropna(subset=['turnover_bbOfComp_sd_t20d_df_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'turnover_bbOfComp_sd_t20d_df_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.41/1.89, 2.25bp/d, 0.7e7



o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['turnover_bbOfComp_sd_t10d_df_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'turnover_bbOfComp_sd_t10d_df_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.82/1.19, 1.04bp/d
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['turnover_bb_sd_t60d_df_rk']>0)].\
            dropna(subset=['turnover_bbOfComp_sd_t10d_df_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'turnover_bbOfComp_sd_t10d_df_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.29/-0.49



#### Turnover of (BexB pctOfComp)

icom['turnoverOfComp_bexb'] = icom['flowOfComp_bexb'].abs()
icom['turnoverOfComp_bexb_t20d'] = icom.groupby('ticker').rolling(20)['turnoverOfComp_bexb'].mean().values
icom['turnoverOfComp_bexb_t20d_rk'] = icom.groupby('datadate')['turnoverOfComp_bexb_t20d'].apply(yu.uniformed_rank).values
icom['turnoverOfComp_bexb_t20d_bk'] = icom.groupby('datadate')['turnoverOfComp_bexb_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['turnoverOfComp_bexb_t20d_bk'], 'turnoverOfComp_bexb_t20d') # mono -4 +2



#### Turnover of (c pctOfComp)

icom['turnoverOfComp_c'] = icom['flowOfComp_c'].abs()
icom['turnoverOfComp_c_t20d'] = icom.groupby('ticker').rolling(20)['turnoverOfComp_c'].mean().values
icom['turnoverOfComp_c_t20d_rk'] = icom.groupby('datadate')['turnoverOfComp_c_t20d'].apply(yu.uniformed_rank).values
icom['turnoverOfComp_c_t20d_bk'] = icom.groupby('datadate')['turnoverOfComp_c_t20d'].apply(lambda x: yu.pdqcut(x,bin
s=10)).values

icom['turnoverOfComp_bb_m_c_t20d'] = icom['turnoverOfComp_bb_t20d_rk']-icom['turnoverOfComp_c_t20d_rk'] 
icom['turnoverOfComp_bb_m_c_t20d_bk'] = icom.groupby('datadate')['turnoverOfComp_bb_m_c_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['turnoverOfComp_c_t20d_bk'], 'turnoverOfComp_c_t20d') # not mono -2, 0, -3, +1 
yu.create_cn_3x3(icom, ['turnoverOfComp_bb_m_c_t20d_bk'], 'turnoverOfComp_bb_m_c_t20d') # less mono -2 -3 +2 0 +3 0


### Turnover of 2 methods: BB pdtOfComp and BB flowDollar

icom['test'] = icom['hkBBFlowOfComp_abs_t20d_rk']+icom['hkBBFlow_dv_pv_abs_t20d_rk']
icom['test_bk'] = icom.groupby('datadate')['test'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['test_rk'] = icom.groupby('datadate')['test'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icom, ['test_bk'], 'test')

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['test_rk']<0)].\
            dropna(subset=['test_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.52/3.12, 3bp/d, 1.7s for csi300

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['test_rk']>0)].\
            dropna(subset=['test_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.23/2.1, 1.79bp/d


### Turnover of (HK pctOfComp)

icom['turnover_ofComp'] = icom['turnoverOfComp_hk'].abs()
icom['turnover_ofComp_t20d'] = icom.groupby('ticker').rolling(20)['turnover_ofComp'].mean().values
icom['turnover_ofComp_t20d_rk'] = icom.groupby('datadate')['turnover_ofComp_t20d'].apply(yu.uniformed_rank).values
icom['turnover_ofComp_t20d_bk'] = icom.groupby('datadate')['turnover_ofComp_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['turnover_ofComp_t20d_bk'], 'turnover_ofComp_t20d') # worse than BB turnover


### Turnover of (HK pctOfComp - BB pctOfComp)

icom['pct_ofComp_nonBB_df1d'] = icom['pct_ofComp_df1d'] - icom['hkBBFlowOfComp']
icom['pct_ofComp_nonBB_df1d_abs'] = icom['pct_ofComp_nonBB_df1d'].abs()
icom['pct_ofComp_nonBB_df1d_abs_bk'] = icom.groupby('datadate')['pct_ofComp_nonBB_df1d_abs'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['pct_ofComp_nonBB_df1d_abs_bk'], 'pct_ofComp_nonBB_df1d_abs') # not quite mono, -4, +1.5, not better than BB turnover






# bb flow (diff in (shares / so))

# bb flow + o2c

# rank(bb
 held ) - rank(of market cap)


# node 1: /so and /pv; # node 2: o2c; # node 3: hk holding; # node 4: 





### Flow: corr between wind large flow and hk flow 
icom['wind_larger_dv_pv'] = icom['larger_net_amt'].divide(icom['pv'])
icom['wind_inst_dv_pv'] = icom['inst_net_amt'].divide(icom['pv'])
icom['held_shares_df_dv_v'] = icom['held_shares_df'].divide(icom['v'])

icom[['wind_larger_dv_pv','held_shares_df_dv_v']].corr() #-0.04
icom[['wind_inst_dv_pv','held_shares_df_dv_v']].corr() #-0.02






### Flow for pctOfComp: HK

icom['flowOfComp_hk_bk'] = icom.groupby('datadate')['flowOfComp_hk'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['flowOfComp_hk_bk'], 'flowOfComp_hk') # v shape


### Flow for pctOfComp: BB

icom['flowOfComp_bb_bk'] = icom.groupby('datadate')['flowOfComp_bb'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['flowOfComp_bb_t60d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=60), on='datadate', min_periods=21)['flowOfComp_bb'].sum().values
icom['flowOfComp_bb_t60d_rk'] = icom.groupby('datadate')['flowOfComp_bb_t60d'].apply(yu.uniformed_rank).values

icom['adjret_o_c_t60d_rk'] = icom.groupby('datadate')['adjret_o_c_t60d'].apply(yu.uniformed_rank).values
icom['flowOfComp_bb_o2c_rkdf'] = icom['flowOfComp_bb_t60d_rk'] - icom['adjret_o_c_t60d_rk']
icom['flowOfComp_bb_o2c_rkdf_bk'] = icom.groupby('datadate')['flowOfComp_bb_o2c_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['flowOfComp_bb_o2c_rkdf_rk'] = icom.groupby('datadate')['flowOfComp_bb_o2c_rkdf'].apply(yu.uniformed_rank).values

icom['flowOfComp_bb_o2c_rkdf_sgnl'] = np.nan
icom.loc[icom['flowOfComp_bb_o2c_rkdf_rk'].abs()>0.8, 'flowOfComp_bb_o2c_rkdf_sgnl'] = icom.loc[icom['flowOfComp_bb_o2c_rkdf_rk'].abs()>0.8, 'flowOfComp_bb_o2c_rkdf_rk']
icom['flowOfComp_bb_o2c_rkdf_sgnl'] = icom.groupby('ticker')['flowOfComp_bb_o2c_rkdf_sgnl'].ffill(limit = 20)


yu.create_cn_3x3(icom, ['flowOfComp_bb_bk'], 'flowOfComp_bb') # v shape
yu.create_cn_3x3(icom, ['flowOfComp_bb_o2c_rkdf_bk'], 'flowOfComp_bb_o2c_rkdf') # mono -4 +6

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['flowOfComp_bb_o2c_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flowOfComp_bb_o2c_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.43/-0.24
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['flowOfComp_bb_o2c_rkdf_rk']>0)].\
            dropna(subset=['flowOfComp_bb_o2c_rkdf_rk','Ba
rrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flowOfComp_bb_o2c_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.35/0.12

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['flowOfComp_bb_o2c_rkdf_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flowOfComp_bb_o2c_rkdf_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.12/1.0



### Flow for dollar/pv: HK

icom['flowDollar_hk_dv_pv'] = icom['flowDollar_hk'].divide(icom['PV_l1d'])
icom['flowDollar_hk_dv_pv_bk'] = icom.groupby('datadate')['flowDollar_hk_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['flowDollar_hk_dv_pv_t60d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=60), on='datadate', min_periods=21)['flowDollar_hk_dv_pv'].sum().values
icom['flowDollar_hk_dv_pv_t60d_rk'] = icom.groupby('datadate')['flowDollar_hk_dv_pv_t60d'].apply(yu.uniformed_rank).values

icom['adjret_o_c_t60d_rk'] = icom.groupby('datadate')['adjret_o_c_t60d'].apply(yu.uniformed_rank).values
icom['flowDollar_hk_o2c_rkdf'] = icom['flowDollar_hk_dv_pv_t60d_rk'] - icom['adjret_o_c_t60d_rk']
icom['flowDollar_hk_o2c_rkdf_bk'] = icom.groupby('datadate')['flowDollar_hk_o2c_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['flowDollar_hk_dv_pv_bk'], 'flowDollar_hk_dv_pv') # v shape
yu.create_cn_3x3(icom, ['flowDollar_hk_o2c_rkdf_bk'], 'flowDollar_hk_o2c_rkdf') # mono -3 +3


### Flow for dollar/pv: BB

icom['flowDollar_bb_dv_pv'] = icom['flowDollar_bb'].divide(icom['PV_l1d'])
icom['flowDollar_bb_dv_pv_bk'] = icom.groupby('datadate')['flowDollar_bb_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values

c1 = icom['flowDollar_bb_dv_pv']>0
icom.loc[c1, 'flowDollar_bb_dv_pv_gt0'] = icom.loc[c1, 'flowDollar_bb_dv_pv']

icom['flowDollar_bb_dv_pv_gt0_bk'] = icom.groupby('datadate')['flowDollar_bb_dv_pv_gt0'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['flowDollar_bb_dv_pv_gt0_rk'] = icom.groupby('datadate')['flowDollar_bb_dv_pv_gt0'].apply(yu.uniformed_rank).values

icom['flowDollar_bb_dv_pv_gt0_t20d'] = icom.groupby('ticker').rolling(20,min_periods=1)['flowDollar_bb_dv_pv_gt0'].sum().values
icom['flowDollar_bb_dv_pv_gt0_t20d_rk'] = icom.groupby('datadate')['flowDollar_bb_dv_pv_gt0_t20d'].apply(yu.uniformed_rank).values
icom['flowDollar_bb_dv_pv_gt0_t60d'] = icom.groupby('ticker').rolling(60,min_periods=1)['flowDollar_bb_dv_pv_gt0'].sum().values
icom['flowDollar_bb_dv_pv_gt0_t6
0d_rk'] = icom.groupby('datadate')['flowDollar_bb_dv_pv_gt0_t60d'].apply(yu.uniformed_rank).values

icom['flowDollar_bb_dv_pv_gt0_sgnl'] = np.nan
c2 = icom['flowDollar_bb_dv_pv_gt0_rk'].abs()>0.8
icom.loc[c2, 'flowDollar_bb_dv_pv_gt0_sgnl'] = icom.loc[c2, 'flowDollar_bb_dv_pv_gt0_rk']
icom['flowDollar_bb_dv_pv_gt0_sgnl'] = icom.groupby('ticker')['flowDollar_bb_dv_pv_gt0_sgnl'].ffill(limit=20)


icom['flowDollar_bb_dv_pv_gt0_sgnl2'] = np.nan
icom['flowDollar_bb_dv_pv_gt0_sgnl2'] = icom['flowDollar_bb_dv_pv_gt0_rk']
icom['flowDollar_bb_dv_pv_gt0_sgnl2'] = icom.groupby('ticker')['flowDollar_bb_dv_pv_gt0_sgnl2'].ffill(limit=60)


icom['flowDollar_bb_dv_pv_t60d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=60), on='datadate', min_periods=21)['flowDollar_bb_dv_pv'].sum().values
icom['flowDollar_bb_dv_pv_t60d_rk'] = icom.groupby('datadate')['flowDollar_bb_dv_pv_t60d'].apply(yu.uniformed_rank).values

icom['flowDollar_bb_dv_pv_t20d'] = icom.groupby('ticker').rolling(20)['flowDollar_bb_dv_pv'].sum().values
icom['flowDollar_bb_dv_pv_t20d_rk'] = icom.groupby('datadate')['flowDollar_bb_dv_pv_t20d'].apply(yu.uniformed_rank).values

icom['adjret_o_c_t20d_rk'] = icom.groupby('datadate')['adjret_o_c_t20d'].apply(yu.uniformed_rank).values
icom['flowDollar_bb_o2c_t20d_rkdf'] = icom['flowDollar_bb_dv_pv_t20d_rk'] - icom['adjret_o_c_t20d_rk']
icom['flowDollar_bb_o2c_t20d_rkdf_bk'] = icom.groupby('datadate')['flowDollar_bb_o2c_t20d_rkdf'].apply(lambda x: yu.pdqcut(x,bins=5)).values
icom['flowDollar_bb_o2c_t20d_rkdf_rk'] = icom.groupby('datadate')['flowDollar_bb_o2c_t20d_rkdf'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icom[icom['datadate'].between('2018-07-01','2020-12-31')], ['flowDollar_bb_dv_pv_bk'], 'flowDollar_bb_dv_pv') # v shape
yu.create_cn_3x3(icom[icom['datadate'].between('2018-07-01','2020-12-31')], ['flowDollar_bb_o2c_rkdf_bk'], 'flowDollar_bb_o2c_rkdf') # mono -2 +4

yu.create_cn_3x3(icom[icom['datadate'].between('2018-07-01','2020-12-31')], ['flowDollar_bb_dv_pv_gt0_bk'], 'flowDollar_bb_dv_pv_gt0') # mono: -6 +6

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['flowDollar_bb_o2c_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flowDollar_bb_o2c_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['flowDollar_bb_o2c_t20d_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=
['ticker','datadate']),
            'flowDollar_bb_o2c_t20d_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.65 / -2.36

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['flowDollar_bb_dv_pv_gt0_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flowDollar_bb_dv_pv_gt0_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.26/-6.46
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['flowDollar_bb_dv_pv_gt0_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flowDollar_bb_dv_pv_gt0_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.63/1.45
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['flowDollar_bb_dv_pv_gt0_t60d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flowDollar_bb_dv_pv_gt0_t60d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.39/1.36

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['flowDollar_bb_dv_pv_gt0_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flowDollar_bb_dv_pv_gt0_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.7/0.28



### Flow for dollar/pv: BB + BRET






### Flow (benchmark): wind inflow vs o2c


icom['large_dv_pv'] = icom['large_net_amt'].divide(icom['pv'])
icom['large_dv_pv_t20d'] = icom.groupby('ticker').rolling(20)['large_dv_pv'].mean().values
icom['large_dv_pv_t20d_rk'] = icom.groupby('datadate')['large_dv_pv_t20d'].apply(yu.uniformed_rank).values
icom['large_dv_pv_t60d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=60),on='datadate',min_periods=21)['large_dv_pv'].mean().values
icom['large_dv_pv_t60d_rk'] = icom.groupby('datadate')['large_dv_pv_t60d'].apply(yu.uniformed_rank).values

icom['adjret_o_c_t20d_rk'] = icom.groupby('datadate')['adjret_o_c_t20d'].apply(yu.uniformed_rank).values
icom['adjret_o_c_t60d_rk'] = icom.groupby('datadate')['adjret_o_c_t60d'].apply(yu.uniformed_rank).values

icom['flowWind_bb_o2c_t60d_rkdf'] = icom['large_dv_pv_t60d_rk'] - icom['adjret_o_c_t60d_rk']
icom['flowWind_bb_o2c_t60d_rkdf_bk'] = icom.groupby('datadate')['flowWind_bb_o2c_t60d_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['flowWind_bb_o2c_t60d_rkdf_rk'] = icom.groupby('datadate')['flowWind_bb_o2c_t60d_rkdf'].apply(yu.uniformed_rank).values

icom['flowWind_bb_o2c_t20d_rkdf'] = icom['lar
ge_dv_pv_t20d_rk'] - icom['adjret_o_c_t20d_rk']
icom['flowWind_bb_o2c_t20d_rkdf_bk'] = icom.groupby('datadate')['flowWind_bb_o2c_t20d_rkdf'].apply(lambda x: yu.pdqcut(x,bins=5)).values
icom['flowWind_bb_o2c_t20d_rkdf_rk'] = icom.groupby('datadate')['flowWind_bb_o2c_t20d_rkdf'].apply(yu.uniformed_rank).values

icom['flowWind_bb_o2c_t60d_rkdf_sgnl'] = np.nan
icom.loc[icom['flowWind_bb_o2c_t60d_rkdf_rk'].abs()>0.8, 'flowWind_bb_o2c_t60d_rkdf_sgnl'] = icom.loc[icom['flowWind_bb_o2c_t60d_rkdf_rk'].abs()>0.8, 'flowWind_bb_o2c_t60d_rkdf_rk']
icom['flowWind_bb_o2c_t60d_rkdf_sgnl'] = icom.groupby('ticker')['flowWind_bb_o2c_t60d_rkdf_sgnl'].ffill(limit=20)


yu.create_cn_3x3(icom[icom.datadate.between('2018-07-01','2020-12-31')], ['flowWind_bb_o2c_t60d_rkdf_bk'], 'flowWind_bb_o2c_t60d_rkdf') # mono -7 +4
yu.create_cn_3x3(icom[icom.datadate.between('2018-07-01','2020-12-31')], ['flowWind_bb_o2c_t20d_rkdf_bk'], 'flowWind_bb_o2c_t20d_rkdf') # mono 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))&(icom['flowWind_bb_o2c_t20d_rkdf_rk']>0)].\
            dropna(subset=['flowWind_bb_o2c_t20d_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flowWind_bb_o2c_t20d_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.49/0.37
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['flowWind_bb_o2c_t20d_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flowWind_bb_o2c_t20d_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.26/0.9

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['flowWind_bb_o2c_t60d_rkdf_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flowWind_bb_o2c_t60d_rkdf_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.56/1.55, 1.55bp/d




### pctOfComp: bb <revised> ###!!!

icom['pctOfComp_bb_rk'] = icom.groupby('datadate')['pctOfComp_bb'].apply(yu.uniformed_rank).values
icom['pctOfComp_bb_bk'] = icom.groupby('datadate')['pctOfComp_bb'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['pctOfComp_bb_t5d'] = icom.groupby('ticker').rolling(5)['pctOfComp_bb'].mean().values
icom['pctOfComp_bb_t5d_rk'] = icom.groupby('datadate')['pctOfComp_bb_t5d'].apply(yu.uniformed_rank).values

#yu.create_cn_3x3(icom[icom['datadate'].between('2018-07-01','2020-12-31')], ['pctOfComp_bb_bk'], 'pctOfComp_b
b_rk') #-11 +3 +3

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['pctOfComp_bb_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 4.4/3.19, 2.89bp/d, 3.4e7 <---best
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))&(icom['pctOfComp_bb_t5d_rk']>0)].\
            dropna(subset=['pctOfComp_bb_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.82/1.99, 1.79bp/d, 1.25e7
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))&(icom['pctOfComp_bb_t5d_rk']<0)].\
            dropna(subset=['pctOfComp_bb_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 




o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['pctOfComp_bb_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 4.94/1.8, 1.63bp/d, 2e7
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))&(icom['pctOfComp_bb_rk']<0)].\
            dropna(subset=['pctOfComp_bb_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 6.59/2.65, 2.86bp/d, 1.4e7
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))&(icom['pctOfComp_bb_rk']>0)].\
            dropna(subset=['pctOfComp_bb_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.01 / 1.07, 0.95bp/d, 0.75e7




### pctOfComp: bexb <revised>

icom['pctOfComp_bexb'] = icom['sharesHeld_bexb'].divide(icom['so'])
icom['pctOfComp_bexb_rk'] = icom.groupby('datadate')['pctOfComp_bexb'].apply(yu.uniformed_rank).values
icom['pctOfComp_bexb_bk'] = icom.groupby('datadate')['pctOfComp_bexb'].apply(lambda x: yu.pdqcut(x,bins=10)).values


yu.create_cn_3x3(icom[icom['datadate'].between('2018-07-01','2019-12-31')], ['pctOfComp_bexb_bk'], 'pctOfComp_bexb') #-11 +3 +2

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2019-12-31'))].\
     
       dropna(subset=['pctOfComp_bexb_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bexb_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs5.3/1.62, 1.03bp/d, 0.6e7
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['pctOfComp_bexb_rk']>0)].\
            dropna(subset=['pctOfComp_bexb_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bexb_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.75/1.42, 0.87bp/d, 3e6

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['pctOfComp_bexb_rk']<0)&(icom['a50_300_flag']==1)].\
            dropna(subset=['pctOfComp_bexb_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bexb_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #

### pctOfComp: c <revised>

icom['pctOfComp_c'] = icom['sharesHeld_c'].divide(icom['so'])
icom['pctOfComp_c_rk'] = icom.groupby('datadate')['pctOfComp_c'].apply(yu.uniformed_rank).values
icom['pctOfComp_c_bk'] = icom.groupby('datadate')['pctOfComp_c'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['pctOfComp_c_t5d'] = icom.groupby('ticker').rolling(5)['pctOfComp_c'].mean().values
icom['pctOfComp_c_t5d_rk'] = icom.groupby('datadate')['pctOfComp_c_t5d'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icom[icom['datadate'].between('2018-07-01','2019-12-31')], ['pctOfComp_c_bk'], 'pctOfComp_c') # less mono -4 0 -3 +2 +0.5

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2019-12-31'))].\
            dropna(subset=['pctOfComp_c_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_c_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.19/2.3, 1.25bp/d, 0.7e7
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['pctOfComp_c_rk']>0)].\
            dropna(subset=['pctOfComp_c_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_c_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.24/1.7, 0.93bp/d, 0.4e7

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2019-12-31'))].\
            dropna(subset=['pctOfComp_c_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_c_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.08/2.44, 1.32bp/d



### pctOfComp: bb - c <revised>

icom['pctOfComp_c'] = icom['sharesHeld_c'].divide(icom['so'])
icom['pctOfComp_c_t5d']  = icom
.groupby('ticker').rolling(5)['pctOfComp_c'].mean().values
icom['pctOfComp_c_rk'] = icom.groupby('datadate')['pctOfComp_c'].apply(yu.uniformed_rank).values
icom['pctOfComp_c_t5d_rk'] = icom.groupby('datadate')['pctOfComp_c_t5d'].apply(yu.uniformed_rank).values
icom['pctOfComp_bb'] = icom['sharesHeld_bb'].divide(icom['so'])
icom['pctOfComp_bb_t5d']  = icom.groupby('ticker').rolling(5)['pctOfComp_bb'].mean().values
icom['pctOfComp_bb_rk'] = icom.groupby('datadate')['pctOfComp_bb'].apply(yu.uniformed_rank).values
icom['pctOfComp_bb_t5d_rk'] = icom.groupby('datadate')['pctOfComp_bb_t5d'].apply(yu.uniformed_rank).values
icom['pctOfComp_bb_m_c'] = icom['pctOfComp_bb_rk'] - icom['pctOfComp_c_rk']

icom['pctOfComp_bb_t5d_m_c_t5d'] = icom['pctOfComp_bb_t5d_rk'] - icom['pctOfComp_c_t5d_rk']
icom['pctOfComp_bb_t5d_m_c_t5d_rk'] = icom.groupby('datadate')['pctOfComp_bb_t5d_m_c_t5d'].apply(yu.uniformed_rank).values


icom['pctOfComp_bb_m_c_bk'] = icom.groupby('datadate')['pctOfComp_bb_m_c'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['pctOfComp_bb_m_c_rk'] = icom.groupby('datadate')['pctOfComp_bb_m_c'].apply(yu.uniformed_rank).values

icom['pctOfComp_bb_m_c_t5d'] = icom.groupby('ticker').rolling(5)['pctOfComp_bb_m_c'].mean().values
icom['pctOfComp_bb_m_c_t5d_rk'] = icom.groupby('datadate')['pctOfComp_bb_m_c_t5d'].apply(yu.uniformed_rank).values

icom['pctOfComp_bb_m_c_sgnl'] = np.nan
icom.loc[icom['pctOfComp_bb_m_c_rk'].abs()>0.8, 'pctOfComp_bb_m_c_sgnl'] = icom.loc[icom['pctOfComp_bb_m_c_rk'].abs()>0.8, 'pctOfComp_bb_m_c_rk']
icom['pctOfComp_bb_m_c_sgnl'] = icom.groupby('ticker')['pctOfComp_bb_m_c_sgnl'].ffill(limit=5)

yu.create_cn_3x3(icom, ['pctOfComp_bb_m_c_bk'], 'pctOfComp_bb_m_c') # mono -7 +7

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['pctOfComp_bb_m_c_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_m_c_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.32/0.19


o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['pctOfComp_bb_t5d_m_c_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_t5d_m_c_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.75 / 2.1, 1.48 bp/d

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['pctOfComp_bb_m_c_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplic
ates(subset=['ticker','datadate']),
            'pctOfComp_bb_m_c_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.7/2.09, 1.43bp/d

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['pctOfComp_bb_m_c_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_m_c_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.25/1.44, 1.59bp/d





### pctOfComp: HK <revised>

icom['pctOfComp_hk_rk'] = icom.groupby('datadate')['pctOfComp_hk'].apply(yu.uniformed_rank).values
icom['pctOfComp_hk_bk'] = icom.groupby('datadate')['pctOfComp_hk'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['pctOfComp_hk_t5d'] = icom.groupby('ticker').rolling(5)['pctOfComp_hk'].sum().values
icom['pctOfComp_hk_t5d_rk'] = icom.groupby('datadate')['pctOfComp_hk_t5d'].apply(yu.uniformed_rank).values


yu.create_cn_3x3(icom[icom['datadate'].between('2018-07-01','2020-12-31')], ['pctOfComp_hk_bk'], 'pctOfComp_hk') # mono, -12,2,1
yu.create_cn_3x3(icom, ['pctOfComp_hk_bk'], 'pctOfComp_hk') # mono, -8,+1

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['pctOfComp_hk_t5d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_hk_t5d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.96/2.28, 1.72bp/d, 2.0e7

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['pctOfComp_hk_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_hk_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.37/2.0, 1.52bp/d, 1.9e7
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))&(icom['pctOfComp_hk_rk']<0)].\
            dropna(subset=['pctOfComp_hk_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_hk_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 4.49/2.74, 3.08bp/d, 1.2e7
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))&(icom['pctOfComp_hk_rk']>0)].\
            dropna(subset=['pctOfComp_hk_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_hk_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.89/1.09, 0.75bp/d, 0.6e7





icom['pct_ofComp_neg_sgnl'] = np.nan
c2 = icom['pct_ofComp_rk']<-0.8
icom.loc[c2, 'pct_ofComp_neg_sgnl'] = icom.loc[c2, 'pct_ofComp_
rk']
icom['pct_ofComp_neg_sgnl'] = icom.groupby('ticker')['pct_ofComp_neg_sgnl'].ffill(limit=10)
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')].\
            dropna(subset=['pct_ofComp_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofComp_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.78 / 2.68, 3.13bp/d



### pct_ofComp  (20d delta)

icom['pctOfComp_bb_df20d'] = icom.groupby('ticker')['pctOfComp_bb'].apply(lambda x: x-x.shift(20)).values
icom['pctOfComp_bb_df20d_rk'] = icom.groupby('datadate')['pctOfComp_bb_df20d'].apply(yu.uniformed_rank).values
icom['pctOfComp_bb_df20d_0crk'] = icom.groupby('datadate')['pctOfComp_bb_df20d'].apply(lambda x: yu.uniformed_rank(x,str_type='zero_cutoff')).values
icom['pctOfComp_bb_df20d_bk'] = icom.groupby('datadate')['pctOfComp_bb_df20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['pct_ofComp_df20d_rk'] = icom.groupby('datadate')['pctOfComp_bb'].apply(yu.uniformed_rank).values
icom['pct_ofComp_df20d_0crk'] = icom.groupby('datadate')['pct_ofComp_df20d'].apply(lambda x: yu.uniformed_rank(x,str_type='zero_cutoff')).values
icom['pct_ofComp_df20d_bk'] = icom.groupby('datadate')['pct_ofComp_df20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['pctOfComp_bb_df20d_bk'], 'pctOfComp_bb_df20d') # -2 -4 +5 +3

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['pctOfComp_bb_df20d_0crk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_df20d_0crk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.14/-3.49
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['pctOfComp_bb_df20d_rk']>0)].\
            dropna(subset=['pctOfComp_bb_df20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_bb_df20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.14/-3.31


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')&(icom['pct_ofComp_df20d_0crk']>0)].\
            dropna(subset=['pct_ofComp_df20d_0crk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofComp_df20d_0crk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 5.12/0.67


icom['pct_ofComp_df20d_ma20_rk'] = icom.groupby('datadate')['pct_ofComp_df20d_ma20'].apply(yu.uniformed_rank).values
icom['pct_ofComp_df20d_ma10_rk'] = icom.groupby('datadate')['pct_ofComp_df20d_ma10'].apply(yu.uniformed_rank).values

icom['pct_ofComp_df20d_ma5_rk'] = icom.groupby('datadate')['pct_ofComp_df20d_ma5'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')&(icom['pct_ofComp_df20d_ma20_rk']>0)].\
            dropna(subset=['pct_ofComp_df20d_ma20_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofComp_df20d_ma20_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.34/1.92, 1.3bp/d
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')&(icom['pct_ofComp_df20d_ma10_rk']>0)].\
            dropna(subset=['pct_ofComp_df20d_ma10_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofComp_df20d_ma10_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.07/2.03, 1.34bp/d
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')&(icom['pct_ofComp_df20d_ma5_rk']>0)].\
            dropna(subset=['pct_ofComp_df20d_ma5_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofComp_df20d_ma5_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 4.3/1.87, 1.23bp/d


icom['pct_ofComp_df20d_sgnl'] = np.nan
c1 = icom['pct_ofComp_df20d_rk'].abs()>=0.8
icom.loc[c1, 'pct_ofComp_df20d_sgnl'] = icom.loc[c1, 'pct_ofComp_df20d_rk']
icom['pct_ofComp_df20d_sgnl'] = icom.groupby('ticker')['pct_ofComp_df20d_sgnl'].ffill(limit=20)


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')&(icom['pct_ofComp_df20d_sgnl']>0)].\
            dropna(subset=['pct_ofComp_df20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofComp_df20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.5 / 2.13, 2.29bp/d
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')&(icom['pct_ofComp_df20d_sgnl']<0)].\
            dropna(subset=['pct_ofComp_df20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofComp_df20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.06 / -1.62


### pct_ofComp  (1d delta)

icom['pct_ofComp_df1d_rk'] = icom.groupby('datadate')['pct_ofComp_df1d'].apply(yu.uniformed_rank).values
icom['pct_ofComp_df1d_0crk'] = icom.groupby('datadate')['pct_ofComp_df1d'].apply(lambda x: yu.uniformed_rank(x,str_type='zero_cutoff')).values
icom['pct_ofComp_df1d_bk'] = icom.groupby('datadate')['pct_ofComp_df1d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['pct_ofComp_df1d_bk'], 'pct_ofComp_df1d')
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='201
9-01-31')&(icom['pct_ofComp_df1d_rk']>0)].\
            dropna(subset=['pct_ofComp_df1d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofComp_df1d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 5.48 / -15.98


### pct_ofComp  (60d delta)

icom['pctOfComp_df60d'] = icom.groupby('ticker')['pctOfComp_bb'].apply(lambda x: x-x.shift(60)).values
icom['pctOfComp_df60d_ma5'] = icom.groupby('ticker').rolling(5)['pctOfComp_df60d'].mean().values
icom['pctOfComp_df60d_ma5_rk'] = icom.groupby('datadate')['pctOfComp_df60d_ma5'].apply(yu.uniformed_rank).values
icom['pctOfComp_df60d_ma5_bk'] = icom.groupby('datadate')['pctOfComp_df60d_ma5'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['pctOfComp_df60d_ma5_bk'], 'pctOfComp_df60d_ma5') # 0 -4 +4
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['pctOfComp_df60d_ma5_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_df60d_ma5_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.79/0.83, 0.64bp/d
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['pctOfComp_df60d_ma5_rk']>0)].\
            dropna(subset=['pctOfComp_df60d_ma5_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfComp_df60d_ma5_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.08/1.53, 1.46bp/d



### pct_ofComp (delta)  +  o2c

icom['adjret_o_c_t20d_rk'] = icom.groupby('datadate')['adjret_o_c_t20d'].apply(yu.uniformed_rank).values
icom['adjret_o_c_t20d_0crk'] = icom.groupby('datadate')['adjret_o_c_t20d'].apply(lambda x: yu.uniformed_rank(x,str_type='zero_cutoff')).values

icom['pct_ofComp_df20d_rk'] = icom.groupby('datadate')['pct_ofComp_df20d'].apply(yu.uniformed_rank).values
icom['pct_ofComp_df20d_0crk'] = icom.groupby('datadate')['pct_ofComp_df20d'].apply(lambda x: yu.uniformed_rank(x,str_type='zero_cutoff')).values

icom['pct_ofComp_df20d_m_o2c'] = icom['pct_ofComp_df20d_rk'] - icom['adjret_o_c_t20d_rk']
icom['pct_ofComp_df20d_m_o2c_rk'] = icom.groupby('datadate')['pct_ofComp_df20d_m_o2c'].apply(yu.uniformed_rank).values

icom['pct_ofComp_df20d_m0c_o2c'] = icom['pct_ofComp_df20d_0crk'] - icom['adjret_o_c_t20d_0crk']
icom['pct_ofComp_df20d_m0c_o2c_rk'] = icom.groupby('datadate')['pct_ofComp_df20d_m0c_o2c'].apply(yu.uniformed_rank).values

icom['pct_ofComp_df20d_m_o2c_sgnl'] = np.nan
c1 = icom['pct_ofComp_df20d_m_o2c_rk']>0.8
icom.loc[c1, 'pct_of
Comp_df20d_m_o2c_sgnl'] = icom.loc[c1, 'pct_ofComp_df20d_m_o2c_rk']
c2 = (icom['adjret_o_c_t20d_rk']>0.8) | (icom['pct_ofComp_df20d_m_o2c_rk']<-0.8)
icom.loc[c2, 'pct_ofComp_df20d_m_o2c_sgnl'] = 0
icom['pct_ofComp_df20d_m_o2c_sgnl'] = icom.groupby('ticker')['pct_ofComp_df20d_m_o2c_sgnl'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')&(icom['pct_ofComp_df20d_m_o2c_rk']>0)].\
            dropna(subset=['pct_ofComp_df20d_m_o2c_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofComp_df20d_m_o2c_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 4.94/0.36, 0.3bp/d

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['pct_ofComp_df20d_m_o2c_sgnl']>0)].\
            dropna(subset=['pct_ofComp_df20d_m_o2c_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofComp_df20d_m_o2c_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs decay from 2020.01 onwards




### pctOfHK  vs 300 index weight
t_300_total_heldDollar = icom[icom['csi300_flag']==1].groupby('datadate')['heldDollar'].sum().reset_index()
t_300_total_heldDollar = t_300_total_heldDollar.rename(columns={'heldDollar':'heldDollar_300total'})

icom2 = icom.merge(t_300_total_heldDollar, on = ['datadate'], how = 'left')
icom2['pct_within_HK300'] = icom2['heldDollar'].divide(icom2['heldDollar_300total'])
icom2.loc[icom2['csi300_flag']!=1, 'pct_within_HK300'] = np.nan
icom2['hk_m_300'] = icom2['pct_within_HK300'] - icom2['w300']
icom2['hk_m_300_rk'] = icom2.groupby('datadate')['hk_m_300'].apply(yu.uniformed_rank).values
icom2['hk_m_300_bk'] = icom2.groupby('datadate')['hk_m_300'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom2[icom2.datadate>='2016-08-01'], ['hk_m_300_bk'], 'hk_m_300') # random

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-01-31')].\
            dropna(subset=['hk_m_300_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'hk_m_300_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs -0.77/1.35

# pctOfHK300 
icom2['pct_within_HK300_bk']=icom2.groupby('datadate')['pct_within_HK300'].apply(lambda x:yu.pdqcut(x,bins=5)).values
icom3 = icom2[icom2['pct_within_HK300_bk']==4] 
icom3['w300_bk'] = icom3.groupby('datadate')['w300'].apply(lambda x: yu.pdqcut(x,bins=5)).values
yu.create_cn_3x3(icom3, ['w300_bk'], 'w300') # 

icom3 = icom2[icom2['pct_within_HK300_bk']==0] 
icom3['w300_bk'] = icom3.groupby('datadate')['w300'].app
ly(lambda x: yu.pdqcut(x,bins=5)).values
yu.create_cn_3x3(icom3, ['w300_bk'], 'w300') # 




### pctOfHK  vs 300 index weight, v2 as of 20220804


t_300_total_heldDollar = icom[icom['csi300_flag']==1].groupby('datadate')['dollarHeld_bb'].sum().reset_index()
t_300_total_heldDollar = t_300_total_heldDollar.rename(columns={'dollarHeld_bb':'heldDollar_300total'})

icom2 = icom.merge(t_300_total_heldDollar, on = ['datadate'], how = 'left')
icom2['pct_within_HK300'] = icom2['dollarHeld_bb'].divide(icom2['heldDollar_300total'])
icom2.loc[icom2['csi300_flag']!=1, 'pct_within_HK300'] = np.nan
icom2['hk_m_300'] = icom2['pct_within_HK300'] / icom2['w300'] -1
icom2['hk_m_300_rk'] = icom2.groupby('datadate')['hk_m_300'].apply(yu.uniformed_rank).values
icom2['hk_m_300_bk'] = icom2.groupby('datadate')['hk_m_300'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom2[icom2.datadate>='2016-08-01'], ['hk_m_300_bk'], 'hk_m_300') # less mono: -10 +4 0



### pctOfHK vs 500 index weight
t_500_total_heldDollar = icom[icom['w500'].notnull()].groupby('datadate')['heldDollar'].sum().reset_index()
t_500_total_heldDollar = t_500_total_heldDollar.rename(columns={'heldDollar':'heldDollar_500total'})

icom2 = icom.merge(t_500_total_heldDollar, on = ['datadate'], how = 'left')
icom2['pct_within_HKall_500'] = icom2['heldDollar'].divide(icom2['heldDollar_500total'])
icom2['hk_m_500'] = icom2['pct_within_HKall'] - icom2['w500']*100
icom2['hk_m_500_rk'] = icom2.groupby('datadate')['hk_m_500'].apply(yu.uniformed_rank).values
icom2['hk_m_500_bk'] = icom2.groupby('datadate')['hk_m_500'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom2['pct_within_HKall_rk'] = icom2.groupby('datadate')['pct_within_HKall'].apply(yu.uniformed_rank).values
icom2['w500_rk'] = icom2.groupby('datadate')['w500'].apply(yu.uniformed_rank).values
icom2['hk_m_500_rkdf'] = icom2['pct_within_HKall_rk'] - icom2['w500_rk']
icom2['hk_m_500_rkdf_rk'] = icom2.groupby('datadate')['hk_m_500_rkdf'].apply(yu.uniformed_rank).values
icom2['hk_m_500_rkdf_bk'] = icom2.groupby('datadate')['hk_m_500_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values


icom2['hk_m_500_sgnl'] = -icom2['hk_m_500_rk']

icom2['hk_m_500_sgnl2'] = np.nan
c1 = icom2['hk_m_500_sgnl'].abs()>0.8
icom2.loc[c1, 'hk_m_500_sgnl2'] = icom2.loc[c1, 'hk_m_500_sgnl']
icom2['hk_m_500_sgnl2'] = icom2.groupby('ticker')['hk_m_500_sgnl2'].ffill(limit=20)

icom2['hk_m_500_rkdf_sgnl'] = np.nan
c1 = icom2['hk_m_500_rkdf_rk'].abs()>0.8
icom2.loc[c1, 'hk_m_500_rkdf
_sgnl'] = icom2.loc[c1, 'hk_m_500_rkdf_rk']
icom2['hk_m_500_rkdf_sgnl'] = icom2.groupby('ticker')['hk_m_500_rkdf_sgnl'].ffill(limit=20)

yu.create_cn_3x3(icom2, ['hk_m_500_bk'], 'hk_m_500') # not 100% mono, +2,-2
yu.create_cn_3x3(icom2, ['hk_m_500_rkdf_bk'], 'hk_m_500_rkdf') # -4, +6, mono except for high area
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-01-31')].\
            dropna(subset=['hk_m_500_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'hk_m_500_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.35/0.84
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-01-31')].\
            dropna(subset=['hk_m_500_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'hk_m_500_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.52/0.27
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-01-31')].\
            dropna(subset=['hk_m_500_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'hk_m_500_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.94/0.94
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-01-31')&(icom2['hk_m_500_rkdf_sgnl']<0)].\
            dropna(subset=['hk_m_500_rkdf_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'hk_m_500_rkdf_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.94/0.94




### pctOfHK vs pct_ofMF

icom['pct_ofHK_m_mf'] = icom['pct_within_HKall'] - icom['pct_ofMF']
icom['pct_ofHK_m_mf_rk'] = icom.groupby('datadate')['pct_ofHK_m_mf'].apply(yu.uniformed_rank).values
icom['pct_ofHK_m_mf_bk'] = icom.groupby('datadate')['pct_ofHK_m_mf'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['pct_ofHK_m_mf_bk'], 'pct_ofHK_m_mf') # not mono


icom['pct_ofHK_p_mf'] = icom['pct_within_HKall'] + icom['pct_ofMF']
icom['pct_ofHK_p_mf_rk'] = icom.groupby('datadate')['pct_ofHK_p_mf'].apply(yu.uniformed_rank).values
icom['pct_ofHK_p_mf_bk'] = icom.groupby('datadate')['pct_ofHK_p_mf'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['pct_ofHK_p_mf_bk'], 'pct_ofHK_p_mf') # 
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')&(icom['pct_ofHK_p_mf_rk']>0)].\
            dropna(subset=['pct_ofHK_p_mf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofHK_p_mf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.17/2.46, 1.01bp/d


icom['pct_within_HKall_rk'] = icom.groupby('datada
te')['pct_within_HKall'].apply(yu.uniformed_rank).values
icom['pct_within_HKall_bk'] = icom.groupby('datadate')['pct_within_HKall'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['pct_within_HKall_bk'], 'pct_within_HKall') # mono -8,+1
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')&(icom['pct_within_HKall_rk']>0)].\
            dropna(subset=['pct_within_HKall_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_within_HKall_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.77/3.83, 1.37bp/d, 51bp edge


icom['pct_ofMF_rk'] = icom.groupby('datadate')['pct_ofMF'].apply(yu.uniformed_rank).values
icom['pct_ofMF_bk'] = icom.groupby('datadate')['pct_ofMF'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['pct_ofMF_bk'], 'pct_ofMF') # mono -3.5, +1
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')&(icom['pct_ofMF_rk']>0)].\
            dropna(subset=['pct_ofMF_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofMF_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.33/1.68


icom['pct_ofMC'] = icom.groupby('datadate')['MC_l1d_x'].apply(lambda x: x/x.sum()).values
icom['pct_ofMC_rk'] = icom.groupby('datadate')['pct_ofMC'].apply(yu.uniformed_rank).values
icom['pct_ofMF_ofMC_rkdf']  = icom['pct_ofMF_rk'] - icom['pct_ofMC_rk']
icom['pct_ofMF_ofMC_rkdf_rk'] = icom.groupby('datadate')['pct_ofMF_ofMC_rkdf'].apply(yu.uniformed_rank).values
icom['pct_ofMF_ofMC_rkdf_bk'] = icom.groupby('datadate')['pct_ofMF_ofMC_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['pct_ofMF_bk'], 'pct_ofMF') # close to monom -4 +1
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')&(icom['pct_ofMF_ofMC_rkdf_rk']>0)].\
            dropna(subset=['pct_ofMF_ofMC_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofMF_ofMC_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.93/1.26


### pctOfBB


icom['pctOfBB'] = icom.groupby('datadate')['dollarHeld_bb'].apply(lambda x: x/x.sum()).values
icom['pctOfBB_rk'] = icom.groupby('datadate')['pctOfBB'].apply(yu.uniformed_rank).values
icom['pctOfBB_bk'] = icom.groupby('datadate')['pctOfBB'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['pctOfBB_bk'], 'pctOfBB') # -12 +4 +1

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['pctOfBB_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subse
t=['ticker','datadate']),
            'pctOfBB_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.76/1.8
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['pctOfBB_rk']>0)].\
            dropna(subset=['pctOfBB_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfBB_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.25/1.29
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['pctOfBB_rk']<0)].\
            dropna(subset=['pctOfBB_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pctOfBB_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 5.72/2.23, 2.5bp/d



### holding: MF - ETF

i_c_raw = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate, s_dq_close as c from wind.dbo.ashareeodprices''')
i_c_raw['datadate'] = pd.to_datetime(i_c_raw['datadate'], format='%Y%m%d')
i_const_grp = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_etf_holding.parquet')
i_const_grp = i_const_grp.merge(i_c_raw, on = ['ticker','datadate'], how ='left')
i_const_grp['heldDollar_etf'] = i_const_grp['c'].multiply(i_const_grp['shares_by_etf'])

icom = icom.merge(i_const_grp, on = ['ticker','datadate'], how ='left')
icom['dollarHeld_mf_active'] = icom['heldDollar_mf'] - icom['heldDollar_etf']
icom['pct_ofMFActive'] = icom.groupby('datadate')['dollarHeld_mf_active'].apply(lambda x: x/x.sum()).values
icom['pct_ofMFActive_rk'] = icom.groupby('datadate')['pct_ofMFActive'].apply(yu.uniformed_rank).values
icom['pct_ofMFActive_bk'] = icom.groupby('datadate')['pct_ofMFActive'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['pct_ofMFActive_bk'], 'pct_ofMFActive') # mono, -2.5, +1

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')&(icom['pct_ofMFActive_rk']<0)].\
            dropna(subset=['pct_ofMFActive_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofMFActive_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.36/1.72




### pct_ofComp high, but etf holding low 
icom['pct_ofComp_rk'] = icom.groupby('datadate')['pct_ofComp'].apply(yu.uniformed_rank).values
icom['pct_ofComp_5bk'] = icom.groupby('datadate')['pct_ofComp'].apply(lambda x: yu.pdqcut(x,bins=5)).values
icom['pct_ofComp_etf'] = icom['shares_by_etf'].divide(icom['est_float_so'])
icom['pct_ofComp_etf_rk'] = icom.groupby('datadate')['pct_ofComp_etf'].apply(yu.uniformed_rank).values
icom['pct_ofComp_etf_5bk'] = icom.groupby('datadate')['pct_ofC
omp_etf'].apply(lambda x: yu.pdqcut(x,bins=5)).values
icom['pct_ofComp_hk_etf_rkdf'] = icom['pct_ofComp_rk'] - icom['pct_ofComp_etf_rk']
icom['pct_ofComp_hk_etf_rkdf_rk'] = icom.groupby('datadate')['pct_ofComp_hk_etf_rkdf'].apply(yu.uniformed_rank).values
icom['pct_ofComp_hk_etf_rkdf_bk'] = icom.groupby('datadate')['pct_ofComp_hk_etf_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values


icom['pct_ofComp_hk_etf_df'] = icom['pct_ofComp'] - icom['pct_ofComp_etf']*100
icom['pct_ofComp_hk_etf_df_rk'] = icom.groupby('datadate')['pct_ofComp_hk_etf_df'].apply(yu.uniformed_rank).values
icom['pct_ofComp_hk_etf_df_bk'] = icom.groupby('datadate')['pct_ofComp_hk_etf_df'].apply(lambda x: yu.pdqcut(x,bins=10)).values



yu.create_cn_3x3(icom, ['pct_ofComp_hk_etf_rkdf_bk'], 'pct_ofComp_hk_etf_rkdf')
yu.create_cn_3x3(icom, ['pct_ofComp_hk_etf_df_bk'], 'pct_ofComp_hk_etf_df')

yu.create_cn_3x3(icom[icom['pct_ofComp_etf_5bk']==4], ['pct_ofComp_5bk'], 'pct_ofComp')
yu.create_cn_3x3(icom[icom['pct_ofComp_etf_5bk']==0], ['pct_ofComp_5bk'], 'pct_ofComp')



o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')].\
            dropna(subset=['pct_ofComp_hk_etf_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofComp_hk_etf_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #3.7/1.83, 1.19bp/d

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')].\
            dropna(subset=['pct_ofComp_hk_etf_df_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofComp_hk_etf_df_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.35/2.08, 1.39bp/d
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-01-31')&(icom['pct_ofComp_hk_etf_df_rk']>0)].\
            dropna(subset=['pct_ofComp_hk_etf_df_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofComp_hk_etf_df_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.35/2.76, 2.27bp/d



