﻿#$%^&* pDataYes_recruit_05c.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 24 13:23:24 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import zipfile
import csv

import jieba

# 5c is simialr to 5b, except that this is for hk universe





GSEC = {'10':'energy','15':'materials','20':'industrials','25':'consumer discretionary',
        '30':'consumer_staples','35':'healthcare','40':'financials','45':'IT',
        '50':'communication services','55':'utilities','60':'real estate'}

### get ind

i_ind = yu.get_sql('''select datadate, ticker, gsector, ggrop, gind, gsubind 
                   FROM [CNDB].[dbo].[UNIVERSE_ALL_CN]
                   where datadate >= '2016-01-01' ''')
c_sh = i_ind['ticker'].str[0].isin(['6'])
c_sz = i_ind['ticker'].str[0].isin(['3','0'])
i_ind.loc[c_sh, 'ticker'] = i_ind.loc[c_sh, 'ticker'] + '.SH'
i_ind.loc[c_sz, 'ticker'] = i_ind.loc[c_sz, 'ticker'] + '.SZ'


### get sd
i_sd = pw.get_ashare_hk_sd_v2()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','a50_300_flag','a50_flag']]

i_sd_map_300 =i_sd_map[i_sd_map['a50_300_flag']==1]
i_sd_datadate_sr = i_sd_map_300['datadate'].drop_duplicates()
i_sd_map_50  = i_sd_map[i_sd_map['a50_flag']==1]


#------------------------------------------------------------------------------
### identify comparable jobs

i_p = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet')

i_raw = pd.DataFrame()
for p in i_p[:-1]:
    
    print(p)
    t_data = pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet', p))
        
    t_data = t_data[t_data['source'].isin(['51job'])] ###!!!
    t_data = t_data[t_data['title'].notnull()]###!!!
    #t_data = t_data[t_data['title'].str.contains('工程师|数据|智能|自动')] ###!!!
    
    t_data['publish_date'] = pd.to_datetime(pd.to_datetime(t_data['published_at']).dt.date)
    t_data['datadate'] = t_data['publish_date'] + pd.to_timedelta('1 day')
    
    t_data = t_data[t_data['ticker_symbol'].notnull()]
    t_data = t_data[t_data['ticker_symbol'].str.contains('\d{6}')]
    t_data.loc[t_data['ticker_symbol'].str.len()!=6, 'ticker_symbol'] = np.nan
    c_sh = t_data['ticker_symbol'].str[0].isin(['6'])
    c_sz = t_data['
ticker_symbol'].str[0].isin(['0', '3'])
    t_data.loc[c_sh, 'ticker'] = t_data.loc[c_sh, 'ticker_symbol'] + '.SH'
    t_data.loc[c_sz, 'ticker'] = t_data.loc[c_sz, 'ticker_symbol'] + '.SZ'
    
    t_data = t_data[t_data['ticker'].notnull()]
    
    t_data = t_data.sort_values('datadate')
    i_ind = i_ind.sort_values('datadate')
    
    t_data = pd.merge_asof(t_data, i_ind, by='ticker', on = 'datadate')
    t_data = t_data.sort_values(['ticker','datadate'])
    t_data['gsector'] = t_data.groupby('ticker')['gsector'].ffill()
    t_data['ggrop'] = t_data.groupby('ticker')['ggrop'].ffill()
    t_data['gind'] = t_data.groupby('ticker')['gind'].ffill()
    t_data['gsubind'] = t_data.groupby('ticker')['gsubind'].ffill()
    
    #t_data = t_data[t_data['gsector']=='45'] ###!!!

    i_raw = i_raw.append(t_data, sort = False)
    



###------------------------------------------------------------------------------
### trailing 1 year job counts

i_raw300 = i_raw[i_raw.ticker.isin(i_sd_map['ticker'].unique().tolist())]


# trailing 1 year job counts



i_tk_t1y_lst = []
for dt in pd.date_range(start = '2017-01-01', end = '2020-12-31'):
    print('.', end='')
    
    # 51job
    
    t_data = i_raw300[(i_raw300['source']=='51job')&(i_raw300['datadate']<=dt) & (i_raw300['datadate']>=dt-pd.to_timedelta('365 days'))]
    if len(t_data) == 0:
        continue
    
    #t_data['annual_salary_rk'] = yu.uniformed_rank(t_data['annual_salary_range_start']).values
    #t_data.loc[(t_data['annual_salary_rk']>0.9) |(t_data['annual_salary_rk']<-0.9), 'annual_salary_range_start'] = np.nan
    #t_data['annual_salary_rk'] = yu.uniformed_rank(t_data['annual_salary_range_start']).values    
    #SALARY_LMT = t_data.loc[t_data['annual_salary_rk'].between(0.2,0.6), 'annual_salary_range_start'].median()
    t_data = t_data[t_data['annual_salary_range_start']>=120000] ###!!!
    
    t_data = t_data.drop_duplicates(subset = ['ticker', 'title', 'company_info_id', 'working_address', 
                                              'publish_date','datadate'], keep = 'last') ###!!! dedup    
    
    t_tk_t1y_cnt = t_data.groupby('ticker')['id'].nunique().reset_index()
    t_tk_t1y_cnt['datadate'] = dt
    t_tk_t1y_cnt = t_tk_t1y_cnt.rename(columns={'id':'id_t1y'})
    
    t_data_1y = i_raw300[(i_raw300['source']=='51job')&(i_raw300['datadate']<=dt-pd.to_timedelta('365 days')) & (i_raw300['datadate']>=dt-pd.to_timedelta('730 days'))]
    t_data_1y = t_data_1y[t_data_1y['annual_salary_ran
ge_start']>=120000] ###!!!
    t_data_1y = t_data_1y.drop_duplicates(subset = ['ticker', 'title', 'company_info_id', 'working_address', 
                                                    'publish_date','datadate'], keep = 'last')
    t_tk_t1y_1y_cnt = t_data_1y.groupby('ticker')['id'].nunique().reset_index()
    t_tk_t1y_1y_cnt['datadate'] = dt
    t_tk_t1y_1y_cnt = t_tk_t1y_1y_cnt.rename(columns={'id':'id_t1y_1y'})
    
    
    
#    t_tkEmp_t1y_cnt = t_data.groupby(['ticker','employer'])['id'].nunique().reset_index()
#    t_tkEmp_t1y_cnt = t_tkEmp_t1y_cnt.rename(columns={'id':'idEmp'})
#    t_tkEmp_t1y_1y_cnt = t_data_1y.groupby(['ticker','employer'])['id'].nunique().reset_index()
#    t_tkEmp_t1y_1y_cnt = t_tkEmp_t1y_1y_cnt.rename(columns={'id':'idEmp_1y'})
#    t_tkEmp_t1y_cnt = t_tkEmp_t1y_cnt.merge(t_tkEmp_t1y_1y_cnt, on='ticker', how='outer')
#    t_tkEmp_t1y_cnt = t_tkEmp_t1y_cnt.dropna()    
#    t_tkEmp_t1y_cnt['idEmp_yy'] = t_tkEmp_t1y_cnt['idEmp'].divide(t_tkEmp_t1y_cnt['idEmp_1y'])-1
#    t_tkEmp_t1y_cnt['idEmp_df1y'] = t_tkEmp_t1y_cnt['idEmp'] - t_tkEmp_t1y_cnt['idEmp_1y']
#    
#    t_tk_t1y_emp = t_tkEmp_t1y_cnt.groupby('ticker')['idEmp_yy'].agg(['mean','median']).reset_index()
#    t_tk_t1y_emp = t_tk_t1y_emp.rename(columns={'mean':'edEmp_yy_mean','median':'edEmp_yy_median'})
#    t_tk_t1y_emp2 = t_tkEmp_t1y_cnt.groupby('ticker')[['idEmp_yy','idEmp_1y']].apply(lambda x: x['idEmp_yy'].multiply(x['idEmp_1y']).sum()/x['idEmp_1y'].sum()).reset_index()
#    t_tk_t1y_emp2 = t_tk_t1y_emp2.rename(columns={0: 'edEmp_yy_w'})
#    t_tk_t1y_emp3 = t_tkEmp_t1y_cnt.groupby('ticker')['idEmp_df1y'].sum().reset_index()
#    
#    t_tk_t1y_emp = t_tk_t1y_emp.merge(t_tk_t1y_emp2, on='ticker', how = 'outer')
#    t_tk_t1y_emp = t_tk_t1y_emp.merge(t_tk_t1y_emp3, on='ticker', how = 'outer')
#    t_tk_t1y_emp['datadate'] = dt
#    
    
#    # liepin
#    
#    t_data2 = i_raw300[(i_raw300['source']=='猎聘网')&(i_raw300['datadate']<=dt) & (i_raw300['datadate']>=dt-pd.to_timedelta('365 days')) ]
#    t_data2 = t_data2[t_data2['annual_salary_range_start']>=12e4] ###!!!
#    
#    t_data2 = t_data2.drop_duplicates(subset = ['ticker', 'title', 'company_info_id', 'working_address', 
#                                              'publish_date','datadate'], keep = 'last') ###!!! dedup    
#    
#    t_tk2_t1y_cnt = t_data2.groupby('ticker')['id'].nunique().reset_index()
#    t_tk2_t1y_cnt['datadate'] = dt
#    t_tk2_t1y_cnt = t_tk2_t1y_cnt.rename(columns={'id':'idLp_t
1y'})
#    
#    
#    t_data2_1y = i_raw300[(i_raw300['source']=='猎聘网')&(i_raw300['datadate']<=dt-pd.to_timedelta('365 days')) & (i_raw300['datadate']>=dt-pd.to_timedelta('730 days'))]
#    t_data2_1y = t_data2_1y[t_data2_1y['annual_salary_range_start']>=12e4] ###!!!
#    t_data2_1y = t_data2_1y.drop_duplicates(subset = ['ticker', 'title', 'company_info_id', 'working_address', 
#                                                    'publish_date','datadate'], keep = 'last')
#    t_tk2_t1y_1y_cnt = t_data2_1y.groupby('ticker')['id'].nunique().reset_index()
#    t_tk2_t1y_1y_cnt['datadate'] = dt
#    t_tk2_t1y_1y_cnt = t_tk2_t1y_1y_cnt.rename(columns={'id':'idLp_t1y_1y'})
#    
    # combine
    
    t_tk_t1y_cnt = t_tk_t1y_cnt.merge(t_tk_t1y_1y_cnt, on=['ticker','datadate'], how = 'outer' )
    #t_tk_t1y_cnt = t_tk_t1y_cnt.merge(t_tk_t1y_emp, on=['ticker','datadate'], how = 'outer' )
    #t_tk_t1y_cnt = t_tk_t1y_cnt.merge(t_tk2_t1y_cnt, on=['ticker','datadate'], how = 'outer' )
    #t_tk_t1y_cnt = t_tk_t1y_cnt.merge(t_tk2_t1y_1y_cnt, on=['ticker','datadate'], how = 'outer'  )
    i_tk_t1y_lst.append(t_tk_t1y_cnt)
    

i_tk_t1y_cnt = pd.concat(i_tk_t1y_lst, sort = False)





### get historical mc

i_mc = yu.get_sql('''select ticker, datadate, mc from [CNDB].[dbo].[UNIVERSE_ALL_CN] 
                    where ticker in ('{0}') '''.format("','".join( i_sd_map['ticker'].str[:6].unique().tolist() )))
i_mc['datadate_1y'] = i_mc['datadate'] - pd.to_timedelta('365 days')
i_mc['datadate_1q'] = i_mc['datadate'] - pd.to_timedelta('91 days')


i_mc = i_mc.sort_values('datadate')

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1q', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1q'})

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1y', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1y'})
i_mc = i_mc.drop(columns = ['datadate_1q', 'datadate_1y'])


c_sh = i_mc['ticker'].str[0].isin(['6'])
c_sz = i_mc['ticker'].str[0].isin(['0', '3'])
i_mc.loc[c_sz, 'ticker'] = i_mc.loc[c_sz, 'ticker'] + '.SZ'
i_mc.loc[c_sh, 'ticker'] = i_mc.loc[c_sh, 'ticker'] + '.SH'

    


### get asset 
i_bs = yu.get_sql('''select ann_
dt, s_info_windcode as ticker, report_period, 
                  TOT_CUR_ASSETS as c_asset, TOT_ASSETS as t_asset,
                  TOT_SHRHLDR_EQY_INCL_MIN_INT as eqy, TOT_LIAB as liab 
                  from [WIND].[dbo].[ASHAREBALANCESHEET]
                  where statement_type = '408001000' ''')

i_bs = i_bs[i_bs['ann_dt'].notnull()]
i_bs['datadate'] = pd.to_datetime(i_bs['ann_dt'], format='%Y%m%d')
i_bs['report_period'] = pd.to_datetime(i_bs['report_period'], format = '%Y%m%d')
i_bs = i_bs.drop(columns = ['ann_dt'])

i_bs = i_bs.sort_values(['ticker','datadate'])
i_bs['max_report_date'] = i_bs.groupby('ticker')['report_period'].cummax()
i_bs = i_bs[i_bs['report_period']>=i_bs['max_report_date']]

i_bs = i_bs.drop(columns = ['report_period', 'max_report_date'])
i_bs = i_bs.sort_values('datadate')


i_bs = pd.merge_asof(i_sd_map[['ticker','datadate']].sort_values('datadate'), 
                     i_bs[['c_asset','t_asset','ticker','datadate']], 
                     by = 'ticker', on = 'datadate')
i_bs['datadate_1y'] = i_bs['datadate'] - pd.to_timedelta('365 days')
i_bs['datadate_1q'] = i_bs['datadate'] - pd.to_timedelta('91 days')

i_bs = pd.merge_asof(i_bs, i_bs[['c_asset','t_asset','ticker','datadate']],
                     by='ticker', left_on='datadate_1y', right_on='datadate',suffixes=['','_m'])
i_bs = i_bs.drop(columns=['datadate_m'])
i_bs = i_bs.rename(columns={'c_asset_m':'c_asset_1y','t_asset_m':'t_asset_1y'})

i_bs = pd.merge_asof(i_bs, i_bs[['c_asset','t_asset','ticker','datadate']],
                     by='ticker', left_on='datadate_1q', right_on='datadate',suffixes=['','_m'])
i_bs = i_bs.drop(columns=['datadate_m'])
i_bs = i_bs.rename(columns={'c_asset_m':'c_asset_1q','t_asset_m':'t_asset_1q'})



### combine

icom_300 = i_sd_map_300.merge(i_tk_t1y_cnt, on = ['ticker', 'datadate'], how = 'left') ###!!!

icom_300 = icom_300.merge(i_bs, on = ['ticker', 'datadate'], how = 'left')
icom_300 = icom_300.merge(i_mc, on = ['ticker', 'datadate'], how = 'left')

icom_300 = icom_300.sort_values(['ticker','datadate'])



### standard tests

icom2 = icom_300.copy()

# ttm count
icom2['ttm_cnt_rk'] = icom2.groupby('datadate')['id_t1y'].apply(yu.uniformed_rank).values

# ttm count / denom
icom2['ttm_cnt_dv_mc'] = icom2['id_t1y'].divide(icom2['mc'])
icom2['ttm_cnt_dv_mc_rk'] = icom2.groupby('datadate')['ttm_cnt_dv_mc'].apply(yu.uniformed_rank).values

icom2['ttm_cnt_dv_ta'] = icom2['id_t1y'].divide(icom2['t_asset'])
icom2['ttm_cnt_dv_ta_rk'] = icom2.g
roupby('datadate')['ttm_cnt_dv_ta'].apply(yu.uniformed_rank).values

# ttm count df1y / denom-1y
icom2['ttm_cnt_df1y'] = icom2['id_t1y'] - icom2['id_t1y_1y']
icom2['ttm_cnt_df1y_rk'] = icom2.groupby('datadate')['ttm_cnt_df1y'].apply(yu.uniformed_rank).values
icom2['ttm_cnt_df1y_dv_mc'] = icom2['ttm_cnt_df1y'].divide(icom2['mc_1y'])
icom2['ttm_cnt_df1y_dv_mc_rk'] = icom2.groupby('datadate')['ttm_cnt_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['ttm_cnt_df1y_dv_ta'] = icom2['ttm_cnt_df1y'].divide(icom2['t_asset_1y'])
icom2['ttm_cnt_df1y_dv_ta_rk'] = icom2.groupby('datadate')['ttm_cnt_df1y_dv_ta'].apply(yu.uniformed_rank).values
icom2['ttm_cnt_df1y_dv_ta_secrk'] = icom2.groupby(['datadate','GSECTOR'])['ttm_cnt_df1y_dv_ta'].apply(yu.uniformed_rank).values
icom2['ttm_cnt_df1y_dv_ta_bk'] = icom2.groupby('datadate')['ttm_cnt_df1y_dv_ta'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom2['ttm_cnt_df1y_dv_ta_5bk'] = icom2.groupby('datadate')['ttm_cnt_df1y_dv_ta'].apply(lambda x: yu.pdqcut(x, bins=5)).values


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['datadate']>='2018-05-01')].\
            dropna(subset=['ttm_cnt_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ttm_cnt_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['datadate']>='2018-05-01')].\
            dropna(subset=['ttm_cnt_df1y_dv_ta_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ttm_cnt_df1y_dv_ta_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['datadate']>='2018-05-01')&(icom2['ttm_cnt_df1y_dv_ta_rk']>0.8)].\
            dropna(subset=['ttm_cnt_df1y_dv_ta_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ttm_cnt_df1y_dv_ta_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['datadate']>='2018-05-01')&(icom2['ttm_cnt_df1y_dv_ta_rk']>0.6)].\
            dropna(subset=['ttm_cnt_df1y_dv_ta_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ttm_cnt_df1y_dv_ta_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['datadate']>='2018-05-01')&\
                        (icom2['ttm_cnt_df1y_dv_ta_secrk']>0.6)&(icom2['GSECTOR']=='45')].\

            dropna(subset=['ttm_cnt_df1y_dv_ta_secrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ttm_cnt_df1y_dv_ta_secrk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.57 / 1.51 // 0.74 / 0.5

for s in GSEC.keys():
    print(GSEC[s])
    o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['datadate']>='2018-05-01')&\
                        (icom2['ttm_cnt_df1y_dv_ta_secrk']>0.6)&(icom2['GSECTOR']==s)].\
            dropna(subset=['ttm_cnt_df1y_dv_ta_secrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ttm_cnt_df1y_dv_ta_secrk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 



yu.create_cn_3x3(icom2, ['ttm_cnt_df1y_dv_ta_bk'], 'ttm_cnt_df1y_dv_ta')
yu.create_cn_3x3(icom2, ['ttm_cnt_df1y_dv_ta_5bk'], 'ttm_cnt_df1y_dv_ta')


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['datadate']>='2018-05-01')&(icom2['ttmMean_cnt_df1y_dv_ta_rk_rk']>0.6)].\
            dropna(subset=['ttmMean_cnt_df1y_dv_ta_rk_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ttmMean_cnt_df1y_dv_ta_rk_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['datadate']>='2018-05-01')&(icom2['ttmLp_cnt_df1y_dv_ta_rk']>0.8)].\
            dropna(subset=['ttmLp_cnt_df1y_dv_ta_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ttmLp_cnt_df1y_dv_ta_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #


