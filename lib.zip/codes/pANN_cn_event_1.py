﻿#$%^&* pANN_cn_event_1.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Sep  6 10:00:39 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime

import os


### sd 

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])


### sd stable shortable 

i_sd_ss = pw.get_china_ss_sd()


### tdate calendar

i_td = yu.get_sql_prod('''select datadate as impact_cdate, tradedate_next from cndbprod.dbo.Calendar_Dates_CN
                     order by datadate''')

i_td2 = yu.get_sql_prod('''select distinct tradedate_next as tdate from cndbprod.dbo.Calendar_Dates_CN
                        order by tradedate_next ''')


### get pastret

i_pastret = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet',
                            columns = ['ticker', 'datadate', 'c2c_bret','twap1000_2c_bret','twap1000_2c_bret_t4w'])
i_pastret['o2c_t20d_ark'] = i_pastret.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)
i_pastret = i_pastret.sort_values(['ticker','datadate'])




### get ann for impact_tdate
# based on manual inspection at 9:15 am Shanghai, data delayed for a max of 1 hour 

i_files = os.listdir(r'S:\TZ\China Data Hunt\ann_em')
i_ann = pd.concat([pd.read_parquet(os.path.join(r'S:\TZ\China Data Hunt\ann_em', i)) for i in i_files], sort=False)

i_ann['eiTime'] = pd.to_datetime(i_ann['eiTime'], format = '%Y-%m-%d %H:%M:%S:%f', errors='coerce')
i_ann['datadate'] = pd.to_datetime((i_ann['eiTime'] - pd.to_timedelta('3 hours')).dt.date)
i_ann['notice_date'] = pd.to_datetime(i_ann['notice_date'])

i_ann = i_ann.drop(columns = [ 'title_ch', 'new_column_code', 'notice_date'])

c_sh = i_ann['ticker'].str[0].isin(['6'])
c_sz = i_ann['ticker'].str[0].isin(['0','3'])
i_ann.loc[c_sh, 'ticker'] = i_ann.loc[c_sh, 'ticker']+ '.SH'
i_ann.loc[c_sz, 'ticker'] = i_ann.loc[c_sz, 'ticker']+ '.SZ'

c1 = i_ann['eiTime'].dt.strftime('%H%M')<='1450'
c2 = i_ann['eiTime'].dt.strftime('%H%M')>'1450'
i_ann.loc[c1, 'impact_cdate'] = pd.to_datetime(i_ann.loc[c1, 'eiTime'].dt.date)
i_ann.loc[c2, 'impact_cdate'] = pd.to_datetime(i_ann.loc[c2, 'eiTime'].dt.date) + pd.to_timedelta('1 day')
i_ann = i_ann.merge(i_td, on = 'impact_cdate', how = 'left')
i_ann = i_ann.rename(columns = {'tradedate_next': 'impact_tdate'})

i_ann = i_ann[['eiTime', 'title', 'ann_type_desc','ticker',  'impact_tdate']]

i_ann_s2 = i_ann.groupby(['ticker', 'impact_tdate']).agg({'title':lambda
 x: '|'.join(x.tolist()),'ann_type_desc':lambda x: '|'.join(x.tolist())})
i_ann_s2['flg_has_ann'] = 1
i_ann_s2 = i_ann_s2.reset_index()




### NB

i_nb = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\prepare_northbound_holding_bb.parquet')

i_nb = i_nb.groupby(['datadate_p1d','ticker'])['bb_shares'].sum().reset_index()






#------------------------------------------------------------------------------
### combine
#------------------------------------------------------------------------------

icom = i_sd.merge(i_ann_s2, left_on = ['ticker','datadate'], right_on = ['ticker','impact_tdate'], how = 'left')
icom = icom.merge(i_pastret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_nb, on = ['ticker', 'datadate_p1d'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['c2c_bret_rk'] = icom.groupby('datadate')['c2c_bret'].apply(yu.uniformed_rank)
icom['o2c_t1m_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)

icom['bb_shares_df1m_dv_so'] = (icom['bb_shares'] - icom.groupby('ticker')['bb_shares'].shift(20).values) / icom['FLOAT_l1d']
icom['bb_shares_df1m_dv_so_rk'] = icom.groupby('datadate')['bb_shares_df1m_dv_so'].apply(yu.uniformed_rank)


icom['flg_has_neg_ann'] = np.nan
c1 = icom['flg_has_ann'].eq(1) & icom['c2c_bret_rk'].lt(-0.8)
icom.loc[c1, 'flg_has_neg_ann'] = 1

icom['flg_has_pos_ann'] = np.nan
c1 = icom['flg_has_ann'].eq(1) & icom['c2c_bret_rk'].gt(0.8)
icom.loc[c1, 'flg_has_pos_ann'] = 1

icom['flg_has_neg_ann_t1m'] = icom.groupby('ticker').rolling(20,min_periods=1)['flg_has_neg_ann'].sum().values

icom['flg_low_n_nuy'] = np.nan
c1 = icom['flg_has_neg_ann_t1m'].gt(0) & icom['o2c_t1m_rk'].lt(-0.8) & icom['bb_shares_df1m_dv_so_rk'].gt(0.8)
icom.loc[c1, 'flg_low_n_nuy'] = 1

yu.create_cn_decay(icom, 'flg_low_n_nuy') # low alpha

icom['sgnl_low_n_nuy'] = icom.groupby('ticker')['flg_low_n_nuy'].ffill(limit=20)
o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2018-01-01','2021-06-30')].\
            dropna(subset=['sgnl_low_n_nuy','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_low_n_nuy','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.8 / 0.38
