﻿#$%^&* pGraph_cn_conews.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 23 06:47:02 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime




### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()


### get news data

i_company = pd.read_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\company.parquet',
                            columns = ['stockCode','newsId'])
i_company = i_company[i_company['stockCode'].str.contains('\d{6}') &\
                      i_company['stockCode'].str.contains('S[HZ]') &\
                      i_company['stockCode'].str[0].isin(['0','3','6']) ]
i_company['ticker'] = i_company['stockCode'].str.split('_').str[0]+'.'+i_company['stockCode'].str.split('_').str[1]
i_company = i_company.drop(columns=['stockCode'])
i_company = i_company.drop_duplicates(subset = ['ticker','newsId'])



i_info = pd.read_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\info.parquet',
                         columns = ['newsId','newsTs'])


i_news_com = i_company.merge(i_info, on = ['newsId'], how = 'left')
i_news_com['datadate'] = pd.to_datetime(pd.to_datetime(i_news_com['newsTs']).dt.date)+pd.to_timedelta('1 day')




### calculate corr matrix

o_shared_news_cnt = []

for dt in pd.date_range(start = '2016-02-01', end = '2021-11-01', freq='W'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    
    t_sd = i_sd[i_sd['datadate']==i_sd_dd[i_sd_dd<=dt].max()]
    
    t_news = i_news_com[(i_news_com['datadate']<=dt)&(i_news_com['datadate']>=dt-pd.to_timedelta('365 days'))&\
                        (i_news_com['ticker'].isin(t_sd['ticker'].tolist()))]
    t_tk_news_map = t_news.groupby('ticker')['newsId'].apply(lambda x: set(x))
    t_tk_news_map = t_tk_news_map.reset_index()
    
        
    t_tkPair_newsSet = pd.DataFrame((t_tk_news_map['newsId'].values[:, None] &\
                                      t_tk_news_map['newsId'].values))
    t_tkPair_newsSet = t_tkPair_newsSet.applymap(lambda x: len(x) )
    t_tkPair_newsSet.columns = t_tk_news_map['ticker'].values
    t_tkPair_newsSet.index = t_tk_news_map['ticker'].values
    t_tkPair_newsSet.values[[np.arange(t_tkPair_newsSet.shape[0])]*2] = 0
    
    t_sum1 = t_tkPair_newsSet.mean(axis = 1)
    t_sum1 = t_sum1.reset_index()
    t_sum1.columns = ['ticker','shared_newsCnt']
    
    t_sum = t_sum1.copy()
    t_sum['datadate'] = dt
   
 
    o_shared_news_cnt.append(t_sum)
    
o_shared_news_cnt = pd.concat(o_shared_news_cnt, axis = 0)

o_shared_news_cnt.to_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_conews_shared_news_cnt.parquet')


### combine 


icom = pd.merge_asof(i_sd, o_shared_news_cnt, by='ticker', on='datadate')

icom = icom.sort_values(['ticker','datadate'])

icom['shared_newsCnt_bk'] = icom.groupby('datadate')['shared_newsCnt'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['shared_newsCnt_rk'] = icom.groupby('datadate')['shared_newsCnt'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['shared_newsCnt_bk'], 'shared_newsCnt') # less mono: -1.5 0.5

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['shared_newsCnt_orth'] = icom.groupby('datadate')[COLS+['shared_newsCnt']].apply(lambda x: yu.orthogonalize_cn(x['shared_newsCnt'], x[COLS])).values
icom['shared_newsCnt_orth_bk'] = icom.groupby('datadate')['shared_newsCnt_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['shared_newsCnt_orth_rk'] = icom.groupby('datadate')['shared_newsCnt_orth'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['shared_newsCnt_orth_bk'], 'shared_newsCnt_orth') # mono: -3.5 +1


    
icom['orth_neg_sgnl'] = np.nan
icom.loc[icom['shared_newsCnt_orth_rk']<-0.8, 'orth_neg_sgnl']  = -1
icom['orth_neg_sgnl'] = icom.groupby('ticker')['orth_neg_sgnl'].ffill(limit=5)


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['orth_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'orth_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.5 / 1.03

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['csi300_flag']==1)].\
            dropna(subset=['orth_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'orth_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.03 / 0.8

