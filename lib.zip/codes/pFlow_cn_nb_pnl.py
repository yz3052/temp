﻿#$%^&* pFlow_cn_nb_pnl.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 27 10:59:59 2023

@author: thzhang
"""


import pandas as pd
import numpy as np

import datetime
import util as yu
import os


# trading pnl from bb investors doesn't work 


# todo
# how to adjust holdings w.r.t. dividend shares?
    
# ideas:    
# hold large number but not in uni ... sell only
# after hong gu, hk holding will increase
# 


### sd 

i_sd = yu.get_sd_cn_1800()


#---- hk
# 'Ticker', 'hk_b_shares', 'hk_c_shares', 'hk_bb_shares', 'craw', 'float', 'flg_cndb_hk', 'DataDate'
root_hk = '/dat/summit_capital/PROD/TZ/hk_holding/'
files_hk = os.listdir(root_hk)
i_nb = pd.concat([pd.read_parquet(root_hk + f) for f in files_hk], axis = 0)
i_nb = i_nb.sort_values(['Ticker', 'DataDate']).reset_index(drop = True)
i_nb['hk_bb_diff'] = i_nb['hk_bb_shares'] - i_nb.groupby('Ticker')['hk_bb_shares'].shift()
i_nb['hk_bb_diff_dv_so'] = i_nb['hk_bb_diff'] / i_nb['float']
i_nb['hk_bb_dv_so'] = i_nb['hk_bb_shares'] / i_nb['float']

i_nb['hk_c_diff'] = i_nb['hk_c_shares'] - i_nb.groupby('Ticker')['hk_c_shares'].shift()
i_nb['hk_c_diff_dv_so'] = i_nb['hk_c_diff'] / i_nb['float']
i_nb['hk_c_dv_so'] = i_nb['hk_c_shares'] / i_nb['float']

i_nb['hk_b_diff'] = i_nb['hk_b_shares'] - i_nb.groupby('Ticker')['hk_b_shares'].shift()
i_nb['hk_b_diff_dv_so'] = i_nb['hk_b_diff'] / i_nb['float']
i_nb['hk_b_dv_so'] = i_nb['hk_b_shares'] / i_nb['float']



### return

i_ret = yu.get_sql_wind('''select substring(s_info_windcode,1,6) as Ticker,
                   trade_dt as [T-1d], s_dq_close as c, s_dq_adjclose as cadj, 
                   s_dq_adjclose / s_dq_adjpreclose - 1 as rawret
                   from wind_prod.dbo.ashareeodprices
                   where trade_dt > '20180101'                   
                   ''')
i_ret['T-1d'] = pd.to_datetime(i_ret['T-1d'], format = '%Y%m%d')


#------------------------------------------------------------------------------
#---- test: hk pnl / nishi 
#------------------------------------------------------------------------------

# combine

icom = i_sd.merge(i_nb, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom.merge(i_ret, on = ['Ticker', 'T-1d'], how = 'left')
icom = icom.merge(i_ret[['T-1d','Ticker','rawret']].rename(columns={'T-1d':'DataDate','rawret':'RawRet+0d'}), 
                  on = ['Ticker', 'DataDate'], how = 'left')
icom = icom[icom['DataDate'].le('2021-12-31')]
icom = icom.sort_values(['Ticker', 'DataDate'])



icom['bb_pnl'] = icom['hk_bb_diff'] * icom['c'] * icom['RawRet+0d']
icom['bb_pnl'] = icom.groupby('Ticker')['bb_pnl'].shift()
icom['bb_pnl_dv_pv'] = icom['bb_pnl'] / icom['avgPVadj']
icom['bb_pnl_dv_pv_t20d'] = icom.groupby('Ticker').rolling(20)['bb_pnl_dv_pv'].mean().values
icom['hk_bb_diff_dv_so_t20d'] = icom.groupby('Ticker').rolling(20)['hk_bb_diff_dv_so'].mean().values
icom['hk_bb_diff_dv_so_t1y'] = icom.groupby('Ticker').rolling(252)['hk_bb_diff_dv_so'].mean().values
c1 = icom['hk_bb_diff_dv_so'] * icom['RawRet-1d'] < 0
icom.loc[c1, 'hk_bb_diff_dv_so_nishi'] = icom.loc[c1, 'hk_bb_diff_dv_so']
icom['hk_bb_diff_dv_so_nishi_t20d'] = icom.groupby('Ticker').rolling(20,min_periods = 1)['hk_bb_diff_dv_so_nishi'].sum().values
icom['hk_bb_diff_dv_so_nishi_t1q'] = icom.groupby('Ticker').rolling(63,min_periods = 1)['hk_bb_diff_dv_so_nishi'].sum().values
icom['hk_bb_diff_dv_so_nishi_t1y'] = icom.groupby('Ticker').rolling(252,min_periods = 1)['hk_bb_diff_dv_so_nishi'].sum().values



icom['bb_pnl_bk'] = icom.groupby('DataDate')['bb_pnl'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom, ['bb_pnl_bk'], 'bb_pnl')
icom['bb_pnl_dv_pv_bk'] = icom.groupby('DataDate')['bb_pnl_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom, ['bb_pnl_dv_pv_bk'], 'bb_pnl_dv_pv') # better v-shaped +2 -3 +2

icom['hk_bb_diff_dv_so_bk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom[icom['hk_bb_diff_dv_so_bk']==0], ['bb_pnl_dv_pv_bk'], 'bb_pnl_dv_pv') 
yu.create_cn_3x3_linux(icom[icom['hk_bb_diff_dv_so_bk']==9], ['bb_pnl_dv_pv_bk'], 'bb_pnl_dv_pv') 

icom['bb_pnl_dv_pv_t20d_bk'] = icom.groupby('DataDate')['bb_pnl_dv_pv_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom, ['bb_pnl_dv_pv_t20d_bk'], 'bb_pnl_dv_pv_t20d') #

icom['hk_bb_diff_dv_so_t20d_bk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom[icom['hk_bb_diff_dv_so_t20d_bk']==0], ['bb_pnl_dv_pv_t20d_bk'], 'bb_pnl_dv_pv_t20d') 
yu.create_cn_3x3_linux(icom[icom['hk_bb_diff_dv_so_t20d_bk']==9], ['bb_pnl_dv_pv_t20d_bk'], 'bb_pnl_dv_pv_t20d') 
yu.create_cn_3x3_linux(icom, ['hk_bb_diff_dv_so_t20d_bk'], 'hk_bb_diff_dv_so_t20d')

icom['hk_bb_diff_dv_so_t1y_bk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so_t1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom, ['hk_bb_diff_dv_so_t1y_bk']
, 'hk_bb_diff_dv_so_t1y')

icom['hk_bb_diff_dv_so_nishi_t20d_bk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so_nishi_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom, ['hk_bb_diff_dv_so_nishi_t20d_bk'], 'hk_bb_diff_dv_so_nishi_t20d')
# less mono: -1.5 +2.5

icom['hk_bb_diff_dv_so_nishi_t1q_bk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so_nishi_t1q'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['hk_bb_diff_dv_so_nishi_t1q_rk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so_nishi_t1q'].apply(yu.uniformed_rank)
yu.create_cn_3x3_linux(icom, ['hk_bb_diff_dv_so_nishi_t1q_bk'], 'hk_bb_diff_dv_so_nishi_t1q')
# mono: -2.5 +2 ###!!!
yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ].\
            dropna(subset=['hk_bb_diff_dv_so_nishi_t1q_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'hk_bb_diff_dv_so_nishi_t1q_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
# 2.4 / -2.4
    
icom['hk_bb_diff_dv_so_nishi_t1y_bk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so_nishi_t1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom, ['hk_bb_diff_dv_so_nishi_t1y_bk'], 'hk_bb_diff_dv_so_nishi_t1y')
# random

icom['hk_bb_dv_so_bk'] = icom.groupby('DataDate')['hk_bb_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom, ['hk_bb_dv_so_bk'], 'hk_bb_dv_so')
# -1 -6 +3 0
icom['hk_bb_dv_so_rk'] = icom.groupby('DataDate')['hk_bb_dv_so'].apply(yu.uniformed_rank)
yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ].\
            dropna(subset=['hk_bb_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'hk_bb_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
# 3.1 / -0.4




icom['bb_pnl_dv_pv_ma1q'] = icom.groupby('Ticker').rolling(63)['bb_pnl_dv_pv'].mean().values
icom['bb_pnl_dv_pv_sd1q'] = icom.groupby('Ticker').rolling(63)['bb_pnl_dv_pv'].std().values
icom['bb_pnl_dv_pv_sharpe_t1q'] = icom['bb_pnl_dv_pv_ma1q'] / icom['bb_pnl_dv_pv_sd1q']
icom['bb_pnl_dv_pv_sharpe_t1q'] = icom['bb_pnl_dv_pv_sharpe_t1q'].replace(np.inf,np.nan).replace(-np.inf,np.nan)

icom['bb_pnl_dv_pv_sharpe_t1q_bk'] = icom.groupby('DataDate')['bb_pnl_dv_pv_sharpe_t1q'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom, ['bb_pnl_dv_pv_sharpe_t1q_bk'], 'bb_pnl_dv_pv_sharpe_t1q')




icom['hk_bb_diff_dv_so_rk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so'].apply(yu.uniformed_r
ank)
icom['BarrRet_CLIP_USD-1d_rk'] = icom.groupby('DataDate')['BarrRet_CLIP_USD-1d'].apply(yu.uniformed_rank)
icom['RawRet-1d_rk'] = icom.groupby('DataDate')['RawRet-1d'].apply(yu.uniformed_rank)

icom = icom.sort_values(['Ticker', 'DataDate'])
icom['bret_t20d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=30),on='DataDate')['BarrRet_CLIP_USD-1d'].mean().values
icom['bret_t20d_rk'] = icom.groupby('DataDate')['bret_t20d'].apply(yu.uniformed_rank)
icom['bret_rk'] = icom.groupby('DataDate')['BarrRet_CLIP_USD-1d'].apply(yu.uniformed_rank)



yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ].\
            dropna(subset=['sgnl5','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl5','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.71 / 0.4
    
    
    
    
    
