﻿#$%^&* util.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Dec  6 17:19:06 2020

@author: thzhang
"""
import pandas as pd
import numpy as np

import numba
from numba import njit

import matplotlib.pyplot as plt
from pandas.plotting import table as ptable

import pyodbc
from sqlalchemy import create_engine
import urllib


from qpython import qconnection
import psycopg2

import datetime
import time
import os

import scipy
import scipy.stats as ss
from scipy.stats import norm
from statsmodels.formula.api import ols
import mosek






import qrcode 
def qrfile(p):
    f = p.split('/')[-1]
    txt=open(p,encoding='utf8').read()
    
    txt = '#$%^&* '+f+' #$%^&*\n'  + txt
    
    for i in range(0,len(txt)//2500+1):    
        t_data = txt[i*2500:i*2500+2500]
        qr = qrcode.QRCode(
            version=40,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(t_data)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        try:
            img.save('/dat/summit_capital/TZ/exit/' + f + '_' + str(i).zfill(3) + '.png')
        except:
            img.save('N:/exit/' + f + '_' + str(i).zfill(3) + '.png')







# this is the util package that can be used in linux env





proxies = {'http':'http://svc_pm_summit_dev:Feng_001!@proxy.mlp.com:3128',
           'https':'https://svc_pm_summit_dev:Feng_001!@proxy.mlp.com:3128'}




def pw():
    return open(r'/dat/summit_capital/TZ/PW.txt').read().replace('\n','')



def tic():
    global t_time_start_yz_global_var 
    t_time_start_yz_global_var = time.time()
        
    
def toc(suffix = None):
    if suffix is None:       
        print ('Time elapse: {0:1.3g} seconds.'.format(time.time()-t_time_start_yz_global_var))
    else:
        print ('{0:1.3g} seconds'.format(time.time()-t_time_start_yz_global_var), end = suffix)

def email(str_subject='', str_body=''):
    
    os.system('''echo "{0}" | mailx -s "{1}" '''.format(str_body, str_subject)+\
              '''thomas.zhang@mlp.com''')


def get_sql(query):
    
    engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
    #conn2 = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=CNDBPROD;UID=svc_fg_dbo;PWD=1eDecejiqu39;TDS_Version=8.0;')
    retu
rn pd.read_sql_query(query, con=engine)


def get_sql_wind(query):
    
    engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_wind_dbo;PWD=DusONA3Habredl;''TDS_Version=8.0;')))
    # gf's version: conn2 = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=WIND;UID=svc_wind_dbo;PWD=DusONA3Habredl;TDS_Version=8.0;')
    return pd.read_sql_query(query, con=engine)


def get_sql_cndb(query):
    
    engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;DATABASE=CNDBPROD;;UID=svc_tz_dbo;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
    # gf's version: conn = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=CNDB;UID=svc_tz_dbo;PWD=;TDS_Version=8.0;')
    return pd.read_sql_query(query, con=engine)

def get_sql_crtc(query):
    conn2 = psycopg2.connect(dbname = "Cereal", user = "svc_fg_cereal", port= 5432,
                             host = "ybsmtnode", password = "8EX/#Mhk")
    return pd.read_sql_query(query, conn2)

def get_cap(query):
    
    #'''select * from "web_chinese_social_media_raw_link"."posts" where meta_robot_name='EastMoney' and dataset_date = '2021-06-03' limit 10 '''
    
    conn_str = '''
                Driver=Simba Athena ODBC Driver;
                AwsRegion=us-east-1;
                S3OutputLocation=s3://mlp-974444692717-feng-pipeline-s3-source-us-east-1-prd/;
                AuthenticationType=Okta;
                UID=thzhang;
                PWD=Citadel190430!;
                idp_host=mlp.okta.com;
                app_id=0oa169nax00rXSl4D4x7/272;
                preferred_role=arn:aws:iam::974444692717:role/mlpDeveloper;
                UseProxyForIdP=1;
                UseProxy=1;
                ProxyHost=proxy.mlp.com;
                ProxyPort=3128'''
                
    with pyodbc.connect(conn_str) as conn:
        result_df = pd.read_sql_query(query, conn)
        
    return result_df


def to_sql():
    # from sqlalchemy import create_engine
    # import urllib
    # engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
    
    # from sqlalchemy import create_engine
    # import urllib
    # engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.pa
rse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=TZDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
    
    
    
    pass


def get_q(query, port=5001):
    
    q = qconnection.QConnection(host = '10.153.45.31', port = port, username = 'thzhang', password = pw(), pandas = True)
    q.open()
    o_data = q(query, pandas = True)    
    q.close()
    return o_data

### Reference Data

def get_cn_cal():
    
    return get_sql('''select * from cndbprod.dbo.Calendar_Dates_CN''')

def get_cn_ed():
    
    pass



def get_cn_return_dates_between(i_datetime_sr1, i_datetime_sr2):
    # This returns 1 if sr1 is T+0 before 2 pm and we can hold a position for 1 day thru T+1 close 
    # which is the last close right before sr2, an event like earnings
    
    datetime_sr1 = i_datetime_sr1.copy()
    datetime_sr2 = i_datetime_sr2.copy()
    
    return_dates = get_sql('''select distinct tradedate_next as returndate
                           from cndbprod.dbo.Calendar_Dates_CN
                           order by tradedate_next ''')
    return_dates = return_dates.reset_index(drop = True)
    return_dates['returndate_id'] = return_dates.index.values
    
    c_late = datetime_sr1.dt.hour.ge(14)
    datetime_sr1[c_late] = pd.to_datetime(datetime_sr1[c_late].dt.date + pd.to_timedelta('1 day'))
    # c_early = datetime_sr2.dt.hour.lt(14)
    # datetime_sr2[c_early] = pd.to_datetime(datetime_sr2[c_early].dt.date - pd.to_timedelta('1 day'))
    
    df_sr1_sr2 = pd.DataFrame({'sr1': datetime_sr1.tolist(), 'sr2': datetime_sr2.tolist()})
    df_sr1_sr2 = df_sr1_sr2.reset_index(drop = True)
    df_sr1_sr2['original_idx'] = df_sr1_sr2.index.values
    
    df_sr1_sr2 = df_sr1_sr2.sort_values('sr1')
    df_sr1_sr2 = pd.merge_asof(df_sr1_sr2, return_dates.rename(columns = {'returndate':'returndate_sr1', 'returndate_id': 'returndate_id_sr1'}), 
                               left_on = 'sr1', right_on = 'returndate_sr1', direction = 'backward')    
    df_sr1_sr2 = df_sr1_sr2.sort_values('sr2')
    df_sr1_sr2 = pd.merge_asof(df_sr1_sr2, return_dates.rename(columns = {'returndate':'returndate_sr2', 'returndate_id': 'returndate_id_sr2'}), 
                               left_on = 'sr2', right_on = 'returndate_sr2', direction = 'forward')
    df_sr1_sr2['retd2event'] = df_sr1_sr2['returndate_id_sr2'] - df_sr1_sr2['returndate_id_sr1'] - 1
    df_sr1_sr2 = df_sr1_sr2.sort_values('original_idx')
    
    return df_sr1_sr2['retd2event'].values




def get_cn_holidays():
    # this is fianlized
    # this returns number of return_dates that we can realistically hold
    # between today and a future event. 
    
    
    i_cal = get_sql('''select distinct tradedate_next as DataDate
                    from cndbprod.dbo.calendar_dates_cn
                    order by tradedate_next ''')
    i_cal['T-1d'] = i_cal['DataDate'].shift()
    i_cal = i_cal[i_cal['DataDate'] > '2015-11-01']
    i_cal = i_cal.sort_values('DataDate')
    
    i_holi = pd.read_excel('/dat/summit_capital/TZ/china_holidays.xlsx')
    i_holi = i_holi.sort_values('hol_cdate_start')
    
    o_cal = pd.merge_asof(i_cal, i_holi, left_on = 'DataDate', right_on = 'hol_cdate_start', direction = 'forward')
    o_cal = o_cal.dropna()
    o_cal['retd2holi'] = get_cn_return_dates_between(o_cal['DataDate'], o_cal['hol_cdate_start'])
    
    return o_cal


def get_us_cal():
    
    return get_sql('''select * from fgdbdev.dbo.Calendar_Dates''')


def get_us_return_dates_between(datetime_sr1, datetime_sr2):
    ### I suspect this one is wrong!!! c_early or c_late is wrong!!!
    
    # This returns 1 if sr1 is T+0 before 3 pm and we can hold a position for 1 day thru T+1 close 
    # which is the last close right before sr2, an event like earnings
    
    
    return_dates = get_sql('''select distinct tradedate_next as returndate
                           from fgdbdev.dbo.Calendar_Dates
                           order by tradedate_next ''')
    return_dates = return_dates.reset_index(drop = True)
    return_dates['returndate_id'] = return_dates.index.values
    
    c_late = datetime_sr1.dt.hour.ge(15)
    datetime_sr1[c_late] = pd.to_datetime(datetime_sr1[c_late].dt.date + pd.to_timedelta('1 day'))
    c_early = datetime_sr2.dt.hour.lt(15)
    datetime_sr2[c_early] = pd.to_datetime(datetime_sr2[c_early].dt.date - pd.to_timedelta('1 day'))
    
    df_sr1_sr2 = pd.DataFrame({'sr1': datetime_sr1.tolist(), 'sr2': datetime_sr2.tolist()})
    df_sr1_sr2 = df_sr1_sr2.reset_index(drop = True)
    df_sr1_sr2['original_idx'] = df_sr1_sr2.index.values
    
    df_sr1_sr2 = df_sr1_sr2.sort_values('sr1')
    df_sr1_sr2 = pd.merge_asof(df_sr1_sr2, return_dates.rename(columns = {'returndate':'returndate_sr1', 'returndate_id': 'returndate_id_sr1'}), 
                               left_on = 'sr1', right_on = 'returndate_sr1', direction = 'backward')    
    df_sr1_sr2 = df_sr1_sr2.sort_values('sr2')
    df_sr1_sr2 = pd.merge_asof(df_sr1_sr2, return_dates.
rename(columns = {'returndate':'returndate_sr2', 'returndate_id': 'returndate_id_sr2'}), 
                               left_on = 'sr2', right_on = 'returndate_sr2', direction = 'forward')
    df_sr1_sr2['retd2event'] = df_sr1_sr2['returndate_id_sr2'] - df_sr1_sr2['returndate_id_sr1'] - 1
    df_sr1_sr2 = df_sr1_sr2.sort_values('original_idx')
    
    return df_sr1_sr2['retd2event'].values




    

### Stats Tools 


def pdqcut(x, bins, labels=None):
    
    # x must be pd.Series()
    
    if pd.isnull(x).sum() == len(x):
        return pd.Series([np.nan]*len(x), index = x.index)
    elif pd.notnull(x).sum() < bins*2:
        return pd.Series([np.nan]*len(x), index = x.index)
    elif x.nunique() < bins:
        return pd.Series([np.nan]*len(x), index = x.index)
        #return pd.cut(x.rank(), bins = bins, labels = range(bins) if labels is None else labels)
    else:
        return pd.cut(x.rank(), bins = bins, labels = range(bins) if labels is None else labels)



def uniformed_rank(input_data, str_type=None):
    # transform(uniformed_rank) 
    # returns nan if apply(uniformed_rank)
    
    # str_type = 'zero_cutoff'
    
    t_input_data_type = ''
    if isinstance(input_data, (pd.core.series.Series)):
        t_r = input_data.rank(method='min')
        t_index = input_data.index
        t_input_data_type = 'Series'
    elif isinstance(input_data, (np.ndarray)):
        t_r = pd.Series(input_data).rank(method='min')
        input_data = pd.Series(input_data)
        t_input_data_type = 'ndarray'
    elif isinstance(input_data, (list)):
        input_data = pd.Series(input_data)
        t_r = pd.Series(input_data).rank(method='min')
        t_input_data_type = 'list'
    else:
        raise Exception("input array type error.")
    
    if len(t_r)<2:
        return pd.Series([np.nan]*len(t_r), index = t_index)
    
    if t_r.notnull().sum()<=1:
        return pd.Series([np.nan]*len(t_r), index = t_index)
    
    if str_type is None:
        return t_r.sub((t_r.min() + t_r.max())/2).divide(t_r.max()-t_r.min())*2
        #return t_r.sub(t_r.mean()).divide(t_r.max()-t_r.min())*2
        
    elif str_type == 'zero_cutoff':
        i01 = input_data.values #ndarray
        o1 = np.array([np.nan] * len(i01))
        o1[i01>0] = pd.Series(i01[i01>0]).rank().values / max(pd.Series(i01[i01>0]).rank().max(),pd.Series(i01[i01<0]).rank().max())
        o1[i01<0] = pd.Series(i01[i01<0]).rank(ascending=False).values / max(pd.Series(i01[i01>0]).rank().max(), 
pd.Series(i01[i01<0]).rank().max()) * (-1)  
        
        if t_input_data_type == 'Series':
            return pd.Series(o1, index = t_index)
        else:
            return pd.Series(o1)
    else:
        raise Exception("str_type param input error.")


def uniformed_rank_simple(input_data):

    t_r = input_data.rank(method='min')
    return t_r.sub((t_r.min() + t_r.max())/2).divide(t_r.max()-t_r.min())*2



def renorm(r):
    
    # input is a series
    #df_universe['BarrRet_CLIP5d_renorm'] = df_universe.groupby('DataDate')['BarrRet_CLIP5d'].apply(renorm)
    
    

    def Rank2Uni(x,m=float('inf')):
        r = x.rank(method = 'min')
        rmax = r.max()
        if ~np.isfinite(m):
            r = r/(rmax+1)
            return r
        else:
            p = ss.norm.cdf(m)
            r = r/(rmax-1)
            r = r - (r.max()-1)
            r = (2*p-1)*r+(1-p)
            return r
    def Winsorize(x,m):
        x[x>m]=m
        x[x<-m]=-m
        return x
    
    rindex = r.index
    res = Winsorize(ss.norm.ppf(Rank2Uni(r, 3)),3)
    rdf = pd.DataFrame(res)
    rdf = rdf.set_index(rindex)
    return rdf
    
    


@njit
def gen_sgnl_from_pulse(arr_pulse_holding_days):
    # the input is an array of pulse integers
    # the integer is either pos or neg, indicating direction and holding period
    # the output is ones, either pos or neg, indicating position
    # tcom.groupby('Ticker')['hldperiod_pulse'].apply(lambda x: pd.Series(gen_sgnl_from_pulse(x.values)).to_frame()).values
    
    if len(arr_pulse_holding_days)<=1:
        return [np.nan]*len(arr_pulse_holding_days)
    
    arr_output = [np.nan]*len(arr_pulse_holding_days)
    
    for i in range(len(arr_pulse_holding_days)):
        
        if i>0:
            prev = arr_pulse_holding_days[i-1]
            
            if (prev>1) and np.isnan(arr_pulse_holding_days[i]):
                arr_pulse_holding_days[i] = prev - 1
            if (prev<-1) and np.isnan(arr_pulse_holding_days[i]):
                arr_pulse_holding_days[i] = prev + 1
            
        curr = arr_pulse_holding_days[i]
        if abs(curr)>=1:
            arr_output[i] = np.sign(curr)
    
    return arr_output






def orthogonalize_cn_v3(tgt_sr, factors_df, ind_df, w_sr, weight_type='clip', normal_x = False, normal_y = False):
    # v3 deals with both factors and dummy industries
    
    # data from [CNDBPROD].[dbo].[UNIVERSE_ALL_CN_GEM3L]
    # cols_i = ['AIRLINES','AUTOCOMP','BANKS','BIOTECH','CAPGOOD
S','CHEMICAL','COMMSVCS','COMMUNIC',
    # 'COMPUTER','CONSDUR','CONSTPP','CONSVCS','DIVFINAN','DIVMETAL','ENERGY','FOODPRD','FOODRETL',
    # 'HEALTH','HSHLDPRD','INSURAN','INTERNET','MEDIA','OILEXPL','OILGAS','PHARMAC','PRECMETL',
    # 'REALEST','RETAIL','SEMICOND','SOFTWARE','STEEL','TELECOM','TRANSPRT','UTILITY']
    # cols_f = ['SRISK','BETA','MOMENTUM','SIZE','EARNYILD','RESVOL','GROWTH','DIVYILD',
    # 'BTOP','LEVERAGE','LIQUIDTY','SIZENL']
    
    # icom['o2c_sw_residret'] = orthogonalize_cn_v3(com['o2c_rawret'], com[cols_f], com[ind_i], com['ones']) 
    # icom['o2c_sw_residret'] = icom.groupby('datadate')[cols_i + cols_f + ['', 'ones']].apply(lambda x: yu.orthogonalize_cn_v3(x['o2c_rawret'], x[cols_f], x[cols_i], x['ones'])).values
            
    
    def Rank2Uni(x,m=float('inf')):
        r = x.rank(method = 'min')
        rmax = r.max()
        if ~np.isfinite(m):
            r = r/(rmax+1)
            return(r)
        else:
            p = ss.norm.cdf(m)
            r = r/(rmax-1)
            r = r - (r.max()-1)
            r = (2*p-1)*r+(1-p)
            return(r)
    def Winsorize(x,m):
        x[x>m]=m
        x[x<-m]=-m
        return(x)
    def ZScore(x):
        #z = (x-x.mean())/x.std()
        z = (x-np.nanmean(x))/np.nanstd(x)
        return(z)
    def lbmd(x):
        # x is a Series
        return ZScore(Winsorize(ss.norm.ppf(Rank2Uni(x, 3)),3))
    
    # get y, normalize y?
    if normal_y == False:
        array_tgt = tgt_sr.values
    else:
        array_tgt = lbmd(tgt_sr)
    
    # process nan 
    c_no_nan = ~ (np.isnan(factors_df.values).any(axis=1) | np.isnan(ind_df.values).any(axis=1) | np.isnan(array_tgt) | np.isnan(w_sr.values))    
    factors_notnan = pd.DataFrame(factors_df.values[c_no_nan])
    ind_notnan = ind_df.values[c_no_nan]
    y_notnan = array_tgt[c_no_nan]
    w_notnan = w_sr.values[c_no_nan]
    
    # if all nan ...
    if len(y_notnan) == 0:
        return pd.Series([np.nan]* len(tgt_sr), index = tgt_sr.index).to_frame()
    
    # get x    
    ind_col_notnan = ind_notnan.sum(axis=0)>0
    ind_notnan = ind_notnan[:, ind_col_notnan]
    if normal_x == True:
        x_notnan = np.hstack([factors_notnan.apply(lbmd, axis = 0).values,ind_notnan])   
    else:
        x_notnan = np.hstack([factors_notnan.values,ind_notnan])   
    
    
    # INVOMEGA
    if weight_type == 'srisk':
        S = w_notnan / 100.0 / np.sqrt(252)
        S = S**2
        INVOMEGA = np.diag(1/S)
    elif weight_type == 'clip'
:
        INVOMEGA = np.diag(w_notnan)
    else:
        raise Exception()
    
    # WLS #1    
    res_ret_notnan = y_notnan - np.dot(x_notnan,np.dot(np.dot(np.dot(np.linalg.inv(np.dot(np.dot(np.transpose(x_notnan),INVOMEGA),x_notnan)),np.transpose(x_notnan)),INVOMEGA), y_notnan))
    res_ret_sr = pd.Series([np.nan]*len(tgt_sr), index = tgt_sr.index)
    res_ret_sr.loc[c_no_nan] = res_ret_notnan
    return res_ret_sr.to_frame()



def orthogonalize_us(tgt_sr, factors_df, ind_df, w_sr, weight_type='clip', normal_x = False, normal_y = False):
    
    # cols_i = 
    
    # cols_f = ['DREVRSL', 'BETA', 'DIVYILD', 'DWNRISK', 'EARNQLTY', 'EARNYILD', 'GROWTH', 
    # 'INDMOM', 'LEVERAGE', 'LIQUIDTY', 'LTREVRSL', 'MGMTQLTY', 'MIDCAP', 'MOMENTUM', 
    # 'PROFIT', 'PROSPECT', 'REGMOM', 'RESVOL', 'SEASON', 'SENTMT', 'SHORTINT', 'STREVRSL', 
    # 'SIZE', 'VALUE']
    
    # icom['o2c_sw_residret'] = orthogonalize_us(com['o2c_rawret'], com[cols_f], com[ind_i], com['ones']) 
    # icom['o2c_sw_residret'] = icom.groupby('datadate')[cols_i + cols_f + ['', 'ones']].apply(lambda x: yu.orthogonalize_us(x['o2c_rawret'], x[cols_f], x[cols_i], x['ones'])).values
            
    
    def Rank2Uni(x,m=float('inf')):
        r = x.rank(method = 'min')
        rmax = r.max()
        if ~np.isfinite(m):
            r = r/(rmax+1)
            return(r)
        else:
            p = ss.norm.cdf(m)
            r = r/(rmax-1)
            r = r - (r.max()-1)
            r = (2*p-1)*r+(1-p)
            return(r)
    def Winsorize(x,m):
        x[x>m]=m
        x[x<-m]=-m
        return(x)
    def ZScore(x):
        #z = (x-x.mean())/x.std()
        z = (x-np.nanmean(x))/np.nanstd(x)
        return(z)
    def lbmd(x):
        # x is a Series
        return ZScore(Winsorize(ss.norm.ppf(Rank2Uni(x, 3)),3))
    
    # get y, normalize y?
    if normal_y == False:
        array_tgt = tgt_sr.values
    else:
        array_tgt = lbmd(tgt_sr)
    
    # process nan 
    c_no_nan = ~ (np.isnan(factors_df.values).any(axis=1) | np.isnan(ind_df.values).any(axis=1) | np.isnan(array_tgt) | np.isnan(w_sr.values))    
    factors_notnan = pd.DataFrame(factors_df.values[c_no_nan])
    ind_notnan = ind_df.values[c_no_nan]
    y_notnan = array_tgt[c_no_nan]
    w_notnan = w_sr.values[c_no_nan]
    
    # if all nan or not enough data points ... 
    if (len(y_notnan) == 0) or (len(y_notnan) <= factors_df.shape[1]+ind_df.shape[1] ):
        return pd.Series([np.nan]* len(tgt_sr), index = tgt_sr.index)
.to_frame()
    
    
    # get x    
    ind_col_notnan = ind_notnan.sum(axis=0)>0
    ind_notnan = ind_notnan[:, ind_col_notnan]
    if normal_x == True:
        x_notnan = np.hstack([factors_notnan.apply(lbmd, axis = 0).values,ind_notnan])   
    else:
        x_notnan = np.hstack([factors_notnan.values,ind_notnan])   
    
    
    # INVOMEGA
    if weight_type == 'srisk':
        S = w_notnan / 100.0 / np.sqrt(252)
        S = S**2
        INVOMEGA = np.diag(1/S)
    elif weight_type == 'clip':
        INVOMEGA = np.diag(w_notnan)
    else:
        raise Exception()
    
    # WLS #1    
    res_ret_notnan = y_notnan - np.dot(x_notnan,np.dot(np.dot(np.dot(np.linalg.inv(np.dot(np.dot(np.transpose(x_notnan),INVOMEGA),x_notnan)),np.transpose(x_notnan)),INVOMEGA), y_notnan))
    res_ret_sr = pd.Series([np.nan]*len(tgt_sr), index = tgt_sr.index)
    res_ret_sr.loc[c_no_nan] = res_ret_notnan
    return res_ret_sr.to_frame()



def orth_symmetry(factors):
    #factors = pd.DataFrame({'g1':[100,100,200,200], 'f1':[10, 1, 10, 1], 'f2':[10,100,1,10]})
    #factors[['f1_tilda', 'f2_tilda']] = factors.groupby('g1')[['f1','f2']].apply(lambda x: orth_symmetry(x[['f1','f2']]))
    col_name = factors.columns     
    D,U=np.linalg.eig(np.dot(factors.T,factors))
    S = np.dot(U,np.diag(D**(-0.5)))
    
    Fhat = np.dot(factors,S)
    Fhat = np.dot(Fhat,U.T)
    Fhat = pd.DataFrame(Fhat,columns = col_name,index = factors.index)
    
    return Fhat


def orth_schmidt(factors):
    
    col_name = factors.columns
    factors1 = factors.values
   
    R = np.zeros((factors1.shape[1], factors1.shape[1]))
    Q = np.zeros(factors1.shape)
    for k in range(0, factors1.shape[1]):
        R[k, k] = np.sqrt(np.dot(factors1[:, k], factors1[:, k]))
        Q[:, k] = factors1[:, k]/R[k, k]
        for j in range(k+1, factors1.shape[1]):
            R[k, j] = np.dot(Q[:, k], factors1[:, j])
            factors1[:, j] = factors1[:, j] - R[k, j]*Q[:, k]

    Q = pd.DataFrame(Q,columns = col_name,index = factors.index)    
    return Q


@njit
def ols_forecast_ts(arry):
    
    y_notnan = arry[~np.isnan(arry)]
    cnt_notnan = len(y_notnan)
        
    if cnt_notnan < 4:
        return np.nan
    else:
        x = np.array(list(range(len(y_notnan))))
        m = np.dot((x-np.mean(y_notnan)),(y_notnan-np.mean(y_notnan))) / np.dot(x-np.mean(x),x-np.mean(x))
        c = np.mean(y_notnan) - m * np.mean(x)
        return (np.max(x)+1)*m+c
    


@njit
def ols_slope_ts(arry, min_sampl
e = 4):
    
    y_notnan = arry[~np.isnan(arry)]
    cnt_notnan = len(y_notnan)
    
    if cnt_notnan < min_sample:
        return np.nan
    else:
        x = np.array(list(range(len(y_notnan))))
        m = np.dot((x-np.mean(y_notnan)),(y_notnan-np.mean(y_notnan))) / np.dot(x-np.mean(x),x-np.mean(x))
        return m
    


#@njit
def ols_resid_cs(arry, arrx, min_sample = 4, intercept = False):
    # this returns the residual y, after regressing against X's
    
    # process nan 
    c_no_nan = ~ ( np.isnan(arrx).any(axis=1) | np.isnan(arry) )
    y_notnan = arry[c_no_nan]
    x_notnan = arrx[c_no_nan]
    
    # sample size check    
    cnt_notnan = len(y_notnan)    
    if cnt_notnan < min_sample:
        return np.nan
    
    # intercept
    if intercept == True:
        x_notnan = np.hstack([np.ones(len(x_notnan)).reshape(len(x_notnan),1), x_notnan])
    
    # calculate
    INVOMEGA = np.diag(np.ones(len(y_notnan)))
    return  y_notnan - np.dot(x_notnan,
            np.dot(np.dot(np.dot(np.linalg.inv(np.dot(np.dot(np.transpose(x_notnan),INVOMEGA),x_notnan)),np.transpose(x_notnan)),INVOMEGA), y_notnan))


from bokeh.io import show
from bokeh.layouts import column, gridplot
from bokeh.models import ColumnDataSource, RangeTool, HoverTool, CustomJS, CrosshairTool, LinearAxis, Range1d
from bokeh.plotting import figure

def ta_plot_linux(df, ticker, sgnl_tertiary=None, sgnl_2=None, sgnl_3=None): 
    # ta_plot(icom, '002236.SZ', sgnl_tertiary = 'sgnl1', sgnl_2 = 'EARNYILD')
    # this is used to plot 1 tertiary signal and 2 continuous signals along with bret and candle
    
    # get input data 
    
    cols = ['datadate', 'ticker'] + [sgnl_tertiary, sgnl_2, sgnl_3]
    cols = [i for i in cols if not i is None]
    i_df = df[df['ticker']==ticker][cols]
    
    i_sd = get_sql_cndb('''select ticker, datadate, BarrRet_CLIP_USD
                   from cndbprod.dbo.Barra_GEM3L_RRET_CN 
                   where ticker = '{0}' 
                   order by datadate '''.format(ticker[:6]))
    c_sh = i_sd['ticker'].str[0].isin(['6'])
    c_sz = i_sd['ticker'].str[0].isin(['0', '3'])
    i_sd.loc[c_sh, 'ticker'] = i_sd.loc[c_sh, 'ticker'] + '.SH'
    i_sd.loc[c_sz, 'ticker'] = i_sd.loc[c_sz, 'ticker'] + '.SZ'
    
    i_wind = get_sql_wind('''select s_info_windcode as ticker, trade_dt as datadate,
                     s_dq_adjopen as o, s_dq_adjhigh as h, s_dq_adjlow as l, s_dq_adjclose as c, 
                     s_dq_amount as amt 
                     fr
om [wind_prod].[dbo].[ashareeodprices] 
                     where s_info_windcode = '{0}' 
                     and trade_dt >= '20160101' 
                     order by trade_dt '''.format(ticker))
    i_wind['datadate'] = pd.to_datetime(i_wind['datadate'], format = '%Y%m%d')
    
    # merge input data
    
    i_data = i_wind.merge(i_sd, on = ['ticker','datadate'], how = 'left')
    i_data = i_data.merge(i_df, on = ['ticker','datadate'], how = 'left')
    i_data['bret_index'] = i_data['BarrRet_CLIP_USD'].cumsum()
    
    # VIZ - main chart: bret + sgnl_bool       
        
    p_main = figure(plot_height=400, plot_width=1600, tools="pan,wheel_zoom,reset", toolbar_location='right',
               x_axis_type="datetime", x_axis_location="below", title = ticker,
               background_fill_color="#ffffff",x_range=(i_data.datadate.min(), i_data.datadate.max()))
    p_main.xaxis.major_label_orientation = 3.1415/4
    p_main_pindex = ColumnDataSource(data=dict(date=i_data['datadate'], bret_index = i_data.set_index('datadate')['bret_index']))
    p_main.circle('date', 'bret_index', source=p_main_pindex, fill_color = 'indigo', size = 4)    

    if not sgnl_tertiary is None:        
        
        i_data[sgnl_tertiary] = i_data[sgnl_tertiary].replace(0, np.nan)                
        c_sgnl_pos = i_data[sgnl_tertiary] > 0
        c_sgnl_neg = i_data[sgnl_tertiary] < 0
        i_data['zero'] = 0
        
        p_main.vbar(i_data.datadate[c_sgnl_pos], 12*60*60*1000, i_data['zero'][c_sgnl_pos], i_data[sgnl_tertiary][c_sgnl_pos], 
                    fill_color="orange", line_color="orange", line_alpha = 0.5, fill_alpha = 0.5)
        p_main.vbar(i_data.datadate[c_sgnl_neg], 12*60*60*1000, i_data['zero'][c_sgnl_neg], i_data[sgnl_tertiary][c_sgnl_neg], 
                    fill_color="purple", line_color="purple", line_alpha = 0.5, fill_alpha = 0.5)
                 
    p_main.yaxis.axis_label = 'BarrRet_CLIP_USD'
    p_main.xaxis[0].ticker.desired_num_ticks = 80
    
    p_main.add_tools(HoverTool(tooltips=[('date','@date{%F}'),('p_index','@{p_index}{0.3f}')],formatters ={'date':'datetime'}))
    
    
    # VIZ - second chart - OHLC and EMA
    
    cond_yang = i_data.c >= i_data.o
    cond_yin = i_data.o > i_data.c
    
    p_2 = figure(x_axis_type="datetime", tools="pan,wheel_zoom,box_zoom,reset", plot_width=1600, plot_height = 250,
                 x_range = p_main.x_range)
    p_2.xaxis.major_label_orientation = 3.1415/4
    p_2.grid.grid_line_alpha
=0.3
    p_2.xaxis[0].ticker.desired_num_ticks = 80
    
    p_2.segment(i_data.datadate, i_data.h, i_data.datadate, i_data.l, color="black")
    p_2.vbar(i_data.datadate[cond_yang], 12*60*60*1000, i_data.o[cond_yang], i_data.c[cond_yang], fill_color="green", line_color="green")
    p_2.vbar(i_data.datadate[cond_yin], 12*60*60*1000, i_data.o[cond_yin], i_data.c[cond_yin], fill_color="#F2583E", line_color="#F2583E")
             
    p_2.add_tools(HoverTool(tooltips=[('date','@datadate{%F}'),('top','@{top}{0.3f}'),('bottom','@{bottom}{0.3f}')],
                                      formatters ={'date':'datetime'}))
    
    o_ema2 = i_data['c'].ewm(span=40, ignore_na = True).mean()
    ema2 = ColumnDataSource(data=dict(date=i_data['datadate'], ema=o_ema2))
    p_2.line('date', 'ema', source=ema2, line_color = 'orange', line_width = 0.8, line_alpha = 0.7)
    
    # VIZ - sgnl_2
    
    if not sgnl_2 is None:
        
        p_3 = figure(x_axis_type="datetime", tools="pan,wheel_zoom,box_zoom,reset", plot_width=1600, plot_height = 180,
                     x_range = p_main.x_range)
        p_3.xaxis.major_label_orientation = 3.1415/4
        p_3.grid.grid_line_alpha=0.3
        p_3.xaxis[0].ticker.desired_num_ticks = 80
        
        p_3_data = ColumnDataSource(data=dict(date=i_data['datadate'], data=i_data.set_index('datadate')[sgnl_2]))
        #p_3.line('date', 'data', source=p_3_data, line_color = 'indigo', line_width = 0.8, line_alpha = 0.7)
        p_3.circle('date', 'data', source=p_3_data, fill_color = 'purple', size = 3)    
        p_3.yaxis.axis_label = sgnl_2
        
    else:
        p_3 = None
        
    
    
    # VIZ - sgnl_3
    
    if not sgnl_3 is None:
        
        p_4 = figure(x_axis_type="datetime", tools="pan,wheel_zoom,box_zoom,reset", plot_width=1600, plot_height = 180,
                     x_range = p_main.x_range)
        p_4.xaxis.major_label_orientation = 3.1415/4
        p_4.grid.grid_line_alpha=0.3
        p_4.xaxis[0].ticker.desired_num_ticks = 80
        
        p_4_data = ColumnDataSource(data=dict(date=i_data['datadate'], data=i_data.set_index('datadate')[sgnl_3]))
        #p_4.line('date', 'data', source=p_4_data, line_color = 'indigo', line_width = 0.8, line_alpha = 0.7)
        p_4.circle('date', 'data', source=p_4_data, fill_color = 'purple', size = 3)
        p_4.yaxis.axis_label = sgnl_3
    
    else:
        p_4 = None
    
    
    
    # VIZ - slider
    slider = figure(plot_height=40, plot_width=160
0, #y_range=p_main.y_range,
                    x_axis_type="datetime", y_axis_type=None,
                    tools="", toolbar_location=None, background_fill_color="#efefef")        
    slider_range_tool = RangeTool(x_range=p_main.x_range)
    slider_range_tool.overlay.fill_color = "navy"
    slider_range_tool.overlay.fill_alpha = 0.2
    slider_c = ColumnDataSource(data=dict(date=i_data.datadate, slider_c=i_data.c))
    slider.line('date', 'slider_c', source=slider_c, line_color = 'blue', line_width = 1)
    slider.ygrid.grid_line_color = None
    slider.add_tools(slider_range_tool)
    slider.toolbar.active_multi = slider_range_tool
    slider.axis.visible = False
    
    
    display_lst = [[p_main],[p_2],[p_3],[p_4],[slider]]
    display_lst = [i for i in display_lst if i!=[None]]
    show(gridplot(display_lst))
    

















### TA



def prepare_us_intraday_rawret():
    # since 2015
       
    i_cal = get_sql('''select distinct tradedate_next as DataDate 
                    from FGDBDEV.dbo.Calendar_Dates 
                    where tradedate_next >= '2015-01-01' ''')
                    
    def helper1(dd):
        
        i_data = get_sql('''
                         with tk_minmaxts as ( select Ticker, Hour, case when Min<30 then 1 else 2 end as hh,
                                min([Min]) as min_min, max([Min]) as max_min
                                from FGDBDEV.dbo.TAQ_TRADE_{0} with (nolock)
                                where DataDate = '{1}'
                                group by Ticker, Hour, case when Min<30 then 1 else 2 end )
                         with tk_start as (
                                select  
                                from FGDBDEV.dbo.TAQ_TRADE_{0} a with (nolock)
                                inner join tk_minmaxts
                                
                                 )
                         
                         select Ticker, Time, Hour, Min, [Trade PV]/[Trade Volume] as px 
                         from FGDBDEV.dbo.TAQ_TRADE_{0} a with (nolock)
                         
                         
                         
                         where DataDate = '{1}'
                         '''.format( dd.strftime('%Y')[-2:], dd.strftime('%Y-%m-%d') ))
        
def prepare_us_vwap():
    # since 2015
    
    # get trade dates 
    
    i_cal = get_us_cal()
    i_cal = i_cal[['TradeDate_next']].drop_duplicates()
    i_cal = i_cal[i_cal['TradeDate_next']>='2016-01-0
1']
    
    # query sql
    
    o_vwap = []
    
    for t1d in i_cal['TradeDate_next'].sort_values().tolist():
        print(t1d,end=',')
        
        t1d_str = t1d.strftime('%Y%m%d')
        
        i_vwap = get_sql('''select Ticker, 
                         case when sum([Trade Volume])>0 then sum([Trade PV]) / sum([Trade Volume]) 
                         else null end as vwap
                         from fgdbdev.dbo.TAQ_TRADE_{0}
                         where DataDate = '{1}'
                         group by Ticker
                         '''.format( t1d_str[2:4], t1d_str ))
        i_vwap['T-1d'] = t1d
        o_vwap.append(i_vwap)
        i_vwap = None
        
    o_vwap = pd.concat(o_vwap, axis = 0)
    o_vwap.to_parquet('/dat/summit_capital/TZ/tmp/us_vwap.parquet')

    
    


@njit
def ta_zigzag15(arr_c, arr_h, arr_l, c_window, c_std_num):
    # this calculates the PIT zigzag vertices and location for each past datadate
    # this should be used like this: groupby('ticker')['c',...].apply(lambda x: ta_zigzag(...))
    
    # c_window = lookback period for std


    # sanity check if we have enough data points
    if len(arr_c) <= c_window * 1.5:
        return np.array([[np.nan]*len(arr_c), [np.nan]*len(arr_c), 
                        [np.nan]*len(arr_c), [np.nan]*len(arr_c), [np.nan]*len(arr_c), [np.nan]*len(arr_c),
                        [np.nan]*len(arr_c), [np.nan]*len(arr_c), [np.nan]*len(arr_c), [np.nan]*len(arr_c),
                        [np.nan]*len(arr_c), [np.nan]*len(arr_c), [np.nan]*len(arr_c), [np.nan]*len(arr_c),
                        [np.nan]*len(arr_c), [np.nan]*len(arr_c), [np.nan]*len(arr_c), [np.nan]*len(arr_c),
                        [np.nan]*len(arr_c), [np.nan]*len(arr_c), [np.nan]*len(arr_c), [np.nan]*len(arr_c),
                        [np.nan]*len(arr_c), [np.nan]*len(arr_c),
                        [np.nan]*len(arr_c), [np.nan]*len(arr_c), [np.nan]*len(arr_c), [np.nan]*len(arr_c),
                        [np.nan]*len(arr_c), [np.nan]*len(arr_c), [np.nan]*len(arr_c), [np.nan]*len(arr_c)]).T
        
    # set up variables
    len_arr_c = len(arr_c)
    arr_index = [i for i in range(len_arr_c)]
    
    state_trend = 9    
    state_last_index = arr_index[c_window-1]
    state_last_price = arr_c[state_last_index]
    
    o_zz_reverse_index = [state_last_index]
    o_zz_reverse_recog_index = [state_last_index]
    o_zz_vertex_price = [state_last_price]
    o_zz_std = [np.std(arr_c[:c_window]) / np.mean(
arr_c[:c_window]) * c_std_num]
    o_zz_vertex_type= [0]
    
    o_ts_curr_trend = [1.0*i for i in range(0)]
    o_ts_curr_idx = [1.0*i for i in range(0)]
    o_ts_vertex_1 = [1.0*i for i in range(0)]
    o_ts_vertex_id1 = [1.0*i for i in range(0)]
    o_ts_vertex_typ1 = [1.0*i for i in range(0)]
    o_ts_vertex_2 = [1.0*i for i in range(0)]
    o_ts_vertex_id2 = [1.0*i for i in range(0)]
    o_ts_vertex_typ2 = [1.0*i for i in range(0)]
    o_ts_vertex_3 = [1.0*i for i in range(0)]
    o_ts_vertex_id3 = [1.0*i for i in range(0)]
    o_ts_vertex_typ3 = [1.0*i for i in range(0)]
    o_ts_vertex_4 = [1.0*i for i in range(0)]
    o_ts_vertex_id4 = [1.0*i for i in range(0)]
    o_ts_vertex_typ4 = [1.0*i for i in range(0)]
    o_ts_vertex_5 = [1.0*i for i in range(0)]
    o_ts_vertex_id5 = [1.0*i for i in range(0)]
    o_ts_vertex_typ5 = [1.0*i for i in range(0)]
    o_ts_vertex_6 = [1.0*i for i in range(0)]
    o_ts_vertex_id6 = [1.0*i for i in range(0)]
    o_ts_vertex_typ6 = [1.0*i for i in range(0)]
    o_ts_vertex_7 = [1.0*i for i in range(0)]
    o_ts_vertex_id7 = [1.0*i for i in range(0)]
    o_ts_vertex_typ7 = [1.0*i for i in range(0)]
    o_ts_vertex_8 = [1.0*i for i in range(0)]
    o_ts_vertex_id8= [1.0*i for i in range(0)]
    o_ts_vertex_typ8 = [1.0*i for i in range(0)]
    o_ts_vertex_9 = [1.0*i for i in range(0)]
    o_ts_vertex_id9 = [1.0*i for i in range(0)]
    o_ts_vertex_typ9 = [1.0*i for i in range(0)]
    o_ts_vertex_10 = [1.0*i for i in range(0)]
    o_ts_vertex_id10 = [1.0*i for i in range(0)]
    o_ts_vertex_typ10 = [1.0*i for i in range(0)]
    
    o_ts_vertex_11 = [1.0*i for i in range(0)]
    o_ts_vertex_id11 = [1.0*i for i in range(0)]
    o_ts_vertex_typ11 = [1.0*i for i in range(0)]    
    o_ts_vertex_12 = [1.0*i for i in range(0)]
    o_ts_vertex_id12 = [1.0*i for i in range(0)]
    o_ts_vertex_typ12 = [1.0*i for i in range(0)]    
    o_ts_vertex_13 = [1.0*i for i in range(0)]
    o_ts_vertex_id13 = [1.0*i for i in range(0)]
    o_ts_vertex_typ13 = [1.0*i for i in range(0)]    
    o_ts_vertex_14 = [1.0*i for i in range(0)]
    o_ts_vertex_id14 = [1.0*i for i in range(0)]
    o_ts_vertex_typ14 = [1.0*i for i in range(0)]    
    o_ts_vertex_15 = [1.0*i for i in range(0)]
    o_ts_vertex_id15 = [1.0*i for i in range(0)]
    o_ts_vertex_typ15 = [1.0*i for i in range(0)]
    
    
    # loop over historical dates
    for i in range(len_arr_c):
        i_index = arr_index[i]
        i_high = arr_h[i]
        i_low = arr_l[i]
     
   
        # must have data with len > c_window
        if i_index < c_window-1:
            o_ts_curr_trend.append(np.nan)
            o_ts_curr_idx.append(i)
            o_ts_vertex_1.append(np.nan)
            o_ts_vertex_id1.append(np.nan)
            o_ts_vertex_typ1.append(np.nan)
            o_ts_vertex_2.append(np.nan)
            o_ts_vertex_id2.append(np.nan)
            o_ts_vertex_typ2.append(np.nan)
            o_ts_vertex_3.append(np.nan)
            o_ts_vertex_id3.append(np.nan)
            o_ts_vertex_typ3.append(np.nan)
            o_ts_vertex_4.append(np.nan)
            o_ts_vertex_id4.append(np.nan)
            o_ts_vertex_typ4.append(np.nan)
            o_ts_vertex_5.append(np.nan)
            o_ts_vertex_id5.append(np.nan)
            o_ts_vertex_typ5.append(np.nan)
            o_ts_vertex_6.append(np.nan)
            o_ts_vertex_id6.append(np.nan)
            o_ts_vertex_typ6.append(np.nan)
            o_ts_vertex_7.append(np.nan)
            o_ts_vertex_id7.append(np.nan)
            o_ts_vertex_typ7.append(np.nan)
            o_ts_vertex_8.append(np.nan)
            o_ts_vertex_id8.append(np.nan)
            o_ts_vertex_typ8.append(np.nan)
            o_ts_vertex_9.append(np.nan)
            o_ts_vertex_id9.append(np.nan)
            o_ts_vertex_typ9.append(np.nan)
            o_ts_vertex_10.append(np.nan)
            o_ts_vertex_id10.append(np.nan)            
            o_ts_vertex_typ10.append(np.nan)
            
            o_ts_vertex_11.append(np.nan)
            o_ts_vertex_id11.append(np.nan)            
            o_ts_vertex_typ11.append(np.nan)            
            o_ts_vertex_12.append(np.nan)
            o_ts_vertex_id12.append(np.nan)            
            o_ts_vertex_typ12.append(np.nan)            
            o_ts_vertex_13.append(np.nan)
            o_ts_vertex_id13.append(np.nan)            
            o_ts_vertex_typ13.append(np.nan)            
            o_ts_vertex_14.append(np.nan)
            o_ts_vertex_id14.append(np.nan)            
            o_ts_vertex_typ14.append(np.nan)            
            o_ts_vertex_15.append(np.nan)
            o_ts_vertex_id15.append(np.nan)            
            o_ts_vertex_typ15.append(np.nan)
            continue
        
        # reverse criteria
        reverse_pct = np.std(arr_c[i_index-c_window+1:i_index+1]) / np.mean(arr_c[i_index-c_window+1:i_index+1]) * c_std_num
        up_state_trend = 1 + reverse_pct
        down_state_trend = 1 - reverse_pct
  
      
        # No initial trend
        if state_trend == 9:
            if i_high / state_last_price > up_state_trend:
                state_trend = 1
            elif i_low / state_last_price < down_state_trend:
                state_trend = -1
        
        # state_trend is up
        elif state_trend == 1:
            # New high
            if i_high >= state_last_price:
                state_last_index, state_last_price = i_index, i_high
            # Reversal
            elif i_low / state_last_price < down_state_trend:
                o_zz_reverse_index.append(state_last_index)
                o_zz_reverse_recog_index.append(i)
                o_zz_vertex_price.append(state_last_price)
                o_zz_std.append(reverse_pct)
                o_zz_vertex_type.append(1)

                state_trend, state_last_index, state_last_price = -1, i_index, i_low
        
        # state_trend is down
        else:
            # New low
            if i_low <= state_last_price:
                state_last_index, state_last_price = i_index, i_low
            # Reversal
            elif i_high / state_last_price > up_state_trend:
                o_zz_reverse_index.append(state_last_index)
                o_zz_reverse_recog_index.append(i)
                o_zz_vertex_price.append(state_last_price)
                o_zz_std.append(reverse_pct)
                o_zz_vertex_type.append(-1)

                state_trend, state_last_index, state_last_price = 1, i_index, i_high
        
        # output daily numbers 
        
        o_ts_curr_trend.append(state_trend)
        o_ts_curr_idx.append(i)
        
        t_o_zz_len = len(o_zz_vertex_price)
        
        if t_o_zz_len >= 1:
            o_ts_vertex_1.append(o_zz_vertex_price[t_o_zz_len-1])
            o_ts_vertex_id1.append(o_zz_reverse_index[t_o_zz_len-1])
            o_ts_vertex_typ1.append(o_zz_vertex_type[t_o_zz_len-1])
        else:
            o_ts_vertex_1.append(np.nan)
            o_ts_vertex_id1.append(np.nan)
            o_ts_vertex_typ1.append(np.nan)
        if t_o_zz_len >= 2:
            o_ts_vertex_2.append(o_zz_vertex_price[t_o_zz_len-2])
            o_ts_vertex_id2.append(o_zz_reverse_index[t_o_zz_len-2])
            o_ts_vertex_typ2.append(o_zz_vertex_type[t_o_zz_len-2])
        else:
            o_ts_vertex_2.append(np.nan)
            o_ts_vertex_id2.append(np.nan)
            o_ts_vertex_typ2.append(np.nan)
        if t_o_zz_len >= 3:
            o_ts_vertex_3.append(o_zz_verte
x_price[t_o_zz_len-3])
            o_ts_vertex_id3.append(o_zz_reverse_index[t_o_zz_len-3])
            o_ts_vertex_typ3.append(o_zz_vertex_type[t_o_zz_len-3])
        else:
            o_ts_vertex_3.append(np.nan)
            o_ts_vertex_id3.append(np.nan)
            o_ts_vertex_typ3.append(np.nan)
        if t_o_zz_len >= 4:
            o_ts_vertex_4.append(o_zz_vertex_price[t_o_zz_len-4])
            o_ts_vertex_id4.append(o_zz_reverse_index[t_o_zz_len-4])
            o_ts_vertex_typ4.append(o_zz_vertex_type[t_o_zz_len-4])
        else:
            o_ts_vertex_4.append(np.nan)
            o_ts_vertex_id4.append(np.nan)
            o_ts_vertex_typ4.append(np.nan)
        if t_o_zz_len >= 5:
            o_ts_vertex_5.append(o_zz_vertex_price[t_o_zz_len-5])
            o_ts_vertex_id5.append(o_zz_reverse_index[t_o_zz_len-5])
            o_ts_vertex_typ5.append(o_zz_vertex_type[t_o_zz_len-5])
        else:
            o_ts_vertex_5.append(np.nan)
            o_ts_vertex_id5.append(np.nan)
            o_ts_vertex_typ5.append(np.nan)
        if t_o_zz_len >= 6:
            o_ts_vertex_6.append(o_zz_vertex_price[t_o_zz_len-6])
            o_ts_vertex_id6.append(o_zz_reverse_index[t_o_zz_len-6])
            o_ts_vertex_typ6.append(o_zz_vertex_type[t_o_zz_len-6])
        else:
            o_ts_vertex_6.append(np.nan)
            o_ts_vertex_id6.append(np.nan)
            o_ts_vertex_typ6.append(np.nan)
        if t_o_zz_len >= 7:
            o_ts_vertex_7.append(o_zz_vertex_price[t_o_zz_len-7])
            o_ts_vertex_id7.append(o_zz_reverse_index[t_o_zz_len-7])
            o_ts_vertex_typ7.append(o_zz_vertex_type[t_o_zz_len-7])
        else:
            o_ts_vertex_7.append(np.nan)
            o_ts_vertex_id7.append(np.nan)
            o_ts_vertex_typ7.append(np.nan)
        if t_o_zz_len >= 8:
            o_ts_vertex_8.append(o_zz_vertex_price[t_o_zz_len-8])
            o_ts_vertex_id8.append(o_zz_reverse_index[t_o_zz_len-8])
            o_ts_vertex_typ8.append(o_zz_vertex_type[t_o_zz_len-8])
        else:
            o_ts_vertex_8.append(np.nan)
            o_ts_vertex_id8.append(np.nan)
            o_ts_vertex_typ8.append(np.nan)
        if t_o_zz_len >= 9:
            o_ts_vertex_9.append(o_zz_vertex_price[t_o_zz_len-9])
            o_ts_vertex_id9.append(o_zz_reverse_index[t_o_zz_len-9])
            o_ts_vertex_typ9.append(o_zz_vertex_type[t_o_zz_len-9])
        else:
            o_ts_vertex_9.append(np.nan)
            o_ts_vertex_id9.append(np.nan)
    
        o_ts_vertex_typ9.append(np.nan)
        if t_o_zz_len >= 10:
            o_ts_vertex_10.append(o_zz_vertex_price[t_o_zz_len-10])
            o_ts_vertex_id10.append(o_zz_reverse_index[t_o_zz_len-10]) 
            o_ts_vertex_typ10.append(o_zz_vertex_type[t_o_zz_len-10])
        else:
            o_ts_vertex_10.append(np.nan)
            o_ts_vertex_id10.append(np.nan) 
            o_ts_vertex_typ10.append(np.nan)
            
        if t_o_zz_len >= 11:
            o_ts_vertex_11.append(o_zz_vertex_price[t_o_zz_len-11])
            o_ts_vertex_id11.append(o_zz_reverse_index[t_o_zz_len-11]) 
            o_ts_vertex_typ11.append(o_zz_vertex_type[t_o_zz_len-11])
        else:
            o_ts_vertex_11.append(np.nan)
            o_ts_vertex_id11.append(np.nan) 
            o_ts_vertex_typ11.append(np.nan)
            
        if t_o_zz_len >= 12:
            o_ts_vertex_12.append(o_zz_vertex_price[t_o_zz_len-12])
            o_ts_vertex_id12.append(o_zz_reverse_index[t_o_zz_len-12]) 
            o_ts_vertex_typ12.append(o_zz_vertex_type[t_o_zz_len-12])
        else:
            o_ts_vertex_12.append(np.nan)
            o_ts_vertex_id12.append(np.nan) 
            o_ts_vertex_typ12.append(np.nan)
            
        if t_o_zz_len >= 13:
            o_ts_vertex_13.append(o_zz_vertex_price[t_o_zz_len-13])
            o_ts_vertex_id13.append(o_zz_reverse_index[t_o_zz_len-13]) 
            o_ts_vertex_typ13.append(o_zz_vertex_type[t_o_zz_len-13])
        else:
            o_ts_vertex_13.append(np.nan)
            o_ts_vertex_id13.append(np.nan) 
            o_ts_vertex_typ13.append(np.nan)
            
        if t_o_zz_len >= 14:
            o_ts_vertex_14.append(o_zz_vertex_price[t_o_zz_len-14])
            o_ts_vertex_id14.append(o_zz_reverse_index[t_o_zz_len-14]) 
            o_ts_vertex_typ14.append(o_zz_vertex_type[t_o_zz_len-14])
        else:
            o_ts_vertex_14.append(np.nan)
            o_ts_vertex_id14.append(np.nan) 
            o_ts_vertex_typ14.append(np.nan)
        
        if t_o_zz_len >= 15:
            o_ts_vertex_15.append(o_zz_vertex_price[t_o_zz_len-15])
            o_ts_vertex_id15.append(o_zz_reverse_index[t_o_zz_len-15]) 
            o_ts_vertex_typ15.append(o_zz_vertex_type[t_o_zz_len-15])
        else:
            o_ts_vertex_15.append(np.nan)
            o_ts_vertex_id15.append(np.nan) 
            o_ts_vertex_typ15.append(np.nan)
            
    return np.array([o_ts_curr_trend, o_ts_curr_idx, 
                    o_
ts_vertex_1, o_ts_vertex_id1, o_ts_vertex_2, o_ts_vertex_id2,
                    o_ts_vertex_3, o_ts_vertex_id3, o_ts_vertex_4, o_ts_vertex_id4,
                    o_ts_vertex_5, o_ts_vertex_id5, o_ts_vertex_6, o_ts_vertex_id6,
                    o_ts_vertex_7, o_ts_vertex_id7, o_ts_vertex_8, o_ts_vertex_id8,
                    o_ts_vertex_9, o_ts_vertex_id9, o_ts_vertex_10, o_ts_vertex_id10,
                    o_ts_vertex_11, o_ts_vertex_id11,
                    o_ts_vertex_12, o_ts_vertex_id12,
                    o_ts_vertex_13, o_ts_vertex_id13,
                    o_ts_vertex_14, o_ts_vertex_id14,
                    o_ts_vertex_15, o_ts_vertex_id15 ]).T






### Back Test






def bt(df, col_signal_str, col_ret_str, sgnl_before_3pm, static_data = None, tcost_method = 'daily', skip_bucket = False):
    # df must have: datadate + ticker + signal ( = % of clip) + return
    # col_signal_str is the desired pst for the next day (not just signal), col_ret_str is the return for the next day
    # usually col_ret_str is bret_p2d, i.e. 2 days after signal date
    # tcost_method ['daily','intraday']
    
    # df quality check
    if df.duplicated(subset = ['ticker','datadate'], keep = False).sum() > 0:
        raise Exception("Input df has duplicate ticker/datadate rows.")
    if pd.isnull(df[['ticker','datadate',col_signal_str,col_ret_str]]).any(axis = 1).sum() > 0:
        raise Exception("Input df has nan values.")

    
    # get df's tickers and date range
    i_tk = df['ticker'].unique().tolist()
    i_df_min_date = (df['datadate'].min()-pd.to_timedelta('1 day')).strftime('%Y-%m-%d')
    
    # get rid of unnecessary columns from df
    for f in ['spread','volatility','SRISK_USE4', 'BETA_USE4', 'BTOP_USE4', 'EARNYILD_USE4', 'GROWTH_USE4', 
              'LEVERAGE_USE4', 'LIQUIDTY_USE4', 'MOMENTUM_USE4', 'MOMENTUM_FAST','SIZE_USE4', 'DIVYILD_USE4', 
              'RESVOL_USE4']:
        try:
            df = df.drop(columns = [f])
        except:
            continue
        try:
            df = df.drop(columns = [f+'_bk'])
        except:
            continue
        
    
    # get static data
    if static_data is not None:
        i_sd = static_data
    else:
        i_sd = pd.read_parquet(r"/dat/summit_capital/Infrastructure/backtester/data_cache/static_data_v2p0.parquet", 
                               columns = ['Ticker','DataDate','T-1d','avgPV_l1d','spread','volatility',
                                          'SRISK_USE4', 'BETA_US
E4', 'BTOP_USE4', 'EARNYILD_USE4', 'GROWTH_USE4', 
                                          'LEVERAGE_USE4', 'LIQUIDTY_USE4', 'MOMENTUM_USE4', 'MOMENTUM_FAST',
                                          'SIZE_USE4'])
    # process static data
    if sgnl_before_3pm == True:
        i_sd = i_sd.rename(columns = {'Ticker':'ticker', 'DataDate': 'datadate'})
    elif sgnl_before_3pm == False:
        i_sd = i_sd.rename(columns = {'Ticker':'ticker', 'T-1d': 'datadate','DataDate':'datadate_p1d'})
    
    i_sd = i_sd[(i_sd['datadate'] + pd.to_timedelta('10 days')>=i_df_min_date)&(i_sd['ticker'].isin(i_tk))]

    # merge sgnl and static data
    i_data = df.merge(i_sd, on = ['ticker','datadate'], how = 'right', suffixes = ['','_staticdata'])
    

    # clip size
    i_data['clip'] = i_data['avgPV_l1d']*0.01
    i_data.loc[i_data['clip']>1e6, 'clip'] = 1e6
    #i_data['clip'] = i_data['clip']*2 ###!!!
    
    # pst
    i_data['pstD'] = i_data[col_signal_str].multiply(i_data['clip'])
    
    # gmv
    i_data['gmv'] = i_data['pstD'].abs()
    
    # pnl
    i_data['pnl'] = i_data['pstD'].multiply(i_data[col_ret_str])
    
    # pnl - tcost
    i_data = i_data.sort_values(['ticker','datadate'])
    i_data = i_data.reset_index(drop = True)
    i_data['pstD_1d'] = i_data.groupby('ticker')['pstD'].shift(1)
    i_data['pstD_1d'] = i_data['pstD_1d'].fillna(0)
    if tcost_method == 'daily':
        i_data['pstD_df'] = (i_data['pstD'] - i_data['pstD_1d']).abs()
    else:
        i_data['pstD_df'] = i_data['pstD'].abs()*2
    i_data['pnl_tcost'] = i_data['pnl'] - 0.3 * i_data['spread'] * i_data['pstD_df'] -\
                          0.09 * ((i_data['volatility']/np.sqrt(252)).pow(0.65)) *\
                          ((i_data['pstD_df']/i_data['avgPV_l1d'])**0.6) * i_data['pstD_df']
    
    # clean the data
    i_data = i_data[i_data.datadate<=df.datadate.max()]
    #i_data = i_data.dropna(subset = ['clip','spread','volatility',col_signal_str, col_ret_str])
    
    # print buckets
    if not skip_bucket:
        for f in ['spread','volatility','SRISK_USE4', 'BETA_USE4', 'BTOP_USE4', 'EARNYILD_USE4', 
                  'GROWTH_USE4', 'LEVERAGE_USE4', 'LIQUIDTY_USE4', 'MOMENTUM_USE4', 'MOMENTUM_FAST', 
                  'SIZE_USE4']:
            try:
                i_data[f+'_bk'] = i_data.groupby('datadate')[f].apply(lambda x: pd.qcut(x,q=5,labels=[1,2,3,4,5]))
                print (f+'(bp): '+str(i_data.groupby(f+'_bk')[[col_ret_str,col_signal_str]].\
                
                   apply(lambda x: x[col_ret_str].multiply(pd.Series(np.sign(x[col_signal_str]))).mean()).multiply(10000).round(4).tolist()))
            except Exception as e:
                print (e)
                continue
    

    
    # daily summarization
    i_data = i_data.sort_values(['ticker', 'datadate'])
    i_data = i_data.reset_index(drop = True)
    o_daily = i_data.groupby('datadate').agg({'pnl':'sum','pnl_tcost':'sum'}).reset_index()
    o_daily = o_daily.dropna()
    
    o_daily['cumpnl'] = o_daily['pnl'].cumsum()
    o_daily['cumpnl_tcost'] = o_daily['pnl_tcost'].cumsum()
    o_daily = o_daily.set_index('datadate')
    
    
    # plot prep
    fig1 = plt.figure(figsize=(16,5))
    ax1 = fig1.add_subplot(121)
    
    # plot cumpnl
    ax1.plot(o_daily['cumpnl'])
    ax1.plot(o_daily['cumpnl_tcost']) ###!!!
    
    ax1.grid()
    ax1.set_ylabel('Cumulative Realized PNL', fontsize = 16)
    ax1.set_xlabel('Date',fontsize = 16)
    
    mean_pnl = np.round(o_daily['pnl'].mean() * 252 / 1e6)
    sr_pnl = np.round(o_daily['pnl'].mean() / o_daily['pnl'].std() * np.sqrt(252),2)
    mean_ret = np.round( (i_data['pnl'].sum() / i_data['gmv'].sum())*1e4,2)
    pt_ret = np.round( (i_data['pnl'].sum() / i_data['pstD_df'].sum())*1e4,2)
    ax1.text(0.01, 0.93, 'Annulized PNL: $' + str(mean_pnl) + ' MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.87, 'Annualized IR: ' + str(sr_pnl), verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.81, 'Daily Return: ' + str(mean_ret) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.75, 'Per Trade Return: ' + str(pt_ret) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    
    ax1.text(0.01, 0.72, '-----------------', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 5 )
    
    mean_pnl2 = np.round(o_daily['pnl_tcost'].mean() * 252 / 1e6)
    sr_pnl2 = np.round(o_daily['pnl_tcost'].mean() / o_daily['pnl_tcost'].std() * np.sqrt(252),2)
    mean_ret2 = np.round( (i_data['pnl_tcost'].sum() / i_data['gmv'].sum())*1e4,2)
    pt_ret2 = np.round( (i_data['pnl_tcost'].sum() / i_data['pstD_df'].sum())*1e4,2)
    ax
1.text(0.01, 0.69, 'Annulized PNL post-tcost: $' + str(mean_pnl2) + ' MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.63, 'Annualized IR post-tcost: ' + str(sr_pnl2), verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.56, 'Daily Return post-tcost: ' + str(mean_ret2) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.49, 'Per Trade Return post-tcost: ' + str(pt_ret2) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    
    ax1.set_title(col_signal_str, fontsize = 16)
    
    # plot gmv
    
    gmvlong = i_data[ i_data['pstD'] > 0].groupby('datadate')['gmv'].sum()
    gmvlong = gmvlong.reset_index()
    gmvlong.columns = ['datadate','long']
    gmvlong = gmvlong.set_index('datadate')
    gmvshort = i_data[ i_data['pstD'] < 0].groupby('datadate')['gmv'].sum()
    gmvshort = gmvshort.reset_index()
    gmvshort.columns = ['datadate','short']
    gmvshort = gmvshort.set_index('datadate')
    
    ax2 = fig1.add_subplot(122)
    gmv = pd.concat([gmvlong,gmvshort],axis=1)
    ax2.plot(gmv)
    
    ax2.grid()
    ax2.set_ylabel('GMV', fontsize = 16)
    ax2.set_xlabel('Date',fontsize = 16)
    
    totgmv = i_data.groupby('datadate')['gmv'].sum().mean()    
    to = np.round(i_data['pstD_df'].sum() / i_data['gmv'].sum() * 100)
    
    ax2.text(0.01, 0.93, 'Avg Long Size: ' + str(np.round(gmvlong['long'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.87, 'Avg Short Size: ' + str(np.round(gmvshort['short'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.81, 'Total Size: ' + str(np.round(totgmv/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.75, 'Turnover: ' + str(to) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    
    return i_data



def bt_us_linux(s, staic_data, col_clip_sgnl, col_ret='BarrRet_CLIP+1d'):
    
    # example
: o_1 = yu.bt_us_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ], i_sd, 'jobsactive_mr_qoq_rk')
    
    
    # dedup    
    s = s.drop_duplicates(subset=['Ticker','DataDate'], keep = 'last')
    
    # dropna
    s = s.dropna(subset=[col_clip_sgnl, col_ret])    
    
    # clip size
    s['clip'] = s['avgPVadj']*0.01
    s.loc[s['clip']>1e6, 'clip'] = 1e6
    
    # pst
    s['pos'] = s[col_clip_sgnl].multiply(s['clip'])
    
    
    #-------------------------------------------------------------------------
    # gf orignal
    #-------------------------------------------------------------------------
    
    s = s[['DataDate','Ticker', 'pos']]
    s = s.sort_values('DataDate')
    s = s.reset_index(drop=True)
    spos = s.pivot_table(index='Ticker',columns=['DataDate'], values='pos')
    spos = spos.fillna(0)
    spos = spos.unstack()
    spos = spos.reset_index()
    spos = spos.rename(columns={0:'pos'})
    spos = spos.sort_values(['Ticker','DataDate'])
    spos['pos_pre'] = spos.groupby(['Ticker'])['pos'].shift(1)
    spos = spos.fillna(0)
    spos = spos[ ~((spos['pos']==0) & (spos['pos_pre']==0))   ]
    spos['trdd'] = abs(spos['pos'] - spos['pos_pre'])
    spos['gmv'] = abs(spos['pos'])
    to = np.round(spos['trdd'].sum() / spos['gmv'].sum() * 100)
    spos = pd.merge(spos, staic_data[['DataDate','Ticker','spread','volatility','avgPVadj',col_ret]], how='inner')
    spos['pos_pnl'] = spos['pos'] * spos[col_ret]
    
    #*** extra        
    spos['pos_pnl_postcost'] = spos['pos_pnl'] \
                              - 0.3 * spos['spread'] * spos['trdd'] \
                              - 0.09 * ((spos['volatility']/np.sqrt(252)).pow(0.65)) \
                              * ((spos['trdd']/spos['avgPVadj'])**0.6) * spos['trdd']    
    #*** extra
    
    temp1 = spos.groupby('Ticker')['pos_pnl'].sum()
    temp1 = temp1.reset_index()
    temp2 = spos.groupby('Ticker')['trdd'].sum()
    temp2 = temp2.reset_index()
    temp3 = spos.groupby('Ticker')['spread'].mean()
    temp3 = temp3.reset_index()
    temp = pd.merge(temp1, temp2, on=['Ticker'], how='inner')
    temp = pd.merge(temp, temp3, on=['Ticker'], how='inner')
    temp['spread_bucket'] = pd.qcut(temp['spread'],10,labels=range(1,11))
    temp = temp.groupby('spread_bucket').agg({'pos_pnl':'sum','trdd':'sum','spread':'mean'})
    temp['ept_spd'] = temp['pos_pnl'] / temp['trdd'] / temp['spread']
    ept = np.round( (spos['pos_pnl'].sum() / spos['trdd'].sum())*1e4,2)
    ept_spd
 = np.round(temp['ept_spd'].mean(),2)
    #***
    #ret = spos.groupby('DataDate')['pos_pnl'].sum()
    ret = spos.groupby('DataDate')[['pos_pnl', 'pos_pnl_postcost']].sum()
    ret = ret.reset_index()
    ret = ret.dropna()
    ret['cumpnl'] = ret['pos_pnl'].cumsum()
    #*** extra   
    ret['cumpnl_postcost'] = ret['pos_pnl_postcost'].cumsum()
    #*** extra   
    ret = ret.set_index('DataDate')
    
    fig1 = plt.figure(figsize=(10,8))
    
    ax1 = fig1.add_subplot(211)
    ax1.plot(ret['cumpnl'])
    ax1.grid()
    ax1.set_ylabel('Cum. PNL', fontsize = 16)
    ax1.set_xlabel('Date',fontsize = 16)
    meanret = np.round( (spos['pos_pnl'].sum() / spos['gmv'].sum())*1e4,2)
    sr = np.round(ret['pos_pnl'].mean() / ret['pos_pnl'].std() * np.sqrt(252),2)
    hit = spos[spos['pos_pnl'] > 0].groupby('DataDate')['Ticker'].count() / spos[spos['pos_pnl'] != 0].groupby('DataDate')['Ticker'].count()
    hit = np.round(hit.mean()*100,2)
    ax1.text(0.01, 0.93, 'annualized sharpe: ' + str(sr), verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.87, 'daily return on gmv: ' + str(meanret) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.81, 'edge per trade: ' + str(ept) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.75, 'edge per trade per spread: ' + str(ept_spd), verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.69, 'hit rate: ' + str(hit) + '%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.63, 'turnover: ' + str(to) + '%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    #-------------------------------------------------------------------------
    
    
    sr_ac = np.round(ret['pos_pnl_postcost'].mean() / ret['pos_pnl_postcost'].std() * np.sqrt(252),2)
    ax1.text(0.01, 0.57, 'annualized sharpe (after cost): ' + str(sr_ac), verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.plot(ret['cumpnl_postcost'])
        
    gmvlong = spos[ spos['pos'] > 0].groupby('DataDate')['
gmv'].sum()
    gmvlong = gmvlong.reset_index()
    gmvlong.columns = ['DataDate','long']
    gmvlong = gmvlong.set_index('DataDate')
    gmvshort = spos[ spos['pos'] < 0].groupby('DataDate')['gmv'].sum()
    gmvshort = gmvshort.reset_index()
    gmvshort.columns = ['DataDate','short']
    gmvshort = gmvshort.set_index('DataDate')
    
    ax2 = fig1.add_subplot(212)
    gmv = pd.concat([gmvlong,gmvshort],axis=1)
    ax2.plot(gmv)
    
    ax2.grid()
    ax2.set_ylabel('GMV: '+ col_clip_sgnl, fontsize = 16)
    ax2.set_xlabel('Date',fontsize = 16)
    
    totgmv = spos.groupby('DataDate')['gmv'].sum().mean()    
    to = np.round(spos['trdd'].abs().sum() / spos['gmv'].abs().sum() * 100)
    
    ax2.text(0.01, 0.93, 'Avg Long Size: ' + str(np.round(gmvlong['long'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.87, 'Avg Short Size: ' + str(np.round(gmvshort['short'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.81, 'Total Size: ' + str(np.round(totgmv/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.75, 'Turnover: ' + str(to) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    
    
    
    return spos
    

def bt_us_linux_wochart(s, static_data, col_clip_sgnl, col_ret='BarrRet_CLIP+1d'):
    
    # example: o_1 = yu.bt_us_linux(icom[icom['DataDate'].between('2017-01-01', '2021-12-31') ], i_sd, 'jobsactive_mr_qoq_rk')
    
    
    # dedup    
    s = s.drop_duplicates(subset=['Ticker','DataDate'], keep = 'last')
    
    # dropna
    s = s.dropna(subset=[col_clip_sgnl, col_ret])    
    
    # clip size
    s['clip'] = s['avgPVadj']*0.01
    s.loc[s['clip']>1e6, 'clip'] = 1e6
    
    # pst
    s['pos'] = s[col_clip_sgnl].multiply(s['clip'])
    
    
    #-------------------------------------------------------------------------
    # gf orignal
    #-------------------------------------------------------------------------
    
    s = s[['DataDate','Ticker', 'pos']]
    s = s.sort_values('DataDate')
    s = s.reset_index(drop=True)
    spos = s.pivot_table(index='Ticker',columns=['DataDate'], values='pos')
    spos = spos.fillna(0)
    spos = spos.unstack()
    
spos = spos.reset_index()
    spos = spos.rename(columns={0:'pos'})
    spos = spos.sort_values(['Ticker','DataDate'])
    spos['pos_pre'] = spos.groupby(['Ticker'])['pos'].shift(1)
    spos = spos.fillna(0)
    spos = spos[ ~((spos['pos']==0) & (spos['pos_pre']==0))   ]
    spos['trdd'] = abs(spos['pos'] - spos['pos_pre'])
    spos['gmv'] = abs(spos['pos'])
    to = np.round(spos['trdd'].sum() / spos['gmv'].sum() * 100)
    spos = pd.merge(spos, static_data[['DataDate','Ticker','spread','volatility','avgPVadj',col_ret]], how='inner')
    spos['pos_pnl'] = spos['pos'] * spos[col_ret]
    spos['pos_pnl_postcost'] = spos['pos_pnl'] \
                              - 0.3 * spos['spread'] * spos['trdd'] \
                              - 0.09 * ((spos['volatility']/np.sqrt(252)).pow(0.65)) \
                              * ((spos['trdd']/spos['avgPVadj'])**0.6) * spos['trdd']
    temp1 = spos.groupby('Ticker')['pos_pnl'].sum()
    temp1 = temp1.reset_index()
    temp2 = spos.groupby('Ticker')['trdd'].sum()
    temp2 = temp2.reset_index()
    temp3 = spos.groupby('Ticker')['spread'].mean()
    temp3 = temp3.reset_index()
    temp = pd.merge(temp1, temp2, on=['Ticker'], how='inner')
    temp = pd.merge(temp, temp3, on=['Ticker'], how='inner')
    temp['spread_bucket'] = pd.qcut(temp['spread'],10,labels=range(1,11))
    temp = temp.groupby('spread_bucket').agg({'pos_pnl':'sum','trdd':'sum','spread':'mean'})
    temp['ept_spd'] = temp['pos_pnl'] / temp['trdd'] / temp['spread']
    ept = np.round( (spos['pos_pnl'].sum() / spos['trdd'].sum())*1e4,2)
    ept_spd = np.round(temp['ept_spd'].mean(),2)
    ret = spos.groupby('DataDate')['pos_pnl','pos_pnl_postcost'].sum()
    ret = ret.reset_index()
    ret = ret.dropna()
    ret['cumpnl'] = ret['pos_pnl'].cumsum()
    ret = ret.set_index('DataDate')
       
    
    #-------------------------------------------------------------------------
    
    meanret = np.round( (spos['pos_pnl'].sum() / spos['gmv'].sum())*1e4,2)
    sr = np.round(ret['pos_pnl'].mean() / ret['pos_pnl'].std() * np.sqrt(252),2)
    sr_ac = np.round(ret['pos_pnl_postcost'].mean() / ret['pos_pnl_postcost'].std() * np.sqrt(252),2)
    hit = spos[spos['pos_pnl'] > 0].groupby('DataDate')['Ticker'].count() / spos[spos['pos_pnl'] != 0].groupby('DataDate')['Ticker'].count()
    hit = np.round(hit.mean()*100,2)
        
    gmvlong = spos[ spos['pos'] > 0].groupby('DataDate')['gmv'].sum()
    gmvlong = gmvlong.reset_index()
    gmvlong.columns = ['DataDate','lo
ng']
    gmvlong = gmvlong.set_index('DataDate')
    gmvshort = spos[ spos['pos'] < 0].groupby('DataDate')['gmv'].sum()
    gmvshort = gmvshort.reset_index()
    gmvshort.columns = ['DataDate','short']
    gmvshort = gmvshort.set_index('DataDate')
    
    to = np.round(spos['trdd'].abs().sum() / spos['gmv'].abs().sum() * 100)
    
    return {'annualized sharpe': sr,
            'annualized sharpe ac': sr_ac,
            'daily return on gmv': meanret,
            'edge per trade': ept,
            'edge per trade per spread': ept_spd,
            'turnover': to,
            'Avg Long Size': np.round(gmvlong['long'].mean()/1e6),
            'Avg Short Size': np.round(gmvshort['short'].mean()/1e6)}
    
    

def bt_cn_15_linux(df, str_col_signal, str_col_ret, static_data = None, 
            tcost_method = 'daily', pst_type = 'clip', hedge='stock', test_short_limit = False):
    
    # this v15 backtest function uses FX-adjusted barra return
    # the clip is USD clip (max = 1m usd)
    # it does NOT restricts short position within shortable uni or shortable amount, if test_short_limit = True
    

    # df quality check
    if df.duplicated(subset = ['Ticker','DataDate'], keep = False).sum() > 0:
        raise Exception("Input df has duplicate ticker/datadate rows.")
    if pd.isnull(df[['Ticker','DataDate',str_col_signal,str_col_ret]]).any(axis = 1).sum() > 0:
        raise Exception("Input df has nan values.")
    
    # get df's tickers and date range
    i_tk = df['Ticker'].unique().tolist()
    i_df_min_date = (df['DataDate'].min()-pd.to_timedelta('1 day')).strftime('%Y-%m-%d')

    # get rid of unnecessary columns from df
    for f in ['spread','volatility','SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL',
              'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'MOMENTUM','DIVYILD', 'SHORTINT', 'VALUE']:
        try:
            df = df.drop(columns = [f])
        except:
            continue
        try:
            df = df.drop(columns = [f+'_bk'])
        except:
            continue
        try:
            df = df.drop(columns = [f+'_rk'])
        except:
            continue
    
    # get static data
    if static_data is not None:
        i_sd = static_data
    else:
        raise Exception('need a static data table.')
    
    i_sd = i_sd[(i_sd['DataDate'] + pd.to_timedelta('10 days')>=i_df_min_date)&(i_sd['Ticker'].isin(i_tk))]
    
    # merge sgnl and static data
    i_data = df.merge(i_sd, on = ['Ticker','DataDate'], how = 'ri
ght', suffixes = ['','_staticdata'])
    
    # clip size
    i_data['clip'] = i_data['avgPVadj_USD']*0.01
    i_data.loc[i_data['clip']>1e6, 'clip'] = 1e6
    
    # pst
    if pst_type == 'clip':
        i_data['pstD'] = i_data[str_col_signal].multiply(i_data['clip'])
    elif pst_type == 'dollar':
        i_data['pstD'] = i_data[str_col_signal]
        c_too_large = i_data['pstD'].abs()>i_data['clip']
        i_data.loc[c_too_large,'pstD'] = i_data.loc[c_too_large,'clip'].multiply(np.sign(i_data.loc[c_too_large,'pstD']))
    else:
        raise Exception("pst_type incorrect")
        
    # GF's function
    
    s = i_data[['Ticker','DataDate','pstD']]
    s = s.sort_values('DataDate')
    s = s.reset_index(drop=True)
    
    spos = s.pivot_table(index='Ticker',columns=['DataDate'], values='pstD')
    spos = spos.fillna(0)
    spos = spos.unstack()
    spos = spos.reset_index()
    spos = spos.rename(columns={0:'pos'})
    spos = spos.sort_values(['Ticker','DataDate'])
    spos['pos_pre'] = spos.groupby(['Ticker'])['pos'].shift(1)
    spos = spos.fillna(0)
    spos = spos[ ~((spos['pos']==0) & (spos['pos_pre']==0))   ]
    spos['trdd'] = spos['pos'] - spos['pos_pre']
    spos['abstrdd'] = abs(spos['trdd'])
    spos['gmv'] = abs(spos['pos'])
    
    to = np.round(spos['abstrdd'].sum() / spos['gmv'].sum() * 100)
    try:
        #spos = pd.merge(spos, i_sd[['DataDate','Ticker','spread','volatility','avgPVadj_USD',str_col_ret,'RawRet_USD+0d','average_weighted_rate_3m']], how='inner') #!
        spos = pd.merge(spos, i_sd[['DataDate','Ticker','spread','volatility','avgPVadj_USD',str_col_ret,'average_weighted_rate_3m']], how='inner') #!
    except:
        #spos = pd.merge(spos, i_sd[['DataDate','Ticker','spread','volatility','avgPVadj_USD',str_col_ret,'RawRet_USD+0d']], how='inner') #!
        spos = pd.merge(spos, i_sd[['DataDate','Ticker','spread','volatility','avgPVadj_USD',str_col_ret]], how='inner') #!
    
    spos['stamp'] = 0.0002
    condition = spos['trdd'] < 0
    spos.loc[condition,'stamp'] = 0.0012
    spos['stampcost'] = spos['stamp'] * spos['abstrdd']
    spos['instcost'] = 0.16 * spos['spread'] * spos['abstrdd']
    if 'average_weighted_rate_3m' in spos.columns.tolist():
        condition = (spos['pos'] < 0)
        spos.loc[condition,'borrowcost'] = - spos.loc[condition,'pos'] * spos.loc[condition,'average_weighted_rate_3m'] / 100 / 252
    else:
        condition = (spos['pos'] < 0)
        spos.loc[condition,'borrowcost'] = - spos.loc[
condition,'pos'] * 0.059 / 360
    spos.loc[spos['pos']>=0, 'borrowcost'] = 0
    if '+0d' in str_col_ret:
        print('using +0d return column ... ')
        spos['transcost'] = 0.068 * ((spos['volatility']/np.sqrt(252))**0.6) * ((spos['abstrdd']/spos['avgPVadj_USD']*2)**0.5) * spos['abstrdd']
        spos['permcost'] = 18.9 * ((spos['volatility']/np.sqrt(252))**2) * ((spos['abstrdd']/spos['avgPVadj_USD']*2)) * spos['abstrdd']
    else:
        spos['transcost'] = 0.068 * ((spos['volatility']/np.sqrt(252))**0.6) * ((spos['abstrdd']/spos['avgPVadj_USD'])**0.5) * spos['abstrdd']
        spos['permcost'] = 18.9 * ((spos['volatility']/np.sqrt(252))**2) * ((spos['abstrdd']/spos['avgPVadj_USD'])) * spos['abstrdd']
    spos['pnl_bc'] = spos['pos'] * spos[str_col_ret] 
    #c_hit_up = (spos['RawRet_USD+0d']>=0.0985) & (spos['pos']>0) & ((spos['pos'].shift(1)==0)|spos['pos'].shift(1).isnull()) #!
    #spos.loc[c_hit_up,'pnl_bc'] = 0 #!
    #c_hit_down = (spos['RawRet_USD+0d']<=-0.0985) & (spos['pos']<0) & ((spos['pos'].shift(1)==0)|spos['pos'].shift(1).isnull()) #!
    #spos.loc[c_hit_down,'pnl_bc'] = 0    #! 
    spos['pnl_ac'] = spos['pnl_bc'] - spos['stampcost'] - spos['instcost']- spos['transcost'] - spos['permcost']
    spos['pnl_ac_ab'] = spos['pnl_ac'] - spos['borrowcost']
    
    ret = spos.groupby('DataDate')['pnl_bc','pnl_ac','pnl_ac_ab'].sum()
    ret = ret.reset_index()
    ret = ret.dropna()
    ret['cumpnl_bc'] = ret['pnl_bc'].cumsum()
    ret['cumpnl_ac'] = ret['pnl_ac'].cumsum()
    ret['cumpnl_ac_ab'] = ret['pnl_ac_ab'].cumsum()
    
    sr_pnl_bc = np.round(ret['pnl_bc'].mean() / ret['pnl_bc'].std() * np.sqrt(252),2)
    sr_pnl_ac = np.round(ret['pnl_ac'].mean() / ret['pnl_ac'].std() * np.sqrt(252),2)
    sr_pnl_acab = np.round(ret['pnl_ac_ab'].mean() / ret['pnl_ac_ab'].std() * np.sqrt(252),2)
    
    mean_ret_bc = np.round( (spos['pnl_bc'].sum() / spos['gmv'].sum())*1e4,2)
    mean_ret_ac = np.round( (spos['pnl_ac'].sum() / spos['gmv'].sum())*1e4,2)
    
    ept = np.round( (spos['pnl_bc'].sum() / spos['abstrdd'].sum())*1e4,2)

    spos['spread_adj'] = spos['spread'] * 0.5 + spos['stamp']

    temp1 = spos.groupby('Ticker')['pnl_bc'].sum()
    temp1 = temp1.reset_index()
    temp2 = spos.groupby('Ticker')['abstrdd'].sum()
    temp2 = temp2.reset_index()
    temp3 = spos.groupby('Ticker')['spread_adj'].mean()
    temp3 = temp3.reset_index()
    
    temp = pd.merge(temp1, temp2, on=['Ticker'], how='inner')
    temp = pd.merge(temp, temp3, on=
['Ticker'], how='inner')
    
    temp['spread_buk'] = pd.qcut(temp['spread_adj'],10,labels=range(1,11))
    temp = temp.groupby('spread_buk').agg({'pnl_bc':'sum','abstrdd':'sum','spread_adj':'mean'})
    temp['ept_spd'] = temp['pnl_bc'] / temp['abstrdd'] / temp['spread_adj']
    
    ept_spd = np.round(temp['ept_spd'].mean(),2)
    

    ret = ret.set_index('DataDate')
    
    
    fig1 = plt.figure(figsize=(10,8))
    ax1 = fig1.add_subplot(211)
    ax1.plot(ret['cumpnl_bc'])
    ax1.plot(ret['cumpnl_ac'])
    ax1.plot(ret['cumpnl_ac_ab'])

    ax1.grid()
    ax1.set_ylabel('PNL', fontsize = 16)
    ax1.set_xlabel('Date',fontsize = 16)
    
    ax1.text(0.01, 0.87, 'Annualized Sharpe: ' + str(sr_pnl_bc) + '(bc), ' +  str(sr_pnl_ac) + ' (ac), '+ str(sr_pnl_acab)+' (acab)', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.81, 'Daily Return on GMV: ' + str(mean_ret_bc) + ' bps (bc), ' + str(mean_ret_ac) + ' bps (ac)', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.75, 'Edge Per Trade: ' + str(ept) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.69, 'Edge Per Trade Per Spread: ' + str(ept_spd), verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.63, 'Turnover: ' + str(to) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    spos_gmvret = spos.groupby('DataDate')[['pnl_ac','gmv']].sum()
    spos_gmvret_number = spos_gmvret['pnl_ac'].sum() / spos_gmvret[spos_gmvret['gmv']>0]['gmv'].mean() / len(spos_gmvret) * 252
    spos_gmvret_number = round(spos_gmvret_number*100,2)
    ax1.text(0.01, 0.57, 'GMV Ret: ' + str(spos_gmvret_number) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    
    
    # plot gmv
    
    
    gmvlong = spos[ spos['pos'] > 0].groupby('DataDate')['gmv'].sum()
    gmvlong = gmvlong.reset_index()
    gmvlong.columns = ['DataDate','long']
    gmvlong = gmvlong.set_index('DataDate')
    gmvshort = spos[ spos['pos'] < 0].groupby('DataDate')['gmv'].sum()
    gmvshort = gmvshort.reset_index()
    gmvshort.columns = ['DataDate','short']
    gmvshort = 
gmvshort.set_index('DataDate')
    
    ax2 = fig1.add_subplot(212)
    gmv = pd.concat([gmvlong,gmvshort],axis=1)
    ax2.plot(gmv)
    
    ax2.grid()
    ax2.set_ylabel('GMV', fontsize = 16)
    ax2.set_xlabel('Date',fontsize = 16)
    
    totgmv = spos.groupby('DataDate')['gmv'].sum().mean()    
    to = np.round(spos['abstrdd'].sum() / spos['gmv'].sum() * 100)
    
    ax2.text(0.01, 0.93, 'Avg Long Size: ' + str(np.round(gmvlong['long'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.87, 'Avg Short Size: ' + str(np.round(gmvshort['short'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.81, 'Total Size: ' + str(np.round(totgmv/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.75, 'Turnover: ' + str(to) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    
    
    return spos




def bt_cn_15_linux_wochart(df, str_col_signal, str_col_ret, static_data = None, 
            tcost_method = 'daily', pst_type = 'clip', hedge='stock', test_short_limit = False):
    
    # same as bt_cn_15, but without charts

    # df quality check
    if df.duplicated(subset = ['Ticker','DataDate'], keep = False).sum() > 0:
        raise Exception("Input df has duplicate ticker/datadate rows.")
    if pd.isnull(df[['Ticker','DataDate',str_col_signal,str_col_ret]]).any(axis = 1).sum() > 0:
        raise Exception("Input df has nan values.")
    
    # get df's tickers and date range
    i_tk = df['Ticker'].unique().tolist()
    i_df_min_date = (df['DataDate'].min()-pd.to_timedelta('1 day')).strftime('%Y-%m-%d')

    # get rid of unnecessary columns from df
    for f in ['spread','volatility','SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL',
              'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'MOMENTUM','DIVYILD', 'SHORTINT', 'VALUE']:
        try:
            df = df.drop(columns = [f])
        except:
            continue
        try:
            df = df.drop(columns = [f+'_bk'])
        except:
            continue
        try:
            df = df.drop(columns = [f+'_rk'])
        except:
            continue
    
    # get static data
    if static_data is not None:
      
  i_sd = static_data
    else:
        raise Exception('need a static data table.')
    
    i_sd = i_sd[(i_sd['DataDate'] + pd.to_timedelta('10 days')>=i_df_min_date)&(i_sd['Ticker'].isin(i_tk))]
    
    # merge sgnl and static data
    i_data = df.merge(i_sd, on = ['Ticker','DataDate'], how = 'right', suffixes = ['','_staticdata'])
    
    # clip size
    i_data['clip'] = i_data['avgPVadj_USD']*0.01
    i_data.loc[i_data['clip']>1e6, 'clip'] = 1e6
    
    # pst
    if pst_type == 'clip':
        i_data['pstD'] = i_data[str_col_signal].multiply(i_data['clip'])
    elif pst_type == 'dollar':
        i_data['pstD'] = i_data[str_col_signal]
        c_too_large = i_data['pstD'].abs()>i_data['clip']
        i_data.loc[c_too_large,'pstD'] = i_data.loc[c_too_large,'clip'].multiply(np.sign(i_data.loc[c_too_large,'pstD']))
    else:
        raise Exception("pst_type incorrect")
        
    # GF's function
    
    s = i_data[['Ticker','DataDate','pstD']]
    s = s.sort_values('DataDate')
    s = s.reset_index(drop=True)
    
    spos = s.pivot_table(index='Ticker',columns=['DataDate'], values='pstD')
    spos = spos.fillna(0)
    spos = spos.unstack()
    spos = spos.reset_index()
    spos = spos.rename(columns={0:'pos'})
    spos = spos.sort_values(['Ticker','DataDate'])
    spos['pos_pre'] = spos.groupby(['Ticker'])['pos'].shift(1)
    spos = spos.fillna(0)
    spos = spos[ ~((spos['pos']==0) & (spos['pos_pre']==0))   ]
    spos['trdd'] = spos['pos'] - spos['pos_pre']
    spos['abstrdd'] = abs(spos['trdd'])
    spos['gmv'] = abs(spos['pos'])
    
    to = np.round(spos['abstrdd'].sum() / spos['gmv'].sum() * 100)
    try:
        #spos = pd.merge(spos, i_sd[['DataDate','Ticker','spread','volatility','avgPVadj_USD',str_col_ret,'RawRet_USD+0d','average_weighted_rate_3m']], how='inner') #!
        spos = pd.merge(spos, i_sd[['DataDate','Ticker','spread','volatility','avgPVadj_USD',str_col_ret,'average_weighted_rate_3m']], how='inner') #!
    except:
        #spos = pd.merge(spos, i_sd[['DataDate','Ticker','spread','volatility','avgPVadj_USD',str_col_ret,'RawRet_USD+0d']], how='inner') #!
        spos = pd.merge(spos, i_sd[['DataDate','Ticker','spread','volatility','avgPVadj_USD',str_col_ret]], how='inner') #!
    
    spos['stamp'] = 0.0002
    condition = spos['trdd'] < 0
    spos.loc[condition,'stamp'] = 0.0012
    spos['stampcost'] = spos['stamp'] * spos['abstrdd']
    spos['instcost'] = 0.16 * spos['spread'] * spos['abstrdd']
    if 'average_weighted_rate_3m
' in spos.columns.tolist():
        condition = (spos['pos'] < 0)
        spos.loc[condition,'borrowcost'] = - spos.loc[condition,'pos'] * spos.loc[condition,'average_weighted_rate_3m'] / 100 / 252
    else:
        condition = (spos['pos'] < 0)
        spos.loc[condition,'borrowcost'] = - spos.loc[condition,'pos'] * 0.10 / 252
    spos.loc[spos['pos']>=0, 'borrowcost'] = 0
    if '+0d' in str_col_ret:
        print('using +0d return column ... ')
        spos['transcost'] = 0.068 * ((spos['volatility']/np.sqrt(252))**0.6) * ((spos['abstrdd']/spos['avgPVadj_USD']*2)**0.5) * spos['abstrdd']
        spos['permcost'] = 18.9 * ((spos['volatility']/np.sqrt(252))**2) * ((spos['abstrdd']/spos['avgPVadj_USD']*2)) * spos['abstrdd']
    else:
        spos['transcost'] = 0.068 * ((spos['volatility']/np.sqrt(252))**0.6) * ((spos['abstrdd']/spos['avgPVadj_USD'])**0.5) * spos['abstrdd']
        spos['permcost'] = 18.9 * ((spos['volatility']/np.sqrt(252))**2) * ((spos['abstrdd']/spos['avgPVadj_USD'])) * spos['abstrdd']
    spos['pnl_bc'] = spos['pos'] * spos[str_col_ret] 
    #c_hit_up = (spos['RawRet_USD+0d']>=0.0985) & (spos['pos']>0) & ((spos['pos'].shift(1)==0)|spos['pos'].shift(1).isnull()) #!
    #spos.loc[c_hit_up,'pnl_bc'] = 0 #!
    #c_hit_down = (spos['RawRet_USD+0d']<=-0.0985) & (spos['pos']<0) & ((spos['pos'].shift(1)==0)|spos['pos'].shift(1).isnull()) #!
    #spos.loc[c_hit_down,'pnl_bc'] = 0    #! 
    spos['pnl_ac'] = spos['pnl_bc'] - spos['stampcost'] - spos['instcost']- spos['transcost'] - spos['permcost']
    spos['pnl_ac_ab'] = spos['pnl_ac'] - spos['borrowcost']
    
    ret = spos.groupby('DataDate')['pnl_bc','pnl_ac','pnl_ac_ab'].sum()
    ret = ret.reset_index()
    ret = ret.dropna()
    ret['cumpnl_bc'] = ret['pnl_bc'].cumsum()
    ret['cumpnl_ac'] = ret['pnl_ac'].cumsum()
    ret['cumpnl_ac_ab'] = ret['pnl_ac_ab'].cumsum()
    
    sr_pnl_bc = np.round(ret['pnl_bc'].mean() / ret['pnl_bc'].std() * np.sqrt(252),2)
    sr_pnl_ac = np.round(ret['pnl_ac'].mean() / ret['pnl_ac'].std() * np.sqrt(252),2)
    sr_pnl_acab = np.round(ret['pnl_ac_ab'].mean() / ret['pnl_ac_ab'].std() * np.sqrt(252),2)
    
    mean_ret_bc = np.round( (spos['pnl_bc'].sum() / spos['gmv'].sum())*1e4,2)
    mean_ret_ac = np.round( (spos['pnl_ac'].sum() / spos['gmv'].sum())*1e4,2)
    
    ept = np.round( (spos['pnl_bc'].sum() / spos['abstrdd'].sum())*1e4,2)

    spos['spread_adj'] = spos['spread'] * 0.5 + spos['stamp']

    temp1 = spos.groupby('Ticker')['pnl_bc'].sum()
    temp
1 = temp1.reset_index()
    temp2 = spos.groupby('Ticker')['abstrdd'].sum()
    temp2 = temp2.reset_index()
    temp3 = spos.groupby('Ticker')['spread_adj'].mean()
    temp3 = temp3.reset_index()
    
    temp = pd.merge(temp1, temp2, on=['Ticker'], how='inner')
    temp = pd.merge(temp, temp3, on=['Ticker'], how='inner')
    
    temp['spread_buk'] = pd.qcut(temp['spread_adj'],10,labels=range(1,11))
    temp = temp.groupby('spread_buk').agg({'pnl_bc':'sum','abstrdd':'sum','spread_adj':'mean'})
    temp['ept_spd'] = temp['pnl_bc'] / temp['abstrdd'] / temp['spread_adj']
    
    ept_spd = np.round(temp['ept_spd'].mean(),2)

    ret = ret.set_index('DataDate')
        
    spos_gmvret = spos.groupby('DataDate')[['pnl_ac','gmv']].sum()
    spos_gmvret_number = spos_gmvret['pnl_ac'].sum() / spos_gmvret[spos_gmvret['gmv']>0]['gmv'].mean() / len(spos_gmvret) * 252
    spos_gmvret_number = round(spos_gmvret_number*100,2)
    
    gmvlong = spos[ spos['pos'] > 0].groupby('DataDate')['gmv'].sum()
    gmvlong = gmvlong.reset_index()
    gmvlong.columns = ['DataDate','long']
    gmvlong = gmvlong.set_index('DataDate')
    gmvshort = spos[ spos['pos'] < 0].groupby('DataDate')['gmv'].sum()
    gmvshort = gmvshort.reset_index()
    gmvshort.columns = ['DataDate','short']
    gmvshort = gmvshort.set_index('DataDate')
    
    to = np.round(spos['abstrdd'].sum() / spos['gmv'].sum() * 100)
    
    meanret = np.round( (spos['pnl_ac'].sum() / spos['gmv'].sum())*1e4,2)
    
    
    return {'sharpe bc': sr_pnl_bc,
            'sharpe ac': sr_pnl_ac,
            'sharpe acab': sr_pnl_acab,
            'daily return on gmv': meanret,
            'edge per trade': ept,
            'edge per trade per spread': ept_spd, 
            'turnover': to,
            'Avg Long Size': np.round(gmvlong['long'].mean()/1e6),
            'Avg Short Size': np.round(gmvshort['short'].mean()/1e6)}



    
    
def create_cn_decay(df, col_sgnl):
    ###!!! not done yet
    # I need to: change from S to /dat/summit_capital
    # also this S drive data is not up to date, I need to replace it with the most recent future Y data 
    # col_sgnl: binary signal only: 0.5 and 1 are the same
    
    i_sd = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\util_sd_create_decay.parquet')
    
    # cleanse signal column
    df = df[['ticker', 'datadate', col_sgnl]]
    df = df[df[col_sgnl].notnull() & (df[col_sgnl]!= False) & (df[col_sgnl]!=0)]
    
    # merge sd
    df = df.merge(i_sd, on = ['ticker', 'data
date'], how = 'inner')
    
    # total clip per datadate
    df['total_df_clip'] = df['clip'].sum()
    
    # determine future bret columns
    col_bret = sorted([int(c[6:-1]) for c in df.columns.tolist() if c[:4]=='bret'])
    col_bret_dict = {c: int(c[6:-1]) for c in df.columns.tolist() if c[:4]=='bret'}
    df = df.rename(columns=col_bret_dict)
    
    # calculate return    
    o_clip_w_mean = df[col_bret].multiply(df['clip'], axis=0).divide(df['total_df_clip'], axis=0).sum(axis=0)
    o_cnt = df[col_bret].count(axis = 0)
    o_clip_w_demean_sqr = (df[col_bret].sub(o_clip_w_mean,axis=1))**2
    o_clip_var = o_clip_w_demean_sqr.multiply(df['clip'], axis=0).divide(df['total_df_clip'], axis=0).sum(axis=0)
    o_tstat = o_clip_w_mean.divide(np.sqrt(o_clip_var)).multiply(np.sqrt(o_cnt)).round(1)
    
    # plot
    
    fig, ax1 = plt.subplots(figsize=(11,4))
    
    ax1.bar(o_clip_w_mean.index.astype(str), o_clip_w_mean*10000, align = 'center')
    ax1.grid()
    ax1.set_xticklabels([])
    ptable(ax1, pd.DataFrame(o_tstat).rename(columns={0:'t'}).T, cellLoc='center',loc='bottom',bbox=[1/len(o_clip_w_mean),-0.15,1-2/len(o_clip_w_mean),0.15], FONTSIZE=20, fontsize=20).set_fontsize(20)
    ax1.set_ylabel('Barra Return ac (bp)')
    ax1.set_xlabel('days after signal', labelpad = 30)







from statsmodels.stats.anova import anova_lm
def create_cn_3x3_linux(s, bucketname, desname, col_ret='BarrRet_CLIP_USD+1d'):
    
        
    tgb = s.groupby(bucketname)
    
    bmin = int(s[bucketname].min())
    bmax = int(s[bucketname].max())

    bt1 = tgb[[desname]].mean().rename(columns=dict([[desname,'mean']]))
    fig = plt.figure(figsize=(15,15))
    ax1 = fig.add_subplot(331)
    ax1.bar(bt1.index, bt1['mean'], align = 'center')
    ax1.grid()
    ax1.set_xlim(bmin-0.5,bmax+0.5)
    ax1.set_xticks(range(bmin,bmax+1))
    ax1.set_xticklabels([])
    bt1['mean'] = bt1['mean'].apply(lambda r: np.round(r,2))
    ptable(ax1, bt1[['mean']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax1.set_ylabel('avg_'+desname)
    
    bt2 = tgb[['Ticker']].count().rename(columns={'Ticker':'mean'})
    bt2['mean'] = bt2['mean'].apply(lambda r: np.int(r/1e3))
    ax2 = fig.add_subplot(332)
    ax2.bar(bt2.index, bt2['mean'], align = 'center')
    ax2.grid()
    ax2.set_xlim(bmin-0.5,bmax+0.5)
    ax2.set_xticks(range(bmin,bmax+1))
    ax2.set_xticklabels([])
    ptable(ax2, bt2[['mean']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax2.set_yl
abel('tot_count (K)')

    bt3 = tgb[['Ticker']].apply(lambda r: len(np.unique(r)))
    bt3 = bt3.reset_index()
    bt3.columns = ['b1','mean']
    bt3 = bt3.set_index('b1')
    ax3 = fig.add_subplot(333)
    ax3.bar(bt2.index, bt3['mean'], align = 'center')
    ax3.grid()
    ax3.set_xlim(bmin-0.5,bmax+0.5)
    ax3.set_xticks(range(bmin,bmax+1))
    ax3.set_xticklabels([])
    ptable(ax3, bt3[['mean']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax3.set_ylabel('uniq_ticker')
 
    bt4 = tgb[['avgPVadj_USD']].mean().rename(columns={'avgPVadj_USD':'mean'})
    bt4['mean'] = bt4['mean'].apply(lambda r: np.round(r/1e6,2))
    ax4 = fig.add_subplot(334)
    ax4.bar(bt4.index, bt4['mean'], align = 'center')
    ax4.grid()
    ax4.set_xlim(bmin-0.5,bmax+0.5)
    ax4.set_xticks(range(bmin,bmax+1))
    ax4.set_xticklabels([])
    ptable(ax4, bt4[['mean']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax4.set_ylabel('avg_adv ($mm)')

    bt5 = tgb[['volatility']].mean().rename(columns={'volatility':'mean'})
    bt5['mean'] = bt5['mean'].apply(lambda r: np.round(r*100,2))
    ax5 = fig.add_subplot(335)
    ax5.bar(bt5.index, bt5['mean'], align = 'center')
    ax5.grid()
    ax5.set_xlim(bmin-0.5,bmax+0.5)
    ax5.set_xticks(range(bmin,bmax+1))
    ax5.set_xticklabels([])
    ptable(ax5, bt5[['mean']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax5.set_ylabel('avg_vol (%)')

    bt6 = tgb[['spread']].mean().rename(columns={'spread':'mean'})
    bt6['mean'] = bt6['mean'].apply(lambda r: np.round(r*1e4,2))
    ax6 = fig.add_subplot(336)
    ax6.bar(bt6.index, bt6['mean'], align = 'center')
    ax6.grid()
    ax6.set_xlim(bmin-0.5,bmax+0.5)
    ax6.set_xticks(range(bmin,bmax+1))
    ax6.set_xticklabels([])
    ptable(ax6, bt6[['mean']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax6.set_ylabel('avg_spread (bps)')
    
    if 'clip' not in s.columns.tolist():
        s['clip'] = s['avgPVadj_USD']*0.01
        s.loc[s['clip']>1e6,'clip'] = 1e6
    
    s['BarrRet'] = s[col_ret]
    s1 = s[bucketname + ['BarrRet','clip']]
    s1 = s1.dropna()
    x_vars = ['C('+b+')' for b in bucketname]
    model = ols('BarrRet ~ ' + '+'.join(x_vars), data=s1).fit()
    aov_table = anova_lm(model, typ=2)
    aov_table = aov_table.reset_index().rename(columns={'index': 'ANOVA'})
    aov_table[['sum_sq','df','F','PR(>F)']] = aov_table[['sum_sq','df','F','PR(>F)']].apply(lambda x: round(x,3))
    aov_table.loc[0,'ANOVA
'] = 'Buckets'
    aov_table = aov_table.append({'ANOVA':'F', 'sum_sq':'PR(>F)'}, sort = False, ignore_index  = True)
    aov_table = aov_table.append({'ANOVA':aov_table['F'].values[0], 'sum_sq':aov_table['PR(>F)'].values[0]}, sort = False, ignore_index  = True)
    aov_table = aov_table.append({'ANOVA':'T-test'}, sort = False, ignore_index  = True)
    aov_table = aov_table.append({'ANOVA':'1st BK#', 'sum_sq':'2nd BK#', 'df':'t-stat'}, sort = False, ignore_index  = True)
    bk_series = s1[bucketname].dropna().drop_duplicates().sort_values(bucketname).reset_index(drop=True)
    for bk_i in range(len(bk_series)-1):
        tdata1 = s1[ (s1[bucketname]==bk_series.loc[bk_i].tolist()).all(axis=1) ]['BarrRet'].values
        tdata2 = s1[ (s1[bucketname]==bk_series.loc[bk_i+1].tolist()).all(axis=1) ]['BarrRet'].values
        aov_table = aov_table.append({'ANOVA': float(bk_series[bucketname].loc[bk_i]), 'sum_sq': float(bk_series[bucketname].loc[bk_i+1]), 
                                      'df': round(scipy.stats.ttest_ind(tdata2, tdata1)[0],3) }, sort = False, ignore_index  = True)
    aov_table = aov_table.drop(columns = ['F', 'PR(>F)'])   
    aov_table = aov_table.replace(np.nan, '')
    ax7 = fig.add_subplot(337)
    ax7.axis('off')
    ptable(ax7, aov_table, cellLoc='center',loc='top',bbox=[0, 0,1,1])   
    ax7.set_ylabel('ANOVA and Adjacent-pair T')
    
    try:
        s['BarrRet_SRISK'] = s['BarrRet_SRISK_USD+1d']    
    except: 
        s['BarrRet_SRISK'] = s['BarrRet_CLIP_USD+1d']    
    s2 = s[bucketname + ['BarrRet_SRISK','clip']]
    s2 = s2.dropna()
    bt8_1 = s2.groupby(bucketname).apply(lambda r: pd.Series(np.average(r[['BarrRet_SRISK']],weights=r['clip'],axis=0),['mean']))
    bt8_1 = bt8_1.reset_index()
    s2 = pd.merge(s2, bt8_1, on=bucketname, how='left')
    s2['BarrRet_SRISK_demean_sqr'] = (s2['BarrRet_SRISK'] - s2['mean'])**2
    bt8_2 = s2.groupby(bucketname).apply(lambda r: pd.Series(np.average(r[['BarrRet_SRISK_demean_sqr']],weights=r['clip'],axis=0),['BarrRet_SRISK_var']))
    bt8_3 = s2.groupby(bucketname)[['clip']].count().rename(columns={'clip':'num'})
    bt8_1 = bt8_1.set_index(bucketname)
    bt8 = pd.concat([bt8_1,bt8_2,bt8_3],axis=1)
    bt8['tstats'] = bt8['mean'] / np.sqrt(bt8['BarrRet_SRISK_var']) * np.sqrt(bt8['num'])
    bt8['tstats'] = bt8['tstats'].apply(lambda r: np.round(r,2))
    bt8['mean'] = bt8['mean'].apply(lambda r: np.round(r*1e4,2))
    ax8 = fig.add_subplot(338)
    ax8.bar(bt8.index, bt8['mean'], a
lign = 'center')
    ax8.grid()
    ax8.set_xlim(bmin-0.5,bmax+0.5)
    ax8.set_xticks(range(bmin,bmax+1))
    ax8.set_xticklabels([])
    ptable(ax8, bt8[['mean','tstats']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax8.set_ylabel('BarrRet_SRISK (bps)')


    s['BarrRet_CLIP'] = s[col_ret]
    s3 = s[bucketname + ['BarrRet_CLIP','clip']]
    s3 = s3.dropna()
    bt9_1 = s3.groupby(bucketname).apply(lambda r: pd.Series(np.average(r[['BarrRet_CLIP']],weights=r['clip'],axis=0),['mean']))
    bt9_1 = bt9_1.reset_index()
    s3 = pd.merge(s3, bt9_1, on=bucketname, how='left')
    s3['BarrRet_CLIP_demean_sqr'] = (s3['BarrRet_CLIP'] - s3['mean'])**2
    bt9_2 = s3.groupby(bucketname).apply(lambda r: pd.Series(np.average(r[['BarrRet_CLIP_demean_sqr']],weights=r['clip'],axis=0),['BarrRet_CLIP_var']))
    bt9_3 = s3.groupby(bucketname)[['clip']].count().rename(columns={'clip':'num'})
    bt9_1 = bt9_1.set_index(bucketname)
    bt9 = pd.concat([bt9_1,bt9_2,bt9_3],axis=1)
    bt9['tstats'] = bt9['mean'] / np.sqrt(bt9['BarrRet_CLIP_var']) * np.sqrt(bt9['num'])
    bt9['tstats'] = bt9['tstats'].apply(lambda r: np.round(r,2))
    bt9['mean'] = bt9['mean'].apply(lambda r: np.round(r*1e4,2))
    ax9 = fig.add_subplot(339)
    ax9.bar(bt9.index, bt9['mean'], align = 'center')
    ax9.grid()
    ax9.set_xlim(bmin-0.5,bmax+0.5)
    ax9.set_xticks(range(bmin,bmax+1))
    ax9.set_xticklabels([])
    ptable(ax9, bt9[['mean','tstats']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax9.set_ylabel('BarrRet_CLIP (bps)')




def create_cn_3x3_linux_wochart(s, bucketname, desname):
    
    if 'clip' not in s.columns.tolist():
        s['clip'] = s['avgPVadj']*0.01
        s.loc[s['clip']>1e6,'clip'] = 1e6
           
    s['BarrRet_CLIP'] = s['BarrRet_CLIP_USD+1d']
    s3 = s[bucketname + ['BarrRet_CLIP','clip']]
    s3 = s3.dropna()
    bt9_1 = s3.groupby(bucketname).apply(lambda r: pd.Series(np.average(r[['BarrRet_CLIP']],weights=r['clip'],axis=0),['mean']))
    bt9_1 = bt9_1.reset_index()
    s3 = pd.merge(s3, bt9_1, on=bucketname, how='left')
    s3['BarrRet_CLIP_demean_sqr'] = (s3['BarrRet_CLIP'] - s3['mean'])**2
    bt9_2 = s3.groupby(bucketname).apply(lambda r: pd.Series(np.average(r[['BarrRet_CLIP_demean_sqr']],weights=r['clip'],axis=0),['BarrRet_CLIP_var']))
    bt9_3 = s3.groupby(bucketname)[['clip']].count().rename(columns={'clip':'num'})
    bt9_1 = bt9_1.set_index(bucketname)
    bt9 = pd.concat([bt9_1,bt9_2,bt9_3],axis=1)
    bt9['t
stats'] = bt9['mean'] / np.sqrt(bt9['BarrRet_CLIP_var']) * np.sqrt(bt9['num'])
    bt9['tstats'] = bt9['tstats'].apply(lambda r: np.round(r,2))
    bt9['mean'] = bt9['mean'].apply(lambda r: np.round(r*1e4,2))    
    bt9['num'] = bt9['num'].astype('Int64')
    
    bt9_dict = {}
    for i in range(1,len(bt9)+1):
        bt9_dict['ret'+str(i)] = bt9['mean'].values[i-1]
    for i in range(1,len(bt9)+1):
        bt9_dict['tstat'+str(i)] = bt9['tstats'].values[i-1]
    for i in range(1,len(bt9)+1):
        bt9_dict['cnt'+str(i)] = bt9['num'].values[i-1]
    bt9_dict['is_mono'] = (bt9['mean'].is_monotonic_increasing | bt9['mean'].is_monotonic_decreasing) &\
                           bt9['mean'].notnull().all() &\
                           (bt9['mean'].count() in [5, 10] )
    bt9_dict['bk_name'] = bucketname[0]

    return bt9_dict





def create_us_3x3_linux(s, bucketname, desname):
    
       
    tgb = s.groupby(bucketname)
    
    bmin = int(s[bucketname].min())
    bmax = int(s[bucketname].max())

    bt1 = tgb[[desname]].mean().rename(columns=dict([[desname,'mean']]))
    fig = plt.figure(figsize=(15,15))
    ax1 = fig.add_subplot(331)
    ax1.bar(bt1.index, bt1['mean'], align = 'center')
    ax1.grid()
    ax1.set_xlim(bmin-0.5,bmax+0.5)
    ax1.set_xticks(range(bmin,bmax+1))
    ax1.set_xticklabels([])
    bt1['mean'] = bt1['mean'].apply(lambda r: np.round(r,2))
    ptable(ax1, bt1[['mean']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax1.set_ylabel('avg_'+desname)
    
    bt2 = tgb[['Ticker']].count().rename(columns={'Ticker':'mean'})
    bt2['mean'] = bt2['mean'].apply(lambda r: np.int(r/1e3))
    ax2 = fig.add_subplot(332)
    ax2.bar(bt2.index, bt2['mean'], align = 'center')
    ax2.grid()
    ax2.set_xlim(bmin-0.5,bmax+0.5)
    ax2.set_xticks(range(bmin,bmax+1))
    ax2.set_xticklabels([])
    ptable(ax2, bt2[['mean']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax2.set_ylabel('tot_count (K)')

    bt3 = tgb[['Ticker']].apply(lambda r: len(np.unique(r)))
    bt3 = bt3.reset_index()
    bt3.columns = ['b1','mean']
    bt3 = bt3.set_index('b1')
    ax3 = fig.add_subplot(333)
    ax3.bar(bt2.index, bt3['mean'], align = 'center')
    ax3.grid()
    ax3.set_xlim(bmin-0.5,bmax+0.5)
    ax3.set_xticks(range(bmin,bmax+1))
    ax3.set_xticklabels([])
    ptable(ax3, bt3[['mean']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax3.set_ylabel('uniq_ticker')
 
    bt4 = tgb[['avgPVadj']].mean().rename
(columns={'avgPVadj':'mean'})
    bt4['mean'] = bt4['mean'].apply(lambda r: np.round(r/1e6,2))
    ax4 = fig.add_subplot(334)
    ax4.bar(bt4.index, bt4['mean'], align = 'center')
    ax4.grid()
    ax4.set_xlim(bmin-0.5,bmax+0.5)
    ax4.set_xticks(range(bmin,bmax+1))
    ax4.set_xticklabels([])
    ptable(ax4, bt4[['mean']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax4.set_ylabel('avg_adv ($mm)')

    bt5 = tgb[['volatility']].mean().rename(columns={'volatility':'mean'})
    bt5['mean'] = bt5['mean'].apply(lambda r: np.round(r*100,2))
    ax5 = fig.add_subplot(335)
    ax5.bar(bt5.index, bt5['mean'], align = 'center')
    ax5.grid()
    ax5.set_xlim(bmin-0.5,bmax+0.5)
    ax5.set_xticks(range(bmin,bmax+1))
    ax5.set_xticklabels([])
    ptable(ax5, bt5[['mean']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax5.set_ylabel('avg_vol (%)')

    bt6 = tgb[['spread']].mean().rename(columns={'spread':'mean'})
    bt6['mean'] = bt6['mean'].apply(lambda r: np.round(r*1e4,2))
    ax6 = fig.add_subplot(336)
    ax6.bar(bt6.index, bt6['mean'], align = 'center')
    ax6.grid()
    ax6.set_xlim(bmin-0.5,bmax+0.5)
    ax6.set_xticks(range(bmin,bmax+1))
    ax6.set_xticklabels([])
    ptable(ax6, bt6[['mean']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax6.set_ylabel('avg_spread (bps)')
    
    if 'clip' not in s.columns:
        s['clip'] = s['avgPVadj']*0.01
        s.loc[s['clip']>1e6,'clip'] = 1e6
    
    s['BarrRet'] = s['BarrRet_SRISK+1d']
    s1 = s[bucketname + ['BarrRet','clip']]
    s1 = s1.dropna()
    x_vars = ['C('+b+')' for b in bucketname]
    model = ols('BarrRet ~ ' + '+'.join(x_vars), data=s1).fit()
    aov_table = anova_lm(model, typ=2)
    aov_table = aov_table.reset_index().rename(columns={'index': 'ANOVA'})
    aov_table[['sum_sq','df','F','PR(>F)']] = aov_table[['sum_sq','df','F','PR(>F)']].apply(lambda x: round(x,3))
    aov_table.loc[0,'ANOVA'] = 'Buckets'
    aov_table = aov_table.append({'ANOVA':'F', 'sum_sq':'PR(>F)'}, sort = False, ignore_index  = True)
    aov_table = aov_table.append({'ANOVA':aov_table['F'].values[0], 'sum_sq':aov_table['PR(>F)'].values[0]}, sort = False, ignore_index  = True)
    aov_table = aov_table.append({'ANOVA':'T-test'}, sort = False, ignore_index  = True)
    aov_table = aov_table.append({'ANOVA':'1st BK#', 'sum_sq':'2nd BK#', 'df':'t-stat'}, sort = False, ignore_index  = True)
    bk_series = s1[bucketname].dropna().drop_duplicates().sort_values(bucket
name).reset_index(drop=True)
    for bk_i in range(len(bk_series)-1):
        tdata1 = s1[ (s1[bucketname]==bk_series.loc[bk_i].tolist()).all(axis=1) ]['BarrRet'].values
        tdata2 = s1[ (s1[bucketname]==bk_series.loc[bk_i+1].tolist()).all(axis=1) ]['BarrRet'].values
        aov_table = aov_table.append({'ANOVA': float(bk_series[bucketname].loc[bk_i]), 'sum_sq': float(bk_series[bucketname].loc[bk_i+1]), 
                                      'df': round(scipy.stats.ttest_ind(tdata2, tdata1)[0],3) }, sort = False, ignore_index  = True)
    aov_table = aov_table.drop(columns = ['F', 'PR(>F)'])   
    aov_table = aov_table.replace(np.nan, '')
    ax7 = fig.add_subplot(337)
    ax7.axis('off')
    ptable(ax7, aov_table, cellLoc='center',loc='top',bbox=[0, 0,1,1])   
    ax7.set_ylabel('ANOVA and Adjacent-pair T')
   
    s['BarrRet_SRISK'] = s['BarrRet_SRISK+1d']
    s2 = s[bucketname + ['BarrRet_SRISK','clip']]
    s2 = s2.dropna()
    bt8_1 = s2.groupby(bucketname).apply(lambda r: pd.Series(np.average(r[['BarrRet_SRISK']],weights=r['clip'],axis=0),['mean']))
    bt8_1 = bt8_1.reset_index()
    s2 = pd.merge(s2, bt8_1, on=bucketname, how='left')
    s2['BarrRet_SRISK_demean_sqr'] = (s2['BarrRet_SRISK'] - s2['mean'])**2
    bt8_2 = s2.groupby(bucketname).apply(lambda r: pd.Series(np.average(r[['BarrRet_SRISK_demean_sqr']],weights=r['clip'],axis=0),['BarrRet_SRISK_var']))
    bt8_3 = s2.groupby(bucketname)[['clip']].count().rename(columns={'clip':'num'})
    bt8_1 = bt8_1.set_index(bucketname)
    bt8 = pd.concat([bt8_1,bt8_2,bt8_3],axis=1)
    bt8['tstats'] = bt8['mean'] / np.sqrt(bt8['BarrRet_SRISK_var']) * np.sqrt(bt8['num'])
    bt8['tstats'] = bt8['tstats'].apply(lambda r: np.round(r,2))
    bt8['mean'] = bt8['mean'].apply(lambda r: np.round(r*1e4,2))
    ax8 = fig.add_subplot(338)
    ax8.bar(bt8.index, bt8['mean'], align = 'center')
    ax8.grid()
    ax8.set_xlim(bmin-0.5,bmax+0.5)
    ax8.set_xticks(range(bmin,bmax+1))
    ax8.set_xticklabels([])
    ptable(ax8, bt8[['mean','tstats']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax8.set_ylabel('BarrRet_SRISK (bps)')


    s['BarrRet_CLIP'] = s['BarrRet_CLIP+1d']
    s3 = s[bucketname + ['BarrRet_CLIP','clip']]
    s3 = s3.dropna()
    bt9_1 = s3.groupby(bucketname).apply(lambda r: pd.Series(np.average(r[['BarrRet_CLIP']],weights=r['clip'],axis=0),['mean']))
    bt9_1 = bt9_1.reset_index()
    s3 = pd.merge(s3, bt9_1, on=bucketname, how='left')
    s3['BarrRet_CLIP_demean_sqr'] = (
s3['BarrRet_CLIP'] - s3['mean'])**2
    bt9_2 = s3.groupby(bucketname).apply(lambda r: pd.Series(np.average(r[['BarrRet_CLIP_demean_sqr']],weights=r['clip'],axis=0),['BarrRet_CLIP_var']))
    bt9_3 = s3.groupby(bucketname)[['clip']].count().rename(columns={'clip':'num'})
    bt9_1 = bt9_1.set_index(bucketname)
    bt9 = pd.concat([bt9_1,bt9_2,bt9_3],axis=1)
    bt9['tstats'] = bt9['mean'] / np.sqrt(bt9['BarrRet_CLIP_var']) * np.sqrt(bt9['num'])
    bt9['tstats'] = bt9['tstats'].apply(lambda r: np.round(r,2))
    bt9['mean'] = bt9['mean'].apply(lambda r: np.round(r*1e4,2))
    ax9 = fig.add_subplot(339)
    ax9.bar(bt9.index, bt9['mean'], align = 'center')
    ax9.grid()
    ax9.set_xlim(bmin-0.5,bmax+0.5)
    ax9.set_xticks(range(bmin,bmax+1))
    ax9.set_xticklabels([])
    ptable(ax9, bt9[['mean','tstats']].T, cellLoc='center',loc='bottom',bbox=[0,-0.15,1,0.15])   
    ax9.set_ylabel('BarrRet_CLIP (bps)')



def create_us_3x3_linux_wochart(s, bucketname, desname):
    
    if 'clip' not in s.columns.tolist():
        s['clip'] = s['avgPVadj']*0.01
        s.loc[s['clip']>1e6,'clip'] = 1e6
           
    s['BarrRet_CLIP'] = s['BarrRet_CLIP+1d']
    s3 = s[bucketname + ['BarrRet_CLIP','clip']]
    s3 = s3.dropna()
    bt9_1 = s3.groupby(bucketname).apply(lambda r: pd.Series(np.average(r[['BarrRet_CLIP']],weights=r['clip'],axis=0),['mean']))
    bt9_1 = bt9_1.reset_index()
    s3 = pd.merge(s3, bt9_1, on=bucketname, how='left')
    s3['BarrRet_CLIP_demean_sqr'] = (s3['BarrRet_CLIP'] - s3['mean'])**2
    bt9_2 = s3.groupby(bucketname).apply(lambda r: pd.Series(np.average(r[['BarrRet_CLIP_demean_sqr']],weights=r['clip'],axis=0),['BarrRet_CLIP_var']))
    bt9_3 = s3.groupby(bucketname)[['clip']].count().rename(columns={'clip':'num'})
    bt9_1 = bt9_1.set_index(bucketname)
    bt9 = pd.concat([bt9_1,bt9_2,bt9_3],axis=1)
    bt9['tstats'] = bt9['mean'] / np.sqrt(bt9['BarrRet_CLIP_var']) * np.sqrt(bt9['num'])
    bt9['tstats'] = bt9['tstats'].apply(lambda r: np.round(r,2))
    bt9['mean'] = bt9['mean'].apply(lambda r: np.round(r*1e4,2))    
    bt9['num'] = bt9['num'].astype('Int64')
    
    bt9_dict = {}
    for i in range(1,len(bt9)+1):
        bt9_dict['ret'+str(i)] = bt9['mean'].values[i-1]
    for i in range(1,len(bt9)+1):
        bt9_dict['tstat'+str(i)] = bt9['tstats'].values[i-1]
    for i in range(1,len(bt9)+1):
        bt9_dict['cnt'+str(i)] = bt9['num'].values[i-1]
    bt9_dict['is_mono'] = (bt9['mean'].is_monotonic_increasing | bt9['mean'].is_monot
onic_decreasing) &\
                           bt9['mean'].notnull().all() &\
                           (bt9['mean'].count() in [5, 10] )
    bt9_dict['bk_name'] = bucketname[0]

    return bt9_dict



    


def mosekoptcn_single_alpha(new_port, old_port, universe, rskexpscaps, secexpscaps, indexpscaps, dn = 10e9, lam = 3, borrow_cap = 0.3, use_etb_universe=True, use_etb_amount=True):
    
    # in github, the comment is version of no gmv neutral
    
    # =============================================================================
    # new_port takes T's portfolio of columns: Ticker, alpha
    # old_port takes T-1d's portfolio of columns: Ticker, opt_shr_old (T-1d's shares)
    # universe is the T-1d universe which has columns: Ticker, Price (T-1d's price), avgPVadj, Avail_Amount_ABC (T's total available shortable amounts in shares)
    # gmv in dollars: e.g. 50e6,
    # lam is the coefficient before risk that needs to be tuned for optimized portfolio,
    # rskexpscaps/secexpscaps/indexpscaps are dictionaries.
    # sample for indexpscaps/secexpscaps/rskexpscaps:
    
    #indnames = [ 'AIRLINES','AUTOCOMP','BANKS','BIOTECH','CAPGOODS','CHEMICAL','COMMSVCS','COMMUNIC','COMPUTER','CONSDUR','CONSTPP',
    #             'CONSVCS','DIVFINAN','DIVMETAL','ENERGY','FOODPRD','FOODRETL','HEALTH','HSHLDPRD','INSURAN','INTERNET','MEDIA','OILEXPL',
    #             'OILGAS','PHARMAC','PRECMETL','REALEST','RETAIL','SEMICOND','SOFTWARE','STEEL','TELECOM','TRANSPRT','UTILITY']
    #indexpscaps = dict([ (x, 0.02) for x in indnames ])
    
    #secnames = ['W_SECTOR_10','W_SECTOR_15','W_SECTOR_20','W_SECTOR_25','W_SECTOR_30','W_SECTOR_35','W_SECTOR_40','W_SECTOR_45','W_SECTOR_50','W_SECTOR_55','W_SECTOR_60']
    #secexpscaps = dict([ (x, 0.02) for x in secnames ]) 
    
    #rsknames = ['BETA','MOMENTUM','SIZE','EARNYILD','RESVOL','GROWTH','DIVYILD','BTOP','LEVERAGE','LIQUIDTY','SIZENL']
    #rskexpscaps = dict([ (x, 0.02) for x in rsknames ])
    # =============================================================================


    
    #==============================================================================
    #   merge old and new port
    #==============================================================================
    
    df = pd.merge(new_port, old_port, on=['Ticker'], how='outer')
    df = df.fillna(0)
    
    # =============================================================================
    #   merge with universe
    # =========================
====================================================
    
    df = pd.merge(df,universe, on=['Ticker'], how='inner')
    df = df.fillna(0)
    
    # =============================================================================
    #   turn on/off etb_avail_universe and/or etb_avail_amount
    # =============================================================================
    
    if (use_etb_amount == True):
        df['Avail_Dollar_ABC'] = df['Avail_Amount_ABC'] * df['Price'] * borrow_cap
    if (use_etb_universe == True) & (use_etb_amount == False):
        condition = df['Avail_Amount_ABC'] > 0
        df.loc[condition,'Avail_Amount_ABC'] = 1e9 # set an abitrary big number
        df['Avail_Dollar_ABC'] = df['Avail_Amount_ABC'] * df['Price']
    if (use_etb_universe == False) & (use_etb_amount == False):
        df['Avail_Dollar_ABC'] = 1e9 * df['Price'] # set an abitrary big number
    
    #==============================================================================
    #   calculate max and min positions: dmax and dmin
    #==============================================================================
    
    df = df.sort_values('Ticker')
    df = df.reset_index(drop=True)
    df['g'] = df['opt_shr_old'] * df['Price']
    df['clip'] = df['avgPVadj'].apply(lambda r: min([r*0.01,1e6]))
    df['poscap1_ub'] = df['clip']
    df['poscap1_lb'] = - df['clip']
    df['poscap2_lb'] = df['g'].apply(lambda r: min([0,r])) - df['Avail_Dollar_ABC']
    df['dmax'] = df['clip']
    df['dmin'] = df[['poscap1_lb','poscap2_lb']].max(axis = 1)
    dmin = np.array(df['dmin'])
    dmax = np.array(df['dmax'])

    #==============================================================================
    #  calcualte weighting matrix: GT
    #==============================================================================
    
    df['wts'] = df.apply(lambda r: 1.0/r['clip'],axis=1)
    wts = np.array(df['wts']) 
    GT = np.diag(np.sqrt(wts))
    m = len(GT)
    
    # =============================================================================
    #  Exposure caps
    # =============================================================================
    
    Rskexps_cap = np.array(list(rskexpscaps.values()))
    Rskexps = df[list(rskexpscaps.keys())].values.transpose()
    Secexps_cap = np.array(list(secexpscaps.values()))
    Secexps = df[list(secexpscaps.keys())].values.transpose()
    Indexps_cap = np.array(list(indexpscaps.values()))
    Indexps = df[list(indexpscaps.keys())
].values.transpose()
    rske = len(Rskexps)
    sece = len(Secexps)
    inde = len(Indexps)
    
    # =============================================================================
    #   alphas
    # =============================================================================

    mu = np.array(df['alpha']) 
    n = len(mu) 

    #==============================================================================
    #   mosek optimization
    #==============================================================================
   
    with mosek.Env() as env:
        with env.Task(0, 0) as task:

            #==============================================================================
            #==============================================================================
            # # Constrains             
            #==============================================================================
            #==============================================================================

            #==============================================================================
            #  Set Constrain Numbers
            #==============================================================================

            task.appendcons(1 + n + sece + inde + rske + m)

            #==============================================================================
            # 1. |sum(x)| = dn
            #==============================================================================

            task.putconbound(0, mosek.boundkey.fx, dn, dn)
            task.putconname(0, 'dollar neutral')

            #==============================================================================
            # 2. dmin <= x <= dmax
            #==============================================================================

            task.putconboundlist(range(1, 1 + n), [mosek.boundkey.ra] * n, dmin, dmax)
            for j in range(1, 1 + n):
                task.putconname(j, "x[%d]" % j)

            #==============================================================================
            # 3. Sec exps caps            
            #==============================================================================

            task.putconboundlist(range(1 + n, 1 + n + sece), [mosek.boundkey.ra] * sece, -Secexps_cap, Secexps_cap)
            for j in range(1 + n, 1 + n + sece):
                task.putconname(j, "Secexps[%d]" % j)

            #==============================
================================================
            # 4. Ind exps caps            
            #==============================================================================

            task.putconboundlist(range(1 + n + sece, 1 + n + sece + inde), [mosek.boundkey.ra] * inde, -Indexps_cap, Indexps_cap)
            for j in range(1 + n + sece, 1 + n + sece + inde):
                task.putconname(j, "Indexps[%d]" % j)

            #==============================================================================
            # 5. Rsk exps caps
            #==============================================================================

            task.putconboundlist(range(1 + n + sece + inde, 1 + n + sece + inde + rske), [mosek.boundkey.ra] * rske, -Rskexps_cap, Rskexps_cap)
            for j in range(1 + n + sece + inde, 1 + n + sece + inde + rske):
                task.putconname(j, "Rskexps[%d]" % j)

            #==============================================================================
            # 6. GTx - t = 0
            #==============================================================================

            task.putconboundlist(range(1 + n + sece + inde + rske, 1 + n + sece + inde + rske + m), [mosek.boundkey.fx] * m, [0.0] * m, [0.0] * m)
            for j in range(1 + n + sece + inde + rske, 1 + n + sece + inde + rske + m):
                task.putconname(j, "GT[%d]" % j)
 
            #==============================================================================
            #   Variables
            #==============================================================================
            #==============================================================================

            #==============================================================================
            # Set Variable Numbers
            #==============================================================================
            
            task.appendvars(n + 1 + m + 1)

            #==============================================================================
            # Set Variable offsets
            #==============================================================================

            offsetx = 0
            offsets = n
            offsett = n + 1
            offsetu = n + 1 + m
            
            #==============================================================================
            # Set Variable boundaries
            #============
==================================================================

            task.putvarboundslice(offsetx, offsetx + n, [mosek.boundkey.fr] * n, [-np.inf] * n, [np.inf] * n)
            for j in range(0, n):
                task.putvarname(offsetx + j, "x[%d]" % (1 + j))
                
            task.putvarbound(offsets + 0, mosek.boundkey.fr, -np.inf, np.inf)
            task.putvarname(offsets + 0, "s")

            task.putvarboundslice(offsett + 0, offsett + m, [mosek.boundkey.fr] * m, [-np.inf] * m, [np.inf] * m)
            for j in range(0, m):
                task.putvarname(offsett + j, "t[%d]" % (1 + j))

            task.putvarbound(offsetu + 0, mosek.boundkey.fx, 0.5, 0.5)
            task.putvarname(offsetu + 0, "u")
                
            #==============================================================================
            #==============================================================================
            #   Matrix A
            #==============================================================================
            #==============================================================================

            #==============================================================================
            # 1. sum(x) 
            #==============================================================================

            task.putaijlist([0] * n, range(offsetx + 0, offsetx + n), [1.0] * n)
            
            #==============================================================================
            # 2. dmin <= x <= dmax
            #==============================================================================

            task.putaijlist(range(1, 1 + n), range(offsetx + 0, offsetx + n), [1.0] * n)

            #==============================================================================
            # 3. Secexp * x
            #==============================================================================

            for j in range(0, sece):
                task.putaijlist([1 + n + j] * n, range(offsetx + 0, offsetx + n), list(Secexps[j]))
            
            #==============================================================================
            # 4. Indexp * x
            #==============================================================================

            for j in range(0, inde):
                task.putaijlist([1 + n + sece + j] * n, range(offsetx + 0, offsetx + n), list(Indexps[j]))

      
      #==============================================================================
            # 5. Rskexps * x
            #==============================================================================

            for j in range(0, rske):
                task.putaijlist([1 + n + sece + inde + j] * n, range(offsetx + 0, offsetx + n), list(Rskexps[j]))

            #==============================================================================
            # 6. GT * x - t
            #==============================================================================

            for j in range(0, m):
                task.putaijlist([1 + n + sece + inde + rske + j] * n, range(offsetx + 0, offsetx + n), list(GT[j]))

            task.putaijlist(range(1 + n + sece + inde + rske, 1 + n + sece + inde + rske + m), range(offsett + 0, offsett + m), [-1.0] * m)

            #==============================================================================
            #   Array C
            #==============================================================================
            #==============================================================================

            task.putclist(range(offsetx, offsetx + n), mu)
            task.putcj(offsets + 0, -lam)

            #==============================================================================
            #==============================================================================
            #   Cones
            #==============================================================================
            #==============================================================================

            task.appendcone(mosek.conetype.rquad, 0.0, [offsets, offsetu] + list(range(offsett, offsett + m)))
            task.putconename(0, "risk")

            task.putobjsense(mosek.objsense.maximize)
            task.optimize()

            xx = [0.] * n
            task.getxxslice(mosek.soltype.itr, offsetx + 0, offsetx + n, xx)
            
            
    xx = pd.DataFrame(xx) 
    xx.columns = ['opt_dollar']

    df = pd.concat([df,xx],axis = 1)
    df = df[['Ticker','opt_dollar']]
    #df = df[['Ticker','opt_dollar','opt_shr_old','spread','volatility','avgPVadj','Price']]
   
    return(df)    








def mosekoptcn_single_alpha_v2(new_port, old_port, universe, rskexpscaps, secexpscaps, indexpscaps, dn = 10e9, lam = 3, borrow_cap = 0.3, use_etb_universe=True, use_etb_amount=True):
    
    # in github, the comment is
 version of no dollar neutral
        
    # =============================================================================
    # new_port takes T's portfolio of columns: Ticker, alpha
    # old_port takes T-1d's portfolio of columns: Ticker, opt_shr_old (T-1d's shares)
    # universe is the T-1d universe which has columns: Ticker, Price (T-1d's price), avgPVadj, Avail_Amount_ABC (T's total available shortable amounts in shares)
    # gmv in dollars: e.g. 50e6,
    # lam is the coefficient before risk that needs to be tuned for optimized portfolio,
    # rskexpscaps/secexpscaps/indexpscaps are dictionaries.
    # sample for indexpscaps/secexpscaps/rskexpscaps:
    
    #indnames = [ 'AIRLINES','AUTOCOMP','BANKS','BIOTECH','CAPGOODS','CHEMICAL','COMMSVCS','COMMUNIC','COMPUTER','CONSDUR','CONSTPP',
    #             'CONSVCS','DIVFINAN','DIVMETAL','ENERGY','FOODPRD','FOODRETL','HEALTH','HSHLDPRD','INSURAN','INTERNET','MEDIA','OILEXPL',
    #             'OILGAS','PHARMAC','PRECMETL','REALEST','RETAIL','SEMICOND','SOFTWARE','STEEL','TELECOM','TRANSPRT','UTILITY']
    #indexpscaps = dict([ (x, 0.02) for x in indnames ])
    
    #secnames = ['W_SECTOR_10','W_SECTOR_15','W_SECTOR_20','W_SECTOR_25','W_SECTOR_30','W_SECTOR_35','W_SECTOR_40','W_SECTOR_45','W_SECTOR_50','W_SECTOR_55','W_SECTOR_60']
    #secexpscaps = dict([ (x, 0.02) for x in secnames ]) 
    
    #rsknames = ['BETA','MOMENTUM','SIZE','EARNYILD','RESVOL','GROWTH','DIVYILD','BTOP','LEVERAGE','LIQUIDTY','SIZENL']
    #rskexpscaps = dict([ (x, 0.02) for x in rsknames ])
    # =============================================================================
        

    #==============================================================================
    #   merge old and new port
    #==============================================================================
    
    df = pd.merge(new_port, old_port, on=['Ticker'], how='outer')
    df = df.fillna(0)
    
    # =============================================================================
    #   merge with universe
    # =============================================================================
    
    df = pd.merge(df,universe, on=['Ticker'], how='inner')
    df = df.fillna(0)
    
    # =============================================================================
    #   turn on/off etb_avail_universe and/or etb_avail_amount
    # =============================================================================
    
    if (use_etb_amount == True):
   
     df['Avail_Dollar_ABC'] = df['Avail_Amount_ABC'] * df['Price'] * borrow_cap
    if (use_etb_universe == True) & (use_etb_amount == False):
        condition = df['Avail_Amount_ABC'] > 0
        df.loc[condition,'Avail_Amount_ABC'] = 1e9 # set an abitrary big number
        df['Avail_Dollar_ABC'] = df['Avail_Amount_ABC'] * df['Price']
    if (use_etb_universe == False) & (use_etb_amount == False):
        df['Avail_Dollar_ABC'] = 1e9 * df['Price'] # set an abitrary big number
    
    #==============================================================================
    #   calculate max and min positions: dmax and dmin
    #==============================================================================
    
    df = df.sort_values('Ticker')
    df = df.reset_index(drop=True)
    df['g'] = df['opt_shr_old'] * df['Price']
    df['clip'] = df['avgPVadj'].apply(lambda r: min([r*0.01,1e6]))
    df['poscap1_ub'] = df['clip']
    df['poscap1_lb'] = - df['clip']
    df['poscap2_lb'] = df['g'].apply(lambda r: min([0,r])) - df['Avail_Dollar_ABC']
    df['dmax'] = df['clip']
    df['dmin'] = df[['poscap1_lb','poscap2_lb']].max(axis = 1)
    dmin = np.array(df['dmin'])
    dmax = np.array(df['dmax'])

    #==============================================================================
    #  calcualte weighting matrix: GT
    #==============================================================================
    
    df['wts'] = df.apply(lambda r: 1.0/r['clip'],axis=1)
    wts = np.array(df['wts']) 
    GT = np.diag(np.sqrt(wts))
    m = len(GT)
    
    # =============================================================================
    #  Exposure caps
    # =============================================================================
    
    Rskexps_cap = np.array(list(rskexpscaps.values()))
    Rskexps = df[list(rskexpscaps.keys())].values.transpose()
    Secexps_cap = np.array(list(secexpscaps.values()))
    Secexps = df[list(secexpscaps.keys())].values.transpose()
    Indexps_cap = np.array(list(indexpscaps.values()))
    Indexps = df[list(indexpscaps.keys())].values.transpose()
    rske = len(Rskexps)
    sece = len(Secexps)
    inde = len(Indexps)
    
    # =============================================================================
    #   alphas
    # =============================================================================

    mu = np.array(df['alpha']) 
    n = len(mu) 

    #==============================================================================

    #   mosek optimization
    #==============================================================================
   
    with mosek.Env() as env:
        with env.Task(0, 0) as task:

            #==============================================================================
            #==============================================================================
            # # Constrains             
            #==============================================================================
            #==============================================================================

            #==============================================================================
            #  Set Constrain Numbers
            #==============================================================================

            task.appendcons(1 + n + sece + inde + rske + m)

            #==============================================================================
            # 1. |sum(x)| <= dn
            #==============================================================================

            task.putconbound(0, mosek.boundkey.ra, -dn, dn)
            task.putconname(0, 'dollar neutral')

            #==============================================================================
            # 2. dmin <= x <= dmax
            #==============================================================================

            task.putconboundlist(range(1, 1 + n), [mosek.boundkey.ra] * n, dmin, dmax)
            for j in range(1, 1 + n):
                task.putconname(j, "x[%d]" % j)

            #==============================================================================
            # 3. Sec exps caps            
            #==============================================================================

            task.putconboundlist(range(1 + n, 1 + n + sece), [mosek.boundkey.ra] * sece, -Secexps_cap, Secexps_cap)
            for j in range(1 + n, 1 + n + sece):
                task.putconname(j, "Secexps[%d]" % j)

            #==============================================================================
            # 4. Ind exps caps            
            #==============================================================================

            task.putconboundlist(range(1 + n + sece, 1 + n + sece + inde), [mosek.boundkey.ra] * inde, -Indexps_cap, Indexps_cap)
            for j in range(1 + n + sece, 1 + n + sece + inde):
                task.putconname(j, "
Indexps[%d]" % j)

            #==============================================================================
            # 5. Rsk exps caps
            #==============================================================================

            task.putconboundlist(range(1 + n + sece + inde, 1 + n + sece + inde + rske), [mosek.boundkey.ra] * rske, -Rskexps_cap, Rskexps_cap)
            for j in range(1 + n + sece + inde, 1 + n + sece + inde + rske):
                task.putconname(j, "Rskexps[%d]" % j)

            #==============================================================================
            # 6. GTx - t = 0
            #==============================================================================

            task.putconboundlist(range(1 + n + sece + inde + rske, 1 + n + sece + inde + rske + m), [mosek.boundkey.fx] * m, [0.0] * m, [0.0] * m)
            for j in range(1 + n + sece + inde + rske, 1 + n + sece + inde + rske + m):
                task.putconname(j, "GT[%d]" % j)
 
            #==============================================================================
            #   Variables
            #==============================================================================
            #==============================================================================

            #==============================================================================
            # Set Variable Numbers
            #==============================================================================
            
            task.appendvars(n + 1 + m + 1)

            #==============================================================================
            # Set Variable offsets
            #==============================================================================

            offsetx = 0
            offsets = n
            offsett = n + 1
            offsetu = n + 1 + m
            
            #==============================================================================
            # Set Variable boundaries
            #==============================================================================

            task.putvarboundslice(offsetx, offsetx + n, [mosek.boundkey.fr] * n, [-np.inf] * n, [np.inf] * n)
            for j in range(0, n):
                task.putvarname(offsetx + j, "x[%d]" % (1 + j))
                
            task.putvarbound(offsets + 0, mosek.boundkey.fr, -np.inf, np.inf)
            task.putvarname(offsets + 0, "s
")

            task.putvarboundslice(offsett + 0, offsett + m, [mosek.boundkey.fr] * m, [-np.inf] * m, [np.inf] * m)
            for j in range(0, m):
                task.putvarname(offsett + j, "t[%d]" % (1 + j))

            task.putvarbound(offsetu + 0, mosek.boundkey.fx, 0.5, 0.5)
            task.putvarname(offsetu + 0, "u")
                
            #==============================================================================
            #==============================================================================
            #   Matrix A
            #==============================================================================
            #==============================================================================

            #==============================================================================
            # 1. sum(x) 
            #==============================================================================

            task.putaijlist([0] * n, range(offsetx + 0, offsetx + n), [1.0] * n)
            
            #==============================================================================
            # 2. dmin <= x <= dmax
            #==============================================================================

            task.putaijlist(range(1, 1 + n), range(offsetx + 0, offsetx + n), [1.0] * n)

            #==============================================================================
            # 3. Secexp * x
            #==============================================================================

            for j in range(0, sece):
                task.putaijlist([1 + n + j] * n, range(offsetx + 0, offsetx + n), list(Secexps[j]))
            
            #==============================================================================
            # 4. Indexp * x
            #==============================================================================

            for j in range(0, inde):
                task.putaijlist([1 + n + sece + j] * n, range(offsetx + 0, offsetx + n), list(Indexps[j]))

            #==============================================================================
            # 5. Rskexps * x
            #==============================================================================

            for j in range(0, rske):
                task.putaijlist([1 + n + sece + inde + j] * n, range(offsetx + 0, offsetx + n), list(Rskexps[j]))

            #=========================================
=====================================
            # 6. GT * x - t
            #==============================================================================

            for j in range(0, m):
                task.putaijlist([1 + n + sece + inde + rske + j] * n, range(offsetx + 0, offsetx + n), list(GT[j]))

            task.putaijlist(range(1 + n + sece + inde + rske, 1 + n + sece + inde + rske + m), range(offsett + 0, offsett + m), [-1.0] * m)

            #==============================================================================
            #   Array C
            #==============================================================================
            #==============================================================================

            task.putclist(range(offsetx, offsetx + n), mu)
            task.putcj(offsets + 0, -lam)

            #==============================================================================
            #==============================================================================
            #   Cones
            #==============================================================================
            #==============================================================================

            task.appendcone(mosek.conetype.rquad, 0.0, [offsets, offsetu] + list(range(offsett, offsett + m)))
            task.putconename(0, "risk")

            task.putobjsense(mosek.objsense.maximize)
            task.optimize()

            xx = [0.] * n
            task.getxxslice(mosek.soltype.itr, offsetx + 0, offsetx + n, xx)
            
            
    xx = pd.DataFrame(xx) 
    xx.columns = ['opt_dollar']

    df = pd.concat([df,xx],axis = 1)
    df = df[['Ticker','opt_dollar']]
    #df = df[['Ticker','opt_dollar','opt_shr_old','spread','volatility','avgPVadj','Price']]
   
    return(df)    




def explore_us_descriptor(com, desc):
    
    # this inputs a sd-data-merged df and the column name of a descriptor
    # input df: 
    # output: it plots bar charts of all 
    
    tk = 'Ticker'
    dt = 'DataDate'
    delta = datetime.timedelta
    
    com = com.sort_values([tk, dt]).reset_index(drop = True)
    com['ones'] = 1
    cols_f = ['DREVRSL', 'BETA', 'DIVYILD', 'DWNRISK', 'EARNQLTY', 'EARNYILD', 
              'GROWTH', 'INDMOM', 'LEVERAGE', 'LIQUIDTY', 'LTREVRSL', 'MGMTQLTY', 
              'MIDCAP', 'MOMENTUM', 'PROFIT', 'PROSPECT', 'REGMOM', 'RESVOL', 
              'SEASON', 'SENTMT', 'SHORTINT', 'STREVRSL', '
SIZE', 'VALUE']
    cols_i = com['GSECTOR'].unique().tolist()
    com = com.drop(columns = [c for c in cols_i if c in com.columns.tolist()])
    com = pd.concat([com, pd.get_dummies(com['GSECTOR'])], axis = 1)
       
    
    com[desc+'_bk'] = com.groupby(dt)[desc].apply(lambda x: pdqcut(x,bins=5)).values
    com[desc+'_orth'] = com.groupby(dt)[[desc,'ones']+cols_i+cols_f].apply(lambda x: orthogonalize_us(x[desc], x[cols_f], x[cols_i], x['ones'])).values
    com[desc+'_orth_bk'] = com.groupby(dt)[desc+'_orth'].apply(lambda x: pdqcut(x,bins=5)).values
    create_us_3x3_linux(com[com[desc+'_bk'].notnull()], [desc+'_bk'], desc)
    if com[desc+'_orth_bk'].notnull().sum() < 1000:
        print('insufficient sample: '+desc+'_orth_bk')
    else:
        create_us_3x3_linux(com[com[desc+'_orth_bk'].notnull()], [desc+'_orth_bk'], desc+'_orth')
    
    com[desc+'_t5d'] = com.groupby(tk).rolling(delta(days=7),on=dt,min_periods=3)[desc].mean().values
    com[desc+'_t20d'] = com.groupby(tk).rolling(delta(days=28),on=dt,min_periods=10)[desc].mean().values
    com[desc+'_t63d'] = com.groupby(tk).rolling(delta(days=91),on=dt,min_periods=30)[desc].mean().values
    com[desc+'_t5d_bk'] = com.groupby(dt)[desc+'_t5d'].apply(lambda x: pdqcut(x,bins=5)).values    
    com[desc+'_t20d_bk'] = com.groupby(dt)[desc+'_t20d'].apply(lambda x: pdqcut(x,bins=5)).values
    com[desc+'_t63d_bk'] = com.groupby(dt)[desc+'_t63d'].apply(lambda x: pdqcut(x,bins=5)).values
    create_us_3x3_linux(com[com[desc+'_t5d_bk'].notnull()], [desc+'_t5d_bk'], desc+'_t5d')
    create_us_3x3_linux(com[com[desc+'_t20d_bk'].notnull()], [desc+'_t20d_bk'], desc+'_t20d')
    create_us_3x3_linux(com[com[desc+'_t63d_bk'].notnull()], [desc+'_t63d_bk'], desc+'_t63d')
    
    com[desc+'_t5d_orth'] = com.groupby(dt)[[desc+'_t5d','ones']+cols_i+cols_f].apply(lambda x: orthogonalize_us(x[desc+'_t5d'], x[cols_f], x[cols_i], x['ones'])).values
    com[desc+'_t5d_orth_bk'] = com.groupby(dt)[desc+'_t5d_orth'].apply(lambda x: pdqcut(x,bins=5)).values    
    com[desc+'_t20d_orth'] = com.groupby(dt)[[desc+'_t20d','ones']+cols_i+cols_f].apply(lambda x: orthogonalize_us(x[desc+'_t20d'], x[cols_f], x[cols_i], x['ones'])).values
    com[desc+'_t20d_orth_bk'] = com.groupby(dt)[desc+'_t20d_orth'].apply(lambda x: pdqcut(x,bins=5)).values
    com[desc+'_t63d_orth'] = com.groupby(dt)[[desc+'_t63d','ones']+cols_i+cols_f].apply(lambda x: orthogonalize_us(x[desc+'_t63d'], x[cols_f], x[cols_i], x['ones'])).values
    com[desc+'_t63d_
orth_bk'] = com.groupby(dt)[desc+'_t63d_orth'].apply(lambda x: pdqcut(x,bins=5)).values
    if com[desc+'_t5d_orth_bk'].notnull().sum() < 1000:
        print('insufficient sample: '+desc+'_t5d_orth_bk')
    else:
        create_us_3x3_linux(com[com[desc+'_t5d_orth_bk'].notnull()], [desc+'_t5d_orth_bk'], desc+'_t5d_orth')    
    if com[desc+'_t20d_orth_bk'].notnull().sum() < 1000:
        print('insufficient sample: '+desc+'_t20d_orth_bk')
    else:
        create_us_3x3_linux(com[com[desc+'_t20d_orth_bk'].notnull()], [desc+'_t20d_orth_bk'], desc+'_t20d_orth')
    if com[desc+'_t63d_orth_bk'].notnull().sum() < 1000:
        print('insufficient sample: '+desc+'_t63d_orth_bk')
    else:
        create_us_3x3_linux(com[com[desc+'_t63d_orth_bk'].notnull()], [desc+'_t63d_orth_bk'], desc+'_t63d_orth')
    
    com[desc+'_df'] = com[desc] - com.groupby(tk)[desc].shift()
    com[desc+'_df_t20d'] = com.groupby(tk).rolling(delta(days=28),on=dt,min_periods=10)[desc+'_df'].mean().values
    com[desc+'_df_orth'] = com.groupby(dt)[[desc+'_df','ones']+cols_i+cols_f].apply(lambda x: orthogonalize_us(x[desc+'_df'], x[cols_f], x[cols_i], x['ones'])).values
    com[desc+'_df_t20d_orth'] = com.groupby(dt)[[desc+'_df_t20d','ones']+cols_i+cols_f].apply(lambda x: orthogonalize_us(x[desc+'_df_t20d'], x[cols_f], x[cols_i], x['ones'])).values
    com[desc+'_df_bk'] = com.groupby(dt)[desc+'_df'].apply(lambda x: pdqcut(x,bins=5)).values
    com[desc+'_df_t20d_bk'] = com.groupby(dt)[desc+'_df_t20d'].apply(lambda x: pdqcut(x,bins=5)).values
    com[desc+'_df_orth_bk'] = com.groupby(dt)[desc+'_df_orth'].apply(lambda x: pdqcut(x,bins=5)).values
    com[desc+'_df_t20d_orth_bk'] = com.groupby(dt)[desc+'_df_t20d_orth'].apply(lambda x: pdqcut(x,bins=5)).values
    if com[desc+'_df_bk'].notnull().sum() < 1000:
        print('insufficient sample: '+desc+'_df_bk')
    else:
        create_us_3x3_linux(com[com[desc+'_df_bk'].notnull()], [desc+'_df_bk'], desc)
    if com[desc+'_df_t20d_bk'].notnull().sum() < 1000:
        print('insufficient sample: '+desc+'_df_t20d_bk')
    else:
        create_us_3x3_linux(com[com[desc+'_df_t20d_bk'].notnull()], [desc+'_df_t20d_bk'], desc+'_df_t20d')
    if com[desc+'_df_orth_bk'].notnull().sum() < 1000:
        print('insufficient sample: '+desc+'_df_orth_bk')
    else:
        create_us_3x3_linux(com[com[desc+'_df_orth_bk'].notnull()], [desc+'_df_orth_bk'], desc+'_df_orth')
    if com[desc+'_df_t20d_orth_bk'].notnull().sum() < 1000:
        print('insufficien
t sample: '+desc+'_df_t20d_orth_bk')
    else:
        create_us_3x3_linux(com[com[desc+'_df_t20d_orth_bk'].notnull()], [desc+'_df_t20d_orth_bk'], desc+'_df_t20d_orth')
    
    









### Static Data 



def prepare_sd_cn_50():
    
    
    
    
    # get universe 
    
    i_uni_50 = get_sql('''select datadate as [T-1d], database_symbol as Ticker,
                       CSRC_Industry_Description as indstr
                         from CNDBPROD.dbo.CSI_ALL_CONS
                         where index_code = '000016' ''')
    i_uni_50['Ticker'] = i_uni_50['Ticker'].str.replace('C','')
    i_uni_50 = i_uni_50.drop_duplicates(subset=['Ticker','T-1d'],keep='last')
    i_uni_50['indstr'] = i_uni_50['indstr'].fillna('')
    i_uni_50.loc[i_uni_50['indstr'].str.contains('Finance'), 'ind_fin'] = 1
    i_uni_50.loc[~i_uni_50['indstr'].str.contains('Finance'), 'ind_fin'] = 0
    i_uni_50 = i_uni_50[['T-1d', 'Ticker', 'ind_fin']]
    
     
    # get calendar
    
    i_cal = get_sql('''select distinct tradedate_next as DataDate from cndbprod.dbo.calendar_dates_cn
                    order by tradedate_next''')
    i_cal['T-1d'] = i_cal['DataDate'].shift()
    i_cal['T-2d'] = i_cal['DataDate'].shift(2)
    i_cal['DataDate_p1d'] = i_cal['DataDate'].shift(-1)
    i_cal = i_cal.dropna()
    
    
    # get barra 
    # tk mapping assume datadate = T-0d here ,just to be conservative
    
    i_tk_map = get_sql('''select sedol, ric, DataDate
                       from cndbprod.dbo.IMPACT_CN_MAPPING
                       order by datadate ''')
    i_tk_map = i_tk_map[['sedol','ric','DataDate']]
    
    i_barra = get_sql('''select datadate as [T-2d], sedol, name, 
                      [srisk%] as SRISK, BETA, MOMENTUM, SIZE, EARNYILD, RESVOL, 
                      GROWTH, DIVYILD, BTOP, LEVERAGE, SIZENL, LIQUIDTY  
                      from CNDBPROD.dbo.BARRA_GEM3L_CN_RSK 
                      where DataDate >= '20150101'
                      order by datadate
                      ''')
    i_barra_s2 = i_barra.merge(i_cal[['T-2d','DataDate']],on=['T-2d'],how='left')
    i_barra_s2 = i_barra_s2.dropna(subset = ['DataDate'])
    i_barra_s2 = i_barra_s2.sort_values('DataDate')
    i_barra_s2 = pd.merge_asof(i_barra_s2, i_tk_map, on = 'DataDate', by ='sedol')
    i_barra_s2['Ticker'] = i_barra_s2['ric'].str.split('.').str[0]
    i_barra_s2 = i_barra_s2.dropna(subset = ['Ticker'])
    i_barra_s2 = i_barra_s2.drop_duplicates(subset = ['Ticker', 'DataDate'], keep = 'las
t')
    i_barra_s2 = i_barra_s2[['DataDate','Ticker', 
                             'SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 
                             'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']]
    
    i_barra = None
    cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 
              'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
   
    
    
    # get spread
    
    i_spread = get_sql('''select Ticker, DataDate as [T-1d], spread 
                       from cndbprod.dbo.trth_spread_cn
                       order by DataDate''')
    i_spread['Ticker'] = i_spread['Ticker'].str.split('.').str[0]
    i_spread = i_spread.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_spread = i_spread[['Ticker', 'T-1d', 'spread']]
        
    # volatility
    
    i_volatility = get_sql('''select datadate as [T-1d], Ticker, gk_vol_63d as volatility
                           from cndbprod.dbo.wind_gkvol_cn                       
                           order by datadate
                           ''')
    i_volatility = i_volatility.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_volatility = i_volatility[['Ticker', 'T-1d', 'volatility']]
    
    # avgVadj, avgPVadj, avgPVadj_USD, 
    
    i_adv = get_sql('''select datadate as [T-1d], Ticker, avgPVadj, avgPVadj_USD
                    from [CNDBPROD].[dbo].trth_adv_cn
                    order by datadate''')
    i_adv['Ticker'] = i_adv['Ticker'].str.split('.').str[0]
    i_adv = i_adv.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_adv = i_adv[['Ticker', 'T-1d', 'avgPVadj', 'avgPVadj_USD']]
    
    # raw return 
    
    i_ret = get_sql_wind('''select trade_dt as [T-1d], s_info_windcode as Ticker,
                         s_dq_adjclose / s_dq_adjpreclose - 1 as [RawRet-1d]
                         from wind_prod.dbo.ashareeodprices 
                         where trade_dt>='20150101' ''')
    i_ret['Ticker'] = i_ret['Ticker'].str.split('.').str[0]
    i_ret['T-1d'] = pd.to_datetime(i_ret['T-1d'], format = '%Y%m%d')    
    i_ret['RawRet-1d'] = i_ret['RawRet-1d'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
    i_ret = i_ret.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_ret = i_ret[['Ticker', 'T-1d', 'RawRet-1d']]
    
    # SO_l1d, FLOAT_1d ???
    
    
    # combine 
    
    icom = i_uni_50.merge(i_cal, on = ['T-1d'], how = 'left')
    icom = icom.dropna(subset=['DataDate']
)
    
    icom = icom.merge(i_ret, on = ['Ticker', 'T-1d'], how = 'left')
    
    icom = icom.sort_values('DataDate')
    icom = pd.merge_asof(icom, i_barra_s2, on = ['DataDate'], by =['Ticker'])
    icom = icom.sort_values('T-1d')    
    icom = pd.merge_asof(icom, i_spread, on = ['T-1d'], by =['Ticker'])
    icom = pd.merge_asof(icom, i_volatility, on = ['T-1d'], by =['Ticker'])
    icom = pd.merge_asof(icom, i_adv, on = ['T-1d'], by =['Ticker'])
    
    icom = icom.sort_values(['Ticker', 'DataDate'])
        
    # calculate residual return
    
    icom['clip'] = icom['avgPVadj_USD'].apply(lambda x: min(x*0.01, 1e6))
    icom['BarrRet_CLIP_USD-1d'] = icom.groupby('T-1d')[cols_f + ['RawRet-1d', 'clip', 'ind_fin']].apply(lambda x: orthogonalize_cn_v3(x['RawRet-1d'], x[cols_f], x[['ind_fin']], x['clip'])).values
    
    # calculate past and future return
    
    icom = icom.merge(icom[['T-1d', 'Ticker','BarrRet_CLIP_USD-1d']].rename(columns={'T-1d':'DataDate'}),
                      on = ['DataDate', 'Ticker'], how = 'left', suffixes = ['', '_merge'])
    icom = icom.rename(columns = {'BarrRet_CLIP_USD-1d_merge':'BarrRet_CLIP_USD+0d'})
    icom = icom.merge(icom[['T-1d', 'Ticker','BarrRet_CLIP_USD-1d']].rename(columns={'T-1d':'DataDate_p1d'}),
                      on = ['DataDate_p1d', 'Ticker'], how = 'left', suffixes = ['', '_merge'])
    icom = icom.rename(columns = {'BarrRet_CLIP_USD-1d_merge':'BarrRet_CLIP_USD+1d'})
    
    # output 
    
    c_sh = icom['Ticker'].str[0].isin(['6'])
    c_sz = icom['Ticker'].str[0].isin(['0', '3'])
    icom.loc[c_sh, 'ticker'] = icom.loc[c_sh, 'Ticker'] + '.SH'
    icom.loc[c_sz, 'ticker'] = icom.loc[c_sz, 'Ticker'] + '.SZ'    
    
    icom.to_parquet('/dat/summit_capital/TZ/China Data Hunt/cache/util_prepare_sd_cn_50.parquet')
    
    
    
def get_sd_cn_50():
    
    return pd.read_parquet('/dat/summit_capital/TZ/China Data Hunt/cache/util_prepare_sd_cn_50.parquet')




def prepare_sd_cn_500():
    
    
    
    
    # get universe 
    
    i_uni_500 = get_sql('''select datadate as [T-1d], database_symbol as Ticker,
                       CSRC_Industry_Description as indstr
                         from CNDBPROD.dbo.CSI_ALL_CONS
                         where index_code = '000905' ''')
    i_uni_500['Ticker'] = i_uni_500['Ticker'].str.replace('C','')
    i_uni_500 = i_uni_500.drop_duplicates(subset=['Ticker','T-1d'],keep='last')
    i_uni_500['indstr'] = i_uni_500['indstr'].fillna('')
    i_uni_500.loc
[i_uni_500['indstr'].str.contains('Finance'), 'ind_fin'] = 1
    i_uni_500.loc[~i_uni_500['indstr'].str.contains('Finance'), 'ind_fin'] = 0
    i_uni_500 = i_uni_500[['T-1d', 'Ticker', 'ind_fin']]
    
     
    # get calendar
    
    i_cal = get_sql('''select distinct tradedate_next as DataDate from cndbprod.dbo.calendar_dates_cn
                    order by tradedate_next''')
    i_cal['T-1d'] = i_cal['DataDate'].shift()
    i_cal['T-2d'] = i_cal['DataDate'].shift(2)
    i_cal['DataDate_p1d'] = i_cal['DataDate'].shift(-1)
    i_cal = i_cal.dropna()
    
    
    # get barra 
    # tk mapping assume datadate = T-0d here ,just to be conservative
    
    i_tk_map = get_sql('''select sedol, ric, DataDate
                       from cndbprod.dbo.IMPACT_CN_MAPPING
                       order by datadate ''')
    i_tk_map = i_tk_map[['sedol','ric','DataDate']]
    
    i_barra = get_sql('''select datadate as [T-2d], sedol, name, 
                      [srisk%] as SRISK, BETA, MOMENTUM, SIZE, EARNYILD, RESVOL, 
                      GROWTH, DIVYILD, BTOP, LEVERAGE, SIZENL, LIQUIDTY  
                      from CNDBPROD.dbo.BARRA_GEM3L_CN_RSK 
                      where DataDate >= '20150101'
                      order by datadate
                      ''')
    i_barra_s2 = i_barra.merge(i_cal[['T-2d','DataDate']],on=['T-2d'],how='left')
    i_barra_s2 = i_barra_s2.dropna(subset = ['DataDate'])
    i_barra_s2 = i_barra_s2.sort_values('DataDate')
    i_barra_s2 = pd.merge_asof(i_barra_s2, i_tk_map, on = 'DataDate', by ='sedol')
    i_barra_s2['Ticker'] = i_barra_s2['ric'].str.split('.').str[0]
    i_barra_s2 = i_barra_s2.dropna(subset = ['Ticker'])
    i_barra_s2 = i_barra_s2.drop_duplicates(subset = ['Ticker', 'DataDate'], keep = 'last')
    i_barra_s2 = i_barra_s2[['DataDate','Ticker', 
                             'SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 
                             'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']]
    
    i_barra = None
    cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 
              'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
   
    
    
    # get spread
    
    i_spread = get_sql('''select Ticker, DataDate as [T-1d], spread 
                       from cndbprod.dbo.trth_spread_cn
                       order by DataDate''')
    i_spread['Ticker'] = i_spread['Ticker'].str.split('.').str[0]
    i_spread = i_spread.drop_duplicates(subset=['Ticker', 'T-1d
'], keep = 'last')
    i_spread = i_spread[['Ticker', 'T-1d', 'spread']]
        
    # get volatility
    
    i_volatility = get_sql('''select datadate as [T-1d], Ticker, gk_vol_63d as volatility
                           from cndbprod.dbo.wind_gkvol_cn                       
                           order by datadate
                           ''')
    i_volatility = i_volatility.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_volatility = i_volatility[['Ticker', 'T-1d', 'volatility']]
    
    # get avgVadj, avgPVadj, avgPVadj_USD, 
    
    i_adv = get_sql('''select datadate as [T-1d], Ticker, avgPVadj, avgPVadj_USD
                    from [CNDBPROD].[dbo].trth_adv_cn
                    order by datadate''')
    i_adv['Ticker'] = i_adv['Ticker'].str.split('.').str[0]
    i_adv = i_adv.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_adv = i_adv[['Ticker', 'T-1d', 'avgPVadj', 'avgPVadj_USD']]
    
    # get CSI500 ret
        
    i_500ret = get_sql('''select DataDate as [T-1d], [Price_Return_-_One_Day_-_CNY] as ret500
                             FROM [CNDBPROD].[dbo].[CSI_ALL_PX]
                             where Database_Symbol = 'CSI500' order by DataDate desc 
                          ''')
                          
    
    # raw return 
    
    i_ret = get_sql_wind('''select trade_dt as [T-1d], s_info_windcode as Ticker,
                         s_dq_adjclose / s_dq_adjpreclose - 1 as [RawRet-1d]
                         from wind_prod.dbo.ashareeodprices 
                         where trade_dt>='20150101' ''')
    i_ret['Ticker'] = i_ret['Ticker'].str.split('.').str[0]
    i_ret['T-1d'] = pd.to_datetime(i_ret['T-1d'], format = '%Y%m%d')    
    i_ret['RawRet-1d'] = i_ret['RawRet-1d'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
    i_ret = i_ret.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_ret = i_ret[['Ticker', 'T-1d', 'RawRet-1d']]
    
    # SO_l1d, FLOAT_1d ???
    
    
    # combine 
    
    icom = i_uni_500.merge(i_cal, on = ['T-1d'], how = 'left')
    icom = icom.dropna(subset=['DataDate'])
    
    icom = icom.merge(i_ret, on = ['Ticker', 'T-1d'], how = 'left')
    
    icom = icom.sort_values('DataDate')
    icom = pd.merge_asof(icom, i_barra_s2, on = ['DataDate'], by =['Ticker'])
    icom = icom.sort_values('T-1d')    
    icom = pd.merge_asof(icom, i_spread, on = ['T-1d'], by =['Ticker'])
    icom = pd.merge_asof(icom, i_volatility, on = ['T-1d'], by =['Ticker'])
    ic
om = pd.merge_asof(icom, i_adv, on = ['T-1d'], by =['Ticker'])
    
    icom = icom.merge(i_500ret, on = ['T-1d'], how = 'left')
    
    icom = icom.sort_values(['Ticker', 'DataDate'])
        
    # calculate residual return
    
    icom['clip'] = icom['avgPVadj_USD'].apply(lambda x: min(x*0.01, 1e6))
    icom['BarrRet_CLIP_USD-1d'] = icom.groupby('T-1d')[cols_f + ['RawRet-1d', 'clip', 'ind_fin']].apply(lambda x: orthogonalize_cn_v3(x['RawRet-1d'], x[cols_f], x[['ind_fin']], x['clip'])).values
    
    # calculate hedged return
    
    icom['hret-1d'] = icom['RawRet-1d'] - icom['ret500']
    
    # calculate past and future return
    
    icom = icom.merge(icom[['T-1d','Ticker','BarrRet_CLIP_USD-1d','hret-1d']]\
                      .rename(columns={'T-1d':'DataDate'}),
                      on = ['DataDate', 'Ticker'], how = 'left', suffixes = ['', '_merge'])
    icom = icom.rename(columns = {'BarrRet_CLIP_USD-1d_merge':'BarrRet_CLIP_USD+0d',
                                  'hret-1d_merge':'hret+0d'})
    icom = icom.merge(icom[['T-1d', 'Ticker','BarrRet_CLIP_USD-1d','hret-1d']]\
                      .rename(columns={'T-1d':'DataDate_p1d'}),
                      on = ['DataDate_p1d', 'Ticker'], how = 'left', suffixes = ['', '_merge'])
    icom = icom.rename(columns = {'BarrRet_CLIP_USD-1d_merge':'BarrRet_CLIP_USD+1d',
                                  'hret-1d_merge':'hret+1d'})
    
    # output 
    
    c_sh = icom['Ticker'].str[0].isin(['6'])
    c_sz = icom['Ticker'].str[0].isin(['0', '3'])
    icom.loc[c_sh, 'ticker'] = icom.loc[c_sh, 'Ticker'] + '.SH'
    icom.loc[c_sz, 'ticker'] = icom.loc[c_sz, 'Ticker'] + '.SZ'    
    
    icom.to_parquet('/dat/summit_capital/TZ/China Data Hunt/cache/util_prepare_sd_cn_500.parquet')
    
    
    
def get_sd_cn_500():
    
    return pd.read_parquet('/dat/summit_capital/TZ/China Data Hunt/cache/util_prepare_sd_cn_500.parquet')






def prepare_sd_cn_1800():
    
    
    
    
    # get universe 
    
    i_uni_1800 = get_sql('''select datadate as [T-1d], Ticker, CSI_index
                         from cndbprod.dbo.universe_csi1800''')
    i_uni_1800 = i_uni_1800.drop_duplicates(subset=['Ticker','T-1d'],keep='last')
    i_uni_1800 = i_uni_1800[['T-1d', 'Ticker', 'CSI_index']]
    
     
    # get calendar
    
    i_cal = get_sql('''select distinct tradedate_next as DataDate from cndbprod.dbo.calendar_dates_cn
                    order by tradedate_next''')
    i_cal['T-1d'] = i_cal['DataDate'].shift
()
    i_cal['T-2d'] = i_cal['DataDate'].shift(2)
    i_cal['DataDate_p1d'] = i_cal['DataDate'].shift(-1)
    i_cal = i_cal.dropna()
    
    # get barra 
    # tk mapping assume datadate = T-0d here ,just to be conservative
    
    i_tk_map = get_sql('''select sedol, ric, DataDate
                       from cndbprod.dbo.IMPACT_CN_MAPPING
                       order by datadate ''')
    i_tk_map = i_tk_map[['sedol','ric','DataDate']]
    
    i_barra = get_sql('''select datadate as [T-2d], sedol, name, 
                      [srisk%] as SRISK, BETA, MOMENTUM, SIZE, EARNYILD, RESVOL, 
                      GROWTH, DIVYILD, BTOP, LEVERAGE, SIZENL, LIQUIDTY  
                      from CNDBPROD.dbo.BARRA_GEM3L_CN_RSK 
                      where DataDate >= '20150101'
                      order by datadate
                      ''')
    i_barra_s2 = i_barra.merge(i_cal[['T-2d','DataDate']],on=['T-2d'],how='left')
    i_barra_s2 = i_barra_s2.dropna(subset = ['DataDate'])
    i_barra_s2 = i_barra_s2.sort_values('DataDate')
    i_barra_s2 = pd.merge_asof(i_barra_s2, i_tk_map, on = 'DataDate', by ='sedol')
    i_barra_s2['Ticker'] = i_barra_s2['ric'].str.split('.').str[0]
    i_barra_s2 = i_barra_s2.dropna(subset = ['Ticker'])
    i_barra_s2 = i_barra_s2.drop_duplicates(subset = ['Ticker', 'DataDate'], keep = 'last')
    i_barra_s2 = i_barra_s2[['DataDate','Ticker', 
                             'SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 
                             'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']]
    
    i_barra = None
    cols_f = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 
              'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
   
    
    # get sw industries
    
    # i_wind_ind = get_sql('''select DataDate, Ticker, sw1_code 
    #                      from CNDBPROD.dbo.INDUSTRY_BROKER_CN  
    #                      order by DataDate''')
    # i_wind_ind_dummy = pd.get_dummies(i_wind_ind['sw1_code'])
    # i_wind_ind_dummy.columns = ['sw'+c for c in i_wind_ind_dummy.columns.tolist()]
    
    # i_wind_ind = pd.concat([i_wind_ind, i_wind_ind_dummy], axis = 1)
    # i_wind_ind = i_wind_ind.drop(columns = ['sw1_code'])
    # i_wind_ind = i_wind_ind.drop_duplicates(subset=['Ticker','DataDate'], keep = 'last') 
    
    # cols_i = i_wind_ind_dummy.columns.tolist()
    # i_wind_ind = i_wind_ind[['Ticker', 'DataDate']+cols_i]
    
    
    # get wind 62 industries
    
   
 i_wind_ind = get_sql('''select DataDate as [T-1d], Ticker, w_ind 
                         from CNDBPROD.dbo.[UNIVERSE_ALL_CN_GEM3L]  
                         order by DataDate''')
    i_wind_ind_dummy = pd.get_dummies(i_wind_ind['w_ind'])
    i_wind_ind_dummy.columns = ['wd'+str(c) for c in i_wind_ind_dummy.columns.tolist()]
    
    i_wind_ind = pd.concat([i_wind_ind, i_wind_ind_dummy], axis = 1)
    i_wind_ind = i_wind_ind.drop(columns = ['w_ind'])
    i_wind_ind = i_wind_ind.drop_duplicates(subset=['Ticker','T-1d'], keep = 'last') 
    
    cols_i = i_wind_ind_dummy.columns.tolist()
    i_wind_ind = i_wind_ind[['Ticker', 'T-1d']+cols_i]
    
    
    # get spread
    
    i_spread = get_sql('''select Ticker, DataDate as [T-1d], spread 
                       from cndbprod.dbo.trth_spread_cn
                       order by DataDate''')
    i_spread['Ticker'] = i_spread['Ticker'].str.split('.').str[0]
    i_spread = i_spread.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_spread = i_spread[['Ticker', 'T-1d', 'spread']]
        
    # volatility
    
    i_volatility = get_sql('''select datadate as [T-1d], Ticker, gk_vol_63d as volatility
                           from cndbprod.dbo.wind_gkvol_cn                       
                           order by datadate
                           ''')
    i_volatility = i_volatility.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_volatility = i_volatility[['Ticker', 'T-1d', 'volatility']]
    
    # avgVadj, avgPVadj, avgPVadj_USD, 
    
    i_adv = get_sql('''select datadate as [T-1d], Ticker, avgPVadj, avgPVadj_USD
                    from [CNDBPROD].[dbo].trth_adv_cn
                    order by datadate''')
    i_adv['Ticker'] = i_adv['Ticker'].str.split('.').str[0]
    i_adv = i_adv.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_adv = i_adv[['Ticker', 'T-1d', 'avgPVadj', 'avgPVadj_USD']]
    
    # raw return 
    
    i_ret = get_sql_wind('''select trade_dt as [T-1d], s_info_windcode as Ticker,
                         s_dq_adjclose / s_dq_adjpreclose - 1 as [RawRet-1d]
                         from wind_prod.dbo.ashareeodprices 
                         where trade_dt>='20150101' ''')
    i_ret['Ticker'] = i_ret['Ticker'].str.split('.').str[0]
    i_ret['T-1d'] = pd.to_datetime(i_ret['T-1d'], format = '%Y%m%d')    
    i_ret['RawRet-1d'] = i_ret['RawRet-1d'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
    i_ret = i_ret.drop_duplicates(subset=['Ticker
', 'T-1d'], keep = 'last')
    i_ret = i_ret[['Ticker', 'T-1d', 'RawRet-1d']]
    
    # SO_l1d, FLOAT_1d ???
    
    
    # combine
    
    icom = i_uni_1800.merge(i_cal, on = ['T-1d'], how = 'left')
    icom = icom.merge(i_ret, on = ['Ticker', 'T-1d'], how = 'left')
    
    icom = icom.sort_values('DataDate')    
    icom = pd.merge_asof(icom, i_barra_s2, on = ['DataDate'], by =['Ticker'])
    icom = pd.merge_asof(icom, i_wind_ind, on = ['T-1d'], by =['Ticker'])
    icom = icom.sort_values('T-1d')    
    icom = pd.merge_asof(icom, i_spread, on = ['T-1d'], by =['Ticker'])
    icom = pd.merge_asof(icom, i_volatility, on = ['T-1d'], by =['Ticker'])
    icom = pd.merge_asof(icom, i_adv, on = ['T-1d'], by =['Ticker'])
    
    icom = icom.sort_values(['Ticker', 'DataDate'])
        
    # calculate residual return
    
    icom['clip'] = icom['avgPVadj_USD'].apply(lambda x: min(x*0.01, 1e6))
    icom['BarrRet_CLIP_USD-1d'] = icom.groupby('T-1d')[cols_i + cols_f + ['RawRet-1d', 'clip']].apply(lambda x: orthogonalize_cn_v3(x['RawRet-1d'], x[cols_f], x[cols_i], x['clip'])).values
    
    # calculate past and future return
    
    icom = icom.merge(icom[['T-1d', 'Ticker','BarrRet_CLIP_USD-1d']].rename(columns={'T-1d':'DataDate'}),
                      on = ['DataDate', 'Ticker'], how = 'left', suffixes = ['', '_merge'])
    icom = icom.rename(columns = {'BarrRet_CLIP_USD-1d_merge':'BarrRet_CLIP_USD+0d'})
    icom = icom.merge(icom[['T-1d', 'Ticker','BarrRet_CLIP_USD-1d']].rename(columns={'T-1d':'DataDate_p1d'}),
                      on = ['DataDate_p1d', 'Ticker'], how = 'left', suffixes = ['', '_merge'])
    icom = icom.rename(columns = {'BarrRet_CLIP_USD-1d_merge':'BarrRet_CLIP_USD+1d'})
    
    # output 
    
    c_sh = icom['Ticker'].str[0].isin(['6'])
    c_sz = icom['Ticker'].str[0].isin(['0', '3'])
    icom.loc[c_sh, 'ticker'] = icom.loc[c_sh, 'Ticker'] + '.SH'
    icom.loc[c_sz, 'ticker'] = icom.loc[c_sz, 'Ticker'] + '.SZ'    
    
    icom.to_parquet('/dat/summit_capital/TZ/China Data Hunt/cache/util_prepare_sd_cn_1800.parquet')
    
    

def get_sd_cn_1800():
    
    return pd.read_parquet('/dat/summit_capital/TZ/China Data Hunt/cache/util_prepare_sd_cn_1800.parquet')
    

def prepare_sd_cn_1800gf():
    
    i_sd = get_sql(''' select * from CNDBPROD.dbo.Static_Data_CSI1800_GEM3L ''')
    i_sd = i_sd.rename(columns = {'cccny_vol_21d':'volatility'})
    
    
    i_sd = i_sd[['DataDate','T-1d','Ticker','cn_index',
                 'GSECTOR', 
'GGROP', 'GIND', 'GSUBIND',
                 'PV_l1d', 'avgVadj', 'avgPVadj', 'avgPVadj_USD', 'spread','volatility',
                 'MC_l1d', 'SO_l1d', 'FLOAT_l1d',
                 'SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 
                 'DIVYILD', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL',
                 'last_ed', 'next_ed', 'EDTrdDate_last', 'EDTrdDate_next', 'd2preed', 'd2nexted',
                 'RawRet_USD-1d', 'RawRet_USD+0d', 'RawRet_USD+1d',
                 'BarrRet_CLIP_USD-1d', 'BarrRet_CLIP_USD+0d', 'BarrRet_CLIP_USD+1d'
                 ]]
    i_sd.to_parquet('/dat/summit_capital/TZ/China Data Hunt/cache/util_prepare_sd_cn_1800gf.parquet')

def get_sd_cn_1800gf():
    
    return pd.read_parquet('/dat/summit_capital/TZ/China Data Hunt/cache/util_prepare_sd_cn_1800gf.parquet')



def prepare_sd_cn_1800_bind():
        
    # get universe 
    
    i_uni_1800 = get_sql('''select datadate as [T-1d], Ticker, CSI_index
                         from cndbprod.dbo.universe_csi1800''')
    i_uni_1800 = i_uni_1800.drop_duplicates(subset=['Ticker','T-1d'],keep='last')
    i_uni_1800 = i_uni_1800[['T-1d', 'Ticker', 'CSI_index']]
    
     
    # get calendar
    
    i_cal = get_sql('''select distinct tradedate_next as DataDate from cndbprod.dbo.calendar_dates_cn
                    order by tradedate_next''')
    i_cal['T-1d'] = i_cal['DataDate'].shift()
    i_cal['T-2d'] = i_cal['DataDate'].shift(2)
    i_cal['DataDate_p1d'] = i_cal['DataDate'].shift(-1)
    i_cal = i_cal.dropna()
    
    # get barra 
    # tk mapping assume datadate = T-0d here ,just to be conservative
    
    i_tk_map = get_sql('''select sedol, ric, DataDate
                       from cndbprod.dbo.IMPACT_CN_MAPPING
                       order by datadate ''')
    i_tk_map = i_tk_map[['sedol','ric','DataDate']]
    
    i_barra = get_sql('''select datadate as [T-2d], sedol, name, 
                      [srisk%] as SRISK, BETA, MOMENTUM, SIZE, EARNYILD, RESVOL, 
                      GROWTH, DIVYILD, BTOP, LEVERAGE, SIZENL, LIQUIDTY,
                      indname 
                      from CNDBPROD.dbo.BARRA_GEM3L_CN_RSK 
                      where DataDate >= '20150101'
                      order by datadate
                      ''')
    i_barra_s2 = i_barra.merge(i_cal[['T-2d','DataDate']],on=['T-2d'],how='left')
    i_barra_s2 = i_barra_s2.dropna(subset = ['DataDate'])
    i_barra_s2 = i_barra_s2.sort_values('DataDate')
    i_barra_s2 = pd.
merge_asof(i_barra_s2, i_tk_map, on = 'DataDate', by ='sedol')
    i_barra_s2['Ticker'] = i_barra_s2['ric'].str.split('.').str[0]
    i_barra_s2 = i_barra_s2.dropna(subset = ['Ticker'])
    i_barra_s2 = i_barra_s2.drop_duplicates(subset = ['Ticker', 'DataDate'], keep = 'last')
    
    i_barra_s2_ind = pd.get_dummies(i_barra_s2['indname'])
    cols_i = i_barra_s2_ind.columns.tolist()
    i_barra_s2 = pd.concat([i_barra_s2, i_barra_s2_ind], axis=1)
    
    i_barra_s2 = i_barra_s2[['DataDate','Ticker', 
                             'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 
                             'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY',
                             ] + cols_i]
    
    i_barra = None
    cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 
              'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
   
    
       
    
    
    # get spread
    
    i_spread = get_sql('''select Ticker, DataDate as [T-1d], spread 
                       from cndbprod.dbo.trth_spread_cn
                       order by DataDate''')
    i_spread['Ticker'] = i_spread['Ticker'].str.split('.').str[0]
    i_spread = i_spread.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_spread = i_spread[['Ticker', 'T-1d', 'spread']]
        
    # volatility
    
    i_volatility = get_sql('''select datadate as [T-1d], Ticker, gk_vol_63d as volatility
                           from cndbprod.dbo.wind_gkvol_cn                       
                           order by datadate
                           ''')
    i_volatility = i_volatility.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_volatility = i_volatility[['Ticker', 'T-1d', 'volatility']]
    
    # avgVadj, avgPVadj, avgPVadj_USD, 
    
    i_adv = get_sql('''select datadate as [T-1d], Ticker, avgPVadj, avgPVadj_USD
                    from [CNDBPROD].[dbo].trth_adv_cn
                    order by datadate''')
    i_adv['Ticker'] = i_adv['Ticker'].str.split('.').str[0]
    i_adv = i_adv.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_adv = i_adv[['Ticker', 'T-1d', 'avgPVadj', 'avgPVadj_USD']]
    
    # raw return 
    
    i_ret = get_sql_wind('''select trade_dt as [T-1d], s_info_windcode as Ticker,
                         s_dq_adjclose / s_dq_adjpreclose - 1 as [RawRet-1d]
                         from wind_prod.dbo.ashareeodprices 
                         where trade_dt>='20150101' ''')
    i_ret['Ticker'] = 
i_ret['Ticker'].str.split('.').str[0]
    i_ret['T-1d'] = pd.to_datetime(i_ret['T-1d'], format = '%Y%m%d')    
    i_ret['RawRet-1d'] = i_ret['RawRet-1d'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
    i_ret = i_ret.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_ret = i_ret[['Ticker', 'T-1d', 'RawRet-1d']]
    
    # SO_l1d, FLOAT_1d ???
    
    
    # combine
    
    icom = i_uni_1800.merge(i_cal, on = ['T-1d'], how = 'left')
    icom = icom.merge(i_ret, on = ['Ticker', 'T-1d'], how = 'left')
    
    icom = icom.sort_values('DataDate')    
    icom = pd.merge_asof(icom, i_barra_s2, on = ['DataDate'], by =['Ticker'])
    icom = icom.sort_values('T-1d')    
    icom = pd.merge_asof(icom, i_spread, on = ['T-1d'], by =['Ticker'])
    icom = pd.merge_asof(icom, i_volatility, on = ['T-1d'], by =['Ticker'])
    icom = pd.merge_asof(icom, i_adv, on = ['T-1d'], by =['Ticker'])
    
    icom = icom.sort_values(['Ticker', 'DataDate'])
        
    # calculate residual return
    
    icom['clip'] = icom['avgPVadj_USD'].apply(lambda x: min(x*0.01, 1e6))
    icom['BarrRet_CLIP_USD-1d'] = icom.groupby('T-1d')[cols_i + cols_f + ['RawRet-1d', 'clip']].apply(lambda x: orthogonalize_cn_v3(x['RawRet-1d'], x[cols_f], x[cols_i], x['clip'])).values
    
    # calculate past and future return
    
    icom = icom.merge(icom[['T-1d', 'Ticker','BarrRet_CLIP_USD-1d']].rename(columns={'T-1d':'DataDate'}),
                      on = ['DataDate', 'Ticker'], how = 'left', suffixes = ['', '_merge'])
    icom = icom.rename(columns = {'BarrRet_CLIP_USD-1d_merge':'BarrRet_CLIP_USD+0d'})
    icom = icom.merge(icom[['T-1d', 'Ticker','BarrRet_CLIP_USD-1d']].rename(columns={'T-1d':'DataDate_p1d'}),
                      on = ['DataDate_p1d', 'Ticker'], how = 'left', suffixes = ['', '_merge'])
    icom = icom.rename(columns = {'BarrRet_CLIP_USD-1d_merge':'BarrRet_CLIP_USD+1d'})
    
    # output 
    
    c_sh = icom['Ticker'].str[0].isin(['6'])
    c_sz = icom['Ticker'].str[0].isin(['0', '3'])
    icom.loc[c_sh, 'ticker'] = icom.loc[c_sh, 'Ticker'] + '.SH'
    icom.loc[c_sz, 'ticker'] = icom.loc[c_sz, 'Ticker'] + '.SZ'    
    
    icom.to_parquet('/dat/summit_capital/TZ/China Data Hunt/cache/util_prepare_sd_cn_1800_bind.parquet')
    
    
    
    
    
    

    
    

def get_sd_cn_1800_bind():
    
    return pd.read_parquet('/dat/summit_capital/TZ/China Data Hunt/cache/util_prepare_sd_cn_1800_bind.parquet')
    




def prepare_sd_cn_3000():
        
    # get 
universe 
    
    i_uni_3000 = get_sql('''select datadate as [T-1d], Ticker 
                         from cndbprod.dbo.UNIVERSE_T3000_CN_GEM3L''')
    i_uni_3000 = i_uni_3000.drop_duplicates(subset=['Ticker','T-1d'],keep='last')
    i_uni_3000 = i_uni_3000[['T-1d', 'Ticker']]
    
     
    # get calendar
    
    i_cal = get_sql('''select distinct tradedate_next as DataDate from cndbprod.dbo.calendar_dates_cn
                    order by tradedate_next''')
    i_cal['T-1d'] = i_cal['DataDate'].shift()
    i_cal['T-2d'] = i_cal['DataDate'].shift(2)
    i_cal['DataDate_p1d'] = i_cal['DataDate'].shift(-1)
    i_cal = i_cal.dropna()
    
    # get barra 
    # tk mapping assume datadate = T-0d here ,just to be conservative
    
    i_tk_map = get_sql('''select sedol, ric, DataDate
                       from cndbprod.dbo.IMPACT_CN_MAPPING
                       order by datadate ''')
    i_tk_map = i_tk_map[['sedol','ric','DataDate']]
    
    i_barra = get_sql('''select datadate as [T-2d], sedol, name, 
                      [srisk%] as SRISK, BETA, MOMENTUM, SIZE, EARNYILD, RESVOL, 
                      GROWTH, DIVYILD, BTOP, LEVERAGE, SIZENL, LIQUIDTY  
                      from CNDBPROD.dbo.BARRA_GEM3L_CN_RSK 
                      where DataDate >= '20150101'
                      order by datadate
                      ''')
    i_barra_s2 = i_barra.merge(i_cal[['T-2d','DataDate']],on=['T-2d'],how='left')
    i_barra_s2 = i_barra_s2.dropna(subset = ['DataDate'])
    i_barra_s2 = i_barra_s2.sort_values('DataDate')
    i_barra_s2 = pd.merge_asof(i_barra_s2, i_tk_map, on = 'DataDate', by ='sedol')
    i_barra_s2['Ticker'] = i_barra_s2['ric'].str.split('.').str[0]
    i_barra_s2 = i_barra_s2.dropna(subset = ['Ticker'])
    i_barra_s2 = i_barra_s2.drop_duplicates(subset = ['Ticker', 'DataDate'], keep = 'last')
    i_barra_s2 = i_barra_s2[['DataDate','Ticker', 
                             'SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 
                             'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']]
    
    i_barra = None
    cols_f = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 
              'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
   
    
    # get sw industries
    
    # i_wind_ind = get_sql('''select DataDate, Ticker, sw1_code 
    #                      from CNDBPROD.dbo.INDUSTRY_BROKER_CN  
    #                      order by DataDate''')
    # i_wind_ind_dummy = pd.get
_dummies(i_wind_ind['sw1_code'])
    # i_wind_ind_dummy.columns = ['sw'+c for c in i_wind_ind_dummy.columns.tolist()]
    
    # i_wind_ind = pd.concat([i_wind_ind, i_wind_ind_dummy], axis = 1)
    # i_wind_ind = i_wind_ind.drop(columns = ['sw1_code'])
    # i_wind_ind = i_wind_ind.drop_duplicates(subset=['Ticker','DataDate'], keep = 'last') 
    
    # cols_i = i_wind_ind_dummy.columns.tolist()
    # i_wind_ind = i_wind_ind[['Ticker', 'DataDate']+cols_i]
    
    
    # get wind 62 industries
    
    i_wind_ind = get_sql('''select DataDate as [T-1d], Ticker, w_ind 
                         from CNDBPROD.dbo.[UNIVERSE_ALL_CN_GEM3L]  
                         order by DataDate''')
    i_wind_ind_dummy = pd.get_dummies(i_wind_ind['w_ind'])
    i_wind_ind_dummy.columns = ['wd'+str(c) for c in i_wind_ind_dummy.columns.tolist()]
    
    i_wind_ind = pd.concat([i_wind_ind, i_wind_ind_dummy], axis = 1)
    i_wind_ind = i_wind_ind.drop(columns = ['w_ind'])
    i_wind_ind = i_wind_ind.drop_duplicates(subset=['Ticker','T-1d'], keep = 'last') 
    
    cols_i = i_wind_ind_dummy.columns.tolist()
    i_wind_ind = i_wind_ind[['Ticker', 'T-1d']+cols_i]
    
    
    # get spread
    
    i_spread = get_sql('''select Ticker, DataDate as [T-1d], spread 
                       from cndbprod.dbo.trth_spread_cn
                       order by DataDate''')
    i_spread['Ticker'] = i_spread['Ticker'].str.split('.').str[0]
    i_spread = i_spread.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_spread = i_spread[['Ticker', 'T-1d', 'spread']]
        
    # volatility
    
    i_volatility = get_sql('''select datadate as [T-1d], Ticker, gk_vol_63d as volatility
                           from cndbprod.dbo.wind_gkvol_cn                       
                           order by datadate
                           ''')
    i_volatility = i_volatility.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_volatility = i_volatility[['Ticker', 'T-1d', 'volatility']]
    
    # avgVadj, avgPVadj, avgPVadj_USD, 
    
    i_adv = get_sql('''select datadate as [T-1d], Ticker, avgPVadj, avgPVadj_USD
                    from [CNDBPROD].[dbo].trth_adv_cn
                    order by datadate''')
    i_adv['Ticker'] = i_adv['Ticker'].str.split('.').str[0]
    i_adv = i_adv.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_adv = i_adv[['Ticker', 'T-1d', 'avgPVadj', 'avgPVadj_USD']]
    
    # raw return 
    
    i_ret = get_sql_wind('''select trade_dt a
s [T-1d], s_info_windcode as Ticker,
                         s_dq_adjclose / s_dq_adjpreclose - 1 as [RawRet-1d]
                         from wind_prod.dbo.ashareeodprices 
                         where trade_dt>='20150101' ''')
    i_ret['Ticker'] = i_ret['Ticker'].str.split('.').str[0]
    i_ret['T-1d'] = pd.to_datetime(i_ret['T-1d'], format = '%Y%m%d')    
    i_ret['RawRet-1d'] = i_ret['RawRet-1d'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
    i_ret = i_ret.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_ret = i_ret[['Ticker', 'T-1d', 'RawRet-1d']]
    
    # SO_l1d, FLOAT_1d ???
    
    
    # combine
    
    icom = i_uni_3000.merge(i_cal, on = ['T-1d'], how = 'left')
    icom = icom.merge(i_ret, on = ['Ticker', 'T-1d'], how = 'left')
    
    icom = icom.sort_values('DataDate')    
    icom = pd.merge_asof(icom, i_barra_s2, on = ['DataDate'], by =['Ticker'])
    icom = pd.merge_asof(icom, i_wind_ind, on = ['T-1d'], by =['Ticker'])
    icom = icom.sort_values('T-1d')    
    icom = pd.merge_asof(icom, i_spread, on = ['T-1d'], by =['Ticker'])
    icom = pd.merge_asof(icom, i_volatility, on = ['T-1d'], by =['Ticker'])
    icom = pd.merge_asof(icom, i_adv, on = ['T-1d'], by =['Ticker'])
    
    icom = icom.sort_values(['Ticker', 'DataDate'])
        
    # calculate residual return
    
    icom['clip'] = icom['avgPVadj_USD'].apply(lambda x: min(x*0.01, 1e6))
    icom['BarrRet_CLIP_USD-1d'] = icom.groupby('T-1d')[cols_i + cols_f + ['RawRet-1d', 'clip']].apply(lambda x: orthogonalize_cn_v3(x['RawRet-1d'], x[cols_f], x[cols_i], x['clip'])).values
    
    # calculate past and future return
    
    icom = icom.merge(icom[['T-1d', 'Ticker','BarrRet_CLIP_USD-1d']].rename(columns={'T-1d':'DataDate'}),
                      on = ['DataDate', 'Ticker'], how = 'left', suffixes = ['', '_merge'])
    icom = icom.rename(columns = {'BarrRet_CLIP_USD-1d_merge':'BarrRet_CLIP_USD+0d'})
    icom = icom.merge(icom[['T-1d', 'Ticker','BarrRet_CLIP_USD-1d']].rename(columns={'T-1d':'DataDate_p1d'}),
                      on = ['DataDate_p1d', 'Ticker'], how = 'left', suffixes = ['', '_merge'])
    icom = icom.rename(columns = {'BarrRet_CLIP_USD-1d_merge':'BarrRet_CLIP_USD+1d'})
    
    # output 
    
    c_sh = icom['Ticker'].str[0].isin(['6'])
    c_sz = icom['Ticker'].str[0].isin(['0', '3'])
    icom.loc[c_sh, 'ticker'] = icom.loc[c_sh, 'Ticker'] + '.SH'
    icom.loc[c_sz, 'ticker'] = icom.loc[c_sz, 'Ticker'] + '.SZ'    
    
    icom.to_parqu
et('/dat/summit_capital/TZ/China Data Hunt/cache/util_prepare_sd_cn_3000.parquet')
    


def get_sd_cn_3000():
    
    return pd.read_parquet('/dat/summit_capital/TZ/China Data Hunt/cache/util_prepare_sd_cn_3000.parquet')
    

def get_ashare_hk_sd_v2(str_type = 'backtest', version='2'):
    # v2 is between 2016 and 2020 where we have hk-uni residual return 
    # v2p1 is between 2016 and 2021
    if str_type == 'backtest':
        print ('loading sd ... ', end='')
        tic()
        i_sd = pd.read_parquet("/dat/summit_capital/Data/China Data Hunt/cache/pWIND_util_static_data_hk_v{0}.parquet".format(version))
    
        
        # hk connect flag
        i_tk_uni = get_sql_wind('''(select S_INFO_WINDCODE as ticker, entry_dt, remove_dt from [WIND].[dbo].[SZSCMEMBERS]) 
                       UNION
                       (select S_INFO_WINDCODE as ticker, entry_dt, remove_dt from [WIND].[dbo].[SHSCMEMBERS]) ''')
        i_tk_uni['entry_dt'] = pd.to_datetime(i_tk_uni['entry_dt'], format='%Y%m%d')
        i_tk_uni.loc[i_tk_uni['remove_dt'].isnull(), 'remove_dt'] = np.nan
        i_tk_uni['remove_dt'] = pd.to_datetime(i_tk_uni['remove_dt'], format='%Y%m%d')
        
        i_sd = i_sd.merge(i_tk_uni, on = ['ticker'], how = 'left')
    
        c_isin = (i_sd['datadate'] >= i_sd['entry_dt']) & ((i_sd['datadate'] <= i_sd['remove_dt'])|i_sd['remove_dt'].isnull())
        i_sd.loc[c_isin,'isin_hk_uni'] = 1
        i_sd = i_sd.rename(columns={'entry_dt':'hk_uni_entry','remove_dt':'hk_uni_remove'})
        
        i_sd = i_sd.sort_values(['ticker','datadate','isin_hk_uni'])
        i_sd = i_sd.drop_duplicates(subset=['ticker','datadate'], keep = 'first')
        
        # get csi300 membership from prod tables
        i_mem_csi300 = get_sql_cndb('''select date_of_portfolio as datadate_p1d,
                               replace(primary_ric_company_level,'.SS','.SH') as ticker 
                               from cndbprod.dbo.csi_300_cons''')
        i_mem_csi300['csi300_flag'] = 1
        i_sd = i_sd.merge(i_mem_csi300, on = ['ticker', 'datadate_p1d'], how = 'left')
        toc()
        return i_sd
    else:
        i_sd = pd.read_parquet("/dat/summit_capital/Data/China Data Hunt/cache/pWIND_util_static_data_hk_v{0}.parquet".format(version))
        return i_sd



def prepare_sd_us():
    
    # orignal columns
    
    
    i_sd = get_sql('''
                   select DataDate, [T-1d], capTicker as Ticker, 
                          GSECTOR, GGROP, GIND,

                          avgPVadj, avgVadj, spread, gk_vol_63d as volatility, MC, EQY_SH_OUT_REAL,
                          [SRISK],[DREVRSL],[BETA],[DIVYILD],[DWNRISK],[EARNQLTY],[EARNYILD],
                          [GROWTH],[INDMOM],[LEVERAGE],[LIQUIDTY],[LTREVRSL],[MGMTQLTY],
                          [MIDCAP],[MOMENTUM],[PROFIT],[PROSPECT],[REGMOM],[RESVOL],[SEASON],
                          [SENTMT],[SHORTINT],[STREVRSL],[SIZE],[VALUE],
                          [time_of_day],[next_ed],[last_time_of_day],[last_ed],[d2nexted],[d2preed],
                          [RawRet-1d],[RawRet+0d],[RawRet+1d],
                          [BarrRet_SRISK-1d],[BarrRet_SRISK+0d],[BarrRet_SRISK+1d],
                          [BarrRet_CLIP-1d],[BarrRet_CLIP+0d],[BarrRet_CLIP+1d],
                          [HedgeRet-1d],[HedgeRet+0d],[HedgeRet+1d]                          
                   from FGDBTEST.dbo.Static_Data
                   ''')
                 
    i_sd[i_sd['DataDate']>='2016-01-01'].to_parquet('/dat/summit_capital/TZ/backtester/data_cache/sd_us_short.parquet')
    i_sd.to_parquet('/dat/summit_capital/TZ/backtester/data_cache/sd_us.parquet')
    


def get_sd_us(long_short='short', extra_column_lst=[]):
    #get static data
    #column_type: all
    #column_type: tk_uni ('DataDate','Ticker','T-1d')
    #column_type: backtest
    
    if long_short=='short':
        i_sd = pd.read_parquet('/dat/summit_capital/TZ/backtester/data_cache/sd_us_short.parquet')
    else:
        i_sd = pd.read_parquet('/dat/summit_capital/TZ/backtester/data_cache/sd_us.parquet')
    
    if len(extra_column_lst) > 0:
        
        i_extra = get_sql('''
                   select DataDate, capTicker as Ticker, {0}                        
                   from FGDBTEST.dbo.Static_Data
                   '''.format( ", ".join(extra_column_lst) ))
        i_sd = i_sd.merge(i_extra, on = ['DataDate', 'Ticker'], how = 'left')
        
    return i_sd



def get_uni2k_us():
    
    return get_sql('''select DataDate, Ticker from [FGDBPROD].[dbo].[UNIVERSE_T2000]''')

def get_uniall_us():
    
    return get_sql('''select DataDate, Ticker, SEDOL, ISIN from [FGDBPROD].[dbo].[UNIVERSE_ALL]''')


def prepare_fut_50():
    
    # get universe and rret
    
    icom = get_sd_cn_50()
    icom = icom[['T-1d', 'Ticker','BarrRet_CLIP_USD-1d']]    
    icom = icom.sort_values(['Ticker', 'DataDate'])
    
    
    # get calendar
    
    i_cal = get_sql('''select distinct tradedate_next a
s DataDate from cndbprod.dbo.calendar_dates_cn
                    order by tradedate_next''')
    i_cal['T-1d'] = i_cal['DataDate'].shift()
    i_cal['T-2d'] = i_cal['DataDate'].shift(2)
    for n in range(1, 121):
        i_cal['DataDate_p'+str(n)+'d'] = i_cal['DataDate'].shift(-n)
    i_cal = i_cal.dropna()
    
    
    
        
    # calculate residual return
    
    icom = icom.merge(i_cal, on = 'T-1d', how = 'left')
    
    for n in range(1,121):
        # the immediate return for the signal on the morning of DataDate
        # has [T-1d] == DataDate+1d
        icom = icom.merge(icom[['Ticker', 'T-1d', 'BarrRet_CLIP_USD-1d']]\
                              .rename(columns = {'T-1d':'DataDate_p'+str(n)+'d', 
                                                 'BarrRet_CLIP_USD-1d':'BarrRet_CLIP_USD_p'+str(n)+'d'}),
                          on = ['Ticker', 'DataDate_p'+str(n)+'d'], how = 'left')
        
    
    icom[['T-1d', 'Ticker', 'DataDate',
            'DataDate_p1d', 'DataDate_p5d', 'DataDate_p10d', 'DataDate_p20d', 'DataDate_p40d',
            'DataDate_p80d', 'DataDate_p120d',
            'BarrRet_CLIP_USD-1d'] + \
         ['BarrRet_CLIP_USD_p'+str(i)+'d' for i in range(1, 121)]]\
        .to_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_50.parquet')



def prepare_fut_500():
        
    
    # get universe and rret
    
    icom = get_sd_cn_500()
    icom = icom[['T-1d', 'Ticker','BarrRet_CLIP_USD-1d','hret-1d']]    
    icom = icom.sort_values(['Ticker', 'T-1d'])
    
    
    # get calendar
    
    i_cal = get_sql('''select distinct tradedate_next as DataDate from cndbprod.dbo.calendar_dates_cn
                    order by tradedate_next''')
    i_cal['T-1d'] = i_cal['DataDate'].shift()
    i_cal['T-2d'] = i_cal['DataDate'].shift(2)
    for n in range(1, 121):
        i_cal['DataDate_p'+str(n)+'d'] = i_cal['DataDate'].shift(-n)
    i_cal = i_cal.dropna()
           
        
    # calculate residual return
    
    icom = icom.merge(i_cal, on = 'T-1d', how = 'left')
    
    for n in range(1,121):
        # the immediate return for the signal on the morning of DataDate
        # has [T-1d] == DataDate+1d
        icom = icom.merge(icom[['Ticker', 'T-1d', 'BarrRet_CLIP_USD-1d', 'hret-1d']]\
                              .rename(columns = {'T-1d':'DataDate_p'+str(n)+'d', 
                                                 'BarrRet_CLIP_USD-1d':'BarrRet_CLIP_USD_p'+str(n)+'d',
                                                 'hret-1
d':'hret_p'+str(n)+'d'}),
                          on = ['Ticker', 'DataDate_p'+str(n)+'d'], how = 'left')
            
    icom[['T-1d', 'Ticker', 'DataDate',
            'DataDate_p1d', 'DataDate_p5d', 'DataDate_p10d', 'DataDate_p20d', 'DataDate_p40d',
            'DataDate_p80d', 'DataDate_p120d',
            'BarrRet_CLIP_USD-1d'] + \
         ['BarrRet_CLIP_USD_p'+str(i)+'d' for i in range(1, 121)]\
         +['hret_p'+str(i)+'d' for i in range(1, 20)]]\
        .to_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_500.parquet')





def prepare_fut_1800():
    
    # if we have a signal at datadate, the bret_p1d ... bret_p20d columns
    # will give us realistic future returns. 
    
    
    
    # get universe 
    
    i_uni_1800 = get_sql('''select datadate as [T-1d], Ticker, CSI_index
                         from cndbprod.dbo.universe_csi1800''')
    i_uni_1800 = i_uni_1800.drop_duplicates(subset=['Ticker','T-1d'],keep='last')
    i_uni_1800 = i_uni_1800[['T-1d', 'Ticker', 'CSI_index']]
    
     
    # get calendar
    
    i_cal = get_sql('''select distinct tradedate_next as DataDate from cndbprod.dbo.calendar_dates_cn
                    order by tradedate_next''')
    i_cal['T-1d'] = i_cal['DataDate'].shift()
    i_cal['T-2d'] = i_cal['DataDate'].shift(2)
    for n in range(1, 121):
        i_cal['DataDate_p'+str(n)+'d'] = i_cal['DataDate'].shift(-n)
    for n in range(1, 21):
        i_cal['DataDate_'+str(n)+'d'] = i_cal['DataDate'].shift(n)
    i_cal = i_cal.dropna()
    
    
    # get barra 
    # tk mapping assume datadate = T-0d here ,just to be conservative
    
    i_tk_map = get_sql('''select sedol, ric, DataDate
                       from cndbprod.dbo.IMPACT_CN_MAPPING
                       order by datadate ''')
    i_tk_map = i_tk_map[['sedol','ric','DataDate']]
    
    i_barra = get_sql('''select datadate as [T-2d], sedol, name, 
                      [srisk%] as SRISK, BETA, MOMENTUM, SIZE, EARNYILD, RESVOL, 
                      GROWTH, DIVYILD, BTOP, LEVERAGE, SIZENL, LIQUIDTY  
                      from CNDBPROD.dbo.BARRA_GEM3L_CN_RSK 
                      where DataDate >= '20150101'
                      order by datadate
                      ''')
    i_barra_s2 = i_barra.merge(i_cal[['T-2d','DataDate']],on=['T-2d'],how='left')
    i_barra_s2 = i_barra_s2.dropna(subset = ['DataDate'])
    i_barra_s2 = i_barra_s2.sort_values('DataDate')
    i_barra_s2 = pd.merge_asof(i_barra_s2, i_tk_map, on = 'DataDate', by ='s
edol')
    i_barra_s2['Ticker'] = i_barra_s2['ric'].str.split('.').str[0]
    i_barra_s2 = i_barra_s2.dropna(subset = ['Ticker'])
    i_barra_s2 = i_barra_s2.drop_duplicates(subset = ['Ticker', 'DataDate'], keep = 'last')
    i_barra_s2 = i_barra_s2[['DataDate','Ticker', 
                             'SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 
                             'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']]
    
    i_barra = None
    cols_f = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 
              'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
   
    
    
    
    # get wind 62 industries
    
    i_wind_ind = get_sql('''select DataDate as [T-1d], Ticker, w_ind 
                         from CNDBPROD.dbo.[UNIVERSE_ALL_CN_GEM3L]  
                         order by DataDate''')
    i_wind_ind_dummy = pd.get_dummies(i_wind_ind['w_ind'])
    i_wind_ind_dummy.columns = ['wd'+str(c) for c in i_wind_ind_dummy.columns.tolist()]
    
    i_wind_ind = pd.concat([i_wind_ind, i_wind_ind_dummy], axis = 1)
    i_wind_ind = i_wind_ind.drop(columns = ['w_ind'])
    i_wind_ind = i_wind_ind.drop_duplicates(subset=['Ticker','T-1d'], keep = 'last') 
    
    cols_i = i_wind_ind_dummy.columns.tolist()
    i_wind_ind = i_wind_ind[['Ticker', 'T-1d']+cols_i]
    
    
    # avgVadj, avgPVadj, avgPVadj_USD, 
    
    i_adv = get_sql('''select datadate as [T-1d], Ticker, avgPVadj, avgPVadj_USD
                    from [CNDBPROD].[dbo].trth_adv_cn
                    order by datadate''')
    i_adv['Ticker'] = i_adv['Ticker'].str.split('.').str[0]
    i_adv = i_adv.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_adv = i_adv[['Ticker', 'T-1d', 'avgPVadj', 'avgPVadj_USD']]
    
    # raw return 
    
    i_ret = get_sql_wind('''select trade_dt as [T-1d], s_info_windcode as Ticker,
                         s_dq_adjclose / s_dq_adjpreclose - 1 as [RawRet-1d]
                         from wind_prod.dbo.ashareeodprices 
                         where trade_dt>='20150101' ''')
    i_ret['Ticker'] = i_ret['Ticker'].str.split('.').str[0]
    i_ret['T-1d'] = pd.to_datetime(i_ret['T-1d'], format = '%Y%m%d')    
    i_ret['RawRet-1d'] = i_ret['RawRet-1d'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
    i_ret = i_ret.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_ret = i_ret[['Ticker', 'T-1d', 'RawRet-1d']]
    
    
    # combine
    
    icom = i_uni_1800.merge(i_cal, on = ['
T-1d'], how = 'left')
    
    icom = icom.merge(i_ret, on = ['Ticker', 'T-1d'], how = 'left')    
    icom = icom.sort_values('DataDate')    
    icom = pd.merge_asof(icom, i_barra_s2, on = ['DataDate'], by =['Ticker'])
    icom = pd.merge_asof(icom, i_wind_ind, on = ['T-1d'], by =['Ticker'])
    icom = icom.sort_values('T-1d')    
    icom = pd.merge_asof(icom, i_adv, on = ['T-1d'], by =['Ticker'])
    
    icom = icom.sort_values(['Ticker', 'DataDate'])
        
    # calculate residual return
    
    icom['clip'] = icom['avgPVadj_USD'].apply(lambda x: min(x*0.01, 1e6))
    icom['BarrRet_CLIP_USD-1d'] = icom.groupby('T-1d')[cols_i + cols_f + ['RawRet-1d', 'clip']].apply(lambda x: orthogonalize_cn_v3(x['RawRet-1d'], x[cols_f], x[cols_i], x['clip'])).values
    icom['DataDate_p0d'] = icom['DataDate']
    
    for n in range(0,121):
        # the immediate return for the signal on the morning of DataDate
        # has [T-1d] == DataDate+1d
        icom = icom.merge(icom[['Ticker', 'T-1d', 'BarrRet_CLIP_USD-1d']]\
                              .rename(columns = {'T-1d':'DataDate_p'+str(n)+'d', 
                                                 'BarrRet_CLIP_USD-1d':'BarrRet_CLIP_USD_p'+str(n)+'d'}),
                          on = ['Ticker', 'DataDate_p'+str(n)+'d'], how = 'left')
    for n in range(1,21):
        icom = icom.merge(icom[['Ticker', 'T-1d', 'BarrRet_CLIP_USD-1d']]\
                              .rename(columns = {'T-1d':'DataDate_'+str(n)+'d', 
                                                 'BarrRet_CLIP_USD-1d':'BarrRet_CLIP_USD_'+str(n)+'d'}),
                          on = ['Ticker', 'DataDate_'+str(n)+'d'], how = 'left')
        
    
    icom[['T-1d', 'Ticker', 'DataDate',
            'DataDate_p1d', 'DataDate_p5d', 'DataDate_p10d', 'DataDate_p20d', 'DataDate_p40d',
            'DataDate_p80d', 'DataDate_p120d',
            'BarrRet_CLIP_USD-1d'] + \
         ['BarrRet_CLIP_USD_p'+str(i)+'d' for i in range(0, 121)] + \
         ['BarrRet_CLIP_USD_'+str(i)+'d' for i in range(1, 21)] ]\
        .to_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800.parquet')
    
    

def prepare_fut_1800_immret():
    
    # this is the original version
    
    # the old version: range(1,41), 0.02 perday, bool_insig_nan False
    
    cols_fut = ['BarrRet_CLIP_USD_p'+str(i)+'d' for i in range(1, 61)]    
    i_fut_1800 = pd.read_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800.parquet',
                                 columns = ['Ticke
r', 'T-1d', 'DataDate'] + cols_fut)
    
    @njit
    def numba_maximum_accumulate(A):
        r = np.empty(len(A))
        t = -np.inf
        for i in range(len(A)):
            t = np.maximum(t, A[i])
            r[i] = t
        return r        
    @njit
    def numba_minimum_accumulate(A):
        r = np.empty(len(A))
        t = -np.inf
        for i in range(len(A)):
            t = np.maximum(t, A[i])
            r[i] = t
        return r
    @njit
    def helper_fut_1800_immret(matrix, thrs, bool_insig_nan = False, perday = True):
        # this outputs immediate return whose abs > thrs
                
        output = [0.0]*0
        
        for i in list(range(matrix.shape[0])):
            
            arr = matrix[i, :]
            
            # step 0 - cleanse return data
            arr[np.isnan(arr)] = 0
            arr_cumsum = np.cumsum(arr)
            
            # step 1 - find the direction of the return
            c_abs_gt_thrs = np.abs(arr_cumsum) > thrs
            if c_abs_gt_thrs.sum() > 0: # if there is sig ret
                direction = np.sign(arr_cumsum[c_abs_gt_thrs][0])
                if direction==1:
                    arr_cumsum_cummax = numba_maximum_accumulate(arr_cumsum)
                    c_dd_gt_thrs = (arr_cumsum_cummax - arr_cumsum)>thrs
                    if np.sum(c_dd_gt_thrs) > 0: # have drawdown > thrs
                        loc_dd = np.where(c_dd_gt_thrs)[0][0]
                        if perday == True:
                            output.append(np.max(arr_cumsum[:loc_dd])/(np.argmax(arr_cumsum[:loc_dd])+1))
                        else: 
                            output.append(np.max(arr_cumsum[:loc_dd]))
                    elif np.sum(c_dd_gt_thrs) == 0: # not have drawdown > thres
                        if perday == True:
                            output.append(np.max(arr_cumsum)/(np.argmax(arr_cumsum)+1))
                        else:
                            output.append(np.max(arr_cumsum))
                                                
                elif direction==-1:
                    arr_cumsum_cummin = numba_minimum_accumulate(arr_cumsum)
                    c_dd_gt_thrs = (arr_cumsum - arr_cumsum_cummin)>thrs
                    if np.sum(c_dd_gt_thrs) > 0: # have drawdown > thrs
                        loc_dd = np.where(c_dd_gt_thrs)[0][0]
                        if perday == True:
                            output.append(np.min(arr_cumsum[:loc_dd])/(np.argmin(arr_cum
sum[:loc_dd])+1))
                        else:
                            output.append(np.min(arr_cumsum[:loc_dd]))
                    elif np.sum(c_dd_gt_thrs) == 0: # not have drawdown > thres
                        if perday == True:
                            output.append(np.min(arr_cumsum)/(np.argmin(arr_cumsum)+1))
                        else:
                            output.append(np.min(arr_cumsum))
                
            else: # if there is no sig ret
                if bool_insig_nan == False:
                    if perday == True:
                        output.append(arr_cumsum[-1] / len(arr_cumsum))
                    else:
                        output.append(arr_cumsum[-1])
                elif bool_insig_nan == True:                    
                    output.append(np.nan)
                        
            
        return np.array(output)
    
    
    
    for thrs in [0.01, 0.02, 0.04, 0.06, 0.10, 0.15]:
        i_fut_1800['ret_perday_thrs'+str(thrs).replace('.','p')+'_insigvalue'] = helper_fut_1800_immret(i_fut_1800[cols_fut].values,thrs,bool_insig_nan=False)
        i_fut_1800['ret_perday_thrs'+str(thrs).replace('.','p')+'_insignan'] = helper_fut_1800_immret(i_fut_1800[cols_fut].values,thrs,bool_insig_nan=True)
    for thrs in [0.01, 0.02, 0.04, 0.06, 0.10, 0.15]:
        i_fut_1800['ret_whole_thrs'+str(thrs).replace('.','p')+'_insigvalue'] = helper_fut_1800_immret(i_fut_1800[cols_fut].values,thrs,bool_insig_nan=False,perday=False)
        i_fut_1800['ret_whole_thrs'+str(thrs).replace('.','p')+'_insignan'] = helper_fut_1800_immret(i_fut_1800[cols_fut].values,thrs,bool_insig_nan=True,perday=False)
    
    i_fut_1800.to_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800_immret.parquet')
        

def prepare_fut_1800_immret_v1p1():
    # there is a bug here ... the drawdown might happen before an extreme
    # example: 0 +1.7 -1.7 (drawdown recognized) +14 -10
    # in this example, when we get to +1.7, we also has a short signal ... 
    # also, average return is calculated through 1 day before drawdown is recognized ...
    
    # this is the original version
    # with some modifications on the algo
    
    cols_fut = ['BarrRet_CLIP_USD_p'+str(i)+'d' for i in range(1, 61)]    
    i_fut_1800 = pd.read_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800.parquet',
                                 columns = ['Ticker', 'T-1d', 'DataDate'] + cols_fut)
    
    @njit
    def numba_maximum_accumulate(
A):
        r = np.empty(len(A))
        t = -np.inf
        for i in range(len(A)):
            t = np.maximum(t, A[i])
            r[i] = t
        return r        
    @njit
    def numba_minimum_accumulate(A):
        r = np.empty(len(A))
        t = -np.inf
        for i in range(len(A)):
            t = np.maximum(t, A[i])
            r[i] = t
        return r
    @njit
    # it turns out that whole-day return is inferior
    # insig return replace with nan or not .. has little impact
    def helper_fut_1800_immret(matrix, thrs):
        # this outputs immediate return whose abs > thrs
                
        output = [0.0]*0
        
        for i in list(range(matrix.shape[0])):
            
            arr = matrix[i, :]
            #arr_idx = np.array(range(len(arr)))
            
            # step 0 - cleanse return data
            arr[np.isnan(arr)] = 0
            arr_cumsum = np.cumsum(arr)
            
            # step 1 - find the direction of the return
            arr_abs_gt_thrs = np.abs(arr_cumsum) > thrs
            if arr_abs_gt_thrs.sum() > 0: # if there is sig ret
                #c_idx_of_first_sig = np.where(arr_abs_gt_thrs)[0][0]
                direction = np.sign(arr_cumsum[arr_abs_gt_thrs][0])
                if direction==1:
                    arr_cumsum_cummax = numba_maximum_accumulate(arr_cumsum)
                    c_dd_gt_thrs = (arr_cumsum_cummax - arr_cumsum)>thrs
                    if np.sum(c_dd_gt_thrs) > 0: # have drawdown > thrs
                        loc_dd = np.where(c_dd_gt_thrs)[0][0]                        
                        output.append(np.max(arr_cumsum[:loc_dd])/(np.argmax(arr_cumsum[:loc_dd])+1))                        
                        #if loc_dd<=c_idx_of_first_sig:
                        #    print(i)
                        #    raise Exception('loc_dd<=c_idx_of_first_sig')
                        
                    elif np.sum(c_dd_gt_thrs) == 0: # not have drawdown > thres                        
                        output.append(np.max(arr_cumsum)/(np.argmax(arr_cumsum)+1))
                                                
                elif direction==-1:
                    arr_cumsum_cummin = numba_minimum_accumulate(arr_cumsum)
                    c_dd_gt_thrs = (arr_cumsum - arr_cumsum_cummin)>thrs
                    if np.sum(c_dd_gt_thrs) > 0: # have drawdown > thrs
                        loc_dd = np.where(c_dd_gt_thrs)[0][0]                        
          
              output.append(np.min(arr_cumsum[:loc_dd])/(np.argmin(arr_cumsum[:loc_dd])+1))                        
                    elif np.sum(c_dd_gt_thrs) == 0: # not have drawdown > thres                        
                        output.append(np.min(arr_cumsum)/(np.argmin(arr_cumsum)+1))
                
            else: # if there is no sig ret
                output.append(arr_cumsum[-1] / len(arr_cumsum))
                
            
        return np.array(output)
    
    
    for thrs in [0.02, 0.04, 0.06, 0.10, 0.15]:
        i_fut_1800['ret_perday_thrs'+str(thrs).replace('.','p')] = helper_fut_1800_immret(i_fut_1800[cols_fut].values,thrs)
        

    i_fut_1800.to_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800_immret_v1p1.parquet')
        



def prepare_fut_1800_immret_v1p2():
    
    # example: 0 +1.7 -1.7 (drawdown recognized) +14 -10
    # in this example, when we get to +1.7, we also has a short signal ... 
    
    # this is the original version
    # with some modifications on the algo
    
    cols_fut = ['BarrRet_CLIP_USD_p'+str(i)+'d' for i in range(1, 61)]    
    i_fut_1800 = pd.read_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800.parquet',
                                 columns = ['Ticker', 'T-1d', 'DataDate'] + cols_fut)
    
    @njit
    def numba_maximum_accumulate(A):
        r = np.empty(len(A))
        t = -np.inf
        for i in range(len(A)):
            t = np.maximum(t, A[i])
            r[i] = t
        return r        
    @njit
    def numba_minimum_accumulate(A):
        r = np.empty(len(A))
        t = np.inf
        for i in range(len(A)):
            t = np.minimum(t, A[i])
            r[i] = t
        return r
    
    @njit
    # it turns out that whole-day return is inferior
    # insig return replace with nan or not .. has little impact
    def helper_fut_1800_immret(matrix, thrs):
        # this outputs immediate return whose abs > thrs
                
        output = [0.0]*0
        
        for i in list(range(matrix.shape[0])):
            
            arr = matrix[i, :]
            arr_idx = np.array(list(range(len(arr))))
            
            # step 0 - cleanse return data
            arr[np.isnan(arr)] = 0
            arr_cumsum = np.cumsum(arr)
            
            # step 1 - find the direction of the return
            arr_abs_gt_thrs = np.abs(arr_cumsum) > thrs
            if arr_abs_gt_thrs.sum() > 0: # if there is sig ret
                c_idx_of_f
irst_sig = np.where(arr_abs_gt_thrs)[0][0]
                direction = np.sign(arr_cumsum[arr_abs_gt_thrs][0])
                if direction==1:
                    arr_cumsum_cummax = numba_maximum_accumulate(arr_cumsum)
                    c_dd_gt_thrs = ((arr_cumsum_cummax - arr_cumsum)>thrs) & (arr_idx > c_idx_of_first_sig)
                    if np.sum(c_dd_gt_thrs) > 0: # have drawdown > thrs
                        loc_dd = np.where(c_dd_gt_thrs)[0][0]                        
                        output.append(np.max(arr_cumsum[:loc_dd])/(np.argmax(arr_cumsum[:loc_dd])+1))                        
                        
                    elif np.sum(c_dd_gt_thrs) == 0: # not have drawdown > thres                        
                        output.append(np.max(arr_cumsum)/(np.argmax(arr_cumsum)+1))
                                                
                elif direction==-1:
                    arr_cumsum_cummin = numba_minimum_accumulate(arr_cumsum)
                    c_dd_gt_thrs = ((arr_cumsum - arr_cumsum_cummin)>thrs) & (arr_idx > c_idx_of_first_sig)
                    if np.sum(c_dd_gt_thrs) > 0: # have drawdown > thrs
                        loc_dd = np.where(c_dd_gt_thrs)[0][0]                        
                        output.append(np.min(arr_cumsum[:loc_dd])/(np.argmin(arr_cumsum[:loc_dd])+1))                        
                    elif np.sum(c_dd_gt_thrs) == 0: # not have drawdown > thres                        
                        output.append(np.min(arr_cumsum)/(np.argmin(arr_cumsum)+1))
                
            else: # if there is no sig ret
                output.append(arr_cumsum[-1] / len(arr_cumsum))
                
            
        return np.array(output)
    
    
    for thrs in [0.02, 0.04, 0.06, 0.10, 0.15]:
        i_fut_1800['ret_perday_thrs'+str(thrs).replace('.','p')] = helper_fut_1800_immret(i_fut_1800[cols_fut].values,thrs)
        

    i_fut_1800.to_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800_immret_v1p2.parquet')
        


def prepare_fut_1800_immret_v1p3():
    
    # example: 0 +1.7 -1.7 (drawdown recognized) +14 -10
    # in this example, when we get to +1.7, we also has a short signal ... 
    
    # this is the original version
    # with some modifications on the algo
    
    cols_fut = ['BarrRet_CLIP_USD_p'+str(i)+'d' for i in range(1, 21)]    
    i_fut_1800 = pd.read_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800.parquet',
                
                 columns = ['Ticker', 'T-1d', 'DataDate'] + cols_fut)
    
    @njit
    def numba_maximum_accumulate(A):
        r = np.empty(len(A))
        t = -np.inf
        for i in range(len(A)):
            t = np.maximum(t, A[i])
            r[i] = t
        return r        
    @njit
    def numba_minimum_accumulate(A):
        r = np.empty(len(A))
        t = np.inf
        for i in range(len(A)):
            t = np.minimum(t, A[i])
            r[i] = t
        return r
    
    @njit
    # it turns out that whole-day return is inferior
    # insig return replace with nan or not .. has little impact
    def helper_fut_1800_immret(matrix):
        # this outputs immediate return whose abs > thrs
                
        output = [0.0]*0
        
        for i in list(range(matrix.shape[0])):
            
            arr = matrix[i, :]
            
            # step 0 - cleanse return data
            arr[np.isnan(arr)] = 0
            arr_cumsum = np.cumsum(arr)
            
            # step 1 - decide direction
            direction = np.sign(np.mean(arr))
            if direction == 1:
                output.append(np.max(arr_cumsum)/(np.argmax(arr_cumsum)+1))
            elif direction == -1:
                output.append(np.min(arr_cumsum)/(np.argmin(arr_cumsum)+1))
            else:
                output.append(np.nan)             
            
        return np.array(output)
    
    
    
    i_fut_1800['ret_perday_v1p3'] = helper_fut_1800_immret(i_fut_1800[cols_fut].values)
        

    i_fut_1800.to_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800_immret_v1p3.parquet')
        





def prepare_fut_1800_imm20ret():
    
    # this version is too old
    
    # the old version: range(1,41), 0.02 perday, bool_insig_nan False
    
    cols_fut = ['BarrRet_CLIP_USD_p'+str(i)+'d' for i in range(1, 21)]    
    i_fut_1800 = pd.read_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800.parquet',
                                 columns = ['Ticker', 'T-1d', 'DataDate'] + cols_fut)
    
    @njit
    def numba_maximum_accumulate(A):
        r = np.empty(len(A))
        t = -np.inf
        for i in range(len(A)):
            t = np.maximum(t, A[i])
            r[i] = t
        return r        
    @njit
    def numba_minimum_accumulate(A):
        r = np.empty(len(A))
        t = -np.inf
        for i in range(len(A)):
            t = np.maximum(t, A[i])
            r[i] = t
        return r
    @njit
    def helper_fut_1800_immr
et(matrix, thrs, bool_insig_nan = False, perday = True):
        # this outputs immediate return whose abs > thrs
                
        output = [0.0]*0
        
        for i in list(range(matrix.shape[0])):
            
            arr = matrix[i, :]
            
            # step 0 - cleanse return data
            arr[np.isnan(arr)] = 0
            arr_cumsum = np.cumsum(arr)
            
            # step 1 - find the direction of the return
            c_abs_gt_thrs = np.abs(arr_cumsum) > thrs
            if c_abs_gt_thrs.sum() > 0: # if there is sig ret
                direction = np.sign(arr_cumsum[c_abs_gt_thrs][0])
                if direction==1:
                    arr_cumsum_cummax = numba_maximum_accumulate(arr_cumsum)
                    c_dd_gt_thrs = (arr_cumsum_cummax - arr_cumsum)>thrs
                    if np.sum(c_dd_gt_thrs) > 0: # have drawdown > thrs
                        loc_dd = np.where(c_dd_gt_thrs)[0][0]
                        if perday == True:
                            output.append(np.max(arr_cumsum[:loc_dd])/(np.argmax(arr_cumsum[:loc_dd])+1))
                        else: 
                            output.append(np.max(arr_cumsum[:loc_dd]))
                    elif np.sum(c_dd_gt_thrs) == 0: # not have drawdown > thres
                        if perday == True:
                            output.append(np.max(arr_cumsum)/(np.argmax(arr_cumsum)+1))
                        else:
                            output.append(np.max(arr_cumsum))
                                                
                elif direction==-1:
                    arr_cumsum_cummin = numba_minimum_accumulate(arr_cumsum)
                    c_dd_gt_thrs = (arr_cumsum - arr_cumsum_cummin)>thrs
                    if np.sum(c_dd_gt_thrs) > 0: # have drawdown > thrs
                        loc_dd = np.where(c_dd_gt_thrs)[0][0]
                        if perday == True:
                            output.append(np.min(arr_cumsum[:loc_dd])/(np.argmin(arr_cumsum[:loc_dd])+1))
                        else:
                            output.append(np.min(arr_cumsum[:loc_dd]))
                    elif np.sum(c_dd_gt_thrs) == 0: # not have drawdown > thres
                        if perday == True:
                            output.append(np.min(arr_cumsum)/(np.argmin(arr_cumsum)+1))
                        else:
                            output.append(np.min(arr_cumsum))
                
            else: # if there is no sig ret
         
       if bool_insig_nan == False:
                    if perday == True:
                        output.append(arr_cumsum[-1] / len(arr_cumsum))
                    else:
                        output.append(arr_cumsum[-1])
                elif bool_insig_nan == True:                    
                    output.append(np.nan)
                        
            
        return np.array(output)
    
    
    
    for thrs in [0.01, 0.02, 0.03, 0.04, 0.06, 0.08, 0.10, 0.15]:
        i_fut_1800['ret_perday_thrs'+str(thrs).replace('.','p')+'_insigvalue'] = helper_fut_1800_immret(i_fut_1800[cols_fut].values,thrs,bool_insig_nan=False)
        i_fut_1800['ret_perday_thrs'+str(thrs).replace('.','p')+'_insignan'] = helper_fut_1800_immret(i_fut_1800[cols_fut].values,thrs,bool_insig_nan=True)
    for thrs in [0.01, 0.02, 0.03, 0.04, 0.06, 0.08, 0.10, 0.15]:
        i_fut_1800['ret_whole_thrs'+str(thrs).replace('.','p')+'_insigvalue'] = helper_fut_1800_immret(i_fut_1800[cols_fut].values,thrs,bool_insig_nan=False,perday=False)
        i_fut_1800['ret_whole_thrs'+str(thrs).replace('.','p')+'_insignan'] = helper_fut_1800_immret(i_fut_1800[cols_fut].values,thrs,bool_insig_nan=True,perday=False)
    
    i_fut_1800.to_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800_imm21ret.parquet')
        
        




def prepare_fut_1800_immret_v2():
    
    # v2 usess zigzag to identify future returns
    
    cols_fut = ['BarrRet_CLIP_USD_p'+str(i)+'d' for i in range(0, 21)]
    cols_past = ['BarrRet_CLIP_USD_'+str(i)+'d' for i in range(1, 21)][::-1]
    i_fut_1800 = pd.read_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800.parquet',
                                 columns = ['Ticker', 'T-1d','DataDate', 'DataDate_p20d'] \
                                           + cols_past + cols_fut)
    i_fut_1800 = i_fut_1800.sort_values(['Ticker', 'DataDate'])
    
    cols_cumret = [c+'_cumret' for c in cols_past + cols_fut]
    i_fut_1800[cols_cumret] = i_fut_1800[cols_past + cols_fut].fillna(0).cumsum(axis = 1)
        
    

    # calculate zigzag for each row, in a vectorized style
    
    THRS_SET = [0.01, 0.03, 0.05]
    
    for thres in THRS_SET:
            
        mtx_cumret = i_fut_1800[cols_cumret].values
        
        mtx_vertex = np.empty(i_fut_1800[cols_cumret].shape)
        mtx_vertex[:] = np.nan
        mtx_vertex_pst = np.empty(i_fut_1800[cols_cumret].shape)
        mtx_vertex_pst[:] = np.nan
        arr_cumret_min = mtx_vertex[:,0].copy()
 
       arr_cumret_min_pst = np.zeros(i_fut_1800[cols_cumret].shape[0])
        arr_cumret_max = mtx_vertex[:,0].copy()
        arr_cumret_max_pst = np.zeros(i_fut_1800[cols_cumret].shape[0])
        arr_status = np.zeros(i_fut_1800[cols_cumret].shape[0])
        
        for i in range(len(cols_cumret)):
            
            if i == 0:
                mtx_vertex[:, 0] = mtx_cumret[:, 0].copy()
                mtx_vertex_pst[:, 0] = 0
                arr_cumret_min = mtx_cumret[:, 0].copy()
                arr_cumret_min_pst[:] = 0
                arr_cumret_max = mtx_cumret[:, 0].copy()
                arr_cumret_max_pst[:] = 0
                arr_status[:] = 0
            elif i == len(cols_cumret)-1:
                mtx_vertex[:, i] = mtx_cumret[:, i].copy()
                mtx_vertex_pst[:, i] = i
            else:
                # the conditions below are True when a vertex is recognized 
                c2 = (arr_status==0) & (mtx_cumret[:, i] - arr_cumret_min > thres) # none and up
                c2b = (arr_status==0) & (arr_cumret_max - mtx_cumret[:, i] > thres)# none and dn                  
                c3 = (arr_status==1) & (arr_cumret_max - mtx_cumret[:, i] > thres) # up and dn
                c4 = (arr_status==-1) & (mtx_cumret[:, i] - arr_cumret_min > thres)# dn and up
                
                # the conditions below are True when no vertex is recognized
                c2c = (arr_status==0) & (np.abs(arr_cumret_max - mtx_cumret[:, i]) <= thres) & (np.abs(mtx_cumret[:, i] - arr_cumret_min) <= thres)# none and none
                c1 = np.logical_not( np.logical_or.reduce((c2,c2b,c2c,c3,c4)) )
                
                # update key variable status under different conditions
                mtx_vertex[c2, i] = arr_cumret_min[c2]
                mtx_vertex_pst[c2, i] = 0
                arr_status[c2] = 1
                arr_cumret_max_pst[c2 & (arr_cumret_max < mtx_cumret[:,i])] = i
                arr_cumret_max[c2] = np.maximum(arr_cumret_max, mtx_cumret[:,i])[c2]
                
                
                mtx_vertex[c2b, i] = arr_cumret_max[c2b]
                mtx_vertex_pst[c2b, i] = 0
                arr_status[c2b] = -1
                arr_cumret_min_pst[c2b & (arr_cumret_min > mtx_cumret[:,i])] = i
                arr_cumret_min[c2b] = np.minimum(arr_cumret_min, mtx_cumret[:,i])[c2b]
                
                
                mtx_vertex[c2c, i] = mtx_vertex[c2c, i-1]
                mtx_vertex_pst[c2
c, i] = mtx_vertex_pst[c2c, i-1]
                            
                mtx_vertex[c3, i] = arr_cumret_max[c3]
                mtx_vertex_pst[c3, i] = arr_cumret_max_pst[c3]
                arr_status[c3] = -1
                arr_cumret_min_pst[c3] = i
                arr_cumret_min[c3] = mtx_cumret[c3, i]
                
                
                mtx_vertex[c4, i] = arr_cumret_min[c4]
                mtx_vertex_pst[c4, i] = arr_cumret_min_pst[c4]
                arr_status[c4] = 1
                arr_cumret_max_pst[c4] = i
                arr_cumret_max[c4] = mtx_cumret[c4, i]
                
                
                mtx_vertex[c1, i] = mtx_vertex[c1, i-1]
                mtx_vertex_pst[c1, i] = mtx_vertex_pst[c1, i-1]            
                arr_cumret_max_pst[c1 & (arr_cumret_max < mtx_cumret[:,i])] = i
                arr_cumret_max[c1] = np.maximum(arr_cumret_max, mtx_cumret[:,i])[c1]
                arr_cumret_min_pst[c1 & (arr_cumret_min > mtx_cumret[:,i])] = i
                arr_cumret_min[c1] = np.minimum(arr_cumret_min, mtx_cumret[:,i])[c1]
                
                
                    
        tt_before_pst = np.argmax(np.ma.masked_array(mtx_vertex_pst, mask=mtx_vertex_pst>20), axis = 1)
        tt_value_before = [mtx_vertex[j, i] for i, j in zip(list(tt_before_pst), list(range(len(tt_before_pst))))]
        tt_value_before = np.array(tt_value_before)
        
        tt_after_pst = np.argmin(np.ma.masked_array(mtx_vertex_pst, mask=mtx_vertex_pst<=20), axis = 1)
        tt_value_after = [mtx_vertex[j, i] for i, j in zip(list(tt_after_pst), list(range(len(tt_after_pst))))]
        tt_value_after = np.array(tt_value_after)
    
        
        i_fut_1800['futret_'+'thrs'+str(thres)+'_wholeseg'] = tt_value_after - tt_value_before
        i_fut_1800['futret_perday_'+'thrs'+str(thres)+'_wholeseg'] = i_fut_1800['futret_'+'thrs'+str(thres)+'_wholeseg'] / (tt_after_pst - tt_before_pst)
        i_fut_1800['futret_perday_'+'thrs'+str(thres)+'_wholeseg'] = i_fut_1800['futret_perday_'+'thrs'+str(thres)+'_wholeseg'].replace(np.inf,np.nan).replace(-np.inf, np.nan)
        i_fut_1800['futret_'+'thrs'+str(thres)+'_residseg'] = tt_value_after - i_fut_1800['BarrRet_CLIP_USD_p0d_cumret']
        i_fut_1800['futret_perday_'+'thrs'+str(thres)+'_residseg'] = i_fut_1800['futret_'+'thrs'+str(thres)+'_residseg'] / (tt_after_pst - 20)
        i_fut_1800['futret_perday_'+'thrs'+str(thres)+'_residseg'] = i_fut_1800['futret_perday_'+'thr
s'+str(thres)+'_residseg'].replace(np.inf,np.nan).replace(-np.inf, np.nan)
        
            
    
    i_fut_1800 = i_fut_1800[['Ticker', 'T-1d', 'DataDate', 'DataDate_p20d']+\
                            ['futret_'+'thrs'+str(t)+'_wholeseg' for t in THRS_SET]+\
                            ['futret_perday_'+'thrs'+str(t)+'_wholeseg' for t in THRS_SET]+\
                            ['futret_'+'thrs'+str(t)+'_residseg' for t in THRS_SET]+\
                            ['futret_perday_'+'thrs'+str(t)+'_residseg' for t in THRS_SET]]
    i_fut_1800.to_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800_immret_v2.parquet')
        

    


def prepare_fut_1800_immret_v2p1():
    
    # v2p1 usess zigzag to identify future returns
    # the daily return in v2p1's zigzag segment is uniform, so we have lower turnover
    
    # read data
    
    cols_fut = ['BarrRet_CLIP_USD_p'+str(i)+'d' for i in range(0, 61)]
    cols_past = ['BarrRet_CLIP_USD_'+str(i)+'d' for i in range(1, 21)][::-1]
    i_fut_1800 = pd.read_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800.parquet',
                                 columns = ['Ticker', 'T-1d', 'DataDate', 'DataDate_p80d'] \
                                           + cols_past + cols_fut)
    i_fut_1800 = i_fut_1800.sort_values(['Ticker', 'DataDate'])
    
    # fill nan with zero
    
    cols_cumret = [c+'_cumret' for c in cols_past + cols_fut]
    i_fut_1800[cols_cumret] = i_fut_1800[cols_past + cols_fut].fillna(0).cumsum(axis = 1)
        
    

    # calculate zigzag for each row, in a vectorized style
    
    THRS_SET = [0.01, 0.02, 0.04]
    
    for thres in THRS_SET:
            
        mtx_cumret = i_fut_1800[cols_cumret].values
        
        mtx_vertex = np.empty(i_fut_1800[cols_cumret].shape)
        mtx_vertex[:] = np.nan
        mtx_vertex_pst = np.empty(i_fut_1800[cols_cumret].shape)
        mtx_vertex_pst[:] = np.nan
        arr_cumret_min = mtx_vertex[:,0].copy()
        arr_cumret_min_pst = np.zeros(i_fut_1800[cols_cumret].shape[0])
        arr_cumret_max = mtx_vertex[:,0].copy()
        arr_cumret_max_pst = np.zeros(i_fut_1800[cols_cumret].shape[0])
        arr_status = np.zeros(i_fut_1800[cols_cumret].shape[0])
        
        for i in range(len(cols_cumret)):
            
            if i == 0:
                mtx_vertex[:, 0] = mtx_cumret[:, 0].copy()
                mtx_vertex_pst[:, 0] = 0
                arr_cumret_min = mtx_cumret[:, 0].copy()
                arr_cumret_min_pst[
:] = 0
                arr_cumret_max = mtx_cumret[:, 0].copy()
                arr_cumret_max_pst[:] = 0
                arr_status[:] = 0
            elif i == len(cols_cumret)-1:
                mtx_vertex[:, i] = mtx_cumret[:, i].copy()
                mtx_vertex_pst[:, i] = i
            else:
                # the conditions below are True when a vertex is recognized 
                c2 = (arr_status==0) & (mtx_cumret[:, i] - arr_cumret_min > thres) # none and up
                c2b = (arr_status==0) & (arr_cumret_max - mtx_cumret[:, i] > thres)# none and dn                  
                c3 = (arr_status==1) & (arr_cumret_max - mtx_cumret[:, i] > thres) # up and dn
                c4 = (arr_status==-1) & (mtx_cumret[:, i] - arr_cumret_min > thres)# dn and up
                
                # the conditions below are True when no vertex is recognized
                c2c = (arr_status==0) & (np.abs(arr_cumret_max - mtx_cumret[:, i]) <= thres) & (np.abs(mtx_cumret[:, i] - arr_cumret_min) <= thres)# none and none
                c1 = np.logical_not( np.logical_or.reduce((c2,c2b,c2c,c3,c4)) )
                
                # update key variable status under different conditions
                mtx_vertex[c2, i] = arr_cumret_min[c2]
                mtx_vertex_pst[c2, i] = 0
                arr_status[c2] = 1
                arr_cumret_max_pst[c2 & (arr_cumret_max < mtx_cumret[:,i])] = i
                arr_cumret_max[c2] = np.maximum(arr_cumret_max, mtx_cumret[:,i])[c2]
                
                
                mtx_vertex[c2b, i] = arr_cumret_max[c2b]
                mtx_vertex_pst[c2b, i] = 0
                arr_status[c2b] = -1
                arr_cumret_min_pst[c2b & (arr_cumret_min > mtx_cumret[:,i])] = i
                arr_cumret_min[c2b] = np.minimum(arr_cumret_min, mtx_cumret[:,i])[c2b]
                
                
                mtx_vertex[c2c, i] = mtx_vertex[c2c, i-1]
                mtx_vertex_pst[c2c, i] = mtx_vertex_pst[c2c, i-1]
                            
                mtx_vertex[c3, i] = arr_cumret_max[c3]
                mtx_vertex_pst[c3, i] = arr_cumret_max_pst[c3]
                arr_status[c3] = -1
                arr_cumret_min_pst[c3] = i
                arr_cumret_min[c3] = mtx_cumret[c3, i]
                
                
                mtx_vertex[c4, i] = arr_cumret_min[c4]
                mtx_vertex_pst[c4, i] = arr_cumret_min_pst[c4]
                arr_status[c4] = 1
                arr_cumret_max_ps
t[c4] = i
                arr_cumret_max[c4] = mtx_cumret[c4, i]
                
                
                mtx_vertex[c1, i] = mtx_vertex[c1, i-1]
                mtx_vertex_pst[c1, i] = mtx_vertex_pst[c1, i-1]            
                arr_cumret_max_pst[c1 & (arr_cumret_max < mtx_cumret[:,i])] = i
                arr_cumret_max[c1] = np.maximum(arr_cumret_max, mtx_cumret[:,i])[c1]
                arr_cumret_min_pst[c1 & (arr_cumret_min > mtx_cumret[:,i])] = i
                arr_cumret_min[c1] = np.minimum(arr_cumret_min, mtx_cumret[:,i])[c1]
                
                
                    
        tt_before_pst = np.argmax(np.ma.masked_array(mtx_vertex_pst, mask=mtx_vertex_pst>20), axis = 1)
        tt_value_before = [mtx_vertex[j, i] for i, j in zip(list(tt_before_pst), list(range(len(tt_before_pst))))]
        tt_value_before = np.array(tt_value_before)
        
        tt_after_pst = np.argmin(np.ma.masked_array(mtx_vertex_pst, mask=mtx_vertex_pst<=20), axis = 1)
        tt_value_after = [mtx_vertex[j, i] for i, j in zip(list(tt_after_pst), list(range(len(tt_after_pst))))]
        tt_value_after = np.array(tt_value_after)
    
        
        i_fut_1800['futret_'+'thrs'+str(thres)+'_wholeseg'] = tt_value_after - tt_value_before
        i_fut_1800['futret_perday_'+'thrs'+str(thres)] = i_fut_1800['futret_'+'thrs'+str(thres)+'_wholeseg'] / (tt_after_pst - tt_before_pst)
        i_fut_1800['futret_perday_'+'thrs'+str(thres)] = i_fut_1800['futret_perday_'+'thrs'+str(thres)].replace(np.inf,np.nan).replace(-np.inf, np.nan)

            
    
    i_fut_1800 = i_fut_1800[['Ticker', 'T-1d', 'DataDate']+\
                            ['futret_perday_'+'thrs'+str(t) for t in THRS_SET]]
                            
    i_fut_1800.to_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800_immret_v2p1.parquet')
        
    
    
    
    
def prepare_fut_3000():
    
    
    # get universe 
    
    i_uni_3000 = get_sql('''select datadate as [T-1d], Ticker, cn_index
                         from cndbprod.dbo.universe_t3000_cn_gem3l''')
    i_uni_3000 = i_uni_3000.drop_duplicates(subset=['Ticker','T-1d'],keep='last')
    i_uni_3000 = i_uni_3000[['T-1d', 'Ticker', 'cn_index']]
    
    
    # get calendar
    
    i_cal = get_sql('''select distinct tradedate_next as DataDate from cndbprod.dbo.calendar_dates_cn
                    order by tradedate_next''')
    i_cal['T-1d'] = i_cal['DataDate'].shift()
    i_cal['T-2d'] = i_cal['DataDate'].shift(2
)
    for n in range(1, 121):
        i_cal['DataDate_p'+str(n)+'d'] = i_cal['DataDate'].shift(-n)
    i_cal = i_cal.dropna()
    
    # get barra 
    # tk mapping assume datadate = T-0d here ,just to be conservative
    
    i_tk_map = get_sql('''select sedol, ric, DataDate
                       from cndbprod.dbo.IMPACT_CN_MAPPING
                       order by datadate ''')
    i_tk_map = i_tk_map[['sedol','ric','DataDate']]
    
    i_barra = get_sql('''select datadate as [T-2d], sedol, name, 
                      [srisk%] as SRISK, BETA, MOMENTUM, SIZE, EARNYILD, RESVOL, 
                      GROWTH, DIVYILD, BTOP, LEVERAGE, SIZENL, LIQUIDTY  
                      from CNDBPROD.dbo.BARRA_GEM3L_CN_RSK 
                      where DataDate >= '20150101'
                      order by datadate
                      ''')
    i_barra_s2 = i_barra.merge(i_cal[['T-2d','DataDate']],on=['T-2d'],how='left')
    i_barra_s2 = i_barra_s2.dropna(subset = ['DataDate'])
    i_barra_s2 = i_barra_s2.sort_values('DataDate')
    i_barra_s2 = pd.merge_asof(i_barra_s2, i_tk_map, on = 'DataDate', by ='sedol')
    i_barra_s2['Ticker'] = i_barra_s2['ric'].str.split('.').str[0]
    i_barra_s2 = i_barra_s2.dropna(subset = ['Ticker'])
    i_barra_s2 = i_barra_s2.drop_duplicates(subset = ['Ticker', 'DataDate'], keep = 'last')
    i_barra_s2 = i_barra_s2[['DataDate','Ticker', 
                             'SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 
                             'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']]
    
    i_barra = None
    cols_f = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 
              'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
   
    
    
    
    # get wind 62 industries
    
    i_wind_ind = get_sql('''select DataDate as [T-1d], Ticker, w_ind 
                         from CNDBPROD.dbo.[UNIVERSE_ALL_CN_GEM3L]  
                         order by DataDate''')
    i_wind_ind_dummy = pd.get_dummies(i_wind_ind['w_ind'])
    i_wind_ind_dummy.columns = ['wd'+str(c) for c in i_wind_ind_dummy.columns.tolist()]
    
    i_wind_ind = pd.concat([i_wind_ind, i_wind_ind_dummy], axis = 1)
    i_wind_ind = i_wind_ind.drop(columns = ['w_ind'])
    i_wind_ind = i_wind_ind.drop_duplicates(subset=['Ticker','T-1d'], keep = 'last') 
    
    cols_i = i_wind_ind_dummy.columns.tolist()
    i_wind_ind = i_wind_ind[['Ticker', 'T-1d']+cols_i]
    
    
    # avgVadj, avgPVadj, avgPVadj_USD, 
    
 
   i_adv = get_sql('''select datadate as [T-1d], Ticker, avgPVadj, avgPVadj_USD
                    from [CNDBPROD].[dbo].trth_adv_cn
                    order by datadate''')
    i_adv['Ticker'] = i_adv['Ticker'].str.split('.').str[0]
    i_adv = i_adv.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_adv = i_adv[['Ticker', 'T-1d', 'avgPVadj', 'avgPVadj_USD']]
    
    # raw return 
    
    i_ret = get_sql_wind('''select trade_dt as [T-1d], s_info_windcode as Ticker,
                         s_dq_adjclose / s_dq_adjpreclose - 1 as [RawRet-1d]
                         from wind_prod.dbo.ashareeodprices 
                         where trade_dt>='20150101' ''')
    i_ret['Ticker'] = i_ret['Ticker'].str.split('.').str[0]
    i_ret['T-1d'] = pd.to_datetime(i_ret['T-1d'], format = '%Y%m%d')    
    i_ret['RawRet-1d'] = i_ret['RawRet-1d'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
    i_ret = i_ret.drop_duplicates(subset=['Ticker', 'T-1d'], keep = 'last')
    i_ret = i_ret[['Ticker', 'T-1d', 'RawRet-1d']]
    
    
    # combine
    
    icom = i_uni_3000.merge(i_cal, on = ['T-1d'], how = 'left')
    
    icom = icom.merge(i_ret, on = ['Ticker', 'T-1d'], how = 'left')    
    
    icom = icom.dropna(subset=['DataDate'])
    icom = icom.sort_values('DataDate')        
    icom = pd.merge_asof(icom, i_barra_s2, on = ['DataDate'], by =['Ticker'])
    icom = pd.merge_asof(icom, i_wind_ind, on = ['T-1d'], by =['Ticker'])
    icom = icom.sort_values('T-1d')    
    icom = pd.merge_asof(icom, i_adv, on = ['T-1d'], by =['Ticker'])
    
    icom = icom.sort_values(['Ticker', 'DataDate'])
        
    # calculate residual return
    
    icom['clip'] = icom['avgPVadj_USD'].apply(lambda x: min(x*0.01, 1e6))
    icom['BarrRet_CLIP_USD-1d'] = icom.groupby('T-1d')[cols_i + cols_f + ['RawRet-1d', 'clip']].apply(lambda x: orthogonalize_cn_v3(x['RawRet-1d'], x[cols_f], x[cols_i], x['clip'])).values
    
    for n in range(1,121):
        # the immediate return for the signal on the morning of DataDate
        # has [T-1d] == DataDate+1d
        icom = icom.merge(icom[['Ticker', 'T-1d', 'BarrRet_CLIP_USD-1d']]\
                              .rename(columns = {'T-1d':'DataDate_p'+str(n)+'d', 
                                                 'BarrRet_CLIP_USD-1d':'BarrRet_CLIP_USD_p'+str(n)+'d'}),
                          on = ['Ticker', 'DataDate_p'+str(n)+'d'], how = 'left')
        
    
    icom[['T-1d', 'Ticker', 'DataDate',
            'DataDate_p1d', 'D
ataDate_p5d', 'DataDate_p10d', 'DataDate_p20d', 'DataDate_p40d',
            'DataDate_p80d','DataDate_p120d',
            'BarrRet_CLIP_USD-1d']+\
         ['BarrRet_CLIP_USD_p'+str(i)+'d' for i in range(1, 121)] ]\
        .to_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_3000.parquet')
    


def draw_pnl_plot(s):
    
    s['pos'] = s['opt_shr']*s['Price']
    s['trdd'] = s['opt_shr']*s['Price'] - s['opt_shr_old']*s['Price-1d']
    s['abstrdd'] = abs(s['trdd'])
    s['gmv'] = abs(s['opt_shr'] * s['Price'])
    
    totgmv = s.groupby('DataDate')['gmv'].sum().mean()    
    to = np.round(s['abstrdd'].sum() / s['gmv'].sum() * 100)
    
    s['stamp'] = 0.0003587
    condition = s['trdd'] < 0
    s.loc[condition,'stamp'] = 0.0013587
    
    s['stampcost'] = s['stamp'] * s['abstrdd']
    s['instcost'] = 0.16 * s['spread'] * s['abstrdd']
    s['transcost'] = 0.068 * ((s['volatility']/np.sqrt(252))**0.6) * ((s['abstrdd']/s['avgPVadj'])**0.5) * s['abstrdd']
    s['permcost'] = 18.9 * ((s['volatility']/np.sqrt(252))**2) * ((s['abstrdd']/s['avgPVadj'])) * s['abstrdd']
    
    s['borrowcost'] = 0
    condition = s['opt_shr'] < 0
    s.loc[condition,'borrowcost'] = - s.loc[condition,'opt_shr'] * s['Price'] * 0.07 / 252
    
    s['rel_pnl'] = s['pos'] * s['AdjRet+1d'] 
    s['rel_pnl_atc'] = s['pos'] * s['AdjRet+1d'] - s['stampcost'] - s['instcost'] - s['transcost'] - s['permcost'] - s['borrowcost']
    
    ret = s.groupby('T+1d')['rel_pnl','rel_pnl_atc'].sum()
    ret = ret.reset_index()
    ret = ret.dropna()
    ret['cumpnl'] = ret['rel_pnl'].cumsum()
    ret['cumpnl_atc'] = ret['rel_pnl_atc'].cumsum()

    T = ret['cumpnl_atc'].tolist()
    Tmax = max([T[0],0])
    Tmin = min([T[0],0])
    mdw = Tmax-Tmin
    for i in range(1,len(T)):
        if T[i] < T[i-1]:
            Tmax = max([T[i-1],Tmax])
            Tmin = T[i]
            mdw = max([Tmax-Tmin,mdw])

    mdw = np.round(mdw/1e6,2)

    sr_pnl_bc = np.round(ret['rel_pnl'].mean() / ret['rel_pnl'].std() * np.sqrt(252),2)
    sr_pnl_ac = np.round(ret['rel_pnl_atc'].mean() / ret['rel_pnl_atc'].std() * np.sqrt(252),2)
    
    mean_ret_bc = np.round( (s['rel_pnl'].sum() / s['gmv'].sum())*1e4,2)
    mean_ret_ac = np.round( (s['rel_pnl_atc'].sum() / s['gmv'].sum())*1e4,2)
  
    ept = np.round( (s['rel_pnl'].sum() / s['abstrdd'].sum())*1e4,2)

    temp1 = s.groupby('Ticker')['rel_pnl'].sum()
    temp1 = temp1.reset_index()
    temp2 = s.groupby('Ticker')['abstrdd'].sum()
    temp2 = temp2.reset_ind
ex()
    temp3 = s.groupby('Ticker')['spread'].mean()
    temp3 = temp3.reset_index()
    
    temp = pd.merge(temp1, temp2, on=['Ticker'], how='inner')
    temp = pd.merge(temp, temp3, on=['Ticker'], how='inner')
    
    temp['spread_buk'] = pd.qcut(temp['spread'],10,labels=range(1,11))
    temp = temp.groupby('spread_buk').agg({'rel_pnl':'sum','abstrdd':'sum','spread':'mean'})
    temp['ept_spd'] = temp['rel_pnl'] / temp['abstrdd'] / temp['spread']
    ept_spd1 = np.round(temp['ept_spd'].mean(),2)
    
    temp = pd.merge(temp1, temp2, on=['Ticker'], how='inner')
    temp = pd.merge(temp, temp3, on=['Ticker'], how='inner')
    temp['ept_spd'] = temp['rel_pnl'] / temp['abstrdd'] / temp['spread']
    temp['ept_spd'] = temp['ept_spd'] * (temp['abstrdd'] / temp['abstrdd'].sum())
    ept_spd2 = np.round(temp['ept_spd'].sum(),2)
    
    ret = ret.set_index('T+1d')
    
    fig1 = plt.figure(figsize=(10,8))
    ax1 = fig1.add_subplot(211)
    ax1.plot(ret['cumpnl'])
    ax1.plot(ret['cumpnl_atc'])

    ax1.grid()
    ax1.set_ylabel('PNL', fontsize = 16)
    ax1.set_xlabel('Date',fontsize = 16)
    
    ax1.text(0.01, 0.87, 'Annualized Sharpe: ' + str(sr_pnl_bc) + '(bc), ' +  str(sr_pnl_ac) + ' (ac)', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.81, 'Daily Return on GMV: ' + str(mean_ret_bc) + ' bps (bc), ' + str(mean_ret_ac) + ' bps (ac)', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.75, 'Edge Per Trade: ' + str(ept) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.69, 'Edge Per Trade Per Spread: ' + str(ept_spd1) + ' | ' + str(ept_spd2), verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.63, 'Max Drawdown: $' + str(mdw) + 'mm', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )

    gmvlong = s[ s['pos'] > 0].groupby('DataDate')['gmv'].sum()
    gmvlong = gmvlong.reset_index()
    gmvlong.columns = ['DataDate','long']
    gmvlong = gmvlong.set_index('DataDate')
    gmvshort = s[ s['pos'] < 0].groupby('DataDate')['gmv'].sum()
    gmvshort = gmvshort.reset_index()
    gmvshort.columns = ['DataDate','short']
    gmvshort = gmvshort.set_index
('DataDate')

    ax2 = fig1.add_subplot(212)
    gmv = pd.concat([gmvlong,gmvshort],axis=1)
    ax2.plot(gmv)
    
    ax2.grid()
    ax2.set_ylabel('AUM', fontsize = 16)

    ax2.text(0.01, 0.93, 'Avg Long Size: ' + str(round(gmvlong['long'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.87, 'Avg Short Size: ' + str(round(gmvshort['short'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.81, 'Total Size: ' + str(round(totgmv/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.75, 'Turnover: ' + str(to) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    
    




def scraper():
    
    i_df = []
        
    from sqlalchemy import create_engine
    import urllib
    
    engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDB;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
    
    i_df.to_sql('cninfo_ed_calendar', con=engine, if_exists  = 'append', index = False)
    
    
    ### selenium / Firefox
    import selenium    
    from selenium.webdriver import Firefox
    from selenium.webdriver.firefox.options import Options
    opts = Options()
    opts.headless = True
    selenium.webdriver.DesiredCapabilities.FIREFOX['proxy'] = {
    "httpProxy": 'proxy.mlp.com:3128', "ftpProxy": 'proxy.mlp.com:3128',
    "sslProxy": 'proxy.mlp.com:3128', "proxyType": "MANUAL"}
    driver = Firefox(executable_path='/home/thzhang/Downloads/geckodriver',options=opts)
    
    
    ### slenium / Firefox (a more stabe version to fight user/pw verification)
        
    from seleniumwire import webdriver as webdriver_wire
    ff_options = webdriver_wire.FirefoxOptions()
    ff_options.add_argument('--headless')
    options = {'proxy': {'http': 'http://thzhang:Citadel190430!@proxy.mlp.com:3128',
        'https': 'https://thzhang:Citadel190430!@proxy.mlp.com:3128'}, 'headless': True}
    driver = webdriver_wire.Firefox(seleniumwire_options=options, executable_path='/home/thzhang/Downloads/geckodriver', options=ff_options)
    
    # note: visit HTTPS might still trigger pop-up alerts to ent
er credentials for proxy. The code below kills it.
    driver.get('https://thzhang:Citadel190430!@comein.cn/roadshow/home/54058')    
    
    
    # regular 
    
    import requests
    
    url = ''
    header = {}
    proxies = {'http':'http://svc_pm_summit_dev:Feng_001!@proxy.mlp.com:3128',
           'https':'https://svc_pm_summit_dev:Feng_001!@proxy.mlp.com:3128'}
    r = requests.post(url, headers=header, proxies=proxies, verify = False)
    return r

    


