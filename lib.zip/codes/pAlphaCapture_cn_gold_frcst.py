﻿#$%^&* pAlphaCapture_cn_gold_frcst.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 30 04:38:23 2022

@author: thzhang
"""


import yz.util as yu 
import pWIND_util as pw

import pandas as pd
import numpy as np


# jin gu has limited history: earliest entrytime is 2021.05
# our goal is to ... predict jin gu?
# how? spot check individual brokers .. how did they build jin gu?



### sd

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])

### ed

i_ed = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pSuntime_util_prepare_earn_cal.parquet')


### prize

i_cxf = yu.get_sql('''select * from suntime_prod.dbo.der_new_fortune_author where report_year>=2017''')
i_cxf = i_cxf[i_cxf['prize_awarded']<=1]
i_cxf['datadate'] = pd.to_datetime(i_cxf['entrytime'].dt.date)
i_cxf['first_author_name'] = i_cxf['author']
i_cxf['flg_xcf'] = 1
i_cxf = i_cxf[['organ_id','first_author_name','datadate','flg_xcf']]
i_cxf = i_cxf.sort_values('datadate')


### suntime reports

i_rpt = yu.get_sql('''select * from SUNTIME_PROD.dbo.rpt_forecast_stk where create_date>'2017-10-01' ''')
i_rpt = i_rpt[i_rpt['attention'].str.contains('首')]
c_sh = i_rpt['stock_code'].str[0].isin(['6'])
c_sz = i_rpt['stock_code'].str[0].isin(['0','3'])
i_rpt.loc[c_sh,'ticker'] = i_rpt.loc[c_sh,'stock_code'] + '.SH'
i_rpt.loc[c_sz,'ticker'] = i_rpt.loc[c_sz,'stock_code'] + '.SZ'



### ugdg


i_ugdg = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_st_ugdg_per_report.parquet')

i_ugdg = i_ugdg[~i_ugdg['report_type'].isin([21, 28, 98])]

i_ugdg = i_ugdg.sort_values(['ticker','report_period','organ_id','datadate'])



s_ugdg = []

for dt in pd.date_range(start = '2017-01-01', end = '2022-06-30'):
    print(dt.strftime('%Y%m%d'), end=',')
    
    t_ugdg = i_ugdg[(i_ugdg['datadate']<=dt)&(i_ugdg['datadate']>=dt-pd.to_timedelta('31  days'))]
    
    t_ugdg_tk_maxdd = t_ugdg.groupby(['ticker','organ_id'])['create_date'].max().reset_index()
    t_ugdg_tk_maxdd = t_ugdg_tk_maxdd.merge(t_ugdg,on=['ticker','organ_id','create_date'],how='inner')
    
    t_ugdg_tk_maxdd['flg_or_up'] = np.sign(t_ugdg_tk_maxdd['frcst_or'] - t_ugdg_tk_maxdd['frcst_or_prev'])
    t_ugdg_tk_maxdd['flg_np_up'] = np.sign(t_ugdg_tk_maxdd['frcst_np'] - t_ugdg_tk_maxdd['frcst_np_prev'])
    t_ugdg_tk_maxdd['flg_eps_up'] = np.sign(t_ugdg_tk_maxdd['frcst_eps'] - t_ugdg_tk_maxdd['frcst_eps_prev'])
    t_ugdg_tk_maxdd['flg_gg_up'] = np.sign(t_ugdg_tk_maxdd['ggrate'] - t_ugdg_tk_maxdd['ggrate_prev'])
        

    t_ugdg_tk_maxdd['sgn_flg_up'] = np.sign(t_ugdg_tk_maxdd[['flg_or_up','flg_np_up','flg_eps_up','flg_gg_up']].sum(axis=1))
    t_ugdg_tk_maxdd['max_flg_up'] = t_ugdg_tk_maxdd[['flg_or_up','flg_np_up','flg_eps_up','flg_gg_up']].max(axis=1)
        
    t_ugdg_tk_maxdd['datadate'] = dt
    
    s_ugdg.append(t_ugdg_tk_maxdd[['datadate','ticker','organ_id','sgn_flg_up']])
    
s_ugdg = pd.concat(s_ugdg, axis=0)




### jin gu 

# report tytpe


i_gold = pd.read_parquet(r'S:\Data\China Data Hunt\cache\gold.parquet')

i_gold['entrydate'] = pd.to_datetime(i_gold['entrytime'].dt.date)
i_gold['create_date_p1d'] = pd.to_datetime(i_gold['create_date']) + pd.to_timedelta('1 day')
i_gold['create_date_p7d'] = pd.to_datetime(i_gold['create_date']) + pd.to_timedelta('7 day')
i_gold['datadate'] = i_gold[['create_date_p1d','entrydate']].max(axis=1)
i_gold['datadate'] = i_gold['create_date_p1d']

i_gold['first_author_name'] = i_gold['author_name'].str.split(',').str[0]
i_gold = i_gold.sort_values('datadate')
i_gold = pd.merge_asof(i_gold, i_cxf, by=['first_author_name','organ_id'], on='datadate', tolerance=pd.to_timedelta('1460 days'))

c_sh = i_gold['stock_code'].str[1].isin(['6'])
c_sz = i_gold['stock_code'].str[1].isin(['0','3'])
i_gold.loc[c_sh, 'ticker'] = i_gold.loc[c_sh, 'stock_code'] + '.SH'
i_gold.loc[c_sz, 'ticker'] = i_gold.loc[c_sz, 'stock_code'] + '.SZ'

i_gold['flg_gold'] = 1

# filter: only periodic jin gu
i_gold = i_gold[i_gold['report_type'].isin([7, 8])]
# filter: only shenwan hongyuan
#!i_gold = i_gold[i_gold['organ_id']==15467]

# filter
# 7's sharpe is better than 8
# donguw,xingye are the best
# analysts with prizes perform better

#o_gold = i_gold[i_gold['flg_xcf']==1].groupby(['ticker', 'datadate'])['flg_gold'].sum().reset_index()
o_gold = i_gold.groupby(['ticker', 'datadate'])['flg_gold'].sum().reset_index()
o_gold = o_gold.sort_values('datadate')



### jin gu past rec  

o_re_tk = []

for org in i_gold['organ_id'].unique().tolist():
    print(org, end=',')
    t_gold = i_gold[i_gold['organ_id']==org]
    t_gold = t_gold.sort_values('create_date').reset_index(drop = True)
    
    dts = t_gold['create_date'].drop_duplicates().tolist()
    for i, dt in enumerate(dts):
        if i == 0:
            pass
        else:
            t_gold_dt_curr = t_gold[t_gold['create_date']==dt]
            t_gold_dt_prev = t_gold[t_gold['create_date']==dts[i-1]]
            s_re_tk = list(set(t_gold_dt_curr.ticker).intersection(set(t_gold_dt_prev.ticker)))
     
       s_re_tk = pd.DataFrame({'ticker': s_re_tk, 
                                    'datadate':t_gold_dt_curr['create_date'].max(),
                                    'org_id':org})
            o_re_tk.append(s_re_tk)

o_re_tk = pd.concat(o_re_tk, axis=0)
o_re_tk['flg_re'] = 1
o_re_tk = o_re_tk.groupby(['ticker', 'datadate'])['flg_re'].sum().reset_index()
o_re_tk['datadate'] = pd.to_datetime(o_re_tk['datadate'])
o_re_tk = o_re_tk.sort_values('datadate')



### jingu forecast
# per org_id on 23rd: if there was ugdg, new coverage, 

o_frcst = []

for i,r in i_gold[['organ_id','create_date']].drop_duplicates().iterrows():
    
    print(i, end=',')
    
    c_organ_id = r['organ_id']
    c_datadate = pd.to_datetime(r['create_date'])
        
    # get ugdg
    t_ugdg = s_ugdg[(s_ugdg['datadate']==c_datadate)&(s_ugdg['organ_id']==c_organ_id)]
    t_ugdg = t_ugdg[t_ugdg['sgn_flg_up']>0]
    
    # get first coverage
    t_first = i_rpt[(i_rpt['entrytime']<=c_datadate)&(i_rpt['create_date']>=c_datadate-pd.to_timedelta('31 days'))]
    t_first = t_first[t_first['organ_id']==c_organ_id]
    
    # get actual gold
    t_gold = i_gold[(i_gold['organ_id']==c_organ_id)&(i_gold['create_date']==c_datadate.strftime('%Y-%m-%d'))]
    t_gold['flg_actual_gold'] = 1
    t_gold = t_gold[['ticker', 'flg_actual_gold']]
    
    # output
    s_frcst = pd.DataFrame({'ticker':list(set(t_ugdg['ticker'].tolist()+t_first['ticker'].tolist())),
                            'gold_date':c_datadate,
                            'datadate':c_datadate-pd.to_timedelta('7 days')})
    s_frcst = s_frcst.merge(t_gold, on = ['ticker'], how = 'left')
    o_frcst.append(s_frcst)

o_frcst = pd.concat(o_frcst, axis=0)
o_frcst['flg_frcst'] = 1

o_frcst_s2 = o_frcst.groupby(['ticker', 'datadate', 'gold_date'])['flg_actual_gold','flg_frcst'].sum().reset_index()



### combine 2K - reappearance + frcst

icom = i_sd.merge(o_gold, on = ['ticker', 'datadate'], how = 'left')
icom = icom.rename(columns = {'flg_gold': 'flg_gold_event'})
icom = icom.sort_values('datadate')
icom = pd.merge_asof(icom, o_gold, by='ticker', on='datadate', tolerance=pd.to_timedelta('10 days'))
icom = pd.merge_asof(icom, o_re_tk, by='ticker', on='datadate', tolerance=pd.to_timedelta('10 days'))
icom = pd.merge_asof(icom, o_frcst, by='ticker', on='datadate', tolerance=pd.to_timedelta('10 days'))
icom = icom.merge(i_ed, on = ['ticker','datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])


### re-appearance jin g
u as an event

icom['sgnl'] = np.nan
icom.loc[icom['flg_re']==1, 'sgnl'] = 1
#icom['sgnl'] = icom.groupby('ticker')['sgnl'].bfill(limit=5)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-12-31'))].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.08 / -1.08


### jin gu as an event, excep re-appearing jin gu

icom['sgnl2'] = np.nan
icom.loc[(icom['flg_re']!=1)&(icom['flg_gold']==1), 'sgnl2'] = 1
#icom['sgnl'] = icom.groupby('ticker')['sgnl'].bfill(limit=5)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-12-31'))].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.08 / -1.08




icom['sgnl2'] = np.nan
icom.loc[(icom['flg_gold']==1), 'sgnl2'] = 1
#icom['sgnl'] = icom.groupby('ticker')['sgnl'].bfill(limit=5)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-12-31'))].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.08 / -1.08


### forecasted jin gu


icom['sgnl3'] = np.nan
icom.loc[(icom['flg_frcst']==1)&(icom['gold_date']<=icom['datadate']), 'sgnl3'] = 1
#icom['sgnl'] = icom.groupby('ticker')['sgnl'].bfill(limit=5)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-12-31'))].\
            dropna(subset=['sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.56 / -6.19

