﻿#$%^&* scraper_yuyuepilu.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat Apr 17 07:10:02 2021

@author: thzhang
"""


import pandas as pd
import numpy as np

import datetime
import requests
proxies = {'http':'http://proxy.mlp.com:3128','https':'https://proxy.mlp.com:3128'} 

from io import StringIO
import json


# this scrapes 


###############################################################################
### CNINFO
###############################################################################


# Here are all of our headers
headers_cninfo = {
    'Accept': '*/*',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-US,en;q=0.9',
    'Content-Length': '107',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Host': 'www.cninfo.com.cn',
    'Origin': 'http://www.cninfo.com.cn',
    'Proxy-Connection': 'keep-alive',
    'Referer': 'http://www.cninfo.com.cn/new/commonUrl?url=data/yypl',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
}

# form data for fetching the report periods
data_report_period = {'rows':'4'}

# get report_periods
url_report_period = "http://www.cninfo.com.cn/new/information/getSelectData"
response_report_period = requests.post(url=url_report_period, data=data_report_period, headers=headers_cninfo, proxies=proxies, verify = False)
i_df_report_period = pd.DataFrame(response_report_period.json())
i_df_report_period = i_df_report_period.sort_values(['value0'],ascending = False)
list_report_period = i_df_report_period['value0'].tolist()[:2]

# scrape 

for period in list_report_period:
    
    data = {
    'sectionTime':period,
    'firstTime':'',
    'lastTime':'',
    'market':'szsh',
    'stockCode':'',
    'orderClos':'',
    'isDesc':'',
    'pagesize':'10000',
    'pagenum':'1'
    }
    
    url = "http://www.cninfo.com.cn/new/information/getPrbookInfo"
    response = requests.post(url, data=data, headers=headers_cninfo, proxies=proxies, verify = False)
    i_json = response.json()
    i_df = pd.DataFrame(i_json['prbookinfos'])
    
    i_df = i_df[i_df['seccode'].str[0].isin(['0','3','6'])]
    t_sz = i_df['seccode'].str[0].isin(['0','3'])
    i_df.loc[t_sz, 'ticker'] = i_df.loc[t_sz, 'seccode']+'.SZ'
    t_sh = i_df['seccode'].str[0].isin(['6'])
    i_df.loc[t_sh, 'ticker'] = i_df.loc[t_sh, 'seccode']+'.SH'
    i_df['secname'] = i_df['secname'].str.replace
(' ','')
    i_df = i_df.drop(columns = ['orgId'])
    i_df['scrape_ts_est'] = datetime.datetime.today()
    i_df['scrape_ts_est'] = i_df['scrape_ts_est'].dt.tz_localize('US/Eastern')
    i_df['scrape_ts_cn'] = i_df['scrape_ts_est'].dt.tz_convert('Asia/Shanghai')
    i_df['scrape_ts_cn'] = i_df['scrape_ts_cn'].dt.tz_localize(None)
    i_df['datadate'] = i_df['scrape_ts_cn'].dt.date
    i_df = i_df.rename(columns={'f001d_0102':'report_period',
                                'f002d_0102':'initial_date',
                                'f003d_0102':'changed1_date',
                                'f004d_0102':'changed2_date',
                                'f005d_0102':'changed3_date',
                                'f006d_0102':'actual_date'
                                })
    for c in ['changed1_date','changed2_date','changed3_date','actual_date']:
        i_df[c] = i_df[c].replace('',np.nan)
        
    i_df['final_scheduled_date'] = i_df['changed3_date']
    c_isnull = i_df['final_scheduled_date'].isnull()
    i_df.loc[c_isnull, 'final_scheduled_date'] = i_df.loc[c_isnull, 'changed2_date']
    c_isnull = i_df['final_scheduled_date'].isnull()
    i_df.loc[c_isnull, 'final_scheduled_date'] = i_df.loc[c_isnull, 'changed1_date']
    c_isnull = i_df['final_scheduled_date'].isnull()
    i_df.loc[c_isnull, 'final_scheduled_date'] = i_df.loc[c_isnull, 'initial_date']
    
    i_df.to_parquet()
