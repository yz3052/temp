﻿#$%^&* pFlow_cn_hk_duration.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 21 16:26:01 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import datetime

# this suggests : if duration of high-bb holding is long, we don't get better returns. 
# The return goes to 0 as holding period increases/



### sd


i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['ticker', 'datadate'])



### hk bb

i_bb = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\prepare_northbound_holding_bb.parquet')
i_bb = i_bb.groupby(['datadate_p1d', 'ticker'])['bb_shares'].sum().reset_index()


### combine

icom = i_sd.merge(i_bb, on = ['ticker', 'datadate_p1d'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['pctOfSO'] = icom['bb_shares'] / icom['FLOAT_l1d']
icom['pctOfSO_bk'] = icom.groupby('datadate')['pctOfSO'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['pctOfSO_rk'] = icom.groupby('datadate')['pctOfSO'].apply(yu.uniformed_rank)

yu.create_cn_3x3(icom, ['pctOfSO_bk'], 'pctOfSO')

icom['flg_bb_isin_topquin'] = 0
icom.loc[icom['pctOfSO_rk']>0.2, 'flg_bb_isin_topquin'] = 1

icom['cnt_bb_isin_topquin_t1q'] = icom.groupby('ticker').rolling(datetime.timedelta(days=91),on='datadate')['flg_bb_isin_topquin'].sum().values
icom['cnt_bb_isin_topquin_t1q_bk'] = icom.groupby('datadate')['cnt_bb_isin_topquin_t1q'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom[icom['pctOfSO_rk']>0.2], ['cnt_bb_isin_topquin_t1q_bk'], 'cnt_bb_isin_topquin_t1q') # -6 +6 +4 +2 0
