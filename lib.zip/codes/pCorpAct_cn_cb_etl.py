﻿#$%^&* pCorpAct_cn_cb_etl.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 18 14:50:25 2022

@author: thzhang
"""



import requests
import json
import pandas as pd
import random

# this is one-time scraper that gets CB announcement data from SSE and SZSE


proxies = {'http':'http://thzhang:Citadel881012@@proxy.mlp.com:3128',
           'https':'https://thzhang:Citadel881012@@proxy.mlp.com:3128'}


### SH
# http://www.sse.com.cn/disclosure/listedinfo/announcement/


header = {'Accept': '*/*',
          'Accept-Encoding': 'gzip, deflate',
          'Accept-Language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
          'Cookie': 'yfx_c_g_u_id_10000042=_ck21021913245814079982015937919; VISITED_STOCK_FUND_CODE=%5B%22600000%22%5D; VISITED_MENU=%5B%228734%22%2C%228537%22%2C%228446%22%2C%229055%22%2C%2210883%22%2C%228363%22%2C%228457%22%2C%228454%22%2C%228619%22%2C%228527%22%2C%228317%22%5D; VISITED_COMPANY_CODE=%5B%22600612%22%2C%22603605%22%2C%22600000%22%2C%22600019%22%2C%22603002%22%5D; VISITED_STOCK_CODE=%5B%22600612%22%2C%22600000%22%2C%22603605%22%2C%22600019%22%2C%22603002%22%5D; seecookie=%5B600612%5D%3A%u8001%u51E4%u7965%2C%u8BC1%u76D1%u4F1A%u884C%u4E1A%2C%5B603605%5D%3A%u73C0%u83B1%u96C5%2C%5B600000%5D%3A%u6D66%u53D1%u94F6%u884C%2C%5B600019%5D%3A%u5B9D%u94A2%u80A1%u4EFD%2C%5B603002%5D%3A%u5B8F%u660C%u7535%u5B50; gdp_user_id=gioenc-edc69gb2%2C3768%2C5511%2C9edc%2Cag3ga2b72044; ba17301551dcbaf9_gdp_session_id=3bb6739e-5366-49c2-a0fd-9098e7e2fb6a; BCSI-CS-8eb227b2413a60e4=2; BCSI-CS-a936f1a83c02d08a=2; yfx_f_l_v_t_10000042=f_t_1660068921450__r_t_1666102053788__v_t_1666118822461__r_c_57; ba17301551dcbaf9_gdp_session_id_3bb6739e-5366-49c2-a0fd-9098e7e2fb6a=true',
          'Host': 'query.sse.com.cn',
          'Proxy-Connection': 'keep-alive',
          'Referer': 'http://www.sse.com.cn/',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36'}

dt_range =  ['2016-12-01' ,'2017-02-01', '2017-04-01', '2017-06-01', '2017-08-01', '2017-10-01',
             '2017-12-01' ,'2018-02-01', '2018-04-01', '2018-06-01', '2018-08-01', '2018-10-01',
             '2018-12-01' ,'2019-02-01', '2019-04-01', '2019-06-01', '2019-08-01', '2019-10-01',
             '2019-12-01' ,'2020-02-01', '2020-04-01', '2020-06-01', '2020-08-01', '2020-10-01',
             '2020-12-01' ,'2021-02-01', '2021-04-01', '2021-06-01', '2021-08-01', '2021-10-01',
             '2021-12-01' ,'2022-02-01', '2022-04-
01', '2022-06-01', '2022-08-01', '2022-10-01']


o_df = []

for i in range(1, len(dt_range)):
    print (i)
    r = requests.get('http://query.sse.com.cn/commonQuery.do?jsonCallBack=jsonpCallback50798201&isPagination=true&pageHelp.pageSize=10000&pageHelp.cacheSize=1&type=inParams&sqlId=COMMON_PL_SSGSXX_ZXGG_L&START_DATE={0}&END_DATE={1}&SECURITY_CODE=&TITLE=&BULLETIN_TYPE=22&pageHelp.pageNo=1&pageHelp.beginPage=1&pageHelp.endPage=1&_=1666118822512'.format(dt_range[i-1],dt_range[i]),
                     proxies = proxies, headers = header)
    
    r1 = r.content[22:-1]
    r1 = r1.decode('utf8')
    r2 = json.loads(r1)

    t_df = pd.DataFrame(r2['result'])
    o_df.append(t_df)

cb_announcement = pd.concat(o_df, axis = 0)
cb_announcement.to_parquet(r'S:\TZ\China Data Hunt\cache\pCorpAct_cn_cb_etl_sse_announcement.parquet')



### SZ
# http://www.szse.cn/disclosure/listed/notice/index.html


header = {'Accept': 'application/json, text/javascript, */*; q=0.01',
          'Accept-Encoding': 'gzip, deflate',
          'Accept-Language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
          'Content-Length': '105',
          'Content-Type': 'application/json',
          'Host': 'www.szse.cn',
          'Origin': 'http://www.szse.cn',
          'Proxy-Connection': 'keep-alive',
          'Referer': 'http://www.szse.cn/disclosure/listed/notice/index.html',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
          'X-Request-Type': 'ajax',
          'X-Requested-With': 'XMLHttpRequest'}

o_df_sz = []

for i in range(1, 450):
    print(i, end=',')
    rdn = str(random.random())
    payload = {"seDate":["",""],"channelCode":["listedNotice_disc"],"bigCategoryId":["0109"],"pageSize":50,"pageNum":i}
    
    r = requests.post('http://www.szse.cn/api/disc/announcement/annList?random={0}'.format(rdn), json = payload, headers = header)
    r1 = r.json()['data']
    
    t_df = pd.DataFrame(r1)
    o_df_sz.append(t_df)
    
    
cb_announcement_sz = pd.concat(o_df_sz, axis = 0)
cb_announcement_sz.to_parquet(r'S:\TZ\China Data Hunt\cache\pCorpAct_cn_cb_etl_szse_announcement.parquet')




