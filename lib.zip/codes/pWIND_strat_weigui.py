﻿#$%^&* pWIND_strat_weigui.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon May 10 13:25:54 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
from yz.util import get_sql, bt_cn
import yz.util as yu



# get sd
i_sd = pw.get_china_sd()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d','avgPVadj','volatility','spread',
                 'BarrRet_CLIP-1d', 'BarrRet_CLIP+0d', 'BarrRet_CLIP+1d','BarrRet_SRISK+0d','BarrRet_SRISK+1d','RawRet+1d','fxRet_SRISK+1d',
                 'fxRet_CLIP+1d','isin_hk_uni']]



# weigui data

i_weigui = get_sql('''select s_info_windcode as ticker, ann_dt as datadate,
                   illeg_type, illeg_type_code, subject, behavior, disposal_type, amount,
                   processor, relation_type 
                   from wind.dbo.AShareIllegality''')
i_weigui = i_weigui[i_weigui['datadate'].notnull()]
i_weigui['datadate'] = pd.to_datetime(i_weigui['datadate'], format='%Y%m%d')

i_weigui_dedup = i_weigui.drop_duplicates(subset = ['ticker', 'datadate'], keep = 'first')
i_weigui_dedup['weigui_flag'] = 1


# sec investigation
i_sec_investigation = get_sql('''select s_info_windcode as ticker, sur_institute, 
                                  sur_reasons, str_anndate as datadate
                                  from wind.dbo.[AShareRegInv] 
                                  where str_anndate is not null''')
i_sec_investigation['datadate'] = pd.to_datetime(i_sec_investigation['datadate'], format= '%Y%m%d')
i_sec_investigation = i_sec_investigation.drop_duplicates(subset=['ticker','datadate'],keep = 'last')
i_sec_investigation['sec_investigation_date'] = i_sec_investigation['datadate']
i_sec_investigation['sec_investigation_flag'] = 1


#icom
icom = i_sd_map.merge(i_weigui_dedup, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(i_sec_investigation, on = ['ticker','datadate'], how = 'left')


#------------------------------------------------------------------------------
### idea 1: weigui - short immediately
#------------------------------------------------------------------------------

### hold 1 day
icom2 = icom.copy()
icom2.loc[icom2['weigui_flag']==1, 'sgnl'] = -1

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.14/ -0.87

### hold 5 day

icom2 = icom.c
opy()
icom2.loc[icom2['weigui_flag']==1, 'sgnl'] = -1
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['sgnl'] = icom2.groupby(['ticker'])['sgnl'].ffill(limit = 5)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.4 / 0.1


### hold 20 day

icom2 = icom.copy()
icom2.loc[icom2['weigui_flag']==1, 'sgnl'] = -1
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['sgnl'] = icom2.groupby(['ticker'])['sgnl'].ffill(limit = 20)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.35 / 0.22


### hold 60 day

icom2 = icom.copy()
icom2.loc[icom2['weigui_flag']==1, 'sgnl'] = -1
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['sgnl'] = icom2.groupby(['ticker'])['sgnl'].ffill(limit = 60)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.54 / 0.47


### hold 200 day

icom2 = icom.copy()
icom2.loc[icom2['weigui_flag']==1, 'sgnl'] = -1
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['sgnl'] = icom2.groupby(['ticker'])['sgnl'].ffill(limit = 200)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.68 / 0.63


### hold 60 day, excl. banks

icom2 = icom.copy()
icom2['processor'] = icom2['processor'].fillna('')
icom2.loc[(icom2['weigui_flag']==1) &\
          (~icom2['processor'].str.contains('银行')) &\
          (icom2['relation_type'].isin(['458001000','458004000','458006000'])), 'sgnl'] = -1
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['sgnl'] = icom2.groupby(['ticker'])['sgnl'].ffill(limit = 60)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.5 / 0.43



### hold 60 day, sec and exchange only

icom2 = ic
om.copy()
icom2['processor'] = icom2['processor'].fillna('')
icom2.loc[(icom2['weigui_flag']==1) &\
          (icom2['processor'].str.contains('证券')), 'sgnl'] = -1
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['sgnl'] = icom2.groupby(['ticker'])['sgnl'].ffill(limit = 60)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.51 / 0.44


### hold 60 day, sec and exchange only + past return

icom2 = icom.copy()
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['bret_t60d'] = icom2.groupby('ticker').rolling(60)['BarrRet_CLIP-1d'].sum().values
icom2['bret_t60d_rk'] = icom2.groupby('datadate')['bret_t60d'].apply(lambda x: yu.uniformed_rank(x)).values

icom2['processor'] = icom2['processor'].fillna('')
icom2.loc[(icom2['weigui_flag']==1) &\
          (icom2['processor'].str.contains('证券')) &\
          (icom2['bret_t60d_rk']>0), 'sgnl'] = -1

icom2['sgnl'] = icom2.groupby(['ticker'])['sgnl'].ffill(limit = 60)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.73 / 0.67



### hold 60 day, sec only

icom2 = icom.copy()
icom2['processor'] = icom2['processor'].fillna('')
icom2.loc[(icom2['weigui_flag']==1) &\
          (icom2['processor'].str.contains('证券监督')), 'sgnl'] = -1
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['sgnl'] = icom2.groupby(['ticker'])['sgnl'].ffill(limit = 60)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.38 / 0.32






#------------------------------------------------------------------------------
### idea 2: long short
#------------------------------------------------------------------------------

### hold 60 day

icom2 = icom.copy()
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['weigui_flag'] = icom2['weigui_flag'].fillna(0)
icom2['weigui_t60d'] = icom2.groupby('ticker').rolling(60)['weigui_flag'].sum().values

icom2.loc[icom2['weigui_t60d']==0, 'sgnl'] = +0.1
icom2.loc[icom2['weigui_t60d']>0, 'sgnl'] = -1

o_1 = bt_cn(icom2[(icom2['datadate']<='
2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs -0.35 / -0.6



#------------------------------------------------------------------------------
### idea 3: sec - short immediately
#------------------------------------------------------------------------------


### hold 5 day

icom2 = icom.copy()
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['sec_investigation_flag'] = icom2['sec_investigation_flag'].fillna(0)
icom2['sec_t5d'] = icom2.groupby('ticker').rolling(5)['sec_investigation_flag'].sum().values

icom2.loc[icom2['sec_t5d']>0, 'sgnl'] = -1

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.71 / 0.64



### hold 60 day

icom2 = icom.copy()
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['sec_investigation_flag'] = icom2['sec_investigation_flag'].fillna(0)
icom2['sec_t60d'] = icom2.groupby('ticker').rolling(60)['sec_investigation_flag'].sum().values

icom2.loc[icom2['sec_t60d']>0, 'sgnl'] = -1

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.9 / 0.87



### hold 200 day

icom2 = icom.copy()
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['sec_investigation_flag'] = icom2['sec_investigation_flag'].fillna(0)
icom2['sec_t200d'] = icom2.groupby('ticker').rolling(200)['sec_investigation_flag'].sum().values

icom2.loc[icom2['sec_t200d']>0, 'sgnl'] = -1

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.56 / 0.53




### hold 60 day + prev return

icom2 = icom.copy()
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['bret_t60d'] = icom2.groupby('ticker').rolling(60)['BarrRet_CLIP-1d'].sum().values
icom2['bret_t60d_rk'] = icom2.groupby('datadate')['bret_t60d'].apply(lambda x: yu.uniformed_rank(x)).values

icom2['sec_investigation_flag'] = icom2['sec_investigation_flag'].fillna(0)
icom2['sec_t60d'] = icom2.groupby('ticker
').rolling(60)['sec_investigation_flag'].sum().values

icom2.loc[(icom2['sec_t60d']>0)&(icom2['bret_t60d_rk']>0), 'sgnl'] = -1

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 1.36 / 1.29




