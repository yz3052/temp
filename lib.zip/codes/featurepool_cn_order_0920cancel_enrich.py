﻿#$%^&* featurepool_cn_order_0920cancel_enrich.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  5 13:04:21 2022

@author: thzhang
"""


import sys
sys.path.append('/export/dataprod/Feature_Script_CN/TZ/')
import featurepool_enrich_lib as fp


import os
import pandas as pd
import numpy as np

import datetime

from sqlalchemy import create_engine
import urllib


# 







### params

DataDate = pd.to_datetime(str(sys.argv[1]), format = '%Y%m%d')
DataDate_m28d = DataDate - pd.to_timedelta('28 days')
DataDate_m28d = DataDate - pd.to_timedelta('28 days')


source_path = '/export/dataprod/Feature_Pool_CN/featurepool_desc_order_0920cancel'
save_path = '/export/dataprod/Feature_Pool_CN/featurepool_enrich_order_0920cancel'

TGT_COLS = ['cancel_b']

conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))



#------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------



### get calendar map, get T-1d

i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()

c_tm1d_str = i_cal.loc[i_cal['DataDate']==DataDate, 'T-1d'].dt.strftime('%Y-%m-%d').values[0]
c_tm1d_dt = pd.to_datetime(c_tm1d_str)



### get a-share universe


i_dtk = pd.read_sql('''select DataDate as [T-1d], Ticker 
                    from cndbprod.dbo.universe_all_cn_gem3l 
                    with (nolock)
                    where datadate = '{0}' 
                    '''.format(c_tm1d_str), conn)
i_dtk = i_dtk.drop_duplicates(subset = ['Ticker', 'T-1d'], keep = 'last')
i_dtk = i_dtk.merge(i_cal, on = ['T-1d'], how = 'left')




### get gem3l, gemtr


i_gem3l = pd.read_sql('''select Ticker, DataDate as [T-1d], 
                 [SRISK],[BETA],[MOMENTUM],[SIZE],[EARNYILD],[RESVOL],[GROWTH],[DIVYILD],
                 [BTOP],[LEVERAGE],[LIQUIDTY],[SIZENL],
                 [AIRLINES],[AUTOCOMP],[BANKS],[BIOTECH],[CAPGOODS],[CHEMICAL],[COMMSVCS],
                 [COMMUNIC],[COMPUTER],[CONSDUR],[CONSTPP],[CONSVCS],[DIVFINAN],[DIVMETAL],
                 [ENERGY],[FOODPRD],[FOODRETL],[HEALTH],[HSHLDPRD],[INSURAN]
,[INTERNET],
                 [MEDIA],[OILEXPL],[OILGAS],[PHARMAC],[PRECMETL],[REALEST],[RETAIL],
                 [SEMICOND],[SOFTWARE],[STEEL],[TELECOM],[TRANSPRT],[UTILITY] 
                 from cndbprod.dbo.[UNIVERSE_ALL_CN_GEM3L] 
                 with (nolock)
                 where DataDate = '{0}' 
                 '''.format(c_tm1d_str), conn)
    
i_gemtr = pd.read_sql('''select Ticker, DataDate as [T-1d], 
                 [SRISK],[BETA],[MOMENTUM],[SIZE],[EARNYILD],[RESVOL],[GROWTH],[DIVYILD],
                 [BTOP],[LEVERAGE],[LIQUIDTY],
                 [AEROSPCE],[AGROCHEM],[AIRLINES],[AUTOCOMP],[BANKS],[BIOTECH],[BLDCNSTR],
                 [CAPMRKTS],[CHEMICAL],[COMMSVCS],[COMMUNIC],[COMPUTER],[CONSDUR],[CONSTPP],
                 [CONSVCS],[DIVFIN],[DIVMETAL],[ENERGY],[FOODPRD],[FOODRETL],[GOLD],[HLTHEQP],
                 [HLTHSVC],[HSHLDPRD],[INOILGAS],[INSURNCE],[INTERNET],[MACHINRY],[MEDIA],
                 [OILEXPL],[OILGAS],[PHARMA],[PRECMETL],[REALEST],[RETAIL],[RGNLBNKS],
                 [RLESTMNG],[SEMICOND],[SMICNDEQ],[SOFTWARE],[STEEL],[TELECOM],[TRNSPORT],
                 [UTILITY]
                 from cndbprod.dbo.[UNIVERSE_ALL_CN_GEMTR] 
                 with (nolock)
                 where DataDate = '{0}' 
                 '''.format(c_tm1d_str), conn)
for c in i_gemtr.columns.tolist():
    if c not in ['Ticker', 'T-1d']:
        i_gemtr = i_gemtr.rename(columns = {c: c+'_gemtr'})




#------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------



### get data from q process



i_files = os.listdir(source_path)
i_desc = pd.concat([pd.read_parquet(os.path.join(source_path,i)) for i in i_files])
i_desc = fp.enrich_feature_v2(i_desc, 'cancel_b')




#------------------------------------------------------------------------------
#
#------------------------------------------------------------------------------



### combine

icom = i_dtk.merge(i_q, on = ['Ticker', 'T-1d'], how = 'left')
icom = icom.merge(i_gem3l, on = ['Ticker', 'T-1d'], how = 'left')
icom = icom.merge(i_gemtr, on = ['Ticker', 'T-1d'], how = 'left')
icom = icom.sort_values(['Ticker', 'DataDate'])
icom = icom.drop_duplicates(subset = ['Ticker', 'DataDate'], keep = 'last')
    


### enrich

icom_cols = set(icom.columns.tolist()).difference({'Ticker','T-1d','DataDate'})
for tgt in TGT_COLS:
    icom = fp.enrich_feature(icom, tgt)
icom = icom[[c for c in ico
m.columns.tolist() if c not in icom_cols]]



### output

icom = icom.drop_duplicates(subset = ['Ticker', 'DataDate'], keep = 'last')
icom.to_parquet(os.path.join(save_path, DataDate.strftime('%Y%m%d')+'.parquet'), 
                allow_truncated_timestamps = True)


