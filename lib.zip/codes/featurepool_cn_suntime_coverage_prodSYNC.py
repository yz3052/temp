﻿#$%^&* featurepool_cn_suntime_coverage_prodSYNC.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct  6 16:02:31 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import os

import datetime

from sqlalchemy import create_engine
import urllib
import pyodbc




#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------


save_path = '/dat/summit_capital/TZ/PROD_FEATURES/featurepool_cn_desc_suntime_cov'
conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
conn_wind = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_wind_dbo;PWD=DusONA3Habredl;''TDS_Version=8.0;')))

today = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
today = pd.to_datetime(today.date())
today_str = today.strftime('%Y%m%d')


#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------

i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()



#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------



dates_to_query = i_cal['DataDate'].dt.strftime('%Y%m%d.parquet').drop_duplicates().tolist()
dates_to_query = [d for d in dates_to_query if (d>='20170101.parquet') and (d<today.strftime('%Y%m%d.parquet'))]

existing_dates = os.listdir(save_path)

dates_to_query = [d for d in dates_to_query if d not in existing_dates]



#------------------------------------------------------------------------------
### get all the suntime data needed
# get rid of non-individual report
#------------------------------------------------------------------------------

if len(dates_to_query) == 0:
    quit()
    
startdt = pd.to_datetime(min(dates_to_query), format='%Y%m%d.parquet') - pd.to_timedelta('180 d
ays')
startdt = startdt.strftime('%Y-%m-%d')


i_rpt_original = pd.read_sql('''select id, report_id, stock_code as Ticker,create_date,
                                report_year*10 + report_quarter as report_period, 
                                report_type, reliability, organ_id, author_name, entrytime 
                                from suntime_prod.dbo.rpt_forecast_stk
                                WITH (NOLOCK)
                                where create_date >= '{0}'
                                      and report_type!=21
                            '''.format(startdt), conn)



#------------------------------------------------------------------------------
### query and calculate metrics
#------------------------------------------------------------------------------



for i in dates_to_query:

    
    # dates
    
    t_1d = pd.to_datetime(i, format='%Y%m%d.parquet')    
    t_1d_str = t_1d.strftime('%Y%m%d')
    t_91d = (t_1d - pd.to_timedelta('91 days')).strftime('%Y-%m-%d')
    t_182d_str = (t_1d - pd.to_timedelta('182 days')).strftime('%Y%m%d')    
    
    t_0d_str = i_cal.loc[i_cal['T-1d']==t_1d, 'DataDate'].dt.strftime('%Y-%m-%d').iloc[0]
    t_today = pd.to_datetime(t_0d_str)
    t_today_str = t_today.strftime('%Y-%m-%d')
    t_today_4am_str = t_today_str + ' 04:00:00'
    t_today_4am = pd.to_datetime(t_today_4am_str)
    t0_0400 = t_today.strftime('%Y-%m-%d 04:00:00')
    t_last_tdate_str = t_1d.strftime('%Y-%m-%d')
    t_preday456 = t_today - pd.to_timedelta('456 days')
    t_preday456_str = t_preday456.strftime('%Y-%m-%d')
    
    # uni

    i_dtk = pd.read_sql('''select datadate as [T-1d], ticker as Ticker
                        from cndbprod.dbo.universe_all_cn_gem3l 
                        with (nolock)
                        where datadate = '{0}' 
                        '''.format(t_1d_str), conn)
    i_dtk = i_dtk.drop_duplicates(subset = ['T-1d', 'Ticker'], keep = 'last')
    
    i_st = i_rpt_original[i_rpt_original['entrytime'].le(t0_0400)&i_rpt_original['create_date'].ge(t_91d)]
    
    s_st = i_st.groupby('Ticker')['organ_id'].nunique()
    s_st = s_st.reset_index()
    s_st = s_st.rename(columns = {'organ_id':'organ_cnt'})
                                                              
    icom = i_dtk.merge(s_st, on = ['Ticker'], how = 'left')
    icom['organ_cnt'] = icom['organ_cnt'].fillna(0)
    icom = icom.merge(i_cal, on = 'T-1d', how = 'left')
    
    
    icom[['DataDate', 'Ticker', 'organ_cnt']].to_p
arquet(os.path.join(save_path, i))
    


