﻿#$%^&* pGraph_cn_ALL.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat Jan 22 22:18:21 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu






### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()



### get data

o_shared_cpt_cnt = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_cpt_01_o_shared_cpt_cnt.parquet')
o_shared_holder_cnt = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_holder_o_shared_holder_cnt.parquet')
o_shared_news_cnt = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_conews_shared_news_cnt.parquet')
o_shared_prod_cnt = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_product_o_shared_prod_cnt.parquet')
o_ret_corr = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_ret_01_o_ret_corr.parquet')


### get zz500 

i_zz500 = yu.get_sql_prod('''select [Date_of_Portfolio] as datadate, substring(Database_Symbol,2,6) as ticker
                            from [CNDBPROD].[dbo].[CSI_500_CONS]
                            where [Date_of_Portfolio] >= '2017-01-01' ''')
c_sh = i_zz500['ticker'].str[0].isin(['6'])
c_sz = i_zz500['ticker'].str[0].isin(['0', '3'])
i_zz500.loc[c_sh, 'ticker'] = i_zz500.loc[c_sh, 'ticker'] + '.SH'
i_zz500.loc[c_sz, 'ticker'] = i_zz500.loc[c_sz, 'ticker'] + '.SZ'
i_zz500['flg_zz500'] = 1


### combine

icom = pd.merge_asof(i_sd, o_shared_holder_cnt, by='ticker', on='datadate')
icom = pd.merge_asof(icom, o_shared_cpt_cnt, by='ticker', on='datadate')
icom = pd.merge_asof(icom, o_shared_news_cnt, by='ticker', on='datadate')
icom = pd.merge_asof(icom, o_shared_prod_cnt, by='ticker', on='datadate')
icom = pd.merge_asof(icom, o_ret_corr, by='ticker', on='datadate')
icom = icom.merge(i_zz500, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])


COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['shared_holderAllCnt_orth'] = icom.groupby('datadate')[COLS+['shared_holderAllCnt']].apply(lambda x: yu.orthogonalize_cn(x['shared_holderAllCnt'], x[COLS])).values
icom['shared_holderAllCnt_orth_bk'] = icom.groupby('datadate')['shared_holderAllCnt_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['shared_holderAllCnt_orth_rk'] = icom.groupby('datadate')['shared_holderAllCnt_orth'].apply(yu.uniformed_rank).values

OLS = ['SRISK', 'BETA', 'MOMEN
TUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['shared_cpt_cnt_orth'] = icom.groupby('datadate')[COLS+['shared_cpt_cnt']].apply(lambda x: yu.orthogonalize_cn(x['shared_cpt_cnt'], x[COLS])).values
icom['shared_cpt_cnt_orth_bk'] = icom.groupby('datadate')['shared_cpt_cnt_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['shared_cpt_cnt_orth_rk'] = icom.groupby('datadate')['shared_cpt_cnt_orth'].apply(yu.uniformed_rank).values

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['shared_newsCnt_orth'] = icom.groupby('datadate')[COLS+['shared_newsCnt']].apply(lambda x: yu.orthogonalize_cn(x['shared_newsCnt'], x[COLS])).values
icom['shared_newsCnt_orth_bk'] = icom.groupby('datadate')['shared_newsCnt_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['shared_newsCnt_orth_rk'] = icom.groupby('datadate')['shared_newsCnt_orth'].apply(yu.uniformed_rank).values

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['shared_prodCnt_orth'] = icom.groupby('datadate')[COLS+['shared_prodCnt']].apply(lambda x: yu.orthogonalize_cn(x['shared_prodCnt'], x[COLS])).values
icom['shared_prodCnt_orth_bk'] = icom.groupby('datadate')['shared_prodCnt_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['shared_prodCnt_orth_rk'] = icom.groupby('datadate')['shared_prodCnt_orth'].apply(yu.uniformed_rank).values

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['corr_mean_orth'] = icom.groupby('datadate')[COLS+['corr_mean']].apply(lambda x: yu.orthogonalize_cn(x['corr_mean'], x[COLS])).values
icom['corr_mean_orth_bk'] = icom.groupby('datadate')['corr_mean_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['corr_mean_orth_rk'] = icom.groupby('datadate')['corr_mean_orth'].apply(yu.uniformed_rank).values

icom['corr_mean_rk'] = icom.groupby('datadate')['corr_mean'].apply(yu.uniformed_rank).values
icom['corr_mean_bk'] = icom.groupby('datadate')['corr_mean'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['corr_mean_orth_bk'], 'corr_mean_orth')
# yu.create_cn_3x3(icom, ['corr_mean_bk'], 'corr_mean')


icom['cpt_holder_rksum'] = icom['shared_holderAllCnt_orth_rk'] + icom['shared_cpt_cnt_orth_rk']
icom['cpt_holder_rksum_bk'] = icom.groupby('datadate')['cpt_holder_rksum'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cpt_holde
r_rksum_rk'] = icom.groupby('datadate')['cpt_holder_rksum'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['cpt_holder_rksum_bk'], 'cpt_holder_rksum') # mono: -4.5 +2

icom['cpt_holder_neg_sgnl'] = np.nan
icom.loc[(icom['shared_holderAllCnt_orth_rk']<-0.8)&(icom['shared_cpt_cnt_orth_rk']<-0.8), 'cpt_holder_neg_sgnl'] = -1
icom['cpt_holder_neg_sgnl'] = icom.groupby('ticker')['cpt_holder_neg_sgnl'].ffill(limit = 20)

icom['cpt_holder_neg_sgnl2'] = np.nan
icom.loc[icom['cpt_holder_rksum_rk']<-0.8, 'cpt_holder_neg_sgnl2'] = -1
icom['cpt_holder_neg_sgnl2'] = icom.groupby('ticker')['cpt_holder_neg_sgnl2'].ffill(limit = 20)

icom['cpt_holder_neg_sgnl3'] = np.nan
icom.loc[(icom['shared_holderAllCnt_orth_rk']<-0.8)|(icom['shared_cpt_cnt_orth_rk']<-0.8), 'cpt_holder_neg_sgnl3'] = -1
icom['cpt_holder_neg_sgnl3'] = icom.groupby('ticker')['cpt_holder_neg_sgnl3'].ffill(limit = 20)

icom['cpt_holder_neg_sgnl4'] = np.nan
icom.loc[(icom['shared_holderAllCnt_orth_rk']<-0.8)|(icom['shared_cpt_cnt_orth_rk']<-0.8)|(icom['shared_newsCnt_orth_rk']<-0.8), 'cpt_holder_neg_sgnl4'] = -1
icom['cpt_holder_neg_sgnl4'] = icom.groupby('ticker')['cpt_holder_neg_sgnl4'].ffill(limit = 20)

icom['cpt_holder_neg_sgnl5'] = np.nan
icom.loc[(icom['shared_holderAllCnt_orth_rk']<-0.8)|(icom['shared_cpt_cnt_orth_rk']<-0.8)|(icom['shared_prodCnt_orth_rk']<-0.8), 'cpt_holder_neg_sgnl5'] = -1
icom['cpt_holder_neg_sgnl5'] = icom.groupby('ticker')['cpt_holder_neg_sgnl5'].ffill(limit = 20)

icom['cpt_holder_neg_sgnl6'] = np.nan
icom.loc[(icom['shared_holderAllCnt_orth_rk']<-0.8)|(icom['shared_cpt_cnt_orth_rk']<-0.8)|(icom['corr_mean_orth_rk']<-0.8), 'cpt_holder_neg_sgnl6'] = -1
icom['cpt_holder_neg_sgnl6'] = icom.groupby('ticker')['cpt_holder_neg_sgnl6'].ffill(limit = 20)

icom['all_sgnl'] = np.nan
#icom.loc[(icom['shared_holderAllCnt_orth_rk']<-0.8)|(icom['shared_cpt_cnt_orth_rk']<-0.8)|(icom['corr_mean_orth_rk']<-0.8), 'all_sgnl'] = -1
icom.loc[(icom['shared_holderAllCnt_orth_rk']>0.8)|(icom['shared_cpt_cnt_orth_rk']>0.8)|(icom['corr_mean_orth_rk']>0.8), 'all_sgnl'] = 1
icom['all_sgnl'] = icom.groupby('ticker')['all_sgnl'].ffill(limit = 20)




o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['cpt_holder_rksum_rk']>0)].\
            dropna(subset=['cpt_holder_rksum_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cpt_holder_rksum_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
      
      dropna(subset=['cpt_holder_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cpt_holder_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #1.61 / 1.37


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['csi300_flag']==1)].\
            dropna(subset=['cpt_holder_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cpt_holder_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.39 / 1.29


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['csi300_flag']==1)].\
            dropna(subset=['cpt_holder_neg_sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cpt_holder_neg_sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.84 / 1.59 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['csi300_flag']==1)].\
            dropna(subset=['cpt_holder_neg_sgnl4','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cpt_holder_neg_sgnl4','BarrRet_CLIP_USD+1d', static_data = i_sd) 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['csi300_flag']==1)].\
            dropna(subset=['cpt_holder_neg_sgnl5','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cpt_holder_neg_sgnl5','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.9 / 1.63

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cpt_holder_neg_sgnl6','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cpt_holder_neg_sgnl6','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.01 / 2.28 ###!!!

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&((icom['flg_zz500']==1)|(icom['csi300_flag']==1))].\
            dropna(subset=['cpt_holder_neg_sgnl6','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cpt_holder_neg_sgnl6','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.55 / 1.03

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&((icom['flg_zz500']==1))].\
            dropna(subset=['cpt_holder_neg_sgnl6','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cpt_holder_neg_sgnl6','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.74 / 0.37


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['all_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'all_sgnl','BarrRet_CLIP_USD+1d', 
static_data = i_sd) 


