﻿#$%^&* pGraph_cn_product.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 23 16:51:38 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime


### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()


### get news data

i_company = pd.read_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\company.parquet',
                            columns = ['stockCode','newsId'])
i_company = i_company[i_company['stockCode'].str.contains('\d{6}') &\
                      i_company['stockCode'].str.contains('S[HZ]') &\
                      i_company['stockCode'].str[0].isin(['0','3','6']) ]
i_company['ticker'] = i_company['stockCode'].str.split('_').str[0]+'.'+i_company['stockCode'].str.split('_').str[1]
i_company = i_company.drop(columns=['stockCode'])
i_company = i_company.drop_duplicates(subset = ['ticker','newsId'])

i_prod = pd.read_parquet(r"S:\Data\China Data Hunt\ChinaScope\cache\product.parquet",
                         columns=['productCode','chineseName','newsId','newsTs'])

i_news_com = i_company.merge(i_prod, on = ['newsId'], how = 'left')
i_news_com['datadate'] = pd.to_datetime(pd.to_datetime(i_news_com['newsTs']).dt.date)+pd.to_timedelta('1 day')




### calculate corr matrix

o_shared_prod_cnt = []

for dt in pd.date_range(start = '2016-02-01', end = '2021-11-01', freq='W'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    
    t_sd = i_sd[i_sd['datadate']==i_sd_dd[i_sd_dd<=dt].max()]
    
    t_news = i_news_com[(i_news_com['datadate']<=dt)&\
                        (i_news_com['ticker'].isin(t_sd['ticker'].tolist()))]
    t_tk_news_map = t_news.groupby('ticker')['productCode'].apply(lambda x: set(x))
    t_tk_news_map = t_tk_news_map.reset_index()
    
        
    t_tkPair_newsSet = pd.DataFrame((t_tk_news_map['productCode'].values[:, None] &\
                                      t_tk_news_map['productCode'].values))
    t_tkPair_newsSet = t_tkPair_newsSet.applymap(lambda x: len(x) )
    t_tkPair_newsSet.columns = t_tk_news_map['ticker'].values
    t_tkPair_newsSet.index = t_tk_news_map['ticker'].values
    t_tkPair_newsSet.values[[np.arange(t_tkPair_newsSet.shape[0])]*2] = 0
    
    t_sum1 = t_tkPair_newsSet.mean(axis = 1)
    t_sum1 = t_sum1.reset_index()
    t_sum1.columns = ['ticker','shared_prodCnt']
    
    t_sum = t_sum1.copy()
    t_sum['datadate'] = dt
    
    o_shared_p
rod_cnt.append(t_sum)
    
o_shared_prod_cnt = pd.concat(o_shared_prod_cnt, axis = 0)

o_shared_prod_cnt.to_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_product_o_shared_prod_cnt.parquet')



### combine 


icom = pd.merge_asof(i_sd, o_shared_prod_cnt, by='ticker', on='datadate')

icom = icom.sort_values(['ticker','datadate'])

icom['shared_prodCnt_bk'] = icom.groupby('datadate')['shared_prodCnt'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['shared_prodCnt_rk'] = icom.groupby('datadate')['shared_prodCnt'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['shared_prodCnt_bk'], 'shared_prodCnt') # less mono : -1.5 +1.5 0

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['shared_prodCnt_orth'] = icom.groupby('datadate')[COLS+['shared_prodCnt']].apply(lambda x: yu.orthogonalize_cn(x['shared_prodCnt'], x[COLS])).values
icom['shared_prodCnt_orth_bk'] = icom.groupby('datadate')['shared_prodCnt_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['shared_prodCnt_orth_rk'] = icom.groupby('datadate')['shared_prodCnt_orth'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['shared_prodCnt_orth_bk'], 'shared_prodCnt_orth') # less mono: -3 +1 0.5


