﻿#$%^&* pGraph_cn_supply_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 27 21:10:08 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu


# this one is old. The ETL process has been updated in pGraph_cn_supply_etl


### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()


### get ticker mapping

i_ent_scr_sec_entity = pd.read_parquet(r"S:\Data\Factset\raw_weekly_full_files\ent_supply_chain_hub\ent_scr_sec_entity\20220101.parquet",
                                       columns = ['FSYM_ID', 'FACTSET_ENTITY_ID']) # 1 entity <> multiple fsym

i_sym_coverage = pd.read_parquet(r"S:\Data\Factset\raw_weekly_full_files\sym_hub\sym_coverage\20220212.parquet",
                                 columns = ['FSYM_ID', 'PROPER_NAME', 'FSYM_PRIMARY_EQUITY_ID', 
                                            'FSYM_PRIMARY_LISTING_ID', 'FSYM_REGIONAL_ID', 'FSYM_SECURITY_ID'])
i_sym_coverage = i_sym_coverage[i_sym_coverage['FSYM_ID']==i_sym_coverage['FSYM_PRIMARY_EQUITY_ID']]
    
i_sym_ticker_region = pd.read_parquet(r"S:\Data\Factset\raw_weekly_full_files\sym_ticker\sym_ticker_region\20220101.parquet",
                                      columns = ['FSYM_ID','TICKER_REGION'])

i_tk_map = i_ent_scr_sec_entity.merge(i_sym_coverage, on = 'FSYM_ID', how = 'inner')
i_tk_map = i_tk_map.merge(i_sym_ticker_region, left_on = 'FSYM_PRIMARY_LISTING_ID', right_on = 'FSYM_ID', 
                          how = 'inner', suffixes = ['', '_region'])
i_tk_map = i_tk_map.drop(columns = ['FSYM_ID_region'])
i_tk_map = i_tk_map[['FACTSET_ENTITY_ID','TICKER_REGION','PROPER_NAME']]


### get relation

i_relation = pd.read_parquet(r"S:\Data\Factset\raw_weekly_full_files\ent_supply_chain\ent_scr_relationships\20220101.parquet")
i_relation['START_DATE'] = pd.to_datetime(i_relation['START_DATE'])
i_relation['END_DATE'] = pd.to_datetime(i_relation['END_DATE'])

i_relation = i_relation.merge(i_tk_map, left_on = 'SOURCE_FACTSET_ENTITY_ID', right_on = 'FACTSET_ENTITY_ID', how = 'left')
i_relation = i_relation.drop(columns = ['FACTSET_ENTITY_ID'])\
                       .rename(columns = {'TICKER_REGION':'TICKER_REGION_source','PROPER_NAME':'NAME_source'})
i_relation = i_relation.merge(i_tk_map, left_on = 'TARGET_FACTSET_ENTITY_ID', right_on = 'FACTSET_ENTITY_ID', how = 'left')
i_relation = i_relation.drop(columns = ['FACTSET_ENTITY_ID'])\
          
             .rename(columns = {'TICKER_REGION':'TICKER_REGION_target','PROPER_NAME':'NAME_target'})


#--------------------
###???
# the code above is good; continue here

i_relation_tkpair = i_relation[i_relation['TICKER_REGION_source'].notnull()&i_relation['TICKER_REGION_target'].notnull()]
i_relation_tkpair = i_relation_tkpair[i_relation_tkpair['TICKER_REGION_source'].str.contains('-CN') |\
                                      i_relation_tkpair['TICKER_REGION_target'].str.contains('-CN')]





i_relation_tkpair['tkpair_set'] = i_relation_tkpair[['ticker_source','ticker_target']].apply(lambda x: set([x['ticker_source'],x['ticker_target']]),axis=1)
i_relation_tkpair['tkpair_set'] = i_relation_tkpair['tkpair_set'].astype(str)



### get suply chain ###???

i_ent_sc = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_supply_etl_i_supply.parquet')
i_ent_sc['START_DATE'] = pd.to_datetime(i_ent_sc['START_DATE'])
i_ent_sc['END_DATE'] = pd.to_datetime(i_ent_sc['END_DATE'])

i_ent_sc = i_ent_sc.merge(i_tk_map, left_on = 'SUPPLIER_FACTSET_ENTITY_ID', right_on = 'FACTSET_ENTITY_ID', how = 'left')
i_ent_sc = i_ent_sc.drop(columns = ['FACTSET_ENTITY_ID'])\
                   .rename(columns = {'TICKER_REGION':'TICKER_REGION_supplier','PROPER_NAME':'NAME_supplier'})
i_ent_sc = i_ent_sc.merge(i_tk_map, left_on = 'CUSTOMER_FACTSET_ENTITY_ID', right_on = 'FACTSET_ENTITY_ID', how = 'left')
i_ent_sc = i_ent_sc.drop(columns = ['FACTSET_ENTITY_ID'])\
                   .rename(columns = {'TICKER_REGION':'TICKER_REGION_customer','PROPER_NAME':'NAME_customer'})


i_supply_tkpair = i_ent_sc[i_ent_sc['ticker_supplier'].notnull()&i_supply['ticker_customer'].notnull()]
i_supply_tkpair['tkpair_set'] = i_supply_tkpair[['ticker_supplier','ticker_customer']].apply(lambda x: set([x['ticker_supplier'],x['ticker_customer']]),axis=1)
i_supply_tkpair['tkpair_set'] = i_supply_tkpair['tkpair_set'].astype(str)







### daily loop 

o_sum = []

for dt in pd.date_range(start = '2017-01-01', end = '2021-06-01'):
    if dt.strftime('%Y-%m-%d')<'2018-08-09':
        continue
    print(dt.strftime('%Y%m%d'), end=' ' )
    
    
    
    t_relation = i_relation[(i_relation['START_DATE']<=dt)&((i_relation['END_DATE']>=dt)|i_relation['END_DATE'].isnull())]
    t_relation_comp = t_relation[t_relation['REL_TYPE']=='COMPETITOR']
    t_relation_xcomp = t_relation[t_relation['REL_TYPE']!='COMPETITOR']
    t_relation_tkpair = i_relation_tkpair[(i_relation_tkpair['START_DATE']<=dt)&((i_relation_t
kpair['END_DATE']>=dt)|i_relation_tkpair['END_DATE'].isnull())]
    t_relation_tkpair_comp = t_relation_tkpair[t_relation_tkpair['REL_TYPE']=='COMPETITOR']
    t_relation_tkpair_xcomp = t_relation_tkpair[t_relation_tkpair['REL_TYPE']!='COMPETITOR']
    t_supply = i_supply[(i_supply['START_DATE']<=dt)&((i_supply['END_DATE']>=dt)|i_supply['END_DATE'].isnull())]
    t_supply_tkpair = i_supply_tkpair[(i_supply_tkpair['START_DATE']<=dt)&((i_supply_tkpair['END_DATE']>=dt)|i_supply_tkpair['END_DATE'].isnull())]
    
    t_sum_comp = t_relation_tkpair_comp[['tkpair_set','REL_TYPE']].drop_duplicates()
    t_sum_comp['tkpair_set'] = t_sum_comp['tkpair_set'].apply(lambda x: eval(x))
    t_sum_comp['ticker1'] = t_sum_comp['tkpair_set'].apply(lambda x: list(x)[0])
    t_sum_comp['ticker2'] = t_sum_comp['tkpair_set'].apply(lambda x: list(x)[1])
    t_sum_comp = pd.concat([t_sum_comp.groupby('ticker1')['ticker2'].count().reset_index().rename(columns={'ticker1':'ticker','ticker2':'compCnt'}),
                            t_sum_comp.groupby('ticker2')['ticker1'].count().reset_index().rename(columns={'ticker2':'ticker','ticker1':'compCnt'})],axis=0)
    t_sum_comp = t_sum_comp.groupby('ticker')['compCnt'].sum().reset_index()
    
    t_sum_rel = t_relation_tkpair_xcomp[['tkpair_set','REL_TYPE']].drop_duplicates()
    t_sum_rel['tkpair_set'] = t_sum_rel['tkpair_set'].apply(lambda x: eval(x))
    t_sum_rel = t_sum_rel[t_sum_rel['tkpair_set'].apply(lambda x: len(x))==2]
    t_sum_rel['ticker1'] = t_sum_rel['tkpair_set'].apply(lambda x: list(x)[0])
    t_sum_rel['ticker2'] = t_sum_rel['tkpair_set'].apply(lambda x: list(x)[1])
    t_sum_rel = pd.concat([t_sum_rel.groupby('ticker1')['ticker2'].count().reset_index().rename(columns={'ticker1':'ticker','ticker2':'relCnt'}),
                           t_sum_rel.groupby('ticker2')['ticker1'].count().reset_index().rename(columns={'ticker2':'ticker','ticker1':'relCnt'})],axis=0)
    t_sum_rel = t_sum_rel.groupby('ticker')['relCnt'].sum().reset_index()
    
    t_sum_supply = t_supply_tkpair[['tkpair_set']].drop_duplicates()
    t_sum_supply['tkpair_set'] = t_sum_supply['tkpair_set'].apply(lambda x: eval(x))
    t_sum_supply = t_sum_supply[t_sum_supply['tkpair_set'].apply(lambda x: len(x))==2]
    t_sum_supply['ticker1'] = t_sum_supply['tkpair_set'].apply(lambda x: list(x)[0])
    t_sum_supply['ticker2'] = t_sum_supply['tkpair_set'].apply(lambda x: list(x)[1])
    t_sum_supply = pd.concat([t_sum_supply.groupby('ticker1')['ticker2'].count(
).reset_index().rename(columns={'ticker1':'ticker','ticker2':'supplyCnt'}),
                              t_sum_supply.groupby('ticker2')['ticker1'].count().reset_index().rename(columns={'ticker2':'ticker','ticker1':'supplyCnt'})],axis=0)
    t_sum_supply = t_sum_supply.groupby('ticker')['supplyCnt'].sum().reset_index()
    
    t_sum = t_sum_comp.merge(t_sum_rel, on = 'ticker', how = 'outer')
    t_sum = t_sum.merge(t_sum_supply, on = 'ticker', how = 'outer')
    t_sum = t_sum[t_sum['ticker'].str[0].isin(['0','3','6'])]
    t_sum['datadate'] = dt
    
    o_sum.append(t_sum)
    
o_sum = pd.concat(o_sum, axis = 0)
o_sum['ticker'] = o_sum['ticker'].str[:6]
c_sh = o_sum['ticker'].str[0].isin(['6'])
c_sz = o_sum['ticker'].str[0].isin(['0','3'])
o_sum.loc[c_sh, 'ticker'] = o_sum.loc[c_sh, 'ticker'] + '.SH'
o_sum.loc[c_sz, 'ticker'] = o_sum.loc[c_sz, 'ticker'] + '.SZ'



### combine

icom = i_sd.merge(o_sum, on = ['ticker','datadate'], how = 'left')

icom['totalRelCnt'] = icom['relCnt'].fillna(0) + icom['supplyCnt'].fillna(0)
icom['totalRelCnt_bk'] = icom.groupby('datadate')['totalRelCnt'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom, ['totalRelCnt_bk'], 'totalRelCnt') # not good: -0.75 +1 0

