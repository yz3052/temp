﻿#$%^&* pGraph_cn_jobTitle.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Feb  6 16:02:17 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import zipfile
import csv

import jieba
import itertools


# job title not working


### get baidu stop words
i_stopword = open(r"S:\Infrastructure\nlp\baidu_stopwords.txt", encoding="utf-8").read()
i_stopword = i_stopword.split('\n')


### get sd
i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values('datadate')

i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','MC_l1d','avgPVadj','avgVadj',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'volatility','spread','BarrRet_SRISK_USD+1d','csi300_flag']]
i_sd_map = i_sd_map.sort_values('datadate')

i_sd_dd = i_sd['datadate'].drop_duplicates()


### get title data


i_p = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet')

i_tk_str = []
for p in i_p:
    t_data = pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet', p),
                             columns = ['id','ticker_symbol','source','title','published_at','created_at'])
    t_data = t_data[t_data['ticker_symbol'].notnull()]
    t_data = t_data[t_data['ticker_symbol'].str.contains('\d{6}')]
    t_data['datadate'] = pd.to_datetime(pd.to_datetime(t_data['created_at']).dt.date)
    c_sz = t_data['ticker_symbol'].str[0].isin(['0', '3'])
    c_sh = t_data['ticker_symbol'].str[0].isin(['6'])
    t_data.loc[c_sz, 'ticker'] = t_data.loc[c_sz, 'ticker_symbol'] + '.SZ'
    t_data.loc[c_sh, 'ticker'] = t_data.loc[c_sh, 'ticker_symbol'] + '.SH'
    
    #t_data= t_data[t_data['source']=='51job'] ###!!!    
    
    t_data['title_clean'] = t_data['title'].str.replace('\(.*\)','').str.replace('（.*）','').\
                             str.replace('\[.*\]','').str.replace('\【.*\】','').\
                             str.replace('\d[K|k|W|w|千|万]','').str.replace('\d','').\
                             str.replace('（|）|,|，|\.|。|:|：|;|；|\(|\)|\*|~|`|!|@|#|$|&|-|—|\+|\/|、|\?',' ').\
                             str.replace('职位编号','').\
                             str.strip().str.replace('[ ]+', ' ').\
                             str.upper()
    t_data = t_data[t_data['title_clean'].notnull() & (t_data['title_clean']!='')]

    t_data['title_seg'] = t_data['title_clean'].apply(lambda x: list(jieba.cut(x)))

    t_data = t_data.sort_values(['datadate'])    
    i_tk_str.append(t_data)
    
i_tk_str = pd.concat(i_tk_str, axis = 0)
i_tk_str = i_tk_str.reset_index(drop = True)

jb_seg_list = list(set(itertools.chain(*i_tk_str['title_seg'])))
jb_seg_id = list(range(len(jb_seg_list)))
jb_seg_dict = {jb_seg_list[i]:i for i in jb_seg_id}

i_tk_str['titleID_seg'] = i_tk_str['title_seg'].apply(lambda x: set([jb_seg_dict[i] for i in x]))


### loop 
# get trailing 1 year jd segments
# calculate pairwise % overlapped segments

o_pct_overlap = []

for dt in pd.date_range(start = '2016-06-01', end = '2021-06-01', freq = 'W'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    yu.tic()
    t_sd = i_sd[i_sd['datadate']==i_sd_dd[i_sd_dd<=dt].max()]
    t_tk_str = i_tk_str[(i_tk_str['datadate']<=dt) & (i_tk_str['datadate']>=dt-pd.to_timedelta('365 days')) &\
                        (i_tk_str['ticker'].isin(t_sd['ticker'].tolist()))]
    
    t_tk_str_byTk = t_tk_str.groupby(['ticker'])['titleID_seg'].apply(lambda x: set(itertools.chain(*x)))
    t_tk_str_byTk = t_tk_str_byTk.reset_index()

    t_intersection_len = pd.DataFrame((t_tk_str_byTk['titleID_seg'].values[:,None] & t_tk_str_byTk['titleID_seg'].values))
    t_intersection_len = np.vectorize(len)(t_intersection_len.values)
    
    t_union_len = pd.DataFrame((t_tk_str_byTk['titleID_seg'].values[:,None] | t_tk_str_byTk['titleID_seg'].values))
    t_union_len = np.vectorize(len)(t_union_len.values)
    
    t_pct_overlap = t_intersection_len/t_union_len
    t_pct_overlap = pd.DataFrame(t_pct_overlap, index = t_tk_str_byTk['ticker'].values, columns = t_tk_str_byTk['ticker'].values)
    t_pct_overlap.values[[np.arange(t_pct_overlap.shape[0])]*2] = np.nan
    
    t_sum1 = t_pct_overlap.mean(axis = 1)
    t_sum1 = t_sum1.reset_index()
    t_sum1.columns = ['ticker','pct_overlap']
    
    t_sum = t_sum1.copy()
    t_sum['datadate'] = dt
    
    yu.toc()
    o_pct_overlap.append(t_sum)
    
o_pct_overlap = pd.concat(o_pct_overlap, axis = 0)
o_pct_overlap.to_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_jobTitle_pct_overlap.parquet')




### combine 


icom = pd.merge_asof(i_sd, o_pct_overlap, by='ticker', on='datadate')

icom = icom.sort_values(['ticker','datadate'])

icom['pct_overlap_bk'] = icom.groupby('datadate')['pct_overlap'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['pct_overlap_rk'] = icom.groupby('datadate')['pct_overlap'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['pct_overlap_bk'], 'pct
_overlap') # random

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['pct_overlap_orth'] = icom.groupby('datadate')[COLS+['pct_overlap']].apply(lambda x: yu.orthogonalize_cn(x['pct_overlap'], x[COLS])).values
icom['pct_overlap_orth_bk'] = icom.groupby('datadate')['pct_overlap_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['pct_overlap_orth_rk'] = icom.groupby('datadate')['pct_overlap_orth'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['pct_overlap_orth_bk'], 'pct_overlap_orth') # ransom

    
icom['orth_neg_sgnl'] = np.nan
icom.loc[icom['pct_overlap_orth_rk']<-0.8, 'orth_neg_sgnl']  = -1
icom['orth_neg_sgnl'] = icom.groupby('ticker')['orth_neg_sgnl'].ffill(limit=5)


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['orth_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'orth_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['csi300_flag']==1)].\
            dropna(subset=['orth_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'orth_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

