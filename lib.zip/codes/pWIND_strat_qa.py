﻿#$%^&* pWIND_strat_qa.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 30 10:44:48 2021

@author: thzhang
"""


import pWIND_util as pw
from pWIND_util import get_china_sd
from yz.util import get_sql, uniformed_rank, bt_cn, ols_beta

import pandas as pd
import numpy as np
import datetime

# get sd
i_sd = get_china_sd()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP+0d', 'BarrRet_CLIP+1d','BarrRet_SRISK+1d','RawRet+1d','fxRet_SRISK+1d','fxRet_CLIP+1d','isin_hk_uni']]

# get qa
i_qa = pw.get_wind_online_qa()
i_qa['s_askdate'] = pd.to_datetime(i_qa['s_askdate'], format = '%Y%m%d')

i_qa.loc[i_qa['s_answerdate'].isnull(),'s_answerdate'] = 'NaT'
i_qa['s_answerdate'] = pd.to_datetime(i_qa['s_answerdate'], format = '%Y%m%d')



# get PIT response time 

o_qa = pd.DataFrame()

for d in pd.date_range(start = '2013-03-01', end = '2021-03-31'):
    d_str = d.strftime('%Y%m%d')
    print (d_str, end= ',')
    
    t_qa = i_qa[(i_qa['s_askdate']<=d_str) & (i_qa['s_askdate']>=d-pd.to_timedelta('91 days'))]
    t_qa.loc[t_qa['s_answerdate']>d_str,'s_answerdate'] = pd.NaT
    t_qa['response_days'] = (t_qa['s_answerdate'] - t_qa['s_askdate']).dt.days
    t_grp = t_qa.groupby('ticker')['response_days'].agg(['count', 'mean', lambda x: x.isnull().sum()])
    t_grp = t_grp.reset_index().rename(columns={'<lambda>':'not_answered', 'mean': 'mean_response_days','count': 'total_q'})
    t_grp['datadate'] = d
    
    o_qa = o_qa.append(t_grp, ignore_index = True)
    
o_qa.to_parquet(r'S:\Data\China Data Hunt\cache\pWIND_strat_qa_pit.parquet')
o_qa = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_strat_qa_pit.parquet')

# combine

icom = i_sd_map.merge(o_qa, on = ['ticker', 'datadate'], how = 'left')


icom = icom.merge(i_sd[['ticker','datadate','SIZE']], on = ['datadate','ticker'], how = 'left')
icom['SIZE_bk'] = icom.groupby('datadate')['SIZE'].apply(lambda x: pd.qcut(x,q=10,labels=range(10))).values

i_sd['turnover'] = i_sd['avgPVadj'].divide(i_sd['MC_l1d'])
icom = icom.merge(i_sd[['ticker','datadate','turnover']], on = ['datadate','ticker'], how = 'left')

i_sd = i_sd.sort_values(['ticker', 'datadate'])
i_sd['BarrRet_CLIP_t60d'] = i_sd.groupby('ticker').rolling(60)['BarrRet_CLIP-1d'].apply(lambda x: (x+1).prod()-1).values
icom = icom.merge(i_sd[['ticker','datadate','BarrRet_CLIP_t60d']], on = ['datadate','ticker'], how = 'left')
icom['BarrRet_CLIP_t60d_rk'] = icom.groupby('datadate')['BarrRet_CLIP_
t60d'].apply(lambda x: uniformed_rank(x)).values



#------------------------------------------------------------------------------
### backtest 

### un-answered questions
icom2 = icom.copy()

icom2['unanswered_pct'] = icom2['not_answered'].divide(icom2['total_q'])
icom2['unanswered_pct'] = icom2['unanswered_pct'].replace(np.inf, np.nan).replace(-np.inf, np.nan)


o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['unanswered_pct','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'unanswered_pct','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs -0.29


### response days rank

icom2 = icom.copy()
icom2['response_days_rk'] = icom2.groupby('datadate')['mean_response_days'].apply(lambda x: uniformed_rank(x)).values

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['response_days_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'response_days_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.03


### total questions asked 

icom2 = icom.copy()
icom2['total_q_rk'] = icom2.groupby('datadate')['total_q'].apply(lambda x: uniformed_rank(x)).values

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['total_q_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'total_q_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 1.91


o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['total_q_rk'].abs()>0.9)].\
            dropna(subset=['total_q_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'total_q_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 1.38


o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['total_q_rk']>0.9)].\
            dropna(subset=['total_q_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'total_q_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.72

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['total_q_rk']<-0.9)].\
            dropna(subset=['total_q_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'total_q_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.87


### residual questions

icom2 = icom.copy()

o_resid_df = pd.DataFrame()

for d in pd.date_range(start=icom2.datadate.min()+pd.to_timedelta('365 days'), end = icom2.d
atadate.max()):
    print(d, end=',')
    t_data = icom2[(icom2['datadate']>=d-pd.to_timedelta('365 days'))&(icom2['datadate']<d)]
    t_data_today = icom2[(icom2['datadate']==d)]
    ols_qa_beta = ols_beta(t_data[['SIZE','turnover','BarrRet_CLIP_t60d_rk']].values,t_data['total_q'].values)
    t_data_today['residual_q'] = t_data_today['total_q'] - ols_qa_beta[0] - t_data_today['SIZE']*ols_qa_beta[1] - t_data_today['turnover']*ols_qa_beta[2] - t_data_today['BarrRet_CLIP_t60d_rk']*ols_qa_beta[3]
    t_data_today = t_data_today[t_data_today['residual_q'].notnull()]
    o_resid_df = o_resid_df.append(t_data_today, ignore_index = True)

icom2 = icom2.merge(o_resid_df[['ticker','datadate','residual_q']], on = ['datadate', 'ticker'], how = 'left')

icom2['residual_q_rk'] = icom2.groupby('datadate')['residual_q'].apply(lambda x: uniformed_rank(x)).values

o_1 = bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
            dropna(subset=['residual_q_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'residual_q_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs  1.55 / 1.12

