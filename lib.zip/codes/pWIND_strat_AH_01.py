﻿#$%^&* pWIND_strat_AH_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 12 14:56:10 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

# this studies the institutional flow for A+H shares
# next: A+H price difference 



### get sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['ticker', 'datadate'])
i_sd['V_t30d'] = i_sd.groupby('ticker').rolling(30)['V_l1d'].mean().values

i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','a50_300_flag','a50_flag','csi300_flag']]

i_sd_map_300 =i_sd_map[i_sd_map['csi300_flag']==1]


### get A+H mapping

i_ah_map = yu.get_sql('''select s_info_windcode as ticker, s_info_windcod2 as ticker_hk,
                      s_info_name as name  
                      from wind.dbo.SHSZRelatedsecurities''')


### HK: participant holding
# 国际中介机构持股数量 IAGENCYT_HOLDER_QUANTITY

i_holding = yu.get_sql('''select * from wind.dbo.HKShareAgencyHoldings ''')
i_holding['datadate'] = pd.to_datetime(i_holding['TRADE_DT'],format='%Y%m%d')
i_holding = i_holding.drop(columns=['TRADE_DT'])
i_holding = i_holding.rename(columns={'S_INFO_WINDCODE':'ticker_hk'})

### HK: 未平仓卖空量

i_si = yu.get_sql('''select s_info_windcode as ticker_hk, trade_dt as datadate,
                  unflat_short_interest as si_shares, unflat_short_selling_amount as si_amt 
                  from wind.dbo.HKShareUnsoldShortsale''')
i_si['datadate'] = pd.to_datetime(i_si['datadate'], format='%Y%m%d')




### HK: 卖空成交量
# 35001000 = 全日卖空量 confirmed
# 35002000 = 上午卖空量 confirmed

i_short_v = yu.get_sql('''select s_info_windcode as ticker_hk, trade_dt as datadate,
                       s_ss_volume as sv_allday, s_ss_turnover as spv_allday 
                       from wind.dbo.HKSHARESHORTSELLINGTURNOVER
                       where s_info_datatype = 350001000 ''')
i_short_v['datadate'] = pd.to_datetime(i_short_v['datadate'], format='%Y%m%d')

i_short_v2 = yu.get_sql('''select s_info_windcode as ticker_hk, trade_dt as datadate,
                       s_ss_volume as sv_am, s_ss_turnover as spv_am 
                       from wind.dbo.HKSHARESHORTSELLINGTURNOVER
                       where s_info_datatype = 350002000 ''')
i_short_v2['datadate'] = pd.to_datetime
(i_short_v2['datadate'], format='%Y%m%d')

i_short_v = i_short_v.merge(i_short_v2, on=['ticker_hk','datadate'], how='outer')






### HK calendar

i_cal = yu.get_sql('''select trade_days as datadate 
                   from wind.dbo.HKEXCalendar 
                   where S_INFO_EXCHMARKET = 'HKEX' 
                   order by trade_days ''')
i_cal['datadate'] = pd.to_datetime(i_cal['datadate'], format='%Y%m%d')
i_cal['datadate_p1d'] = i_cal['datadate'].shift(-1)
i_cal['datadate_p2d'] = i_cal['datadate'].shift(-2)


### HK return

i_ret = yu.get_sql('''select s_info_windcode as ticker_hk, trade_dt as datadate,
                   case when S_DQ_ADJPRECLOSE!=0 then S_DQ_ADJCLOSE/S_DQ_ADJPRECLOSE-1 else null end as ret 
                   from wind.dbo.HKshareEODPrices''')
i_ret['datadate'] = pd.to_datetime(i_ret['datadate'], format= '%Y%m%d')
i_ret = i_ret.sort_values(['ticker_hk','datadate'])
i_ret['ret_allrk'] = i_ret.groupby('datadate')['ret'].apply(yu.uniformed_rank).values


### HK SO
i_so = yu.get_sql('''select s_info_windcode as ticker_hk, financial_trade_dt as datadate,
                  FLOAT_A_SHR_TODAY*10000 as float_so 
                  from wind.dbo.HKShareEODDerivativeIndex''')
i_so['datadate'] = pd.to_datetime(i_so['datadate'], format='%Y%m%d')


### combine - all HK

icomhk = i_ret.merge(i_short_v, on = ['ticker_hk','datadate'], how = 'left')
icomhk = icomhk.merge(i_si, on = ['ticker_hk','datadate'], how = 'left')
icomhk = icomhk.merge(i_so, on = ['ticker_hk','datadate'], how = 'left')
icomhk = icomhk.merge(i_holding, on = ['ticker_hk','datadate'], how = 'left')
icomhk = icomhk.merge(i_ah_map, on = 'ticker_hk', how = 'left')
icomhk = icomhk.merge(i_sd_map, on = ['ticker','datadate'], how = 'left')

icomhk = icomhk.sort_values(['ticker_hk', 'datadate'])

icomhk['iagencyFlow'] = icomhk.groupby('ticker_hk')['IAGENCYT_HOLDER_QUANTITY'].apply(lambda x: x-x.shift()).values
icomhk['iagencyPct_dv_so'] = icomhk['IAGENCYT_HOLDER_QUANTITY'].divide(icomhk['float_so'])
icomhk['iagencyFlow_dv_so'] = icomhk['iagencyFlow'].divide(icomhk['float_so'])
icomhk['iagencyFlow_dv_so'] = icomhk['iagencyFlow_dv_so'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
icomhk['iagencyFlow_dv_so_bk'] = icomhk.groupby('datadate')['iagencyFlow_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomhk['iagencyFlow_dv_so_t5d'] = icomhk.groupby('ticker_hk').rolling(5)['iagencyFlow_dv_so'].mean().values
icomhk['iagencyFlow_dv_so_t20d'] = icomhk.groupby('ticker_hk').rolling(20)
['iagencyFlow_dv_so'].mean().values

icomhk['ret_allrk_p1d'] = icomhk.groupby('ticker_hk')['ret_allrk'].shift(-1).values
icomhk['ret_allrk_p2d'] = icomhk.groupby('ticker_hk')['ret_allrk'].shift(-2).values

icomhk[icomhk.ticker.notnull()].groupby('iagencyFlow_dv_so_bk')['BarrRet_CLIP_USD+1d'].mean().plot()
icomhk.groupby('iagencyFlow_dv_so_bk')['ret_allrk_p2d'].mean().plot()
yu.create_cn_3x3(icomhk, ['iagencyFlow_dv_so_bk'], 'iagencyFlow_dv_so')


### combine - AH universe 

icomhk = i_ret.merge(i_ah_map, on = ['ticker_hk'], how = 'inner')
icomhk = icomhk.merge(i_short_v, on = ['ticker_hk','datadate'], how = 'left')
icomhk = icomhk.merge(i_si, on = ['ticker_hk','datadate'], how = 'left')
icomhk = icomhk.merge(i_so, on = ['ticker_hk','datadate'], how = 'left')
icomhk = icomhk.merge(i_holding, on = ['ticker_hk','datadate'], how = 'left')
icomhk = icomhk.merge(i_sd_map, on = ['ticker','datadate'], how = 'left')

icomhk = icomhk.sort_values(['ticker_hk', 'datadate'])

icomhk['iagencyFlow'] = icomhk.groupby('ticker_hk')['IAGENCYT_HOLDER_QUANTITY'].apply(lambda x: x-x.shift()).values
icomhk['iagencyPct_dv_so'] = icomhk['IAGENCYT_HOLDER_QUANTITY'].divide(icomhk['float_so'])
icomhk['iagencyFlow_dv_so'] = icomhk['iagencyFlow'].divide(icomhk['float_so'])
icomhk['iagencyFlow_dv_so_bk'] = icomhk.groupby('datadate')['iagencyFlow_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomhk['iagencyFlow_dv_so_t5d'] = icomhk.groupby('ticker_hk').rolling(5)['iagencyFlow_dv_so'].mean().values
icomhk['iagencyFlow_dv_so_t20d'] = icomhk.groupby('ticker_hk').rolling(20)['iagencyFlow_dv_so'].mean().values

yu.create_cn_3x3(icomhk, ['iagencyFlow_dv_so_bk'], 'iagencyFlow_dv_so')

