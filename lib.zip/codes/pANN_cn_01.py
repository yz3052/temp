﻿#$%^&* pANN_cn_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 18 20:01:23 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime

import os


### sd 

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])


### sd stable shortable 

i_sd_ss = pw.get_china_ss_sd()


### tdate calendar

i_td = yu.get_sql_prod('''select datadate as impact_cdate, tradedate_next from cndbprod.dbo.Calendar_Dates_CN
                     order by datadate''')

i_td2 = yu.get_sql_prod('''select distinct tradedate_next as tdate from cndbprod.dbo.Calendar_Dates_CN
                        order by tradedate_next ''')


### get wind news 

i_news = pw.get_wind_news_v2()

i_news['datadate'] = pd.to_datetime((i_news['publishts'] - pd.to_timedelta('4 hours')).dt.date)



### get china scope

#i_company = pd.read_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\company.parquet',
#                            columns = ['stockCode','newsId','relevance'])
#i_company = i_company[i_company['stockCode'].str.contains('\d{6}') &\
#                      i_company['stockCode'].str.contains('S[HZ]') &\
#                      i_company['stockCode'].str[0].isin(['0','3','6']) ]
#i_company['ticker'] = i_company['stockCode'].str.split('_').str[0]+'.'+i_company['stockCode'].str.split('_').str[1]
#i_company = i_company.drop(columns=['stockCode'])
#i_company = i_company.drop_duplicates(subset = ['ticker','newsId'])
#
#          
#i_info = pd.read_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\info.parquet',
#                         columns = ['newsId','newsTs','newsTitle_cn','newsSummary','relevance','emotionDetail'])
#i_info = i_info.drop_duplicates()
#
#
#i_news_com = i_company.merge(i_info, on = ['newsId'], how = 'left')
#i_news_com['datadate'] = pd.to_datetime(pd.to_datetime(i_news_com['newsTs']).dt.date)+pd.to_timedelta('1 day')
#i_news_com['emotionDetail_dict'] = i_news_com['emotionDetail'].apply(lambda x: eval(x.replace('=',':')))
#i_news_com['emo_pos'] = i_news_com['emotionDetail_dict'].apply(lambda x: x[1])
#i_news_com['emo_neg'] = i_news_com['emotionDetail_dict'].apply(lambda x: x[2])
#i_news_com['emo_neu'] = i_news_com['emotionDetail_dict'].apply(lambda x: x[0])
#i_news_com['emo_net'] = i_news_com['emo_pos'] - i_news_com['emo_neg']
#i_news_com['emo_netV2'] = (i_news_com['emo_pos'] - i_news_com['emo_neg'])*(i_news_com['emo_pos'] + i_news_com['emo_neg'])



### get ann
# based on manual 
inspection at 9:15 am Shanghai, data delayed for a max of 1 hour 

i_files = os.listdir(r'S:\TZ\China Data Hunt\ann_em')
i_ann = pd.concat([pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\ann_em', i)) for i in i_files], sort=False)

i_ann['eiTime'] = pd.to_datetime(i_ann['eiTime'], format = '%Y-%m-%d %H:%M:%S:%f', errors='coerce')
i_ann['datadate'] = pd.to_datetime((i_ann['eiTime'] - pd.to_timedelta('3 hours')).dt.date)
i_ann['notice_date'] = pd.to_datetime(i_ann['notice_date'])

i_ann = i_ann.drop(columns = [ 'title_ch', 'new_column_code', 'notice_date'])

c_sh = i_ann['ticker'].str[0].isin(['6'])
c_sz = i_ann['ticker'].str[0].isin(['0','3'])
i_ann.loc[c_sh, 'ticker'] = i_ann.loc[c_sh, 'ticker']+ '.SH'
i_ann.loc[c_sz, 'ticker'] = i_ann.loc[c_sz, 'ticker']+ '.SZ'

c1 = i_ann['eiTime'].dt.strftime('%H%M')<='1450'
c2 = i_ann['eiTime'].dt.strftime('%H%M')>'1450'
i_ann.loc[c1, 'impact_cdate'] = pd.to_datetime(i_ann.loc[c1, 'eiTime'].dt.date)
i_ann.loc[c2, 'impact_cdate'] = pd.to_datetime(i_ann.loc[c2, 'eiTime'].dt.date) + pd.to_timedelta('1 day')
i_ann = i_ann.merge(i_td, on = 'impact_cdate', how = 'left')
i_ann = i_ann.rename(columns = {'tradedate_next': 'impact_tdate'})

i_ann = i_ann[['art_code', 'eiTime', 'title', 'ann_type_cide', 'ann_type_desc',
               'ticker', 'datadate', 'impact_cdate', 'impact_tdate']]


### loop for t1m metrics 

o_ann = []

for dt in pd.date_range(start = '2017-01-01', end = '2021-12-31'):
    print('.',end='')
    t_ann = i_ann[(i_ann['datadate']<=dt) & (i_ann['datadate']>=dt-pd.to_timedelta('28 days'))]
    
    # t1q cnt
    s_ann = t_ann.groupby('ticker')['art_code'].nunique().reset_index()
    s_ann = s_ann.rename(columns = {'art_code': 'ann_cnt_t1q'})
        
    s_ann['datadate'] = dt
    o_ann.append(s_ann)

o_ann = pd.concat(o_ann, axis = 0)

# o_ann.to_parquet(r'S:\Data\China Data Hunt\cache\pANN_cn_01_t1m_metrics.parquet')



### loop for t1q metrics 

o_ann = []

for dt in pd.date_range(start = '2017-01-01', end = '2021-12-31'):
    print('.',end='')
    t_ann = i_ann[(i_ann['datadate']<=dt) & (i_ann['datadate']>=dt-pd.to_timedelta('91 days'))]
    
    # t1q cnt
    s_ann = t_ann.groupby('ticker')['art_code'].nunique().reset_index()
    s_ann = s_ann.rename(columns = {'art_code': 'ann_cnt_t1q'})
        
    s_ann['datadate'] = dt
    o_ann.append(s_ann)

o_ann = pd.concat(o_ann, axis = 0)

### loop for daily metrics 

o_ann_2 = []

for dt in pd.date_range(start = '2017-01-01', end = '2021-12-31'):
    
print('.',end='')
    t_ann = i_ann[(i_ann['impact_tdate']==dt)]
    
    s0 = t_ann.groupby('ticker')['art_code'].count()
    s0 = s0.reset_index()
    s0 = s0.rename(columns={'art_code':'ann_cnt'})
    
    s1 = t_ann.groupby('ticker')['ann_type_desc'].apply(lambda x: (x=='其他').any())
    s1 = s1.reset_index()
    s1 = s1.rename(columns={'ann_type_desc':'flg_has_any_others'})
    
    s2 = t_ann.groupby('ticker')['ann_type_desc'].apply(lambda x: (x=='其他').any())
    s2 = s2.reset_index()    
    s2 = s2.rename(columns={'ann_type_desc':'flg_has_all_others'})
        
    s_ann = s0.merge(s1, on = 'ticker', how = 'outer')        
    s_ann = s_ann.merge(s2, on = 'ticker', how = 'outer')        
    s_ann['impact_tdate'] = dt
    o_ann_2.append(s_ann)

o_ann_2 = pd.concat(o_ann_2, axis = 0)



### loop for daily metrics 

o_ann_3 = []

for dt in pd.date_range(start = '2017-01-01', end = '2021-12-31'):
    print('.',end='')
    
    # select all news that might have impacted stock price today
    prev_tdate_1430 = i_td2['tdate'][i_td2['tdate']<dt].max().strftime('%Y%m%d')+' 14:30:00'
    t_news = i_news[(i_news['publishts']>=prev_tdate_1430) & (i_news['datadate']<=dt)]
    
    t_ann = i_ann[(i_ann['impact_tdate']==dt)]
    
    s_news = t_news.groupby('ticker').agg({'object_id':'nunique','sentiment_score':'mean'})
    s_news.columns = ['wind_news_cnt', 'wind_sentiment']
    s_news = s_news.reset_index()
    
    s_ann = t_ann.groupby('ticker')['art_code'].nunique()
    s_ann = s_ann.reset_index()
    s_ann.columns = ['ticker', 'ann_cnt']
    
    s = s_news.merge(s_ann, on = 'ticker', how = 'outer')
    s['datadate'] = dt
    
    o_ann_3.append(s)

o_ann_3 = pd.concat(o_ann_3, axis = 0)



#------------------------------------------------------------------------------
### combine 2K
#------------------------------------------------------------------------------



#icom = i_sd.merge(o_ann_2, left_on = ['ticker', 'datadate'], right_on = ['ticker', 'impact_tdate'], how = 'left')
icom = i_sd.merge(o_ann_3, left_on = ['ticker', 'datadate'], right_on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])


# t1q ann cnt

icom['ann_cnt_t1q_bk'] = icom.groupby('datadate')['ann_cnt_t1q'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['ann_cnt_t1q_bk'], 'ann_cnt_t1q') # some ngeative relationship, but low tstat

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(
subset=['sgnl_l_preed','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_l_preed','BarrRet_CLIP_USD+1d', static_data = i_sd) # 


# ann-driven big movements

icom['bbret_rk']=icom.groupby('datadate')['BarrRet_SRISK_USD-1d'].apply(yu.uniformed_rank)

icom['flg_big_up'] = np.nan
icom.loc[(icom['bbret_rk']>0.8)&(icom['RawRet_USD-1d']>0.05), 'flg_big_up'] = 1

icom['flg_big_dn'] = np.nan
icom.loc[(icom['bbret_rk']<-0.8)&(icom['RawRet_USD-1d']<-0.05), 'flg_big_dn'] = 1

yu.create_cn_decay(icom, 'flg_big_up') # random
yu.create_cn_decay(icom[icom['flg_has_all_others']==1], 'flg_big_up') # a little bit momentum
yu.create_cn_decay(icom, 'flg_big_dn') # reversal obvious
yu.create_cn_decay(icom[icom['flg_has_all_others']==1], 'flg_big_dn') # less reversal
yu.create_cn_decay(icom[icom['ann_cnt'].isnull()], 'flg_big_dn') # 


icom['sgnl_big_dn_woann'] = np.nan
c1 = icom['ann_cnt'].isnull()
c2 = (icom['bbret_rk']<-0.8)&(icom['RawRet_USD-1d']<-0.05)&(icom['RawRet_USD-1d']>-0.09)
icom.loc[c1 & c2, 'sgnl_big_dn_woann'] = 1
icom['sgnl_big_dn_woann'] = icom.groupby('ticker')['sgnl_big_dn_woann'].ffill(limit=10)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_big_dn_woann','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_big_dn_woann','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.81 / -1.25

t1 = o_1.groupby('ticker')['pnl_bc'].sum().sort_values()
o_1[o_1.ticker=='002506.SZ'].set_index('datadate')['pnl_ac'].cumsum().plot()
301071
t1 = i_ann[i_ann.ticker.str.contains('301071')]
t1 = icom[icom.ticker=='002506.SZ']
t2 = o_1[o_1.ticker=='002506.SZ']


icom['sgnl_big_dn_wann'] = np.nan
c1 = (icom['ann_cnt']>=1) & (icom['flg_has_all_others']!=1)
c2 = (icom['bbret_rk']<-0.8)&(icom['RawRet_USD-1d']<-0.05)
icom.loc[c1 & c2, 'sgnl_big_dn_wann'] = 1
icom['sgnl_big_dn_wann'] = icom.groupby('ticker')['sgnl_big_dn_wann'].ffill(limit=10)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_big_dn_wann','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_big_dn_wann','BarrRet_CLIP_USD+1d', static_data = i_sd) # -0.55 / -1.68


# big moves without any news / ann


icom['bbret_rk']=icom.groupby('datadate')['BarrRet_SRISK_USD-1d'].apply(yu.uniformed_rank)

icom['flg_big_up'] = np.nan
icom.loc[(icom['bbret_rk']>0.8)&(icom['RawRet_USD-1d']>0.05), 'flg_big_
up'] = 1

icom['flg_big_dn'] = np.nan
icom.loc[(icom['bbret_rk']<-0.8)&(icom['RawRet_USD-1d']<-0.05), 'flg_big_dn'] = 1

icom['flg_no_news_ann'] = np.nan
c1 = icom['ann_cnt'].isnull() & icom['wind_news_cnt'].isnull()
icom.loc[c1, 'flg_no_news_ann'] = 1

yu.create_cn_decay(icom[icom['flg_no_news_ann']==1], 'flg_big_up') 
yu.create_cn_decay(icom[icom['flg_no_news_ann']==1], 'flg_big_dn') 


t1 = icom[(icom['flg_no_news_ann']==1)&(icom['flg_big_up']==1)] 
t2 = icom[(icom['ticker']=='603920.SH')][['ticker','datadate','BarrRet_CLIP_USD-1d','RawRet_USD-1d','sgnl_big_up_wonews']]

# 0000001.SZ 2021.10.11 避免全板块带领的上涨，上涨需要破位而不是快速震荡


icom.loc[(icom['flg_no_news_ann']==1)&(icom['flg_big_up']==1), 'sgnl_big_up_wonews'] = 1
icom['sgnl_big_up_wonews'] = icom.groupby('ticker')['sgnl_big_up_wonews'].ffill(limit=10)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl_big_up_wonews','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_big_up_wonews','BarrRet_CLIP_USD+1d', static_data = i_sd)

t3 = o_1.groupby('ticker')['pnl_ac'].sum().sort_values()

