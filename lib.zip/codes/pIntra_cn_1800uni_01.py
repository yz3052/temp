﻿#$%^&* pIntra_cn_1800uni_01.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 13 03:28:27 2023

@author: thzhang
"""

import pandas as pd
import numpy as np

import os
import util as yu
import util_intra as yui

from multiprocessing import Pool


### get sd 

i_sd = yui.get_intra_sd()





### get feature

if __name__=='__main__':
    
    root1 = '/dat/summit_capital/TZ/PROD_Q/q_intraday_trd_act/'
    with Pool(20) as pool:
        i_feat_act = pool.map(yui.get_feat_act, [root1+f for f in os.listdir(root1)])
    i_feat_act = pd.concat(i_feat_act, axis = 0)

if __name__=='__main__':
    
    root2 = '/dat/summit_capital/TZ/PROD_Q/q_intraday_trd_ls/'
    with Pool(20) as pool:
        i_feat_ls = pool.map(yui.get_feat_ls, [root2+f for f in os.listdir(root2)])
    i_feat_ls = pd.concat(i_feat_ls, axis = 0)

if __name__=='__main__':

    root3 = '/dat/summit_capital/TZ/PROD_Q/q_intraday_odbk_imb/'
    with Pool(20) as pool:
        i_feat_imb = pool.map(yui.get_feat_imb, [root3+f for f in os.listdir(root3)])
    i_feat_imb = pd.concat(i_feat_imb, axis = 0)



### combine


icom = i_sd.merge(i_feat_act, on = ['Ticker', 'tm1d', 'ts15m_s'], how = 'left')
icom = icom.merge(i_feat_ls, on = ['Ticker', 'tm1d', 'ts15m_s'], how = 'left')
icom = icom.merge(i_feat_imb, on = ['Ticker', 'tm1d', 'ts15m_s'], how = 'left')
icom = icom.sort_values(['Ticker', 'tm1d', 'ts15m_s']).reset_index(drop = True)


icom = icom[icom['volatility']>0.6]
icom['rawret_m15m_rk'] = icom.groupby(['tm1d','ts15m_e'])['rawret_m15m'].apply(yu.uniformed_rank)




#---- all signals combined


icom['askp_span_avg15m_rk'] = icom.groupby(['tm1d','ts15m_e'])['askp_span_avg15m'].apply(yu.uniformed_rank)
icom['bidp_span_avg15m_rk'] = icom.groupby(['tm1d','ts15m_e'])['bidp_span_avg15m'].apply(yu.uniformed_rank)
icom['bap_span_avg15m'] = np.nan
c1 = icom['rawret_m15m_rk'] >= 0.3
icom.loc[c1, 'bap_span_avg15m'] = - (icom.loc[c1, 'askp_span_avg15m_rk']+1)
c2 = icom['rawret_m15m_rk'] <= -0.3
icom.loc[c2, 'bap_span_avg15m'] = (icom.loc[c2, 'bidp_span_avg15m_rk']+1)
icom['bap_span_avg15m_bk'] = icom.groupby(['tm1d','ts15m_s'])['bap_span_avg15m'].apply(lambda x: yu.pdqcut(x, bins=10)).values
icom['bap_span_avg15m_sgnl'] = icom.groupby(['tm1d','ts15m_s'])['bap_span_avg15m'].apply(yu.uniformed_rank)

icom['nxlarge_dv_pv'] = (icom['buy_xlarge_sm15m'] - icom['sell_xlarge_sm15m']) / icom[['buy_all_sm15m','sell_all_sm15m']].mean(axis=1)
icom['nlarge_dv_pv'] = (icom['buy_large_sm15m'] - icom
['sell_large_sm15m']) / icom[['buy_all_sm15m','sell_all_sm15m']].mean(axis=1)
icom['n2large_dv_pv'] = icom['nxlarge_dv_pv'] + icom['nlarge_dv_pv']
icom['n2large_dv_pv_bk'] = icom.groupby(['tm1d', 'ts15m_e'])['n2large_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['n2large_dv_pv_sgnl'] = -icom.groupby(['tm1d', 'ts15m_e'])['n2large_dv_pv'].apply(yu.uniformed_rank)

icom['d_actB_nmsm15m'] = icom['d_actB_sm15m'] / icom['d_tot_sm15m']
icom['d_actS_nmsm15m'] = icom['d_actS_sm15m'] / icom['d_tot_sm15m']
icom['d_actN_nmsm15m'] = icom['d_actB_nmsm15m'] - icom['d_actS_nmsm15m']
icom['d_actN_nmsm15m_bk'] = icom.groupby(['tm1d','ts15m_s'])['d_actN_nmsm15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['d_actN_nmsm15m_sgnl'] = - icom.groupby(['tm1d','ts15m_s'])['d_actN_nmsm15m'].apply(yu.uniformed_rank)

icom['agg'] = icom[['bap_span_avg15m_sgnl', 'n2large_dv_pv_sgnl', 'd_actN_nmsm15m_sgnl']].mean(axis = 1, skipna = True)
icom['agg_bk'] = icom.groupby(['tm1d', 'ts15m_e'])['agg'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['agg_rk'] = icom.groupby(['tm1d', 'ts15m_e'])['agg'].apply(yu.uniformed_rank)
yui.plot_barchart_cn(icom, 'agg_bk', 'agg', col_ret = 'rawret_p15m_rk') # -440 +300


icom['agg_sgnl'] = np.nan
c1 = icom['agg_rk'].abs()>0.9
icom.loc[c1, 'agg_sgnl'] = icom.loc[c1, 'agg_rk']
icom['agg_sgnl_ff4'] = icom.groupby(['Ticker','tm1d'])['agg_sgnl'].ffill(limit = 4)
yui.plot_pnl_cn(icom, col_sgnl = 'agg_rk', col_ret = 'rawret_p15m')
yui.plot_pnl_cn(icom, col_sgnl = 'agg_sgnl', col_ret = 'rawret_p15m')
yui.plot_pnl_cn(icom, col_sgnl = 'agg_sgnl_ff4', col_ret = 'rawret_p15m') # ac very bad


yui.plot_barchart_cn(icom, 'bap_span_avg15m_bk', 'bap_span_avg15m', col_ret = 'rawret_p15m_rk') 
yui.plot_barchart_cn(icom, 'bap_span_avg15m_bk', 'bap_span_avg15m', col_ret = 'rawret_p15m') 
yui.plot_pnl_cn(icom[icom['bap_span_avg15m_sgnl'].abs().gt(0.99)], col_sgnl = 'bap_span_avg15m_sgnl', col_ret = 'rawret_p15m')


# why low rank cannot get translated to negative return 



#?

c1 = icom['bap_span_avg15m_bk'].eq(0)
icom.loc[c1,'rawret_p15m_rk'].mean()
icom.loc[c1,'rawret_p15m'].mean()

c2 = icom['bap_span_avg15m_bk'].eq(9)
icom.loc[c2,'rawret_p15m'].hist(bins=100)
icom.loc[c1,'rawret_p15m'].hist(bins=100)

#---- bar chart - active 

icom['d_actB_nmsm15m'] = icom['d_actB_sm15m'] / icom['d_tot_sm15m']
icom['d_actB_nmsm15m_bk'] = icom.groupby(['tm1d', 'ts15m_s'])['d_actB_nmsm15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['d_actB_nmsm60m'] = icom['d_a
ctB_sm60m'] / icom['d_tot_sm60m']
icom['d_actB_nmsm60m_bk'] = icom.groupby(['tm1d', 'ts15m_s'])['d_actB_nmsm60m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['d_actB_nmsmsod'] = icom['d_actB_sinceO'] / icom['d_tot_sinceO']
icom['d_actB_nmsmsod_bk'] = icom.groupby(['tm1d', 'ts15m_s'])['d_actB_nmsmsod'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['d_actS_nmsm15m'] = icom['d_actS_sm15m'] / icom['d_tot_sm15m']
icom['d_actN_nmsm15m'] = icom['d_actB_nmsm15m'] - icom['d_actS_nmsm15m']
icom['d_actN_nmsm15m_bk'] = icom.groupby(['tm1d','ts15m_s'])['d_actN_nmsm15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yui.plot_barchart_cn(icom, 'd_actN_nmsm15m_bk', 'd_actN_nmsm15m', col_ret = 'rawret_p15m_rk') # mono +84 -312

icom['d_actN_nmsm15m_rk'] = icom.groupby(['tm1d','ts15m_e'])['d_actN_nmsm15m'].apply(yu.uniformed_rank)
icom['d_actN_nmsm15m_sgnl'] = - icom['d_actN_nmsm15m_rk']
icom.loc[icom['d_actN_nmsm15m_sgnl'].abs()<0.98, 'd_actN_nmsm15m_sgnl'] = np.nan
icom['d_actN_nmsm15m_sgnl'] = icom.groupby(['Ticker','tm1d'])['d_actN_nmsm15m_sgnl'].ffill(8)
yui.plot_pnl_cn(icom, col_sgnl = 'd_actN_nmsm15m_sgnl', col_ret = 'rawret_p15m')
# 9.07 / 3.52 ###!!!



icom['d_actB_nmsmsod'] = icom['d_actB_sinceO'] / icom['d_tot_sinceO']
icom['d_actS_nmsmsod'] = icom['d_actS_sinceO'] / icom['d_tot_sinceO']
icom['d_actN_nmsmsod'] = icom['d_actB_nmsmsod'] - icom['d_actS_nmsmsod']
icom['d_actN_nmsmsod_rk'] = icom.groupby('tm1d')['d_actN_nmsmsod'].apply(yu.uniformed_rank)
icom['d_actN_nmsmsod_sgnl'] = - icom['d_actN_nmsmsod_rk']
icom.loc[icom['d_actN_nmsmsod_sgnl'].abs()<0.99, 'd_actN_nmsmsod_sgnl'] = np.nan
icom.loc[~icom['ts15m_e'].dt.strftime('%H%M').isin(['0945','1000','1015']), 'd_actN_nmsmsod_sgnl'] = np.nan
icom['d_actN_nmsmsod_sgnl'] = icom.groupby(['Ticker','tm1d'])['d_actN_nmsmsod_sgnl'].ffill()
yui.plot_pnl_cn(icom, col_sgnl = 'd_actN_nmsmsod_sgnl', col_ret = 'rawret_p15m')
# 4.9 / 0





#---- bar chart - ls

icom['sell_small_sm15m_pct'] = icom['sell_small_sm15m'] / icom['sell_all_sm15m']
icom['sell_small_sm15m_pct_bk'] = icom.groupby(['tm1d','ts15m_s'])['sell_small_sm15m_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'sell_small_sm15m_pct_bk', 'sell_small_sm15m_pct', col_ret = 'rawret_p15m_rk') # -ve mono
yui.plot_barchart_cn(icom, 'sell_small_sm15m_pct_bk', 'sell_small_sm15m_pct', col_ret = 'rawret_p15m') # 0 1.0 -1.8

icom['sell_small_sod_pct'] = icom['sell_small_sod'] / icom['sell_all_sod']
icom['sell_small_sod_pct_bk'] = icom.g
roupby(['tm1d','ts15m_s'])['sell_small_sod_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'sell_small_sod_pct_bk', 'sell_small_sod_pct', col_ret = 'rawret_p15m_rk') # -ve mono
yui.plot_barchart_cn(icom, 'sell_small_sod_pct_bk', 'sell_small_sod_pct', col_ret = 'rawret_p15m') # +0.5 +0.2

icom['buy_small_sm15m_pct'] = icom['buy_small_sm15m'] / icom['buy_all_sm15m']
icom['buy_small_sm15m_pct_bk'] = icom.groupby(['tm1d','ts15m_s'])['buy_small_sm15m_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'buy_small_sm15m_pct_bk', 'buy_small_sm15m_pct', col_ret = 'rawret_p15m_rk') # +ve mono
yui.plot_barchart_cn(icom, 'buy_small_sm15m_pct_bk', 'buy_small_sm15m_pct', col_ret = 'rawret_p15m') # -ve mono: +2.5 -0.6


# bar chart - ls
# its weired rawret_rk and rawret's relationship with the feature are opposite
# this is because alpha itself has negative correlation with past return

icom['net_small_sm15m'] = (icom['buy_small_sm15m']-icom['sell_small_sm15m']) / (icom['buy_all_sod'] + icom['sell_all_sod']) * 2
icom['net_small_sm15m_bk'] = icom.groupby(['tm1d','ts15m_s'])['net_small_sm15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yui.plot_barchart_cn(icom, 'net_small_sm15m_bk', 'net_small_sm15m', col_ret = 'rawret_p15m_rk') # +ve relation
yui.plot_barchart_cn(icom, 'net_small_sm15m_bk', 'net_small_sm15m', col_ret = 'rawret_p15m') # -ve relation
yui.plot_barchart_cn(icom, 'net_small_sm15m_bk', 'net_small_sm15m', col_ret = 'rawret_p15m_demean') # -ve relation



icom.loc[icom['clip15m'].lt(1e5) & icom['net_small_sm15m_bk'].eq(0), 'rawret_p15m'].mean() #-0.038
icom.loc[icom['clip15m'].lt(1e5) & icom['net_small_sm15m_bk'].eq(0), 'rawret_p15m_rk'].mean() #-0.0002

icom.loc[icom['clip15m'].gt(5e5) & icom['net_small_sm15m_bk'].eq(0), 'rawret_p15m'].mean() #0.0004
icom.loc[icom['clip15m'].gt(5e5) & icom['net_small_sm15m_bk'].eq(0), 'rawret_p15m_rk'].mean() #-0.0038


#!
icom.loc[icom['net_small_sm15m_bk'].eq(0), 'rawret_p15m'].hist(bins=100)
icom.loc[icom['net_small_sm15m_bk'].eq(0), 'rawret_p15m'].mean()
icom.loc[icom['net_small_sm15m_bk'].eq(9), 'rawret_p15m'].mean()
icom['net_small_sm15m_rk'] = icom.groupby(['tm1d','ts15m_s'])['net_small_sm15m'].apply(yu.uniformed_rank)
yui.plot_pnl_cn(icom, col_sgnl = 'net_small_sm15m_rk', col_ret = 'rawret_p15m')
#!


#---- bar chart - imb

icom['baratio_avg15m_bk'] = icom.groupby(['tm1d','ts15m_s'])['baratio_avg15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchar
t_cn(icom, 'baratio_avg15m_bk', 'baratio_avg15m', col_ret = 'rawret_p15m_rk') # random

icom['baratio_avg15m_rk'] = icom.groupby(['tm1d','ts15m_s'])['baratio_avg15m'].apply(yu.uniformed_rank)
icom['baratio_avg15m_sgnl2'] = np.nan
c1 = icom['baratio_avg15m_rk'].abs()>0.99
icom.loc[c1, 'baratio_avg15m_sgnl2'] = icom.loc[c1, 'baratio_avg60m_rk']
yui.plot_pnl_cn(icom, col_sgnl = 'baratio_avg15m_sgnl2', col_ret = 'rawret_p60m') 

icom['baratio_avg60m_rk'] = icom.groupby(['tm1d','ts15m_s'])['baratio_avg60m'].apply(yu.uniformed_rank)
icom['baratio_avg60m_sgnl2'] = np.nan
c1 = icom['baratio_avg60m_rk'].abs()>0.99
icom.loc[c1, 'baratio_avg60m_sgnl2'] = - icom.loc[c1, 'baratio_avg60m_rk']
yui.plot_pnl_cn(icom, col_sgnl = 'baratio_avg60m_sgnl2', col_ret = 'rawret_p60m') 
# 3.78 / -0.95



#---- bar chart - reversal
# 2023 very flat

icom['rawret_m15m_bk'] = icom.groupby(['tm1d','ts15m_e'])['rawret_m15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'rawret_m15m_bk', 'rawret_m15m', col_ret = 'rawret_p15m_rk') # a-shaped, right side high t

icom['rawret_sod_bk'] = icom.groupby(['tm1d','ts15m_e'])['rawret_sod'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'rawret_sod_bk', 'rawret_sod', col_ret = 'rawret_eod_rk') 

icom['rawret_sod_rk'] = icom.groupby(['tm1d','ts15m_s'])['rawret_sod'].apply(yu.uniformed_rank)
icom['rawret_sod_sgnl2'] = np.nan
c1 = icom['rawret_sod_rk'].abs().gt(0.99) & icom['ts15m_e'].dt.hour.ge(13)
icom.loc[c1, 'rawret_sod_sgnl2'] = - icom.loc[c1, 'rawret_sod_rk']
yui.plot_pnl_cn(icom, col_sgnl = 'rawret_sod_sgnl2', col_ret = 'rawret_eod') # 4.9/3.8, 2023 drawdown
