﻿#$%^&* featurepool_enrich_lib.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Oct  4 16:22:12 2022
@author: thzhang
"""


import pandas as pd
import numpy as np
import scipy.stats as ss

try:
    from numba import njit
except:
    raise Exception("Please install numba: pip install numba --proxy=proxy.mlp.com:3128")



def Rank2Uni(x,m=float('inf')):
    
    r = x.rank(method = 'min')
    rmax = r.max()
    if ~np.isfinite(m):
        r = r/(rmax+1)
        return r
    else:
        p = ss.norm.cdf(m)
        r = r/(rmax-1)
        r = r - (r.max()-1)
        r = (2*p-1)*r+(1-p)
        return r
        

def Winsorize(x,m):
    
    x[x>m]=m
    x[x<-m]=-m
    
    return x


def ZScore(x):
    
    z = (x-np.nanmean(x))/np.nanstd(x)
    
    return z


def rerank(r):
    # r is a Series
    
    rindex = r.index
    res = np.zeros(len(r))
    res = res + float('nan')
    x2 = np.array(r)
    x2 = x2[~np.isnan(x2)]
    x3 = list(x2)    
    x3.reverse()
    x3 = list(ss.rankdata(x3)-1)
    x3.reverse()
    if len(x2) > 0:
        res2 = -1 + 1/len(x2) *(ss.rankdata(x2) - 1  + np.array(x3))
        res[~np.isnan(np.array(r))] = res2
    rdf = pd.DataFrame(res)
    rdf = rdf.set_index(rindex)
    return rdf
    
    
def lbmd(x):
    # x is a Series
    
    try:
        x1 = x[x.notnull()]
    except:
        print(type(x))
        print(np.isnan(x).sum())
    
    x1_output = Winsorize(ss.norm.ppf(Rank2Uni(x1, 3)),3)
    
    output = pd.DataFrame([np.nan] * len(x), index = x.index)
    output.loc[x.notnull(), 0] = x1_output   
    
    return output[0].values
    

def zscore10(x):
    # this is for cross-sectional zscore x10
    # the input is a series
    
    x1 = (x - x.mean()) / x.std()
    x1 = x1.replace(np.inf, np.nan).replace(-np.inf, np.nan)
    
    for i in range(9):
        x1 = Winsorize(x1,3)
        x1 = (x1 - x1.mean()) / x1.std()
    
    x1 = Winsorize(x1,3)
    
    return pd.DataFrame(x1.values, index = x.index)



def orth(tgt_sr, factors_df, ind_df, w_sr):
                 
    # normalize y
    array_tgt = lbmd(tgt_sr)
    
    # process nan 
    c_no_nan = ~ (np.isnan(factors_df.values).any(axis=1) | np.isnan(ind_df.values).any(axis=1) | np.isnan(array_tgt) | np.isnan(w_sr.values))
    factors_notnan = pd.DataFrame(factors_df.values[c_no_nan])
    ind_notnan = ind_df.values[c_no_nan]
    y_notnan = array_tgt[c_no_nan]
    w_notnan = w_sr.values[c_no_nan]
    
    # if all nan ...
    if len(y_notnan) == 0:
        return pd
.Series([np.nan]* len(tgt_sr), index = tgt_sr.index).to_frame()
    
    # get x    
    ind_col_notnan = ind_notnan.sum(axis=0)>0
    ind_notnan = ind_notnan[:, ind_col_notnan]
    x_notnan = np.hstack([factors_notnan.apply(lbmd, axis = 0).values,ind_notnan])   
        
    # INVOMEGA
    S = w_notnan / 100.0 / np.sqrt(252)
    S = S**2
    INVOMEGA = np.diag(1/S)
    
    # WLS #1    
    res_ret_notnan = y_notnan - np.dot(x_notnan,np.dot(np.dot(np.dot(np.linalg.inv(np.dot(np.dot(np.transpose(x_notnan),INVOMEGA),x_notnan)),np.transpose(x_notnan)),INVOMEGA), y_notnan))
    res_ret_sr = pd.Series([np.nan]*len(tgt_sr), index = tgt_sr.index)
    res_ret_sr.loc[c_no_nan] = res_ret_notnan
    return res_ret_sr.to_frame()



@njit
def idxmax(arr):
    arr_reverse = arr[::-1]
    max_arr = np.max(arr[~np.isnan(arr)])
    for i in range(len(arr)):
        if arr_reverse[i] == max_arr:
            return i+1
@njit
def idxmin(arr):
    arr_reverse = arr[::-1]
    min_arr = np.min(arr[~np.isnan(arr)])
    for i in range(len(arr)):
        if arr_reverse[i] == min_arr:
            return i+1
        


def enrich_feature(icom, feature_name_str):
    # icom has the data for 1 day
    # require columns: feature_name_str
    # require columns from gem3l: industry binary cols, factor float cols
    # require columns from gemtr: industry binary cols, factor float cols
        
    icom[feature_name_str+'_winsor'] = lbmd(icom[feature_name_str])
    icom[feature_name_str+'_rk'] = rerank(icom[feature_name_str])
    icom[feature_name_str+'_zscore'] = zscore10(icom[feature_name_str])    
    icom = icom.assign(**{feature_name_str+'_raw': icom[feature_name_str].values})
    
    # gem3l
    cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']
    cols_i = ['AIRLINES','AUTOCOMP','BANKS','BIOTECH','CAPGOODS','CHEMICAL','COMMSVCS','COMMUNIC','COMPUTER','CONSDUR','CONSTPP','CONSVCS','DIVFINAN','DIVMETAL','ENERGY','FOODPRD','FOODRETL','HEALTH','HSHLDPRD','INSURAN','INTERNET','MEDIA','OILEXPL','OILGAS','PHARMAC','PRECMETL','REALEST','RETAIL','SEMICOND','SOFTWARE','STEEL','TELECOM','TRANSPRT','UTILITY']
    for typ in ['_winsor', '_rk', '_zscore', '_raw']:
        icom[feature_name_str+typ+'_orthgem3l'] = orth(icom[feature_name_str+typ], icom[cols_f], icom[cols_i], icom['SRISK']).values
    
    # gemtr 
    cols_f = ['BETA_gemtr','MOMENTUM_gemtr','SIZE_gemtr','EARNYILD_gemtr','RESVOL_gemtr','GROWTH_gemtr','DIVYILD
_gemtr','BTOP_gemtr','LEVERAGE_gemtr','LIQUIDTY_gemtr']
    cols_i = ['AEROSPCE_gemtr','AGROCHEM_gemtr','AIRLINES_gemtr','AUTOCOMP_gemtr','BANKS_gemtr','BIOTECH_gemtr','BLDCNSTR_gemtr','CAPMRKTS_gemtr','CHEMICAL_gemtr','COMMSVCS_gemtr','COMMUNIC_gemtr','COMPUTER_gemtr','CONSDUR_gemtr','CONSTPP_gemtr','CONSVCS_gemtr','DIVFIN_gemtr','DIVMETAL_gemtr','ENERGY_gemtr','FOODPRD_gemtr','FOODRETL_gemtr','GOLD_gemtr','HLTHEQP_gemtr','HLTHSVC_gemtr','HSHLDPRD_gemtr','INOILGAS_gemtr','INSURNCE_gemtr','INTERNET_gemtr','MACHINRY_gemtr','MEDIA_gemtr','OILEXPL_gemtr','OILGAS_gemtr','PHARMA_gemtr','PRECMETL_gemtr','REALEST_gemtr','RETAIL_gemtr','RGNLBNKS_gemtr','RLESTMNG_gemtr','SEMICOND_gemtr','SMICNDEQ_gemtr','SOFTWARE_gemtr','STEEL_gemtr','TELECOM_gemtr','TRNSPORT_gemtr','UTILITY_gemtr']
    for typ in ['_winsor', '_rk', '_zscore', '_raw']:
        icom[feature_name_str+typ+'_orthgemtr'] = orth(icom[feature_name_str+typ], icom[cols_f], icom[cols_i], icom['SRISK_gemtr']).values
    
    # output
    return icom

def enrich_feature_orth(icom, feature_name_str):
    # icom has the data for multiple day
    # require columns: feature_name_str
    # require columns from gem3l: industry binary cols, factor float cols
    # require columns from gemtr: industry binary cols, factor float cols
        
    icom[feature_name_str+'_winsor'] = icom.groupby('DataDate')[feature_name_str].apply(lbmd)
    icom[feature_name_str+'_rk'] = icom.groupby('DataDate')[feature_name_str].apply(rerank)
    icom[feature_name_str+'_zscore'] = icom.groupby('DataDate')[feature_name_str].apply(zscore10)
    icom = icom.assign(**{feature_name_str+'_raw': icom[feature_name_str].values})
    
    # gem3l
    cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']
    cols_i = ['AIRLINES','AUTOCOMP','BANKS','BIOTECH','CAPGOODS','CHEMICAL','COMMSVCS','COMMUNIC','COMPUTER','CONSDUR','CONSTPP','CONSVCS','DIVFINAN','DIVMETAL','ENERGY','FOODPRD','FOODRETL','HEALTH','HSHLDPRD','INSURAN','INTERNET','MEDIA','OILEXPL','OILGAS','PHARMAC','PRECMETL','REALEST','RETAIL','SEMICOND','SOFTWARE','STEEL','TELECOM','TRANSPRT','UTILITY']
    for typ in ['_winsor', '_rk', '_zscore', '_raw']:
        icom[feature_name_str+typ+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',feature_name_str+typ]+cols_f+cols_i].apply(lambda x: orth(x[feature_name_str+typ], x[cols_f], x[cols_i], x['SRISK'])).values
    
    # gemtr 
    cols_f = ['BETA_gemtr','MOMENTUM_gemtr','SI
ZE_gemtr','EARNYILD_gemtr','RESVOL_gemtr','GROWTH_gemtr','DIVYILD_gemtr','BTOP_gemtr','LEVERAGE_gemtr','LIQUIDTY_gemtr']
    cols_i = ['AEROSPCE_gemtr','AGROCHEM_gemtr','AIRLINES_gemtr','AUTOCOMP_gemtr','BANKS_gemtr','BIOTECH_gemtr','BLDCNSTR_gemtr','CAPMRKTS_gemtr','CHEMICAL_gemtr','COMMSVCS_gemtr','COMMUNIC_gemtr','COMPUTER_gemtr','CONSDUR_gemtr','CONSTPP_gemtr','CONSVCS_gemtr','DIVFIN_gemtr','DIVMETAL_gemtr','ENERGY_gemtr','FOODPRD_gemtr','FOODRETL_gemtr','GOLD_gemtr','HLTHEQP_gemtr','HLTHSVC_gemtr','HSHLDPRD_gemtr','INOILGAS_gemtr','INSURNCE_gemtr','INTERNET_gemtr','MACHINRY_gemtr','MEDIA_gemtr','OILEXPL_gemtr','OILGAS_gemtr','PHARMA_gemtr','PRECMETL_gemtr','REALEST_gemtr','RETAIL_gemtr','RGNLBNKS_gemtr','RLESTMNG_gemtr','SEMICOND_gemtr','SMICNDEQ_gemtr','SOFTWARE_gemtr','STEEL_gemtr','TELECOM_gemtr','TRNSPORT_gemtr','UTILITY_gemtr']
    for typ in ['_winsor', '_rk', '_zscore', '_raw']:
        icom[feature_name_str+typ+'_orthgemtr'] = icom.groupby('DataDate')[['SRISK_gemtr',feature_name_str+typ]+cols_f+cols_i].apply(lambda x: orth(x[feature_name_str+typ], x[cols_f], x[cols_i], x['SRISK_gemtr'])).values
    
    # output
    return icom


def enrich_feature_orth_simple(icom, feature_name_str):
    # icom has the data for multiple day
    # require columns: feature_name_str
    # require columns from gem3l: industry binary cols, factor float cols
    # require columns from gemtr: industry binary cols, factor float cols
        
    icom[feature_name_str+'_rk'] = icom.groupby('DataDate')[feature_name_str].apply(rerank)
    
    # gem3l
    cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']
    cols_i = ['AIRLINES','AUTOCOMP','BANKS','BIOTECH','CAPGOODS','CHEMICAL','COMMSVCS','COMMUNIC','COMPUTER','CONSDUR','CONSTPP','CONSVCS','DIVFINAN','DIVMETAL','ENERGY','FOODPRD','FOODRETL','HEALTH','HSHLDPRD','INSURAN','INTERNET','MEDIA','OILEXPL','OILGAS','PHARMAC','PRECMETL','REALEST','RETAIL','SEMICOND','SOFTWARE','STEEL','TELECOM','TRANSPRT','UTILITY']
    for typ in ['_rk']:
        icom[feature_name_str+typ+'_orthgem3l'] = icom.groupby('DataDate')[['SRISK',feature_name_str+typ]+cols_f+cols_i].apply(lambda x: orth(x[feature_name_str+typ], x[cols_f], x[cols_i], x['SRISK'])).values
    
    # output
    return icom
    


def enrich_feature_ts(i_desc, f):
    
    # this calculates MA 
    
    # i_desc has the data for multiple days
    # require Ticker amd T-1d columns
    # require a column
 for the feature name string: f
    # require columns from gem3l: industry binary cols, factor float cols
    # require columns from gemtr: industry binary cols, factor float cols
        
    # prep
    i_desc = i_desc.sort_values(['Ticker', 'T-1d'])
    i_desc = i_desc.reset_index(drop = True)   
    
    # 1. Rolling 5 day, 10 day, 21 day, 63 day, 126 day, 252 day average including today
    for i in [5, 10, 21, 63, 126, 252]:
        i_desc[f+'_ma'+str(i)+'d'] = i_desc.groupby('Ticker').rolling(i,min_periods=i//2)[f].mean().values
    
    # 2. Rolling 252 day average, standard deviation, max, min (not including today)    
    i_desc[f+'_sd252d'] = i_desc.groupby('Ticker').rolling(252,min_periods=252//2)[f].std().values
    i_desc[f+'_max252d'] = i_desc.groupby('Ticker').rolling(252,min_periods=252//2)[f].max().values
    i_desc[f+'_max252d'] = i_desc.groupby('Ticker')[f+'_max252d'].shift()
    i_desc[f+'_min252d'] = i_desc.groupby('Ticker').rolling(252,min_periods=252//2)[f].min().values
    i_desc[f+'_min252d'] = i_desc.groupby('Ticker')[f+'_min252d'].shift()
    
    # 3. Today’s zscore in trailing history (today’s value - rolling 252 day average) / rolling 252 day std
    i_desc[f+'_z252d'] = (i_desc[f] - i_desc[f+'_ma252d']).divide(i_desc[f+'_sd252d'])
    i_desc[f+'_z252d'] = i_desc[f+'_z252d'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
    
    # 4. Distinance of today’s value to rolling 252 day max/min: (today’s value - rolling 252 day max/min) 
    i_desc[f+'_d2max252d'] = i_desc[f] - i_desc[f+'_max252d']
    i_desc[f+'_d2min252d'] = i_desc[f] - i_desc[f+'_min252d']
    
    # 5. Time closeness of today’s value to rolling 252 day nearest max/min: unit is in trading days    
    i_desc[f+'_t2max252d'] = i_desc.groupby('Ticker').rolling(252,min_periods=252//2)[f].apply(idxmax, raw = True).values
    i_desc[f+'_t2max252d'] = i_desc.groupby('Ticker')[f+'_t2max252d'].shift()
    i_desc[f+'_t2min252d'] = i_desc.groupby('Ticker').rolling(252,min_periods=252//2)[f].apply(idxmax, raw = True).values
    i_desc[f+'_t2min252d'] = i_desc.groupby('Ticker')[f+'_t2min252d'].shift()
    
    
    # output
    return i_desc
    
    
    


    
    

def enrich_feature_ts_simple(i_desc, f):
    
    # this calculates MA 
    
    # i_desc has the data for multiple days
    # require Ticker amd T-1d columns
    # require a column for the feature name string: f
    # require columns from gem3l: industry binary cols, factor float cols
    # require columns 
from gemtr: industry binary cols, factor float cols
        
    # prep
    i_desc = i_desc.sort_values(['Ticker', 'T-1d'])
    i_desc = i_desc.reset_index(drop = True)   
    
    # 1. Rolling 5 day, 10 day, 21 day, 63 day, 126 day, 252 day average including today
    for i in [5, 21, 63]:
        i_desc[f+'_ma'+str(i)+'d'] = i_desc.groupby('Ticker').rolling(i,min_periods=i//2)[f].mean().values
    
    # 2. Rolling 252 day average, standard deviation, max, min (not including today)
    # 3. Today’s zscore in trailing history (today’s value - rolling 252 day average) / rolling 252 day std    
    # 4. Distinance of today’s value to rolling 252 day max/min: (today’s value - rolling 252 day max/min) 
    
    # 5. Time closeness of today’s value to rolling 252 day nearest max/min: unit is in trading days    
    i_desc[f+'_t2max252d'] = i_desc.groupby('Ticker').rolling(252,min_periods=252//2)[f].apply(idxmax, raw = True).values
    i_desc[f+'_t2max252d'] = i_desc.groupby('Ticker')[f+'_t2max252d'].shift()
    i_desc[f+'_t2min252d'] = i_desc.groupby('Ticker').rolling(252,min_periods=252//2)[f].apply(idxmax, raw = True).values
    i_desc[f+'_t2min252d'] = i_desc.groupby('Ticker')[f+'_t2min252d'].shift()
    
    
    # output
    return i_desc
    
    
    

