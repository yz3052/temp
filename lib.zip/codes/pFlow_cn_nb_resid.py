﻿#$%^&* pFlow_cn_nb_resid.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  5 16:42:11 2023

@author: thzhang
"""



import pandas as pd
import numpy as np

import datetime
import util as yu
import os


# this studies break up/dn that are dirven by hk bb flows .. no alpha



#---- sd 

i_sd = yu.get_sd_cn_1800()



#---- cal 

i_cal = yu.get_cn_cal()
i_cal = i_cal[['TradeDate_next']].sort_values('TradeDate_next').drop_duplicates()
i_cal = i_cal.rename(columns = {'TradeDate_next': 'DataDate'})
i_cal['T-1d'] = i_cal['DataDate'].shift()
i_cal = i_cal.dropna()





#---- return and v

i_ret = yu.get_sql_wind('''select substring(s_info_windcode,1,6) as Ticker,
                   trade_dt as [T-1d], s_dq_close as c, s_dq_adjclose as cadj, 
                   s_dq_adjclose / s_dq_adjpreclose - 1 as rawret,
                   s_dq_volume*100 as v
                   from wind_prod.dbo.ashareeodprices
                   where trade_dt > '20180101'                   
                   ''')
i_ret['T-1d'] = pd.to_datetime(i_ret['T-1d'], format = '%Y%m%d')

i_ret = i_ret.sort_values(['Ticker', 'T-1d'])
i_ret['cadj_max1y'] = i_ret.groupby('Ticker').rolling(datetime.timedelta(days=365),on='T-1d',min_periods=126)['cadj'].max().values
i_ret['cadj_min1y'] = i_ret.groupby('Ticker').rolling(datetime.timedelta(days=365),on='T-1d',min_periods=126)['cadj'].min().values



#---- future return

i_futret = pd.read_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800.parquet')
i_futret = i_futret[['Ticker', 'DataDate']]




#---- hk
# 'Ticker', 'hk_b_shares', 'hk_c_shares', 'hk_bb_shares', 'craw', 'float', 'flg_cndb_hk', 'DataDate'
root_hk = '/dat/summit_capital/PROD/TZ/hk_holding/'
files_hk = os.listdir(root_hk)
i_nb = pd.concat([pd.read_parquet(root_hk + f) for f in files_hk], axis = 0)
i_nb = i_nb.sort_values(['Ticker', 'DataDate']).reset_index(drop = True)
i_nb['hk_bb_diff'] = i_nb['hk_bb_shares'] - i_nb.groupby('Ticker')['hk_bb_shares'].shift()
i_nb['hk_bb_diff_dv_so'] = i_nb['hk_bb_diff'] / i_nb['float']
i_nb['hk_bb_dv_so'] = i_nb['hk_bb_shares'] / i_nb['float']

i_nb['hk_c_diff'] = i_nb['hk_c_shares'] - i_nb.groupby('Ticker')['hk_c_shares'].shift()
i_nb['hk_c_diff_dv_so'] = i_nb['hk_c_diff'] / i_nb['float']
i_nb['hk_c_dv_so'] = i_nb['hk_c_shares'] / i_nb['float']

i_nb['hk_b_diff'] = i_nb['hk_b_shares'] - i_nb.groupby('Ticker')['hk_b_shares'].shift()
i_nb['hk_b_diff_dv_so'] = i_nb['hk_b_diff'] / i_nb['float']
i_nb['hk_b_dv_so'] = i_nb['hk_b_
shares'] / i_nb['float']


# nb metrics - batch 1

i_nb_s2 = i_nb.merge(i_cal, on = 'DataDate', how = 'left')
i_nb_s2 = i_nb_s2.merge(i_ret[['Ticker', 'T-1d', 'rawret','v']], on = ['T-1d', 'Ticker'], how = 'left')
i_nb_s2 = i_nb_s2.sort_values(['Ticker', 'DataDate']).reset_index(drop = True)

t_corr = i_nb_s2.groupby('Ticker')[['rawret', 'hk_bb_diff_dv_so']].rolling(20,min_periods=15).corr()
i_nb_s2['corr_t1m'] = t_corr['rawret'].values.tolist()[1::2]
i_nb_s2['corr_t1m'] = i_nb_s2['corr_t1m'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
i_nb_s2.loc[i_nb_s2['corr_t1m']==0, 'corr_t1m'] = np.nan

i_nb_s2['hk_bb_dv_v'] = i_nb_s2['hk_bb_shares'] / i_nb_s2['v']










#------------------------------------------------------------------------------
#---- test: hk bb trading on the breakout
#------------------------------------------------------------------------------


icom = i_sd.merge(i_nb_s2, on = ['Ticker', 'T-1d','DataDate'], how = 'left')
icom = icom.merge(i_ret[['Ticker', 'T-1d', 'cadj', 'cadj_max1y', 'cadj_min1y']], 
                  on = ['Ticker', 'T-1d'], how = 'left')
icom = icom[icom['DataDate'].le('2021-12-31')]
icom = icom.sort_values(['Ticker', 'DataDate'])

icom['hk_bb_diff_dv_so_rk'] = icom.groupby('DataDate')['hk_bb_diff_dv_so'].apply(yu.uniformed_rank)




icom['sgnl'] = np.nan
c_break_up = icom['cadj'] == icom['cadj_max1y']
icom.loc[c_break_up & icom['hk_bb_diff_dv_so_rk'].gt(0.98), 'sgnl'] = 1
icom['sgnl'] = icom.groupby('Ticker')['sgnl'].ffill(limit=10)

o_1 = yu.bt_cn_15_linux(icom[(icom['DataDate'].between('2018-01-01','2021-12-30'))].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd)

    


icom['sgnl2'] = np.nan
c_break_dn = icom['cadj'] == icom['cadj_min1y']
icom.loc[c_break_dn & icom['hk_bb_diff_dv_so_rk'].lt(-0.98), 'sgnl2'] = -1
icom['sgnl2'] = icom.groupby('Ticker')['sgnl2'].ffill(limit=10)

o_1 = yu.bt_cn_15_linux(icom[(icom['DataDate'].between('2018-01-01','2021-12-30'))].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd)

