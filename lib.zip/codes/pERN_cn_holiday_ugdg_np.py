﻿#$%^&* pERN_cn_holiday_ugdg_np.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 18 14:22:15 2023

@author: thzhang
"""


import pandas as pd
import numpy as np

import datetime
import util as yu

import os


# this is a POC showing that pre-earning signals can also work pre-holiday


### get sd

i_sd = yu.get_sd_cn_1800()


### get ed

i_ed = yu.get_sql('''select DataDate, Ticker, d2nexted 
                  from cndbprod.dbo.static_data_t2000_gem3l''')

### get holidays

i_holi = yu.get_cn_holidays()

### get UGDG

root = '/dat/summit_capital/TZ/PROD_FEATURES/featurepool_cn_desc_suntime_ugdg_e/'
i_ugdg_files = os.listdir(root)
i_ugdg = pd.concat([pd.read_parquet(root + f) for f in i_ugdg_files], axis = 0)


### combine

icom = i_sd.merge(i_holi, on = ['DataDate', 'T-1d'], how = 'left')
icom = icom.merge(i_ugdg, on = ['DataDate', 'Ticker'], how = 'left')
icom = icom.merge(i_ed, on = ['DataDate', 'Ticker'], how = 'left')
icom = icom.sort_values(['Ticker', 'DataDate'])

icom['np_pct_up_t1q_rk'] = icom.groupby('DataDate')['np_pct_up_t1q'].apply(yu.uniformed_rank)

o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-06-01', '2021-12-31') &\
                             icom['d2nexted'].between(1,14)].\
            dropna(subset=['np_pct_up_t1q_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'np_pct_up_t1q_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)


o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-06-01', '2021-12-31') &\
                             icom['d2nexted'].between(1,7) &\
                             icom['np_pct_up_t1q_rk'].abs().gt(0.5) ].\
            dropna(subset=['np_pct_up_t1q_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'np_pct_up_t1q_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)


    
o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-06-01', '2021-12-31') &\
                             icom['np_pct_up_t1q_rk'].between(0,1) ].\
        dropna(subset=['np_pct_up_t1q_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
        'np_pct_up_t1q_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)

    
    
o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-06-01', '2021-12-31') &\
                         icom['retd2holi'].between(0,3) &\
                         icom['np_pct_up_t1q_rk'].between(0.5,+1)    ].\
        dropna(subset=['np_pct_up_t1q_rk','BarrRet_CLIP_USD+1d']).
drop_duplicates(subset=['Ticker','DataDate']),
        'np_pct_up_t1q_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)

