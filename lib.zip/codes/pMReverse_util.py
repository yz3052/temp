﻿#$%^&* pMReverse_util.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Jan  6 20:40:34 2021

@author: thzhang
"""

import pandas as pd
import numpy as np


from bokeh.io import show
from bokeh.layouts import column, gridplot
from bokeh.models import ColumnDataSource, RangeTool, HoverTool, CustomJS, CrosshairTool, LinearAxis, Range1d
from bokeh.plotting import figure

# here below is a backtester specifically for mean reverse strategies 

import matplotlib.pyplot as plt
def bt_mr(df, col_signal_str, col_ret_str, sgnl_before_3pm, static_data = None, tcost_method = 'daily', skip_bucket = False):
    # df must have: datadate + ticker + signal ( = % of clip) + return
    # col_signal_str is the desired pstD for the next day (not just signal), col_ret_str is the return for the next day
    # usually col_ret_str is bret_p1d
    # tcost_method ['daily','intraday']
    
    # df quality check
    if df.duplicated(subset = ['ticker','datadate'], keep = False).sum() > 0:
        raise Exception("Input df has duplicate ticker/datadate rows.")
    if pd.isnull(df[['ticker','datadate',col_signal_str,col_ret_str]]).any(axis = 1).sum() > 0:
        raise Exception("Input df has nan values.")

    
    # get df's tickers and date range
    i_tk = df['ticker'].unique().tolist()
    i_df_min_date = (df['datadate'].min()-pd.to_timedelta('1 day')).strftime('%Y-%m-%d')
    
    # get rid of unnecessary columns from df
    for f in ['spread','volatility','SRISK_USE4', 'BETA_USE4', 'BTOP_USE4', 'EARNYILD_USE4', 'GROWTH_USE4', 
              'LEVERAGE_USE4', 'LIQUIDTY_USE4', 'MOMENTUM_USE4', 'MOMENTUM_FAST','SIZE_USE4', 'DIVYILD_USE4', 
              'RESVOL_USE4','SHORTINT_FAST', 'VALUE_FAST']:
        try:
            df = df.drop(columns = [f])
        except:
            continue
        try:
            df = df.drop(columns = [f+'_bk'])
        except:
            continue
        try:
            df = df.drop(columns = [f+'_rk'])
        except:
            continue
        
    
    # get static data
    if static_data is not None:
        i_sd = static_data
    else:
        i_sd = pd.read_parquet(r"S:\Infrastructure\backtester\data_cache\static_data_v2p0.parquet", 
                               columns = ['Ticker','DataDate','T-1d','avgPV_l1d','spread','volatility',
                                          'SRISK_USE4', 'BETA_USE4', 'BTOP_USE4', 'EARNYILD_USE4', 'GROWTH_USE4', 
                                          'LEVERAGE_USE4', 'LIQUIDTY_USE4', 'MOMENTUM_USE
4', 'MOMENTUM_FAST',
                                          'SIZE_USE4','SHORTINT_FAST', 'VALUE_FAST'])
    # process static data
    if sgnl_before_3pm == True:
        i_sd = i_sd.rename(columns = {'Ticker':'ticker', 'DataDate': 'datadate'})
    elif sgnl_before_3pm == False:
        i_sd = i_sd.rename(columns = {'Ticker':'ticker', 'T-1d': 'datadate','DataDate':'datadate_p1d'})
    
    i_sd = i_sd[(i_sd['datadate'] + pd.to_timedelta('10 days')>=i_df_min_date)&(i_sd['ticker'].isin(i_tk))]

    # merge sgnl and static data
    i_data = df.merge(i_sd, on = ['ticker','datadate'], how = 'right', suffixes = ['','_staticdata'])
    

    # clip size
    i_data['clip'] = i_data['avgPV_l1d']*0.01
    i_data.loc[i_data['clip']>1e6, 'clip'] = 1e6
    #i_data['clip'] = i_data['clip']*2 ###!!!
    
    # pst
    i_data['pstD'] = i_data[col_signal_str]
    
    # gmv
    i_data['gmv'] = i_data['pstD'].abs()
    
    # pnl
    i_data['pnl'] = i_data['pstD'].multiply(i_data[col_ret_str])
    i_data = i_data.sort_values(['ticker','datadate'])
    i_data['cumpnl'] = i_data.groupby('ticker')['pnl'].cumsum()
    
    # pnl - tcost
    i_data = i_data.sort_values(['ticker','datadate'])
    i_data = i_data.reset_index(drop = True)
    i_data['pstD_1d'] = i_data.groupby('ticker')['pstD'].shift(1)
    i_data['pstD_1d'] = i_data['pstD_1d'].fillna(0)
    if tcost_method == 'daily':
        i_data['pstD_df'] = (i_data['pstD'] - i_data['pstD_1d']).abs()
    else:
        i_data['pstD_df'] = i_data['pstD'].abs()*2
    i_data['pnl_tcost'] = i_data['pnl'] - 0.3 * i_data['spread'] * i_data['pstD_df'] -\
                          0.09 * ((i_data['volatility']/np.sqrt(252)).pow(0.65)) *\
                          ((i_data['pstD_df']/i_data['avgPV_l1d'])**0.6) * i_data['pstD_df']
    
    # clean the data
    i_data = i_data[i_data.datadate<=df.datadate.max()]
    #i_data = i_data.dropna(subset = ['clip','spread','volatility',col_signal_str, col_ret_str])
    
    # print buckets
    if not skip_bucket:
        for f in ['spread','volatility','SRISK_USE4', 'BETA_USE4', 'BTOP_USE4', 'EARNYILD_USE4', 
                  'GROWTH_USE4','LEVERAGE_USE4','MOMENTUM_FAST','SIZE_USE4','SHORTINT_FAST','VALUE_FAST']:
            try:
                i_data[f+'_bk'] = i_data.groupby('datadate')[f].apply(lambda x: pd.qcut(x,q=5,labels=[1,2,3,4,5]))
                print (f+'(bp): '+str(i_data.groupby(f+'_bk')[[col_ret_str,col_signal_str]].\
                                   apply(lambda x: x[col_re
t_str].multiply(pd.Series(np.sign(x[col_signal_str]))).mean()).multiply(10000).round(4).tolist()))
            except Exception as e:
                print (e)
                continue
    

    
    # daily summarization
    i_data = i_data.sort_values(['ticker', 'datadate'])
    i_data = i_data.reset_index(drop = True)
    o_daily = i_data.groupby('datadate').agg({'pnl':'sum','pnl_tcost':'sum'}).reset_index()
    o_daily = o_daily.dropna()
    
    o_daily['cumpnl'] = o_daily['pnl'].cumsum()
    o_daily['cumpnl_tcost'] = o_daily['pnl_tcost'].cumsum()
    o_daily = o_daily.set_index('datadate')
    
    
    # plot prep
    fig1 = plt.figure(figsize=(16,5))
    ax1 = fig1.add_subplot(121)
    
    # plot cumpnl
    ax1.plot(o_daily['cumpnl'])
    ax1.plot(o_daily['cumpnl_tcost']) ###!!!
    
    ax1.grid()
    ax1.set_ylabel('Cumulative Realized PNL', fontsize = 16)
    ax1.set_xlabel('Date',fontsize = 16)
    
    mean_pnl = np.round(o_daily['pnl'].mean() * 252 / 1e6)
    sr_pnl = np.round(o_daily['pnl'].mean() / o_daily['pnl'].std() * np.sqrt(252),2)
    mean_ret = np.round( (i_data['pnl'].sum() / i_data['gmv'].sum())*1e4,2)
    pt_ret = np.round( (i_data['pnl'].sum() / i_data['pstD_df'].sum())*1e4,2)
    ax1.text(0.01, 0.93, 'Annulized PNL: $' + str(mean_pnl) + ' MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.87, 'Annualized IR: ' + str(sr_pnl), verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.81, 'Daily Return: ' + str(mean_ret) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.75, 'Per Trade Return: ' + str(pt_ret) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    
    ax1.text(0.01, 0.72, '-----------------', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 5 )
    
    mean_pnl2 = np.round(o_daily['pnl_tcost'].mean() * 252 / 1e6)
    sr_pnl2 = np.round(o_daily['pnl_tcost'].mean() / o_daily['pnl_tcost'].std() * np.sqrt(252),2)
    mean_ret2 = np.round( (i_data['pnl_tcost'].sum() / i_data['gmv'].sum())*1e4,2)
    pt_ret2 = np.round( (i_data['pnl_tcost'].sum() / i_data['pstD_df'].sum())*1e4,2)
    ax1.text(0.01, 0.69, 'Annulized PNL post-tcos
t: $' + str(mean_pnl2) + ' MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.63, 'Annualized IR post-tcost: ' + str(sr_pnl2), verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.56, 'Daily Return post-tcost: ' + str(mean_ret2) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.49, 'Per Trade Return post-tcost: ' + str(pt_ret2) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    
    ax1.set_title(col_signal_str, fontsize = 16)
    
    # plot gmv
    
    gmvlong = i_data[ i_data['pstD'] > 0].groupby('datadate')['gmv'].sum()
    gmvlong = gmvlong.reset_index()
    gmvlong.columns = ['datadate','long']
    gmvlong = gmvlong.set_index('datadate')
    gmvshort = i_data[ i_data['pstD'] < 0].groupby('datadate')['gmv'].sum()
    gmvshort = gmvshort.reset_index()
    gmvshort.columns = ['datadate','short']
    gmvshort = gmvshort.set_index('datadate')
    
    ax2 = fig1.add_subplot(122)
    gmv = pd.concat([gmvlong,gmvshort],axis=1)
    ax2.plot(gmv)
    
    ax2.grid()
    ax2.set_ylabel('GMV', fontsize = 16)
    ax2.set_xlabel('Date',fontsize = 16)
    
    totgmv = i_data.groupby('datadate')['gmv'].sum().mean()    
    to = np.round(i_data['pstD_df'].sum() / i_data['gmv'].sum() * 100)
    
    ax2.text(0.01, 0.93, 'Avg Long Size: ' + str(np.round(gmvlong['long'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.87, 'Avg Short Size: ' + str(np.round(gmvshort['short'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.81, 'Total Size: ' + str(np.round(totgmv/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.75, 'Turnover: ' + str(to) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    
    return i_data



def viz(i_data, tk_pair_list):
    
    i_data['zero'] = 0
    i_data['valid_date'] = i_data['valid_date'].replace(np.nan, 0)
   
    

    #pid*2
    #spread, ma of spread, final_spread
    #pst1, pst2 
    #pnl
    
    # Main chart: pid of tk1 ad tk2

    p_main = figure(plot_height=260, plot_width=1600, tools="pan,wheel_zoom,reset", toolbar_location='right',
               x_axis_type="datetime", x_axis_location="below", title = str(tk_pair_list)+': dark for tk1',
               background_fill_color="#ffffff",x_range=(i_data.datadate.min(), i_data.datadate.max()))
    p_main.xaxis.major_label_orientation = 3.1415/4
    p_main_p_index1 = ColumnDataSource(data=dict(date=i_data['datadate'], p_index = i_data.set_index('datadate')['pid1'] ))
    p_main.circle('date', 'p_index', source=p_main_p_index1, fill_color = 'indigo', size = 4)
    p_main_p_index2 = ColumnDataSource(data=dict(date=i_data['datadate'], p_index2 = i_data.set_index('datadate')['pid2'] ))
    p_main.circle('date', 'p_index2', source=p_main_p_index2, fill_color = 'orange', size = 4)
    p_main.xaxis[0].ticker.desired_num_ticks = 40
    
    # main chart: mouse hovering tool
    p_main.add_tools(HoverTool(tooltips=[('date','@date{%F}'),('pid1','@{p_index}{0.3f}'),('pid2','@{p_index2}{0.3f}')],formatters ={'date':'datetime'}))
    
    # second chart: spread, ma of spread, 
    
    p_2 = figure(x_axis_type="datetime", tools="pan,wheel_zoom,box_zoom,reset", plot_width=1600, plot_height = 160,
                 x_range = p_main.x_range, title = 'raw spread + MA')
    p_2.xaxis.major_label_orientation = 3.1415/4
    p_2.grid.grid_line_alpha=0.3
    p_2.xaxis[0].ticker.desired_num_ticks = 40
    
    spread =  ColumnDataSource(data=dict(date=i_data['datadate'], spread=i_data['spread']))
    p_2.line('date', 'spread', source=spread, line_color = 'red', line_width = 0.8, line_alpha = 0.7)
    spread_ma = ColumnDataSource(data=dict(date=i_data['datadate'], spread_ma=i_data['spread_ma']))
    p_2.line('date', 'spread_ma', source=spread_ma, line_color = 'blue', line_width = 0.8, line_alpha = 0.7)
    zero =  ColumnDataSource(data=dict(date=i_data['datadate'], zero=i_data['zero']))
    p_2.line('date', 'zero', source=zero, line_color = 'green', line_width = 0.8, line_alpha = 0.7)    
    
    p_2.add_tools(HoverTool(tooltips=[('date','@date{%F}'),('spread','@{spread}{0.3f}'),('spread_ma','@{spread_ma}{0.3f}')],
                                      formatters ={'date':'datetime'}))
    p_2.xaxis.visible = False
    
    
    # 2.5 chart: spread zscore
    p_25 = figure(x_axis_type="datetime", tools="pan,wheel_zoom,box_zoom,reset", plo
t_width=1600, plot_height = 120,
                 x_range = p_main.x_range, title = 'spread zscore')
    
    spread_zscore =  ColumnDataSource(data=dict(date=i_data['datadate'], spread_zscore=i_data['spread_zscore']))
    p_25.vbar('date', top='spread_zscore', source=spread_zscore, width = 12*60*60*1000, line_color = 'blue')
    zero =  ColumnDataSource(data=dict(date=i_data['datadate'], zero=i_data['zero']))
    p_25.line('date', 'zero', source=zero, line_color = 'yellow', line_width = 0.8, line_alpha = 0.7)    
    
    p_25.xaxis.visible = False
    

    # third chart: pst1 and pst2
    p_3 = figure(x_axis_type="datetime", tools="pan,wheel_zoom,box_zoom,reset", plot_width=1600, plot_height = 80,
                 x_range = p_main.x_range, title = 'pst, pst1 = black, +pst = short spread')
    p_3.xaxis.major_label_orientation = 3.1415/4
    p_3.grid.grid_line_alpha=0.3
    p_3.xaxis[0].ticker.desired_num_ticks = 40
    
    pst_tk1 =  ColumnDataSource(data=dict(date=i_data['datadate'], pst_tk1=i_data['pst_tk1']))
    p_3.vbar('date', top = 'pst_tk1', source=pst_tk1, line_color = 'black', width = 12*60*60*1000, line_alpha = 0.7)
    pst_tk2 =  ColumnDataSource(data=dict(date=i_data['datadate'], pst_tk2=i_data['pst_tk2']))
    p_3.vbar('date', top = 'pst_tk2', source=pst_tk2, line_color = 'orange', width = 12*60*60*1000, line_alpha = 0.7)
    p_3.xaxis.visible = False
    
    # fourth chrat: cumpnl 
    p_4 = figure(x_axis_type="datetime", tools="pan,wheel_zoom,box_zoom,reset", plot_width=1600, plot_height = 100,
                 x_range = p_main.x_range, title = 'cumpnl')
    p_4.xaxis.major_label_orientation = 3.1415/4
    p_4.grid.grid_line_alpha=0.3
    p_4.xaxis[0].ticker.desired_num_ticks = 40
    p_4.xaxis.visible = False
    
    cumpnl =  ColumnDataSource(data=dict(date=i_data['datadate'], cumpnl=i_data['cumpnl']))
    p_4.line('date', 'cumpnl', source=cumpnl, line_color = 'black', line_width = 0.8, line_alpha = 0.7)
    
    
    # slider
    slider = figure(plot_height=40, plot_width=1600, #y_range=p_main.y_range,
                    x_axis_type="datetime", y_axis_type=None,
                    tools="", toolbar_location=None, background_fill_color="#efefef")        
    slider_range_tool = RangeTool(x_range=p_main.x_range)
    slider_range_tool.overlay.fill_color = "navy"
    slider_range_tool.overlay.fill_alpha = 0.2
    slider_c = ColumnDataSource(data=dict(date=i_data['datadate'], slider_c=i_data['valid_date']))
    slider.circle('date', '
slider_c', source=slider_c, line_color = 'blue', line_width = 1)
    slider.ygrid.grid_line_color = None
    slider.add_tools(slider_range_tool)
    slider.toolbar.active_multi = slider_range_tool
    slider.axis.visible = False
    
    
    show(gridplot([[p_main],[p_2],[p_25],[p_3],[p_4], [slider]]))
    
    
    
    return None
