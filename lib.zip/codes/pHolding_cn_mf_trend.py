﻿#$%^&* pHolding_cn_mf_trend.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat Jul  9 07:31:59 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import gc
import os
import datetime


# this studies the trend of nortbound holdings



### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()




### trading calendar

i_cn_cal = yu.get_sql("select distinct datadate, tradedate_next from [CNDBPROD].[dbo].[Calendar_Dates_CN]")


### return

i_ret = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet',
                        columns = ['ticker','datadate','twap1000_2c_bret_t4w','twap1000_2c_t4w'])




### so

i_so = yu.get_sql('''select datadate, ticker, EQY_FLOAT as so 
                  from cndbprod.dbo.universe_all_cn_gem3l 
                  where datadate >= '2016-01-01' ''')
c_sh = i_so['ticker'].str[0].isin(['6'])
c_sz = i_so['ticker'].str[0].isin(['0','3'])
i_so.loc[c_sh, 'ticker'] = i_so.loc[c_sh, 'ticker'] + '.SH'
i_so.loc[c_sz, 'ticker'] = i_so.loc[c_sz, 'ticker'] + '.SZ'

i_so = i_so.sort_values('datadate')


### HK holding 


#i_h = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate, s_quantity 
#                 from wind.dbo.SHSCChannelholdings
#                 where s_info_windcode not like '%HK' ''')
#i_h['datadate'] = pd.to_datetime(i_h['datadate'], format = '%Y%m%d')
#
#i_h = i_h.sort_values('datadate')
#i_h = pd.merge_asof(i_h, i_so, by = 'ticker', on = 'datadate')
#
#i_h['h_pctOfSO'] = i_h['s_quantity'].divide(i_h['so'])
#
#i_h = i_h.sort_values(['ticker', 'datadate'])
#i_h['h_pctOfSO_t200d_std'] = i_h.groupby('ticker').rolling(200)['h_pctOfSO'].std().values
#i_h['h_pctOfSO_t200d_avg'] = i_h.groupby('ticker').rolling(200)['h_pctOfSO'].mean().values
#i_h['h_pctOfSO_t200d_std_dv_avg'] = i_h['h_pctOfSO_t200d_std'].divide(i_h['h_pctOfSO_t200d_avg'])


### MF holding

i_mf = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_wind_holding_mf_q_est_step2.parquet')
i_mf = i_mf.sort_values('datadate')



#------------------------------------------------------------------------------
### combine
#------------------------------------------------------------------------------




#icom = i_sd.merge(i_h, on = ['ticker', 'datadate'], how = 'left')

icom = pd.merge_asof(i_sd, i_mf, by = 'ticker', on = 'datadate')
icom = icom.sort_values(['tic
ker', 'datadate'])

icom = icom.merge(i_ret, on = ['ticker', 'datadate'], how = 'left')




# nortbound std idea doesn't work 

icom['h_pctOfSO_t200d_std_dv_avg_bk'] = icom.groupby('datadate')['h_pctOfSO_t200d_std_dv_avg'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['h_pctOfSO_t200d_std_bk'] = icom.groupby('datadate')['h_pctOfSO_t200d_std'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['h_pctOfSO_t200d_std_dv_avg_bk'], 'h_pctOfSO_t200d_std_dv_avg') # random
yu.create_cn_3x3(icom, ['h_pctOfSO_t200d_std_bk'], 'h_pctOfSO_t200d_std') # less mono: -2 +2 +1

# how about slope of north holding? 

# mf trends 

icom['pctOfSO_t200d_mean'] = icom.groupby('ticker').rolling(200)['pctOfSO'].mean().values
icom['pctOfSO_t200d_mean_1d'] = icom.groupby('ticker')['pctOfSO_t200d_mean'].shift()
icom['pctOfSO_!d'] = icom.groupby('ticker')['pctOfSO'].shift()

c1 = (icom['pctOfSO']>icom['pctOfSO_t200d_mean']) & (icom['pctOfSO_!d']<icom['pctOfSO_t200d_mean_1d'])
icom['flg_mf_up_x'] = np.nan
icom.loc[c1, 'flg_mf_up_x'] = 1

yu.create_cn_decay(icom, 'flg_mf_up_x')

icom['sgnl_up_x'] = np.nan
icom['sgnl_up_x'] = icom.groupby('ticker')['flg_mf_up_x'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna(subset=['sgnl_up_x','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_up_x','BarrRet_CLIP_USD+1d', static_data = i_sd) 

# 5d: 0.79 / -0.73
# 20d: 1.42 / 0.53
# 40d: 1.49 / 0.83

t_pnl = o_1.groupby('ticker')['pnl_ac'].sum().sort_values()
c_tk = '002131.SZ'
icom[icom.ticker==c_tk].set_index('datadate')[['pctOfSO','pctOfSO_t200d_mean']].plot()
o_1[o_1.ticker==c_tk].set_index('datadate')['pnl_ac'].cumsum().plot()



# mf trends + pastret

icom['twap1000_2c_bret_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)

icom['pctOfSO_t200d_mean'] = icom.groupby('ticker').rolling(200)['pctOfSO'].mean().values
icom['pctOfSO_t200d_mean_1d'] = icom.groupby('ticker')['pctOfSO_t200d_mean'].shift()
icom['pctOfSO_1d'] = icom.groupby('ticker')['pctOfSO'].shift()


icom['sgnl_gt200_lowret'] = np.nan
c1 = (icom['pctOfSO']>icom['pctOfSO_t200d_mean']) & (icom['twap1000_2c_bret_t4w_rk']<-0.8)
icom.loc[c1, 'sgnl_gt200_lowret'] = 1
#c2 = (icom['pctOfSO']<icom['pctOfSO_t200d_mean']) 
#icom.loc[c2, 'sgnl_gt200_lowret'] = 0

icom['sgnl_gt200_lowret'] = icom.groupby('ticker')['sgnl_gt200_lowret'].ffill(limit = 63)

yu.create_cn_decay(icom, 'sgnl_gt20
0_lowret')

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna(subset=['sgnl_gt200_lowret','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_gt200_lowret','BarrRet_CLIP_USD+1d', static_data = i_sd) 
