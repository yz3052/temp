﻿#$%^&* pFlow_us__etl_astec_daily_backfill.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May  3 11:22:05 2023

@author: thzhang
"""

import pandas as pd

import os


### intraday  3:45 pm

# intraday files

root = '/dat/mdwarehouse/public/FIS/AstecAnalytics/intraday_out/'

o_files = []
for year in os.listdir(root):
    if year == 'inflated_history':
        continue
    for month in os.listdir(root + year):
        for day in os.listdir(root + year + '/' + month):
            root_f = root + year + '/' + month + '/' + day
            for f in os.listdir(root_f):
                if not f.endswith('txt'):
                    o_files.append([root_f, f])
o_files = pd.DataFrame(o_files, columns = ['fd', 'f'])


# get the last intraday file before 3pm est on each date

o_files = o_files[o_files['f'].str.split('.').str[-1].str.isnumeric()]
o_files['date_ts'] = o_files['f'].str.split('.').str[-2] + ' ' + o_files['f'].str.split('.').str[-1]
o_files['date_ts'] = pd.to_datetime(o_files['date_ts'],format = '%Y%m%d %H%M%S')
o_files['date_ts'] = o_files['date_ts'].dt.tz_localize('UTC').dt.tz_convert('US/Eastern').dt.tz_localize(None)

o_files = o_files[o_files['date_ts'].dt.strftime('%H%M%S')<='154500']
o_files['folder_date'] = pd.to_datetime(o_files['fd'].str[-10:], format='%Y/%m/%d')
o_files = o_files[o_files['folder_date'] == pd.to_datetime(o_files['date_ts'].dt.strftime('%Y-%m-%d'))]

o_files['file_size'] = (o_files['fd']+'/'+o_files['f']).apply(lambda x: os.stat(x)[6])
o_files = o_files[o_files['file_size'] > 10240]

o_files = o_files.sort_values('date_ts')
o_files = o_files.reset_index(drop = True)
o_files = o_files.drop_duplicates(subset = ['folder_date'], keep = 'last')
o_files = o_files[['fd', 'f', 'folder_date']]

# get data

data_backfill = []
for i,r in o_files.iterrows():    
    print('.', end='')
    tdata = pd.read_csv(os.path.join(r['fd'], r['f']), sep = '|')
    tdata['DataDate'] = r['folder_date']
    tdata['TradingSymbol'] = tdata['TradingSymbol'].fillna('')
    data_backfill.append(tdata)
    
data_backfill = pd.concat(data_backfill, axis = 0)
data_backfill = data_backfill[['DataDate', 'AstecID', 'Date', 'CUSIP', 'ISIN', 
                               'TradingSymbol', 'ContractTypeID', 'LoanStageID', 
                               'CollateralTypeID', 'CollateralCurrencyID', 'Tickets',
                               'Units', 'MarketValueUSD', 'Age', 'LoanRateAvg', 
                               'LoanRateMax', 'LoanRate
Min', 'LoanRateStdev']]
data_backfill.to_csv('/export/datadev/cache/astec_1545.csv', index = False, sep = '|')

'''
create table astec_1545 (DataDate datetime,
                        AstecID integer, Date datetime, CUSIP varchar(max), 
                        ISIN varchar(max), TradingSymbol varchar(max), 
                        ContractTypeID varchar(max), LoanStageID varchar(max),
                        CollateralTypeID varchar(max), CollateralCurrencyID varchar(max),
                        Tickets integer, Units float, MarketValueUSD float,
                        Age float, LoanRateAvg float, LoanRateMax float,
                        LoanRateMin float, LoanRateStdev float)
'''

'''
freebcp [TZDBDEV].[dbo].[astec_1545] in /export/datadev/cache/astec_1545.csv -S summitsqldb -U svc_tz_dbo -P 1wutRe2tidripri -c -t '|'
'''




### intraday  10:15 am

# intraday files

root = '/dat/mdwarehouse/public/FIS/AstecAnalytics/intraday_out/'

o_files = []
for year in os.listdir(root):
    if year == 'inflated_history':
        continue
    for month in os.listdir(root + year):
        for day in os.listdir(root + year + '/' + month):
            root_f = root + year + '/' + month + '/' + day
            for f in os.listdir(root_f):
                if not f.endswith('txt'):
                    o_files.append([root_f, f])
o_files = pd.DataFrame(o_files, columns = ['fd', 'f'])


# get the last intraday file before 3pm est on each date

o_files = o_files[o_files['f'].str.split('.').str[-1].str.isnumeric()]
o_files['date_ts'] = o_files['f'].str.split('.').str[-2] + ' ' + o_files['f'].str.split('.').str[-1]
o_files['date_ts'] = pd.to_datetime(o_files['date_ts'],format = '%Y%m%d %H%M%S')
o_files['date_ts'] = o_files['date_ts'].dt.tz_localize('UTC').dt.tz_convert('US/Eastern').dt.tz_localize(None)

o_files = o_files[o_files['date_ts'].dt.strftime('%H%M%S')<='101500']
o_files['folder_date'] = pd.to_datetime(o_files['fd'].str[-10:], format='%Y/%m/%d')
o_files = o_files[o_files['folder_date'] == pd.to_datetime(o_files['date_ts'].dt.strftime('%Y-%m-%d'))]

o_files['file_size'] = (o_files['fd']+'/'+o_files['f']).apply(lambda x: os.stat(x)[6])
o_files = o_files[o_files['file_size'] > 10240]

o_files = o_files.sort_values('date_ts')
o_files = o_files.reset_index(drop = True)
o_files = o_files.drop_duplicates(subset = ['folder_date'], keep = 'last')
o_files = o_files[['fd', 'f', 'folder_date']]

# get data

data_backfill = []
for i,r in o_files.iterrows():    
    print('.', e
nd='')
    tdata = pd.read_csv(os.path.join(r['fd'], r['f']), sep = '|')
    tdata['DataDate'] = r['folder_date']
    tdata['TradingSymbol'] = tdata['TradingSymbol'].fillna('')
    data_backfill.append(tdata)
    
data_backfill = pd.concat(data_backfill, axis = 0)
data_backfill = data_backfill[['DataDate', 'AstecID', 'Date', 'CUSIP', 'ISIN', 
                               'TradingSymbol', 'ContractTypeID', 'LoanStageID', 
                               'CollateralTypeID', 'CollateralCurrencyID', 'Tickets',
                               'Units', 'MarketValueUSD', 'Age', 'LoanRateAvg', 
                               'LoanRateMax', 'LoanRateMin', 'LoanRateStdev']]
data_backfill.to_csv('/export/datadev/cache/astec_1015.csv', index = False, sep = '|')

'''
create table astec_1015 (DataDate datetime,
                        AstecID integer, Date datetime, CUSIP varchar(max), 
                        ISIN varchar(max), TradingSymbol varchar(max), 
                        ContractTypeID varchar(max), LoanStageID varchar(max),
                        CollateralTypeID varchar(max), CollateralCurrencyID varchar(max),
                        Tickets integer, Units float, MarketValueUSD float,
                        Age float, LoanRateAvg float, LoanRateMax float,
                        LoanRateMin float, LoanRateStdev float)
'''

'''
freebcp [TZDBDEV].[dbo].[astec_1015] in /export/datadev/cache/astec_1015.csv -S summitsqldb -U svc_tz_dbo -P 1wutRe2tidripri -c -t '|'
'''






### daily - utilization

root = '/dat/mdwarehouse/public/FIS/AstecAnalytics/out/'

o_files = []
for year in os.listdir(root):
    if year == 'inflated_history':
        continue
    for month in os.listdir(root + year):
        if (year=='2019') and (month=='03'):
            continue
        for day in os.listdir(root + year + '/' + month):
            root_f = root + year + '/' + month + '/' + day
            for f in os.listdir(root_f):
                if f.endswith('txt') and ('_U2_' in f):
                    o_files.append([root_f, f])
o_files = pd.DataFrame(o_files, columns = ['fd', 'f'])


i_util = []
for i,r in o_files.iterrows():    
    print('.', end='')
    filename = r['f'].split('_')[-1]
    tdata = pd.read_csv(os.path.join(r['fd'], r['f']), sep = '|')
    tdata['DataDate'] = pd.to_datetime(filename, format='%Y%m%d.txt')
    tdata['TradingSymbol'] = tdata['TradingSymbol'].fillna('')
    tdata = tdata[['DataDate', 'AstecID', 'Date', 'CUSIP', 'ISIN', 'TradingSymbol',
           
        'UtilizationPercent_Units', 'Available_Units', 'Available_MarketValueUSD']]
    i_util.append(tdata)
i_util = pd.concat(i_util, axis = 0)
i_util.to_csv('/export/datadev/cache/astec_u2_eod.csv', index = False, sep = '|')



'''
create table astec_u2_eod (DataDate datetime,
                        AstecID integer, Date datetime, CUSIP varchar(max), 
                        ISIN varchar(max), TradingSymbol varchar(max), 
                        UtilizationPercent_Units float, 
                        Available_Units float, Available_MarketValueUSD float)
'''
'''
freebcp [TZDBDEV].[dbo].[astec_u2_eod] in /export/datadev/cache/astec_u2_eod.csv -S summitsqldb -U svc_tz_dbo -P 1wutRe2tidripri -c -t '|'
'''





### daily - position

root = '/dat/mdwarehouse/public/FIS/AstecAnalytics/out/'

o_files = []
for year in os.listdir(root):
    if year == 'inflated_history':
        continue
    for month in os.listdir(root + year):
        if (year=='2019') and (month=='03'):
            continue
        for day in os.listdir(root + year + '/' + month):
            root_f = root + year + '/' + month + '/' + day
            for f in os.listdir(root_f):
                if f.endswith('txt') and ('_P5_' in f):
                    o_files.append([root_f, f])
o_files = pd.DataFrame(o_files, columns = ['fd', 'f'])


i_pst = []
for i,r in o_files.iterrows():    
    print('.', end='')    
    filename = r['f'].split('_')[-1]
    tdata = pd.read_csv(os.path.join(r['fd'], r['f']), sep = '|')
    tdata['DataDate'] = pd.to_datetime(filename, format='%Y%m%d.txt')
    tdata['TradingSymbol'] = tdata['TradingSymbol'].fillna('').astype(str) 

    tdata = tdata[['DataDate', 'AstecID', 'Date', 'CUSIP', 'ISIN', 'TradingSymbol', 
                   'ContractTypeID', 'LoanStageID', 'CollateralTypeID', 
                   'CollateralCurrencyID', 'Tickets', 'Units', 'MarketValueUSD', 
                   'Age', 'RetailLoanRateAvg', 'RetailLoanRateMax', 'RetailLoanRateMin', 
                   'RetailLoanRateStdev']]
    i_pst.append(tdata)
i_pst = pd.concat(i_pst, axis = 0)
i_pst.to_csv('/export/datadev/cache/astec_p5_eod.csv', index = False, sep = '|')

    


'''
create table astec_p5_eod (DataDate datetime, AstecID integer, Date datetime,
                           CUSIP varchar(max), ISIN varchar(max), 
                           TradingSymbol varchar(max), ContractTypeID varchar(max),
                           LoanStageID varchar(max), CollateralTypeID varchar(max),
               
            CollateralCurrencyID varchar(max), Tickets integer,
                           Units float, MarketValueUSD float, Age float,
                           RetailLoanRateAvg float, RetailLoanRateMax float,
                           RetailLoanRateMin float, RetailLoanRateStdev float)
'''
'''
freebcp [TZDBDEV].[dbo].[astec_p5_eod] in /export/datadev/cache/astec_p5_eod.csv -S summitsqldb -U svc_tz_dbo -P 1wutRe2tidripri -c -t '|'
'''





### daily history - utilization

root = '/dat/mdwarehouse/public/FIS/AstecAnalytics/out/inflated_history/'


i_util_hist = []
for f in os.listdir(root):    
    if 'H_U2_' not in f:
        continue    
    
    tdata = pd.read_csv(root + f, sep = '|')
    tdata['DataDate'] = pd.to_datetime(tdata['Date'])
    
    tdata = tdata[['DataDate', 'AstecID', 'Date', 'CUSIP', 'ISIN', 'TradingSymbol',
                   'UtilizationPercent_Units', 'Available_Units', 'Available_MarketValueUSD']]
    i_util_hist.append(tdata)

i_util_hist = pd.concat(i_util_hist, axis = 0)
i_util_hist.to_csv('/export/datadev/cache/astec_u2_eod_hist.csv', index = False, sep = '|')

'''
freebcp [TZDBDEV].[dbo].[astec_u2_eod] in /export/datadev/cache/astec_u2_eod_hist.csv -S summitsqldb -U svc_tz_dbo -P 1wutRe2tidripri -c -t '|'
'''

    


### daily history - position

root = '/dat/mdwarehouse/public/FIS/AstecAnalytics/out/inflated_history/'

i_pst_hist = []
for f in os.listdir(root):    
    if 'H_P5_' not in f:
        continue
    
    tdata = pd.read_csv(root + f, sep = '|')
    tdata['DataDate'] = pd.to_datetime(tdata['Date'])
        
    tdata = tdata[['DataDate', 'AstecID', 'Date', 'CUSIP', 'ISIN', 'TradingSymbol', 
                   'ContractTypeID', 'LoanStageID', 'CollateralTypeID', 
                   'CollateralCurrencyID', 'Tickets', 'Units', 'MarketValueUSD', 
                   'Age', 'RetailLoanRateAvg', 'RetailLoanRateMax', 'RetailLoanRateMin', 
                   'RetailLoanRateStdev']]
    i_pst_hist.append(tdata)
    
i_pst_hist = pd.concat(i_pst_hist, axis = 0)
i_pst_hist.to_csv('/export/datadev/cache/astec_p5_eod_hist.csv', index = False, sep = '|')


'''
freebcp [TZDBDEV].[dbo].[astec_p5_eod] in /export/datadev/cache/astec_p5_eod_hist.csv -S summitsqldb -U svc_tz_dbo -P 1wutRe2tidripri -c -t '|'
'''

### also: other daily files might be worth a shot
