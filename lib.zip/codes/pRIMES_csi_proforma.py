﻿#$%^&* pRIMES_csi_proforma.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 29 20:52:45 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import os



### get 300 and 500 constituent

i_300 = yu.get_sql('''select date_of_portfolio as datadate, 
                   replace(primary_ric_company_level,'SS','SH') as ticker,
                   Investable_Weight as w_con 
                   from cndbprod.dbo.csi_300_cons''')
i_500 = yu.get_sql('''select date_of_portfolio as datadate, 
                   replace(primary_ric_company_level,'SS','SH') as ticker,
                   Investable_Weight as w_con  
                   from cndbprod.dbo.csi_500_cons''')


### get proforma files

i_dir300 = []
for r,p,fs in os.walk(r'Z:\Rimes\Indices\CSI\CSI300'):
    for f in fs:
        if ('PROFORMA' in f) and f.endswith('.psv'):
            print('.',end='')
            i_dir300.append([f,r,os.path.join(r,f)])
            
i_proforma300 = []
for lst in i_dir300:
    print('^',end='')
    t_psv = pd.read_csv(open(lst[2],errors='ignore'), sep='|')
    t_psv = t_psv[['Date of Portfolio','Primary RIC Company Level','Investable Weight']]
    t_psv['filename'] = lst[0]
    i_proforma300.append(t_psv)
i_proforma300 = pd.concat(i_proforma300, axis = 0)
i_proforma300['datadate'] = pd.to_datetime(i_proforma300['Date of Portfolio'], format='%Y%m%d')
i_proforma300['ticker'] = i_proforma300['Primary RIC Company Level'].str.replace('SS','SH')


i_dir500 = []
for r,p,fs in os.walk(r'Z:\Rimes\Indices\CSI\CSI500'):
    for f in fs:
        if ('PROFORMA' in f) and f.endswith('.psv'):
            print('.',end='')
            i_dir500.append([f,r,os.path.join(r,f)])
            
i_proforma500 = []
for lst in i_dir500:
    print('^',end='')
    t_psv = pd.read_csv(open(lst[2],errors='ignore'), sep='|')
    t_psv = t_psv[['Date of Portfolio','Primary RIC Company Level','Investable Weight']]
    t_psv['filename'] = lst[0]
    i_proforma500.append(t_psv)
i_proforma500 = pd.concat(i_proforma500, axis = 0)
i_proforma500['datadate'] = pd.to_datetime(i_proforma500['Date of Portfolio'], format='%Y%m%d')
i_proforma500['ticker'] = i_proforma500['Primary RIC Company Level'].str.replace('SS','SH')




### calculate diff between proforma and actual constituents

o_add_rm = []

for dt in i_proforma300['datadate'].drop_duplicates().tolist():
    
    t_proforma300 = i_proforma300[i_proforma300['datadate']==dt]
    t_con300 = i_300[i_30
0['datadate']==dt]
    
    if len(t_con300)==0:
        print('_', end=' ')
    else:
        print(dt.strftime('%Y%m%d'),end=' ')
    
    t_df300 = t_proforma300.merge(t_con300, on = ['ticker','datadate'], how = 'outer')
    t_df300 = t_df300.fillna(0)
    t_df300['add_rm'] = np.nan
    c1 = (t_df300['w_con']==0)&(t_df300['Investable Weight']>0)
    t_df300.loc[c1, 'add_rm'] = 1
    c2 = (t_df300['w_con']>0)&(t_df300['Investable Weight']==0)
    t_df300.loc[c2, 'add_rm'] = -1
    t_df300['w_chg'] = t_df300['Investable Weight'] - t_df300['w_con']
    
    t_df300['index'] = 'CSI300'
    t_df300 = t_df300[['ticker','datadate','w_chg','add_rm','index']]
    
    o_add_rm.append(t_df300)
    
for dt in i_proforma500['datadate'].drop_duplicates().tolist():
    
    t_proforma500 = i_proforma500[i_proforma500['datadate']==dt]
    t_con500 = i_500[i_500['datadate']==dt]
    
    if len(t_con500)==0:
        print('_', end=' ')
    else:
        print(dt.strftime('%Y%m%d'),end=' ')
    
    t_df500 = t_proforma500.merge(t_con500, on = ['ticker','datadate'], how = 'outer')
    t_df500 = t_df500.fillna(0)
    t_df500['add_rm'] = np.nan
    c1 = (t_df500['w_con']==0)&(t_df500['Investable Weight']>0)
    t_df500.loc[c1, 'add_rm'] = 1
    c2 = (t_df500['w_con']>0)&(t_df500['Investable Weight']==0)
    t_df500.loc[c2, 'add_rm'] = -1
    t_df500['w_chg'] = t_df500['Investable Weight'] - t_df500['w_con']
    
    t_df500['index'] = 'CSI500'
    t_df500 = t_df500[['ticker','datadate','w_chg','add_rm','index']]
    
    o_add_rm.append(t_df500)
    
o_add_rm = pd.concat(o_add_rm, axis=0)



### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d',
                 'isin_hk_uni','csi300_flag',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d',
                 'EARNYILD','GROWTH']]


#### total stock value + index-ticker mapping


i_funds = yu.get_sql('''select a.s_info_windcode, a.f_ann_date as datadate, a.f_prt_stockvalue, 
                     b.f_info_name, b.f_info_benchmark, b.f_info_type, b.f_info_fund_id, 
                     c.s_info_indexwindcode, d.s_info_name   
                      from [WIND].[dbo].[CHINAMUTUALFUNDASSETPORTFOLIO] a 
                      left join wind.dbo.CHINAMUTUALFUNDDESCRIPTION b
                      on a.S_INFO_WINDCODE =
 b.f_info_windcode 
                      left join  [WIND].[dbo].[CHINAMUTUALFUNDTRACKINGINDEX] c
                      on a.s_info_windcode = c.s_info_windcode 
                      left join wind.dbo.windcustomcode d
                      on c.s_info_indexwindcode = d.s_info_windcode                       
                      where c.s_info_indexwindcode is not null 
                      order by f_info_fund_id''')

i_funds = i_funds[i_funds['s_info_name'].isin(['沪深300','中证500' ])]
i_funds['datadate'] = pd.to_datetime(i_funds['datadate'], format = '%Y%m%d')
i_funds.loc[i_funds['s_info_indexwindcode']=='000300.SH','index'] = 'CSI300'
i_funds.loc[i_funds['s_info_indexwindcode']=='000905.SH','index'] = 'CSI500'

i_funds = i_funds[['datadate','s_info_windcode','f_prt_stockvalue','index']]
i_funds = i_funds.sort_values('datadate')

i_funds_sum = []
for dt in pd.date_range(start='2015-06-01',end='2021-06-01'):    
    t_funds = i_funds[i_funds['datadate'].between(dt-pd.to_timedelta('100 days'), dt)]
    t_funds = t_funds.drop_duplicates(subset=['s_info_windcode','index'], keep = 'last')
    t_funds_sum = t_funds.groupby('index')['f_prt_stockvalue'].sum().reset_index()
    t_funds_sum['datadate'] = dt
    i_funds_sum.append(t_funds_sum)
i_funds_sum = pd.concat(i_funds_sum, axis = 0)




### combine
icom = i_sd.merge(o_add_rm, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(i_funds_sum, on = ['index','datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])

icom['trackingMoneyChg_dv_pv'] = icom['f_prt_stockvalue'].multiply(icom['w_chg']).divide(icom['avgPVadj'])

icom['add_rm_sgnl'] = icom.groupby('ticker')['add_rm'].ffill(limit = 1)


# test

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['flag_add','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flag_add','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 4.31 / 2.13, 3.82bp/d
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['flag_add']>0)].\
            dropna(subset=['flag_add','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flag_add','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 5.02/3.47, 7.77bp/d, 1m

# 800; add / removal

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['add_rm_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'add_rm_sgnl','BarrRet_CLIP_USD+1d', static_dat
a = i_sd_map) # 3.87/0.55
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['add_rm_sgnl']>0)].\
            dropna(subset=['add_rm_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'add_rm_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 3.82/2.34

# 300; add / removal

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['index']=='CSI300')].\
            dropna(subset=['add_rm_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'add_rm_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 0.59/-1.77
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['index']=='CSI300')&(icom['add_rm_sgnl']>0)].\
            dropna(subset=['add_rm_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'add_rm_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 0.68/-0.26

# 300; add / removal; big chg

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['index']=='CSI300')&(icom['trackingMoneyChg_dv_pv'].abs()>0.75)].\
            dropna(subset=['add_rm_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'add_rm_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 3.56/2.69
