﻿#$%^&* pIntra_cn_1800uni_imb.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 22 02:15:59 2023

@author: thzhang
"""


import pandas as pd
import numpy as np

import os
import util as yu
import util_intra as yui

from multiprocessing import Pool


### get sd 

i_sd = yui.get_intra_sd()



### imb

if __name__=='__main__':

    root3 = '/dat/summit_capital/TZ/PROD_Q/q_intraday_odbk_imb/'
    with Pool(20) as pool:
        i_feat_imb = pool.map(yui.get_feat_imb, [root3+f for f in os.listdir(root3)])
    i_feat_imb = pd.concat(i_feat_imb, axis = 0)



### combine 

icom = i_sd.merge(i_feat_imb, on = ['Ticker', 'tm1d', 'ts15m_s'], how = 'left')
icom = icom.sort_values(['Ticker', 'tm1d', 'ts15m_e'])

icom['rawret_m15m_rk'] = icom.groupby(['tm1d', 'ts15m_e'])['rawret_m15m'].apply(yu.uniformed_rank)




# i_feat_imb.columns
# 'bidd_tot', 'askd_tot', 'bidv_nmstd15m', 'bidv_nmstd60m',
# 'bidv_nmstdsod', 'askv_nmstd15m', 'askv_nmstd60m', 'askv_nmstdsod',
# 'bidp_span_avg5m', 'bidp_span_avg15m', 'bidp_span_avg60m',
# 'bidp_span_avgsod', 'askp_span_avg5m', 'askp_span_avg15m',
# 'askp_span_avg60m', 'askp_span_avgsod', 'baratio_avg5m',
# 'baratio_avg15m', 'baratio_avg60m', 'baratio_avgsod', 'baratio_std15m',
# 'baratio_std60m', 'baratio_stdsod', 'Ticker', 'tm1d', 'ts15m_s'




       
#---- 10-level price span
       
icom['bidp_span_avg15m_bk'] = icom.groupby(['tm1d','ts15m_e'])['bidp_span_avg15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'bidp_span_avg15m_bk', 'bidp_span_avg15m', 
                     col_ret = 'rawret_p15m_rk') # -100 +100
yui.plot_barchart_cn(icom[icom['rawret_m15m']>0], 'bidp_span_avg15m_bk', 
                     'bidp_span_avg15m', col_ret = 'rawret_p15m_rk') # random
yui.plot_barchart_cn(icom[icom['rawret_m15m']<0], 'bidp_span_avg15m_bk', 
                     'bidp_span_avg15m', col_ret = 'rawret_p15m_rk') # -60 +300
yui.plot_barchart_cn(icom[icom['rawret_m15m_rk']<-0.5], 'bidp_span_avg15m_bk', 
                     'bidp_span_avg15m', col_ret = 'rawret_p15m_rk') # -100 +400 

icom['askp_span_avg15m_bk'] = icom.groupby(['tm1d','ts15m_e'])['askp_span_avg15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'askp_span_avg15m_bk', 'askp_span_avg15m', col_ret = 'rawret_p15m_rk') # -100 +50 -118
yui.plot_barchart_cn(icom[icom['rawret_m15m_rk']>0.5], 'askp_span_avg15m_bk', 
                     'askp_span_avg15m', col_ret = 'rawret_p15m_rk') # -90 -574 
yui.plot_bar
chart_cn(icom[icom['rawret_m15m'].gt(0)&icom['rawret_m15m_rk'].gt(0.3)], 'askp_span_avg15m_bk', 
                     'askp_span_avg15m', col_ret = 'rawret_p15m_rk') # 
yui.plot_barchart_cn(icom[icom['rawret_m15m']<0], 'askp_span_avg15m_bk', 
                     'askp_span_avg15m', col_ret = 'rawret_p15m_rk') # -150 + 160 +109


icom['askp_span_avg15m_rk'] = icom.groupby(['tm1d','ts15m_e'])['askp_span_avg15m'].apply(yu.uniformed_rank)
icom['bidp_span_avg15m_rk'] = icom.groupby(['tm1d','ts15m_e'])['bidp_span_avg15m'].apply(yu.uniformed_rank)
icom['test'] = np.nan
c1 = icom['rawret_m15m_rk'] > 0
icom.loc[c1, 'test'] = - icom.loc[c1, 'rawret_m15m_rk'] * (icom.loc[c1, 'askp_span_avg15m_rk']+1)
c2 = icom['rawret_m15m_rk'] < 0
icom.loc[c2, 'test'] = - icom.loc[c2, 'rawret_m15m_rk'] * (1+icom.loc[c2, 'bidp_span_avg15m_rk'])
icom['test_bk'] = icom.groupby(['tm1d','ts15m_s'])['test'].apply(lambda x: yu.pdqcut(x, bins=10)).values
yui.plot_barchart_cn(icom, 'test_bk', 'test', col_ret = 'rawret_p15m_rk') # -420 +100

icom['test'] = np.nan
c1 = icom['rawret_m15m_rk'] > 0.3
icom.loc[c1, 'test'] = - icom.loc[c1, 'rawret_m15m_rk'] * (icom.loc[c1, 'askp_span_avg15m_rk']+1)
c2 = icom['rawret_m15m_rk'] < -0.3
icom.loc[c2, 'test'] = - icom.loc[c2, 'rawret_m15m_rk'] * (1+icom.loc[c2, 'bidp_span_avg15m_rk'])
icom['test_bk'] = icom.groupby(['tm1d','ts15m_s'])['test'].apply(lambda x: yu.pdqcut(x, bins=10)).values
yui.plot_barchart_cn(icom, 'test_bk', 'test', col_ret = 'rawret_p15m_rk') # -480 +128 

icom['test2'] = np.nan
c1 = icom['rawret_m15m_rk'] >= 0.3
icom.loc[c1, 'test2'] = - (icom.loc[c1, 'askp_span_avg15m_rk']+1)
c2 = icom['rawret_m15m_rk'] <= -0.3
icom.loc[c2, 'test2'] = (icom.loc[c2, 'bidp_span_avg15m_rk']+1)
icom['test2_bk'] = icom.groupby(['tm1d','ts15m_s'])['test2'].apply(lambda x: yu.pdqcut(x, bins=10)).values
yui.plot_barchart_cn(icom, 'test2_bk', 'test2', col_ret = 'rawret_p15m_rk') # -360 +280 ###!!!





icom['span_ratio_avg15m'] = icom['bidp_span_avg15m'] / icom['askp_span_avg15m']
icom['span_ratio_avg15m_bk'] = icom.groupby(['tm1d','ts15m_e'])['span_ratio_avg15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'span_ratio_avg15m_bk', 'span_ratio_avg15m', col_ret = 'rawret_p15m_rk') # random 
yui.plot_barchart_cn(icom[icom['rawret_m15m_rk'].abs().gt(0.3)], 'span_ratio_avg15m_bk', 'span_ratio_avg15m', col_ret = 'rawret_p15m_rk')


#---- odbk dev / mean ###!!!

icom['bidv_nmstd15m_bk'] = icom.groupby(['tm1d','ts15m_e'])['bidv_nmstd15m'].
apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'bidv_nmstd15m_bk', 'bidv_nmstd15m', col_ret = 'rawret_p15m_rk') # 200 -155
yui.plot_barchart_cn(icom[icom['rawret_m15m']<0], 'bidv_nmstd15m_bk', 
                     'bidv_nmstd15m', col_ret = 'rawret_p15m_rk') #360 -100
yui.plot_barchart_cn(icom[icom['rawret_m15m']>0], 'bidv_nmstd15m_bk', 
                     'bidv_nmstd15m', col_ret = 'rawret_p15m_rk') #70 -230

icom['askv_nmstd15m_bk'] = icom.groupby(['tm1d','ts15m_e'])['askv_nmstd15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'askv_nmstd15m_bk', 'askv_nmstd15m', col_ret = 'rawret_p15m_rk') # 250 -170
yui.plot_barchart_cn(icom[icom['rawret_m15m']<0], 'askv_nmstd15m_bk', 
                     'askv_nmstd15m', col_ret = 'rawret_p15m_rk') # 400 -100 
yui.plot_barchart_cn(icom[icom['rawret_m15m']>0], 'askv_nmstd15m_bk', 
                     'askv_nmstd15m', col_ret = 'rawret_p15m_rk') # 100 -240
yui.plot_barchart_cn(icom[icom['rawret_m15m_rk'].abs().lt(0.3)], 'askv_nmstd15m_bk', 
                     'askv_nmstd15m', col_ret = 'rawret_p15m_rk') # 320 -120
yui.plot_barchart_cn(icom[icom['rawret_m15m_rk'].gt(0.3)], 'askv_nmstd15m_bk', 
                     'askv_nmstd15m', col_ret = 'rawret_p15m_rk') # 0 -230

icom['ratio_nmstd15m'] = icom['bidv_nmstd15m'] / icom['askv_nmstd15m']
icom['ratio_nmstd15m_bk'] = icom.groupby(['tm1d','ts15m_e'])['ratio_nmstd15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'ratio_nmstd15m_bk', 'ratio_nmstd15m', col_ret = 'rawret_p15m_rk') # -20 -90 -17

icom['ba_std_diff'] = (icom['bidv_nmstd15m'] - icom['askv_nmstd15m']).abs() / (icom['bidv_nmstd15m'] + icom['askv_nmstd15m'])
icom['ba_std_diff_bk'] = icom.groupby(['tm1d','ts15m_e'])['ba_std_diff'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'ba_std_diff_bk', 'ba_std_diff', col_ret = 'rawret_p15m_rk') # -100 0



#---- 10-level v 



icom['baratio_avg15m_bk'] = icom.groupby(['tm1d','ts15m_s'])['baratio_avg15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'baratio_avg15m_bk', 'baratio_avg15m', col_ret = 'rawret_p15m_rk') # -170 0
yui.plot_barchart_cn(icom[icom['rawret_m15m']<0], 'baratio_avg15m_bk', 
                     'baratio_avg15m', col_ret = 'rawret_p15m_rk') # -170 +100
yui.plot_barchart_cn(icom[icom['rawret_m15m']>0], 'baratio_avg15m_bk', 
                     'baratio_avg15m', col_ret = 'rawret_p15m_rk') # -200 -90



#---- baratio std
 

icom['baratio_std15m_bk'] = icom.groupby(['tm1d','ts15m_s'])['baratio_std15m'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'baratio_std15m_bk', 'baratio_std15m', col_ret = 'rawret_p15m_rk') # 170 -126 -77


#---- chg in bids/ asks w.r.t. price chg
# incrase / decrease do not matter
# the bigger the change, the lower the return

icom['bidd_tot_df'] = icom['bidd_tot'] - icom.groupby(['Ticker', 'tm1d'])['bidd_tot'].shift()
icom['bidd_tot_df_dv_curr'] = icom['bidd_tot_df'] / icom['bidd_tot']
icom['bidd_tot_df_dv_pv'] = icom['bidd_tot_df'] / icom['avgPVadj']
icom['askd_tot_df'] = icom['askd_tot'] - icom.groupby(['Ticker', 'tm1d'])['askd_tot'].shift()
icom['askd_tot_df_dv_curr'] = icom['askd_tot_df'] / icom['askd_tot']
icom['askd_tot_df_dv_pv'] = icom['askd_tot_df'] / icom['avgPVadj']

icom['ba_df_df'] = icom['bidd_tot_df'] - icom['askd_tot_df']
icom['ba_df_df_dv_sm'] = icom['ba_df_df'] / (icom['bidd_tot_df'].abs() + icom['askd_tot_df'].abs())
icom['ba_df_df_dv_tot'] = icom['ba_df_df'] / (icom['bidd_tot'] + icom['askd_tot'])


for c in ['bidd_tot_df_dv_curr','bidd_tot_df_dv_pv','askd_tot_df_dv_curr',
          'askd_tot_df_dv_pv','ba_df_df_dv_sm','ba_df_df_dv_tot']:
    icom[c+'_bk'] = icom.groupby(['tm1d', 'ts15m_e'])[c].apply(lambda x: yu.pdqcut(x,bins=10)).values
    yui.plot_barchart_cn(icom, c+'_bk', c, col_ret = 'rawret_p15m_rk') 

