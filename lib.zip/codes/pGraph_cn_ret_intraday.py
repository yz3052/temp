﻿#$%^&* pGraph_cn_ret_intraday.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri May  6 09:29:00 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sklearn.linear_model import LinearRegression

# this studies 1min / 5min correlation matrix intraday
# not working though


COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD',
       'RESVOL', 'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL',
       'AIRLINES', 'AUTOCOMP', 'BANKS', 'BIOTECH', 'CAPGOODS', 'CHEMICAL',
       'COMMSVCS', 'COMMUNIC', 'COMPUTER', 'CONSDUR', 'CONSTPP', 'CONSVCS',
       'DIVFINAN', 'DIVMETAL', 'ENERGY', 'FOODPRD', 'FOODRETL', 'HEALTH',
       'HSHLDPRD', 'INSURAN', 'INTERNET', 'MEDIA', 'OILEXPL', 'OILGAS',
       'PHARMAC', 'PRECMETL', 'REALEST', 'RETAIL', 'SEMICOND', 'SOFTWARE',
       'STEEL', 'TELECOM', 'TRANSPRT', 'UTILITY']

### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])


### get trading dates 

tdates = yu.get_sql("select distinct trade_dt as datadate from wind_prod.dbo.ashareeodprices where trade_dt >= '20170101' ")
tdates['datadate'] = pd.to_datetime(tdates['datadate'], format='%Y%m%d')
tdates = tdates.sort_values('datadate').reset_index(drop = True)




### calculate correlation matrix of 1 min ret 

o_corr_1min_sum = []

for dt in tdates['datadate']:
    print (dt.strftime('%Y%m%d'), end = ' ')
    
    ret1min = yu.get_sql('''select ticker, 5*floor(trade_minutes/5) as hh5m, sum(ret) as ret 
                             from cndbprod.dbo.trade_cn_kline
                             where datadate = '{0}' and trade_minutes<1457 
							 group by 5*floor(trade_minutes/5), ticker
                         '''.format(dt.strftime('%Y-%m-%d')) )
    
    
    t_ret_1min_pv = ret1min.pivot_table(index = 'hh5m', columns = 'ticker', values = 'ret')
    
    t_ret_1min_pv_nancnt = t_ret_1min_pv.isnull().sum(axis=0)
    t_ret_1min_pv_nancnt = t_ret_1min_pv_nancnt[t_ret_1min_pv_nancnt>20]
    if len(t_ret_1min_pv_nancnt) > 0:
        t_ret_1min_pv = t_ret_1min_pv.drop(columns = t_ret_1min_pv_nancnt.index.tolist())
    
    t_ret_1min = t_ret_1min_pv.corr()
    t_ret_1min.values[[np.arange(len(t_ret_1min))]*2] = np.nan
    if len(t_ret_1min) == 0:
        continue
    
    t_corr_1min_mean = t_ret_1min.mean(axis = 1)
    t_corr_1min_mean = t_corr_1min_mean.reset_index().rename(columns={0: 'ret_1min_corr_mean'})
    t_corr_1min_mean['datadat
e']=dt
    o_corr_1min_sum.append(t_corr_1min_mean)

o_corr_1min_sum = pd.concat(o_corr_1min_sum, axis = 0)
o_corr_1min_sum = o_corr_1min_sum.sort_values('datadate')
c_sh = o_corr_1min_sum['ticker'].str[0].isin(['6'])
c_sz = o_corr_1min_sum['ticker'].str[0].isin(['0','3'])
o_corr_1min_sum.loc[c_sh, 'ticker'] = o_corr_1min_sum.loc[c_sh, 'ticker'] + '.SH'
o_corr_1min_sum.loc[c_sz, 'ticker'] = o_corr_1min_sum.loc[c_sz, 'ticker'] + '.SZ'

o_corr_1min_sum.to_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_ret_1min_corr.parquet')



### combine

icom = pd.merge_asof(i_sd, o_corr_1min_sum, by='ticker', on='datadate')
icom = icom.sort_values(['ticker','datadate'])

icom['ret_1min_corr_mean_bk'] = icom.groupby('datadate')['ret_1min_corr_mean'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ret_1min_corr_mean_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=20),on='datadate')['ret_1min_corr_mean'].mean().values
icom['ret_1min_corr_mean_t20d_bk'] = icom.groupby('datadate')['ret_1min_corr_mean_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ret_1min_corr_mean_t65d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=91),on='datadate')['ret_1min_corr_mean'].mean().values
icom['ret_1min_corr_mean_t65d_bk'] = icom.groupby('datadate')['ret_1min_corr_mean_t65d'].apply(lambda x: yu.pdqcut(x,bins=10)).values


yu.create_cn_3x3(icom, ['ret_1min_corr_mean_bk'], 'ret_1min_corr_mean') # -3 +1
yu.create_cn_3x3(icom, ['ret_1min_corr_mean_t20d_bk'], 'ret_1min_corr_mean_t20d') # -3 +2 0

yu.create_cn_3x3(icom, ['ret_1min_corr_mean_t65d_bk'], 'ret_1min_corr_mean_t65d') # 



