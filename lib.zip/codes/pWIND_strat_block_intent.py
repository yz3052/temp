﻿#$%^&* pWIND_strat_block_intent.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Jul  7 04:19:16 2022

@author: thzhang
"""

import requests
import json

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu


# only some alpha if we test with rawret




### get block intent data


proxies = {'http':'http://thzhang:Citadel580227!@proxy.mlp.com:3128','https':'https://thzhang:Citadel580227!@proxy.mlp.com:3128'} 
headers = {
    'Host': 'query.sse.com.cn',
    'Proxy-Connection': 'keep-alive',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.84 Safari/537.36',
    'Accept': '*/*',
    'Referer': 'http://www.sse.com.cn/',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-US,en;q=0.9',
    'Cookie': 'yfx_c_g_u_id_10000042=_ck21021913245814079982015937919; VISITED_STOCK_FUND_CODE=%5B%22600000%22%5D; VISITED_MENU=%5B%228734%22%2C%228537%22%2C%228446%22%2C%229055%22%2C%2210883%22%2C%228363%22%2C%228457%22%2C%228454%22%2C%228619%22%2C%228527%22%2C%228317%22%5D; VISITED_COMPANY_CODE=%5B%22600612%22%2C%22603605%22%2C%22600000%22%2C%22600019%22%2C%22603002%22%5D; VISITED_STOCK_CODE=%5B%22600612%22%2C%22600000%22%2C%22603605%22%2C%22600019%22%2C%22603002%22%5D; seecookie=%5B600612%5D%3A%u8001%u51E4%u7965%2C%u8BC1%u76D1%u4F1A%u884C%u4E1A%2C%5B603605%5D%3A%u73C0%u83B1%u96C5%2C%5B600000%5D%3A%u6D66%u53D1%u94F6%u884C%2C%5B600019%5D%3A%u5B9D%u94A2%u80A1%u4EFD%2C%5B603002%5D%3A%u5B8F%u660C%u7535%u5B50; gdp_user_id=gioenc-edc69gb2%2C3768%2C5511%2C9edc%2Cag3ga2b72044; ba17301551dcbaf9_gdp_session_id=c41bebd5-63d0-4a50-8d40-f6d5a736ccac; ba17301551dcbaf9_gdp_session_id_c41bebd5-63d0-4a50-8d40-f6d5a736ccac=true; yfx_f_l_v_t_10000042=f_t_1613759098404__r_t_1657181151605__v_t_1657181825361__r_c_34'}

url = 'http://query.sse.com.cn/commonQuery.do?&jsonCallBack=jsonpCallback91962515&isPagination=true&pageHelp.pageSize=25000&pageHelp.pageNo=1&pageHelp.beginPage=1&pageHelp.cacheSize=1&pageHelp.endPage=1&sqlId=COMMON_SSE_JYXXPL_DZJYXX_YXSB&stockId=&startDate=&endDate=&_=1657181825392'

resp = requests.get(url, headers=headers, proxies=proxies, verify = False)

i_block_intent = resp.text[22:-1]
i_block_intent = pd.DataFrame(json.loads(i_block_intent)['pageHelp']['data'])

i_block_intent.to_parquet(r'S:\Data\China Data Hunt\cache\pWIND_strat_block_intent.parquet')


i_block_intent = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_strat_block_intent.parquet')

i_bl
ock_intent['datadate'] = pd.to_datetime(i_block_intent['tradeday'])
i_block_intent.loc[i_block_intent['tradeDirection']=='B', 'dir'] = 1
i_block_intent.loc[i_block_intent['tradeDirection']=='S', 'dir'] = -1
i_block_intent['ticker'] = i_block_intent['stockId'] + '.SH'
i_block_intent['quantity'] = pd.to_numeric(i_block_intent['quantity']) * 10000
i_block_intent['price'] = pd.to_numeric(i_block_intent['price'])

i_block_intent = i_block_intent[['ticker','datadate','dir','price','quantity','memo']]





### sd


i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])


### combine

icom = i_sd.merge(i_block_intent, on = ['ticker','datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])

icom['q_dv_v'] = icom['quantity'].divide(icom['avgVadj'])


yu.create_cn_decay(icom[icom['dir']==1], 'dir')
yu.create_cn_decay(icom[(icom['dir']==1)&(icom['q_dv_v']>0.01)], 'dir')
yu.create_cn_decay(icom[icom['dir']==-1], 'dir')


icom['sgnl_b'] = np.nan
icom.loc[icom['dir']==1, 'sgnl_b'] = 1
icom['sgnl_b'] = icom.groupby('ticker')['sgnl_b'].ffill(limit = 10)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna(subset=['sgnl_b','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_b','BarrRet_CLIP_USD+1d', static_data = i_sd)  #0.16/-0.3

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna(subset=['sgnl_b','RawRet_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_b','RawRet_USD+1d', static_data = i_sd) #1.04/0.77

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna(subset=['sgnl_b','HedgeRet_CSI500_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_b','HedgeRet_CSI500_USD+1d', static_data = i_sd) #0.83/0.47





icom['sgnl_s'] = np.nan
icom.loc[icom['dir']==-1, 'sgnl_s'] = 1
icom['sgnl_s'] = icom.groupby('ticker')['sgnl_s'].ffill(limit =5)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna(subset=['sgnl_s','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_s','BarrRet_CLIP_USD+1d', static_data = i_sd) 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna(subset=['sgnl_s','RawRet_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_s','RawRet_USD+1d', static_data = i_sd)

