﻿#$%^&* pIntra_cn_1800uni_ls.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 22 21:38:17 2023

@author: thzhang
"""


import pandas as pd
import numpy as np

import os
import util as yu
import util_intra as yui

from multiprocessing import Pool


### get sd 

i_sd = yui.get_intra_sd()



### get feature

if __name__=='__main__':
    
    root2 = '/dat/summit_capital/TZ/PROD_Q/q_intraday_trd_ls/'
    with Pool(20) as pool:
        i_feat_ls = pool.map(yui.get_feat_ls, [root2+f for f in os.listdir(root2)])
    i_feat_ls = pd.concat(i_feat_ls, axis = 0)




### combine

icom = i_sd.merge(i_feat_ls, on = ['Ticker', 'tm1d', 'ts15m_s'], how = 'left')
icom = icom.sort_values(['Ticker', 'tm1d', 'ts15m_s']).reset_index(drop = True)




### net / pv

icom['nlarge_dv_pvsod'] = (icom['buy_large_sm15m'] - icom['sell_large_sm15m']) / icom[['buy_all_sod','sell_all_sod']].mean(axis=1)
icom['nlarge_dv_pvsod_bk'] = icom.groupby(['tm1d', 'ts15m_e'])['nlarge_dv_pvsod'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['nlarge_dv_pv'] = (icom['buy_large_sm15m'] - icom['sell_large_sm15m']) / icom[['buy_all_sm15m','sell_all_sm15m']].mean(axis=1)
icom['nlarge_dv_pv_bk'] = icom.groupby(['tm1d', 'ts15m_e'])['nlarge_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['nlargesod_dv_pvsod'] = (icom['buy_large_sod'] - icom['sell_large_sod']) / icom[['buy_all_sod','sell_all_sod']].mean(axis=1)
icom['nlargesod_dv_pvsod_bk'] = icom.groupby(['tm1d', 'ts15m_e'])['nlargesod_dv_pvsod'].apply(lambda x: yu.pdqcut(x,bins=10)).values


yui.plot_barchart_cn(icom, 'nlarge_dv_pvsod_bk', 'nlarge_dv_pvsod', col_ret = 'rawret_p15m_rk') # random
yui.plot_barchart_cn(icom, 'nlarge_dv_pv_bk', 'nlarge_dv_pv', col_ret = 'rawret_p15m_rk') # +250 -190
yui.plot_barchart_cn(icom, 'nlargesod_dv_pvsod_bk', 'nlargesod_dv_pvsod', col_ret = 'rawret_p15m_rk') # random
yui.plot_barchart_cn(icom[icom['rawret_sod'].lt(-0.03) & icom['ts15m_e'].dt.strftime('%H%M').le('1130')], 
                     'nlarge_dv_pv_bk', 'nlarge_dv_pv', col_ret = 'rawret_p60m')


icom['rawret_m15m_rk'] = icom.groupby(['tm1d','ts15m_e'])['rawret_m15m'].apply(yu.uniformed_rank)
icom['nlarge_dv_pv_rk'] = icom.groupby(['tm1d', 'ts15m_e'])['nlarge_dv_pv'].apply(yu.uniformed_rank)

icom['sgnl_l1'] = np.nan
c1 = icom['rawret_m60m'].abs().between(0.05, 0.08) & icom['ts15m_e'].dt.strftime('%H%M').le('1130')
icom.loc[c1, 'sgnl_l1'] = - icom.loc[c1, 'rawret_m15m_rk']
icom['sgnl_l1'] = icom.groupby(['Ticker','tm1d'])[
'sgnl_l1'].ffill(limit=4)
yui.plot_pnl_cn(icom, col_sgnl = 'sgnl_l1', col_ret = 'rawret_p15m') # ###??? overfit -> find out why it overfits



icom['sgnl_l2'] = np.nan
c1 = icom['rawret_m60m'].between(-0.08, -0.05) & icom['ts15m_e'].dt.strftime('%H%M').le('1130') 
icom.loc[c1, 'sgnl_l2'] = 1
c1 = icom['rawret_m60m'].between(0.05, 0.09) & icom['ts15m_e'].dt.strftime('%H%M').le('1130') 
icom.loc[c1, 'sgnl_l2'] = -1
icom['sgnl_l2'] = icom.groupby(['Ticker','tm1d'])['sgnl_l2'].ffill(limit=2)
yui.plot_pnl_cn(icom, col_sgnl = 'sgnl_l2', col_ret = 'rawret_p15m', neutral = False)









icom['nxlarge_dv_pv'] = (icom['buy_xlarge_sm15m'] - icom['sell_xlarge_sm15m']) / icom[['buy_all_sm15m','sell_all_sm15m']].mean(axis=1)
icom['nxlarge_dv_pv_bk'] = icom.groupby(['tm1d', 'ts15m_e'])['nxlarge_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'nxlarge_dv_pv_bk', 'nxlarge_dv_pv', col_ret = 'rawret_p15m_rk') # 235 -310


icom['n2large_dv_pv'] = icom['nxlarge_dv_pv'] + icom['nlarge_dv_pv']
icom['n2large_dv_pv_bk'] = icom.groupby(['tm1d', 'ts15m_e'])['n2large_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'n2large_dv_pv_bk', 'n2large_dv_pv', col_ret = 'rawret_p15m_rk') # +400 -390 #!!!
yui.plot_barchart_cn(icom, 'n2large_dv_pv_bk', 'n2large_dv_pv', col_ret = 'rawret_p15m')





icom['nsmall_dv_pvsod'] = (icom['buy_small_sm15m'] - icom['sell_small_sm15m']) / icom[['buy_all_sod','sell_all_sod']].mean(axis=1)
icom['nsmall_dv_pvsod_bk'] = icom.groupby(['tm1d', 'ts15m_e'])['nsmall_dv_pvsod'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'nsmall_dv_pvsod_bk', 'nsmall_dv_pvsod', col_ret = 'rawret_p15m_rk') # -280 +100

icom['nsmall_dv_pvsod_rk'] = icom.groupby(['tm1d','ts15m_e'])['nsmall_dv_pvsod'].apply(yu.uniformed_rank)
icom['n_dv_pvsod_rk'] = icom.groupby(['tm1d','ts15m_e'])['n_dv_pvsod'].apply(yu.uniformed_rank)
icom['l_m_s_rkdf'] = icom['n_dv_pvsod_rk'] - icom['nsmall_dv_pvsod_rk']
icom['l_m_s_rkdf_bk'] = icom.groupby(['tm1d', 'ts15m_e'])['l_m_s_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yui.plot_barchart_cn(icom, 'l_m_s_rkdf_bk', 'l_m_s_rkdf', col_ret = 'rawret_p15m_rk') # 70 -270

