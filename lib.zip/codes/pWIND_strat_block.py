﻿#$%^&* pWIND_strat_block.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  5 17:30:38 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime


# try: trailing 1y, read reports s


### sd

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])


### sd stable shortable 

i_sd_ss = pw.get_china_ss_sd()

### past returns 


i_pastret = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet',
                            columns = ['ticker', 'datadate', 'twap1000_2c_bret', 'twap1000_2c_bret_t4w'])
i_pastret = i_sd[['ticker', 'datadate']].merge(i_pastret, on = ['ticker', 'datadate'], how = 'inner')
i_pastret['twap1000_2c_bret_rk'] = i_pastret.groupby('datadate')['twap1000_2c_bret'].apply(yu.uniformed_rank)
i_pastret['twap1000_2c_bret_t4w_rk'] = i_pastret.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)
i_pastret = i_pastret.sort_values(['ticker','datadate'])
i_pastret['twap1000_2c_bret_t4wt1y'] = i_pastret.groupby('ticker').rolling(datetime.timedelta(days=365),min_periods = 60,on='datadate')['twap1000_2c_bret_t4w'].mean().values
i_pastret['twap1000_2c_bret_t4wt1y_rk'] = i_pastret.groupby('datadate')['twap1000_2c_bret_t4wt1y'].apply(yu.uniformed_rank)
i_pastret = i_pastret.sort_values('datadate')


### close price

i_c = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate, 
                 s_dq_preclose as prec, s_dq_amount*1000 as amt_tot,
                 s_dq_high as h, s_dq_low as l 
                 from wind_prod.dbo.ashareeodprices
                 where trade_dt >='20160101' ''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format='%Y%m%d')


### block

i_block = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                     s_block_price, s_block_amount*10000 as s_block_amount, s_block_frequency,
                     s_block_buyername, s_block_sellername
                     from [WIND_PROD].[dbo].[ASHAREBLOCKTRADE] 
                     where trade_dt>=  '20160101' ''')
i_block['datadate'] = pd.to_datetime(i_block['datadate'], format='%Y%m%d')
i_block = i_block.merge(i_c, on = ['ticker', 'datadate'], how = 'left')

i_block.loc[i_block['s_block_price']<i_block['prec'], 'dir'] = -1
i_block.loc[i_block['s_block_price']>i_block['prec'], 'dir'] = 1
i_block.loc[i_block['s_block_price']==i_block['prec'], 'dir'] = 0

i_block['amt_x_dir'] = i_block['dir'].multiply
(i_block['s_block_amount'])
i_block['amt_x_dir_dv_pvSameD'] = i_block['amt_x_dir'].divide(i_block['amt_tot'])

i_block['flg_buy_isinst']=0
i_block.loc[i_block['s_block_buyername'].str.contains('jigouzhuanyong|jiaoyidanyuan|zongbu'), 'flg_buy_isinst'] = 1
i_block['flg_sell_isinst']=0
i_block.loc[i_block['s_block_sellername'].str.contains('jigouzhuanyong|jiaoyidanyuan|zongbu'), 'flg_sell_isinst'] = 1

i_block['dir2'] = 0
c1 = (i_block['flg_buy_isinst']==1)&(i_block['flg_sell_isinst']==0)
i_block.loc[c1, 'dir2'] = 1
c2 = (i_block['flg_buy_isinst']==0)&(i_block['flg_sell_isinst']==1)
i_block.loc[c2, 'dir2'] = -1

i_block['amt_x_dir2'] = i_block['dir2'].multiply(i_block['s_block_amount'])
i_block['amt_x_dir2_dv_pvSameD'] = i_block['amt_x_dir2'].divide(i_block['amt_tot'])

i_block['amt_dv_pvSameD'] = i_block['s_block_amount'].divide(i_block['amt_tot'])

i_block['premium'] = i_block['s_block_price'].divide(i_block['prec']) - 1
i_block['premium2'] = (i_block['s_block_price']-i_block['l']).divide(i_block['h']-i_block['l'])
i_block['premium2'] = i_block['premium2'].replace(np.inf, np.nan).replace(-np.inf, np.nan)


i_block_buyer_opp_cnt = i_block.groupby(['ticker', 'datadate', 's_block_buyername'])['s_block_sellername'].nunique().reset_index()
i_block_buyer_opp_cnt = i_block_buyer_opp_cnt.rename(columns={'s_block_sellername':'buyer_opp_cnt'})
i_block_seller_opp_cnt = i_block.groupby(['ticker', 'datadate', 's_block_sellername'])['s_block_buyername'].nunique().reset_index()
i_block_seller_opp_cnt = i_block_seller_opp_cnt.rename(columns={'s_block_buyername':'seller_opp_cnt'})
i_block = i_block.merge(i_block_buyer_opp_cnt, on = ['ticker','datadate','s_block_buyername'], how = 'left')
i_block = i_block.merge(i_block_seller_opp_cnt, on = ['ticker','datadate','s_block_sellername'], how = 'left')

i_block['dir3'] = 0 
c1 = (i_block['buyer_opp_cnt']>1) & (i_block['seller_opp_cnt']==1)
i_block.loc[c1, 'dir3'] = 1
c2 = (i_block['seller_opp_cnt']>1) & (i_block['buyer_opp_cnt']==1)
i_block.loc[c2, 'dir3'] = -1

i_block['amt_x_dir3'] = i_block['dir3'].multiply(i_block['s_block_amount'])
i_block['amt_x_dir3_dv_pvSameD'] = i_block['amt_x_dir3'].divide(i_block['amt_tot'])

s_block1 = i_block.groupby(['ticker', 'datadate'])[['amt_x_dir','amt_x_dir2','amt_x_dir3','s_block_amount','amt_dv_pvSameD','amt_x_dir2_dv_pvSameD','amt_x_dir3_dv_pvSameD']].sum().reset_index()
s_block2 = i_block.groupby(['ticker', 'datadate'])[['premium','s_block_amount']].apply(lambda x: x['premium'].multiply(x[
's_block_amount']).sum() / x['s_block_amount'].sum())
s_block2.name = 'premium'
s_block2 = s_block2.reset_index()
s_block = s_block1.merge(s_block2, on = ['ticker', 'datadate'], how = 'outer')


### loop

o_loop = []

for dt in pd.date_range(start='2017-01-01',end='2022-06-30'):
    print(dt.strftime('%Y%m%d'),end=',')
    
    t_block = s_block[(s_block['datadate']<=dt)&(s_block['datadate']>=dt-pd.to_timedelta('365 days'))]
    
    s_loop_btch1 = t_block.groupby('ticker')[['amt_x_dir','amt_x_dir2','amt_x_dir3','s_block_amount']].sum().reset_index()
    s_loop_btch2 = t_block.groupby('ticker')['amt_dv_pvSameD'].mean().reset_index()
    s_loop_btch3 = t_block.groupby('ticker')['datadate'].count().reset_index()
    s_loop_btch3 = s_loop_btch3.rename(columns = {'datadate':'cnt_t1y'})
    s_loop = s_loop_btch1.merge(s_loop_btch2, on = 'ticker', how = 'outer')
    s_loop = s_loop.merge(s_loop_btch3, on = 'ticker', how = 'outer')
    s_loop['datadate'] = dt
    
    o_loop.append(s_loop)

o_loop = pd.concat(o_loop, axis=0)
o_loop = o_loop.rename(columns = {'amt_x_dir':'amt_x_dir_t1y','amt_x_dir2':'amt_x_dir2_t1y',
                                  'amt_x_dir3':'amt_x_dir3_t1y',
                                  's_block_amount': 'amt_t1y', 'amt_dv_pvSameD':'amt_dv_pvSameD_t1y'})



    
    
    
    
    
#------------------------------------------------------------------------------
### combine 2K
#------------------------------------------------------------------------------
    
    

icom = i_sd.merge(s_block, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(o_loop, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_pastret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])



# buy / sell direction

icom['flg_block_b'] = np.nan
icom.loc[icom['amt_x_dir']>0, 'flg_block_b'] = 1

icom['sgnl_block_b'] = icom.groupby('ticker')['flg_block_b'].ffill(limit = 5)

icom['flg_block_s'] = np.nan
icom.loc[icom['amt_x_dir']<0, 'flg_block_s'] = 1

icom['sgnl_block_s'] = icom.groupby('ticker')['flg_block_s'].ffill(limit = 5)


icom['flg_block_b2'] = np.nan
icom.loc[icom['amt_x_dir2']>0, 'flg_block_b2'] = 1

icom['sgnl_block_b2'] = icom.groupby('ticker')['flg_block_b2'].ffill(limit = 5)

icom['flg_block_s2'] = np.nan
icom.loc[icom['amt_x_dir2']<0, 'flg_block_s2'] = 1

icom['sgnl_block_s2'] = icom.groupby('ticker')['flg_block_s2'].ffill(limit = 5)



icom['flg_block_b3'] = np.nan
icom.loc[icom['amt_x_dir3_dv_p
vSameD']>0.5, 'flg_block_b3'] = 1

icom['flg_block_s3'] = np.nan
icom.loc[icom['amt_x_dir3_dv_pvSameD']<-0.5, 'flg_block_s3'] = 1




#yu.create_cn_decay(icom, 'flg_block_b')
#yu.create_cn_decay(icom, 'flg_block_s')
#yu.create_cn_decay(icom, 'flg_block_b2')
#yu.create_cn_decay(icom, 'flg_block_s2')
#yu.create_cn_decay(icom, 'flg_block_b3')



o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna(subset=['sgnl_block_b','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_block_b','BarrRet_CLIP_USD+1d', static_data = i_sd) 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna(subset=['sgnl_block_s','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_block_s','BarrRet_CLIP_USD+1d', static_data = i_sd) 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna(subset=['sgnl_block_b2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_block_b2','BarrRet_CLIP_USD+1d', static_data = i_sd) 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna(subset=['sgnl_block_s2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_block_s2','BarrRet_CLIP_USD+1d', static_data = i_sd) 


o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna(subset=['sgnl_block_large','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_block_large','BarrRet_CLIP_USD+1d', static_data = i_sd) 




# big block

icom['twap1000_2c_bret_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)

icom['amt_x_dir_dv_pv'] = icom['amt_x_dir'].divide(icom['avgPVadj'])
icom['amt_x_dir2_dv_pv'] = icom['amt_x_dir2'].divide(icom['avgPVadj'])
icom['amt_dv_pv'] = icom['s_block_amount'].divide(icom['avgPVadj']) 

icom['flg_big_buy'] = np.nan
icom.loc[icom['amt_x_dir_dv_pv']>1, 'flg_big_buy'] = 1
icom['flg_big_sell'] = np.nan
icom.loc[icom['amt_x_dir_dv_pv']<-1, 'flg_big_sell'] = 1

icom['flg_big2_buy'] = np.nan
icom.loc[icom['amt_x_dir2_dv_pv']>1, 'flg_big2_buy'] = 1
icom['flg_big2_sell'] = np.nan
icom.loc[icom['amt_x_dir2_dv_pv']<-1, 'flg_big2_sell'] = 1

icom['flg_big_amt'] = np.nan
icom.loc[icom['amt_dv_pv']>1, 'flg_big_amt'] = 1

yu.create_cn_decay(icom, 'flg_big_buy') # -ve ret n5d

yu.create_cn_decay(icom, 'flg_big2_buy') # random
yu.create_cn_decay(icom, 'flg_big_sell') # rdn
yu.create_cn_decay(icom, 'flg_big2_sell') # 
yu.create_cn_decay(icom, 'flg_big_amt') # -ve ret n5d

yu.create_cn_decay(icom[icom['twap1000_2c_bret_t4w_rk']<-0.5], 'flg_big_buy') 
yu.create_cn_decay(icom[icom['twap1000_2c_bret_t4w_rk']<-0.5], 'flg_big_amt') 



icom['sgnl1'] = np.nan
icom.loc[(icom['twap1000_2c_bret_t4w_rk']>0.5) & (icom['flg_big_amt']==1), 'sgnl1'] = 1
icom['sgnl1'] = icom.groupby('ticker')['sgnl1'].ffill(limit=5)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['sgnl1','RawRet_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','RawRet_USD+1d', static_data = i_sd) 



icom['sgnl2'] = np.nan
icom.loc[(icom['flg_big_buy']==1), 'sgnl2'] = 1
icom['sgnl2'] = icom.groupby('ticker')['sgnl2'].ffill(limit=1)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-12-31'))].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) 



# block with high / low premium 

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']

icom['amt_x_dir_dv_pv'] = icom['amt_x_dir'].divide(icom['avgPVadj'])
icom['amt_x_dir2_dv_pv'] = icom['amt_x_dir2'].divide(icom['avgPVadj'])
icom['amt_dv_pv'] = icom['s_block_amount'].divide(icom['avgPVadj']) 

icom['flg_premium_high'] = np.nan
icom.loc[icom['premium']>0.05, 'flg_premium_high'] = 1

icom['flg_premium_low'] = np.nan
icom.loc[(icom['premium']<-0.05)&(icom['amt_x_dir2_dv_pv']<-0.5), 'flg_premium_low'] = 1

yu.create_cn_decay(icom, 'flg_premium_high') # leaning -ve n20d
yu.create_cn_decay(icom, 'flg_premium_low') # random


# block / same day pv

icom['amt_dv_pvSameD_t1y_bk'] = icom.groupby('datadate')['amt_dv_pvSameD_t1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['amt_dv_pvSameD_t1y_secbk'] = icom.groupby(['datadate','GIND'])['amt_dv_pvSameD_t1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['amt_dv_pvSameD_t1y_orth'] = icom.groupby('datadate')[COLS+['amt_dv_pvSameD_t1y']].apply(lambda x: yu.orthogonal
ize_cn(x['amt_dv_pvSameD_t1y'], x[COLS])).values
icom['amt_dv_pvSameD_t1y_orth_bk'] = icom.groupby('datadate')['amt_dv_pvSameD_t1y_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['amt_dv_pvSameD_t1y_bk'], 'amt_dv_pvSameD_t1y')
yu.create_cn_3x3(icom, ['amt_dv_pvSameD_t1y_secbk'], 'amt_dv_pvSameD_t1y')



# t1y metrics


COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']

icom['amt_x_dir_t1y'] = icom['amt_x_dir_t1y'].fillna(0)
icom['amt_x_dir_t1y_bk'] = icom.groupby('datadate')['amt_x_dir_t1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['amt_x_dir_t1y_dv_pv'] = icom['amt_x_dir_t1y'].divide(icom['avgPVadj'])
icom['amt_x_dir_t1y_dv_pv_bk'] = icom.groupby('datadate')['amt_x_dir_t1y_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['amt_x_dir2_t1y'] = icom['amt_x_dir2_t1y'].fillna(0)
icom['amt_x_dir2_t1y_bk'] = icom.groupby('datadate')['amt_x_dir2_t1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['amt_x_dir2_t1y_dv_pv'] = icom['amt_x_dir2_t1y'].divide(icom['avgPVadj'])
icom['amt_x_dir2_t1y_dv_pv_bk'] = icom.groupby('datadate')['amt_x_dir2_t1y_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['amt_t1y'] = icom['amt_t1y'].fillna(0)
icom['amt_t1y'] = icom['amt_t1y'].replace(0, np.nan)
icom['amt_t1y_bk'] = icom.groupby('datadate')['amt_t1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['amt_t1y_dv_pv'] = icom['amt_t1y'].divide(icom['avgPVadj'])
icom['amt_t1y_dv_pv_bk'] = icom.groupby('datadate')['amt_t1y_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['amt_t1y_dv_pv_orth'] = icom.groupby('datadate')[COLS+['amt_t1y_dv_pv']].apply(lambda x: yu.orthogonalize_cn(x['amt_t1y_dv_pv'], x[COLS])).values
icom['amt_t1y_dv_pv_orth_bk'] = icom.groupby('datadate')['amt_t1y_dv_pv_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values




# orthogonalize? 

yu.create_cn_3x3(icom, ['amt_x_dir_t1y_bk'], 'amt_x_dir_t1y')
yu.create_cn_3x3(icom, ['amt_x_dir_t1y_dv_pv_bk'], 'amt_x_dir_t1y_dv_pv')
yu.create_cn_3x3(icom, ['amt_x_dir2_t1y_bk'], 'amt_x_dir2_t1y')
yu.create_cn_3x3(icom, ['amt_x_dir2_t1y_dv_pv_bk'], 'amt_x_dir2_t1y_dv_pv')

yu.create_cn_3x3(icom, ['amt_t1y_dv_pv_bk'], 'amt_t1y_dv_pv')
yu.create_cn_3x3(icom, ['amt_t1y_dv_pv_orth_bk'], 'amt_t1y_dv_pv_orth') # random



# t1y/q activity

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']

icom['cnt_t1y_bk'] = icom.groupby('datadate')['cnt_t1y'].a
pply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_t1y_orth'] = icom.groupby('datadate')[COLS+['cnt_t1y']].apply(lambda x: yu.orthogonalize_cn(x['cnt_t1y'], x[COLS])).values
icom['cnt_t1y_orth_bk'] = icom.groupby('datadate')['cnt_t1y_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['cnt_t1y_bk'], 'cnt_t1y')
yu.create_cn_3x3(icom, ['cnt_t1y_orth_bk'], 'cnt_t1y_orth')

