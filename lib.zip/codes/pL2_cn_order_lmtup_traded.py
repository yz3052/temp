﻿#$%^&* pL2_cn_order_lmtup_traded.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 19 11:29:37 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime




### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])



### get q data

i_lmtup = yu.get_q('''(get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sh_lmtup_order),
                      (get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sz_lmtup_order)''')

i_lmtup['code'] = i_lmtup['code'].str.decode('utf8')
c_sh = i_lmtup['code'].str[0].isin(['6'])
c_sz = i_lmtup['code'].str[0].isin(['0','3'])
i_lmtup.loc[c_sh, 'ticker'] = i_lmtup.loc[c_sh, 'code'] + '.SH'
i_lmtup.loc[c_sz, 'ticker'] = i_lmtup.loc[c_sz, 'code'] + '.SZ'
i_lmtup['datadate'] = pd.to_datetime(i_lmtup['date'])
i_lmtup = i_lmtup.sort_values(['ticker', 'datadate'])
i_lmtup = i_lmtup[i_lmtup['ticker'].notnull()]



### combine 

icom = i_sd.merge(i_lmtup, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])


### first look
       
icom['v_lmtup_od_del_dv_v'] = icom['v_lmtup_od_del'].divide(icom['V_l1d'])
icom['v_lmtup_od_del_dv_v_bk'] = icom.groupby('datadate')['v_lmtup_od_del_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['v_lmtup_od_del_dv_v_bk'], 'v_lmtup_od_del_dv_v') # mono: +3 -3 

icom['v_lmtup_od_add_dv_v'] = icom['v_lmtup_od_add'].divide(icom['V_l1d'])
icom['v_lmtup_od_add_dv_v_bk'] = icom.groupby('datadate')['v_lmtup_od_add_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['v_lmtup_od_add_dv_v_bk'], 'v_lmtup_od_add_dv_v') # random

icom['cnt_lmtup_od_del_dv_v'] = icom['cnt_lmtup_od_del'].divide(icom['V_l1d'])
icom['cnt_lmtup_od_del_dv_v_bk'] = icom.groupby('datadate')['cnt_lmtup_od_del_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cnt_lmtup_od_del_dv_v_bk'], 'cnt_lmtup_od_del_dv_v') # mono: +3 -3




### total quota 

icom['quota_dv_v'] = icom['v_lmtup_od_add'].divide(icom['V_l1d'])
icom['quota_dv_v_bk'] = icom.groupby('datadate')['quota_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['quota_dv_so'] = icom['v_lmtup_od_add'].divide(icom['FLOAT_l1d'])
icom['quota_dv_so_bk'] = icom.groupby('datadate')['quota_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['quota_dv_v_bk'], 'quota_dv_v') # random
yu.create_cn_3x3(icom, ['quota_dv_so_bk'
], 'quota_dv_so') # less mono: +1 +2 -5



### used quota

icom['v_lmtup_od_del_dv_v'] = icom['v_lmtup_od_del'].divide(icom['V_l1d'])
icom['v_lmtup_od_del_dv_v_bk'] = icom.groupby('datadate')['v_lmtup_od_del_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['v_lmtup_od_del_dv_v_t20d']  = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['v_lmtup_od_del_dv_v'].mean().values
icom['v_lmtup_od_del_dv_v_t20d_bk'] = icom.groupby('datadate')['v_lmtup_od_del_dv_v_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['v_lmtup_od_del_dv_v_t60d']  = icom.groupby('ticker').rolling(datetime.timedelta(days=84),on='datadate')['v_lmtup_od_del_dv_v'].mean().values
icom['v_lmtup_od_del_dv_v_t60d_bk'] = icom.groupby('datadate')['v_lmtup_od_del_dv_v_t60d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['v_lmtup_od_del_dv_v_t60d_sgnl'] = - icom.groupby('datadate')['v_lmtup_od_del_dv_v_t60d'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icom, ['v_lmtup_od_del_dv_v_bk'], 'v_lmtup_od_del_dv_v') # mono: +3 -3 
yu.create_cn_3x3(icom, ['v_lmtup_od_del_dv_v_t20d_bk'], 'v_lmtup_od_del_dv_v_t20d') # mono: +3 -2
yu.create_cn_3x3(icom, ['v_lmtup_od_del_dv_v_t60d_bk'], 'v_lmtup_od_del_dv_v_t60d') # mono: +2 -2

icom['v_lmtup_od_del_lowerP_dv_v'] = icom['v_lmtup_od_del_lowerP'].divide(icom['V_l1d'])
icom['v_lmtup_od_del_lowerP_dv_v_bk'] = icom.groupby('datadate')['v_lmtup_od_del_lowerP_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['v_lmtup_od_del_lowerP_dv_v_bk'], 'v_lmtup_od_del_lowerP_dv_v') # mono: +2.5 -2

icom['v_lmtup_od_del_upperP_dv_v'] = icom['v_lmtup_od_del_upperP'].divide(icom['V_l1d'])
icom['v_lmtup_od_del_upperP_dv_v_bk'] = icom.groupby('datadate')['v_lmtup_od_del_upperP_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['v_lmtup_od_del_upperP_dv_v_bk'], 'v_lmtup_od_del_upperP_dv_v') # mono: +3.5 -2.5

icom['v_lmtup_od_del_dv_quota'] = icom['v_lmtup_od_del'].divide(icom['v_lmtup_od_add'])
icom['v_lmtup_od_del_dv_quota_bk'] = icom.groupby('datadate')['v_lmtup_od_del_dv_quota'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['v_lmtup_od_del_dv_quota_bk'], 'v_lmtup_od_del_dv_quota') # mono: +3.5 -1


### used quota PNL

icom['v_lmtup_od_del_dv_v'] = icom['v_lmtup_od_del'].divide(icom['V_l1d'])
icom['v_lmtup_od_del_dv_v_t20d']  = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['v_lmtup_od_del_dv_v'].mean().values
icom['v_lmtup_od_del_dv_v_
t20d_sgnl'] = - icom.groupby('datadate')['v_lmtup_od_del_dv_v_t20d'].apply(yu.uniformed_rank).values
icom['v_lmtup_od_del_dv_v_t60d']  = icom.groupby('ticker').rolling(datetime.timedelta(days=84),on='datadate')['v_lmtup_od_del_dv_v'].mean().values
icom['v_lmtup_od_del_dv_v_t60d_sgnl'] = - icom.groupby('datadate')['v_lmtup_od_del_dv_v_t60d'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['v_lmtup_od_del_dv_v_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v_lmtup_od_del_dv_v_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.92/0.05
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['v_lmtup_od_del_dv_v_t60d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v_lmtup_od_del_dv_v_t60d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.86 / 0.95
