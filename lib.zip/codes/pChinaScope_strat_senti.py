﻿#$%^&* pChinaScope_strat_senti.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 25 07:02:19 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw


### get china scope



i_company = pd.read_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\company.parquet',
                            columns = ['stockCode','newsId','relevance'])
i_company = i_company[i_company['stockCode'].str.contains('\d{6}') &\
                      i_company['stockCode'].str.contains('S[HZ]') &\
                      i_company['stockCode'].str[0].isin(['0','3','6']) ]
i_company['ticker'] = i_company['stockCode'].str.split('_').str[0]+'.'+i_company['stockCode'].str.split('_').str[1]
i_company = i_company.drop(columns=['stockCode'])
i_company = i_company.drop_duplicates(subset = ['ticker','newsId'])

          
i_info = pd.read_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\info.parquet',
                         columns = ['newsId','newsTs','newsTitle_cn','newsSummary','relevance','emotionDetail'])
i_info = i_info.drop_duplicates()


i_news_com = i_company.merge(i_info, on = ['newsId'], how = 'left')
i_news_com['datadate'] = pd.to_datetime(pd.to_datetime(i_news_com['newsTs']).dt.date)+pd.to_timedelta('1 day')
i_news_com['emotionDetail_dict'] = i_news_com['emotionDetail'].apply(lambda x: eval(x.replace('=',':')))
i_news_com['emo_pos'] = i_news_com['emotionDetail_dict'].apply(lambda x: x[1])
i_news_com['emo_neg'] = i_news_com['emotionDetail_dict'].apply(lambda x: x[2])
i_news_com['emo_neu'] = i_news_com['emotionDetail_dict'].apply(lambda x: x[0])
i_news_com['emo_net'] = i_news_com['emo_pos'] - i_news_com['emo_neg']
i_news_com['emo_netV2'] = (i_news_com['emo_pos'] - i_news_com['emo_neg'])*(i_news_com['emo_pos'] + i_news_com['emo_neg'])

### generate daily metrics based on china scope

o_cs_metrics = []

for dt in pd.date_range(start = '2015-01-01', end = '2020-12-31'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    t_news_com = i_news_com[(i_news_com['datadate']<=dt) & (i_news_com['datadate']>=dt-pd.to_timedelta('91 days'))]
    t_news_com_highR = t_news_com[t_news_com['relevance']>=0.9]
    
    t_news_com_t1m = t_news_com[t_news_com['datadate']>=dt-pd.to_timedelta('31 days')]
    t_news_com_highR_t1m = t_news_com_t1m[t_news_com_t1m['relevance']>=0.9]
    t_news_com_t1m_1m = t_news_com[(t_news_com['datadate']<dt-pd.to_timedelta('31 days'))&(t_news_com['datadate']>=dt-pd.to_timedelta('62 days'))]
    t_news_com
_highR_t1m_1m = t_news_com_t1m_1m[t_news_com_t1m_1m['relevance']>=0.9]
    
    metrics_emo_net_t1q = t_news_com.groupby('ticker')[['emo_net','emo_netV2']].mean().reset_index()
    metrics_emo_net_t1q = metrics_emo_net_t1q.rename(columns={'emo_net':'emo_net_t1q','emo_netV2':'emo_netV2_t1q'})
    metrics_emo_net_highR_t1q = t_news_com_highR.groupby('ticker')[['emo_net','emo_netV2']].mean().reset_index()
    metrics_emo_net_highR_t1q = metrics_emo_net_highR_t1q.rename(columns={'emo_net':'emo_net_highR_t1q','emo_netV2':'emo_netV2_highr_t1q'})
    
    metrics_emo_net_t1m = t_news_com_t1m.groupby('ticker')[['emo_net','emo_netV2']].mean().reset_index()
    metrics_emo_net_t1m = metrics_emo_net_t1m.rename(columns={'emo_net':'emo_net_t1m','emo_netV2':'emo_netV2_t1m'})
    metrics_emo_net_highR_t1m = t_news_com_highR_t1m.groupby('ticker')[['emo_net','emo_netV2']].mean().reset_index()
    metrics_emo_net_highR_t1m = metrics_emo_net_highR_t1m.rename(columns={'emo_net':'emo_net_highR_t1m','emo_netV2':'emo_netV2_highR_t1m'})
    
    metrics_emo_net_t1m_1m = t_news_com_t1m_1m.groupby('ticker')[['emo_net','emo_netV2']].mean().reset_index()
    metrics_emo_net_t1m_1m = metrics_emo_net_t1m_1m.rename(columns={'emo_net':'emo_net_t1m_1m','emo_netV2':'emo_netV2_t1m_1m'})
    metrics_emo_net_highR_t1m_1m = t_news_com_highR_t1m_1m.groupby('ticker')[['emo_net','emo_netV2']].mean().reset_index()
    metrics_emo_net_highR_t1m_1m = metrics_emo_net_highR_t1m_1m.rename(columns={'emo_net':'emo_net_highR_t1m_1m','emo_netV2':'emo_netV2_highR_t1m_1m'})
    
    t_cs_metric = metrics_emo_net_t1q.merge(metrics_emo_net_t1m, on = 'ticker', how = 'outer')
    t_cs_metric = t_cs_metric.merge(metrics_emo_net_highR_t1q, on = 'ticker', how = 'outer')
    t_cs_metric = t_cs_metric.merge(metrics_emo_net_highR_t1m, on = 'ticker', how = 'outer')
    t_cs_metric = t_cs_metric.merge(metrics_emo_net_t1m_1m, on = 'ticker', how = 'outer')
    t_cs_metric = t_cs_metric.merge(metrics_emo_net_highR_t1m_1m, on = 'ticker', how = 'outer')
    t_cs_metric['datadate'] = dt
    
    o_cs_metrics.append(t_cs_metric)
    
o_cs_metrics = pd.concat(o_cs_metrics, axis = 0)

    

### get sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d',
                 'isin_hk_uni','csi300_flag',
                 'avgPVadj','avgPVadj_USD','volatility','sp
read','BarrRet_SRISK_USD+1d',
                 'EARNYILD','GROWTH']]


### combine

icom = i_sd_map.merge(o_cs_metrics, on = ['ticker','datadate'], how = 'left')

cols = ['emo_net_t1q', 'emo_netV2_t1q', 'emo_net_t1m',
       'emo_netV2_t1m', 'emo_net_highR_t1q', 'emo_netV2_highr_t1q',
       'emo_net_highR_t1m', 'emo_netV2_highR_t1m', 'emo_net_t1m_1m',
       'emo_netV2_t1m_1m', 'emo_net_highR_t1m_1m', 'emo_netV2_highR_t1m_1m']


# rank of sentiment
    
icom['emo_netV2_1mdfrk'] = icom['emo_netV2_t1m_rk'] - icom['emo_netV2_t1m_1m_rk']
icom['emo_netV2_1mdfrk_rk'] = icom.groupby('datadate')['emo_netV2_1mdfrk'].apply(yu.uniformed_rank).values
icom['emo_netV2_1mdfrk_bk'] = icom.groupby('datadate')['emo_netV2_1mdfrk'].apply(lambda x:yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['emo_netV2_1mdfrk_bk'], 'emo_netV2_1mdfrk')

# rank of delta sentiment

icom = icom.sort_values(['ticker','datadate'])
icom['emo_net_t1q_1m'] = icom.groupby('ticker')['emo_net_t1q'].shift(22).values
icom['emo_net_t1q_1mdf'] = icom['emo_net_t1q'] - icom['emo_net_t1q_1m']
icom['emo_net_t1q_1mdf_rk'] = icom.groupby('datadate')['emo_net_t1q_1mdf'].apply(yu.uniformed_rank).values
icom['emo_net_t1q_1mdf_bk'] = icom.groupby('datadate')['emo_net_t1q_1mdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['emo_net_t1q_1mdf_bk'], 'emo_net_t1q_1mdf') # +2.5, -1.5


icom['emo_net_t1m_1mdf'] = icom['emo_net_t1m'] - icom['emo_net_t1m_1m']
icom['emo_net_t1m_1mdf_rk'] = icom.groupby('datadate')['emo_net_t1m_1mdf'].apply(yu.uniformed_rank).values
icom['emo_net_t1m_1mdf_bk'] = icom.groupby('datadate')['emo_net_t1m_1mdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['emo_net_t1m_1mdf_bk'], 'emo_net_t1m_1mdf') # +1, -1

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['emo_net_t1m_1mdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'emo_net_t1m_1mdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['emo_net_t1q_1mdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'emo_net_t1q_1mdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 


### combine

icom_x300 = i_sd_map[i_sd_map['csi300_flag']!=1].merge(o_cs_metrics, on = ['ticker','datadate'], how = 'left')

icom_x300 = icom_x300.sort_values(['ticker','datadate'])
icom_x300['emo_net_t1q_1m'] = icom_x30
0.groupby('ticker')['emo_net_t1q'].shift(22).values
icom_x300['emo_net_t1q_1mdf'] = icom_x300['emo_net_t1q'] - icom_x300['emo_net_t1q_1m']
icom_x300['emo_net_t1q_1mdf_rk'] = icom_x300.groupby('datadate')['emo_net_t1q_1mdf'].apply(yu.uniformed_rank).values
icom_x300['emo_net_t1q_1mdf_bk'] = icom_x300.groupby('datadate')['emo_net_t1q_1mdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom_x300, ['emo_net_t1q_1mdf_bk'], 'emo_net_t1q_1mdf') # +2.5, -1.5


icom_x300['emo_net_t1m_1mdf'] = icom_x300['emo_net_t1m'] - icom_x300['emo_net_t1m_1m']
icom_x300['emo_net_t1m_1mdf_rk'] = icom_x300.groupby('datadate')['emo_net_t1m_1mdf'].apply(yu.uniformed_rank).values
icom_x300['emo_net_t1m_1mdf_bk'] = icom_x300.groupby('datadate')['emo_net_t1m_1mdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom_x300, ['emo_net_t1m_1mdf_bk'], 'emo_net_t1m_1mdf') # +1, -1


o_1 = yu.bt_cn_15(icom_x300[(icom_x300['datadate']<='2020-01-01')].\
            dropna(subset=['emo_net_t1q_1mdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'emo_net_t1q_1mdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # -0.91

