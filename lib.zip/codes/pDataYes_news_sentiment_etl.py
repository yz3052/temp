﻿#$%^&* pDataYes_news_sentiment_etl.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Sep  4 16:19:47 2022

@author: thzhang
"""



import pandas as pd

import os

import zipfile




root = '/dat/mdwarehouse/public/502897/3792/News_Sentiment_Data/Trial_20211111/news_company_score'

for i in os.listdir(root):    
    
    tpath = os.path.join(root, i)    
    tdata = pd.concat(
                    [pd.read_csv(zipfile.ZipFile(tpath).open(i)) for i in zipfile.ZipFile(tpath).namelist()],
                    ignore_index=True )
    tdata.to_parquet(os.path.join('/dat/summit_capital/TZ/China Data Hunt/Datayes/news_sentiment',i+'.parquet'))




root = '/dat/mdwarehouse/public/502897/3792/News_Sentiment_Data/Trial_20211111/news_stock_index_v2'

for i in os.listdir(root):    
    
    tpath = os.path.join(root, i)    
    tdata = pd.concat(
                    [pd.read_csv(zipfile.ZipFile(tpath).open(i)) for i in zipfile.ZipFile(tpath).namelist()],
                    ignore_index=True )
    tdata['TICKER_SYMBOL'] = tdata['TICKER_SYMBOL'].astype(str)
    tdata.to_parquet(os.path.join('/dat/summit_capital/TZ/China Data Hunt/Datayes/news_sentiment',i+'.parquet'))






root = '/dat/mdwarehouse/public/502897/3792/News_Sentiment_Data/Trial_20211111/news_tag_v1'

for i in os.listdir(root):    
    
    tpath = os.path.join(root, i)    
    tdata = pd.concat(
                    [pd.read_csv(zipfile.ZipFile(tpath).open(i)) for i in zipfile.ZipFile(tpath).namelist()],
                    ignore_index=True )
    tdata.to_parquet(os.path.join('/dat/summit_capital/TZ/China Data Hunt/Datayes/news_sentiment',i+'.parquet'))





root = '/dat/mdwarehouse/public/502897/3792/News_Sentiment_Data/Trial_20211111/vnews_content_v1'

for i in os.listdir(root):    
    
    tpath = os.path.join(root, i)    
    tdata = pd.concat(
                    [pd.read_csv(zipfile.ZipFile(tpath).open(i)) for i in zipfile.ZipFile(tpath).namelist()],
                    ignore_index=True )
    for c in tdata.columns.tolist():
        tdata[c] = tdata[c].astype(str)
    tdata.to_parquet(os.path.join('/dat/summit_capital/TZ/China Data Hunt/Datayes/news_sentiment',i+'.parquet'))



root = '/dat/mdwarehouse/public/502897/3792/News_Sentiment_Data/Trial_20211111/vnews_content_wechat'

for i in os.listdir(root):    
    
    tpath = os.path.join(root, i)    
    tdata = pd.concat(
                    [pd.read_csv(zipfile.ZipFile(tpath).open(i)) for i in zipfile.ZipFile(tpath).namelist()],
               
     ignore_index=True )
    tdata.to_parquet(os.path.join('/dat/summit_capital/TZ/China Data Hunt/Datayes/news_sentiment',i+'.parquet'))






root = '/dat/mdwarehouse/public/502897/3792/News_Sentiment_Data/Trial_20211111/vnews_summary_v1'

for i in os.listdir(root):    
    
    tpath = os.path.join(root, i)    
    tdata = pd.concat(
                    [pd.read_csv(zipfile.ZipFile(tpath).open(i)) for i in zipfile.ZipFile(tpath).namelist()],
                    ignore_index=True )
    tdata.to_parquet(os.path.join('/dat/summit_capital/TZ/China Data Hunt/Datayes/news_sentiment',i+'.parquet'))






#-----------------------------
### datayes security master mapping 
    
i_master = open(r"Z:\502897\3792\Master\md_security_20210304.txt",encoding='utf8').read()
i_master = [r.split('#@DatayesRow@#') for r in i_master.split('#@DatayesCol@#')]
i_master = pd.DataFrame(i_master[1:], columns = i_master[0])
i_master.to_parquet(r'S:\TZ\China Data Hunt\Datayes\master_ticker_mapping.parquet')

