﻿#$%^&* pTA_cn_zigzag_01.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec  8 12:31:48 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import util as yu

import os

import datetime



# when calc corr, this includes curr px: c_nm 

# take away
# cherry-picking didnt work. very high corr decreaes sample size





### sd

i_sd = yu.get_sd_cn_1800()
i_sd = i_sd.sort_values(['DataDate'])





### zigzag


# get data

i_zz = pd.read_parquet('/dat/summit_capital/TZ/tmp/pTA_cn_zigzag_featurepool7.parquet')
i_zz['T-1d'] = pd.to_datetime(i_zz['T-1d'])


# normalize to 0-1 range

cols = ['zz_vertex_1', 'zz_vertex_2', 'zz_vertex_3', 'zz_vertex_4',
       'zz_vertex_5', 'zz_vertex_6', 'zz_vertex_7', 'zz_vertex_8',
       'zz_vertex_9', 'zz_vertex_10', 'zz_vertex_11', 'zz_vertex_12',
       'zz_vertex_13', 'zz_vertex_14', 'zz_vertex_15']
cols_nm = [c+'_nm' for c in cols]
i_zz['range'] = i_zz[cols+['c']].max(axis=1) - i_zz[cols+['c']].min(axis=1)
i_zz[cols_nm] = i_zz[cols].sub(i_zz[cols+['c']].min(axis=1),axis=0).divide(i_zz['range'], axis = 0)
i_zz['zz_vertex_fut1_nm'] = (i_zz['zz_vertex_fut1'] - i_zz[cols].min(axis=1)) / i_zz['range']
i_zz['c_nm'] = (i_zz['c'] - i_zz[cols+['c']].min(axis=1)) / i_zz['range']

# get rid of rows with short history

i_zz = i_zz[i_zz['zz_vertex_15'].notnull()]

# change from float64 -> float32
# cols_32 = [c for c in i_zz.columns.tolist() if c not in ['Ticker', 'T-1d','zz_date_fut1']]
# i_zz[cols_32] = i_zz[cols_32].astype(np.float32)


### helper


from numba import njit
@njit
def numba_corr(matrix_curr_vx, matrix_hist_vx, arr_hist_vx_act, 
               matrix_curr_ln, matrix_hist_ln, 
               arr_curr_range, arr_hist_range,
               arr_curr_trend, arr_hist_trend):
    
    
    # calculate metrics for right targets
    
    array_vx_rght_mean = [0.0]*0
    array_vx_rght_std = [0.0]*0
    array_ln_rght_mean = [0.0]*0
    array_ln_rght_std = [0.0]*0
    
    for n in range(len(matrix_hist_vx)):
        
        matrix_vx_rght_row = matrix_hist_vx[n,:]
        value_vx_rght_mean = np.mean(matrix_vx_rght_row)
        array_vx_rght_mean.append(value_vx_rght_mean)
        array_vx_rght_demean = matrix_vx_rght_row - value_vx_rght_mean        
        array_vx_rght_std.append(np.sqrt(np.sum(array_vx_rght_demean**2)))
        
        matrix_ln_rght_row = matrix_hist_ln[n,:]
        value_ln_rght_mean = np.mean(matrix_ln_rght_row)
        array_ln_rght_mean.append(value_ln_rght_mea
n)
        array_ln_rght_demean = matrix_ln_rght_row - value_ln_rght_mean
        array_ln_rght_std.append(np.sqrt(np.sum(array_ln_rght_demean**2)))


    
    # loop thru left targets
    
    lst_frcst = [[0.0, 0.0]]*0
    for n in range(len(matrix_curr_vx)):
        
        # current left target
        
        array_vx_left = matrix_curr_vx[n,:]
        c_isnan = np.isnan(array_vx_left)
        if np.sum(c_isnan)>0:
            lst_frcst.append([np.nan, np.nan])
            continue        
        array_ln_left = matrix_curr_ln[n,:]
              
        # calculate left stats
        
        value_vx_left_mean = np.mean(array_vx_left)
        array_vx_left_demean = array_vx_left - value_vx_left_mean
        array_vx_left_demean2 = array_vx_left_demean**2
        value_vx_left_std = np.sqrt(np.sum(array_vx_left_demean2))
        
        value_ln_left_mean = np.mean(array_ln_left)
        array_ln_left_demean = array_ln_left - value_ln_left_mean
        array_ln_left_demean2 = array_ln_left_demean**2        
        value_ln_left_std = np.sqrt(np.sum(array_ln_left_demean2))
        
        value_curr_range = arr_curr_range[n]
        
                
        # loop thru right history, and calc correlation, mae, etc.
        arr_gud_cnt = 0
        arr_tobeavg = 0
        
        for r in range(len(matrix_hist_vx)):
            
            value_hist_range = arr_hist_range[r]
            
            if arr_curr_trend[n] != arr_hist_trend[r]:
                continue
            if abs(value_curr_range - value_hist_range) / (value_curr_range + value_hist_range) * 2 > 0.2:
                continue            
            array_vx_rght = matrix_hist_vx[r,:]
            if abs(array_vx_rght[15] - array_vx_left[15]) / (value_curr_range + value_hist_range) * 2 > 0.1:
                continue
           
            value_vx_rght_mean = array_vx_rght_mean[r]
            array_vx_rght_demean = array_vx_rght - value_vx_rght_mean
                                   
            tt_vx_corr = np.dot(array_vx_left_demean, array_vx_rght_demean) / value_vx_left_std / array_vx_rght_std[r]
            tt_vx_mae = np.mean(np.abs(array_vx_left - array_vx_rght))
            
            array_ln_rght = matrix_hist_ln[r,:]
            value_ln_rght_mean = array_ln_rght_mean[r]
            array_ln_rght_demean = array_ln_rght - value_ln_rght_mean
            
            tt_len_corr = np.dot(array_ln_left_demean, array_ln_rght_demean) / value_ln_left_std / array_ln_
rght_std[r]
            
            if (tt_vx_corr>0.95) and (tt_vx_mae<0.1) and (tt_len_corr>0.7):
            #if (tt_vx_corr>0.95) :
                arr_gud_cnt+=1
                arr_tobeavg += array_vx_left[0] + arr_hist_vx_act[r] - array_vx_rght[0]
        
        # output results
        if arr_gud_cnt >= 1:
            lst_frcst.append([arr_tobeavg / arr_gud_cnt, arr_gud_cnt])
        else:
            lst_frcst.append([np.nan, np.nan])
            
    return np.array(lst_frcst)
    

def gen_frcst(param):
    
    t_sd, t_zz_hist, t_zz_curr, dd = param[0], param[1], param[2], param[3]
        
    cols_seg = ['seg_len_idx1', 'seg_len_idx2', 'seg_len_idx3', 'seg_len_idx4', 'seg_len_idx5',
               'seg_len_idx6', 'seg_len_idx7', 'seg_len_idx8', 'seg_len_idx9', 'seg_len_idx10', 
               'seg_len_idx11', 'seg_len_idx12', 'seg_len_idx13', 'seg_len_idx14']
    
    t_zz_hist = t_zz_hist[t_zz_hist['zz_vertex_15'].notnull()]
    t_zz_hist = t_zz_hist[cols_nm+cols_seg+['zz_curr_trend','range','c_nm','zz_vertex_fut1_nm']]
    
    t_zz_hist_vx = t_zz_hist[cols_nm+['c_nm']].values
    t_zz_hist_vx_act = t_zz_hist['zz_vertex_fut1_nm'].values
    t_zz_hist_ln = t_zz_hist[cols_seg].values
    t_zz_hist_range = t_zz_hist['range'].values
    t_zz_hist_trend = t_zz_hist['zz_curr_trend'].values
    
    
    t_zz_curr= t_zz_curr[t_zz_curr['Ticker'].isin(t_sd['Ticker'].tolist())]
    t_zz_curr = t_zz_curr[['Ticker','T-1d','c_nm','range','zz_curr_trend']+cols_nm+cols_seg]
    t_zz_curr_vx = t_zz_curr[cols_nm+['c_nm']].values
    t_zz_curr_ln = t_zz_curr[cols_seg].values
    t_zz_curr_range = t_zz_curr['range'].values
    t_zz_curr_trend = t_zz_curr['zz_curr_trend'].values
    
    s_zz_curr = pd.DataFrame(numba_corr(t_zz_curr_vx, t_zz_hist_vx, t_zz_hist_vx_act, t_zz_curr_ln, t_zz_hist_ln, 
                                        t_zz_curr_range, t_zz_hist_range, t_zz_curr_trend, t_zz_hist_trend), 
                             columns =  ['frcst','sample_cnt'])
    s_zz_curr['Ticker'] = t_zz_curr['Ticker'].tolist()
    s_zz_curr['T-1d'] = t_zz_curr['T-1d'].tolist()
    s_zz_curr = s_zz_curr.dropna()
    
    return s_zz_curr 


# o_zz_frcst = []
# cols_seg = ['seg_len_idx1', 'seg_len_idx2', 'seg_len_idx3', 'seg_len_idx4', 'seg_len_idx5',
#            'seg_len_idx6', 'seg_len_idx7', 'seg_len_idx8', 'seg_len_idx9', 'seg_len_idx10', 
#            'seg_len_idx11', 'seg_len_idx12', 'seg_len_idx13', 'seg_len_idx14']

# for dd in i_sd[i_sd['T-1d'].dt.year.is
in([2019])&i_sd['T-1d'].dt.month.between(6,12)]['T-1d'].sort_values().drop_duplicates():
#     print(dd.strftime('%Y%m%d'))
#     print(datetime.datetime.now().strftime('%H%M%S'))
    
    
#     # prepare curr and hist data
    
#     t_sd = i_sd[i_sd['DataDate']==dd]
    
#     t_zz_hist = i_zz[i_zz['T-1d'].lt(dd) & i_zz['zz_date_fut1'].lt(dd) & i_zz['T-1d'].gt(dd-pd.to_timedelta('730 days'))]
#     t_zz_hist = t_zz_hist[t_zz_hist['zz_vertex_15'].notnull()]
#     t_zz_hist = t_zz_hist[cols_nm+cols_seg+['zz_curr_trend','range','c_nm','zz_vertex_fut1_nm']]
    
#     ###??? limit hist sample to current ticker universe?
#     t_zz_hist_vx = t_zz_hist[cols_nm+['c_nm']].values
#     t_zz_hist_vx_act = t_zz_hist['zz_vertex_fut1_nm'].values
#     t_zz_hist_ln = t_zz_hist[cols_seg].values
#     t_zz_hist_range = t_zz_hist['range'].values
#     t_zz_hist_trend = t_zz_hist['zz_curr_trend'].values
    
#     t_zz_curr = i_zz[i_zz['T-1d'].eq(dd) & i_zz['Ticker'].isin(t_sd['Ticker'].tolist())]
#     t_zz_curr = t_zz_curr[['Ticker','T-1d','c_nm','range','zz_curr_trend']+cols_nm+cols_seg]
#     t_zz_curr_vx = t_zz_curr[cols_nm+['c_nm']].values
#     t_zz_curr_ln = t_zz_curr[cols_seg].values
#     t_zz_curr_range = t_zz_curr['range'].values
#     t_zz_curr_trend = t_zz_curr['zz_curr_trend'].values
    
    
#     # make forecasts
#     # njit: 
#     # njit(parallel=True): 580s
#     # njit(parallel=True,fastmath=True):  574s
#     # np.float64->32: 580s
#     yu.tic()
    
#     s_zz_curr = pd.DataFrame(numba_corr(t_zz_curr_vx, t_zz_hist_vx, t_zz_hist_vx_act, t_zz_curr_ln, t_zz_hist_ln, 
#                                         t_zz_curr_range, t_zz_hist_range, t_zz_curr_trend, t_zz_hist_trend), 
#                              columns =  ['frcst','sample_cnt'])
#     s_zz_curr['Ticker'] = t_zz_curr['Ticker'].tolist()
#     s_zz_curr['T-1d'] = t_zz_curr['T-1d'].tolist()
#     s_zz_curr = s_zz_curr.dropna()
#     yu.toc()
    
    
    
#     o_zz_frcst.append(s_zz_curr)
    
#     break

# o_zz_frcst = pd.concat(o_zz_frcst, axis=0)
# o_zz_frcst.to_parquet(r'S:\TZ\tmp\pTA_cn_zigzag_frcst5_19b.parquet')




from multiprocessing import Pool

if __name__ == '__main__':
    
    dd_list = i_sd[i_sd['T-1d']>='2017-01-01']['T-1d'].sort_values().drop_duplicates()


    o_zz_frcst_final = []

    
    for n in range(0, 49):
        t_dd_list = dd_list[n*30: n*30+30]
        
        print(n)
        yu.tic()
        with Pool(30) as p:
            o_zz_frcst = p.map(gen_frcst, 

                               ([i_sd[i_sd['DataDate']==dd], 
                                 i_zz[i_zz['T-1d'].lt(dd) & i_zz['zz_date_fut1'].lt(dd) & i_zz['T-1d'].gt(dd-pd.to_timedelta('730 days'))], 
                                 i_zz[i_zz['T-1d'].eq(dd)], 
                                 dd] for dd in t_dd_list))
            o_zz_frcst_final.extend(o_zz_frcst)
        yu.toc()
    



o_zz_frcst_final = pd.concat(o_zz_frcst_final, axis = 0)


icom = i_sd.merge(o_zz_frcst_final, on = ['Ticker', 'T-1d'], how = 'left')
icom = icom.merge(i_zz, on = ['Ticker', 'T-1d'], how = 'left')
icom = icom.sort_values(['Ticker', 'DataDate'])




icom['m1'] = (icom['frcst'] - icom['c_nm']) / icom['c_nm']
icom['m1'] = icom['m1'].replace(np.inf,np.nan).replace(-np.inf,np.nan)

icom['m1_bk'] = icom.groupby('DataDate')['m1'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom[icom['zz_curr_trend']==-1], ['m1_bk'], 'm1')



icom['m2'] = (icom['frcst'] - icom['c_nm']) 
icom['m2_bk'] = icom.groupby('DataDate')['m2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom[icom['zz_curr_trend']==-1], ['m2_bk'], 'm2')
yu.create_cn_3x3_linux(icom[icom['zz_curr_trend']==1], ['m2_bk'], 'm2')



icom['m3'] = icom['m2'] * icom['range']
icom['m3_bk'] = icom.groupby('DataDate')['m3'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom[icom['zz_curr_trend']==-1], ['m3_bk'], 'm3')
yu.create_cn_3x3_linux(icom[icom['zz_curr_trend']==1], ['m3_bk'], 'm3')


    

cols_i = [c for c in i_sd.columns.tolist() if c[:2]=='wd']
cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'SIZENL', 'LIQUIDTY']
icom['ones'] = 1

icom['m2_orth'] = icom.groupby('DataDate')[cols_i+cols_f+['m2','ones']].apply(lambda x: yu.orthogonalize_cn_v3(x['m2'],x[cols_f],x[cols_i],x['ones'])).values
icom['m3_orth'] = icom.groupby('DataDate')[cols_i+cols_f+['m3','ones']].apply(lambda x: yu.orthogonalize_cn_v3(x['m3'],x[cols_f],x[cols_i],x['ones'])).values

icom['m3_bk'] = icom.groupby('DataDate')['m3'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3_linux(icom[icom['zz_curr_trend']==-1], ['m3_bk'], 'm3')

icom['m3_rk'] = icom.groupby('DataDate')['m3'].apply(yu.uniformed_rank)
o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2017-06-01', '2021-12-31') ].\
            dropna(subset=['m3_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'm3_rk','BarrRet_CLIP_USD+
1d', static_data = i_sd) # 
# top decile not working 0 sharpe, 
