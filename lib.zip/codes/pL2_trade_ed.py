﻿#$%^&* pL2_trade_ed.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed May  4 20:10:31 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine





### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])


### ed

i_ed = yu.get_sql('''select [T-1d] as datadate, ticker
                              ,[last_ped]
                              ,[last_ed]
                              ,[next_ped]
                              ,[next_ed]
                              ,[EDTrdDate_last]
                              ,[EDTrdDate_next]
                      FROM [CNDBPROD].[dbo].[Static_Data_HC_GEM3L] ''')
c_sh = i_ed['ticker'].str[0].isin(['6'])
c_sz = i_ed['ticker'].str[0].isin(['0', '3'])
i_ed.loc[c_sh, 'ticker'] = i_ed.loc[c_sh, 'ticker'] + '.SH'
i_ed.loc[c_sz, 'ticker'] = i_ed.loc[c_sz, 'ticker'] + '.SZ'



      


### get large trade

i_large = pd.read_csv(r'S:\Infrastructure\backtester\data_cache\kdb_L2_cn_codebank_trade_sum_shsz.csv')

i_large['ticker'] = i_large['code'].astype(str).str.zfill(6)
i_large.loc[i_large['ticker'].str[0]=='6', 'ticker'] = i_large.loc[i_large['ticker'].str[0]=='6', 'ticker'] + '.SH'
i_large.loc[i_large['ticker'].str[0].isin(['0','3']), 'ticker'] = i_large.loc[i_large['ticker'].str[0].isin(['0','3']), 'ticker'] + '.SZ'

i_large['datadate'] = pd.to_datetime(i_large['date'])


### combine

icom = i_sd.merge(i_large, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_ed, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['d2ed'] = (icom['next_ed'] - icom['datadate']).dt.days

icom['V_l1d_t20dmean'] = icom.groupby('ticker').rolling(datetime.timedelta(days=20),on='datadate')['V_l1d'].mean().values
icom['V_l1d_t20dstd'] = icom.groupby('ticker').rolling(datetime.timedelta(days=20),on='datadate')['V_l1d'].std().values
icom['V_l1d_z'] = (icom['V_l1d'] - icom['V_l1d_t20dmean']).divide(icom['V_l1d_t20dstd'])

### large b before ed 


icom['large_b_wind_dv_pv'] = icom['large_b_wind'].divide(icom['pv_fullday'])
icom['large_b_wind_dv_pv_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['large_b_wind_dv_pv'].mean().values
icom['large_b_wind_dv_pv_t20dmax'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['large_b_wind_dv_pv'].max().values
icom['large_b_wind_dv_pv_t40d'] = icom.g
roupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['large_b_wind_dv_pv'].mean().values
icom['large_b_wind_dv_pv_bk'] = icom.groupby('datadate')['large_b_wind_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['large_b_wind_dv_pv_sgnl'] = icom.groupby('datadate')['large_b_wind_dv_pv'].apply(yu.uniformed_rank).values
icom['large_b_wind_dv_pv_t20d_sgnl'] = icom.groupby('datadate')['large_b_wind_dv_pv_t20d'].apply(yu.uniformed_rank).values
icom['large_b_wind_dv_pv_t40d_sgnl'] = icom.groupby('datadate')['large_b_wind_dv_pv_t40d'].apply(yu.uniformed_rank).values

icom['large_b_wind_dv_pv_t20d_sgnl_t20dmax'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['large_b_wind_dv_pv_t20d_sgnl'].max().values
icom['large_b_wind_dv_pv_t20d_sgnl_t20dmax_sgnl'] = np.nan
icom.loc[icom['d2ed']<=3, 'large_b_wind_dv_pv_t20d_sgnl_t20dmax_sgnl'] = 0
icom.loc[icom['large_b_wind_dv_pv_t20d_sgnl_t20dmax']>0.5, 'large_b_wind_dv_pv_t20d_sgnl_t20dmax_sgnl'] = 1
icom['large_b_wind_dv_pv_t20d_sgnl_t20dmax_sgnl']=icom.groupby('ticker')['large_b_wind_dv_pv_t20d_sgnl_t20dmax_sgnl'].ffill(limit=10)

icom['large_b_wind_dv_pv_bin_sgnl'] = np.nan
icom.loc[(icom['large_b_wind_dv_pv_bk']>=8) & (icom['d2ed']<=14), 'large_b_wind_dv_pv_bin_sgnl'] = 1
icom.loc[icom['d2ed']<=3, 'large_b_wind_dv_pv_bin_sgnl'] = 0
icom['large_b_wind_dv_pv_bin_sgnl'] = icom.groupby('ticker')['large_b_wind_dv_pv_bin_sgnl'].ffill()



yu.create_cn_3x3(icom, ['large_b_wind_dv_pv_bk'], 'large_b_wind_dv_pv') # 0.5 -2 +3.5
yu.create_cn_3x3(icom[icom['d2ed']<=14], ['large_b_wind_dv_pv_bk'], 'large_b_wind_dv_pv') # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['d2ed']<=14)&(icom['large_b_wind_dv_pv_t20d_sgnl']>0)].\
            dropna(subset=['large_b_wind_dv_pv_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'large_b_wind_dv_pv_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.71 / 0.93


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['d2ed']<=14)&(icom['large_b_wind_dv_pv_t40d_sgnl']>0)].\
            dropna(subset=['large_b_wind_dv_pv_t40d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'large_b_wind_dv_pv_t40d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.62 / 0.9


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['d2ed']<=14)].\
            dropna(subset=['large_b_wind_dv_pv_t20d_sgnl_t20dmax_sgnl','BarrRet_CLIP_USD+1d']).drop_du
plicates(subset=['ticker','datadate']),
            'large_b_wind_dv_pv_t20d_sgnl_t20dmax_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['large_b_wind_dv_pv_bin_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'large_b_wind_dv_pv_bin_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.31 / -1.01


icom.loc[icom['large_b_wind_dv_pv_sgnl']>0, 'ticker'].unique()
t1 = icom[icom['ticker']=='603993.SH']




### large v before ed


icom['V_l1d_z_sgnl'] = np.nan

icom.loc[(icom['V_l1d_z']>3)&(icom['d2ed']<=14), 'V_l1d_z_sgnl'] = 1
icom.loc[icom['d2ed']<=3, 'V_l1d_z_sgnl'] = 0
icom['V_l1d_z_sgnl'] = icom.groupby('ticker')['V_l1d_z_sgnl'].ffill()

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['V_l1d_z_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'V_l1d_z_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) 



### large net before ed 

icom['large_net_wind_dv_pv'] =(icom['large_b_wind']-icom['large_s_wind']).divide(icom['pv_fullday'])
icom['large_net_wind_dv_pv_bk'] = icom.groupby('datadate')['large_net_wind_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['large_net_wind_dv_pv_sgnl'] = icom.groupby('datadate')['large_net_wind_dv_pv'].apply(yu.uniformed_rank).values

icom['large_net_wind_dv_pv_bin_sgnl'] = np.nan
icom.loc[(icom['large_net_wind_dv_pv_sgnl']>0.95) & (icom['d2ed']<=14), 'large_net_wind_dv_pv_bin_sgnl'] = 1
icom.loc[(icom['d2ed']<=3)|(icom['d2ed'].isnull()), 'large_net_wind_dv_pv_bin_sgnl'] = 0
icom['large_net_wind_dv_pv_bin_sgnl'] = icom.groupby('ticker')['large_net_wind_dv_pv_bin_sgnl'].ffill()

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['large_net_wind_dv_pv_bin_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'large_net_wind_dv_pv_bin_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.26 / 0.06


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['EARNYILD']<-0.5)].\
            dropna(subset=['large_net_wind_dv_pv_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'large_net_wind_dv_pv_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd)

t1 = icom[icom['ticker']=='603993.SH']
