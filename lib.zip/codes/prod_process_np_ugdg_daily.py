﻿#$%^&* prod_process_np_ugdg_daily.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 30 08:15:30 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pyodbc
from sqlalchemy import create_engine
import urllib



import datetime


#==============================================================================
### conn
#==============================================================================

conn_wind = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=WIND_PROD;UID=svc_wind_dbo;PWD=DusONA3Habredl;TDS_Version=8.0;')
conn = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=CNDBPROD;UID=svc_fg_dbo;PWD=1eDecejiqu39;TDS_Version=8.0;')
engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))




# =============================================================================
### trade dates
# =============================================================================

sql = '''
select distinct TradeDate_next as TradeDate 
from CNDBPROD.dbo.Calendar_Dates_CN with (nolock)
where TradeDate_next >= '20170101'
'''
cd = pd.read_sql(sql,conn)
cd = cd.sort_values('TradeDate')
cd['TradeDateStr'] = cd['TradeDate'].apply(lambda r: str( r.year * 10000 + r.month * 100 + r.day ))
cd = cd.reset_index(drop=True)
cday = cd['TradeDate'].tolist()




# =============================================================================
### determine the dates we need to run
# =============================================================================

maxdd = pd.read_sql('''select max(datadate) from cndbdev.dbo.SUNTIME_ugdg ''', conn).values[0][0]
now = datetime.datetime.today()
date_index = cd[cd['TradeDate'].le(now) & cd['TradeDate'].gt(maxdd)]
date_index = date_index.index.tolist()


if len(date_index) == 0:
    quit()




# =============================================================================
# 
# =============================================================================


i_rpt_original = pd.read_sql('''select id, report_id, stock_code as Ticker,create_date,
                    report_year*10 + report_quarter as report_period, 
                    report_type, reliability, organ_id, author_name, 
                    forecast_or as frcst_or, forecast_np as frcst_np, forecast_eps as frcst_eps, 
                    gg_rating
_code as ggrate, 
                    target_price_ceiling as tp_upper, target_price_floor as tp_lower,
                    attention, entrytime
                    from suntime_prod.dbo.rpt_forecast_stk
                    WITH (NOLOCK)
                    ''', conn) 




# =============================================================================
# 
# =============================================================================

s_ugdg_preved = []

for t_i in date_index: 

    
    t_today = cday[t_i]
    t_last_tdate = cday[t_i-1]
    t_preday456 = t_today - pd.to_timedelta('456 days')
    
    # get ed calendar
    
    t_ed_cal = pd.read_sql('''select Ticker, last_ed
                               FROM [CNDBPROD].[dbo].[CNINFO_ED_format] 
                               with (nolock)
                               where datadate = '{0}'
                               order by Ticker, d2nexted 
                               '''.format(t_last_tdate.strftime('%Y-%m-%d')), conn)
    
    t_ed_cal = t_ed_cal.drop_duplicates(subset = ['Ticker'], keep = 'first')
       
    
            
    
    # get suntime data
    
    c1 = i_rpt_original['entrytime'].lt(t_last_tdate) | i_rpt_original['create_date'].lt(t_last_tdate)
    i_rpt = i_rpt_original[ c1 & (i_rpt_original['create_date']>=t_preday456.strftime('%Y-%m-%d'))]
    
    # format
    
    i_rpt = i_rpt.assign(create_date = pd.to_datetime(i_rpt['create_date']))
    i_rpt = i_rpt.assign(datadate = pd.to_datetime(i_rpt['entrytime'].dt.date))
    
    i_rpt = i_rpt.assign(author_name = i_rpt['author_name'].fillna('_'))        
    c1 = i_rpt['author_name'].str.contains(',')
    i_rpt.loc[c1, 'author_1st'] = i_rpt.loc[c1, 'author_name'].str.split(',').str[0]
    i_rpt.loc[~c1, 'author_1st'] = i_rpt.loc[~c1, 'author_name']
        
    # calculate prev rating 
    
    i_rpt_s3 = i_rpt.sort_values(['organ_id','author_1st','Ticker','report_period','datadate','entrytime','report_id']).reset_index(drop = True)
    
    t_rpt_s3_np = i_rpt_s3[['organ_id','author_1st','Ticker','report_period','report_id','datadate','frcst_np']]
    t_rpt_s3_np = t_rpt_s3_np.drop_duplicates(keep = 'last')
    t_rpt_s3_np = t_rpt_s3_np.dropna()
    t_rpt_s3_np['frcst_np_prev'] = t_rpt_s3_np.groupby(['organ_id', 'author_1st','Ticker','report_period'])['frcst_np'].shift()
    t_rpt_s3_np = t_rpt_s3_np.drop(columns = ['frcst_np'])    
    i_rpt_s3 = i_rpt_s3.merge(t_rpt_s3_np, on = ['organ_id','author_1st','Ticker','report_period'
,'report_id','datadate'], how = 'left')

    t_rpt_s3_eps = i_rpt_s3[['organ_id','author_1st','Ticker','report_period','report_id','datadate','frcst_eps']]
    t_rpt_s3_eps = t_rpt_s3_eps.drop_duplicates(keep = 'last')
    t_rpt_s3_eps = t_rpt_s3_eps.dropna()
    t_rpt_s3_eps['frcst_eps_prev'] = t_rpt_s3_eps.groupby(['organ_id', 'author_1st','Ticker','report_period'])['frcst_eps'].shift()
    t_rpt_s3_eps = t_rpt_s3_eps.drop(columns = ['frcst_eps'])    
    i_rpt_s3 = i_rpt_s3.merge(t_rpt_s3_eps, on = ['organ_id','author_1st','Ticker','report_period','report_id','datadate'], how = 'left')
    
    # calculate rating upgrades since prev ed
    
    i_rpt_s3 = i_rpt_s3[~i_rpt_s3['report_type'].isin([21, 28, 98])]
    i_rpt_s3 = i_rpt_s3.sort_values(['Ticker','report_period','organ_id','datadate'])
    
    i_rpt_s4 = i_rpt_s3.merge(t_ed_cal[['Ticker','last_ed']], on = 'Ticker', how = 'left')
    i_rpt_s4 = i_rpt_s4[(i_rpt_s4['create_date']>i_rpt_s4['last_ed']+pd.to_timedelta('7 days')) | (i_rpt_s4['last_ed'].isnull())] 
    
    # get the most recent ugdg
    
    t_ugdg_tk_maxdd = i_rpt_s4.groupby(['Ticker','organ_id'])['create_date'].max().reset_index()
    if len(t_ugdg_tk_maxdd)==0:
        continue
    t_ugdg_tk_maxdd = t_ugdg_tk_maxdd.merge(i_rpt_s4,on=['Ticker','organ_id','create_date'],how='inner')
    
    
    t_ugdg_tk_maxdd['flg_np_up'] = np.sign(t_ugdg_tk_maxdd['frcst_np'] - t_ugdg_tk_maxdd['frcst_np_prev'])
    t_ugdg_tk_maxdd['flg_eps_up'] = np.sign(t_ugdg_tk_maxdd['frcst_eps'] - t_ugdg_tk_maxdd['frcst_eps_prev'])
    
    t_ugdg_tk_maxdd['flg_np_up'] = t_ugdg_tk_maxdd['flg_np_up'].fillna(0)
    t_ugdg_tk_maxdd['flg_eps_up'] = t_ugdg_tk_maxdd['flg_eps_up'].fillna(0)    
    t_ugdg_tk_maxdd['sgn_flg_e_up'] = np.sign(t_ugdg_tk_maxdd[['flg_np_up','flg_eps_up']].sum(axis=1))   
    
    
    # get summary stats per organ_id
    
    t_ugdg_tk_maxdd = t_ugdg_tk_maxdd.groupby(['Ticker', 'organ_id'])[['sgn_flg_e_up']].apply(lambda x: np.sign(x.mean())).reset_index()
    
            
    # summarize rating upgrade per ticker

    s_up_ratio = t_ugdg_tk_maxdd.groupby('Ticker')['sgn_flg_e_up'].apply(lambda x: x.sum()/x.count())
    s_up_ratio = s_up_ratio.reset_index()        
    s_up_ratio = s_up_ratio.rename(columns={'sgn_flg_e_up':'np_pct_up_since_preved'})
    s_up_ratio['T-1d'] = t_last_tdate
    s_up_ratio['DataDate'] = t_today
    
    # output 
    s_ugdg_preved.append(s_up_ratio)
    
s_ugdg_preved = pd.concat(s_ugdg_preved, axis = 0)
s_ugdg_
preved = s_ugdg_preved[['Ticker', 'T-1d', 'DataDate', 'np_pct_up_since_preved']]




# =============================================================================
# 
# =============================================================================








s_ugdg_t1q = []

for t_i in date_index:
    
    t_today = cday[t_i]
    t_last_tdate = cday[t_i-1]
    t_preday91 = t_today - pd.to_timedelta('91 days')
    t_preday456 = t_today - pd.to_timedelta('456 days')
    
            
    
    # get suntime data
    
    c1 = i_rpt_original['entrytime'].lt(t_last_tdate) | i_rpt_original['create_date'].lt(t_last_tdate)
    i_rpt = i_rpt_original[ c1 & (i_rpt_original['create_date']>=t_preday456.strftime('%Y-%m-%d'))]
    
    # format
    
    i_rpt = i_rpt.assign(create_date = pd.to_datetime(i_rpt['create_date']))
    i_rpt = i_rpt.assign(datadate = pd.to_datetime(i_rpt['entrytime'].dt.date))
    
    i_rpt = i_rpt.assign(author_name = i_rpt['author_name'].fillna('_'))
    c1 = i_rpt['author_name'].str.contains(',')
    i_rpt.loc[c1, 'author_1st'] = i_rpt.loc[c1, 'author_name'].str.split(',').str[0]
    i_rpt.loc[~c1, 'author_1st'] = i_rpt.loc[~c1, 'author_name']
        
    # calculate prev rating 
    
    i_rpt_s3 = i_rpt.sort_values(['organ_id','author_1st','Ticker','report_period','datadate','entrytime','report_id']).reset_index(drop = True)
    
    t_rpt_s3_np = i_rpt_s3[['organ_id','author_1st','Ticker','report_period','report_id','datadate','frcst_np']]
    t_rpt_s3_np = t_rpt_s3_np.drop_duplicates(keep = 'last')
    t_rpt_s3_np = t_rpt_s3_np.dropna()
    t_rpt_s3_np['frcst_np_prev'] = t_rpt_s3_np.groupby(['organ_id', 'author_1st','Ticker','report_period'])['frcst_np'].shift()
    t_rpt_s3_np = t_rpt_s3_np.drop(columns = ['frcst_np'])    
    i_rpt_s3 = i_rpt_s3.merge(t_rpt_s3_np, on = ['organ_id','author_1st','Ticker','report_period','report_id','datadate'], how = 'left')

    t_rpt_s3_eps = i_rpt_s3[['organ_id','author_1st','Ticker','report_period','report_id','datadate','frcst_eps']]
    t_rpt_s3_eps = t_rpt_s3_eps.drop_duplicates(keep = 'last')
    t_rpt_s3_eps = t_rpt_s3_eps.dropna()
    t_rpt_s3_eps['frcst_eps_prev'] = t_rpt_s3_eps.groupby(['organ_id', 'author_1st','Ticker','report_period'])['frcst_eps'].shift()
    t_rpt_s3_eps = t_rpt_s3_eps.drop(columns = ['frcst_eps'])    
    i_rpt_s3 = i_rpt_s3.merge(t_rpt_s3_eps, on = ['organ_id','author_1st','Ticker','report_period','report_id','datadate'], how = 'left')
    
    # calculate rating upgrad
es since prev ed
    
    i_rpt_s3 = i_rpt_s3[~i_rpt_s3['report_type'].isin([21, 28, 98])]
    i_rpt_s3 = i_rpt_s3.sort_values(['Ticker','report_period','organ_id','datadate'])
    
    i_rpt_s4 = i_rpt_s3[i_rpt_s3['create_date']>=t_preday91]
    
    # get the most recent ugdg
    
    t_ugdg_tk_maxdd = i_rpt_s4.groupby(['Ticker','organ_id'])['create_date'].max().reset_index()
    if len(t_ugdg_tk_maxdd)==0:
        continue
    t_ugdg_tk_maxdd = t_ugdg_tk_maxdd.merge(i_rpt_s4,on=['Ticker','organ_id','create_date'],how='inner')
    
    
    t_ugdg_tk_maxdd['flg_np_up'] = np.sign(t_ugdg_tk_maxdd['frcst_np'] - t_ugdg_tk_maxdd['frcst_np_prev'])
    t_ugdg_tk_maxdd['flg_eps_up'] = np.sign(t_ugdg_tk_maxdd['frcst_eps'] - t_ugdg_tk_maxdd['frcst_eps_prev'])
    
    t_ugdg_tk_maxdd['flg_np_up'] = t_ugdg_tk_maxdd['flg_np_up'].fillna(0)
    t_ugdg_tk_maxdd['flg_eps_up'] = t_ugdg_tk_maxdd['flg_eps_up'].fillna(0)    
    t_ugdg_tk_maxdd['sgn_flg_e_up'] = np.sign(t_ugdg_tk_maxdd[['flg_np_up','flg_eps_up']].sum(axis=1))   
    
    
    # get summary stats per organ_id
    
    t_ugdg_tk_maxdd = t_ugdg_tk_maxdd.groupby(['Ticker', 'organ_id'])[['sgn_flg_e_up']].apply(lambda x: np.sign(x.mean())).reset_index()
    
            
    # summarize rating upgrade per ticker

    s_up_ratio = t_ugdg_tk_maxdd.groupby('Ticker')['sgn_flg_e_up'].apply(lambda x: x.sum()/x.count())
    s_up_ratio = s_up_ratio.reset_index()        
    s_up_ratio = s_up_ratio.rename(columns={'sgn_flg_e_up':'np_pct_up_t1q'})
    s_up_ratio['T-1d'] = t_last_tdate
    s_up_ratio['DataDate'] = t_today
    
    # output 
    s_ugdg_t1q.append(s_up_ratio)
    
s_ugdg_t1q = pd.concat(s_ugdg_t1q, axis = 0)
s_ugdg_t1q = s_ugdg_t1q[['Ticker', 'T-1d', 'DataDate', 'np_pct_up_t1q']]



# =============================================================================
### output
# =============================================================================



s_ugdg = pd.merge(s_ugdg_t1q, s_ugdg_preved, on = ['Ticker', 'T-1d', 'DataDate'], how = 'outer')
s_ugdg = s_ugdg[['Ticker', 'T-1d', 'DataDate', 'np_pct_up_t1q', 'np_pct_up_since_preved']]


s_ugdg.to_sql('SUNTIME_ugdg', con = engine, index = False, if_exists = 'append')

