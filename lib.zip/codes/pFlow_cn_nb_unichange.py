﻿#$%^&* pFlow_cn_nb_unichange.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  5 16:42:11 2023

@author: thzhang
"""



import pandas as pd
import numpy as np

import datetime
import util as yu
import os


# this studies sell-only tickers with heavy hk holding
# sellonly: small sample, small pnl size, not worth it




#---- sd 

i_sd = yu.get_sd_cn_1800gf()



#---- cal 

i_cal = yu.get_cn_cal()
i_cal = i_cal[['TradeDate_next']].sort_values('TradeDate_next').drop_duplicates()
i_cal = i_cal.rename(columns = {'TradeDate_next': 'DataDate'})
i_cal['T-1d'] = i_cal['DataDate'].shift()
i_cal = i_cal.dropna()


#---- hk uni 
# entry info received on the same day, but after market open
i_hk_sell_uni = yu.get_sql_wind('''select substring([S_INFO_WINDCODE],1,6) as Ticker, 
                                [ENTRY_DT], [REMOVE_DT]
                                from [WIND_PROD].[dbo].[SZSCSELLMEMBERS]
                                ''')
i_hk_sell_uni['REMOVE_DT'] = i_hk_sell_uni['REMOVE_DT'].fillna('20401231')
i_hk_sell_uni['REMOVE_DT'] = pd.to_datetime(i_hk_sell_uni['REMOVE_DT'], format='%Y%m%d')
i_hk_sell_uni['ENTRY_DT'] = i_hk_sell_uni['ENTRY_DT'].fillna('20401231')
i_hk_sell_uni['ENTRY_DT'] = pd.to_datetime(i_hk_sell_uni['ENTRY_DT'], format='%Y%m%d')

o_hk_sell_uni = []
for dd in pd.date_range(start = '2018-01-07', end = '2023-03-31'):
    print('.', end='')
    c1 = i_hk_sell_uni['ENTRY_DT'].lt(dd) & i_hk_sell_uni['REMOVE_DT'].ge(dd-pd.to_timedelta('1 day'))
    t_hk_sell_uni = i_hk_sell_uni[c1]
    t_hk_sell_uni = t_hk_sell_uni[['Ticker']]
    t_hk_sell_uni['DataDate'] = dd
    t_hk_sell_uni['flg_hk_sellonly'] = 1
    o_hk_sell_uni.append(t_hk_sell_uni)
o_hk_sell_uni = pd.concat(o_hk_sell_uni, axis = 0)


#---- adj
# i_adj = yu.get_sql_wind('''
#                    select substring(s_info_windcode,1,6) as Ticker, trade_dt as [T-1d],
#                    s_dq_adjfactor as adj 
#                    from wind_prod.dbo.ashareeodprices
#                    ''')


#---- return and v

i_ret = yu.get_sql_wind('''select substring(s_info_windcode,1,6) as Ticker,
                   trade_dt as [T-1d], s_dq_close as c, 
                   s_dq_adjclose / s_dq_adjpreclose - 1 as rawret,
                   s_dq_volume*100 as v
                   from wind_prod.dbo.ashareeodprices
                   where trade_dt > '20180101'                   
                   ''')
i_ret['T-1d'] = pd.to_datetime(i_ret['T-1d'], format = '%Y%m%d')


#---- futur
e return

i_futret = pd.read_parquet('/dat/summit_capital/TZ/tmp/util_prepare_fut_1800.parquet')
i_futret = i_futret[['Ticker', 'DataDate']]




#---- hk
# 'Ticker', 'hk_b_shares', 'hk_c_shares', 'hk_bb_shares', 'craw', 'float', 'flg_cndb_hk', 'DataDate'
root_hk = '/dat/summit_capital/TZ/tmp/temp_hk_v2/'
files_hk = os.listdir(root_hk)
i_nb = pd.concat([pd.read_parquet(root_hk + f) for f in files_hk], axis = 0)
i_nb = i_nb.sort_values(['Ticker', 'DataDate']).reset_index(drop = True)
i_nb['hk_bb_diff'] = i_nb['hk_bb_shares'] - i_nb.groupby('Ticker')['hk_bb_shares'].shift()
i_nb['hk_bb_diff_dv_so'] = i_nb['hk_bb_diff'] / i_nb['float']
i_nb['hk_bb_dv_so'] = i_nb['hk_bb_shares'] / i_nb['float']

# nb metrics - batch 1

i_nb_s2 = i_nb.merge(i_cal, on = 'DataDate', how = 'left')
i_nb_s2 = i_nb_s2.merge(i_ret[['Ticker', 'T-1d', 'rawret','v']], on = ['T-1d', 'Ticker'], how = 'left')
i_nb_s2 = i_nb_s2.sort_values(['Ticker', 'DataDate']).reset_index(drop = True)

t_corr = i_nb_s2.groupby('Ticker')[['rawret', 'hk_bb_diff_dv_so']].rolling(20,min_periods=15).corr()
i_nb_s2['corr_t1m'] = t_corr['rawret'].values.tolist()[1::2]
i_nb_s2['corr_t1m'] = i_nb_s2['corr_t1m'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
i_nb_s2.loc[i_nb_s2['corr_t1m']==0, 'corr_t1m'] = np.nan

i_nb_s2['hk_bb_dv_v'] = i_nb_s2['hk_bb_shares'] / i_nb_s2['v']




#---- test: sell-only tickers with heavy hk holding 

icom = i_sd.merge(o_hk_sell_uni, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom.merge(i_nb, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom.sort_values(['Ticker', 'DataDate'])

icom['hk_shares'] = icom['hk_b_shares'].fillna(0) + icom['hk_c_shares'].fillna(0)
icom['hk_shares_dv_v'] = icom['hk_shares'] / icom['avgVadj']
icom['hk_shares_dv_v_rk'] = icom.groupby('DataDate')['hk_shares_dv_v'].apply(yu.uniformed_rank)

icom['sgnl_sellonly'] = np.nan
c1 = icom['hk_shares_dv_v_rk'].gt(0) & icom['flg_hk_sellonly'].eq(1)
icom.loc[c1, 'sgnl_sellonly'] = -1
c1 = icom['hk_shares_dv_v_rk'].lt(-0.8) & icom['flg_hk_sellonly'].eq(1)
icom.loc[c1, 'sgnl_sellonly'] = 0
icom['sgnl_sellonly'] = icom.groupby('Ticker')['sgnl_sellonly'].ffill(limit=20)

o_1 = yu.bt_cn_15_linux(icom[(icom['DataDate'].between('2018-01-01','2021-12-30'))].\
            dropna(subset=['sgnl_sellonly','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sgnl_sellonly','BarrRet_CLIP_USD+1d', static_data = i_sd)
    
t1 = o_1.groupby('Ticker')['pnl_ac'].sum().sort_values()

t2 =icom[icom['
Ticker']=='002124']

