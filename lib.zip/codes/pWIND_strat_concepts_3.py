﻿#$%^&* pWIND_strat_concepts_3.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  4 06:39:19 2022

@author: thzhang
"""




import pandas as pd
import numpy as np
import datetime as dd
import time

import yz.util as yu
import pWIND_util as pw

import os
import gzip
from bs4 import BeautifulSoup as bs

from io import StringIO

### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['ticker','datadate'])
i_sd['bret_t5d'] = i_sd.groupby('ticker').rolling(dd.timedelta(days=7), on = 'datadate', min_periods = 4)['BarrRet_SRISK_USD-1d'].sum().values
i_sd['bret_t20d'] = i_sd.groupby('ticker').rolling(dd.timedelta(days=28), on = 'datadate', min_periods = 10)['BarrRet_SRISK_USD-1d'].sum().values
i_sd['bret_t60d'] = i_sd.groupby('ticker').rolling(dd.timedelta(days=84), on = 'datadate', min_periods = 30)['BarrRet_SRISK_USD-1d'].sum().values
i_sd = i_sd.sort_values('datadate')

i_sd_dd = i_sd['datadate'].drop_duplicates()


### get wind concept raw data

i_w = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_strat_concepts_backup_raw_20211122.parquet')

# cleanse 
i_w = i_w[i_w['s_info_windcode'].notnull()]
i_w = i_w[i_w['wind_sec_code'].notnull()]
i_w = i_w[~i_w['wind_sec_name'].str.contains('lugangtong|lugutong|zhangting|dieting')]
i_w['modified_time_cn'] = pd.to_datetime(i_w['modified_time_est']).dt.tz_localize('US/Eastern').dt.tz_convert('Asia/Shanghai').dt.tz_localize(None)
i_w['mopdate'] = pd.to_datetime(i_w['mopdate'].str.split('+').str[0])
i_w['opdate'] = pd.to_datetime(i_w['opdate'].str.split('+').str[0])
i_w['plan_date'] = pd.to_datetime(i_w['plan_date'])
i_w.loc[i_w['entry_dt'].notnull(), 'entry_dt'] = pd.to_datetime(i_w.loc[i_w['entry_dt'].notnull(), 'entry_dt'], format = '%Y%m%d', errors = 'coerce')
i_w['entry_dt'] = i_w['entry_dt'].fillna(pd.NaT)
i_w['entry_dt'] = pd.to_datetime(i_w['entry_dt'])
i_w.loc[i_w['remove_dt'].notnull(), 'remove_dt'] = pd.to_datetime(i_w.loc[i_w['remove_dt'].notnull(), 'remove_dt'], format = '%Y%m%d', errors = 'coerce')
i_w['remove_dt'] = i_w['remove_dt'].fillna(pd.NaT)
i_w['remove_dt'] = pd.to_datetime(i_w['remove_dt'])


### calculate concpet_set per ticker per date
# ['ticker', 'datadate', 'wind_sec_code']

o_concept_tk_map = []
for dt in pd.date_range(start = '2018-01-01', end = '2019-12-31'):   
    print (dt.strftime('%Y%m%d'), end = ' ')
    d_str = dt.strftime('%Y-%m-%d')
    d_str = d_str + ' 23:59:59'
    t_data = i_w[i_w['modified_time_cn']<=d_str]
    c_within_range = (t_data['entry_d
t']<=dt)&(t_data['remove_dt']>=dt)
    c_after_entry = (t_data['entry_dt']<=dt)&(t_data['remove_dt'].isnull())
    c_unknown_start = (t_data['entry_dt'].isnull())&(t_data['remove_dt']>=dt)
    c_unkown = (t_data['entry_dt'].isnull())&(t_data['remove_dt'].isnull())
    c_curr_sign = t_data['cur_sign']=='1'
    t_concept = t_data[c_within_range | c_after_entry | c_unknown_start | c_unkown | c_curr_sign]
    t_concept = t_concept.groupby('s_info_windcode')['wind_sec_code'].apply(lambda x: set(x.tolist())).reset_index()
    t_concept['datadate'] = dt
    t_concept = t_concept.rename(columns={'s_info_windcode':'ticker'})
    o_concept_tk_map.append(t_concept)
o_concept_tk_map = pd.concat(o_concept_tk_map, axis = 0)


### Loop: shared wind concept


o_shared_cpt_bret = []

for dt in pd.date_range(start = '2018-01-01', end = '2019-12-31', freq='W'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    # select data
    
    t_sd = i_sd[i_sd['datadate']==i_sd_dd[i_sd_dd<=dt].max()][['ticker','bret_t20d']]    
    t_cpt = o_concept_tk_map[(o_concept_tk_map['datadate']==dt)]
    t_cpt = t_cpt[t_cpt['ticker'].isin(t_sd['ticker'].tolist())]
    t_tk_cptSet = t_cpt[['ticker','wind_sec_code']].set_index('ticker')
    
    # concept set for each ticker
    
    t_tkPair_cptSet = pd.DataFrame((t_tk_cptSet['wind_sec_code'].values[:, None] & t_tk_cptSet['wind_sec_code'].values))
    
    t_tkPair_cptCnt = t_tkPair_cptSet.applymap(lambda x: np.log(len(x)+2) )
    t_tkPair_cptCnt.columns = t_tk_cptSet.index.values
    t_tkPair_cptCnt.index = t_tk_cptSet.index.values
    t_tkPair_cptCnt.values[[np.arange(t_tkPair_cptCnt.shape[0])]*2] = 0
    
    # 
    t_bret = pd.DataFrame({'ticker':t_tk_cptSet.index.values})
    t_bret = t_bret.merge(t_sd, on = 'ticker', how = 'left')
    t_bret = t_bret.set_index('ticker')
    
    
    t_tkPair_cptCnt_wt_ret = t_tkPair_cptCnt.\
                            multiply(t_bret.values, axis = 0).\
                            sum(axis = 0).\
                            divide(t_tkPair_cptCnt.sum(axis = 1).values)
                            
    t_tkPair_cptCnt_wt_ret = t_tkPair_cptCnt_wt_ret.reset_index()
    t_tkPair_cptCnt_wt_ret = t_tkPair_cptCnt_wt_ret.rename(columns={0:'sharedCptWt_bret'})
    t_tkPair_cptCnt_wt_ret['datadate'] = dt
    
    o_shared_cpt_bret.append(t_tkPair_cptCnt_wt_ret)

o_shared_cpt_bret = pd.concat(o_shared_cpt_bret, axis = 0)
o_shared_cpt_bret = o_shared_cpt_bret.rename(columns={'index':'ticker'})
o_shared_cpt_bret = 
o_shared_cpt_bret.sort_values('datadate')



### combine

icom = pd.merge_asof(i_sd, o_shared_cpt_bret, by='ticker', on='datadate', tolerance=pd.to_timedelta('7 days'))
icom = icom.sort_values(['ticker','datadate'])


icom['sharedCptWt_bret_bk'] = icom.groupby('datadate')['sharedCptWt_bret'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['sharedCptWt_bret_rk'] = icom.groupby('datadate')['sharedCptWt_bret'].apply(yu.uniformed_rank).values

icom['bret_t20d_rk'] = icom.groupby('datadate')['bret_t20d'].apply(yu.uniformed_rank).values
icom['bret_t20d_bk'] = icom.groupby('datadate')['bret_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['sharedCptWt_bret_rkdf'] = icom['sharedCptWt_bret_rk']- icom['bret_t20d_rk']
icom['sharedCptWt_bret_rkdf_bk'] = icom.groupby('datadate')['sharedCptWt_bret_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['sharedCptWt_bret_rkdf_rk'] = icom.groupby('datadate')['sharedCptWt_bret_rkdf'].apply(yu.uniformed_rank).values




#!
icom['sharedCptWt_bret_rkdf_sgnl2'] = np.nan
icom.loc[(icom['sharedCptWt_bret_rk']>0.5)&(icom['bret_t20d_rk']<-0.8), 'sharedCptWt_bret_rkdf_sgnl2'] = 1
icom.loc[icom['sharedCptWt_bret_rkdf_rk']<-0.8, 'sharedCptWt_bret_rkdf_sgnl2'] = -1
icom['sharedCptWt_bret_rkdf_sgnl2'] = icom.groupby('ticker')['sharedCptWt_bret_rkdf_sgnl2'].ffill(limit = 20)

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2020-01-01'))&(icom['sharedCptWt_bret_rkdf_sgnl2']>0)].\
            dropna(subset=['sharedCptWt_bret_rkdf_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sharedCptWt_bret_rkdf_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.95 / 1.02
