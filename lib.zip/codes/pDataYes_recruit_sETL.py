﻿#$%^&* pDataYes_recruit_sETL.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Sep  2 12:20:08 2021

@author: thzhang
"""


import os
import zipfile
import csv

import pandas as pd 
import numpy as np


### load the txt data (with ticker only)


path_file = []
for d, p, fs in os.walk('/dat/mdwarehouse/public/502897/DATA-9097/trial_20210811/Recruitment_Content_History'):
    if len(fs)>0:
        for f in fs:
            if f.endswith('.zip'):
                path_file.append([d, f])
                

                
for pf in path_file:    
    print(pf[1])
    zf = zipfile.ZipFile(os.path.join(pf[0], pf[1]))
    t_data = pd.read_csv(zf.open(pf[1].replace('.zip','.csv')), dtype = {'ticker_symbol': str})
    
    t_data = t_data[t_data['ticker_symbol'].notnull()]
    
    t_data = t_data[t_data['position_responsibilities'].notnull() | t_data['position_requirements'].notnull()]
    t_data['position_responsibilities'] = t_data['position_responsibilities'].fillna('')
    t_data['position_requirements'] = t_data['position_requirements'].fillna('')
    
    c_same = t_data['position_responsibilities'] == t_data['position_requirements']
    t_data.loc[c_same, 'job_desc'] = t_data.loc[c_same, 'position_responsibilities']
    c_respon_valid = (t_data['position_responsibilities']!='') & (t_data['position_requirements']=='')
    t_data.loc[c_respon_valid, 'job_desc'] = t_data.loc[c_respon_valid, 'position_responsibilities']
    c_req_valid = (t_data['position_responsibilities']=='') & (t_data['position_requirements']!='')
    t_data.loc[c_req_valid, 'job_desc'] = t_data.loc[c_req_valid, 'position_requirements']
    c_diff = (t_data['position_responsibilities'] != t_data['position_requirements']) &\
            (t_data['position_responsibilities']!='') &\
            (t_data['position_requirements']!='')
    t_data.loc[c_diff, 'job_desc'] = t_data.loc[c_diff, 'position_responsibilities'] + t_data.loc[c_diff, 'position_requirements']
    
    t_data.loc[c_same, 'position_responsibilities'] = ''
    t_data.loc[c_same, 'position_requirements'] = ''
    t_data.loc[c_respon_valid, 'position_responsibilities'] = ''
    t_data.loc[c_req_valid, 'position_requirements'] = ''
    
    
    t_data['datadate'] = pd.to_datetime(pd.to_datetime(t_data['published_at']).dt.date)+pd.to_timedelta('1 day')
    
    c_sh = t_data['ticker_symbol'].str[0].isin(['6'])
    c_sz = t_data['ticker_symbol'].str[0].isin(['0', '3'])
    t_data.loc[c_sh, 'ticker'] = t_data.loc[c_sh, 'ticker_symb
