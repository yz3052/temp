﻿#$%^&* vz_highchart_template1.py #$%^&*
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
			<title>Basic line</title>
			<meta http-equiv="content-type" content="text/html; charset=UTF-8">
				<meta name="robots" content="noindex, nofollow">
					<meta name="googlebot" content="noindex, nofollow">
						<meta name="viewport" content="width=device-width, initial-scale=1">
							<script type="text/javascript" src="/js/lib/dummy.js"></script>
							<script id="insert"></script>
						</head>
						<body>
							<script src="https://code.highcharts.com/highcharts.js"></script>
							<script src="https://code.highcharts.com/modules/series-label.js"></script>
							<script src="https://code.highcharts.com/modules/exporting.js"></script>
							<script src="https://code.highcharts.com/modules/export-data.js"></script>
							<script src="https://code.highcharts.com/modules/accessibility.js"></script>
							<figure class="highcharts-figure">
								<div id="container" data-highcharts-chart="0" role="region" aria-label="Solar Employment Growth by Sector, 2010-2016. Highcharts interactive chart." aria-hidden="false" style="overflow: hidden;">
									<div id="highcharts-screen-reader-region-before-0" aria-label="Chart screen reader information." role="region" aria-hidden="false" style="position: relative;">
										<div aria-hidden="false" style="position: absolute; width: 1px; height: 1px; overflow: hidden; white-space: nowrap; clip: rect(1px, 1px, 1px, 1px); margin-top: -3px; opacity: 0.01;">
											<h5>Solar Employment Growth by Sector, 2010-2016</h5>
											<div>Line chart with 5 lines.</div>
											<div>Source: thesolarfoundation.com</div>
											<div>
        Basic line chart showing trends in a dataset. This chart includes the
        series-label module, which adds a label to each line for
        enhanced readability.
    </div>
											<div>
												<a id="hc-linkto-highcharts-data-table-0" role="button" tabindex="-1" aria-expanded="false" href="#highcharts-data-table-0">View as data table, Solar Employment Growth by Sector, 2010-2016</a>
											</div>
											<div>The chart has 1 X axis displaying values. Range: 2010 to 2017</div>
											<div>The chart has 1 Y axis displaying Number of Employees. Range: 0 to 200000.</div>
										</div>
									</div>
									<div aria-hidden="false" aria-live="assertive" style="position: absolute; width: 1px; height: 1px; overflow: hidden;
 white-space: nowrap; clip: rect(1px, 1px, 1px, 1px); margin-top: -3px; opacity: 0.01;"></div>
									<div aria-hidden="false" aria-live="polite" style="position: absolute; width: 1px; height: 1px; overflow: hidden; white-space: nowrap; clip: rect(1px, 1px, 1px, 1px); margin-top: -3px; opacity: 0.01;"></div>
									<div id="highcharts-bnhlkyh-0" dir="ltr" class="highcharts-container " style="position: relative; overflow: hidden; width: 360px; height: 400px; text-align: left; line-height: normal; z-index: 0; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);" tabindex="0" aria-hidden="false">
										<svg version="1.1" class="highcharts-root" style="font-family:&quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif;font-size:12px;"
											xmlns="http://www.w3.org/2000/svg" width="360" height="400" viewBox="0 0 360 400" aria-label="Interactive chart" aria-hidden="false">
											<desc aria-hidden="true">Created with Highcharts 8.1.0</desc>
											<defs aria-hidden="true">
												<clipPath id="highcharts-bnhlkyh-1-">
													<rect x="0" y="0" width="269" height="158" fill="none"></rect>
												</clipPath>
											</defs>
											<rect fill="#ffffff" class="highcharts-background" x="0" y="0" width="360" height="400" rx="0" ry="0" aria-hidden="true"></rect>
											<rect fill="none" class="highcharts-plot-background" x="81" y="92" width="269" height="158" aria-hidden="true"></rect>
											<g class="highcharts-grid highcharts-xaxis-grid" data-z-index="1" aria-hidden="true">
												<path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 83.5 92 L 83.5 250" opacity="1"></path>
												<path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 271.5 92 L 271.5 250" opacity="1"></path>
											</g>
											<g class="highcharts-grid highcharts-yaxis-grid" data-z-index="1" aria-hidden="true">
												<path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 81 250.5 L 350 250.5" opacity="1"></path>
												<path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 81 211.5 L 350 211.5" opacity="1"></path>
												<path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 81 171.5 L 350 171.5" opacity="1"></path>
												<path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-
line" d="M 81 132.5 L 350 132.5" opacity="1"></path>
												<path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 81 91.5 L 350 91.5" opacity="1"></path>
											</g>
											<rect fill="none" class="highcharts-plot-border" data-z-index="1" x="81" y="92" width="269" height="158" aria-hidden="true"></rect>
											<g class="highcharts-axis highcharts-xaxis" data-z-index="2" aria-hidden="true">
												<path fill="none" class="highcharts-tick" stroke="#ccd6eb" stroke-width="1" d="M 83.5 250 L 83.5 260" opacity="1"></path>
												<path fill="none" class="highcharts-tick" stroke="#ccd6eb" stroke-width="1" d="M 271.5 250 L 271.5 260" opacity="1"></path>
												<path fill="none" class="highcharts-axis-line" stroke="#ccd6eb" stroke-width="1" data-z-index="7" d="M 81 250.5 L 350 250.5"></path>
											</g>
											<g class="highcharts-axis highcharts-yaxis" data-z-index="2" aria-hidden="true">
												<text x="26.140625" data-z-index="7" text-anchor="middle" transform="translate(0,0) rotate(270 26.140625 171)" class="highcharts-axis-title" style="color:#666666;fill:#666666;" y="171">
													<tspan>Number of Employees</tspan>
												</text>
												<path fill="none" class="highcharts-axis-line" data-z-index="7" d="M 81 92 L 81 250"></path>
											</g>
											<g class="highcharts-series-group" data-z-index="3" aria-hidden="false">
												<g data-z-index="0.1" class="highcharts-series highcharts-series-0 highcharts-line-series highcharts-color-0" transform="translate(81,92) scale(1 1)" clip-path="url(#highcharts-bnhlkyh-1-)" aria-hidden="true" opacity="1">
													<path fill="none" d="M 2.6372549019584 123.29213999999999 L 40.31232492997 116.52262999999999 L 77.987394957982 112.83017000000001 L 115.66246498599 102.97018 L 153.33753501401 81.34551 L 191.01260504202 63.254509999999996 L 228.68767507003 49.66493 L 266.36274509804 36.201750000000004" class="highcharts-graph" data-z-index="1" stroke="#7cb5ec" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></path>
													<path fill="none" d="M 2.6372549019584 123.29213999999999 L 40.31232492997 116.52262999999999 L 77.987394957982 112.83017000000001 L 115.66246498599 102.97018 L 153.33753501401 81.34551 L 191.01260504202 63.254509999999996 L 228.68767507003 49.66493 L 266.36274509804 36.201750000000004" visibility="visible" data-z-index="2" class="highcharts-tracker-line" stroke-lin
ecap="round" stroke-linejoin="round" stroke="rgba(192,192,192,0.0001)" stroke-width="22"></path>
												</g>
												<g data-z-index="0.1" class="highcharts-markers highcharts-series-0 highcharts-line-series highcharts-color-0 highcharts-tracker" transform="translate(81,92) scale(1 1)" aria-hidden="false" role="region" tabindex="-1" aria-label="Installation, line 1 of 5 with 8 data points." style="outline: 0px;" opacity="1">
													<path fill="#7cb5ec" d="M 80 215.34562 A 0 0 0 1 1 80 215.34562 Z" class="highcharts-halo highcharts-color-0" data-z-index="-1" fill-opacity="0.25" visibility="hidden"></path>
													<path fill="#7cb5ec" d="M 2.0000000000000004 127.29213999999999 A 4 4 0 1 1 2.003999999333336 127.29213800000015 Z" opacity="1" class="highcharts-point highcharts-color-0" tabindex="-1" role="img" aria-label="1. x, 2010, 43,934. Installation." style="outline: 0px;"></path>
													<path fill="#7cb5ec" d="M 40 120.52262999999999 A 4 4 0 1 1 40.00399999933334 120.52262800000015 Z" opacity="1" class="highcharts-point highcharts-color-0" tabindex="-1" role="img" aria-label="2. x, 2011, 52,503. Installation." style="outline: 0px;" stroke-width="0.00006393081937805523"></path>
													<path fill="#7cb5ec" d="M 77 116.83017000000001 A 4 4 0 1 1 77.00399999933333 116.83016800000017 Z" opacity="1" class="highcharts-point highcharts-color-0" tabindex="-1" role="img" aria-label="3. x, 2012, 57,177. Installation." style="outline: 0px;" stroke-width="0.0000019063997278492145"></path>
													<path fill="#7cb5ec" d="M 115 106.97018 A 4 4 0 1 1 115.00399999933333 106.97017800000016 Z" opacity="1" class="highcharts-point highcharts-color-0" tabindex="-1" role="img" aria-label="4. x, 2013, 69,658. Installation." style="outline: 0px;" stroke-width="3.5051585981524074e-7"></path>
													<path fill="#7cb5ec" d="M 153 85.34551 A 4 4 0 1 1 153.00399999933333 85.34550800000017 Z" opacity="1" class="highcharts-point highcharts-color-0" tabindex="-1" role="img" aria-label="5. x, 2014, 97,031. Installation." style="outline: 0px;" stroke-width="0.00013016127849851955"></path>
													<path fill="#7cb5ec" d="M 191 67.25451 A 4 4 0 1 1 191.00399999933333 67.25450800000016 Z" opacity="1" class="highcharts-point highcharts-color-0" tabindex="-1" role="img" aria-label="6. x, 2015, 119,931. Installation." style="outline: 0px;" stroke-width="0.00013016127849851955"></path>
													<path fill="#7cb5ec" d="M 228 53.66493 A 4 4 0 1 1 
228.00399999933333 53.66492800000017 Z" opacity="1" class="highcharts-point highcharts-color-0" tabindex="-1" role="img" aria-label="7. x, 2016, 137,133. Installation." style="outline: 0px;" stroke-width="0.0007992249455124334"></path>
													<path fill="#7cb5ec" d="M 266 40.201750000000004 A 4 4 0 1 1 266.00399999933336 40.20174800000017 Z" opacity="1" class="highcharts-point highcharts-color-0" tabindex="-1" role="img" aria-label="8. x, 2017, 154,175. Installation." style="outline: 0px;" stroke-width="3.465380119041517e-7"></path>
												</g>
												<g data-z-index="0.1" class="highcharts-series highcharts-series-1 highcharts-line-series highcharts-color-1" transform="translate(81,92) scale(1 1)" clip-path="url(#highcharts-bnhlkyh-1-)" aria-hidden="true" opacity="1">
													<path fill="none" d="M 2.6372549019584 138.31636 L 40.31232492997 138.98944 L 77.987394957982 134.50382 L 115.66246498599 134.41771 L 153.33753501401 132.3329 L 191.01260504202 134.07722 L 228.68767507003 127.88441 L 266.36274509804 126.05714" class="highcharts-graph" data-z-index="1" stroke="#434348" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></path>
													<path fill="none" d="M 2.6372549019584 138.31636 L 40.31232492997 138.98944 L 77.987394957982 134.50382 L 115.66246498599 134.41771 L 153.33753501401 132.3329 L 191.01260504202 134.07722 L 228.68767507003 127.88441 L 266.36274509804 126.05714" visibility="visible" data-z-index="2" class="highcharts-tracker-line" stroke-linecap="round" stroke-linejoin="round" stroke="rgba(192,192,192,0.0001)" stroke-width="22"></path>
												</g>
												<g data-z-index="0.1" class="highcharts-markers highcharts-series-1 highcharts-line-series highcharts-color-1 highcharts-tracker" transform="translate(81,92) scale(1 1)" aria-hidden="false" role="region" tabindex="-1" aria-label="Manufacturing, line 2 of 5 with 8 data points." style="outline: 0px;" opacity="1">
													<path fill="#434348" d="M 528 232.96636 A 0 0 0 1 1 528 232.96636 Z" class="highcharts-halo highcharts-color-1" data-z-index="-1" fill-opacity="0.25" visibility="hidden"></path>
													<path fill="#434348" d="M 2 134.31636 L 6 138.31636 L 2 142.31636 L -2 138.31636 Z" opacity="1" class="highcharts-point highcharts-color-1" tabindex="-1" role="img" aria-label="1. x, 2010, 24,916. Manufacturing." style="outline: 0px;"></path>
													<path fill="#434348" d="M 40 134.98944 L 44 138.98944 L 40 142.98944 L 36 138.98
944 Z" opacity="1" class="highcharts-point highcharts-color-1" tabindex="-1" role="img" aria-label="2. x, 2011, 24,064. Manufacturing." style="outline: 0px;"></path>
													<path fill="#434348" d="M 77 130.50382 L 81 134.50382 L 77 138.50382 L 73 134.50382 Z" opacity="1" class="highcharts-point highcharts-color-1" tabindex="-1" role="img" aria-label="3. x, 2012, 29,742. Manufacturing." style="outline: 0px;"></path>
													<path fill="#434348" d="M 115 130.41771 L 119 134.41771 L 115 138.41771 L 111 134.41771 Z" opacity="1" class="highcharts-point highcharts-color-1" tabindex="-1" role="img" aria-label="4. x, 2013, 29,851. Manufacturing." style="outline: 0px;"></path>
													<path fill="#434348" d="M 153 128.3329 L 157 132.3329 L 153 136.3329 L 149 132.3329 Z" opacity="1" class="highcharts-point highcharts-color-1" tabindex="-1" role="img" aria-label="5. x, 2014, 32,490. Manufacturing." style="outline: 0px;"></path>
													<path fill="#434348" d="M 191 130.07722 L 195 134.07722 L 191 138.07722 L 187 134.07722 Z" opacity="1" class="highcharts-point highcharts-color-1" tabindex="-1" role="img" aria-label="6. x, 2015, 30,282. Manufacturing." style="outline: 0px;" stroke-width="0.000008748808670408677"></path>
													<path fill="#434348" d="M 228 123.88441 L 232 127.88441 L 228 131.88441 L 224 127.88441 Z" opacity="1" class="highcharts-point highcharts-color-1" tabindex="-1" role="img" aria-label="7. x, 2016, 38,121. Manufacturing." style="outline: 0px;" stroke-width="0.0019331954284137476"></path>
													<path fill="#434348" d="M 266 122.05714 L 270 126.05714 L 266 130.05714 L 262 126.05714 Z" opacity="1" class="highcharts-point highcharts-color-1" tabindex="-1" role="img" aria-label="8. x, 2017, 40,434. Manufacturing." style="outline: 0px;" stroke-width="0.002219017698460002"></path>
												</g>
												<g data-z-index="0.1" class="highcharts-series highcharts-series-2 highcharts-line-series highcharts-color-2" transform="translate(81,92) scale(1 1)" clip-path="url(#highcharts-bnhlkyh-1-)" aria-hidden="true" opacity="1">
													<path fill="none" d="M 2.6372549019584 148.72224 L 40.31232492997 143.99962 L 77.987394957982 145.35605 L 115.66246498599 142.38091 L 153.33753501401 142.05385 L 191.01260504202 138.74217 L 228.68767507003 132.60387 L 266.36274509804 126.88427" class="highcharts-graph" data-z-index="1" stroke="#90ed7d" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"></path>
												
	<path fill="none" d="M 2.6372549019584 148.72224 L 40.31232492997 143.99962 L 77.987394957982 145.35605 L 115.66246498599 142.38091 L 153.33753501401 142.05385 L 191.01260504202 138.74217 L 228.68767507003 132.60387 L 266.36274509804 126.88427" visibility="visible" data-z-index="2" class="highcharts-tracker-line" stroke-linecap="round" stroke-linejoin="round" stroke="rgba(192,192,192,0.0001)" stroke-width="22"></path>
												</g>
												<g data-z-index="0.1" class="highcharts-markers highcharts-series-2 highcharts-line-series highcharts-color-2 highcharts-tracker" transform="translate(81,92) scale(1 1)" aria-hidden="false" role="region" tabindex="-1" aria-label="Sales &amp;amp; Distribution, line 3 of 5 with 8 data points." style="outline: 0px;" opacity="1">
													<path fill="#90ed7d" d="M 379 256.40958 A 0 0 0 1 1 379 256.40958 Z" class="highcharts-halo highcharts-color-2" data-z-index="-1" fill-opacity="0.25" visibility="hidden"></path>
													<path fill="#90ed7d" d="M -2 144.72224 L 6 144.72224 L 6 152.72224 L -2 152.72224 Z" opacity="1" class="highcharts-point highcharts-color-2" tabindex="-1" role="img" aria-label="1. x, 2010, 11,744. Sales &amp;amp; Distribution." style="outline: 0px;"></path>
													<path fill="#90ed7d" d="M 36 139.99962 L 44 139.99962 L 44 147.99962 L 36 147.99962 Z" opacity="1" class="highcharts-point highcharts-color-2" tabindex="-1" role="img" aria-label="2. x, 2011, 17,722. Sales &amp;amp; Distribution." style="outline: 0px;"></path>
													<path fill="#90ed7d" d="M 73 141.35605 L 81 141.35605 L 81 149.35605 L 73 149.35605 Z" opacity="1" class="highcharts-point highcharts-color-2" tabindex="-1" role="img" aria-label="3. x, 2012, 16,005. Sales &amp;amp; Distribution." style="outline: 0px;"></path>
													<path fill="#90ed7d" d="M 111 138.38091 L 119 138.38091 L 119 146.38091 L 111 146.38091 Z" opacity="1" class="highcharts-point highcharts-color-2" tabindex="-1" role="img" aria-label="4. x, 2013, 19,771. Sales &amp;amp; Distribution." style="outline: 0px;"></path>
													<path fill="#90ed7d" d="M 149 138.05385 L 157 138.05385 L 157 146.05385 L 149 146.05385 Z" opacity="1" class="highcharts-point highcharts-color-2" tabindex="-1" role="img" aria-label="5. x, 2014, 20,185. Sales &amp;amp; Distribution." style="outline: 0px;"></path>
													<path fill="#90ed7d" d="M 187 134.74217 L 195 134.74217 L 195 142.74217 L 187 142.74217 Z" opacity="1" class="highcharts-point highcharts-co
lor-2" tabindex="-1" role="img" aria-label="6. x, 2015, 24,377. Sales &amp;amp; Distribution." style="outline: 0px;" stroke-width="0.0005859006574716052"></path>
													<path fill="#90ed7d" d="M 224 128.60387 L 232 128.60387 L 232 136.60387 L 224 136.60387 Z" opacity="1" class="highcharts-point highcharts-color-2" tabindex="-1" role="img" aria-label="7. x, 2016, 32,147. Sales &amp;amp; Distribution." style="outline: 0px;" stroke-width="0.00002235784257133451"></path>
													<path fill="#90ed7d" d="M 262 122.88427 L 270 122.88427 L 270 130.88427000000001 L 262 130.88427000000001 Z" opacity="1" class="highcharts-point highcharts-color-2" tabindex="-1" role="img" aria-label="8. x, 2017, 39,387. Sales &amp;amp; Distribution." style="outline: 0px;"></path>
												</g>
												<g data-z-index="0.1" class="highcharts-series highcharts-series-3 highcharts-line-series highcharts-color-3" transform="translate(81,92) scale(1 1)" clip-path="url(#highcharts-bnhlkyh-1-)" aria-hidden="false" opacity="1">
													<path fill="none" d="M 77.987394957982 151.68948 L 115.66246498599 148.38649 L 153.33753501401 146.06152 L 191.01260504202 140.26292 L 228.68767507003 130.824 L 266.36274509804 130.96067" class="highcharts-graph" data-z-index="1" stroke="#f7a35c" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" aria-hidden="false" role="region" tabindex="-1" aria-label="Project Development, line 4 of 5 with 8 data points." style="outline: 0px;"></path>
													<path fill="none" d="M 77.987394957982 151.68948 L 115.66246498599 148.38649 L 153.33753501401 146.06152 L 191.01260504202 140.26292 L 228.68767507003 130.824 L 266.36274509804 130.96067" visibility="visible" data-z-index="2" class="highcharts-tracker-line" stroke-linecap="round" stroke-linejoin="round" stroke="rgba(192,192,192,0.0001)" stroke-width="22" aria-hidden="true"></path>
												</g>
												<g data-z-index="0.1" class="highcharts-markers highcharts-series-3 highcharts-line-series highcharts-color-3 highcharts-tracker" transform="translate(81,92) scale(1 1)" aria-hidden="true" opacity="1">
													<path fill="#f7a35c" d="M 379 259.22008 A 0 0 0 1 1 379 259.22008 Z" class="highcharts-halo highcharts-color-3" data-z-index="-1" fill-opacity="0.25" visibility="hidden"></path>
													<rect x="2.6372549019584" y="151.68948" width="1" height="1" fill="none" class="highcharts-a11y-dummy-point" opacity="0" fill-opacity="0" stroke-opacity="0" tabindex="-1" rol
e="img" aria-label="1. x, 2010, No value. Project Development." style="outline: 0px;"></rect>
													<rect x="40.31232492997" y="151.68948" width="1" height="1" fill="none" class="highcharts-a11y-dummy-point" opacity="0" fill-opacity="0" stroke-opacity="0" tabindex="-1" role="img" aria-label="2. x, 2011, No value. Project Development." style="outline: 0px;"></rect>
													<path fill="#f7a35c" d="M 77 147.68948 L 81 155.68948 L 73 155.68948 Z" opacity="1" class="highcharts-point highcharts-color-3" tabindex="-1" role="img" aria-label="3. x, 2012, 7,988. Project Development." style="outline: 0px;"></path>
													<path fill="#f7a35c" d="M 115 144.38649 L 119 152.38649 L 111 152.38649 Z" opacity="1" class="highcharts-point highcharts-color-3" tabindex="-1" role="img" aria-label="4. x, 2013, 12,169. Project Development." style="outline: 0px;"></path>
													<path fill="#f7a35c" d="M 153 142.06152 L 157 150.06152 L 149 150.06152 Z" opacity="1" class="highcharts-point highcharts-color-3" tabindex="-1" role="img" aria-label="5. x, 2014, 15,112. Project Development." style="outline: 0px;"></path>
													<path fill="#f7a35c" d="M 191 136.26292 L 195 144.26292 L 187 144.26292 Z" opacity="1" class="highcharts-point highcharts-color-3" tabindex="-1" role="img" aria-label="6. x, 2015, 22,452. Project Development." style="outline: 0px;" stroke-width="0.00000995318479014417"></path>
													<path fill="#f7a35c" d="M 228 126.82400000000001 L 232 134.824 L 224 134.824 Z" opacity="1" class="highcharts-point highcharts-color-3" tabindex="-1" role="img" aria-label="7. x, 2016, 34,400. Project Development." style="outline: 0px;"></path>
													<path fill="#f7a35c" d="M 266 126.96067 L 270 134.96067 L 262 134.96067 Z" opacity="1" class="highcharts-point highcharts-color-3" tabindex="-1" role="img" aria-label="8. x, 2017, 34,227. Project Development." style="outline: 0px;"></path>
												</g>
												<g data-z-index="0.1" class="highcharts-series highcharts-series-4 highcharts-line-series highcharts-color-4" transform="translate(81,92) scale(1 1)" clip-path="url(#highcharts-bnhlkyh-1-)" aria-hidden="true" opacity="1">
													<path fill="none" d="M 2.6372549019584 147.80268 L 40.31232492997 153.30108 L 77.987394957982 151.59705 L 115.66246498599 149.11408 L 153.33753501401 150.89869 L 191.01260504202 148.66536 L 228.68767507003 143.56354 L 266.36274509804 143.69231" class="highcharts-graph" data-z-index="1" stroke="#8085e9" s
troke-width="2" stroke-linejoin="round" stroke-linecap="round"></path>
													<path fill="none" d="M 2.6372549019584 147.80268 L 40.31232492997 153.30108 L 77.987394957982 151.59705 L 115.66246498599 149.11408 L 153.33753501401 150.89869 L 191.01260504202 148.66536 L 228.68767507003 143.56354 L 266.36274509804 143.69231" visibility="visible" data-z-index="2" class="highcharts-tracker-line" stroke-linecap="round" stroke-linejoin="round" stroke="rgba(192,192,192,0.0001)" stroke-width="22"></path>
												</g>
												<g data-z-index="0.1" class="highcharts-markers highcharts-series-4 highcharts-line-series highcharts-color-4 highcharts-tracker" transform="translate(81,92) scale(1 1)" aria-hidden="false" role="region" tabindex="-1" aria-label="Other, line 5 of 5 with 8 data points." style="outline: 0px;" opacity="1">
													<path fill="#8085e9" d="M 379 274.74864 A 0 0 0 1 1 379 274.74864 Z" class="highcharts-halo highcharts-color-4" data-z-index="-1" fill-opacity="0.25" visibility="hidden"></path>
													<path fill="#8085e9" d="M -2 143.80268 L 6 143.80268 L 2 151.80268 Z" opacity="1" class="highcharts-point highcharts-color-4" tabindex="-1" role="img" aria-label="1. x, 2010, 12,908. Other." style="outline: 0px;"></path>
													<path fill="#8085e9" d="M 36 149.30108 L 44 149.30108 L 40 157.30108 Z" opacity="1" class="highcharts-point highcharts-color-4" tabindex="-1" role="img" aria-label="2. x, 2011, 5,948. Other." style="outline: 0px;"></path>
													<path fill="#8085e9" d="M 73 147.59705 L 81 147.59705 L 77 155.59705 Z" opacity="1" class="highcharts-point highcharts-color-4" tabindex="-1" role="img" aria-label="3. x, 2012, 8,105. Other." style="outline: 0px;"></path>
													<path fill="#8085e9" d="M 111 145.11408 L 119 145.11408 L 115 153.11408 Z" opacity="1" class="highcharts-point highcharts-color-4" tabindex="-1" role="img" aria-label="4. x, 2013, 11,248. Other." style="outline: 0px;"></path>
													<path fill="#8085e9" d="M 149 146.89869 L 157 146.89869 L 153 154.89869 Z" opacity="1" class="highcharts-point highcharts-color-4" tabindex="-1" role="img" aria-label="5. x, 2014, 8,989. Other." style="outline: 0px;"></path>
													<path fill="#8085e9" d="M 187 144.66536 L 195 144.66536 L 191 152.66536 Z" opacity="1" class="highcharts-point highcharts-color-4" tabindex="-1" role="img" aria-label="6. x, 2015, 11,816. Other." style="outline: 0px;" stroke-width="0.00003947789809188862"></path>
											
		<path fill="#8085e9" d="M 224 139.56354 L 232 139.56354 L 228 147.56354 Z" opacity="1" class="highcharts-point highcharts-color-4" tabindex="-1" role="img" aria-label="7. x, 2016, 18,274. Other." style="outline: 0px;"></path>
													<path fill="#8085e9" d="M 262 139.69231 L 270 139.69231 L 266 147.69231 Z" opacity="1" class="highcharts-point highcharts-color-4" tabindex="-1" role="img" aria-label="8. x, 2017, 18,111. Other." style="outline: 0px;"></path>
												</g>
											</g>
											<g class="highcharts-exporting-group" data-z-index="3" aria-hidden="true">
												<g class="highcharts-button highcharts-contextbutton" stroke-linecap="round" transform="translate(326,10)">
													<rect fill="#ffffff" class="highcharts-button-box" x="0.5" y="0.5" width="24" height="22" rx="2" ry="2" stroke="none" stroke-width="1"></rect>
													<title>Chart context menu</title>
													<path fill="#666666" d="M 6 6.5 L 20 6.5 M 6 11.5 L 20 11.5 M 6 16.5 L 20 16.5" class="highcharts-button-symbol" data-z-index="1" stroke="#666666" stroke-width="3"></path>
													<text x="0" data-z-index="1" style="color:#333333;cursor:pointer;font-weight:normal;fill:#333333;" y="12"></text>
												</g>
											</g>
											<g class="highcharts-label highcharts-series-label highcharts-series-label-0 highcharts-color-0" opacity="1" data-z-index="3" transform="translate(276,107)" aria-hidden="true">
												<path fill="none" class="highcharts-label-box" d="M 0 0" stroke="#7cb5ec" stroke-width="1"></path>
												<text x="0" data-z-index="1" style="color:#7cb5ec;font-weight:bold;fill:#7cb5ec;" y="12">Installation</text>
											</g>
											<g class="highcharts-label highcharts-series-label highcharts-series-label-1 highcharts-color-1" opacity="1" data-z-index="3" transform="translate(219,199)" aria-hidden="true">
												<path fill="none" class="highcharts-label-box" d="M 0 0" stroke="#434348" stroke-width="1"></path>
												<text x="0" data-z-index="1" style="color:#434348;font-weight:bold;fill:#434348;" y="12">Manufacturing</text>
											</g>
											<text x="180" text-anchor="middle" class="highcharts-title" data-z-index="4" style="color:#333333;font-size:18px;fill:#333333;" y="24" aria-hidden="true">
												<tspan>Solar Employment Growth by</tspan>
												<tspan dy="21" x="180">Sector, 2010-2016</tspan>
											</text>
											<text x="180" text-anchor="middle" class="highcharts-subtitle"
 data-z-index="4" style="color:#666666;fill:#666666;" y="73" aria-hidden="true">
												<tspan>Source: thesolarfoundation.com</tspan>
											</text>
											<text x="10" text-anchor="start" class="highcharts-caption" data-z-index="4" style="color:#666666;fill:#666666;" y="397" aria-hidden="true"></text>
											<g class="highcharts-axis-labels highcharts-xaxis-labels" data-z-index="7" aria-hidden="true">
												<text x="83.637254901958" style="color:#666666;cursor:default;font-size:11px;fill:#666666;" text-anchor="middle" transform="translate(0,0)" y="269" opacity="1">2010</text>
												<text x="272.01260504202" style="color:#666666;cursor:default;font-size:11px;fill:#666666;" text-anchor="middle" transform="translate(0,0)" y="269" opacity="1">2015</text>
											</g>
											<g class="highcharts-axis-labels highcharts-yaxis-labels" data-z-index="7" aria-hidden="true">
												<text x="66" style="color:#666666;cursor:default;font-size:11px;fill:#666666;" text-anchor="end" transform="translate(0,0)" y="254" opacity="1">0</text>
												<text x="66" style="color:#666666;cursor:default;font-size:11px;fill:#666666;" text-anchor="end" transform="translate(0,0)" y="215" opacity="1">50k</text>
												<text x="66" style="color:#666666;cursor:default;font-size:11px;fill:#666666;" text-anchor="end" transform="translate(0,0)" y="175" opacity="1">100k</text>
												<text x="66" style="color:#666666;cursor:default;font-size:11px;fill:#666666;" text-anchor="end" transform="translate(0,0)" y="136" opacity="1">150k</text>
												<text x="66" style="color:#666666;cursor:default;font-size:11px;fill:#666666;" text-anchor="end" transform="translate(0,0)" y="96" opacity="1">200k</text>
											</g>
											<g class="highcharts-legend" data-z-index="7" transform="translate(98,284)" aria-hidden="true">
												<rect fill="none" class="highcharts-legend-box" rx="0" ry="0" x="0" y="0" width="163" height="101" visibility="visible"></rect>
												<g data-z-index="1">
													<g>
														<g class="highcharts-legend-item highcharts-line-series highcharts-color-0 highcharts-series-0" data-z-index="1" transform="translate(8,3)">
															<path fill="none" d="M 0 11 L 16 11" class="highcharts-graph" stroke="#7cb5ec" stroke-width="2"></path>
															<path fill="#7cb5ec" d="M 8 15 A 4 4 0 1 1 8.003999999333336 14.999998000000167 Z" class="highcharts-point" opacity="1"></path>
															<text x
="21" style="color:#333333;cursor:pointer;font-size:12px;font-weight:bold;fill:#333333;" text-anchor="start" data-z-index="2" y="15">
																<tspan>Installation</tspan>
															</text>
														</g>
														<g class="highcharts-legend-item highcharts-line-series highcharts-color-1 highcharts-series-1" data-z-index="1" transform="translate(8,21)">
															<path fill="none" d="M 0 11 L 16 11" class="highcharts-graph" stroke="#434348" stroke-width="2"></path>
															<path fill="#434348" d="M 8 7 L 12 11 L 8 15 L 4 11 Z" class="highcharts-point" opacity="1"></path>
															<text x="21" y="15" style="color:#333333;cursor:pointer;font-size:12px;font-weight:bold;fill:#333333;" text-anchor="start" data-z-index="2">
																<tspan>Manufacturing</tspan>
															</text>
														</g>
														<g class="highcharts-legend-item highcharts-line-series highcharts-color-2 highcharts-series-2" data-z-index="1" transform="translate(8,39)">
															<path fill="none" d="M 0 11 L 16 11" class="highcharts-graph" stroke="#90ed7d" stroke-width="2"></path>
															<path fill="#90ed7d" d="M 4 7 L 12 7 L 12 15 L 4 15 Z" class="highcharts-point" opacity="1"></path>
															<text x="21" y="15" style="color:#333333;cursor:pointer;font-size:12px;font-weight:bold;fill:#333333;" text-anchor="start" data-z-index="2">
																<tspan>Sales &amp; Distribution</tspan>
															</text>
														</g>
														<g class="highcharts-legend-item highcharts-line-series highcharts-color-3 highcharts-series-3" data-z-index="1" transform="translate(8,57)">
															<path fill="none" d="M 0 11 L 16 11" class="highcharts-graph" stroke="#f7a35c" stroke-width="2"></path>
															<path fill="#f7a35c" d="M 8 7 L 12 15 L 4 15 Z" class="highcharts-point" opacity="1"></path>
															<text x="21" y="15" style="color:#333333;cursor:pointer;font-size:12px;font-weight:bold;fill:#333333;" text-anchor="start" data-z-index="2">
																<tspan>Project Development</tspan>
															</text>
														</g>
														<g class="highcharts-legend-item highcharts-line-series highcharts-color-4 highcharts-series-4" data-z-index="1" transform="translate(8,75)">
															<path fill="none" d="M 0 11 L 16 11" class="highcharts-graph" stroke="#8085e9" stroke-width="2"></path>
															<path fill="#8085e9" d="M 4 7 L 12 7 L 8 15 Z" class="highcharts-point" opacity="
1"></path>
															<text x="21" y="15" style="color:#333333;cursor:pointer;font-size:12px;font-weight:bold;fill:#333333;" text-anchor="start" data-z-index="2">
																<tspan>Other</tspan>
															</text>
														</g>
													</g>
												</g>
											</g>
											<text x="350" class="highcharts-credits" text-anchor="end" data-z-index="8" style="cursor:pointer;color:#999999;font-size:9px;fill:#999999;" y="395" aria-label="Chart credits: Highcharts.com" aria-hidden="false">Highcharts.com</text>
											<g class="highcharts-label highcharts-tooltip                       highcharts-color-0" style="white-space:nowrap;pointer-events:none;" data-z-index="8" transform="translate(89,-9999)" opacity="0" visibility="hidden" aria-hidden="true">
												<path fill="none" class="highcharts-label-box highcharts-tooltip-box highcharts-shadow" d="M 3.5 0.5 L 142.5 0.5 C 145.5 0.5 145.5 0.5 145.5 3.5 L 145.5 44.5 C 145.5 47.5 145.5 47.5 142.5 47.5 L 77.5 47.5 L 71.5 53.5 L 65.5 47.5 L 3.5 47.5 C 0.5 47.5 0.5 47.5 0.5 44.5 L 0.5 3.5 C 0.5 0.5 0.5 0.5 3.5 0.5" stroke="#000000" stroke-opacity="0.049999999999999996" stroke-width="5" transform="translate(1, 1)"></path>
												<path fill="none" class="highcharts-label-box highcharts-tooltip-box highcharts-shadow" d="M 3.5 0.5 L 142.5 0.5 C 145.5 0.5 145.5 0.5 145.5 3.5 L 145.5 44.5 C 145.5 47.5 145.5 47.5 142.5 47.5 L 77.5 47.5 L 71.5 53.5 L 65.5 47.5 L 3.5 47.5 C 0.5 47.5 0.5 47.5 0.5 44.5 L 0.5 3.5 C 0.5 0.5 0.5 0.5 3.5 0.5" stroke="#000000" stroke-opacity="0.09999999999999999" stroke-width="3" transform="translate(1, 1)"></path>
												<path fill="none" class="highcharts-label-box highcharts-tooltip-box highcharts-shadow" d="M 3.5 0.5 L 142.5 0.5 C 145.5 0.5 145.5 0.5 145.5 3.5 L 145.5 44.5 C 145.5 47.5 145.5 47.5 142.5 47.5 L 77.5 47.5 L 71.5 53.5 L 65.5 47.5 L 3.5 47.5 C 0.5 47.5 0.5 47.5 0.5 44.5 L 0.5 3.5 C 0.5 0.5 0.5 0.5 3.5 0.5" stroke="#000000" stroke-opacity="0.15" stroke-width="1" transform="translate(1, 1)"></path>
												<path fill="rgba(247,247,247,0.85)" class="highcharts-label-box highcharts-tooltip-box" d="M 3.5 0.5 L 142.5 0.5 C 145.5 0.5 145.5 0.5 145.5 3.5 L 145.5 44.5 C 145.5 47.5 145.5 47.5 142.5 47.5 L 77.5 47.5 L 71.5 53.5 L 65.5 47.5 L 3.5 47.5 C 0.5 47.5 0.5 47.5 0.5 44.5 L 0.5 3.5 C 0.5 0.5 0.5 0.5 3.5 0.5" stroke="#7cb5ec" stroke-width="1"></path>
												<text x="8" data-z-index="1" style="color:#333333;cursor:default;font-size:12
px;fill:#333333;" y="20">
													<tspan style="font-size: 10px">2011</tspan>
													<tspan style="fill:#7cb5ec" x="8" dy="15">?</tspan>
													<tspan dx="0"> Installation: </tspan>
													<tspan style="font-weight:bold" dx="0">52 503</tspan>
												</text>
											</g>
										</svg>
										<div class="highcharts-a11y-proxy-container" aria-hidden="false">
											<div aria-label="Toggle series visibility" role="region" aria-hidden="false">
												<button aria-label="Toggle visibility of Installation" tabindex="-1" aria-pressed="false" class="highcharts-a11y-proxy-button" aria-hidden="false" style="border-width: 0px; background-color: transparent; cursor: pointer; outline: none; opacity: 0.001; z-index: 999; overflow: hidden; padding: 0px; margin: 0px; display: block; position: absolute; width: 88.6719px; height: 18px; left: 106px; top: 289px; visibility: visible;"></button>
												<button aria-label="Toggle visibility of Manufacturing" tabindex="-1" aria-pressed="false" class="highcharts-a11y-proxy-button" aria-hidden="false" style="border-width: 0px; background-color: transparent; cursor: pointer; outline: none; opacity: 0.001; z-index: 999; overflow: hidden; padding: 0px; margin: 0px; display: block; position: absolute; width: 108.688px; height: 18px; left: 106px; top: 307px; visibility: visible;"></button>
												<button aria-label="Toggle visibility of Sales &amp; Distribution" tabindex="-1" aria-pressed="false" class="highcharts-a11y-proxy-button" aria-hidden="false" style="border-width: 0px; background-color: transparent; cursor: pointer; outline: none; opacity: 0.001; z-index: 999; overflow: hidden; padding: 0px; margin: 0px; display: block; position: absolute; width: 140.172px; height: 18px; left: 106px; top: 325px; visibility: visible;"></button>
												<button aria-label="Toggle visibility of Project Development" tabindex="-1" aria-pressed="false" class="highcharts-a11y-proxy-button" aria-hidden="false" style="border-width: 0px; background-color: transparent; cursor: pointer; outline: none; opacity: 0.001; z-index: 999; overflow: hidden; padding: 0px; margin: 0px; display: block; position: absolute; width: 147.063px; height: 18px; left: 106px; top: 343px; visibility: visible;"></button>
												<button aria-label="Toggle visibility of Other" tabindex="-1" aria-pressed="false" class="highcharts-a11y-proxy-button" aria-hidden="false" style="border-width: 0px; background-color: transpar
ent; cursor: pointer; outline: none; opacity: 0.001; z-index: 999; overflow: hidden; padding: 0px; margin: 0px; display: block; position: absolute; width: 55.8906px; height: 18px; left: 106px; top: 361px; visibility: visible;"></button>
											</div>
											<div aria-label="Chart menu" role="region" aria-hidden="false">
												<button aria-label="View chart menu" aria-expanded="false" class="highcharts-a11y-proxy-button" aria-hidden="false" style="border-width: 0px; background-color: transparent; cursor: pointer; outline: none; opacity: 0.001; z-index: 999; overflow: hidden; padding: 0px; margin: 0px; display: block; position: absolute; width: 24px; height: 22px; left: 326.5px; top: 10.5px;"></button>
											</div>
										</div>
									</div>
									<div id="highcharts-screen-reader-region-after-0" aria-label="" aria-hidden="false" style="position: relative;">
										<div aria-hidden="false" style="position: absolute; width: 1px; height: 1px; overflow: hidden; white-space: nowrap; clip: rect(1px, 1px, 1px, 1px); margin-top: -3px; opacity: 0.01;">
											<div id="highcharts-end-of-chart-marker-0">End of interactive chart.</div>
										</div>
									</div>
								</div>
							</figure>
							<script type="text/javascript">//
								<![CDATA[


Highcharts.chart('container', {

    title: {
        text: 'Solar Employment Growth by Sector, 2010-2016'
    },

    subtitle: {
        text: 'Source: thesolarfoundation.com'
    },

    yAxis: {
        title: {
            text: 'Number of Employees'
        }
    },

    xAxis: {
        accessibility: {
            rangeDescription: 'Range: 2010 to 2017'
        }
    },

    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
    },

    plotOptions: {
        series: {
            label: {
                connectorAllowed: false
            },
            pointStart: 2010
        }
    },

    series: [{
        name: 'Installation',
        data: [43934, 52503, 57177, 69658, 97031, 119931, 137133, 154175]
    }, {
        name: 'Manufacturing',
        data: [24916, 24064, 29742, 29851, 32490, 30282, 38121, 40434]
    }, {
        name: 'Sales & Distribution',
        data: [11744, 17722, 16005, 19771, 20185, 24377, 32147, 39387]
    }, {
        name: 'Project Development',
        data: [null, null, 7988, 12169, 15112, 22452, 34400, 34227]
    }, {
        name: 'Other',
        data: [12908, 5948, 8105, 11248, 8989, 11816, 18
274, 18111]
    }],

    responsive: {
        rules: [{
            condition: {
                maxWidth: 500
            },
            chartOptions: {
                legend: {
                    layout: 'horizontal',
                    align: 'center',
                    verticalAlign: 'bottom'
                }
            }
        }]
    }

});


  //]]>
							</script>
						</body>
					</html>
