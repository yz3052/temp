﻿#$%^&* scraper_huaxing_02.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  6 08:52:12 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu


# this script tells us how to scrub and use Hua xing's scraped raw data
# this also has a short backtest


### get raw Hua Xing data

i_data = pd.read_parquet(r'S:\Data\China Data Hunt\Huaxing_meetings_history.parquet')

i_data['index'] = i_data.index.values
i_data['ticker'] = i_data['title'].str.extract('(\d{6} CH)')

i_data['implied_yr'] = i_data['title'].str.extract('\s{1}(20[12]\d)')
i_data['implied_yr'] = i_data['implied_yr'].fillna(method = 'ffill')

i_data = i_data[i_data['event_date_str'].notnull() & (i_data['event_date_str'].str.strip()!='') ]
i_data['meeting_date_str']  = i_data['event_date_str'].str.strip()+' '+i_data['implied_yr']
i_data['meeting_date'] = pd.to_datetime(i_data['meeting_date_str'], errors = 'coerce')

i_data = i_data[i_data['ticker'].notnull()]
c_sz = i_data['ticker'].str[0].isin(['3','0'])
c_sh = i_data['ticker'].str[0].isin(['6'])
i_data.loc[c_sz, 'ticker'] = i_data.loc[c_sz, 'ticker'].str.replace(' CH','.SZ')
i_data.loc[c_sh, 'ticker'] = i_data.loc[c_sh, 'ticker'].str.replace(' CH','.SH')

i_data['datadate_2d'] = i_data['meeting_date'] - pd.to_timedelta('2 days')
i_data['flag_2'] = 1
i_data['datadate_5d'] = i_data['meeting_date'] - pd.to_timedelta('5 days')
i_data['flag_5'] = 1
i_data['datadate_10d'] = i_data['meeting_date'] - pd.to_timedelta('10 days')
i_data['flag_10'] = 1


### sd

i_sd_fx = pw.get_ashare_hk_sd()
i_sd_map_fx = i_sd_fx[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP+1d','RawRet+1d','isin_hk_uni']]
i_sd_map_fx = i_sd_map_fx.sort_values('datadate')




### combine fx - all

i_data = i_data.sort_values('meeting_date')

icomfxall = pd.merge_asof(i_sd_map_fx, i_data[['ticker','datadate_2d','flag_2']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_2d'], 
                     tolerance = pd.to_timedelta('2 days'), allow_exact_matches = False)

icomfxall = pd.merge_asof(icomfxall, i_data[['ticker','datadate_5d','flag_5']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_5d'], 
                     tolerance = pd.to_timedelta('5 days'), allow_exact_matches = False)

icomfxall = pd.merge_asof(icomfxall, i_data[['ticker','datadate_10d','title','event_type','flag_10']], 
                   
  by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_10d'], 
                     tolerance = pd.to_timedelta('10 days'), allow_exact_matches = False)


#------------------------------------------------------------------------------
### Idea 1: long before meetings
#------------------------------------------------------------------------------


### 2 days
icom2 = icomfxall.copy()
c_sgnl = (icom2['flag_2'] == 1)
icom2.loc[c_sgnl, 'sgnl'] = 1

o_1 = yu.bt_cn_15(icom2[icom2['datadate']<='2020-12-31'].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx)



### 5 days
icom2 = icomfxall.copy()
c_sgnl = (icom2['flag_5'] == 1)
icom2.loc[c_sgnl, 'sgnl'] = 1

o_1 = yu.bt_cn_15(icom2[icom2['datadate']<='2020-12-31'].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx)

### 10 days
icom2 = icomfxall.copy()
c_sgnl = (icom2['flag_10'] == 1)
icom2.loc[c_sgnl, 'sgnl'] = 1

o_1 = yu.bt_cn_15(icom2[icom2['datadate']<='2020-12-31'].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx)


### 2 days: NDR + corporate conf
icom2 = icomfxall.copy()
c_sgnl = (icom2['flag_2'] == 1)
icom2.loc[c_sgnl & icom2['event_type'].str.contains('^NDR|Corporate Conference'), 'sgnl'] = 1

o_1 = yu.bt_cn_15(icom2[icom2['datadate']<='2020-12-31'].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx)


### 5 days: NDR + corporate conf
icom2 = icomfxall.copy()
c_sgnl = (icom2['flag_5'] == 1)
icom2.loc[c_sgnl & icom2['event_type'].str.contains('^NDR|Corporate Conference'), 'sgnl'] = 1

o_1 = yu.bt_cn_15(icom2[icom2['datadate']<='2020-12-31'].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx)


### 10 days: NDR + corporate conf
icom2 = icomfxall.copy()
c_sgnl = (icom2['flag_10'] == 1)
icom2.loc[c_sgnl & icom2['event_type'].str.contains('^NDR|Corporate Conference'), 'sgnl'] = 1

o_1 = yu.bt_cn_15(icom2[icom2['datadate']<='2020-12-31'].\
        dropna(subset=['sgnl','Barr
Ret_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx)


### 5 days: NDR + corporate conf, hold 90 days
icom2 = icomfxall.copy()
c_sgnl = (icom2['flag_5'] == 1)
icom2.loc[c_sgnl & icom2['event_type'].str.contains('^NDR|Corporate Conference'), 'sgnl'] = 1

icom2['sgnl'] = icom2.groupby('ticker')['sgnl'].ffill(limit=90)

o_1 = yu.bt_cn_15(icom2[icom2['datadate']<='2020-12-31'].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx)


