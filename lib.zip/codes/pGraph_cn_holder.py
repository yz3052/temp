﻿#$%^&* pGraph_cn_holder.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 20 08:25:38 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu




### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()



### holder data

i_inst_h = yu.get_sql('''select s_info_windcode as ticker, report_period, ann_date as datadate, 
                      s_holder_compcode, s_holder_name, s_holder_holdercategory as holderSubType 
                      from wind.dbo.ashareinstholderderdata''')
i_inst_h = i_inst_h[i_inst_h['datadate'].notnull()]
i_inst_h['datadate'] = pd.to_datetime(i_inst_h['datadate'], format = '%Y%m%d')


# holder type
# 'QFII', '券商集合理财', '基金', '保险公司', '信托公司', '阳光私募',
# '券商', '企业年金', '基金管理公司', '陆股通', '社保基金'
# '非金融类上市公司', '财务公司', '一般法人', '银行'

type_strat = ['非金融类上市公司', '财务公司', '一般法人', '银行']
i_inst_h.loc[i_inst_h['holderSubType'].isin(type_strat), 'holderType'] = 'strategic'
type_financial = ['QFII', '券商集合理财', '基金', '保险公司', '信托公司', '阳光私募',
                  '券商', '企业年金', '基金管理公司', '陆股通', '社保基金']
i_inst_h.loc[i_inst_h['holderSubType'].isin(type_financial), 'holderType'] = 'investment'




### daily loop: generate holder set per date per ticker 


o_tk_holderStrat_map = []
o_tk_holderAll_map = []

for dt in pd.date_range(start = '2016-01-01', end = '2021-11-01'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    # select data 
    t_holder = i_inst_h[(i_inst_h['datadate']<=dt) & (i_inst_h['datadate']>=dt-pd.to_timedelta('182 days'))]
    
    t_tk_holderStrat_map = t_holder[t_holder['holderType']=='strategic'].\
                            groupby('ticker')['s_holder_compcode'].apply(lambda x: set(x))
    t_tk_holderStrat_map = t_tk_holderStrat_map.reset_index()
    t_tk_holderStrat_map['datadate'] = dt
    o_tk_holderStrat_map.append(t_tk_holderStrat_map)
    
    t_tk_holderAll_map = t_holder.groupby('ticker')['s_holder_compcode'].apply(lambda x: set(x))
    t_tk_holderAll_map = t_tk_holderAll_map.reset_index()
    t_tk_holderAll_map['datadate'] = dt    
    o_tk_holderAll_map.append(t_tk_holderAll_map)
    
o_tk_holderStrat_map = pd.concat(o_tk_holderStrat_map, axis = 0)
o_tk_holderAll_map = pd.concat(o_tk_holderAll_map, axis = 0)




### Loop: shared holder within HK uni

o_shared_holder_cnt = []

for dt in pd.date_range(start = '2016-02-01', end = '2021-11-01', freq='W'):
    print(dt.strftime('%Y%m%d'), end 
= ' ')
    
    t_sd = i_sd[i_sd['datadate']==i_sd_dd[i_sd_dd<=dt].max()]
    t_tk_holderStrat_map = o_tk_holderStrat_map[o_tk_holderStrat_map['datadate']==dt]
    t_tk_holderStrat_map = t_tk_holderStrat_map[t_tk_holderStrat_map['ticker'].isin(t_sd['ticker'].tolist())]
    t_tk_holderAll_map = o_tk_holderAll_map[o_tk_holderAll_map['datadate']==dt]
    t_tk_holderAll_map = t_tk_holderAll_map[t_tk_holderAll_map['ticker'].isin(t_sd['ticker'].tolist())]

    
    t_tkPair_holderStratSet = pd.DataFrame((t_tk_holderStrat_map['s_holder_compcode'].values[:, None] &\
                                            t_tk_holderStrat_map['s_holder_compcode'].values))
    t_tkPair_holderStratCnt = t_tkPair_holderStratSet.applymap(lambda x: len(x) )
    t_tkPair_holderStratCnt.columns = t_tk_holderStrat_map['ticker'].values
    t_tkPair_holderStratCnt.index = t_tk_holderStrat_map['ticker'].values
    t_tkPair_holderStratCnt.values[[np.arange(t_tkPair_holderStratCnt.shape[0])]*2] = 0
    
    t_sum1 = t_tkPair_holderStratCnt.mean(axis = 1)
    t_sum1 = t_sum1.reset_index()
    t_sum1.columns = ['ticker','shared_holderStratCnt']
    
    
    t_tkPair_holderAllSet = pd.DataFrame((t_tk_holderAll_map['s_holder_compcode'].values[:, None] &\
                                          t_tk_holderAll_map['s_holder_compcode'].values))
    t_tkPair_holderAllCnt = t_tkPair_holderAllSet.applymap(lambda x: len(x) )
    t_tkPair_holderAllCnt.columns = t_tk_holderAll_map['ticker'].values
    t_tkPair_holderAllCnt.index = t_tk_holderAll_map['ticker'].values
    t_tkPair_holderAllCnt.values[[np.arange(t_tkPair_holderAllCnt.shape[0])]*2] = 0
    
    t_sum2 = t_tkPair_holderAllCnt.mean(axis = 1)
    t_sum2 = t_sum2.reset_index()
    t_sum2.columns = ['ticker','shared_holderAllCnt']
    
    t_sum = t_sum1.merge(t_sum2, on = ['ticker'], how = 'outer')    
    t_sum['datadate'] = dt
    
    o_shared_holder_cnt.append(t_sum)

o_shared_holder_cnt = pd.concat(o_shared_holder_cnt, axis = 0)
o_shared_holder_cnt = o_shared_holder_cnt.sort_values('datadate')

o_shared_holder_cnt.to_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_holder_o_shared_holder_cnt.parquet')
o_shared_holder_cnt = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_holder_o_shared_holder_cnt.parquet')


### combine 


icom = pd.merge_asof(i_sd, o_shared_holder_cnt, by='ticker', on='datadate')

icom['shared_holderStratCnt_bk'] = icom.groupby('datadate')['shared_holderStratCnt'].apply(lambda x: yu.pdqcut(x,bins=10)).value
s

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['shared_holderStratCnt_orth'] = icom.groupby('datadate')[COLS+['shared_holderStratCnt']].apply(lambda x: yu.orthogonalize_cn(x['shared_holderStratCnt'], x[COLS])).values
icom['shared_holderStratCnt_orth_bk'] = icom.groupby('datadate')['shared_holderStratCnt_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['shared_holderAllCnt_bk'] = icom.groupby('datadate')['shared_holderAllCnt'].apply(lambda x: yu.pdqcut(x,bins=10)).values

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['shared_holderAllCnt_orth'] = icom.groupby('datadate')[COLS+['shared_holderAllCnt']].apply(lambda x: yu.orthogonalize_cn(x['shared_holderAllCnt'], x[COLS])).values
icom['shared_holderAllCnt_orth_bk'] = icom.groupby('datadate')['shared_holderAllCnt_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['shared_holderAllCnt_orth_rk'] = icom.groupby('datadate')['shared_holderAllCnt_orth'].apply(yu.uniformed_rank).values


yu.create_cn_3x3(icom, ['shared_holderStratCnt_bk'], 'shared_holderStratCnt') # random
yu.create_cn_3x3(icom, ['shared_holderStratCnt_orth_bk'], 'shared_holderStratCnt_orth') # random
    
yu.create_cn_3x3(icom, ['shared_holderAllCnt_bk'], 'shared_holderAllCnt') # mono: -5 +1
yu.create_cn_3x3(icom, ['shared_holderAllCnt_orth_bk'], 'shared_holderAllCnt_orth') # mono: -6 +2
    
    
icom['orth_neg_sgnl'] = np.nan
icom.loc[icom['shared_holderAllCnt_orth_rk']<-0.8, 'orth_neg_sgnl']  = -1
icom['orth_neg_sgnl'] = icom.groupby('ticker')['orth_neg_sgnl'].ffill(limit=5)

icom['orth_pos_sgnl'] = np.nan
icom.loc[icom['shared_holderAllCnt_orth_rk']>0.5, 'orth_pos_sgnl']  = 1
icom['orth_pos_sgnl'] = icom.groupby('ticker')['orth_pos_sgnl'].ffill(limit=5)


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['orth_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'orth_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.64 / 2.07

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['csi300_flag']==1)].\
            dropna(subset=['orth_neg_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'orth_neg_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.54 / 1.3

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['orth_pos_sgnl','BarrRet
_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'orth_pos_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.49  / 0.78
