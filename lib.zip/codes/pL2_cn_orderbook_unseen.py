﻿#$%^&* pL2_cn_orderbook_unseen.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 10 19:11:18 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine


### sd

i_sd = pw.get_ashare_t2000_sd()


### get q

i_unseen = yu.get_q('''get `:/export/datadev/Data/SHSZ/odbk2min_batch1''', port = 5006)

i_unseen['ticker'] = i_unseen['code'].astype(str).str.zfill(6)
c_sh = i_unseen['ticker'].str[0].isin(['6'])
c_sz = i_unseen['ticker'].str[0].isin(['0','3'])
i_unseen.loc[c_sh, 'ticker'] = i_unseen.loc[c_sh, 'ticker'] + '.SH'
i_unseen.loc[c_sz, 'ticker'] = i_unseen.loc[c_sz, 'ticker'] + '.SZ'

i_unseen = i_unseen.rename(columns = {'date': 'datadate'})


### get spec situation

i_spec = pw.get_wind_limit()
i_spec['flg_any_lmtupdn'] = i_spec[['limitup_allday', 'limitdown_allday','limitup_touch', 
                                    'limitdown_touch', 'limitup_onclose','limitdown_onclose']].max(axis=1)
i_spec = i_spec[['ticker','datadate','flg_any_lmtupdn']]



### combine

icom = i_sd.merge(i_unseen, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_spec, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])

icomind = pd.get_dummies(icom['GIND'])
icom = pd.concat([icom, icomind], axis = 1)
icom['ones'] = 1
cols_i = icomind.columns.tolist()
cols_f = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']


# b unseen / seen, s unseen / seen

icom['b_unseen_dv_seen'] = icom['bid_v_gt10'] / (icom['bid_v_le5'] + icom['bid_v_6to10'])
icom['s_unseen_dv_seen'] = icom['ask_v_gt10'] / (icom['ask_v_le5'] + icom['ask_v_6to10'])

icom['b_unseen_dv_seen_orth'] = icom.groupby('datadate')[['b_unseen_dv_seen','ones']+cols_i+cols_f].apply(lambda x: yu.orthogonalize_cn_v3(x['b_unseen_dv_seen'], x[cols_f], x[cols_i], x['ones'])).values
icom['s_unseen_dv_seen_orth'] = icom.groupby('datadate')[['s_unseen_dv_seen','ones']+cols_i+cols_f].apply(lambda x: yu.orthogonalize_cn_v3(x['s_unseen_dv_seen'], x[cols_f], x[cols_i], x['ones'])).values

icom['b_unseen_dv_seen_orth_bk'] = icom.groupby('datadate')['b_unseen_dv_seen_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['s_unseen_dv_seen_orth_bk'] = icom.groupby('datadate')['s_unseen_dv_seen_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['b_unseen_dv_seen_orth_bk'], 'b_unseen_dv_seen_orth') 
# 0 +2 -2.7
yu.create_cn_3x3(icom, ['s_unseen_dv_seen_orth_bk'], 's_unseen_dv_seen_orth') # 0 +2 -4.5


# b unseen / s unseen

icom['unseen_b_dv_s'] = icom['bid_v_gt10'] / icom['ask_v_gt10']
icom['unseen_b_dv_s'] = icom['unseen_b_dv_s'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
icom['unseen_b_dv_s'] = icom['unseen_b_dv_s'].replace(0, np.nan)
icom['unseen_b_dv_s_orth'] = icom.groupby('datadate')[['unseen_b_dv_s','ones']+cols_i+cols_f].apply(lambda x: yu.orthogonalize_cn_v3(x['unseen_b_dv_s'], x[cols_f], x[cols_i], x['ones'],normal_y=True)).values
icom['unseen_b_dv_s_orth_bk'] = icom.groupby('datadate')['unseen_b_dv_s_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['unseen_b_dv_s_orth_bk'], 'unseen_b_dv_s_orth') # mono: -6 +5.0
yu.create_cn_3x3(icom[icom['flg_any_lmtupdn']!=1], ['unseen_b_dv_s_orth_bk'], 'unseen_b_dv_s_orth') # mono: -5 +2


icom['unseen_b_dv_s_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate',min_periods=10)['unseen_b_dv_s'].mean().values
icom['unseen_b_dv_s_t20d_orth'] = icom.groupby('datadate')[['unseen_b_dv_s_t20d','ones']+cols_i+cols_f].apply(lambda x: yu.orthogonalize_cn_v3(x['unseen_b_dv_s_t20d'], x[cols_f], x[cols_i], x['ones'],normal_y=True)).values
icom['unseen_b_dv_s_t20d_orth_bk'] = icom.groupby('datadate')['unseen_b_dv_s_t20d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['unseen_b_dv_s_t20d_orth_bk'], 'unseen_b_dv_s_t20d_orth') # random

icom['unseen_b_dv_s_t5d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=7),on='datadate',min_periods=2)['unseen_b_dv_s'].mean().values
icom['unseen_b_dv_s_t5d_orth'] = icom.groupby('datadate')[['unseen_b_dv_s_t5d','ones']+cols_i+cols_f].apply(lambda x: yu.orthogonalize_cn_v3(x['unseen_b_dv_s_t5d'], x[cols_f], x[cols_i], x['ones'],normal_y=True)).values
icom['unseen_b_dv_s_t5d_orth_bk'] = icom.groupby('datadate')['unseen_b_dv_s_t5d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['unseen_b_dv_s_t5d_orth_bk'], 'unseen_b_dv_s_t5d_orth') # mono: -3.8 +3.8





# net unseen std


icom['net_vstd_gt10'] = icom['net_vstd_gt10'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
icom['net_vstd_gt10_orth'] = icom.groupby('datadate')[['net_vstd_gt10','ones']+cols_i+cols_f].apply(lambda x: yu.orthogonalize_cn_v3(x['net_vstd_gt10'], x[cols_f], x[cols_i], x['ones'],normal_y=True)).values
icom['net_vstd_gt10_orth_bk'] = icom.groupby('datadate')['net_vstd_gt10_orth'].apply(lambda 
x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['net_vstd_gt10_orth_bk'], 'net_vstd_gt10_orth') # mono: +3.3 / -4.4

icom['ask_vstd_dv_v_gt10'] = icom['ask_vstd_gt10'] / icom['ask_v_gt10']
icom['bid_vstd_dv_v_gt10'] = icom['bid_vstd_gt10'] / icom['bid_v_gt10']
icom['bidask_vstd_dv_v_gt10'] = icom['bid_vstd_dv_v_gt10'] / icom['ask_vstd_dv_v_gt10']
icom['bidask_vstd_dv_v_gt10_orth'] = icom.groupby('datadate')[['bidask_vstd_dv_v_gt10','ones']+cols_i+cols_f].apply(lambda x: yu.orthogonalize_cn_v3(x['bidask_vstd_dv_v_gt10'], x[cols_f], x[cols_i], x['ones'],normal_y=True)).values
icom['bidask_vstd_dv_v_gt10_orth_bk'] = icom.groupby('datadate')['bidask_vstd_dv_v_gt10_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['bidask_vstd_dv_v_gt10_orth_bk'], 'bidask_vstd_dv_v_gt10_orth') # random

icom['bidask_vstd_gt10'] = icom['bid_vstd_gt10'] / icom['ask_vstd_gt10']
icom['bidask_vstd_gt10'] = icom['bidask_vstd_gt10'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
icom['bidask_vstd_gt10_orth'] = icom.groupby('datadate')[['bidask_vstd_gt10','ones']+cols_i+cols_f].apply(lambda x: yu.orthogonalize_cn_v3(x['bidask_vstd_gt10'], x[cols_f], x[cols_i], x['ones'],normal_y=True)).values
icom['bidask_vstd_gt10_orth_bk'] = icom.groupby('datadate')['bidask_vstd_gt10_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['bidask_vstd_gt10_orth_bk'], 'bidask_vstd_gt10_orth') # mono: -6 +4

icom['bidask_vstd_gt10_t5d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=7),min_periods=2,on='datadate')['bidask_vstd_gt10'].mean().values
icom['bidask_vstd_gt10_t5d_orth'] = icom.groupby('datadate')[['bidask_vstd_gt10_t5d','ones']+cols_i+cols_f].apply(lambda x: yu.orthogonalize_cn_v3(x['bidask_vstd_gt10_t5d'], x[cols_f], x[cols_i], x['ones'],normal_y=True)).values
icom['bidask_vstd_gt10_t5d_orth_bk'] = icom.groupby('datadate')['bidask_vstd_gt10_t5d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['bidask_vstd_gt10_t5d_orth_bk'], 'bidask_vstd_gt10_t5d_orth') # -3.7 +2.3

icom['bidask_vstd_gt10_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),min_periods=10,on='datadate')['bidask_vstd_gt10'].mean().values
icom['bidask_vstd_gt10_t20d_orth'] = icom.groupby('datadate')[['bidask_vstd_gt10_t20d','ones']+cols_i+cols_f].apply(lambda x: yu.orthogonalize_cn_v3(x['bidask_vstd_gt10_t20d'], x[cols_f], x[cols_i], x['ones'],normal_y=True)).values
icom['bidask_vstd_gt10_t20d_orth_bk'] = icom.groupby('da
tadate')['bidask_vstd_gt10_t20d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['bidask_vstd_gt10_t20d_orth_bk'], 'bidask_vstd_gt10_t20d_orth') # less mono: -1.7 +2.4 0
