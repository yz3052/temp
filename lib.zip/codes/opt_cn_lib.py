﻿#$%^&* opt_cn_lib.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 26 09:51:18 2022

@author: thzhang
"""



import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


import mosek

import pyodbc


import scipy.stats as ss
import statsmodels.api as sm
import scipy





# =============================================================================
# 
# =============================================================================

def draw_pnl_plot(s):
    
    s['pos'] = s['opt_shr']*s['Price']
    s['trdd'] = s['opt_shr']*s['Price'] - s['opt_shr_old']*s['Price-1d']
    s['abstrdd'] = abs(s['trdd'])
    s['gmv'] = abs(s['opt_shr'] * s['Price'])
    
    totgmv = s.groupby('DataDate')['gmv'].sum().mean()    
    to = np.round(s['abstrdd'].sum() / s['gmv'].sum() * 100)
    
    s['stamp'] = 0.0003587
    condition = s['trdd'] < 0
    s.loc[condition,'stamp'] = 0.0013587
    
    s['stampcost'] = s['stamp'] * s['abstrdd']
    s['instcost'] = 0.16 * s['spread'] * s['abstrdd']
    s['transcost'] = 0.068 * ((s['volatility']/np.sqrt(252))**0.6) * ((s['abstrdd']/s['avgPVadj'])**0.5) * s['abstrdd']
    s['permcost'] = 18.9 * ((s['volatility']/np.sqrt(252))**2) * ((s['abstrdd']/s['avgPVadj'])) * s['abstrdd']
    
    s['borrowcost'] = 0
    condition = s['opt_shr'] < 0
    s.loc[condition,'borrowcost'] = - s.loc[condition,'opt_shr'] * s.loc[condition,'Price'] * 0.058 / 360
    
    s['rel_pnl'] = s['pos'] * s['AdjRet+1d'] 
    s['rel_pnl_atc'] = s['pos'] * s['AdjRet+1d'] - s['stampcost'] - s['instcost'] - s['transcost'] - s['permcost'] - s['borrowcost']
    
    ret = s.groupby('T+1d')['rel_pnl','rel_pnl_atc'].sum()
    ret = ret.reset_index()
    ret = ret.dropna()
    ret['cumpnl'] = ret['rel_pnl'].cumsum()
    ret['cumpnl_atc'] = ret['rel_pnl_atc'].cumsum()

    T = ret['cumpnl_atc'].tolist()
    Tmax = max([T[0],0])
    Tmin = min([T[0],0])
    mdw = Tmax-Tmin
    for i in range(1,len(T)):
        if T[i] < T[i-1]:
            Tmax = max([T[i-1],Tmax])
            Tmin = T[i]
            mdw = max([Tmax-Tmin,mdw])

    mdw = np.round(mdw/1e6,2)

    sr_pnl_bc = np.round(ret['rel_pnl'].mean() / ret['rel_pnl'].std() * np.sqrt(252),2)
    sr_pnl_ac = np.round(ret['rel_pnl_atc'].mean() / ret['rel_pnl_atc'].std() * np.sqrt(252),2)
    
    mean_ret_bc = np.round( (s['rel_pnl'].sum() / s['gmv'].sum())*1e4,2)
    mean_ret_ac = np.round( (s['rel_pnl_atc'].sum() / s['gmv'].sum())*1e4,2)
  
    ept = np.round( (s['rel_pnl'].sum
() / s['abstrdd'].sum())*1e4,2)

    temp1 = s.groupby('Ticker')['rel_pnl'].sum()
    temp1 = temp1.reset_index()
    temp2 = s.groupby('Ticker')['abstrdd'].sum()
    temp2 = temp2.reset_index()
    temp3 = s.groupby('Ticker')['spread'].mean()
    temp3 = temp3.reset_index()
    
    temp = pd.merge(temp1, temp2, on=['Ticker'], how='inner')
    temp = pd.merge(temp, temp3, on=['Ticker'], how='inner')
    
    temp['spread_buk'] = pd.qcut(temp['spread'],10,labels=range(1,11))
    temp = temp.groupby('spread_buk').agg({'rel_pnl':'sum','abstrdd':'sum','spread':'mean'})
    temp['ept_spd'] = temp['rel_pnl'] / temp['abstrdd'] / temp['spread']
    ept_spd1 = np.round(temp['ept_spd'].mean(),2)
    
    temp = pd.merge(temp1, temp2, on=['Ticker'], how='inner')
    temp = pd.merge(temp, temp3, on=['Ticker'], how='inner')
    temp['ept_spd'] = temp['rel_pnl'] / temp['abstrdd'] / temp['spread']
    temp['ept_spd'] = temp['ept_spd'] * (temp['abstrdd'] / temp['abstrdd'].sum())
    ept_spd2 = np.round(temp['ept_spd'].sum(),2)
    
    ret = ret.set_index('T+1d')
    
    fig1 = plt.figure(figsize=(10,8))
    ax1 = fig1.add_subplot(211)
    ax1.plot(ret['cumpnl'])
    ax1.plot(ret['cumpnl_atc'])

    ax1.grid()
    ax1.set_ylabel('PNL', fontsize = 16)
    ax1.set_xlabel('Date',fontsize = 16)
    
    ax1.text(0.01, 0.87, 'Annualized Sharpe: ' + str(sr_pnl_bc) + '(bc), ' +  str(sr_pnl_ac) + ' (ac)', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.81, 'Daily Return on GMV: ' + str(mean_ret_bc) + ' bps (bc), ' + str(mean_ret_ac) + ' bps (ac)', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.75, 'Edge Per Trade: ' + str(ept) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.69, 'Edge Per Trade Per Spread: ' + str(ept_spd1) + ' | ' + str(ept_spd2), verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.63, 'Max Drawdown: $' + str(mdw) + 'mm', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )

    gmvlong = s[ s['pos'] > 0].groupby('DataDate')['gmv'].sum()
    gmvlong = gmvlong.reset_index()
    gmvlong.columns = ['DataDate','long']
    gmvlong = gmvlong.set_index('D
ataDate')
    gmvshort = s[ s['pos'] < 0].groupby('DataDate')['gmv'].sum()
    gmvshort = gmvshort.reset_index()
    gmvshort.columns = ['DataDate','short']
    gmvshort = gmvshort.set_index('DataDate')

    ax2 = fig1.add_subplot(212)
    gmv = pd.concat([gmvlong,gmvshort],axis=1)
    ax2.plot(gmv)
    
    ax2.grid()
    ax2.set_ylabel('AUM', fontsize = 16)

    ax2.text(0.01, 0.93, 'Avg Long Size: ' + str(round(gmvlong['long'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.87, 'Avg Short Size: ' + str(round(gmvshort['short'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.81, 'Total Size: ' + str(round(totgmv/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.75, 'Turnover: ' + str(to) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    
    

# =============================================================================
# new_port takes T's portfolio of columns: Ticker, alpha
# old_port takes T-1d's portfolio of columns: Ticker, opt_shr_old (T-1d's shares)
# universe is the T-1d universe which has columns: Ticker, Price (T-1d's price), avgPVadj, Avail_Amount_ABC (T's total available shortable amounts in shares)
# gmv in dollars: e.g. 50e6,
# lam is the coefficient before risk that needs to be tuned for optimized portfolio,
# rskexpscaps/secexpscaps/indexpscaps are dictionaries.
# sample for indexpscaps/secexpscaps/rskexpscaps:

#indnames = [ 'AIRLINES','AUTOCOMP','BANKS','BIOTECH','CAPGOODS','CHEMICAL','COMMSVCS','COMMUNIC','COMPUTER','CONSDUR','CONSTPP',
#             'CONSVCS','DIVFINAN','DIVMETAL','ENERGY','FOODPRD','FOODRETL','HEALTH','HSHLDPRD','INSURAN','INTERNET','MEDIA','OILEXPL',
#             'OILGAS','PHARMAC','PRECMETL','REALEST','RETAIL','SEMICOND','SOFTWARE','STEEL','TELECOM','TRANSPRT','UTILITY']
#indexpscaps = dict([ (x, 0.02) for x in indnames ])

#secnames = ['W_SECTOR_10','W_SECTOR_15','W_SECTOR_20','W_SECTOR_25','W_SECTOR_30','W_SECTOR_35','W_SECTOR_40','W_SECTOR_45','W_SECTOR_50','W_SECTOR_55','W_SECTOR_60']
#secexpscaps = dict([ (x, 0.02) for x in secnames ]) 

#rsknames = ['BETA','MOMENTUM','SIZE','EARNYILD','RESVOL','GROWTH','DIVYILD','BTOP'
,'LEVERAGE','LIQUIDTY','SIZENL']
#rskexpscaps = dict([ (x, 0.02) for x in rsknames ])
# =============================================================================


def mosekoptcn_single_alpha(new_port, old_port, universe, gmv, rskexpscaps, secexpscaps, indexpscaps, lam = 3, borrow_cap = 0.3, use_etb_universe=True, use_etb_amount=True):

    #==============================================================================
    #   merge old and new port
    #==============================================================================
    
    df = pd.merge(new_port, old_port, on=['Ticker'], how='outer')
    df = df.fillna(0)
    
    # =============================================================================
    #   merge with universe
    # =============================================================================
    
    df = pd.merge(df,universe, on=['Ticker'], how='inner')
    df = df.fillna(0)
    
    # =============================================================================
    #   turn on/off etb_avail_universe and/or etb_avail_amount
    # =============================================================================
    
    if (use_etb_amount == True):
        df['Avail_Dollar_ABC'] = df['Avail_Amount_ABC'] * df['Price'] * borrow_cap
    if (use_etb_universe == True) & (use_etb_amount == False):
        condition = df['Avail_Amount_ABC'] > 0
        df.loc[condition,'Avail_Amount_ABC'] = 1e9 # set an abitrary big number
        df['Avail_Dollar_ABC'] = df['Avail_Amount_ABC'] * df['Price']
    if (use_etb_universe == False) & (use_etb_amount == False):
        df['Avail_Dollar_ABC'] = 1e9 * df['Price'] # set an abitrary big number
    
    #==============================================================================
    #   calculate max and min positions: dmax and dmin
    #==============================================================================
    
    df = df.sort_values('Ticker')
    df = df.reset_index(drop=True)
    df['g'] = df['opt_shr_old'] * df['Price']
    df['clip'] = df['avgPVadj'].apply(lambda r: min([r*0.01,3e6]))
    df['poscap1_ub'] = df['clip']
    df['poscap1_lb'] = - df['clip']
    df['poscap2_lb'] = df['g'].apply(lambda r: min([0,r])) - df['Avail_Dollar_ABC']
    df['dmax'] = df['clip']
    df['dmin'] = df[['poscap1_lb','poscap2_lb']].max(axis = 1)
    dmin = np.array(df['dmin'])
    dmax = np.array(df['dmax'])

    #==============================================================================
    #  c
alcualte weighting matrix: GT
    #==============================================================================
    
    df['wts'] = df.apply(lambda r: 1.0/r['clip'],axis=1)
    wts = np.array(df['wts']) 
    GT = np.diag(np.sqrt(wts))
    m = len(GT)
    
    # =============================================================================
    #  Exposure caps
    # =============================================================================
    
    Rskexps_cap = np.array(list(rskexpscaps.values())) * gmv
    Rskexps = df[list(rskexpscaps.keys())].values.transpose()
    Secexps_cap = np.array(list(secexpscaps.values())) * gmv
    Secexps = df[list(secexpscaps.keys())].values.transpose()
    Indexps_cap = np.array(list(indexpscaps.values())) * gmv
    Indexps = df[list(indexpscaps.keys())].values.transpose()
    rske = len(Rskexps)
    sece = len(Secexps)
    inde = len(Indexps)
    
    # =============================================================================
    #   alphas
    # =============================================================================

    mu = np.array(df['alpha']) 
    n = len(mu) 

    #==============================================================================
    #   mosek optimization
    #==============================================================================
   
    with mosek.Env() as env:
        with env.Task(0, 0) as task:

            #==============================================================================
            #==============================================================================
            # # Constrains             
            #==============================================================================
            #==============================================================================

            #==============================================================================
            #  Set Constrain Numbers
            #==============================================================================

            task.appendcons(1 + n + sece + inde + rske + m + n*2 + 1)

            #==============================================================================
            # 1. |sum(x)| = 0
            #==============================================================================

            task.putconbound(0, mosek.boundkey.fx, 0, 0)
            task.putconname(0, 'dollar neutral')

            #================================================================
==============
            # 2. dmin <= x <= dmax
            #==============================================================================

            task.putconboundlist(range(1, 1 + n), [mosek.boundkey.ra] * n, dmin, dmax)
            for j in range(1, 1 + n):
                task.putconname(j, "x[%d]" % j)

            #==============================================================================
            # 3. Sec exps caps            
            #==============================================================================

            task.putconboundlist(range(1 + n, 1 + n + sece), [mosek.boundkey.ra] * sece, -Secexps_cap, Secexps_cap)
            for j in range(1 + n, 1 + n + sece):
                task.putconname(j, "Secexps[%d]" % j)

            #==============================================================================
            # 4. Ind exps caps            
            #==============================================================================

            task.putconboundlist(range(1 + n + sece, 1 + n + sece + inde), [mosek.boundkey.ra] * inde, -Indexps_cap, Indexps_cap)
            for j in range(1 + n + sece, 1 + n + sece + inde):
                task.putconname(j, "Indexps[%d]" % j)

            #==============================================================================
            # 5. Rsk exps caps
            #==============================================================================

            task.putconboundlist(range(1 + n + sece + inde, 1 + n + sece + inde + rske), [mosek.boundkey.ra] * rske, -Rskexps_cap, Rskexps_cap)
            for j in range(1 + n + sece + inde, 1 + n + sece + inde + rske):
                task.putconname(j, "Rskexps[%d]" % j)

            #==============================================================================
            # 6. GTx - t = 0
            #==============================================================================

            task.putconboundlist(range(1 + n + sece + inde + rske, 1 + n + sece + inde + rske + m), [mosek.boundkey.fx] * m, [0.0] * m, [0.0] * m)
            for j in range(1 + n + sece + inde + rske, 1 + n + sece + inde + rske + m):
                task.putconname(j, "GT[%d]" % j)
                
            #==============================================================================
            # 7. v - x >= 0
            #==============================================================================

            task.putconboundlist(range(
1 + n + sece + inde + rske + m, 1 + n + sece + inde + rske + m + n), [mosek.boundkey.lo] * n, [0.0]*n, [np.inf] * n)
            for j in range(1 + n + sece + inde + rske + m, 1 + n + sece + inde + rske + m + n):
                task.putconname(j, "v1[%d]" % j)

            #==============================================================================
            # 8. v + x >= 0
            #==============================================================================

            task.putconboundlist(range(1 + n + sece + inde + rske + m + n, 1 + n + sece + inde + rske + m + n*2), [mosek.boundkey.lo] * n, [0.0]*n, [np.inf] * n)
            for j in range(1 + n + sece + inde + rske + m + n, 1 + n + sece + inde + rske + m + n*2):
                task.putconname(j, "v2[%d]" % j)
               
            #==============================================================================
            # 9. gmv constrian               
            #==============================================================================
                
            task.putconbound(1 + n + sece + inde + rske + m + n*2, mosek.boundkey.fx, gmv, gmv)
            task.putconname(1 + n + sece + inde + rske + m + n*2, 'gmv')
 
            #==============================================================================
            #   Variables
            #==============================================================================
            #==============================================================================

            #==============================================================================
            # Set Variable Numbers
            #==============================================================================
            
            task.appendvars(n*2 + 1 + m + 1)

            #==============================================================================
            # Set Variable offsets
            #==============================================================================

            offsetx = 0
            offsetv = n
            offsets = n*2
            offsett = n*2 + 1
            offsetu = n*2 + 1 + m
            
            #==============================================================================
            # Set Variable boundaries
            #==============================================================================

            task.putvarboundslice(offsetx, offsetx + n, [mosek.boundkey.fr] * n, [-np.inf] * n, [np.in
f] * n)
            for j in range(0, n):
                task.putvarname(offsetx + j, "x[%d]" % (1 + j))
                
            task.putvarboundslice(offsetv + 0, offsetv + n, [mosek.boundkey.fr] * n, [-np.inf] * n, [np.inf] * n)
            for j in range(0, n):
                task.putvarname(offsetv + j, "v[%d]" % (1 + j)) 

            task.putvarbound(offsets + 0, mosek.boundkey.fr, -np.inf, np.inf)
            task.putvarname(offsets + 0, "s")

            task.putvarboundslice(offsett + 0, offsett + m, [mosek.boundkey.fr] * m, [-np.inf] * m, [np.inf] * m)
            for j in range(0, m):
                task.putvarname(offsett + j, "t[%d]" % (1 + j))

            task.putvarbound(offsetu + 0, mosek.boundkey.fx, 0.5, 0.5)
            task.putvarname(offsetu + 0, "u")
                
            #==============================================================================
            #==============================================================================
            #   Matrix A
            #==============================================================================
            #==============================================================================

            #==============================================================================
            # 1. sum(x) 
            #==============================================================================

            task.putaijlist([0] * n, range(offsetx + 0, offsetx + n), [1.0] * n)
            
            #==============================================================================
            # 2. dmin <= x <= dmax
            #==============================================================================

            task.putaijlist(range(1, 1 + n), range(offsetx + 0, offsetx + n), [1.0] * n)

            #==============================================================================
            # 3. Secexp * x
            #==============================================================================

            for j in range(0, sece):
                task.putaijlist([1 + n + j] * n, range(offsetx + 0, offsetx + n), list(Secexps[j]))
            
            #==============================================================================
            # 4. Indexp * x
            #==============================================================================

            for j in range(0, inde):
                task.putaijlist([1 + n + sece + j] * n, range(offsetx 
+ 0, offsetx + n), list(Indexps[j]))

            #==============================================================================
            # 5. Rskexps * x
            #==============================================================================

            for j in range(0, rske):
                task.putaijlist([1 + n + sece + inde + j] * n, range(offsetx + 0, offsetx + n), list(Rskexps[j]))

            #==============================================================================
            # 6. GT * x - t
            #==============================================================================

            for j in range(0, m):
                task.putaijlist([1 + n + sece + inde + rske + j] * n, range(offsetx + 0, offsetx + n), list(GT[j]))

            task.putaijlist(range(1 + n + sece + inde + rske, 1 + n + sece + inde + rske + m), range(offsett + 0, offsett + m), [-1.0] * m)

            #==============================================================================
            # 7. v - x             
            #==============================================================================
            
            task.putaijlist(range(1 + n + sece + inde + rske + m, 1 + n + sece + inde + rske + m + n), range(offsetx + 0, offsetx + n), [-1.0] * n)
            task.putaijlist(range(1 + n + sece + inde + rske + m, 1 + n + sece + inde + rske + m + n), range(offsetv + 0, offsetv + n), [1.0] * n)

            #==============================================================================
            # 8. v + x
            #==============================================================================

            task.putaijlist(range(1 + n + sece + inde + rske + m + n, 1 + n + sece + inde + rske + m + n*2), range(offsetx + 0, offsetx + n), [1.0] * n)
            task.putaijlist(range(1 + n + sece + inde + rske + m + n, 1 + n + sece + inde + rske + m + n*2), range(offsetv + 0, offsetv + n), [1.0] * n)
            
            #==============================================================================
            # 9. sum(v)            
            #==============================================================================
            
            task.putaijlist([1 + n + sece + inde + rske + m + n*2] * n, range(offsetv + 0, offsetv + n), [1.0] * n)
            
            #==============================================================================
            #   Array C
            #============================================
==================================
            #==============================================================================

            task.putclist(range(offsetx, offsetx + n), mu)
            task.putcj(offsets + 0, -lam)

            #==============================================================================
            #==============================================================================
            #   Cones
            #==============================================================================
            #==============================================================================

            task.appendcone(mosek.conetype.rquad, 0.0, [offsets, offsetu] + list(range(offsett, offsett + m)))
            task.putconename(0, "risk")

            task.putobjsense(mosek.objsense.maximize)
            task.optimize()

            xx = [0.] * n
            task.getxxslice(mosek.soltype.itr, offsetx + 0, offsetx + n, xx)
            
            
    xx = pd.DataFrame(xx) 
    xx.columns = ['opt_dollar']

    df = pd.concat([df,xx],axis = 1)
    df = df[['Ticker','opt_dollar']]
    
    return(df)    








def serchopt(gmv_in, lam, borrow_cap, use_etb_universe, use_etb_amount, startdatestr, enddatestr, alpha_dataframe, top_decile = False):
    

    conn = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=CNDBPROD;UID=svc_fg_dbo;PWD=1eDecejiqu39;TDS_Version=8.0;')

    indnames = [ 'AIRLINES','AUTOCOMP','BANKS','BIOTECH','CAPGOODS','CHEMICAL','COMMSVCS','COMMUNIC','COMPUTER','CONSDUR','CONSTPP',
                 'CONSVCS','DIVFINAN','DIVMETAL','ENERGY','FOODPRD','FOODRETL','HEALTH','HSHLDPRD','INSURAN','INTERNET','MEDIA','OILEXPL',
                 'OILGAS','PHARMAC','PRECMETL','REALEST','RETAIL','SEMICOND','SOFTWARE','STEEL','TELECOM','TRANSPRT','UTILITY']
    
    #indexpscaps = dict([ (x, 0.02) for x in indnames ])
    indexpscaps = dict([ (x, 0.5) for x in indnames ])

    # =============================================================================
    # 
    # =============================================================================
    
    secnames = ['W_SECTOR_10','W_SECTOR_15','W_SECTOR_20','W_SECTOR_25','W_SECTOR_30','W_SECTOR_35','W_SECTOR_40','W_SECTOR_45','W_SECTOR_50','W_SECTOR_55','W_SECTOR_60']
    #secexpscaps = dict([ (x, 0.02) for x in secnames ]) 
    secexpscaps = dict([ (x, 0.5) for x in secnames ]) 

    # ==========================================================================
===
    # 
    # =============================================================================
    
    rsknames = ['BETA','MOMENTUM','SIZE','EARNYILD','RESVOL','GROWTH','DIVYILD','BTOP','LEVERAGE','LIQUIDTY','SIZENL']
    #rskexpscaps = dict([ (x, 0.02) for x in rsknames ])
    rskexpscaps = dict([ (x, 0.05) for x in rsknames ])
    
    # =============================================================================
    # 
    # =============================================================================
    
    sql = '''
    select distinct TradeDate_next as TradeDate 
    from CNDBPROD.dbo.Calendar_Dates_HC
    where TradeDate_next >= startdatestr and TradeDate_next <= enddatestr
    '''
    sql = sql.replace( 'startdatestr', '\''+ startdatestr + '\'' )
    sql = sql.replace( 'enddatestr', '\''+ enddatestr + '\'' )
    cd = pd.read_sql(sql,conn)
    cd = cd.sort_values('TradeDate')
    cd['TradeDateStr'] = cd['TradeDate'].apply(lambda r: str( r.year * 10000 + r.month * 100 + r.day ))
    cd['TradeDateStr2'] = cd['TradeDate'].dt.strftime('%Y-%m-%d')
    cd = cd.reset_index(drop=True)
    cday = cd['TradeDate'].tolist()
    cdstr = cd['TradeDateStr'].tolist() 
    cdstr2 = cd['TradeDateStr2'].tolist()
    
    df_dport = pd.DataFrame([])
    for dd in range(1,len(cday)):
        
        print(dd, end=',')
        todaystr = cdstr[dd]
        todaystr2 = cdstr2[dd]
        yesterday = cday[dd-1]
        yesterdaystr = cdstr[dd-1]
       
        #==============================================================================
        #     
        #==============================================================================
        
        if dd <= (gmv_in / 10e6):
            gmv = 10e6 * dd
        else:
            gmv = gmv_in
        
        #==============================================================================
        # 
        #==============================================================================
        
        sql = '''
        select Ticker, SEDOL, PX_CLOSE, FX_LAST, MC, W_SECTOR, isinHC,
        avgPVadj_USD as avgPVadj, spread, cccny_vol_21d as volatility,
        SRISK,BETA,MOMENTUM,SIZE,EARNYILD,RESVOL,GROWTH,DIVYILD,BTOP,LEVERAGE,LIQUIDTY,SIZENL,
        AIRLINES,AUTOCOMP,BANKS,BIOTECH,CAPGOODS,CHEMICAL,COMMSVCS,COMMUNIC,COMPUTER,CONSDUR,CONSTPP,
        CONSVCS,DIVFINAN,DIVMETAL,ENERGY,FOODPRD,FOODRETL,HEALTH,HSHLDPRD,INSURAN,INTERNET,MEDIA,OILEXPL,
        OILGAS,PHARMAC,PRECMETL,REALEST,RETAIL,SEMICOND,SOFTWARE,S
TEEL,TELECOM,TRANSPRT,UTILITY
        from CNDBPROD.dbo.UNIVERSE_T3000_CN_GEM3L where DataDate = yesterdaystr and PX_CLOSE > 0
        '''
        sql = sql.replace( 'yesterdaystr', '\''+ yesterdaystr + '\'' )
        universe = pd.read_sql(sql,conn)
        universe['Price'] = universe['PX_CLOSE'] / universe['FX_LAST']
        universe['MC'] = universe['MC'] * 1e4 / universe['FX_LAST']
    
        universe = universe.reset_index(drop=True)
        secs = pd.get_dummies(universe['W_SECTOR'],prefix='W_SECTOR')
        universe = pd.concat([universe, secs],axis=1)
    
        #==============================================================================
        #         
        #==============================================================================
        
        df_alpha = alpha_dataframe[alpha_dataframe['DataDate']==todaystr2]
        df_alpha = df_alpha[['Ticker', 'alpha']]
        
        if len(df_alpha) == 0:
            df_alpha = alpha_dataframe[alpha_dataframe['DataDate']==yesterdaystr[:4]+'-'+yesterdaystr[4:6]+'-'+yesterdaystr[6:8]]
            df_alpha = df_alpha[['Ticker', 'alpha']]
            
        # =============================================================================
        #     
        # =============================================================================
        
        df_alpha = universe[['Ticker']].merge(df_alpha, on = 'Ticker', how = 'left') ###!!!
        
        df_alpha = df_alpha.reset_index(drop=True)
        df_alpha['alpha'] = df_alpha['alpha'].fillna(0)
        df_alpha = df_alpha[['Ticker','alpha']]
        
        if top_decile == True:
            df_alpha.loc[df_alpha['alpha'].abs()<0.8, 'alpha'] = 0
        
        
        
        #==============================================================================
        # 
        #==============================================================================
                    
        sql = '''
        select RIC, Avail_Amount_MS, Rate_MS, Avail_Amount_UBS, Rate_UBS, Avail_Amount_GS, Rate_GS,
        Avail_Amount_JPM, Rate_JPM, Avail_Amount_BAML, Rate_BAML, Avail_Amount_CITI, Rate_CITI
        from CNDBPROD.dbo.MLP_CN_ETBLIST_ABC_RIC
        where DataDate = todaystr
        '''
        sql = sql.replace('todaystr', '\'' + todaystr + '\'')
        ETB = pd.read_sql(sql, conn)
        ETB = ETB[ETB['RIC'].str.len()==9]
        ETB = ETB.drop_duplicates()
        ETB['EXG'] = ETB['RIC'].apply(lambda r: r.split('.')[1])
        ETB[
'Ticker'] = ETB['RIC'].apply(lambda r: r.split('.')[0])
        ETB['Avail_Amount_CITI'] = ETB['Avail_Amount_CITI'].fillna(0)
        ETB = ETB.groupby('Ticker')[['Avail_Amount_MS','Avail_Amount_UBS','Avail_Amount_GS','Avail_Amount_JPM','Avail_Amount_BAML','Avail_Amount_CITI']].sum()
        ETB['Avail_Amount_ABC'] = ETB[['Avail_Amount_MS','Avail_Amount_UBS','Avail_Amount_GS','Avail_Amount_JPM','Avail_Amount_BAML','Avail_Amount_CITI']].sum(axis=1)
        ETB = ETB.reset_index()
        ETB = ETB[['Ticker','Avail_Amount_ABC']]
        
        #==============================================================================
        #     
        #==============================================================================
        
        universe = pd.merge(universe, ETB, on=['Ticker'], how='left')
    
        # =============================================================================
        #     
        # =============================================================================
        
        if dd == 1:
            df_alpha['opt_shr'] = 0
            old_port = df_alpha.copy()
        else:
            old_port = df_dport[ df_dport['DataDate'] == yesterday ]
    
        old_port = old_port[['Ticker','opt_shr']]
        old_port.columns = ['Ticker','opt_shr_old']
        new_port = df_alpha[['Ticker','alpha']]
    
        df_alpha = mosekoptcn_single_alpha(new_port, old_port, universe, gmv, rskexpscaps, secexpscaps, indexpscaps, lam, borrow_cap, use_etb_universe, use_etb_amount)
        
        df_alpha = df_alpha.merge(universe[['Ticker', 'Price', 'spread','volatility','avgPVadj']], on = 'Ticker', how = 'left')
            
        df_alpha['opt_shr'] = df_alpha['opt_dollar'] / df_alpha['Price']
        df_alpha['opt_shr'] = df_alpha['opt_shr'].apply(lambda r: int(round(r/100.0)*100))
        df_alpha['opt_dollar'] = df_alpha['opt_shr'] * df_alpha['Price']

        # =============================================================================
        #             
        # =============================================================================
        
        df_alpha['DataDate'] = pd.to_datetime(todaystr)
        df_alpha['T-1d'] = yesterday
        
        df_alpha = df_alpha.merge(old_port, on = 'Ticker', how = 'left')
        df_alpha['opt_shr_old'] = df_alpha['opt_shr_old'].fillna(0)
        
        df_alpha = df_alpha[['DataDate','T-1d','Ticker', 
                             'opt_shr','opt_dollar', 'opt_shr_old',
   
                          'spread','volatility','avgPVadj','Price'
                           ]]
        
        df_alpha = df_alpha.sort_values(['Ticker'])
        df_alpha = df_alpha.reset_index(drop=True)   
    
        df_dport = pd.concat([df_dport,df_alpha])
        print(todaystr, end = ',')
        
    #==============================================================================
    #     
    #==============================================================================
    
    df_exp = df_dport.copy()
    df_exp = df_exp.rename(columns={'Price':'Price-1d'})
    
    #==============================================================================
    #  
    #==============================================================================
    
    sql = '''
    select DataDate, Ticker, AdjRet_USD as AdjRet, (PX_CLOSE / FX_LAST) as Price 
    from CNDBPROD.dbo.UNIVERSE_ALL_CN_GEM3L
    where DataDate >= startdatestr and DataDate <= enddatestr
    '''
    sql = sql.replace( 'startdatestr', '\''+ startdatestr + '\'' )
    sql = sql.replace( 'enddatestr', '\''+ enddatestr + '\'' )
    bbgdata = pd.read_sql(sql, conn)
    
    #==============================================================================
    #  
    #==============================================================================
    
    sql = '''
    select distinct TradeDate_next as DataDate
    from CNDBPROD.dbo.Calendar_Dates_CN
    '''
    alldays = pd.read_sql(sql,conn)
    alldays = alldays.sort_values('DataDate')
    alldays['T+1d'] = alldays['DataDate'].shift(-1)
    alldays = alldays.dropna()
    
    df_exp = pd.merge(df_exp, alldays, on = ['DataDate'], how = 'inner')
    
    datatemp = bbgdata[['DataDate','Ticker','AdjRet']]
    datatemp = datatemp.rename(columns={'DataDate':'T+1d','AdjRet':'AdjRet+1d'})
    df_exp = pd.merge(df_exp, datatemp, on = ['T+1d','Ticker'], how = 'inner')
    
    datatemp = bbgdata[['DataDate','Ticker','Price']]
    df_exp = pd.merge(df_exp, datatemp, on = ['DataDate','Ticker'], how = 'inner')
    
    draw_pnl_plot(df_exp)

