﻿#$%^&* featurepool_cn_suntime_ugdg_tp_prodSYNC.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 30 08:15:30 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pyodbc
from sqlalchemy import create_engine
import urllib

import os
import datetime

from multiprocessing import Pool


#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------


save_path = '/dat/summit_capital/TZ/PROD_FEATURES/featurepool_cn_desc_suntime_ugdg_tp'
conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
conn_wind = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_wind_dbo;PWD=DusONA3Habredl;''TDS_Version=8.0;')))

today = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
today = pd.to_datetime(today.date())
today_str = today.strftime('%Y%m%d')



#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------


i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()



#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------



dates_to_query = i_cal['DataDate'].dt.strftime('%Y%m%d.parquet').drop_duplicates().tolist()
dates_to_query = [d for d in dates_to_query if (d>='20170101.parquet') and (d<today.strftime('%Y%m%d.parquet'))]

existing_dates = os.listdir(save_path)

dates_to_query = [d for d in dates_to_query if d not in existing_dates]




#------------------------------------------------------------------------------
### helper functions
#------------------------------------------------------------------------------


def calculate_ugdg_tp(i):
    
       
    
    
    #--------------------------------------------------------------------------
    # step 1 - dates a
nd timestamps
    #--------------------------------------------------------------------------
    t_1d = pd.to_datetime(i, format='%Y%m%d.parquet')
    t_1d_str = t_1d.strftime('%Y%m%d')
    t_91d_ts = t_1d - pd.to_timedelta('91 days')
    t_456d_ts = t_1d - pd.to_timedelta('455 days')
    t_456d_str = t_456d_ts.strftime('%Y%m%d')
    t_0d_str = i_cal.loc[i_cal['T-1d']==t_1d, 'DataDate'].dt.strftime('%Y-%m-%d').iloc[0]
    t_0d = pd.to_datetime(t_0d_str)
    today_4am_str = t_0d.strftime('%Y-%m-%d')+' 04:00:00'
    
    
    #--------------------------------------------------------------------------
    # step 2 - get ed calendar
    #--------------------------------------------------------------------------
       
    t_ed_cal = pd.read_sql('''select Ticker, last_ed
                               FROM [CNDBPROD].[dbo].[CNINFO_ED_format] 
                               with (nolock)
                               where datadate = '{0}'
                               order by Ticker, d2nexted 
                               '''.format(t_1d_str), conn)
    
    t_ed_cal = t_ed_cal.drop_duplicates(subset = ['Ticker'], keep = 'first')
            
    
    
    #--------------------------------------------------------------------------
    ### step 3 - get suntime data
    #--------------------------------------------------------------------------
    
    # step 3.1 - get raw data and format it
    
    i_rpt_original = pd.read_sql('''select report_id, stock_code as Ticker, create_date,
                                 organ_id, author_name, 
                                 target_price_ceiling as tpu, target_price_floor as tpl  
                                 from suntime_prod.dbo.rpt_forecast_stk
                        WITH (NOLOCK)
                        where entrytime < '{0}'
                            and create_date <= '{1}'
                            and create_date >= '{2}'
                            and (report_type not in (21, 28, 98))
                            and ((target_price_ceiling is not null) or (target_price_floor is not null))
                        order by create_date, entrytime 
                        '''.format(today_4am_str, t_1d_str, t_456d_str), conn) 
                        
    i_rpt_original = i_rpt_original[i_rpt_original['Ticker'].str[0].isin(['0','3','6'])]
    
    i_rpt_original['create_date'] = pd.to_datetime(i_rpt_original['create_date'])
        
    i_rpt_original['author_name'] = i_rpt_original['author_na
me'].fillna('_')
    c1 = i_rpt_original['author_name'].str.contains(',')
    i_rpt_original.loc[c1, 'author_1st'] = i_rpt_original.loc[c1, 'author_name'].str.split(',').str[0]
    i_rpt_original.loc[~c1, 'author_1st'] = i_rpt_original.loc[~c1, 'author_name']
        
    # step 3.2 - calculate tp as the mean of l and u
    
    i_rpt_original['tp'] = i_rpt_original[['tpu','tpl']].mean(axis=1)
    
    # step 3.3 - dedup
    
    i_rpt_original = i_rpt_original.drop_duplicates(subset = ['report_id', 'Ticker'], keep = 'last')
    
    # step 3.4 - wrap up
    
    i_rpt_original = i_rpt_original[['Ticker','report_id','organ_id','author_1st','create_date','tp']]
    
    
    
        
    
    #--------------------------------------------------------------------------
    ### step 4 - get adj factor
    # for faster computation, only fetch adjfactor when it is changed
    #--------------------------------------------------------------------------
    
    i_adj = pd.read_sql('''with tb1 as (select s_info_windcode, trade_dt, s_dq_adjfactor, 
                                               lag(s_dq_adjfactor,1) over (partition by 
                                                                           s_info_windcode 
                                                                           order by s_info_windcode, trade_dt) 
                                               as s_dq_adjfactor_1 
                                        from WIND_PROD.dbo.ASHAREEODPRICES
                                        where trade_dt<='{0}' and trade_dt>='{1}' )
                           select s_info_windcode as Ticker, trade_dt as create_date, 
                                  s_dq_adjfactor as adjf 
                           from tb1 
                           where ((s_dq_adjfactor!=s_dq_adjfactor_1) or (s_dq_adjfactor_1 is null)) 
                           order by trade_dt '''.format(t_1d_str, t_456d_str), conn_wind)
    
    i_adj['Ticker'] = i_adj['Ticker'].str[:6]
    i_adj = i_adj[i_adj['Ticker'].str[0].isin(['0','3','6'])]
    i_adj['create_date'] = pd.to_datetime(i_adj['create_date'], format='%Y%m%d')
    
    
    #--------------------------------------------------------------------------
    ### step 5 - processing
    #--------------------------------------------------------------------------
    
    
    # step 5.1 - append adjfactor
    
    i_rpt_s3 = i_rpt_original.sort_values('create_date')
    i_rpt_s3 = pd.merge_asof(i_rpt_s3, i_adj, by = 'T
icker', on = 'create_date')
    i_rpt_s3['tp_adj'] = i_rpt_s3['tp'] * i_rpt_s3['adjf']
    
    i_rpt_s3 = i_rpt_s3[['organ_id','author_1st','Ticker','report_id','create_date','tp_adj']]
    i_rpt_s3 = i_rpt_s3.dropna()
        
    
    # step 5.2 - calculate prev rating
    
    t_rpt_s3 = i_rpt_s3.sort_values('create_date')
    t_rpt_s3['tp_prev'] = i_rpt_s3.sort_values('create_date').groupby(['organ_id', 'author_1st','Ticker'])['tp_adj'].shift()
    t_rpt_s3 = t_rpt_s3.drop(columns = ['tp_adj'])
    i_rpt_s3 = i_rpt_s3.merge(t_rpt_s3, on = ['organ_id','author_1st','Ticker','report_id','create_date'], how = 'left')
        
    
    # step 5.3 - append ed    
    
    i_rpt_s3 = i_rpt_s3.merge(t_ed_cal[['Ticker','last_ed']], on = 'Ticker', how = 'left')
    
    
    # step 5.4 - get the most recent and summary stat (since prev ed)
    
    i_rpt_s4 = i_rpt_s3[(i_rpt_s3['create_date']>i_rpt_s3['last_ed']+pd.to_timedelta('7 days')) | (i_rpt_s3['last_ed'].isnull())] 
    
    if len(i_rpt_s4) > 0:
        
        t_ugdg_tk_maxdd = i_rpt_s4.groupby(['Ticker','organ_id'])['create_date'].max().reset_index()
        t_ugdg_tk_maxdd = t_ugdg_tk_maxdd.merge(i_rpt_s4,on=['Ticker','organ_id','create_date'],how='inner')
            
        t_ugdg_tk_maxdd['score_tp_up'] = np.sign(t_ugdg_tk_maxdd['tp_adj'] - t_ugdg_tk_maxdd['tp_prev'])
        t_ugdg_tk_maxdd['score_tp_up'] = t_ugdg_tk_maxdd['score_tp_up'].fillna(0)
        
        t_ugdg_tk_maxdd['score_tp_up5pct'] = 0
        t_ugdg_tk_maxdd.loc[t_ugdg_tk_maxdd['tp_adj']/t_ugdg_tk_maxdd['tp_prev']>=1.05, 'score_tp_up5pct'] = 1
        t_ugdg_tk_maxdd.loc[t_ugdg_tk_maxdd['tp_adj']/t_ugdg_tk_maxdd['tp_prev']<=0.95, 'score_tp_up5pct'] = -1
        
        t_ugdg_tk_maxdd['score_tp_up10pct'] = 0
        t_ugdg_tk_maxdd.loc[t_ugdg_tk_maxdd['tp_adj']/t_ugdg_tk_maxdd['tp_prev']>=1.1, 'score_tp_up10pct'] = 1
        t_ugdg_tk_maxdd.loc[t_ugdg_tk_maxdd['tp_adj']/t_ugdg_tk_maxdd['tp_prev']<=0.9, 'score_tp_up10pct'] = -1
                
        t_ugdg_tk_maxdd = t_ugdg_tk_maxdd.groupby(['Ticker', 'organ_id'])[['score_tp_up','score_tp_up5pct','score_tp_up10pct']].apply(lambda x: np.sign(x.mean())).reset_index()
            
        s_up_ratio_since_ed = t_ugdg_tk_maxdd.groupby('Ticker')[['score_tp_up','score_tp_up5pct','score_tp_up10pct']].apply(lambda x: x.sum()/x.count())
        s_up_ratio_since_ed.columns = ['score_tp_up_sinceed','score_tp_up5pct_sinceed','score_tp_up10pct_sinceed']
        s_up_ratio_since_ed = s_u
p_ratio_since_ed.reset_index()        
        
    else:
        
        s_up_ratio_since_ed = pd.DataFrame(columns = ['Ticker','score_tp_up_sinceed','score_tp_up5pct_sinceed','score_tp_up10pct_sinceed'])
    
    
    # step 5.4 - get the most recent and summary stat (trailing 1q)
    
    i_rpt_s4 = i_rpt_s3[i_rpt_s3['create_date'] >= t_91d_ts ] 
    
    if len(i_rpt_s4) > 0:
        
        t_ugdg_tk_maxdd = i_rpt_s4.groupby(['Ticker','organ_id'])['create_date'].max().reset_index()
        t_ugdg_tk_maxdd = t_ugdg_tk_maxdd.merge(i_rpt_s4,on=['Ticker','organ_id','create_date'],how='inner')
            
        t_ugdg_tk_maxdd['score_tp_up'] = np.sign(t_ugdg_tk_maxdd['tp_adj'] - t_ugdg_tk_maxdd['tp_prev'])
        t_ugdg_tk_maxdd['score_tp_up'] = t_ugdg_tk_maxdd['score_tp_up'].fillna(0)
        
        t_ugdg_tk_maxdd['score_tp_up5pct'] = 0
        t_ugdg_tk_maxdd.loc[t_ugdg_tk_maxdd['tp_adj']/t_ugdg_tk_maxdd['tp_prev']>=1.05, 'score_tp_up5pct'] = 1
        t_ugdg_tk_maxdd.loc[t_ugdg_tk_maxdd['tp_adj']/t_ugdg_tk_maxdd['tp_prev']<=0.95, 'score_tp_up5pct'] = -1
        
        t_ugdg_tk_maxdd['score_tp_up10pct'] = 0
        t_ugdg_tk_maxdd.loc[t_ugdg_tk_maxdd['tp_adj']/t_ugdg_tk_maxdd['tp_prev']>=1.1, 'score_tp_up10pct'] = 1
        t_ugdg_tk_maxdd.loc[t_ugdg_tk_maxdd['tp_adj']/t_ugdg_tk_maxdd['tp_prev']<=0.9, 'score_tp_up10pct'] = -1
                
        t_ugdg_tk_maxdd = t_ugdg_tk_maxdd.groupby(['Ticker', 'organ_id'])[['score_tp_up','score_tp_up5pct','score_tp_up10pct']].apply(lambda x: np.sign(x.mean())).reset_index()
            
        s_up_ratio_t1q = t_ugdg_tk_maxdd.groupby('Ticker')[['score_tp_up','score_tp_up5pct','score_tp_up10pct']].apply(lambda x: x.sum()/x.count())
        s_up_ratio_t1q.columns = ['score_tp_up_t1q','score_tp_up5pct_t1q','score_tp_up10pct_t1q']
        s_up_ratio_t1q = s_up_ratio_t1q.reset_index()        
        
    else:
        
        s_up_ratio_t1q = pd.DataFrame(columns = ['Ticker','score_tp_up_t1q','score_tp_up5pct_t1q','score_tp_up10pct_t1q'])
    
    
    
    
    
    
    
    #--------------------------------------------------------------------------
    # save to parquet
    #--------------------------------------------------------------------------
    
    s_tp = s_up_ratio_since_ed.merge(s_up_ratio_t1q, on = 'Ticker', how = 'outer')
    s_tp['DataDate'] = t_0d
    s_tp.to_parquet(os.path.join(save_path, i))



if __name__ == '__main__':
    
    with Pool(20) as p:
        p.map(calculate_ugdg_tp,
 dates_to_query)
        
    

