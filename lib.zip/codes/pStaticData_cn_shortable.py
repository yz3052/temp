﻿#$%^&* pStaticData_cn_shortable.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 23 19:11:19 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu



#------------------------------------------------------------------------------
### get trading calendar
#------------------------------------------------------------------------------

i_cal = yu.get_sql('''select distinct tradedate_next, TradeDateID_next FROM [CNDBPROD].[dbo].[Calendar_Dates_CN]''')



#------------------------------------------------------------------------------
### get ABC
#------------------------------------------------------------------------------

cols_amt = ['amt_ms', 'amt_ubs', 'amt_gs', 'amt_jpm', 'amt_baml', 'amt_citi']
cols_usd = ['dollar_ms', 'dollar_ubs', 'dollar_gs', 'dollar_jpm', 'dollar_baml', 'dollar_citi']
cols_rate = ['rate_ms', 'rate_ubs', 'rate_gs', 'rate_jpm', 'rate_baml', 'rate_citi']

i_abc = yu.get_sql(''' select SUBSTRING(RIC, 1, 6) as Ticker, DataDate, 
                              sum(Avail_Amount_MS) as amt_ms, 
                              sum(Avail_Amount_MS*Rate_MS)/sum(Avail_Amount_MS) as rate_ms,
                              sum(Avail_Amount_UBS) as amt_ubs, 
                              sum(Avail_Amount_UBS*Rate_UBS)/sum(Avail_Amount_UBS) as rate_ubs,
                              sum(Avail_Amount_GS) as amt_gs, 
                              sum(Avail_Amount_GS*Rate_GS)/sum(Avail_Amount_GS) as rate_gs,
                              sum(Avail_Amount_JPM) as amt_jpm, 
                              sum(Avail_Amount_JPM*Rate_JPM)/sum(Avail_Amount_JPM) as rate_jpm,
                              sum(Avail_Amount_BAML) as amt_baml, 
                              sum(Avail_Amount_BAML*Rate_BAML)/sum(Avail_Amount_BAML) as rate_baml,
                              sum(Avail_Amount_CITI) as amt_citi, 
                              sum(Avail_Amount_CITI*Rate_CITI)/sum(Avail_Amount_CITI) as rate_citi
                        FROM [CNDBPROD].[dbo].[MLP_CN_ETBList_ABC_RIC]  
                        where right(RIC,2)!='DY'
                        group by SUBSTRING(RIC, 1, 6), DataDate 
                        order by DataDate, Ticker''')
    
i_c = yu.get_sql('''select Ticker, DataDate, PX_CLOSE/FX_LAST as c_usd, avgPVadj_USD 
                    from [CNDBPROD].[dbo].[UNIVERSE_ALL_CN_GEM3L] 
                    where DataDate >= '2017-07-01' 
                    order by DataDate, Ticker ''')

i_abc_s2 = pd.merge_asof(i_
abc, i_c, by='Ticker', on='DataDate', allow_exact_matches = False)

i_abc_s2.loc[i_abc_s2['rate_ms']==0, 'amt_ms'] = np.nan
i_abc_s2.loc[i_abc_s2['rate_ubs']==0, 'amt_ubs'] = np.nan
i_abc_s2.loc[i_abc_s2['rate_gs']==0, 'amt_gs'] = np.nan
i_abc_s2.loc[i_abc_s2['rate_jpm']==0, 'amt_jpm'] = np.nan
i_abc_s2.loc[i_abc_s2['rate_baml']==0, 'amt_baml'] = np.nan
i_abc_s2.loc[i_abc_s2['rate_citi']==0, 'amt_citi'] = np.nan

i_abc_s2['dollar_ms'] = i_abc_s2['amt_ms'].multiply(i_abc_s2['c_usd'])
i_abc_s2['dollar_ubs'] = i_abc_s2['amt_ubs'].multiply(i_abc_s2['c_usd'])
i_abc_s2['dollar_gs'] = i_abc_s2['amt_gs'].multiply(i_abc_s2['c_usd'])
i_abc_s2['dollar_jpm'] = i_abc_s2['amt_jpm'].multiply(i_abc_s2['c_usd'])
i_abc_s2['dollar_baml'] = i_abc_s2['amt_baml'].multiply(i_abc_s2['c_usd'])
i_abc_s2['dollar_citi'] = i_abc_s2['amt_citi'].multiply(i_abc_s2['c_usd'])



i_abc_dd = i_abc_s2['DataDate'].drop_duplicates()

#------------------------------------------------------------------------------
### loop over hk trading dates
#------------------------------------------------------------------------------



o_stable_tk = []

for dt in i_abc_dd:
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    t_abc = i_abc_s2[(i_abc_s2['DataDate']<=dt)&(i_abc_s2['DataDate']>dt-pd.to_timedelta('91 days'))]
    
    t_abc['total_avail_amount'] = t_abc[cols_amt].sum(axis=1)
    t_abc['total_avail_dollar'] = t_abc[cols_usd].sum(axis=1)
    t_abc['amount_weighted_rate'] = (t_abc['rate_ms']*t_abc['amt_ms']).add(
                                     t_abc['rate_ubs']*t_abc['amt_ubs'], fill_value=0).add(
                                     t_abc['rate_gs']*t_abc['amt_gs'], fill_value=0).add(
                                     t_abc['rate_jpm']*t_abc['amt_jpm'], fill_value=0).add(
                                     t_abc['rate_baml']*t_abc['amt_baml'], fill_value=0).add(
                                     t_abc['rate_citi']*t_abc['amt_citi'], fill_value=0)\
                                    .divide(t_abc['total_avail_amount'])
    t_abc['clip'] = t_abc['avgPVadj_USD']*0.01
    t_abc.loc[t_abc['clip']>1e6, 'clip'] = 1e6
    t_abc['avail_dollar_per_clip'] = t_abc['total_avail_dollar'].divide(t_abc['clip'])
    
    
    s_abc_tdy = t_abc[(t_abc['DataDate']==dt)]
    
    
    
    s_abc_t3m_1 = t_abc.groupby('Ticker')[['total_avail_amount','total_avail_dollar','amount_weighted_rate','avail_dollar_per_clip']].mean().reset_index()
    s_abc_t3m_1 = s_abc_t3m_1.rename(columns={'total_avail_amoun
t':'average_amount_3m','total_avail_dollar':'average_avail_dollar_3m','amount_weighted_rate':'amount_weighted_rate_3m', 'avail_dollar_per_clip':'average_avail_dollar_3m_per_clip'})
    
    t_abc['brkr_cnt'] = t_abc[cols_amt].notnull().sum(axis=1)
    t_abc.loc[t_abc['brkr_cnt']>=1, 'flg_brkr_cnt_gt1'] = 1
    t_abc['flg_brkr_cnt_gt1'] = t_abc['flg_brkr_cnt_gt1'].fillna(0)
    t_abc.loc[t_abc['brkr_cnt']>=2, 'flg_brkr_cnt_gt2'] = 1
    t_abc['flg_brkr_cnt_gt2'] = t_abc['flg_brkr_cnt_gt2'].fillna(0)
    
    c_tdate_cnt = t_abc['DataDate'].nunique()
    s_abc_t3m_2 = t_abc.groupby('Ticker')[['flg_brkr_cnt_gt1', 'flg_brkr_cnt_gt2']].apply(lambda x: x.sum()/c_tdate_cnt).reset_index()
    s_abc_t3m_2 = s_abc_t3m_2.rename(columns={'flg_brkr_cnt_gt1':'pct_lt1_broker_3m', 'flg_brkr_cnt_gt2':'pct_lt2_broker_3m'})
    
    s_stable_tk = s_abc_t3m_1.merge(s_abc_t3m_2,on='Ticker',how='outer')
    s_stable_tk = s_stable_tk.merge(s_abc_tdy[['Ticker','total_avail_amount','total_avail_dollar','amount_weighted_rate']],on='Ticker',how='outer')
    s_stable_tk['DataDate'] = dt
    s_stable_tk = s_stable_tk[['Ticker', 'DataDate', 'amount_weighted_rate_3m',
                               'average_amount_3m', 'average_avail_dollar_3m', 'average_avail_dollar_3m_per_clip',
                               'pct_lt1_broker_3m', 'pct_lt2_broker_3m']]
    
    o_stable_tk.append(s_stable_tk)
    
    
o_stable_tk = pd.concat(o_stable_tk, axis = 0)

o_stable_tk.to_csv(r'S:\Data\China Data Hunt\cache\test.csv', index = False)


'''
create table MLP_CN_ETBList_stable_stock_v2 (
Ticker varchar(max), DataDate datetime,  amount_weighted_rate_3m float,
average_amount_3m float, average_avail_dollar_3m float, average_avail_dollar_3m_per_clip float,
pct_lt1_broker_3m float, pct_lt2_broker_3m float)
bcp [CNDBDEV].[dbo].[MLP_CN_ETBList_stable_stock] in "S:\Data\China Data Hunt\cache\test.csv" -c -t  , -S summitsqldb -U AD\thzhang -T -F 2 -e "S:\Data\China Data Hunt\cache\error.txt"
'''

