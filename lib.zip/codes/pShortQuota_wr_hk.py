﻿#$%^&* pShortQuota_wr_hk.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 10 14:55:25 2022

@author: thzhang
"""


import pWIND_util as pw
import yz.util as yu

import pandas as pd
import numpy as np

import matplotlib.pyplot as plt


# source: \\ad\dfs\botraders\alltraders\China_Avail

# next: different ways to identify "sudden increase"
# any other metrics?
# holding positions for longer periods?
# also explore rate 


### |-- Ashare universe

i_uni = yu.get_sql('''select datadate as datadate_p1d, ticker
                   from [CNDBPROD].[dbo].[BARRA_GEM3L_CN_FORMAT]
                   where datadate >= '20180101'
                   ''')
i_uni = i_uni.sort_values(['ticker','datadate_p1d'])
c_sh = i_uni.ticker.str[0].isin(['6'])
c_sz = i_uni.ticker.str[0].isin(['0','3'])
i_uni.loc[c_sh, 'ticker'] = i_uni.loc[c_sh, 'ticker'] + '.SH'
i_uni.loc[c_sz, 'ticker'] = i_uni.loc[c_sz, 'ticker'] + '.SZ'


### |-- o2o return

i_o2o = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate_p1d,
                 s_dq_adjopen as o
                 from wind_prod.dbo.ashareeodprices
                 where trade_dt >= '20180101' ''')
i_o2o['datadate_p1d'] = pd.to_datetime(i_o2o['datadate_p1d'], format = '%Y%m%d')
i_o2o = i_o2o.sort_values(['ticker', 'datadate_p1d']).reset_index(drop=True)
i_o2o['o_1d'] = i_o2o.groupby('ticker')['o'].shift()
i_o2o['o2oret'] = i_o2o['o'] / i_o2o['o_1d'] - 1
i_o2o['o2oret+0d'] = i_o2o.groupby('ticker')['o2oret'].shift(-1)
i_o2o['o2oret+01d'] = i_o2o['o2oret+0d'] + i_o2o.groupby('ticker')['o2oret'].shift(-2)
i_o2o['o2oret+02d'] = i_o2o['o2oret+0d'] + i_o2o.groupby('ticker')['o2oret'].shift(-3)
i_o2o['o2oret+03d'] = i_o2o['o2oret+0d'] + i_o2o.groupby('ticker')['o2oret'].shift(-4)
i_o2o['o2oret+04d'] = i_o2o['o2oret+0d'] + i_o2o.groupby('ticker')['o2oret'].shift(-5)
i_o2o['o2oret-1d'] = i_o2o['o2oret']
i_o2o = i_o2o[['ticker', 'datadate_p1d', 'o2oret+01d','o2oret+04d','o2oret+0d', 'o2oret-1d']]


### |-- c

i_c = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                 s_dq_close as c, s_dq_adjclose / s_dq_adjpreclose - 1 as c2c
                 from wind_prod.dbo.ashareeodprices
                 where trade_dt >= '20180101' ''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format = '%Y%m%d')
i_c = i_c.sort_values(['ticker', 'datadate'])
i_c['c2c_t5d'] = i_c.groupby('ticker').rolling(5)['c2c'].mean().values
i_c['c2c_t20d'] = i_c.groupby('ticker').rolling(20)['c2c'].mean().values
i_c['c_ma
x1y'] = i_c.groupby('ticker').rolling(252)['c'].max().values
i_c['c_min1y'] = i_c.groupby('ticker').rolling(252)['c'].min().values
i_c['c_hlidx'] = (i_c['c'] - i_c['c_min1y']) / (i_c['c_max1y'] - i_c['c_min1y'])
i_c = i_c.sort_values('datadate')


### |-- pastret

i_pastret = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet',
                            columns = ['ticker', 'datadate', 'twap1000_2c_bret', 'twap1000_2c_bret_t4w'])
i_pastret = i_pastret.sort_values(['datadate'])




### |-- Float

i_guben = pw.get_wind_float()
i_guben = i_guben.sort_values('datadate')



#### |- PV

i_pv = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                 s_dq_amount*1000 as amt 
                 from wind_prod.dbo.ashareeodprices
                 where trade_dt >= '2018-01-01' 
                 order by s_info_windcode, trade_dt ''')
i_pv['datadate'] = pd.to_datetime(i_pv['datadate'], format = '%Y%m%d')
i_pv['avgPV'] = i_pv.groupby('ticker').rolling(20)['amt'].mean().values
i_pv = i_pv.sort_values('datadate')


### |-- CSI500 index futures

i_500 = pd.read_excel(r'\\vfudat04\udat04\thzhang\Downloads\510500.xlsx')
i_500 = i_500.sort_values('Date')
i_500['o2o500ret'] = i_500['Open'] / i_500['Open'].shift() - 1
i_500['datadate_p1d'] = i_500['Date']
i_500['o2o500ret+0d'] = i_500['o2o500ret'].shift(-1)
i_500 = i_500[['datadate_p1d', 'o2o500ret+0d']]


### |-- hk total holding

i_h_gs = pd.read_parquet(r'S:\Data\China Data Hunt\cache\prepare_northbound_holding_bb.parquet')
i_h_gs = i_h_gs[i_h_gs['s_holder_num'] == 'B01451'] # gs
i_h_gs = i_h_gs.rename(columns = {'bb_shares':'bb_gs_shares'})
i_h_gs = i_h_gs[['datadate_p1d','ticker','bb_gs_shares']]

i_h_ms = pd.read_parquet(r'S:\Data\China Data Hunt\cache\prepare_northbound_holding_bb.parquet')
i_h_ms = i_h_ms[i_h_ms['s_holder_num'] == 'B01274'] # ms
i_h_ms = i_h_ms.rename(columns = {'bb_shares':'bb_ms_shares'})
i_h_ms = i_h_ms[['datadate_p1d','ticker','bb_ms_shares']]


### |-- hk calendar

i_hk_cal = yu.get_sql('''select distinct tradedate_next as datadate_p1d
                      from [CNDBPROD].[dbo].[Calendar_Dates_HC]''')


### ETB gs

i_etb_gs = yu.get_sql('''select datadate as datadate_p1d, ric, avail_amount_gs, rate_gs                    
                   from [CNDBPROD].[dbo].[MLP_CN_ETBList_ABC_RIC] 
                   ''')
i_etb_gs['ticker_6d'] = i_etb_gs['ric'].str[:6]
i_etb_gs.loc[i_etb_gs['ric'].str[-2:].isin(['SS', 'SZ']), 'mkt'] = 'onsh
ore'
i_etb_gs.loc[i_etb_gs['ric'].str[-2:].isin(['SH', 'ZK']), 'mkt'] = 'offshore'

i_etb_gs = i_etb_gs.groupby(['ticker_6d','mkt','datadate_p1d'])['avail_amount_gs'].sum().reset_index()
i_etb_gs = i_etb_gs.pivot_table(index=['ticker_6d', 'datadate_p1d'], columns = 'mkt', values = 'avail_amount_gs')
i_etb_gs = i_etb_gs.rename(columns={'offshore':'gs_off_shares', 'onshore':'gs_on_shares'})
i_etb_gs = i_etb_gs.reset_index()

c_sh = i_etb_gs['ticker_6d'].str[0].isin(['6'])
c_sz = i_etb_gs['ticker_6d'].str[0].isin(['0','3'])
i_etb_gs.loc[c_sh, 'ticker'] = i_etb_gs.loc[c_sh, 'ticker_6d'] + '.SH'
i_etb_gs.loc[c_sz, 'ticker'] = i_etb_gs.loc[c_sz, 'ticker_6d'] + '.SZ'
i_etb_gs = i_etb_gs[i_etb_gs['ticker'].notnull()]

# merge other data into ETB

i_etb_gs = i_etb_gs.sort_values('datadate_p1d')
i_etb_gs = pd.merge_asof(i_etb_gs, i_guben[['ticker', 'datadate', 'float_guben']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m']) ###??? how about freefloat_guben here?
i_etb_gs = i_etb_gs.drop(columns = 'datadate')
i_etb_gs = pd.merge_asof(i_etb_gs, i_c[['ticker', 'datadate', 'c', 'c2c', 'c2c_t5d', 'c2c_t20d','c_hlidx']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_gs = i_etb_gs.drop(columns = 'datadate')
i_etb_gs = pd.merge_asof(i_etb_gs, i_pv[['ticker', 'datadate', 'avgPV']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_gs = i_etb_gs.drop(columns = 'datadate')

i_etb_gs = i_etb_gs.merge(i_h_gs, on = ['ticker', 'datadate_p1d'], how = 'left')

i_etb_gs['gs_off_pctFloat'] = i_etb_gs['gs_off_shares'] / i_etb_gs['float_guben']
i_etb_gs['gs_on_pctFloat'] = i_etb_gs['gs_on_shares'] / i_etb_gs['float_guben']
i_etb_gs['gs_off_rmb'] = i_etb_gs['gs_off_shares']  * i_etb_gs['c'] 
i_etb_gs['gs_off_rmb'] = i_etb_gs['gs_off_rmb'].fillna(0)
i_etb_gs['gs_on_rmb'] = i_etb_gs['gs_on_shares']  * i_etb_gs['c'] 
i_etb_gs['gs_on_rmb'] = i_etb_gs['gs_on_rmb'].fillna(0)

i_etb_gs['gs_off_rmb_1d'] = i_etb_gs.groupby('ticker')['gs_off_rmb'].shift(1)
i_etb_gs['gs_off_rmb_2d'] = i_etb_gs.groupby('ticker')['gs_off_rmb'].shift(2)
i_etb_gs['gs_off_rmb_3d'] = i_etb_gs.groupby('ticker')['gs_off_rmb'].shift(3)
i_etb_gs['gs_off_rmb_4d'] = i_etb_gs.groupby('tick
er')['gs_off_rmb'].shift(4)
i_etb_gs['gs_off_rmb_5d'] = i_etb_gs.groupby('ticker')['gs_off_rmb'].shift(5)
i_etb_gs['gs_off_rmb_7d'] = i_etb_gs.groupby('ticker')['gs_off_rmb'].shift(7)
i_etb_gs['gs_off_rmb_9d'] = i_etb_gs.groupby('ticker')['gs_off_rmb'].shift(9)
i_etb_gs['avgPV_1d'] = i_etb_gs.groupby('ticker')['avgPV'].shift(1)
i_etb_gs['avgPV_2d'] = i_etb_gs.groupby('ticker')['avgPV'].shift(2)
i_etb_gs['avgPV_3d'] = i_etb_gs.groupby('ticker')['avgPV'].shift(3)
i_etb_gs['avgPV_4d'] = i_etb_gs.groupby('ticker')['avgPV'].shift(4)
i_etb_gs['avgPV_5d'] = i_etb_gs.groupby('ticker')['avgPV'].shift(5)
i_etb_gs['avgPV_7d'] = i_etb_gs.groupby('ticker')['avgPV'].shift(7)
i_etb_gs['avgPV_9d'] = i_etb_gs.groupby('ticker')['avgPV'].shift(9)


# calculate flags

i_etb_gs = i_etb_gs.sort_values(['ticker', 'datadate_p1d'])

i_etb_gs['flg_gs_appear'] = np.nan
c1 = (i_etb_gs['gs_off_rmb_1d'] == 0) & (i_etb_gs['gs_off_rmb_2d'] == 0) \
     & (i_etb_gs['gs_off_rmb_3d'] == 0) & (i_etb_gs['gs_off_rmb_4d'] == 0) \
     & (i_etb_gs['gs_off_rmb_5d'] == 0)
i_etb_gs.loc[(i_etb_gs['gs_off_rmb']>5e6)&c1, 'flg_gs_appear'] = 1

i_etb_gs['flg_gs_appear2'] = np.nan
c1 = (i_etb_gs['gs_off_rmb_1d'] == 0) & (i_etb_gs['gs_off_rmb_2d'] == 0) \
     & (i_etb_gs['gs_off_rmb_3d'] == 0) & (i_etb_gs['gs_off_rmb_4d'] == 0) \
     & (i_etb_gs['gs_off_rmb_5d'] == 0)
i_etb_gs.loc[(i_etb_gs['gs_off_rmb'] / i_etb_gs['avgPV'] > 0.05)&c1, 'flg_gs_appear2'] = 1

i_etb_gs['flg_gs_appear2n'] = np.nan
c1 = (i_etb_gs['gs_off_rmb_1d'] == 0) & (i_etb_gs['gs_off_rmb_2d'] == 0) \
     & (i_etb_gs['gs_off_rmb_3d'] == 0) & (i_etb_gs['gs_off_rmb_4d'] == 0) \
     & (i_etb_gs['gs_off_rmb_5d'] == 0)
i_etb_gs.loc[(i_etb_gs['gs_on_rmb'] / i_etb_gs['avgPV'] > 0.05)&c1, 'flg_gs_appear2n'] = 1

i_etb_gs['flg_gs_appear3'] = np.nan
c1 = (i_etb_gs['gs_off_rmb_1d'] == 0) & (i_etb_gs['gs_off_rmb_2d'] == 0) \
     & (i_etb_gs['gs_off_rmb_3d'] == 0) & (i_etb_gs['gs_off_rmb_4d'] == 0) \
     & (i_etb_gs['gs_off_rmb_5d'] == 0)
i_etb_gs.loc[((i_etb_gs['gs_off_rmb'] / i_etb_gs['avgPV'] > 0.05)|(i_etb_gs['gs_off_rmb']>5e6))\
             & c1, 'flg_gs_appear3'] = 1
             
i_etb_gs['flg_gs_appear4'] = np.nan
c1 = (i_etb_gs['gs_off_rmb_1d'] == 0) & (i_etb_gs['gs_off_rmb_2d'] == 0) \
     & (i_etb_gs['gs_off_rmb_3d'] == 0) & (i_etb_gs['gs_off_rmb_4d'] == 0) \
     & (i_etb_gs['gs_off_rmb_5d'] == 0)
c2 = (i_etb_gs['gs_off_rmb'] / i_etb_gs['avgPV'] > 0.05) | (i_etb_gs['gs_off_rmb']>5e6)
i_etb_gs.loc[c1 & c2 , 'flg_gs_appear4'] = 1


f
or i in [1,2,3]:
    c1 = i_etb_gs.groupby('ticker')['flg_gs_appear4'].shift()==1
    c2 = (i_etb_gs['gs_off_rmb'] / i_etb_gs['avgPV'] > 0.05) | (i_etb_gs['gs_off_rmb']>5e6)
    i_etb_gs.loc[c1 & c2 , 'flg_gs_appear4'] = 1










### ETB ms

i_etb_ms = yu.get_sql('''select datadate as datadate_p1d, ric, avail_amount_ms, rate_ms                    
                   from [CNDBPROD].[dbo].[MLP_CN_ETBList_ABC_RIC] 
                   ''')
i_etb_ms['ticker_6d'] = i_etb_ms['ric'].str[:6]
i_etb_ms.loc[i_etb_ms['ric'].str[-2:].isin(['SS', 'SZ']), 'mkt'] = 'onshore'
i_etb_ms.loc[i_etb_ms['ric'].str[-2:].isin(['SH', 'ZK']), 'mkt'] = 'offshore'

i_etb_ms = i_etb_ms.groupby(['ticker_6d','mkt','datadate_p1d'])['avail_amount_ms'].sum().reset_index()
i_etb_ms = i_etb_ms.pivot_table(index=['ticker_6d', 'datadate_p1d'], columns = 'mkt', values = 'avail_amount_ms')
i_etb_ms = i_etb_ms.rename(columns={'offshore':'ms_off_shares', 'onshore':'ms_on_shares'})
i_etb_ms = i_etb_ms.reset_index()

c_sh = i_etb_ms['ticker_6d'].str[0].isin(['6'])
c_sz = i_etb_ms['ticker_6d'].str[0].isin(['0','3'])
i_etb_ms.loc[c_sh, 'ticker'] = i_etb_ms.loc[c_sh, 'ticker_6d'] + '.SH'
i_etb_ms.loc[c_sz, 'ticker'] = i_etb_ms.loc[c_sz, 'ticker_6d'] + '.SZ'

# merge other data into ETB

i_etb_ms = i_etb_ms.sort_values('datadate_p1d')
i_etb_ms = pd.merge_asof(i_etb_ms, i_guben[['ticker', 'datadate', 'float_guben']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m']) ###??? how about freefloat_guben here?
i_etb_ms = i_etb_ms.drop(columns = 'datadate')
i_etb_ms = pd.merge_asof(i_etb_ms, i_c[['ticker', 'datadate', 'c']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_ms = i_etb_ms.drop(columns = 'datadate')
i_etb_ms = pd.merge_asof(i_etb_ms, i_pv[['ticker', 'datadate', 'avgPV']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_ms = i_etb_ms.drop(columns = 'datadate')

i_etb_ms['ms_off_pctFloat'] = i_etb_ms['ms_off_shares'] / i_etb_ms['float_guben']
i_etb_ms['ms_on_pctFloat'] = i_etb_ms['ms_on_shares'] / i_etb_ms['float_guben']
i_etb_ms['ms_off_rmb'] = i_etb_ms['ms_off_shares']  * i_etb_ms['c'] 
i_etb_ms['ms_off_rmb'] = i_etb_ms['ms_off_rmb'].fillna(0)
i_etb_ms['ms_on_
rmb'] = i_etb_ms['ms_on_shares']  * i_etb_ms['c'] 
i_etb_ms['ms_on_rmb'] = i_etb_ms['ms_on_rmb'].fillna(0)

# calculate flags

i_etb_ms = i_etb_ms.sort_values(['ticker', 'datadate_p1d'])

i_etb_ms['flg_ms_appear'] = np.nan
c1 = (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(1) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(2) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(3) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(4) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(5) == 0)
i_etb_ms.loc[(i_etb_ms['ms_off_rmb']>5e6)&c1, 'flg_ms_appear'] = 1

i_etb_ms['flg_ms_appear2'] = np.nan
c1 = (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(1) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(2) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(3) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(4) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(5) == 0)
i_etb_ms.loc[(i_etb_ms['ms_off_rmb'] / i_etb_ms['avgPV'] > 0.05)&c1, 'flg_ms_appear2'] = 1

i_etb_ms['flg_ms_appear2n'] = np.nan
c1 = (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(1) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(2) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(3) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(4) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(5) == 0)
i_etb_ms.loc[(i_etb_ms['ms_on_rmb'] / i_etb_ms['avgPV'] > 0.05)&c1, 'flg_ms_appear2n'] = 1

i_etb_ms['flg_ms_appear3'] = np.nan
c1 = (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(1) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(2) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(3) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(4) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(5) == 0)
i_etb_ms.loc[((i_etb_ms['ms_off_rmb'] / i_etb_ms['avgPV'] > 0.05)|(i_etb_ms['ms_off_rmb']>5e6))\
             & c1, 'flg_ms_appear3'] = 1


i_etb_ms = i_etb_ms[['ticker','datadate_p1d','flg_ms_appear','flg_ms_appear2','flg_ms_appear2n','flg_ms_appear3']]






### ETB jpm

i_etb_jpm = yu.get_sql('''select datadate as datadate_p1d, ric, avail_amount_jpm, rate_jpm                    
                   from [CNDBPROD].[dbo].[MLP_CN_ETBList_ABC_RIC] 
                   ''')
i_etb_jpm['ticker_6d'] = i_etb_jpm['ric'].str[:6]
i_etb_jpm.loc[i_etb_jpm['ric'].str[-2:].isin(['SS', 'SZ']), 'mkt'] = 'onshore'
i_etb_j
pm.loc[i_etb_jpm['ric'].str[-2:].isin(['SH', 'ZK']), 'mkt'] = 'offshore'

i_etb_jpm = i_etb_jpm.groupby(['ticker_6d','mkt','datadate_p1d'])['avail_amount_jpm'].sum().reset_index()
i_etb_jpm = i_etb_jpm.pivot_table(index=['ticker_6d', 'datadate_p1d'], columns = 'mkt', values = 'avail_amount_jpm')
i_etb_jpm = i_etb_jpm.rename(columns={'offshore':'jpm_off_shares', 'onshore':'jpm_on_shares'})
i_etb_jpm = i_etb_jpm.reset_index()

c_sh = i_etb_jpm['ticker_6d'].str[0].isin(['6'])
c_sz = i_etb_jpm['ticker_6d'].str[0].isin(['0','3'])
i_etb_jpm.loc[c_sh, 'ticker'] = i_etb_jpm.loc[c_sh, 'ticker_6d'] + '.SH'
i_etb_jpm.loc[c_sz, 'ticker'] = i_etb_jpm.loc[c_sz, 'ticker_6d'] + '.SZ'

# merge other data into ETB

i_etb_jpm = i_etb_jpm.sort_values('datadate_p1d')
i_etb_jpm = pd.merge_asof(i_etb_jpm, i_guben[['ticker', 'datadate', 'float_guben']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m']) ###??? how about freefloat_guben here?
i_etb_jpm = i_etb_jpm.drop(columns = 'datadate')
i_etb_jpm = pd.merge_asof(i_etb_jpm, i_c[['ticker', 'datadate', 'c']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_jpm = i_etb_jpm.drop(columns = 'datadate')
i_etb_jpm = pd.merge_asof(i_etb_jpm, i_pv[['ticker', 'datadate', 'avgPV']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_jpm = i_etb_jpm.drop(columns = 'datadate')

i_etb_jpm['jpm_off_pctFloat'] = i_etb_jpm['jpm_off_shares'] / i_etb_jpm['float_guben']
i_etb_jpm['jpm_on_pctFloat'] = i_etb_jpm['jpm_on_shares'] / i_etb_jpm['float_guben']
i_etb_jpm['jpm_off_rmb'] = i_etb_jpm['jpm_off_shares']  * i_etb_jpm['c'] 
i_etb_jpm['jpm_off_rmb'] = i_etb_jpm['jpm_off_rmb'].fillna(0)
i_etb_jpm['jpm_on_rmb'] = i_etb_jpm['jpm_on_shares']  * i_etb_jpm['c'] 
i_etb_jpm['jpm_on_rmb'] = i_etb_jpm['jpm_on_rmb'].fillna(0)

# calculate flags

i_etb_jpm = i_etb_jpm.sort_values(['ticker', 'datadate_p1d'])

i_etb_jpm['flg_jpm_appear'] = np.nan
c1 = (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(1) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(2) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(3) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(4) == 0) \
     & (i_etb_jpm
.groupby('ticker')['jpm_off_rmb'].shift(5) == 0)
i_etb_jpm.loc[(i_etb_jpm['jpm_off_rmb']>5e6)&c1, 'flg_jpm_appear'] = 1

i_etb_jpm['flg_jpm_appear2'] = np.nan
c1 = (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(1) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(2) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(3) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(4) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(5) == 0)
i_etb_jpm.loc[(i_etb_jpm['jpm_off_rmb'] / i_etb_jpm['avgPV'] > 0.05)&c1, 'flg_jpm_appear2'] = 1

i_etb_jpm['flg_jpm_appear2n'] = np.nan
c1 = (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(1) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(2) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(3) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(4) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(5) == 0)
i_etb_jpm.loc[(i_etb_jpm['jpm_on_rmb'] / i_etb_jpm['avgPV'] > 0.05)&c1, 'flg_jpm_appear2n'] = 1

i_etb_jpm['flg_jpm_appear3'] = np.nan
c1 = (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(1) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(2) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(3) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(4) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(5) == 0)
i_etb_jpm.loc[((i_etb_jpm['jpm_off_rmb'] / i_etb_jpm['avgPV'] > 0.05)|(i_etb_jpm['jpm_off_rmb']>5e6))\
             & c1, 'flg_jpm_appear3'] = 1


i_etb_jpm = i_etb_jpm[['ticker','datadate_p1d','flg_jpm_appear','flg_jpm_appear2','flg_jpm_appear2n','flg_jpm_appear3']]





#------------------------------------------------------------------------------
### bt  
#------------------------------------------------------------------------------


def bt_wr(df, str_col_date, str_col_sgnl, str_col_ret):
    # this tests long-only equal-weighted signals
    
    CAPITAL = 1e6
    LMT=4e5
    
    # calculate pstD
    
    df_daily_signals = df.groupby(str_col_date)[str_col_sgnl].sum().reset_index()
    df_daily_signals.columns = [str_col_date, 'daily_sgnl_cnt']
    df = df.merge(df_daily_signals, on=str_col_date, how='left')
    
    df['pstD'] = CAPITAL / df['daily_sgnl_cnt'] * df[str_col_sgnl]
    df.loc[df['pstD']>LMT,'pstD'] = LMT
    
    #
    
    s = df.sort_values(str_col_date)
    s = s.reset_index(drop=True)
    
    spos = s.pivot_table(index='
ticker',columns=[str_col_date], values='pstD')
    spos = spos.fillna(0)
    spos = spos.unstack()
    spos = spos.reset_index()
    spos = spos.rename(columns={0:'pos'})
    spos = spos.sort_values(['ticker',str_col_date])
    spos['pos_pre'] = spos.groupby(['ticker'])['pos'].shift(1)
    spos = spos.fillna(0)
    spos = spos[ ~((spos['pos']==0) & (spos['pos_pre']==0))   ]
    spos['trdd'] = spos['pos'] - spos['pos_pre']
    spos['abstrdd'] = abs(spos['trdd'])
    spos['gmv'] = abs(spos['pos'])
        
    c_b = spos['trdd']>=0
    spos.loc[c_b, 'cost'] = spos.loc[c_b, 'abstrdd'] * (0.00025+0.00002)
    c_s = spos['trdd']<0
    spos.loc[c_s, 'cost'] = spos.loc[c_s, 'abstrdd'] * (0.001+0.00025+0.00002)
    
    spos = spos.merge(df[['ticker', str_col_date, str_col_ret]], on = ['ticker', str_col_date], how = 'left')
    spos['pnl_bc'] = spos['pos'] * spos[str_col_ret] 
    spos['pnl_ac'] = spos['pnl_bc'] - spos['cost']    
    
    ret = spos.groupby(str_col_date)['pnl_bc','pnl_ac'].sum()
    ret = ret.reset_index()
    ret = ret.dropna()
    ret['cumpnl_bc'] = ret['pnl_bc'].cumsum()
    ret['cumpnl_ac'] = ret['pnl_ac'].cumsum()
        
    sr_pnl_bc = np.round(ret['pnl_bc'].mean() / ret['pnl_bc'].std() * np.sqrt(252),2)
    sr_pnl_ac = np.round(ret['pnl_ac'].mean() / ret['pnl_ac'].std() * np.sqrt(252),2)

    mean_ret_bc = np.round( (spos['pnl_bc'].sum() / spos['gmv'].sum())*1e4,2)
    mean_ret_ac = np.round( (spos['pnl_ac'].sum() / spos['gmv'].sum())*1e4,2)
    
    ept = np.round( (spos['pnl_bc'].sum() / spos['abstrdd'].sum())*1e4,2)
    
    ret = ret.set_index(str_col_date)
    
    # plot
    
    fig1 = plt.figure(figsize=(20,4))
    ax1 = fig1.add_subplot(121)
    ax1.plot(ret['cumpnl_bc'])
    ax1.plot(ret['cumpnl_ac'])

    ax1.grid()
    ax1.set_ylabel('PNL', fontsize = 16)
    ax1.set_xlabel('Date',fontsize = 16)
    
    ax1.text(0.01, 0.87, 'Annualized Sharpe: ' + str(sr_pnl_bc) + '(bc), ' +  str(sr_pnl_ac) + ' (ac) ', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.81, 'Daily Return on GMV: ' + str(mean_ret_bc) + ' bps (bc), ' + str(mean_ret_ac) + ' bps (ac)', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.75, 'Edge Per Trade: ' + str(ept) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    
spos_gmvret = spos.groupby(str_col_date)[['pnl_ac','gmv']].sum()
    spos_gmvret_number = spos_gmvret['pnl_ac'].sum() / spos_gmvret[spos_gmvret['gmv']>0]['gmv'].mean() / len(spos_gmvret) * 252
    spos_gmvret_number = round(spos_gmvret_number*100,2)
    ax1.text(0.01, 0.57, 'GMV Ret: ' + str(spos_gmvret_number) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    
    
    gmvlong = spos[ spos['pos'] > 0].groupby(str_col_date)['gmv'].sum()
    gmvlong = gmvlong.reset_index()
    gmvlong.columns = [str_col_date,'long']
    gmvlong = gmvlong.set_index(str_col_date)
    gmvshort = spos[ spos['pos'] < 0].groupby(str_col_date)['gmv'].sum()
    gmvshort = gmvshort.reset_index()
    gmvshort.columns = [str_col_date,'short']
    gmvshort = gmvshort.set_index(str_col_date)
    
    ax2 = fig1.add_subplot(122)
    gmv = pd.concat([gmvlong,gmvshort],axis=1)
    ax2.plot(gmv)
    
    ax2.grid()
    ax2.set_ylabel('GMV', fontsize = 16)
    ax2.set_xlabel('Date',fontsize = 16)
    
    totgmv = spos.groupby(str_col_date)['gmv'].sum().mean()    
    to = np.round(spos['abstrdd'].sum() / spos['gmv'].sum() * 100)
    
    ax2.text(0.01, 0.93, 'Avg Long Size: ' + str(np.round(gmvlong['long'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.87, 'Avg Short Size: ' + str(np.round(gmvshort['short'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.81, 'Total Size: ' + str(np.round(totgmv/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.75, 'Turnover: ' + str(to) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    
    
    
    return spos



#------------------------------------------------------------------------------
### combine 
#------------------------------------------------------------------------------

icom = i_etb_gs.merge(i_o2o,  on = ['datadate_p1d','ticker'], how='left')
icom = icom.merge(i_etb_ms,  on = ['datadate_p1d','ticker'], how='left')
icom = icom.merge(i_etb_jpm,  on = ['datadate_p1d','ticker'], how='left')
icom = icom.merge(i_500, on = 'datadate_p1d', how = 'left')
icom['o2ohedgeret+0d'] = icom['o2
oret+0d'] - icom['o2o500ret+0d']
icom = icom.sort_values('datadate_p1d')
icom = pd.merge_asof(icom, i_pastret, by='ticker', left_on='datadate_p1d',right_on='datadate',
                     allow_exact_matches = False, suffixes=['','_m'])
icom = icom.drop(columns = 'datadate')
icom = icom.sort_values(['ticker', 'datadate_p1d'])


icom = icom.merge(i_300500[['ticker','datadate_p1d','cn_index']],on=['ticker','datadate_p1d'],how='left')
#icom['avgPV_rk'] = icom.groupby('datadate_p1d')['avgPV'].apply(yu.uniformed_rank)


# sgnl

icom['sgnl_appear'] = np.nan
icom.loc[(icom['flg_gs_appear']==1)&(icom['twap1000_2c_bret']<0), 'sgnl_appear'] = 1

icom['sgnl_appear2'] = np.nan
icom.loc[(icom['flg_gs_appear']==1)&(icom['twap1000_2c_bret_t4w']<0), 'sgnl_appear2'] = 1

icom['sgnl_appear3'] = np.nan
icom.loc[(icom['flg_gs_appear']==1)&(icom['twap1000_2c_bret_t4w']<0)&(icom['twap1000_2c_bret']<0), 'sgnl_appear3'] = 1

icom['sgnl_appear4'] = np.nan
icom.loc[(icom['flg_gs_appear2']==1)&(icom['twap1000_2c_bret_t4w']<0)&(icom['twap1000_2c_bret']<0), 'sgnl_appear4'] = 1

icom['sgnl_appear4n'] = np.nan
icom.loc[(icom['flg_gs_appear2n']==1)&(icom['twap1000_2c_bret_t4w']<0)&(icom['twap1000_2c_bret']<0), 'sgnl_appear4n'] = 1

icom['sgnl_appear5'] = np.nan
icom.loc[(icom['flg_gs_appear3']==1)&(icom['bb_gs_shares']>0)&(icom['twap1000_2c_bret_t4w']<0)&(icom['twap1000_2c_bret']<0), 'sgnl_appear5'] = 1

icom['sgnl_appear5b'] = np.nan
icom.loc[(icom['flg_gs_appear3']==1)&(icom['twap1000_2c_bret_t4w']<0)&(icom['c_hlidx']>0.5)&(icom['twap1000_2c_bret']<0), 'sgnl_appear5b'] = 1

icom['sgnl_appear5c'] = np.nan
icom.loc[(icom.groupby('ticker')['sgnl_appear5b'].shift()==1)&((i_etb_gs['gs_off_rmb'] / i_etb_gs['avgPV'] > 0.05)), 'sgnl_appear5c'] = 1


icom['sgnl_appear6'] = np.nan
icom.loc[(icom['flg_gs_appear4']==1)&(icom['twap1000_2c_bret_t4w']<0)&(icom['twap1000_2c_bret']<0), 'sgnl_appear6'] = 1

icom['sgnl_appear4'] = np.nan
icom.loc[(icom['flg_gs_appear4']==1), 'sgnl_appear4'] = 1



icom['sgnl_ms_appear3'] = np.nan
icom.loc[(icom['flg_ms_appear']==1)&(icom['twap1000_2c_bret_t4w']<0)&(icom['twap1000_2c_bret']<0), 'sgnl_ms_appear3'] = 1

icom['sgnl_ms_appear4'] = np.nan
icom.loc[(icom['flg_ms_appear2']==1)&(icom['twap1000_2c_bret_t4w']<0)&(icom['twap1000_2c_bret']<0), 'sgnl_ms_appear4'] = 1

icom['sgnl_ms_appear4n'] = np.nan
icom.loc[(icom['flg_ms_appear2n']==1)&(icom['twap1000_2c_bret_t4w']<0)&(icom['twap1000_2c_bret']<0), 'sgnl_ms_appear4n'] = 1

icom['sgnl_ms_appear5'] = np.nan
icom.loc[
(icom['flg_ms_appear3']==1)&(icom['twap1000_2c_bret_t4w']<0)&(icom['twap1000_2c_bret']<0), 'sgnl_ms_appear5'] = 1


icom['sgnl_jpm_appear4'] = np.nan
icom.loc[(icom['flg_jpm_appear2']==1)&(icom['twap1000_2c_bret_t4w']<0)&(icom['twap1000_2c_bret']<0), 'sgnl_jpm_appear4'] = 1

icom['sgnl_jpm_appear4n'] = np.nan
icom.loc[(icom['flg_jpm_appear2n']==1)&(icom['twap1000_2c_bret_t4w']<0)&(icom['twap1000_2c_bret']<0), 'sgnl_jpm_appear4n'] = 1


icom['sgnl_all_appear4'] = icom['sgnl_ms_appear4']
c1 = icom['sgnl_all_appear4'].isnull()
icom.loc[c1, 'sgnl_all_appear4'] = icom.loc[c1, 'sgnl_appear4']
c1 = icom['sgnl_all_appear4'].isnull()
icom.loc[c1, 'sgnl_all_appear4'] = icom.loc[c1, 'sgnl_jpm_appear4']


o_1 = bt_wr(icom, 'datadate_p1d', 'flg_appear', 'o2oret+0d')
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_appear', 'o2oret+0d') # 1.95 / 1.03
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_appear', 'o2ohedgeret+0d') # 1.62 /0.52
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_appear2', 'o2oret+0d') # 2.16 / 1.19
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_appear3', 'o2oret+0d') # 2.6 / 1.64
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_appear3', 'o2ohedgeret+0d') # 1.9 / 0.74
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_appear4', 'o2oret+0d') # 2.04 / 1.14
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_appear4n', 'o2oret+0d') # 0.81 / 0.06 <- 2021.11 ONWARDS ONLY
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_appear5', 'o2oret+0d') # 2.4 / 1.43
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_appear5b', 'o2oret+0d') # 2.8 / 2.3
o_1 = bt_wr(icom[icom.cn_index.notnull()], 'datadate_p1d', 'sgnl_appear5b', 'o2oret+0d') #4.04 / 3.24 ###!!!
o_1 = bt_wr(icom[icom.cn_index.notnull() & (icom.cn_index!='NaN')], 'datadate_p1d', 'sgnl_appear5b', 'o2oret+0d') # 4.24 / 3.5
o_1 = bt_wr(icom[icom.cn_index.notnull() & (icom.cn_index!='NaN')], 'datadate_p1d', 'sgnl_appear5c', 'o2oret+0d') # losing money on the 2nd day ....




o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_appear6', 'o2oret+0d')
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_ms_appear3', 'o2oret+0d') # 0.54 - 0.37
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_ms_appear4', 'o2oret+0d') # 3.34 / 2.48
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_ms_appear4n', 'o2oret+0d') # 1.48 / 0.48 <- 2020.11 ONWARDS ONLY
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_ms_appear5', 'o2oret+0d') # 0.87 / -0.05
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_jpm_appear4', 'o2oret+0d') # 4.77 / 3.62
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_jpm_appear4n', 'o2oret+0d') # 0.52 / 0.45 <- 2020.11 ONWARDS ONLY

o_1 = bt_wr(icom, 'datadate_p
1d', 'sgnl_all_appear4', 'o2oret+0d') # 3.0 / 2.15





# inspection

t2 = icom[(icom['datadate_p1d']=='2022-08-05') & (icom['sgnl_all_appear4']==1)]
o_1.groupby('ticker')['pnl_ac'].sum().sort_values().head(5)
o_1[o_1.ticker=='300782.SZ'].set_index('datadate_p1d')['pnl_ac'].cumsum().plot()
t1 = icom[icom.ticker=='300014.SZ']

i_300500 = pw.get_ashare_t2000_sd()




#------------------------------------------------------------------------------
### stat studies 
#------------------------------------------------------------------------------


i_etb_gs = yu.get_sql('''select datadate as datadate_p1d, ric, avail_amount_gs, rate_gs                    
                   from [CNDBPROD].[dbo].[MLP_CN_ETBList_ABC_RIC]                    ''')
i_etb_gs['ticker_6d'] = i_etb_gs['ric'].str[:6]
i_etb_gs.loc[i_etb_gs['ric'].str[-2:].isin(['SS', 'SZ']), 'mkt'] = 'onshore'
i_etb_gs.loc[i_etb_gs['ric'].str[-2:].isin(['SH', 'ZK']), 'mkt'] = 'offshore'

i_etb_gs = i_etb_gs.groupby(['ticker_6d','mkt','datadate_p1d'])['avail_amount_gs'].sum().reset_index()
i_etb_gs = i_etb_gs.pivot_table(index=['ticker_6d', 'datadate_p1d'], columns = 'mkt', values = 'avail_amount_gs')
i_etb_gs = i_etb_gs.rename(columns={'offshore':'gs_off_shares', 'onshore':'gs_on_shares'})
i_etb_gs = i_etb_gs.reset_index()

c_sh = i_etb_gs['ticker_6d'].str[0].isin(['6'])
c_sz = i_etb_gs['ticker_6d'].str[0].isin(['0','3'])
i_etb_gs.loc[c_sh, 'ticker'] = i_etb_gs.loc[c_sh, 'ticker_6d'] + '.SH'
i_etb_gs.loc[c_sz, 'ticker'] = i_etb_gs.loc[c_sz, 'ticker_6d'] + '.SZ'
i_etb_gs = i_etb_gs[i_etb_gs['ticker'].notnull()]





i_etb_ms = yu.get_sql('''select datadate as datadate_p1d, ric, avail_amount_ms, rate_ms                    
                   from [CNDBPROD].[dbo].[MLP_CN_ETBList_ABC_RIC]                    ''')
i_etb_ms['ticker_6d'] = i_etb_ms['ric'].str[:6]
i_etb_ms.loc[i_etb_ms['ric'].str[-2:].isin(['SS', 'SZ']), 'mkt'] = 'onshore'
i_etb_ms.loc[i_etb_ms['ric'].str[-2:].isin(['SH', 'ZK']), 'mkt'] = 'offshore'

i_etb_ms = i_etb_ms.groupby(['ticker_6d','mkt','datadate_p1d'])['avail_amount_ms'].sum().reset_index()
i_etb_ms = i_etb_ms.pivot_table(index=['ticker_6d', 'datadate_p1d'], columns = 'mkt', values = 'avail_amount_ms')
i_etb_ms = i_etb_ms.rename(columns={'offshore':'ms_off_shares', 'onshore':'ms_on_shares'})
i_etb_ms = i_etb_ms.reset_index()

c_sh = i_etb_ms['ticker_6d'].str[0].isin(['6'])
c_sz = i_etb_ms['ticker_6d'].str[0].isin(['0','3'])
i_etb_ms.loc[c_sh, 'ticker'] = i_etb_ms.loc[c_sh, 'ticker_6d'] + 
'.SH'
i_etb_ms.loc[c_sz, 'ticker'] = i_etb_ms.loc[c_sz, 'ticker_6d'] + '.SZ'
i_etb_ms = i_etb_ms[i_etb_ms['ticker'].notnull()]





# combine


s = i_uni[i_uni.datadate_p1d>'2019-01-01'].merge(i_o2o, on = ['ticker', 'datadate_p1d'], how = 'left')
s = s.merge(i_hk_cal, on = 'datadate_p1d', how = 'inner')
s = s.sort_values(['ticker','datadate_p1d'])
s = s.merge(i_h_gs, on = ['ticker', 'datadate_p1d'], how = 'left')
s['bb_gs_shares'] = s['bb_gs_shares'].fillna(0)
s = s.merge(i_h_ms, on = ['ticker', 'datadate_p1d'], how = 'left')
s['bb_ms_shares'] = s['bb_ms_shares'].fillna(0)
s = s.merge(i_etb_gs, on = ['ticker', 'datadate_p1d'], how = 'left')
s['gs_off_shares'] = s['gs_off_shares'].fillna(0)
s = s.merge(i_etb_ms, on = ['ticker', 'datadate_p1d'], how = 'left')
s['ms_off_shares'] = s['ms_off_shares'].fillna(0)
s = s[s.datadate_p1d!='2022-04-07']


s = s.sort_values('datadate_p1d')
s = pd.merge_asof(s, i_guben[['ticker', 'datadate', 'float_guben']], 
                  by='ticker', left_on='datadate_p1d', right_on='datadate', 
                  allow_exact_matches = False, suffixes=['','_m'])
s = s.drop(columns = 'datadate')
s = pd.merge_asof(s, i_c[['ticker', 'datadate', 'c', 'c2c', 'c2c_t5d', 'c2c_t20d']], 
                  by='ticker', left_on='datadate_p1d', right_on='datadate', 
                  allow_exact_matches = False, suffixes=['','_m'])
s = s.drop(columns = 'datadate')
s = pd.merge_asof(s, i_pv[['ticker', 'datadate', 'avgPV']], 
                  by='ticker', left_on='datadate_p1d', right_on='datadate', 
                  allow_exact_matches = False, suffixes=['','_m'])
s = s.drop(columns = 'datadate')


s = s.sort_values(['ticker','datadate_p1d'])
s['bb_gs_pctSO'] = s['bb_gs_shares'] / s['float_guben']
s['bb_gs_pctPV'] = s['bb_gs_shares'] * s['c'] / s['avgPV']
s['bb_gs_pctPV'] = s['bb_gs_pctPV'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
s['bb_gs_pctPV_t6m'] = s.groupby('ticker').rolling(126)['bb_gs_pctPV'].mean().values
s['bb_gs_pctPV_t1w'] = s.groupby('ticker').rolling(5)['bb_gs_pctPV'].mean().values
s['gs_off_rmb'] = s['gs_off_shares'] * s['c']
s['gs_off_pctSO'] = s['gs_off_shares'] / s['float_guben']
s['gs_off_pctPV'] = s['gs_off_rmb'] / s['avgPV']
s['gs_off_pctPV_t6m'] = s.groupby('ticker').rolling(126)['gs_off_pctPV'].mean().values
s['gs_off_pctPV_t1w'] = s.groupby('ticker').rolling(5)['gs_off_pctPV'].mean().values
s['gs_off_df1d_pctPV'] = (s['gs_off_rmb'] - s.groupby('ticker')['gs_off_rmb'].shift())/s['avgPV']
s['gs_off_df1d_pctBBdf'] =
 (s['gs_off_shares'] - s.groupby('ticker')['gs_off_shares'].shift())/\
                         (s['bb_gs_shares'] - s.groupby('ticker')['bb_gs_shares'].shift())

s['gs_off_df1d_pctPV_gt0'] = s['gs_off_df1d_pctPV']
s.loc[s['gs_off_df1d_pctPV_gt0']<=0,'gs_off_df1d_pctPV_gt0'] = np.nan
s['bb_gs_shares_delta_tdy'] = s.groupby('ticker')['bb_gs_shares'].shift(-1) - s['bb_gs_shares']
s['bb_gs_shares_delta_tdy_dv_pv'] = s['bb_gs_shares_delta_tdy']*s['c']/s['avgPV']

s['bb_ms_pctSO'] = s['bb_ms_shares'] / s['float_guben']
s['bb_ms_pctPV'] = s['bb_ms_shares'] * s['c'] / s['avgPV']
s['ms_off_rmb'] = s['ms_off_shares'] * s['c']
s['ms_off_pctSO'] = s['ms_off_shares'] / s['float_guben']
s['ms_off_pctPV'] = s['ms_off_rmb'] / s['avgPV']
s['ms_off_df1d_pctPV'] = (s['ms_off_rmb'] - s.groupby('ticker')['ms_off_rmb'].shift())/s['avgPV']
s['ms_off_df1d_pctBBdf'] = (s['ms_off_shares'] - s.groupby('ticker')['ms_off_shares'].shift())/\
                         (s['bb_ms_shares'] - s.groupby('ticker')['bb_ms_shares'].shift())



#s['gs'] = '|'
#s['ms'] = '|'
#s = s[['datadate_p1d','ticker','o2oret+04d','o2oret+01d','o2oret+0d','o2oret-1d',
#       'gs', 'bb_gs_shares','bb_gs_pctSO',
#       'bb_gs_pctPV','bb_gs_pctPV_t6m','bb_gs_pctPV_t1w',
#       'gs_off_shares','gs_off_pctSO',
#       'gs_off_pctPV','gs_off_pctPV_t6m','gs_off_pctPV_t1w',
#       'gs_off_df1d_pctPV', 'gs_off_df1d_pctBBdf',
#       'ms', 'bb_ms_shares','bb_ms_pctSO','bb_ms_pctPV','ms_off_shares','ms_off_pctSO','ms_off_pctPV',
#       'ms_off_df1d_pctPV', 'ms_off_df1d_pctBBdf']]





s1 = s[s.ticker=='600528.SH']
s1 = s[s.ticker=='603628.SH']
s1 = s[s['gs_off_df1d_pctBBdf'].between(0.9,1.1) & (s['gs_off_df1d_pctPV']>0.02) & (s['o2oret-1d']<0)]

s1['o2oret+0d'].mean() / s1['o2oret+0d'].std() * np.sqrt(len(s1))

s1 =  s.groupby('ticker')['bb_gs_pctPV'].mean().sort_values()



s['gs_off_shares_df1d'] = s['gs_off_shares'] - s.groupby('ticker')['gs_off_shares'].shift()
s['gs_off_shares_df1d_gt0'] = s['gs_off_shares_df1d'].apply(lambda x: x if x>0 else 0)
s['gs_off_rmb'] = s['gs_off_rmb'].fillna(0)
s['gs_off_rmb_df1d'] = s['gs_off_rmb'] - s.groupby('ticker')['gs_off_rmb'].shift()
s['bb_shares_delta_tdy'] = s.groupby('ticker')['bb_shares'].shift(-1) - s['bb_shares']
s['bb_shares_df1d'] = s['bb_shares'] - s.groupby('ticker')['bb_shares'].shift()
s['bb_shares_df1d_gt0'] = s['bb_shares_df1d'].apply(lambda x: x if x>0 else 0)

s['gs_off_shares_df1dnm'] = s['gs_off_shares_df1d'] - s['bb_shares_df1d']
s['gs_off_shares_df1dnm2
'] = s['gs_off_shares_df1d_gt0'] - s['bb_shares_df1d_gt0']
s['gs_off_shares_df1dnm2_gt0'] = s['gs_off_shares_df1dnm2'].apply(lambda x: x if x>0 else 0)

s[['gs_off_shares_df1dnm','bb_shares_delta_tdy']].corr() # -0.2%
s[['gs_off_shares_df1dnm2_gt0','bb_shares_delta_tdy']].corr() # 2%
s[s['gs_off_sharesnm']*s['c']/s['avgPV']>0][['gs_off_sharesnm', 'bb_shares_delta_tdy']].corr() #-4%
s[s['gs_off_shares_df1dnm2_gt0']*s['c']/s['avgPV']>0.01][['gs_off_shares_df1dnm2_gt0', 'bb_shares_delta_tdy']].corr() #-2%

s[['gs_off_shares_df1d', 'bb_shares_delta_tdy']].corr() #0.7%
s2 = s[s['gs_off_sharesnm']*s['c']/s['avgPV']>0.01].groupby('ticker')[['gs_off_sharesnm', 'bb_shares_delta_tdy']].apply(lambda x: x[['gs_off_sharesnm', 'bb_shares_delta_tdy']].corr().values[0][1])
s2 = s.groupby('ticker')[['gs_off_shares_df1dnm2_gt0', 'bb_shares_delta_tdy']].apply(lambda x: x[['gs_off_shares_df1dnm2_gt0', 'bb_shares_delta_tdy']].corr().values[0][1])

s2.mean()
s2.loc['601336.SH']


s1 = s[s.ticker=='600582.SH']
s1[['gs_off_sharesnm', 'bb_shares_delta_tdy']].corr()
s1[['gs_off_sharesnm2', 'bb_shares_delta_tdy']].corr()
s1[s1['gs_off_sharesnm']*s1['c']/s1['avgPV']>0.01][['gs_off_sharesnm', 'bb_shares_delta_tdy']].corr() #47%
s1[s1['gs_off_sharesnm2']*s1['c']/s1['avgPV']>0.01][['gs_off_sharesnm2', 'bb_shares_delta_tdy']].corr() #9%





#---

s['bb_gs_shares_df1d'] = s['bb_shares'] - s.groupby('ticker')['bb_shares'].shift()
s['bb_ms_shares_df1d'] = s['bb_ms_shares'] - s.groupby('ticker')['bb_ms_shares'].shift()
c1 = (s['bb_gs_shares_df1d']*s['c']/s['avgPV'] <-0.02) | (s['bb_ms_shares_df1d']*s['c']/s['avgPV'] <-0.02)
c2 = (s['bb_shares']+s['bb_ms_shares'])*s['c']/s['avgPV'] < 0.01
c3 = (s['c2c_t5d'] < -0.05) & (s['c2c']<-0)
s['flg_gs_selloff'] = np.nan
s.loc[c1&c2&c3, 'flg_gs_selloff'] = 1
s['flg_gs_selloff'] = s.groupby('ticker')['flg_gs_selloff'].ffill(limit=10)
o_1 = bt_wr(s, 'datadate_p1d', 'flg_gs_selloff', 'o2oret+0d')



#--- trailing corr
# bar chart not working
# corr tstat across time series usually high but still volatile

s_corr = []
for dt in pd.date_range(start='2019-03-31',end='2022-07-31'):
    print('.',end='')
    ts = s[(s['datadate_p1d']<dt)&(s['datadate_p1d']>=dt-pd.to_timedelta('91 days'))]
        
    t_corr = ts.groupby('ticker')[['bb_gs_shares_delta_tdy_dv_pv','gs_off_df1d_pctPV_gt0']].apply(lambda x: x.corr().values[0][1])
    t_corr = t_corr.reset_index()
    t_corr.columns = ['ticker', 'corr_t1q']
    t_corr['datadate_p1d'] = dt
    s_corr.append(t_corr)

s_corr = pd.concat(s_corr, axis = 0)


i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['ticker', 'datadate'])
i_sd = i_sd.merge(s_corr, on = ['ticker', 'datadate_p1d'], how = 'left')
i_sd['corr_t1q_bk'] = i_sd.groupby('datadate')['corr_t1q'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(i_sd,['corr_t1q_bk'],'corr_t1q') # random

t1 = s_corr.groupby('ticker')['corr_t1q'].apply(lambda x: x.mean()/x.std()*np.sqrt(x.count()) if x.std()!=0 else np.nan)
t1= t1[t1.notnull()]

