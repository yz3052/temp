﻿#$%^&* pWIND_strat_mutualfund_02.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 19 10:33:50 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

# this studies mutual funds's top 10 holdings
# e.g. if a ticker regularly appears in top 10 holding 


### get close price

i_c = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate, 
                 s_dq_close as c from wind.dbo.ashareeodprices''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format='%Y%m%d')
i_c = i_c.sort_values('datadate')

### compcode and ticker_fund mapping
i_tk_fund_map = yu.get_sql('''select s_info_windcode as ticker_fund, s_info_compcode as s_holder_compcode 
                           from wind.dbo.windcustomcode ''')


### features of fund: nav returns

i_fund_nav = yu.get_sql('''select f_info_windcode as ticker_fund, price_date,
                        f_nav_unit*F_NAV_ADJFACTOR as adjNAV 
                        from wind.dbo.ChinaMutualFundNAV 
                        where price_date > '20140101' ''')
i_fund_nav['datadate'] = pd.to_datetime(i_fund_nav['price_date'],format='%Y%m%d') + pd.to_timedelta('30 days')
i_fund_nav = i_fund_nav.sort_values(['ticker_fund','datadate'])
i_fund_nav['fund_ret'] = i_fund_nav.groupby('ticker_fund').rolling(252)['adjNAV'].apply(lambda x: x[0]/x[-1]-1).values
i_fund_nav['fund_ret_rk'] = i_fund_nav.groupby('price_date')['fund_ret'].apply(yu.uniformed_rank).values
i_fund_nav = i_fund_nav.sort_values('datadate')


### features of fund: award <done>

i_fund_award = yu.get_sql(''' select a.s_info_windcode as ticker_fund, a.s_info_compcode, 
                          a.s_info_sectypename, a.s_info_name, 
                          b.s_info_award_code, b.opdate 
                          from wind.dbo.WindCustomCode a 
                          inner join wind.dbo.COMPANYAWARD b 
                          on a.s_info_compcode = b.S_INFO_COMPCODE  ''')
i_fund_award['datadate'] = pd.to_datetime(i_fund_award['opdate'].dt.date)
i_fund_award = i_fund_award.sort_values('datadate')
i_fund_award = i_fund_award[['s_info_compcode', 'datadate','s_info_award_code']]


### features of fund: style <done>

i_mf_style = yu.get_sql('''select f_info_windcode as ticker_fund, 
                        f_info_fullname, 
                        f_info_firstinvesttype, f_info_firstinveststyle,
                        f_info_setupdate, f_info_issuedate, f_info_fund_id as s_
holder_compcode,
                        f_info_benchmark 
                        from wind.dbo.ChinaMutualFundDescription''')

i_mf_style = i_mf_style[(i_mf_style['f_info_firstinvesttype']!='债券型')&\
                        (i_mf_style['f_info_firstinvesttype']!='货币市场型')&\
                        (i_mf_style['f_info_firstinveststyle']!='被动指数型')&\
                        (i_mf_style['f_info_firstinveststyle']!='增强指数型')&\
                        (i_mf_style['f_info_firstinveststyle']!='商品型')&\
                        (i_mf_style['f_info_firstinveststyle']!='保本型')]

i_mf_style['f_info_issuedate'] = i_mf_style['f_info_issuedate'].fillna(np.nan)
i_mf_style['f_info_issuedate'] = pd.to_datetime(i_mf_style['f_info_issuedate'], format='%Y%m%d', errors = 'coerce')
i_mf_style['f_info_setupdate'] = i_mf_style['f_info_setupdate'].fillna(np.nan)
i_mf_style['f_info_setupdate'] = pd.to_datetime(i_mf_style['f_info_setupdate'], format='%Y%m%d', errors = 'coerce')

i_mf_style['isActiveInv_flag'] = 1
i_mf_style = i_mf_style.drop_duplicates(subset=['s_holder_compcode'], keep = 'first')
i_mf_style = i_mf_style[['s_holder_compcode', 'isActiveInv_flag']]


### features of fund: holder: turnover
# for Dec and Jun, it is only calculated after the 2nd disclosure (the full portfolio disclosure)

i_h = yu.get_sql('''select S_INFO_WINDCODE as ticker_fund, f_prt_enddate as report_period,
                 s_info_stockwindcode as ticker, F_PRT_STKVALUE as held_dollar,
                 F_PRT_STKVALUETONAV as heldPct_ofMF, ann_date as datadate
                 from wind.dbo.ChinaMutualFundStockPortfolio
                 ''')
i_h = i_h[i_h['datadate'].notnull()]
i_h['datadate'] = pd.to_datetime(i_h['datadate'], format = '%Y%m%d')
i_h['report_period'] = pd.to_datetime(i_h['report_period'], format = '%Y%m%d')

o_turnover = []

for mf_fund in i_h['ticker_fund'].unique().tolist():
    print('.',end='')
    t_fund_h = i_h[i_h['ticker_fund']==mf_fund]
    t_fund_h_periods = t_fund_h['report_period'].sort_values().drop_duplicates().tolist()
    if len(t_fund_h_periods) <= 1:
        continue
    for i, p in enumerate(t_fund_h_periods[1:]):
        t_curr_h = t_fund_h[t_fund_h['report_period']==p][['ticker_fund','ticker','report_period','heldPct_ofMF']]
        t_prev_h = t_fund_h[t_fund_h['report_period']==t_fund_h_periods[i]][['ticker_fund','ticker','report_period','heldPct_ofMF']]
        
        t_merged_h = t_curr_h.merge(t_prev_h, on = ['ticker_fund','ticker'], suffixes=['_prev','_curr'])
  
      t_merged_h['heldPct_ofMF_prev'] = t_merged_h['heldPct_ofMF_prev'].fillna(0)
        t_merged_h['heldPct_ofMF_curr'] = t_merged_h['heldPct_ofMF_curr'].fillna(0)
        
        t_turnover = pd.DataFrame({'absChg_heldPct_ofMF':[(t_merged_h['heldPct_ofMF_curr']-t_merged_h['heldPct_ofMF_prev']).abs().sum()],
                                  'datadate': [t_fund_h[t_fund_h['report_period']==p]['datadate'].max()],
                                  'ticker_fund': [mf_fund]})
        o_turnover.append(t_turnover)
         
o_turnover = pd.concat(o_turnover, axis = 0)
o_turnover = o_turnover.sort_values(['ticker_fund','datadate'])
o_turnover['absChg_heldPct_ofMF_t2y'] = o_turnover.groupby('ticker_fund').rolling(4,min_periods=1)['absChg_heldPct_ofMF'].mean().values

o_turnover = o_turnover.sort_values(['datadate'])






### features of fund: holder: individual or not

#i_fund_holder_type = ###???


### features of fund: rating <done>

i_fund_rating = yu.get_sql('''select s_info_windcode as ticker_fund, rating_ann_date as datadate,
                           rptdate,
                           starlevel, rating_interval, rating_gagency, rating_type 
                           from wind.dbo.CMFundThirdPartyRating
                           where rating_ann_date is not null''')
i_fund_rating = i_fund_rating[i_fund_rating['rating_gagency']=='上海证券']
i_fund_rating['datadate'] = pd.to_datetime(i_fund_rating['datadate'], format='%Y%m%d')
i_fund_rating = i_fund_rating.groupby(['ticker_fund','datadate'])['starlevel'].mean().reset_index()
i_fund_rating = i_fund_rating.sort_values(['datadate'])


### get top 10 holdings for each fund, each quarterly report

i_holding = yu.get_sql('''select s_info_windcode as ticker, ann_date as datadate, 
                       s_holder_name as holder_name, s_holder_holdercategory, s_holder_compcode,
                       report_period, 
                       s_holder_quantity as held_shares, s_holder_pct as pct_ofComp 
                       from [WIND].[dbo].[ASHAREINSTHOLDERDERDATA] 
                       where report_period >= 20140101 ''')

i_holding = i_holding[i_holding['s_holder_holdercategory']=='基金']
i_holding = i_holding[i_holding['datadate'].notnull()&i_holding['report_period'].notnull()]
i_holding['report_period'] = pd.to_datetime(i_holding['report_period'], format='%Y%m%d')
i_holding['datadate'] = pd.to_datetime(i_holding['datadate'], format='%Y%m%d')
i_holding = i_holding.sort_values('datadate')

i_holding = i_holding.
merge(i_tk_fund_map, on = ['s_holder_compcode'], how = 'left')

i_holding = pd.merge_asof(i_holding, i_c, by='ticker', on='datadate')
i_holding['held_dollar'] = i_holding['held_shares'].multiply(i_holding['c'])
i_holding = i_holding.sort_values(['s_holder_compcode','report_period','held_dollar'], ascending=False)

i_holding_top10 = i_holding.groupby(['s_holder_compcode','report_period']).head(10)
i_holding_top10 = i_holding_top10.sort_values('datadate')
i_holding_top10 = pd.merge_asof(i_holding_top10, i_fund_award, 
                                left_by='s_holder_compcode',
                                right_by = 's_info_compcode', 
                                on = 'datadate', tolerance= pd.to_timedelta('550 days'))
i_holding_top10 = i_holding_top10.merge(i_mf_style, on='s_holder_compcode', how = 'left')
i_holding_top10 = pd.merge_asof(i_holding_top10, i_fund_rating, by='ticker_fund', on = 'datadate')
i_holding_top10 = pd.merge_asof(i_holding_top10, i_fund_nav, by='ticker_fund', on = 'datadate', tolerance=pd.to_timedelta('7 days'))
i_holding_top10 = pd.merge_asof(i_holding_top10, o_turnover, by='ticker_fund', on = 'datadate', tolerance=pd.to_timedelta('7 days'))


### for each ticker, get the number of mutuals that hold it as top 10 

o_mf_cnt = []
for dt in pd.date_range(start = '2015-01-01', end = '2021-12-31'):
    print(dt.strftime('%Y%m%d'), end=' ')
    
    t_holding = i_holding_top10[i_holding_top10['datadate'].between(dt-pd.to_timedelta('95 days'),dt)]
    
    t_holding_sum = t_holding.groupby('ticker')['s_holder_compcode'].nunique().reset_index()
    t_holding_sum = t_holding_sum.rename(columns={'s_holder_compcode':'mf_cnt'})
    
    t_holding_D_sum = t_holding.groupby('ticker')['held_dollar'].sum().reset_index()
    t_holding_D_sum = t_holding_D_sum.rename(columns={'held_dollar':'mf_dollar'})
    
    t_holding_award_sum = t_holding[t_holding['s_info_award_code'].notnull()].groupby('ticker')['s_holder_compcode'].nunique().reset_index()
    t_holding_award_sum = t_holding_award_sum.rename(columns={'s_holder_compcode':'mf_award_cnt'})
    
    t_holding_active_sum = t_holding[t_holding['isActiveInv_flag']==1].groupby('ticker')['s_holder_compcode'].nunique().reset_index()
    t_holding_active_sum = t_holding_active_sum.rename(columns={'s_holder_compcode':'mf_active_cnt'})
    
    t_holding_activeLowTurnover_sum = t_holding[(t_holding['isActiveInv_flag']==1)&(t_holding['absChg_heldPct_ofMF_t2y']>3)].groupby('ticker')['s_holder_compcode']
.nunique().reset_index()
    t_holding_activeLowTurnover_sum = t_holding_activeLowTurnover_sum.rename(columns={'s_holder_compcode':'mf_activeLowTurnover_cnt'})
    
    t_holding_activePct_sum = t_holding[t_holding['isActiveInv_flag']==1].groupby('ticker')['pct_ofComp'].sum().reset_index()
    t_holding_activePct_sum = t_holding_activePct_sum.rename(columns={'pct_ofComp':'pct_ofComp_active'})
    
    t_holding_activeWinner_sum = t_holding[(t_holding['isActiveInv_flag']==1)&(t_holding['fund_ret_rk']>0)].groupby('ticker')['pct_ofComp'].sum().reset_index()
    t_holding_activeWinner_sum = t_holding_activeWinner_sum.rename(columns={'pct_ofComp':'pct_ofComp_activeWinner'})
    
    t_holding_4star_sum = t_holding[t_holding['starlevel']>=4].groupby('ticker')['s_holder_compcode'].nunique().reset_index()
    t_holding_4star_sum = t_holding_4star_sum.rename(columns={'s_holder_compcode':'mf_4star_cnt'})
    
    t_holding_o_sum = t_holding_sum.merge(t_holding_award_sum, on = 'ticker', how = 'outer')
    t_holding_o_sum = t_holding_o_sum.merge(t_holding_active_sum, on = 'ticker', how = 'outer')
    t_holding_o_sum = t_holding_o_sum.merge(t_holding_4star_sum, on = 'ticker', how = 'outer')
    t_holding_o_sum = t_holding_o_sum.merge(t_holding_D_sum, on = 'ticker', how = 'outer')
    t_holding_o_sum = t_holding_o_sum.merge(t_holding_activeLowTurnover_sum, on = 'ticker', how = 'outer')
    t_holding_o_sum = t_holding_o_sum.merge(t_holding_activePct_sum, on = 'ticker', how = 'outer')
    t_holding_o_sum = t_holding_o_sum.merge(t_holding_activeWinner_sum, on = 'ticker', how = 'outer')
    
    t_holding_o_sum['datadate'] = dt
    
    o_mf_cnt.append(t_holding_o_sum)
o_mf_cnt = pd.concat(o_mf_cnt, axis = 0)



### o2c return

i_o_c_ret = pw.get_wind_mkt_data(col_list = ['ticker', 'datadate', 'adjret_o_c'])
i_o_c_ret = i_o_c_ret.sort_values(['ticker', 'datadate'])
i_o_c_ret['adjret_o_c_t63d'] = i_o_c_ret.groupby('ticker').rolling(datetime.timedelta(days=91), on = 'datadate', min_periods=45)['adjret_o_c'].mean().values
i_o_c_ret['adjret_o_c_t63d_allrk'] = i_o_c_ret.groupby('datadate')['adjret_o_c_t63d'].apply(yu.uniformed_rank).values
i_o_c_ret['adjret_o_c_t252d'] = i_o_c_ret.groupby('ticker').rolling(datetime.timedelta(days=365), on = 'datadate', min_periods=180)['adjret_o_c'].mean().values
i_o_c_ret['adjret_o_c_t252d_allrk'] = i_o_c_ret.groupby('datadate')['adjret_o_c_t252d'].apply(yu.uniformed_rank).values



### sd



i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = 
i_sd.sort_values(['ticker', 'datadate'])
i_sd['V_t30d'] = i_sd.groupby('ticker').rolling(30)['V_l1d'].mean().values

i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d','V_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','csi300_flag']]

i_sd_map_300 =i_sd_map[i_sd_map['csi300_flag']==1]



### combine: hk


icom = i_sd.merge(o_mf_cnt, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_o_c_ret, on = ['ticker', 'datadate'], how = 'left')
icom['mf_cnt'] = icom['mf_cnt'].fillna(0)
icom['mfAward_cnt'] = icom['mf_award_cnt'].fillna(0)
icom['mfActive_cnt'] = icom['mf_active_cnt'].fillna(0)
icom['mfActiveLowTurnover_cnt'] = icom['mf_activeLowTurnover_cnt'].fillna(0)
icom['mf4star_cnt'] = icom['mf_4star_cnt'].fillna(0)
icom['mf_dollar'] = icom['mf_dollar'].fillna(0)
icom['pct_ofComp_active'] = icom['pct_ofComp_active'].fillna(0)


icom['mc_5bk'] = icom.groupby('datadate')['MC_l1d'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom['mf_cnt_rk'] = icom.groupby('datadate')['mf_cnt'].apply(yu.uniformed_rank).values
icom['mf_cnt_bk'] = icom.groupby('datadate')['mf_cnt'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom['mfAward_cnt_rk'] = icom.groupby('datadate')['mfAward_cnt'].apply(yu.uniformed_rank).values
icom['mfAward_cnt_bk'] = icom.groupby('datadate')['mfAward_cnt'].apply(lambda x: yu.pdqcut(x,bins=5)).values
icom.loc[icom['mfAward_cnt']>=1, 'mfAward_sgnl'] = 1

icom['mfActive_cnt_rk'] = icom.groupby('datadate')['mfActive_cnt'].apply(yu.uniformed_rank).values
icom['mfActive_cnt_secrk'] = icom.groupby(['datadate','GSECTOR'])['mfActive_cnt'].apply(yu.uniformed_rank).values
icom['mfActive_cnt_secbk'] = icom.groupby(['datadate','GSECTOR'])['mfActive_cnt'].apply(lambda x: yu.pdcut(x,bins=10)).values
icom['mfActive_cnt_bk'] = icom.groupby('datadate')['mfActive_cnt'].apply(lambda x: yu.pdqcut(x,bins=5)).values
icom['mfActive1_sgnl'] = np.nan
icom.loc[icom['mfActive_cnt']>=3, 'mfActive1_sgnl'] = 1

icom['mfActiveLowTurnover_cnt_rk'] = icom.groupby('datadate')['mfActiveLowTurnover_cnt'].apply(yu.uniformed_rank).values
icom['mfActiveLowTurnover_cnt_bk'] = icom.groupby('datadate')['mfActiveLowTurnover_cnt'].apply(lambda x: yu.pdqcut(x,bins=5)).values
icom['mfActiveLowTurnover_sgnl'] = np.nan
icom.loc[icom['mfActiveLowTurnover_cnt']>=3, 'mfActiveLowTurnover_sgnl'] = 1


icom['m
f4star_cnt_rk'] = icom.groupby('datadate')['mf4star_cnt'].apply(yu.uniformed_rank).values
icom['mf4star_cnt_bk'] = icom.groupby('datadate')['mf4star_cnt'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom['mf_cnt_mcrk'] = icom.groupby(['datadate','mc_5bk'])['mf_cnt'].apply(yu.uniformed_rank).values
icom['mf_cnt_mcbk'] = icom.groupby(['datadate','mc_5bk'])['mf_cnt'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom['mf_dollar_rk'] = icom.groupby(['datadate'])['mf_dollar'].apply(yu.uniformed_rank).values
icom['mf_dollar_bk'] = icom.groupby(['datadate'])['mf_dollar'].apply(lambda x: yu.pdqcut(x,bins=5)).values

#icom['mf_active_dollar_rk'] = icom.groupby(['datadate'])['mf_active_dollar'].apply(yu.uniformed_rank).values
#icom['mf_active_dollar_bk'] = icom.groupby(['datadate'])['mf_active_dollar'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom['pct_ofComp_active_rk'] = icom.groupby(['datadate'])['pct_ofComp_active'].apply(yu.uniformed_rank).values
icom['pct_ofComp_active_bk'] = icom.groupby(['datadate'])['pct_ofComp_active'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom['pct_ofComp_activeWinner_rk'] = icom.groupby(['datadate'])['pct_ofComp_activeWinner'].apply(yu.uniformed_rank).values

icom['test_rk'] = icom['pct_ofComp_active_rk'] - icom['pct_ofComp_activeWinner_rk'] 
icom.loc[icom['test_rk']>1, 'test_rk'] = 1
icom.loc[icom['test_rk']<-1, 'test_rk'] = -1




o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['mf_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mf_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.11/2.37, 1.29bp/d, 2.2e7

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mf_cnt_rk']>0)].\
            dropna(subset=['mf_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mf_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.01/2.45, 1.15bp/d

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mf_cnt_rk']<0)].\
            dropna(subset=['mf_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mf_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.62/1.85, 1.54bp/d

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mf4star_cnt_rk']>0)].\
            dropna(subset=['mf4star_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mf4star_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #p
rcs2.2/1.74, no major drawdown

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['mfActive_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mfActive_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.16/2.46, 1.43bp/d, 2.2e7, 2.5e7

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')&(icom['mfActive_cnt_rk']>0)].\
            dropna(subset=['mfActive_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mfActive_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.05/2.55, 1.33bp/d, 1.5e7 ###!!!

yu.create_cn_3x3(icom, ['mfActive_cnt_secbk'], 'mfActive_cnt') # 
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mfActive_cnt_secrk']>0)&(icom['mf4star_cnt_rk']>0)].\
            dropna(subset=['mfActive_cnt_secrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mfActive_cnt_secrk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.77/2.35, 1.83bp/d, 1.5e7 ###!!!

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mfActive_cnt_rk']>0)&(icom['mf4star_cnt_rk']>0)].\
            dropna(subset=['mfActive_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mfActive_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.46/2.06, 1.59bp/d, 1.3e7


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mfActive_cnt_rk']>0)&(icom['GROWTH'].abs()<2)].\
            dropna(subset=['mfActive_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mfActive_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.3/2.78, 1.49bp/d, 1.5e7 ###!!!





o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mfActive_cnt_rk']>0)&(icom['EARNYILD'].abs()<2)].\
            dropna(subset=['mfActive_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mfActive_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.3/2.78, 1.49bp/d, 1.5e7 


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mfActive1_sgnl']>0)&(icom['GROWTH']>0)].\
            dropna(subset=['mfActive1_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mfActive1_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mfActiveLowTurnover_cnt_rk']>0)].\
            dropna(subs
et=['mfActiveLowTurnover_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mfActiveLowTurnover_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.63/1.86, 1.24bp/d, 1.0e7


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mfAward_cnt_rk']>0)].\
            dropna(subset=['mfAward_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mfAward_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.51/2.03, 1.37bp/d, 1.2e7

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mfAward_sgnl']>0)].\
            dropna(subset=['mfAward_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mfAward_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.61/2.05, 1.23bp/s, 1.5e7




o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mf_dollar_rk']>0)].\
            dropna(subset=['mf_dollar_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mf_dollar_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.48/1.89

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mf_active_dollar_rk']>0)].\
            dropna(subset=['mf_active_dollar_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mf_active_dollar_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.73/2.21, 1.19bp/d, 1.25e7

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['pct_ofComp_active_rk']>0)].\
            dropna(subset=['pct_ofComp_active_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofComp_active_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.54/2.07, 1.48bp/d, 1.25e7 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['pct_ofComp_activeWinner_rk']>0)].\
            dropna(subset=['pct_ofComp_activeWinner_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pct_ofComp_activeWinner_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.74/1.33






### combine: 300

icom300 = i_sd_map_300.merge(o_mf_cnt, on = ['ticker', 'datadate'], how = 'left')
icom300['mf_cnt'] = icom300['mf_cnt'].fillna(0)
icom300['mfAward_cnt'] = icom300['mf_award_cnt'].fillna(0)
icom300['mfActive_cnt'] = icom300['mf_active_cnt'].fillna(0)
icom300['mf4star_cnt'] = icom300['mf_4star_cnt'].fillna(0)

icom300['mc_5bk'] = icom300.groupby('datadate')['MC_l1d'].apply(lambda x:
 yu.pdqcut(x,bins=5)).values

icom300['mf_cnt_rk'] = icom300.groupby('datadate')['mf_cnt'].apply(yu.uniformed_rank).values
icom300['mf_cnt_bk'] = icom300.groupby('datadate')['mf_cnt'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom300['mfAward_cnt_rk'] = icom300.groupby('datadate')['mfAward_cnt'].apply(yu.uniformed_rank).values
icom300['mfAward_cnt_bk'] = icom300.groupby('datadate')['mfAward_cnt'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom300['mfActive_cnt_rk'] = icom300.groupby('datadate')['mfActive_cnt'].apply(yu.uniformed_rank).values
icom300['mfActive_cnt_bk'] = icom300.groupby('datadate')['mfActive_cnt'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom300['mf4star_cnt_rk'] = icom300.groupby('datadate')['mf4star_cnt'].apply(yu.uniformed_rank).values
icom300['mf4star_cnt_bk'] = icom300.groupby('datadate')['mf4star_cnt'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom300['mf_cnt_mcrk'] = icom300.groupby(['datadate','mc_5bk'])['mf_cnt'].apply(yu.uniformed_rank).values
icom300['mf_cnt_mcbk'] = icom300.groupby(['datadate','mc_5bk'])['mf_cnt'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom300, ['mf_cnt_bk'], 'mf_cnt')
yu.create_cn_3x3(icom300, ['mf_cnt_mcbk'], 'mf_cnt')




o_1 = yu.bt_cn_15(icom300[(icom300['datadate']<='2019-12-31')].\
            dropna(subset=['mf_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mf_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.14/1.77

o_1 = yu.bt_cn_15(icom300[(icom300['datadate']<='2019-12-31')].\
            dropna(subset=['mfActive_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mfActive_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.34 / 1.98

o_1 = yu.bt_cn_15(icom300[(icom300['datadate']<='2019-12-31')].\
            dropna(subset=['mf4star_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mf4star_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.38/0.9


o_1 = yu.bt_cn_15(icom300[(icom300['datadate']<='2019-12-31')].\
            dropna(subset=['mfAward_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mfAward_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.08 / 1.64

o_1 = yu.bt_cn_15(icom300[(icom300['datadate']<='2019-12-31')&(icom300['mf_cnt_mcrk'].abs()>0.5)].\
            dropna(subset=['mf_cnt_mcrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datada
te']),
            'mf_cnt_mcrk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.5/1.76

t1 = yu.explore(icom300, 'mf_cnt_mcrk')





### combine: 180

icom180 = i_sd_map_300.merge(o_mf_cnt, on = ['ticker', 'datadate'], how = 'left')
icom180['mf_cnt'] = icom180['mf_cnt'].fillna(0)

icom180['mc_rknum'] = icom180.groupby('datadate')['MC_l1d'].rank()
icom180 = icom180[icom180['mc_rknum']<=180]

icom180['mc_5bk'] = icom180.groupby('datadate')['MC_l1d'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom180['mf_cnt_rk'] = icom180.groupby('datadate')['mf_cnt'].apply(yu.uniformed_rank).values
icom180['mf_cnt_bk'] = icom180.groupby('datadate')['mf_cnt'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom180['mf_cnt_mcrk'] = icom180.groupby(['datadate','mc_5bk'])['mf_cnt'].apply(yu.uniformed_rank).values
icom180['mf_cnt_mcbk'] = icom180.groupby(['datadate','mc_5bk'])['mf_cnt'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom180['mf_cnt_secrk'] = icom180.groupby(['datadate','GSECTOR'])['mf_cnt'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icom180, ['mf_cnt_bk'], 'mf_cnt')
yu.create_cn_3x3(icom180, ['mf_cnt_mcbk'], 'mf_cnt')

o_1 = yu.bt_cn_15(icom180[(icom180['datadate']<='2019-12-31')].\
            dropna(subset=['mf_cnt_mcrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mf_cnt_mcrk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.58/1.59

o_1 = yu.bt_cn_15(icom180[(icom180['datadate']<='2019-12-31')&(icom180['mf_cnt_mcrk'].abs()>0.5)].\
            dropna(subset=['mf_cnt_mcrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mf_cnt_mcrk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.42/1.38

o_1 = yu.bt_cn_15(icom180[(icom180['datadate']<='2019-12-31')&(icom180['mf_cnt_secrk'].abs()>0.5)].\
            dropna(subset=['mf_cnt_secrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mf_cnt_secrk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.12 / 1.53



