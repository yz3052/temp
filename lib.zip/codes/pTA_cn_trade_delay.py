#$%^&* pTA_cn_trade_delay.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep  1 01:23:50 2023

@author: thzhang
"""

import pandas as pd
import numpy as np

import util as yu



# std is a good filter
# sh and sz separately
# sz metrics did not work
# also, we need to explore the time delay in order data




# sd 

i_sd = yu.get_sd_cn_1800()


# get q data 

i_sz = pd.read_csv('/dat/summit_capital/TZ/tmp/sz.txt',sep = '|')
i_sz = i_sz.rename(columns = {'code': 'Ticker', 'date': 'T-1d'})
i_sz['T-1d'] = pd.to_datetime(i_sz['T-1d'])
i_sz['Ticker'] = i_sz['Ticker'].astype(int).astype(str).str.zfill(6)

i_sh = pd.read_csv('/dat/summit_capital/TZ/tmp/sh.txt',sep = '|')
i_sh = i_sh.rename(columns = {'code': 'Ticker', 'date': 'T-1d'})
i_sh['T-1d'] = pd.to_datetime(i_sh['T-1d'])
i_sh['Ticker'] = i_sh['Ticker'].astype(int).astype(str).str.zfill(6)

i_delay = pd.concat([i_sh, i_sz], axis = 0)


# combine

icom = i_sd.merge(i_delay, on = ['Ticker', 'T-1d'], how = 'left')
icom = icom.sort_values(['Ticker', 'T-1d'])


for c in ['sh_trd_m_snd_med', 'sh_trd_m_snd_avg', 
       'sz_snd_m_trd_med', 'sz_snd_m_trd_avg', 'sz_rcv_m_trd_med',
       'sz_rcv_m_trd_avg', 'sz_rcv_m_snd_med', 'sz_rcv_m_snd_avg']:
    icom[c+ '_bk'] = icom.groupby('DataDate')[c].apply(lambda x: yu.pdqcut(x,bins=10)).values
    yu.create_cn_3x3_linux(icom, [c+'_bk'], c)
    
    
icom['avgPVadj_bk'] = icom.groupby('DataDate')['avgPVadj'].apply(lambda x: yu.pdqcut(x,bins=10)).values
for c in ['sh_trd_m_snd_med', 'sh_trd_m_snd_med_am', 'sh_trd_m_snd_std']:
    icom[c+ '_bk'] = icom.groupby(['DataDate','avgPVadj_bk'])[c].apply(lambda x: yu.pdqcut(x,bins=10)).values
    yu.create_cn_3x3_linux(icom, [c+'_bk'], c)

yu.create_cn_3x3_linux(icom[icom['sh_trd_m_snd_std_bk'].ge(3)], ['sh_trd_m_snd_med_bk'], 'sh_trd_m_snd_med')
###!!! +2 -11

icom['sh_trd_m_snd_med_pvrk'] = icom.groupby(['DataDate','avgPVadj_bk'])['sh_trd_m_snd_med'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['sh_trd_m_snd_med_pvrk_t20d'] = icom.groupby('Ticker').rolling(20)['sh_trd_m_snd_med_pvrk'].mean().values
icom['sh_trd_m_snd_med_pvrk_t20d_bk'] = icom.groupby('DataDate')['sh_trd_m_snd_med_pvrk_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['sh_trd_m_snd_med_pvrk_t20d_sgnl'] = -icom.groupby('DataDate')['sh_trd_m_snd_med_pvrk_t20d'].apply(yu.uniformed_rank)
yu.create_cn_3x3_linux(icom, ['sh_trd_m_snd_med_pvrk_t20d_bk'], 'sh_trd_m_snd_med_pvrk_t20d')
###!!! +6 -6


yu.bt_cn_15_linux(icom[icom['Data
Date'].between('2021-01-01', '2022-12-31') \
                       & icom['sh_trd_m_snd_med_pvrk_t20d_sgnl'].abs().gt(0.5)].\
            dropna(subset=['sh_trd_m_snd_med_pvrk_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'sh_trd_m_snd_med_pvrk_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) 
# full continuous sgnl 3.7 /2.5 /1.4
# 3.6 2.1 1.4



    
for c in ['sz_rcv_m_snd_med']:
    icom[c+ '_bk'] = icom.groupby(['DataDate','avgPVadj_bk'])[c].apply(lambda x: yu.pdqcut(x,bins=10)).values
    yu.create_cn_3x3_linux(icom, [c+'_bk'], c)



icom['sh_trd_m_snd_med_rk'] = icom.groupby(['DataDate','avgPVadj_bk'])['sh_trd_m_snd_med'].apply(yu.uniformed_rank)


# sh_trd_m_snd_med: higher delay, lower return