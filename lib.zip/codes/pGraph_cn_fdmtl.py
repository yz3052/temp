﻿#$%^&* pGraph_cn_fdmtl.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 23 17:06:17 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()


### get wind ttm data

i_ttm = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                   S_DFA_OR_TTM as [or],S_DFA_NETPROFIT_TTM as np,S_DFA_CASHFLOW_TTM as cf,
                   S_DFA_TOTASSETS as a,S_DFA_TOTASSETS/(S_DFA_TOTASSETS+S_DFA_TOTLIAB) as a2al,
                   S_DFA_ROE_TTM as roe 
                   from wind.dbo.PITFinancialFactor 
                   order by s_info_windcode, trade_dt''')
i_ttm['datadate'] = pd.to_datetime(i_ttm['datadate'], format='%Y%m%d')

i_ttm['or_yy'] = i_ttm.groupby('ticker')['or'].apply(lambda x: x.divide(x.shift(252))-1)
i_ttm['np_yy'] = i_ttm.groupby('ticker')['np'].apply(lambda x: x.divide(x.shift(252))-1)
i_ttm['cf_yy'] = i_ttm.groupby('ticker')['cf'].apply(lambda x: x.divide(x.shift(252))-1)

i_ttm = i_ttm[['ticker','datadate','or_yy','np_yy','cf_yy','a','a2al','roe']]

i_ttm_s2 = i_sd.merge(i_ttm, on = ['ticker','datadate'], how = 'left')
for c in ['or_yy','np_yy','cf_yy','a','a2al','roe']:
    i_ttm_s2[c] = i_ttm_s2[c].replace(np.inf,np.nan).replace(-np.inf,np.nan)
    i_ttm_s2[c+'_rk'] = i_ttm_s2.groupby('datadate')[c].apply(yu.uniformed_rank).values


### calculate pair wise rank distance
    

o_dist_sum = []

for dt in pd.date_range(start = '2016-02-01', end = '2021-06-01', freq='W'):
    print (dt.strftime('%Y%m%d'), end = ' ')
    
    COLS = ['or_yy_rk','np_yy_rk','cf_yy_rk','a_rk','a2al_rk','roe_rk']
    
    t_fdmtl = i_ttm_s2[(i_ttm_s2['datadate']==dt)]
    t_fdmtl = t_fdmtl[COLS + ['ticker']]
    t_fdmtl = t_fdmtl.set_index('ticker')
    
    
    t_dist = np.linalg.norm(t_fdmtl.values[:, None, :] - t_fdmtl.values[None, :, :], axis=-1)
    if len(t_dist) == 0:
        continue
    t_dist = pd.DataFrame(t_dist, index = t_fdmtl.index.values, columns = t_fdmtl.index.values)
    
    t_dist_mean = t_dist.mean(axis = 1)
    t_dist_mean = t_dist_mean.reset_index().rename(columns={0: 'dist_mean'})
    
    t_dist_sum = t_dist_mean.copy()
    t_dist_sum['datadate'] = dt
    
    o_dist_sum.append(t_dist_sum)

o_dist_sum = pd.concat(o_dist_sum, axis = 0)
o_dist_sum = o_dist_sum.rename(columns = {'index':'ticker'})
o_dist_sum = o_dist_
sum.sort_values('datadate')


### 

icom = pd.merge_asof(i_sd, o_dist_sum, by='ticker', on='datadate')
icom = icom.sort_values(['ticker','datadate'])


icom['dist_mean_bk'] = icom.groupby('datadate')['dist_mean'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['dist_mean_rk'] = icom.groupby('datadate')['dist_mean'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['dist_mean_bk'], 'dist_mean') # random

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['fdmtl_dist_orth'] = icom.groupby('datadate')[COLS+['dist_mean']].apply(lambda x: yu.orthogonalize_cn(x['dist_mean'], x[COLS])).values
icom['fdmtl_dist_orth_bk'] = icom.groupby('datadate')['fdmtl_dist_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['fdmtl_dist_orth_rk'] = icom.groupby('datadate')['fdmtl_dist_orth'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['fdmtl_dist_orth_bk'], 'fdmtl_dist_orth') # random




