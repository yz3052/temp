﻿#$%^&* pShortQuota_cn_etl.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu May 13 08:58:38 2021

@author: thzhang
"""

import pWIND_util as pw

import pandas as pd

from yz.util import get_sql, bt_cn
import yz.util as yu
import datetime
import os
import pathlib





# get sd
i_sd = pw.get_china_sd()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d','avgPVadj','volatility','spread',
                 'BarrRet_CLIP+0d', 'BarrRet_CLIP+1d','BarrRet_SRISK+0d','BarrRet_SRISK+1d','RawRet+1d','fxRet_SRISK+1d',
                 'fxRet_CLIP+1d','isin_hk_uni']]
i_sd_map['ticker_int'] = i_sd_map['ticker'].str[:6].astype(int)

#------------------------------------------------------------------------------
# short quota
#------------------------------------------------------------------------------

# sedol
o_bbg_sedol = get_sql('''select distinct Sedol, ticker from [BackTest].[dbo].[IMPACTH_isin_sedol]''')
o_bbg_sedol = o_bbg_sedol.dropna()
c_sz = o_bbg_sedol['ticker'].str[0].isin(['0','3'])
o_bbg_sedol.loc[c_sz, 'ticker'] = o_bbg_sedol.loc[c_sz, 'ticker'] + '.SZ'
c_sh = o_bbg_sedol['ticker'].str[0].isin(['6'])
o_bbg_sedol.loc[c_sh, 'ticker'] = o_bbg_sedol.loc[c_sh, 'ticker'] + '.SH'

# get RMB prices 
i_rmb_px = get_sql('''select s_info_windcode as ticker, trade_dt as datadate, 
                   S_DQ_CLOSE as c from wind.dbo.ashareeodprices''')
i_rmb_px['datadate'] = pd.to_datetime(i_rmb_px['datadate'], format='%Y%m%d')
i_rmb_px = i_rmb_px.sort_values(['datadate','ticker'])

# get files
i_files_r = os.listdir(r'\\ad\dfs\botraders\alltraders\China_Avail\history')
i_files_r = [i for i in i_files_r if i.startswith('china_indicative_availability')]
i_files_r = [i for i in i_files_r if ('withoutFee' not in i) and  ('20180509_174744' not in i)]

i_files_r_fee = [i for i in i_files_r if (i.split('_')[3][:8] >= '20190328') & ('_BBG_' not in i)]
i_files_r_nofee = [i for i in i_files_r if (i.split('_')[3][:8] < '20190328') & ('_BBG_' not in i)]


# analyze files with fees 
o_data_tk_lvl_fee = pd.DataFrame()
o_data_brk_lvl_fee = pd.DataFrame()
for f in i_files_r_fee:
    print(f.split('_')[3].replace('.csv',''), end=' ')
    
    # read data
    t_r = pd.read_csv(os.path.join(r'\\ad\dfs\botraders\alltraders\China_Avail\history', f))
    t_r = t_r.rename(columns = {'Value':'shortable_mc_usd', 'StockAmount':'shortable_shares'})
    
    # alert
    if t_r['Fee'].isnull().sum() > 0:
        raise Exception('Fee has nan values.')

    # get ET mod
ified time 
    fname = pathlib.Path(os.path.join(r'\\ad\dfs\botraders\alltraders\China_Avail\history', f))
    mtime = datetime.datetime.fromtimestamp(fname.stat().st_mtime)
    t_r['publish_datetime_et'] = mtime
    t_r['publish_datetime_et'] = t_r['publish_datetime_et'].dt.tz_localize('US/Eastern')
    
    # get CST publish datetime and datadate
    t_r['publish_datetime_cst'] = t_r['publish_datetime_et'].dt.tz_convert('Asia/Shanghai')
    t_r['publish_datetime_cst'] = t_r['publish_datetime_cst'].dt.tz_localize(None)
    t_r['datadate'] = pd.to_datetime(f.split('_')[3].replace('.csv','')) + pd.to_timedelta('1 day')
    t_r = t_r.sort_values('datadate')
    
    # attach WIND ticker, get rid of SEDOLs that cannot be mapped to a ticker
    t_r = t_r.merge(o_bbg_sedol, on = ['Sedol'], how = 'left')
    t_r = t_r[t_r['ticker'].notnull()]
    
    # attach rmb price
    t_r = pd.merge_asof(t_r, i_rmb_px, by = ['ticker'], on = ['datadate'], allow_exact_matches = False)
    t_r['shortable_mc_rmb'] = t_r['shortable_shares'].multiply(t_r['c'])
    
    # format
    t_r = t_r.drop(columns = ['CCY','ReportDate','publish_datetime_et','c'])
    t_r['fee_x_shortable_shares'] = t_r['Fee'].multiply(t_r['shortable_shares'])
    
    # weighted fee
    t_r_grp = t_r.groupby(['ticker','datadate','publish_datetime_cst']).agg({'shortable_mc_rmb':sum,
                         'shortable_mc_usd':sum,'shortable_shares':sum,'fee_x_shortable_shares':sum}).reset_index()
    t_r_grp['fee'] = t_r_grp['fee_x_shortable_shares'].divide(t_r_grp['shortable_shares'])
    t_r_grp = t_r_grp.drop(columns = ['fee_x_shortable_shares'])
    
    # append
    o_data_tk_lvl_fee = o_data_tk_lvl_fee.append(t_r_grp, ignore_index = True)     
    o_data_brk_lvl_fee = o_data_brk_lvl_fee.append(t_r, ignore_index = True)

# earliest fee 
o_data_brk_lvl_fee = o_data_brk_lvl_fee.sort_values(['datadate', 'ticker'])
o_data_brk_lvl_fee_earliest = o_data_brk_lvl_fee.groupby(['Broker','Sedol','ticker'])['Fee'].first()
o_data_brk_lvl_fee_earliest = o_data_brk_lvl_fee_earliest.reset_index()

# analyze files without fees
o_data_tk_lvl_nofee = pd.DataFrame()
o_data_brk_lvl_nofee = pd.DataFrame()
for f in i_files_r_nofee:
    print(f.split('_')[3].replace('.csv',''), end=' ')
    
    # read data
    t_r = pd.read_csv(os.path.join(r'\\ad\dfs\botraders\alltraders\China_Avail\history', f))
    t_r = t_r.rename(columns = {'Value':'shortable_mc_usd', 'StockAmount':'shortable_shares'})
    
    # get ET modified time 

    fname = pathlib.Path(os.path.join(r'\\ad\dfs\botraders\alltraders\China_Avail\history', f))
    mtime = datetime.datetime.fromtimestamp(fname.stat().st_mtime)
    t_r['publish_datetime_et'] = mtime
    t_r['publish_datetime_et'] = t_r['publish_datetime_et'].dt.tz_localize('US/Eastern')
    
    # get CST publish datetime and datadate
    t_r['publish_datetime_cst'] = t_r['publish_datetime_et'].dt.tz_convert('Asia/Shanghai')
    t_r['publish_datetime_cst'] = t_r['publish_datetime_cst'].dt.tz_localize(None)
    t_r['datadate'] = pd.to_datetime(f.split('_')[3].replace('.csv','')) + pd.to_timedelta('1 day')
    
    # attach WIND ticker, get rid of SEDOLs that cannot be mapped to a ticker
    t_r = t_r.merge(o_bbg_sedol, on = ['Sedol'], how = 'left')
    t_r = t_r[t_r['ticker'].notnull()]
    
    # attach rmb price
    t_r = pd.merge_asof(t_r, i_rmb_px, by = ['ticker'], on = ['datadate'], allow_exact_matches = False)
    t_r['shortable_mc_rmb'] = t_r['shortable_shares'].multiply(t_r['c'])
    
    # format
    t_r = t_r.drop(columns = ['CCY','ReportDate','publish_datetime_et','c'])
    
    # merge fee
    t_r = t_r.merge(o_data_brk_lvl_fee_earliest, on = ['Broker', 'Sedol', 'ticker'], how = 'left')
    t_r = t_r[t_r['Fee'].notnull()]
    
    # weighted fee
    t_r['fee_x_shortable_shares'] = t_r['Fee'].multiply(t_r['shortable_shares'])
    t_r_grp = t_r.groupby(['ticker','datadate','publish_datetime_cst']).agg({'shortable_mc_rmb':sum,
                         'shortable_mc_usd':sum,'shortable_shares':sum,'fee_x_shortable_shares':sum}).reset_index()
    t_r_grp['fee'] = t_r_grp['fee_x_shortable_shares'].divide(t_r_grp['shortable_shares'])
    t_r_grp = t_r_grp[t_r_grp['shortable_shares']>0]
    t_r_grp = t_r_grp.drop(columns = ['fee_x_shortable_shares'])
    
    # append
    o_data_tk_lvl_nofee = o_data_tk_lvl_nofee.append(t_r_grp, ignore_index = True)
    o_data_brk_lvl_nofee = o_data_brk_lvl_nofee.append(t_r, ignore_index = True)
    
# combine fee files nad no-fee files, then output to csv
o_tk_lvl = o_data_tk_lvl_nofee.append(o_data_tk_lvl_fee, sort = False)
o_tk_lvl = o_tk_lvl.reset_index(drop = True)
o_tk_lvl['publish_datetime_cst'] = pd.to_datetime(o_tk_lvl['publish_datetime_cst'].dt.strftime('%Y-%m-%d %H:%M:%S'))
o_tk_lvl.to_parquet(r'S:\Data\China Data Hunt\cache\pWIND_strat_short_quota_tk_lvl.parquet')

o_brk_lvl = o_data_brk_lvl_nofee.append(o_data_brk_lvl_fee, sort = False)
o_brk_lvl = o_brk_lvl.reset_index(drop = True)
o_brk_lvl['publish_d
atetime_cst'] = pd.to_datetime(o_brk_lvl['publish_datetime_cst'].dt.strftime('%Y-%m-%d %H:%M:%S'))
o_brk_lvl.to_parquet(r'S:\Data\China Data Hunt\cache\pWIND_strat_short_quota_brk_lvl.parquet')

o_tk_lvl = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_strat_short_quota_tk_lvl.parquet')
o_brk_lvl = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_strat_short_quota_brk_lvl.parquet')



# get c_c_ret

i_c_c_ret = pw.get_wind_mkt_data(col_list = ['ticker', 'datadate', 'adjret'])
i_c_c_ret = i_c_c_ret.sort_values(['ticker', 'datadate'])
i_c_c_ret['adjret_l1d'] = i_c_c_ret.groupby('ticker')['adjret'].shift()
i_c_c_ret['adjret_bk'] = i_c_c_ret.groupby('datadate')['adjret'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values

i_c_c_ret['adjret_t5d'] = i_c_c_ret.groupby('ticker').rolling(5)['adjret'].sum().values
i_c_c_ret['adjret_t10d'] = i_c_c_ret.groupby('ticker').rolling(10)['adjret'].sum().values
i_c_c_ret['adjret_t20d'] = i_c_c_ret.groupby('ticker').rolling(20)['adjret'].sum().values
i_c_c_ret['adjret_t65d'] = i_c_c_ret.groupby('ticker').rolling(65)['adjret'].sum().values
i_c_c_ret['adjret_t130d'] = i_c_c_ret.groupby('ticker').rolling(130)['adjret'].sum().values
i_c_c_ret['adjret_t250d'] = i_c_c_ret.groupby('ticker').rolling(250)['adjret'].sum().values
i_c_c_ret = i_c_c_ret[i_c_c_ret['datadate']>='2014-04-11']
i_c_c_ret['adjret_t5d_bk'] = i_c_c_ret.groupby('datadate')['adjret_t5d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
i_c_c_ret['adjret_t10d_bk'] = i_c_c_ret.groupby('datadate')['adjret_t10d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
i_c_c_ret['adjret_t20d_bk'] = i_c_c_ret.groupby('datadate')['adjret_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
i_c_c_ret['adjret_t65d_bk'] = i_c_c_ret.groupby('datadate')['adjret_t65d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
i_c_c_ret['adjret_t130d_bk'] = i_c_c_ret.groupby('datadate')['adjret_t130d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
i_c_c_ret['adjret_t250d_bk'] = i_c_c_ret.groupby('datadate')['adjret_t250d'].apply(lambda x: yu.pdqcut(x,bins=10)).values


# combine
icom = i_sd_map.merge(o_tk_lvl, on = ['ticker', 'datadate'], how = 'left')

icom = icom.sort_values(['ticker','datadate'])
icom['quota_t60d_avg'] = icom.groupby('ticker').rolling(60)['shortable_mc_rmb'].mean().values
icom['quota_t60d_med'] = icom.groupby('ticker').rolling(60)['shortable_mc_rmb'].median().values
icom['quota_t60d_std'] = icom.groupby('ticker').rolling(60)['shortable_mc_rmb'].std().values
icom
['quota_z60'] = (icom['shortable_mc_rmb']-icom['quota_t60d_med']).divide(icom['quota_t60d_std'])
icom['quota_t20d_avg'] = icom.groupby('ticker').rolling(20)['shortable_mc_rmb'].mean().values
icom['quota_t20d_med'] = icom.groupby('ticker').rolling(20)['shortable_mc_rmb'].median().values
icom['quota_t20d_std'] = icom.groupby('ticker').rolling(20)['shortable_mc_rmb'].std().values
icom['quota_z20'] = (icom['shortable_mc_rmb']-icom['quota_t20d_med']).divide(icom['quota_t20d_std'])

icom['quota_t5d_sum'] = icom.groupby('ticker').rolling(5)['shortable_mc_rmb'].sum().values
icom['quota_t5d_sum_t60d_avg'] = icom.groupby('ticker').rolling(60)['quota_t5d_sum'].mean().values
icom['quota_t5d_sum_t60d_med'] = icom.groupby('ticker').rolling(60)['quota_t5d_sum'].median().values
icom['quota_t5d_sum_t60d_std'] = icom.groupby('ticker').rolling(60)['quota_t5d_sum'].std().values
icom['quota_t5d_sum_z60'] = (icom['quota_t5d_sum']-icom['quota_t5d_sum_t60d_med']).divide(icom['quota_t5d_sum_t60d_std'])

icom['uquota'] = icom['shortable_mc_rmb'].divide(icom['avgPVadj'])

icom['uquota_t60d_avg'] = icom.groupby('ticker').rolling(60)['uquota'].mean().values
icom['uquota_t60d_med'] = icom.groupby('ticker').rolling(60)['uquota'].median().values
icom['uquota_t60d_std'] = icom.groupby('ticker').rolling(60)['uquota'].std().values
icom['uquota_z60'] = (icom['uquota']-icom['uquota_t60d_med']).divide(icom['uquota_t60d_std'])

icom['uquota_t5d_sum'] = icom.groupby('ticker').rolling(5)['uquota'].sum().values
icom['uquota_t5d_sum_t60d_avg'] = icom.groupby('ticker').rolling(60)['uquota_t5d_sum'].mean().values
icom['uquota_t5d_sum_t60d_med'] = icom.groupby('ticker').rolling(60)['uquota_t5d_sum'].median().values
icom['uquota_t5d_sum_t60d_std'] = icom.groupby('ticker').rolling(60)['uquota_t5d_sum'].std().values
icom['uquota_t5d_sum_z60'] = (icom['uquota_t5d_sum']-icom['uquota_t5d_sum_t60d_med']).divide(icom['uquota_t5d_sum_t60d_std'])

icom = icom.merge(i_c_c_ret, on = ['datadate', 'ticker'], how = 'left')

#------------------------------------------------------------------------------
### idea 1: quota Zscore >+-2
#------------------------------------------------------------------------------


### low short quota Zscore
icom2 = icom.copy()
icom2.loc[icom2['quota_z60']<-2, 'sgnl'] = 1

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, sta
tic_data = i_sd) # -0.57 / -0.9

### high short quota Zscore
icom2 = icom.copy()
icom2.loc[icom2['quota_z60']>2, 'sgnl'] = 1

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 1.58 / 1.1


### high short quota Zscore, after sell off 
icom2 = icom.copy()
icom2.loc[(icom2['quota_z60']>2)&(icom2['adjret_t20d_bk']<=3), 'sgnl'] = 1

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 2.01 / 1.42


### high short quota Zscore, after sell off , hold 5 more days
icom2 = icom.copy()
icom2.loc[(icom2['quota_z60']>2)&(icom2['adjret_t20d_bk']<=3), 'sgnl'] = 1
icom2['sgnl'] = icom2.groupby('ticker')['sgnl'].ffill(limit=5)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 2.29 / 2.04


### high short quota Zscore, after sell off , hold 10 more days
icom2 = icom.copy()
icom2.loc[(icom2['quota_z60']>2)&(icom2['adjret_t20d_bk']<=3), 'sgnl'] = 1
icom2['sgnl'] = icom2.groupby('ticker')['sgnl'].ffill(limit=10)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 1.75 / 1.57

#------------------------------------------------------------------------------
### idea 2: rank (quota Zscore)
#------------------------------------------------------------------------------


### +ve & -ve short quota Zscore
icom2 = icom.copy()
icom2.loc[icom2['quota_z60']>3, 'quota_z60'] = 3
icom2.loc[icom2['quota_z60']<-3, 'quota_z60'] = -3
icom2['sgnl'] = icom2.groupby('datadate')['quota_z60'].apply(lambda x: yu.uniformed_rank(x)).values

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 1.13 / 0.82


### +ve short quota Zscore
icom2 = icom.copy()
icom2.loc[icom2['quota_z60']>3, 'quota_z60'] = 3

icom2.loc[icom2['quota_z60']<-3, 'quota_z60'] = -3
icom2['sgnl'] = icom2.groupby('datadate')['quota_z60'].apply(lambda x: yu.uniformed_rank(x)).values

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['sgnl']>0)].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 0.82 / 0.28

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['sgnl']>0.8)].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 1.42 / 0.89


### -ve short quota Zscore
icom2 = icom.copy()
icom2.loc[icom2['quota_z60']>3, 'quota_z60'] = 3
icom2.loc[icom2['quota_z60']<-3, 'quota_z60'] = -3
icom2['sgnl'] = icom2.groupby('datadate')['quota_z60'].apply(lambda x: yu.uniformed_rank(x)).values

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['sgnl']<0)].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # -0.26 / -0.78



#------------------------------------------------------------------------------
### idea 3: PV-adj quota Zscore >+2
#------------------------------------------------------------------------------



### high short quota Zscore, after sell off , hold 5 more days
icom2 = icom.copy()
icom2.loc[(icom2['uquota_z60']>2)&(icom2['adjret_t20d_bk']<=3), 'sgnl'] = 1
icom2['sgnl'] = icom2.groupby('ticker')['sgnl'].ffill(limit=5)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 1.86 / 1.62 vs benchmark 2.29 / 2.04

### high t5d short uquota Zscore, after sell off , hold 5 more days
icom2 = icom.copy()
icom2.loc[(icom2['uquota_t5d_sum_z60']>2)&(icom2['adjret_t20d_bk']<=3), 'sgnl'] = 1
icom2['sgnl'] = icom2.groupby('ticker')['sgnl'].ffill(limit=5)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 2.23 / 2.0 vs benchmark 2.29 / 2.04


#------------------------------------------------------------------------------
### idea 3:
 t5d quota Zscore >+2
#------------------------------------------------------------------------------


### high t5d short quota Zscore, after sell off , hold 5 more days
icom2 = icom.copy()
icom2.loc[(icom2['quota_t5d_sum_z60']>2)&(icom2['adjret_t20d_bk']<=3), 'sgnl'] = 1
icom2['sgnl'] = icom2.groupby('ticker')['sgnl'].ffill(limit=5)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 2.42 / 2.19 vs benchmark 2.29 / 2.04


### high t5d short quota Zscore, after sell off , hold 5 more days
icom2 = icom.copy()
icom2.loc[(icom2['quota_t5d_sum_z60']>2)&(icom2['adjret_t20d_bk']<=0), 'sgnl'] = 1
icom2['sgnl'] = icom2.groupby('ticker')['sgnl'].ffill(limit=5)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 2.37 / 2.21 vs benchmark 2.29 / 2.04




### high t5d short quota Zscore, after sell off , hold 5 more days
icom2 = icom.copy()
icom2.loc[(icom2['quota_t5d_sum_z60']>2)&(icom2['adjret_t20d_bk']>=9), 'sgnl'] = -1
icom2['sgnl'] = icom2.groupby('ticker')['sgnl'].ffill(limit=5)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 0.17 / 0.03



### low t5d short quota Zscore, after rally , short,  hold 5 more days
icom2 = icom.copy()
icom2.loc[(icom2['quota_t5d_sum_z60']<-2)&(icom2['adjret_t20d_bk']>=9), 'sgnl'] = -1
icom2['sgnl'] = icom2.groupby('ticker')['sgnl'].ffill(limit=5)

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) # 1.08 / 1.02


