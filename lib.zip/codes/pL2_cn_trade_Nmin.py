﻿#$%^&* pL2_cn_trade_Nmin.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 17 12:19:03 2022

@author: thzhang
"""

import os 

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime
from sqlalchemy import create_engine

# this has the following signals
# pq correlation
# skewness


### i_sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')


### get o2c return

i_o2c = yu.get_sql('''SELECT [datadate],[ticker],[close_1hr_vwap]/[open_1hr_vwap]-1 as o2c_ret FROM [CNDBPROD].[dbo].[TRTH_OPENCLOSE_CN]''')
c_sh = i_o2c['ticker'].str[0].isin(['6'])
c_sz = i_o2c['ticker'].str[0].isin(['0', '3'])
i_o2c.loc[c_sh, 'ticker'] = i_o2c.loc[c_sh, 'ticker'] + '.SH'
i_o2c.loc[c_sz, 'ticker'] = i_o2c.loc[c_sz, 'ticker'] + '.SZ'


### get intraday "mild" return

i_mild = yu.get_q("(get `:/export/datadev/Data/SHSZ/TRADE_Nmin_metrics/trade_5min_retrun_decomp_sz),(get `:/export/datadev/Data/SHSZ/TRADE_Nmin_metrics/trade_5min_retrun_decomp_sh)")
i_mild['datadate'] = pd.to_datetime(i_mild['date'])
i_mild['code'] = i_mild['code'].str.decode('utf8')
c_sh = i_mild['code'].str[0].isin(['6'])
c_sz = i_mild['code'].str[0].isin(['0', '3'])
i_mild.loc[c_sh, 'ticker'] = i_mild.loc[c_sh, 'code'] + '.SH'
i_mild.loc[c_sz, 'ticker'] = i_mild.loc[c_sz, 'code'] + '.SZ'
i_mild = i_mild.sort_values(['ticker', 'datadate'])



### get data: 1min P-Q correlation
# code is in Instructure/q/L2_cn_trade_1min_query.q

files = os.listdir(r'S:\Data\China Data Hunt\TRTHv2\cache_query_ouput')

i_1min_metrics = pd.concat([pd.read_csv(os.path.join(r'S:\Data\China Data Hunt\TRTHv2\cache_query_ouput', f), sep = '|') for f in files], axis = 0)
i_1min_metrics['ticker'] = i_1min_metrics['ric'].str.replace('SS','SH')
i_1min_metrics['datadate'] = pd.to_datetime(i_1min_metrics['date'])

# trailing Nd 

s_1min_metrics = []
for dt in pd.date_range(start = '2015-02-01', end = '2021-09-24'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    t_min_metrics_t60d = i_1min_metrics[(i_1min_metrics['datadate']<=dt)&(i_1min_metrics['datadate']>=dt-pd.to_timedelta('84 days'))]
    t_min_metrics_t40d = t_min_metrics_t60d[(t_min_metrics_t60d['datadate']<=dt)&(t_min_metrics_t60d['datadate']>=dt-pd.to_timedelta('56 days'))]
    t_min_metrics_t20d = t_min_metrics_t40d[(t_min_metrics_t40d['datadate']<=dt)&(t_min_metrics_t40d['datadate']>=dt-pd.to_timedelta('28 days'))]
    t_min_metrics_t10d = t_min_metrics_t20d[(t_min_metrics_t20d['datadate']<=dt)&(t_min_metrics_t20d['datadate']>=dt-p
d.to_timedelta('14 days'))]
    t_min_metrics_t5d = t_min_metrics_t10d[(t_min_metrics_t10d['datadate']<=dt)&(t_min_metrics_t10d['datadate']>=dt-pd.to_timedelta('7 days'))]
    
    s60 = t_min_metrics_t60d.groupby('ticker').agg({'p_sum': sum,'p2_sum': sum,
                                                    'q_pct_sum': sum,'q_pct2_sum': sum,
                                                    'pq_pct_sum': sum,'i_cnt': sum})
    s60['p_mean'] = s60['p_sum'].divide(s60['i_cnt'])
    s60['q_pct_mean'] = s60['q_pct_sum'].divide(s60['i_cnt'])
    s60['corr_nom'] = s60['pq_pct_sum'] - s60['p_sum'].multiply(s60['q_pct_mean']) - s60['q_pct_sum'].multiply(s60['p_mean']) + s60['p_sum'].multiply(s60['q_pct_sum']).divide(s60['i_cnt'])
    s60['corr_denom_p'] = np.sqrt(s60['p2_sum'] - s60['p_mean'].pow(2).multiply(s60['i_cnt'])*2 + s60['p_mean'].pow(2).multiply(s60['i_cnt']))
    s60['corr_denom_q_pct'] = np.sqrt(s60['q_pct2_sum'] - s60['q_pct_mean'].pow(2).multiply(s60['i_cnt'])*2 + s60['q_pct_mean'].pow(2).multiply(s60['i_cnt']))    
    s60['pq_pct_corr_t60d'] = s60['corr_nom'].divide(s60['corr_denom_p']).divide(s60['corr_denom_q_pct'])
    s60 = s60.reset_index()
    
    s40 = t_min_metrics_t40d.groupby('ticker').agg({'p_sum': sum,'p2_sum': sum,
                                                    'q_pct_sum': sum,'q_pct2_sum': sum,
                                                    'pq_pct_sum': sum,'i_cnt': sum})
    s40['p_mean'] = s40['p_sum'].divide(s40['i_cnt'])
    s40['q_pct_mean'] = s40['q_pct_sum'].divide(s40['i_cnt'])
    s40['corr_nom'] = s40['pq_pct_sum'] - s40['p_sum'].multiply(s40['q_pct_mean']) - s40['q_pct_sum'].multiply(s40['p_mean']) + s40['p_sum'].multiply(s40['q_pct_sum']).divide(s40['i_cnt'])
    s40['corr_denom_p'] = np.sqrt(s40['p2_sum'] - s40['p_mean'].pow(2).multiply(s40['i_cnt'])*2 + s40['p_mean'].pow(2).multiply(s40['i_cnt']))
    s40['corr_denom_q_pct'] = np.sqrt(s40['q_pct2_sum'] - s40['q_pct_mean'].pow(2).multiply(s40['i_cnt'])*2 + s40['q_pct_mean'].pow(2).multiply(s40['i_cnt']))    
    s40['pq_pct_corr_t40d'] = s40['corr_nom'].divide(s40['corr_denom_p']).divide(s40['corr_denom_q_pct'])
    s40 = s40.reset_index()
    
    s20 = t_min_metrics_t20d.groupby('ticker').agg({'p_sum': sum,'p2_sum': sum,
                                                    'q_pct_sum': sum,'q_dpct_sum': sum, 'odq_pct_sum': sum, 
                                                    'q_pct2_sum': sum,'q_dpct2_sum': sum, 'odq_pct2_sum': sum, 
                
                                    'pq_pct_sum': sum,'pq_dpct_sum': sum, 'podq_pct_sum': sum,
                                                    'i_cnt': sum})
    s20['p_mean'] = s20['p_sum'].divide(s20['i_cnt'])
    s20['q_pct_mean'] = s20['q_pct_sum'].divide(s20['i_cnt'])
    s20['odq_pct_mean'] = s20['odq_pct_sum'].divide(s20['i_cnt'])
    s20['corr_nom'] = s20['pq_pct_sum'] - s20['p_sum'].multiply(s20['q_pct_mean']) - s20['q_pct_sum'].multiply(s20['p_mean']) + s20['p_sum'].multiply(s20['q_pct_sum']).divide(s20['i_cnt'])
    s20['corr_denom_p'] = np.sqrt(s20['p2_sum'] - s20['p_mean'].pow(2).multiply(s20['i_cnt'])*2 + s20['p_mean'].pow(2).multiply(s20['i_cnt']))
    s20['corr_denom_q_pct'] = np.sqrt(s20['q_pct2_sum'] - s20['q_pct_mean'].pow(2).multiply(s20['i_cnt'])*2 + s20['q_pct_mean'].pow(2).multiply(s20['i_cnt']))    
    s20['pq_pct_corr_t20d'] = s20['corr_nom'].divide(s20['corr_denom_p']).divide(s20['corr_denom_q_pct'])
    
    s20['q_dpct_mean'] = s20['q_dpct_sum'].divide(s20['i_cnt'])
    s20['corr_nom'] = s20['pq_dpct_sum'] - s20['p_sum'].multiply(s20['q_dpct_mean']) - s20['q_dpct_sum'].multiply(s20['p_mean']) + s20['p_sum'].multiply(s20['q_dpct_sum']).divide(s20['i_cnt'])
    s20['corr_denom_p'] = np.sqrt(s20['p2_sum'] - s20['p_mean'].pow(2).multiply(s20['i_cnt'])*2 + s20['p_mean'].pow(2).multiply(s20['i_cnt']))
    s20['corr_denom_q_pct'] = np.sqrt(s20['q_dpct2_sum'] - s20['q_dpct_mean'].pow(2).multiply(s20['i_cnt'])*2 + s20['q_dpct_mean'].pow(2).multiply(s20['i_cnt']))    
    s20['pq_dpct_corr_t20d'] = s20['corr_nom'].divide(s20['corr_denom_p']).divide(s20['corr_denom_q_pct'])
    
    s20['odq_pct_mean'] = s20['odq_pct_sum'].divide(s20['i_cnt'])
    s20['corr_nom'] = s20['podq_pct_sum'] - s20['p_sum'].multiply(s20['odq_pct_mean']) - s20['odq_pct_sum'].multiply(s20['p_mean']) + s20['p_sum'].multiply(s20['odq_pct_sum']).divide(s20['i_cnt'])
    s20['corr_denom_p'] = np.sqrt(s20['p2_sum'] - s20['p_mean'].pow(2).multiply(s20['i_cnt'])*2 + s20['p_mean'].pow(2).multiply(s20['i_cnt']))
    s20['corr_denom_q_pct'] = np.sqrt(s20['odq_pct2_sum'] - s20['odq_pct_mean'].pow(2).multiply(s20['i_cnt'])*2 + s20['odq_pct_mean'].pow(2).multiply(s20['i_cnt']))    
    s20['podq_pct_corr_t20d'] = s20['corr_nom'].divide(s20['corr_denom_p']).divide(s20['corr_denom_q_pct'])
    
    s20 = s20.reset_index()
    
    
    s = s60[['ticker','pq_pct_corr_t60d']].merge(s40[['ticker','pq_pct_corr_t40d']], on = ['ticker'], how = 'outer')
    s = s.merge(s20[['ticker'
,'pq_pct_corr_t20d','pq_dpct_corr_t20d','podq_pct_corr_t20d']], on = ['ticker'], how = 'outer')
    #s = s.merge(s10[['ticker','pq_pct_corr_t10d']], on = ['ticker'], how = 'outer')
    #s = s.merge(s5[['ticker','pq_pct_corr_t5d']], on = ['ticker'], how = 'outer')
    s['datadate'] = dt
    
    s_1min_metrics.append(s)
    
    
s_1min_metrics = pd.concat(s_1min_metrics, axis = 0)



###  get data: DOWNILLIQ and UPILLIQ

i_updn = yu.get_q('''t1: (get `:/export/datadev/Data/SHSZ/TRADE_Nmin_metrics/trade_5min_illiq_sh),(get `:/export/datadev/Data/SHSZ/TRADE_Nmin_metrics/trade_5min_illiq_sz);
                     t1: select date,code,coef_proactBuy,coef_proactSell,coef_pct_proactBuy,coef_pct_proactSell from t1;
                     t1''')
i_updn['code'] = i_updn['code'].str.decode('utf8')
c_sh = i_updn['code'].str[0].isin(['6'])
c_sz = i_updn['code'].str[0].isin(['0', '3'])
i_updn.loc[c_sh, 'ticker'] = i_updn.loc[c_sh, 'code'] + '.SH'
i_updn.loc[c_sz, 'ticker'] = i_updn.loc[c_sz, 'code'] + '.SZ'
i_updn['datadate'] = pd.to_datetime(i_updn['date'])
i_updn = i_updn.sort_values(['ticker', 'datadate'])


icomupdn = i_sd.merge(i_updn, on = ['ticker', 'datadate'], how = 'left')
COLS = ['SRISK', 'BETA', 'SIZE', 'RESVOL']

icomupdn['coef_proactBuy_orth'] = icomupdn.groupby('datadate')[COLS+['coef_proactBuy']].apply(lambda x: yu.orthogonalize_cn(x['coef_proactBuy'], x[COLS])).values
icomupdn['coef_proactBuy_orth_bk'] = icomupdn.groupby('datadate')['coef_proactBuy_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomupdn['coef_proactBuy_bk'] = icomupdn.groupby('datadate')['coef_proactBuy'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icomupdn['coef_proactSell_orth'] = icomupdn.groupby('datadate')[COLS+['coef_proactSell']].apply(lambda x: yu.orthogonalize_cn(x['coef_proactSell'], x[COLS])).values
icomupdn['coef_proactSell_orth_bk'] = icomupdn.groupby('datadate')['coef_proactSell_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomupdn['coef_proactSell_bk'] = icomupdn.groupby('datadate')['coef_proactSell'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icomupdn['coef_pct_proactBuy_orth'] = icomupdn.groupby('datadate')[COLS+['coef_pct_proactBuy']].apply(lambda x: yu.orthogonalize_cn(x['coef_pct_proactBuy'], x[COLS])).values
icomupdn['coef_pct_proactBuy_orth_bk'] = icomupdn.groupby('datadate')['coef_pct_proactBuy'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomupdn['coef_pct_proactBuy_bk'] = icomupdn.groupby('datadate')['coef_pct_proactBuy'].apply(lambda x: yu.pdq
cut(x,bins=10)).values

icomupdn['coef_pct_proactSell_orth'] = icomupdn.groupby('datadate')[COLS+['coef_pct_proactSell']].apply(lambda x: yu.orthogonalize_cn(x['coef_pct_proactSell'], x[COLS])).values
icomupdn['coef_pct_proactSell_orth_bk'] = icomupdn.groupby('datadate')['coef_pct_proactSell'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomupdn['coef_pct_proactSell_bk'] = icomupdn.groupby('datadate')['coef_pct_proactSell'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icomupdn, ['coef_proactBuy_orth_bk'], 'coef_proactBuy_orth') # random
yu.create_cn_3x3(icomupdn, ['coef_proactBuy_bk'], 'coef_proactBuy') # less mono: 0 -1 +2
yu.create_cn_3x3(icomupdn, ['coef_proactSell_orth_bk'], 'coef_proactSell_orth') # random
yu.create_cn_3x3(icomupdn, ['coef_proactSell_bk'], 'coef_proactSell') 
yu.create_cn_3x3(icomupdn, ['coef_pct_proactBuy_orth_bk'], 'coef_pct_proactBuy_orth') # less mono: -1 +2 -3.5
yu.create_cn_3x3(icomupdn, ['coef_pct_proactBuy_bk'], 'coef_pct_proactBuy') 
yu.create_cn_3x3(icomupdn, ['coef_pct_proactSell_orth_bk'], 'coef_pct_proactSell_orth') # less mono: -4 +2 +1
yu.create_cn_3x3(icomupdn, ['coef_pct_proactSell_bk'], 'coef_pct_proactSell') 




### get data: Nmin bars

i_nmin = yu.get_q('''
                  (get `:/export/datadev/Data/SHSZ/TRADE_Nmin_metrics/trade_nmin_metrics_sh), (get `:/export/datadev/Data/SHSZ/TRADE_Nmin_metrics/trade_nmin_metrics_sz)
                  ''', port = 5006)
i_nmin['code'] = i_nmin['code'].str.decode('utf8')
c_sh = i_nmin['code'].str[0].isin(['6'])
c_sz = i_nmin['code'].str[0].isin(['0', '3'])
i_nmin.loc[c_sh, 'ticker'] = i_nmin.loc[c_sh, 'code'] + '.SH'
i_nmin.loc[c_sz, 'ticker'] = i_nmin.loc[c_sz, 'code'] + '.SZ'
i_nmin['datadate'] = pd.to_datetime(i_nmin['date'])
i_nmin = i_nmin.sort_values(['ticker', 'datadate'])



i_nmin['skew_5min'] = i_nmin['sum_r3_5min'] / (i_nmin['sum_r2_5min']**1.5) * np.sqrt(i_nmin['cnt_notnull_5min'])
i_nmin['skew_5min_t10d'] = i_nmin.groupby('ticker').rolling(datetime.timedelta(days=14),on='datadate')['skew_5min'].mean().values
i_nmin['skew_5min_t20d'] = i_nmin.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['skew_5min'].mean().values
i_nmin['skew_5min_t40d'] = i_nmin.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['skew_5min'].mean().values
i_nmin['skew_5min_t60d'] = i_nmin.groupby('ticker').rolling(datetime.timedelta(days=84),on='datadate')['skew_5min'].mean().values

i_nmin['skew_5min_09301000'] = i_nmin['sum_r3_5min_093
01000'] / (i_nmin['sum_r2_5min_09301000']**1.5) * np.sqrt(i_nmin['cnt_notnull_5min_09301000'])
i_nmin['skew_5min_09301000_t40d'] = i_nmin.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['skew_5min_09301000'].mean().values

i_nmin['skew_5min_09301430'] = i_nmin['sum_r3_5min_09301430'] / (i_nmin['sum_r2_5min_09301430']**1.5) * np.sqrt(i_nmin['cnt_notnull_5min_09301430'])
i_nmin['skew_5min_09301430_t40d'] = i_nmin.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['skew_5min_09301430'].mean().values

i_nmin['skew_5min_10001500'] = i_nmin['sum_r3_5min_10001500'] / (i_nmin['sum_r2_5min_10001500']**1.5) * np.sqrt(i_nmin['cnt_notnull_5min_10001500'])
i_nmin['skew_5min_10001500_t40d'] = i_nmin.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['skew_5min_10001500'].mean().values

i_nmin['skew_5min_14301500'] = i_nmin['sum_r3_5min_14301500'] / (i_nmin['sum_r2_5min_14301500']**1.5) * np.sqrt(i_nmin['cnt_notnull_5min_14301500'])
i_nmin['skew_5min_14301500_t40d'] = i_nmin.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['skew_5min_14301500'].mean().values

i_nmin['r_5min_std_t20d'] = i_nmin.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['r_5min_std'].mean().values



s_nmin = []
for dt in pd.date_range(start = '2017-02-01', end = '2020-12-31'):
    print(dt.strftime('%Y%m%d'), end= ' ')
    
    t_nmin_t20d = i_nmin[(i_nmin['datadate']>=dt - pd.to_timedelta('28 days')) & (i_nmin['datadate']<=dt)]
    
    t_nmin_t20d_skew = t_nmin_t20d.groupby('ticker')[['sum_r2_10min','sum_r3_10min','cnt_notnull_10min']].\
                            apply(lambda x: x['sum_r3_10min'].sum() / (x['sum_r2_10min'].sum()**1.5) * np.sqrt(x['cnt_notnull_10min'].sum()) )
    t_nmin_t20d_skew = t_nmin_t20d_skew.reset_index()
    t_nmin_t20d_skew.columns = ['ticker', 'skew_10min_t20d_v2']
    
    t_nmin_t40d = i_nmin[(i_nmin['datadate']>=dt - pd.to_timedelta('56 days')) & (i_nmin['datadate']<=dt)]
    
    t_nmin_t40d_skew = t_nmin_t40d.groupby('ticker')[['sum_r2_5min','sum_r3_5min','cnt_notnull_5min']].\
                            apply(lambda x: x['sum_r3_5min'].sum() / (x['sum_r2_5min'].sum()**1.5) * np.sqrt(x['cnt_notnull_5min'].sum()) )
    t_nmin_t40d_skew = t_nmin_t40d_skew.reset_index()
    t_nmin_t40d_skew.columns = ['ticker', 'skew_5min_t40d_v2']
    
    t_nmin_t40d_skew_09301000 = t_nmin_t40d.groupby('ticker')[['sum_r2_5min_09301000','sum_r3_5min_09301000','cnt_notnull_5min_09301000
']].\
                            apply(lambda x: x['sum_r3_5min_09301000'].sum() / (x['sum_r2_5min_09301000'].sum()**1.5) * np.sqrt(x['cnt_notnull_5min_09301000'].sum()) )
    t_nmin_t40d_skew_09301000 = t_nmin_t40d_skew_09301000.reset_index()
    t_nmin_t40d_skew_09301000.columns = ['ticker', 'skew_10min_t40d_09301000_v2']
    
    t_nmin_t40d_skew_09301430 = t_nmin_t40d.groupby('ticker')[['sum_r2_5min_09301430','sum_r3_5min_09301430','cnt_notnull_5min_09301430']].\
                            apply(lambda x: x['sum_r3_5min_09301430'].sum() / (x['sum_r2_5min_09301430'].sum()**1.5) * np.sqrt(x['cnt_notnull_5min_09301430'].sum()) )
    t_nmin_t40d_skew_09301430 = t_nmin_t40d_skew_09301430.reset_index()
    t_nmin_t40d_skew_09301430.columns = ['ticker', 'skew_10min_t40d_09301430_v2']
    
    t_nmin_t40d_skew_10001500 = t_nmin_t40d.groupby('ticker')[['sum_r2_5min_10001500','sum_r3_5min_10001500','cnt_notnull_5min_10001500']].\
                            apply(lambda x: x['sum_r3_5min_10001500'].sum() / (x['sum_r2_5min_10001500'].sum()**1.5) * np.sqrt(x['cnt_notnull_5min_10001500'].sum()) )
    t_nmin_t40d_skew_10001500 = t_nmin_t40d_skew_10001500.reset_index()
    t_nmin_t40d_skew_10001500.columns = ['ticker', 'skew_10min_t40d_10001500_v2']
    
    t_nmin_t40d_skew_14301500 = t_nmin_t40d.groupby('ticker')[['sum_r2_5min_14301500','sum_r3_5min_14301500','cnt_notnull_5min_14301500']].\
                            apply(lambda x: x['sum_r3_5min_14301500'].sum() / (x['sum_r2_5min_14301500'].sum()**1.5) * np.sqrt(x['cnt_notnull_5min_14301500'].sum()) )
    t_nmin_t40d_skew_14301500 = t_nmin_t40d_skew_14301500.reset_index()
    t_nmin_t40d_skew_14301500.columns = ['ticker', 'skew_10min_t40d_14301500_v2']
    
    s_nmin_skew = t_nmin_t20d_skew.merge(t_nmin_t40d_skew, on = 'ticker', how = 'outer')
    s_nmin_skew = s_nmin_skew.merge(t_nmin_t40d_skew_09301000, on = 'ticker', how = 'outer')
    s_nmin_skew = s_nmin_skew.merge(t_nmin_t40d_skew_09301430, on = 'ticker', how = 'outer')
    s_nmin_skew = s_nmin_skew.merge(t_nmin_t40d_skew_10001500, on = 'ticker', how = 'outer')
    s_nmin_skew = s_nmin_skew.merge(t_nmin_t40d_skew_14301500, on = 'ticker', how = 'outer')
    s_nmin_skew['datadate'] = dt
    s_nmin.append(s_nmin_skew)
s_nmin = pd.concat(s_nmin, axis = 0)


icomskew = i_sd.merge(i_nmin, on = ['ticker','datadate'], how = 'left')
icomskew = icomskew.merge(i_o2c, on = ['ticker','datadate'], how = 'left')
icomskew = icomskew.merge(i_mild, on = ['ticker','datada
te'], how = 'left')
icomskew = icomskew.sort_values(['ticker','datadate'])
COLS = ['SRISK', 'BETA', 'SIZE', 'RESVOL', 'LIQUIDTY']



# mild return 

icomskew['avg_xtrm_lnr'] = icomskew['avg_xtrm_lnr'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
icomskew['avg_xtrm_lnr_t20d'] = icomskew.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['avg_xtrm_lnr'].mean().values
icomskew['avg_xtrm_lnr_t20d_bk'] = icomskew.groupby('datadate')['avg_xtrm_lnr_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomskew['avg_xtrm_lnr_bk'] = icomskew.groupby('datadate')['avg_xtrm_lnr'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomskew['avg_mild_lnr'] = icomskew['avg_mild_lnr'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
icomskew['avg_mild_lnr_bk'] = icomskew.groupby('datadate')['avg_mild_lnr'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icomskew, ['avg_mild_lnr_bk'], 'avg_mild_lnr') # -0.5 +2 -5.5
# yu.create_cn_3x3(icomskew, ['avg_xtrm_lnr_bk'], 'avg_xtrm_lnr') # random
# yu.create_cn_3x3(icomskew, ['avg_xtrm_lnr_t20d_bk'], 'avg_xtrm_lnr_t20d') # random


# intrday return vol


icomskew['r_5min_std_t20d'] = icomskew.groupby('ticker').rolling(datetime.timedelta(days=20),on='datadate')['r_5min_std'].mean().values
icomskew['r_5min_std_t20d_bk'] = icomskew.groupby('datadate')['r_5min_std_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icomskew, ['r_5min_std_t20d_bk'], 'r_5min_std_t20d') # A-shaped

icomskew['r_5min_std_dv_t20d'] = icomskew['r_5min_std'].divide(icomskew['r_5min_std_t20d'])
icomskew['r_5min_std_dv_t20d_bk'] = icomskew.groupby('datadate')['r_5min_std_dv_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icomskew, ['r_5min_std_dv_t20d_bk'], 'r_5min_std_dv_t20d') # A-shaped

icomskew['r_5min_std_bk'] = icomskew.groupby('datadate')['r_5min_std'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomskew['r_5min_std_orth'] = icomskew.groupby('datadate')[COLS+['r_5min_std']].apply(lambda x: yu.orthogonalize_cn(x['r_5min_std'],x[COLS])).values
icomskew['r_5min_std_orth_bk'] = icomskew.groupby('datadate')['r_5min_std_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icomskew, ['r_5min_std_bk'], 'r_5min_std') # A-shaped -2.5 +3 -5
# yu.create_cn_3x3(icomskew, ['r_5min_std_orth_bk'], 'r_5min_std_orth') # -1 +2 -6

icomskew['o2c_t20d'] = icomskew.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['o2c_ret'].mean().values
icomskew['o2c_t20d_rk'] = icomsk
ew.groupby('datadate')['o2c_t20d'].apply(yu.uniformed_rank).values
icomskew['o2c_t20d_bk'] = icomskew.groupby('datadate')['o2c_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

# yu.create_cn_3x3(icomskew, ['o2c_t20d_bk'], 'o2c_t20d') # mono: +2 -4.5
# yu.create_cn_3x3(icomskew[icomskew['o2c_t20d_bk']>=8], ['r_5min_std_bk'], 'r_5min_std') # random
# yu.create_cn_3x3(icomskew[icomskew['o2c_t20d_bk']<=1], ['r_5min_std_bk'], 'r_5min_std') # A-shaped




# skew 

icomskew['skew_5min_t10d_bk'] = icomskew.groupby('datadate')['skew_5min_t10d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icomskew, ['skew_5min_t10d_bk'], 'skew_5min_t10d') # mono: +1 -5
icomskew['skew_5min_t20d_bk'] = icomskew.groupby('datadate')['skew_5min_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icomskew, ['skew_5min_t20d_bk'], 'skew_5min_t20d') # less mono: +1 +3 -5
icomskew['skew_5min_t40d_sgnl'] = -icomskew.groupby('datadate')['skew_5min_t40d'].apply(yu.uniformed_rank).values
icomskew['skew_5min_t40d_bk'] = icomskew.groupby('datadate')['skew_5min_t40d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icomskew, ['skew_5min_t40d_bk'], 'skew_5min_t40d') # mono: +2 -4.5
icomskew['skew_5min_t60d_bk'] = icomskew.groupby('datadate')['skew_5min_t60d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icomskew, ['skew_5min_t60d_bk'], 'skew_5min_t60d') # less mono: +1 +1.5 -4
icomskew['skew_10min_t20d_bk'] = icomskew.groupby('datadate')['skew_10min_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icomskew, ['skew_10min_t20d_bk'], 'skew_10min_t20d') # less mono: +1 +2 -5

icomskew['skew_5min_09301000_t40d_bk'] = icomskew.groupby('datadate')['skew_5min_09301000_t40d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomskew['skew_5min_09301430_t40d_bk'] = icomskew.groupby('datadate')['skew_5min_09301430_t40d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomskew['skew_5min_10001500_bk'] = icomskew.groupby('datadate')['skew_5min_10001500'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomskew['skew_5min_10001500_orth'] = icomskew.groupby('datadate')[COLS+['skew_5min_10001500']].apply(lambda x: yu.orthogonalize_cn(x['skew_5min_10001500'],x[COLS])).values
icomskew['skew_5min_10001500_orth_sgnl'] = -icomskew.groupby('datadate')['skew_5min_10001500_orth'].apply(yu.uniformed_rank).values
icomskew['skew_5min_10001500_sgnl'] = -icomskew.groupby('datadate')['skew_5min_10001500'].apply(yu.uniformed_rank).values
icomskew['ske
w_5min_10001500_t40d_bk'] = icomskew.groupby('datadate')['skew_5min_10001500_t40d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomskew['skew_5min_10001500_t40d_orth'] = icomskew.groupby('datadate')[COLS+['skew_5min_10001500_t40d']].apply(lambda x: yu.orthogonalize_cn(x['skew_5min_10001500_t40d'],x[COLS])).values
icomskew['skew_5min_10001500_t40d_orth_bk'] = icomskew.groupby('datadate')['skew_5min_10001500_t40d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomskew['skew_5min_10001500_t40d_sgnl'] = -icomskew.groupby('datadate')['skew_5min_10001500_t40d'].apply(yu.uniformed_rank).values
icomskew['skew_5min_10001500_t40d_orth_sgnl'] = -icomskew.groupby('datadate')['skew_5min_10001500_t40d_orth'].apply(yu.uniformed_rank).values
icomskew['skew_5min_14301500_t40d_bk'] = icomskew.groupby('datadate')['skew_5min_14301500_t40d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icomskew, ['skew_5min_10001500_bk'], 'skew_5min_10001500') # +1 -5
yu.create_cn_3x3(icomskew, ['skew_5min_09301000_t40d_bk'], 'skew_5min_09301000_t40d') # random
yu.create_cn_3x3(icomskew, ['skew_5min_09301430_t40d_bk'], 'skew_5min_09301430_t40d') # less mono: +1 +2 -4
yu.create_cn_3x3(icomskew, ['skew_5min_10001500_t40d_bk'], 'skew_5min_10001500_t40d') # mono: +4 -8
yu.create_cn_3x3(icomskew, ['skew_5min_14301500_t40d_bk'], 'skew_5min_14301500_t40d') # less mono: +1 -2
yu.create_cn_3x3(icomskew, ['skew_5min_10001500_t40d_orth_bk'], 'skew_5min_10001500_t40d_orth') # mono +5 -9 ###!!!



o_1 = yu.bt_cn_15(icomskew[(icomskew['datadate']<='2020-12-31')].\
            dropna(subset=['skew_5min_t40d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'skew_5min_t40d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.92 / -0.4
o_1 = yu.bt_cn_15(icomskew[(icomskew['datadate']<='2020-12-31')].\
            dropna(subset=['skew_5min_10001500_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'skew_5min_10001500_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.82/-20
o_1 = yu.bt_cn_15(icomskew[(icomskew['datadate']<='2020-12-31')].\
            dropna(subset=['skew_5min_10001500_t40d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'skew_5min_10001500_t40d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.35 / 1.15
o_1 = yu.bt_cn_15(icomskew[(icomskew['datadate']<='2020-12-31')].\
            dropna(subset=['skew_5min_10001500_orth_sgnl','BarrRet_CLIP_USD+1d']
).drop_duplicates(subset=['ticker','datadate']),
            'skew_5min_10001500_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.76 / -19
o_1 = yu.bt_cn_15(icomskew[(icomskew['datadate']<='2020-12-31')].\
            dropna(subset=['skew_5min_10001500_t40d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'skew_5min_10001500_t40d_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.37 / 1.23 ###!!!


# to sql
icomskew['Ticker'] = icomskew['ticker'].str[:6]
icomskew['DataDate'] = icomskew['datadate']
param_engine = create_engine('mssql+pyodbc://summitsqldb_cndbdev') 
icomskew[['Ticker','DataDate','skew_5min_10001500_t40d_orth_sgnl']].to_sql('F001_skew_LS_MA', param_engine , index = False, if_exists = 'replace', chunksize = 10000)

# to sql
icomskew['Ticker'] = icomskew['ticker'].str[:6]
icomskew['DataDate'] = icomskew['datadate']
param_engine = create_engine('mssql+pyodbc://summitsqldb_cndbdev') 
icomskew[['Ticker','DataDate','skew_5min_10001500_orth_sgnl']].to_sql('F001_skew_LS_1D', param_engine , index = False, if_exists = 'replace', chunksize = 10000)





cols = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icomskew['skew_5min_t40d_orth'] = icomskew.groupby('datadate')[cols+['skew_5min_t40d']].apply(lambda x: yu.orthogonalize_cn(x['skew_5min_t40d'], x[cols])).values
icomskew['skew_5min_t40d_orth_sgnl'] = -icomskew.groupby('datadate')['skew_5min_t40d_orth'].apply(yu.uniformed_rank).values
icomskew['skew_5min_t40d_orth_bk'] = icomskew.groupby('datadate')['skew_5min_t40d_orth'].apply(lambda x: yu.pdqcut(x, bins=10)).values
#yu.create_cn_3x3(icomskew, ['skew_5min_t40d_orth_bk'], 'skew_5min_t40d_orth') # less mono: +0.5 +2 -6

o_1 = yu.bt_cn_15(icomskew[(icomskew['datadate']<='2020-12-31')].\
            dropna(subset=['skew_5min_t40d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'skew_5min_t40d_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.0 / -0.29 


icomskew['skew_5min_t40d_orth_sgnl2'] = np.nan
icomskew['flg1'] = np.nan
icomskew.loc[icomskew['skew_5min_t40d_orth_sgnl']<=-0.9, 'flg1'] = -1
icomskew['flg1'] = icomskew.groupby('ticker')['flg1'].ffill(limit=10)
icomskew.loc[icomskew['flg1']==-1, 'skew_5min_t40d_orth_sgnl2'] = icomskew.loc[icomskew['flg1']==-1, 'skew_5min_t40d_orth_sgnl']

o_1 = yu.bt_cn_15(icomskew[(icomskew['datadate']<='2020-12-31')].\
            dropna(subset=['ske
w_5min_t40d_orth_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'skew_5min_t40d_orth_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.53 / 1.79


icomskew['skew_5min_t40d_orth_sgnl3'] = np.nan
icomskew.loc[icomskew['skew_5min_t40d_orth_sgnl']<=-0.9, 'skew_5min_t40d_orth_sgnl3'] = -1
icomskew['skew_5min_t40d_orth_sgnl3'] = icomskew.groupby('ticker')['skew_5min_t40d_orth_sgnl3'].ffill(limit=10)
o_1 = yu.bt_cn_15(icomskew[(icomskew['datadate']<='2020-12-31')].\
            dropna(subset=['skew_5min_t40d_orth_sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'skew_5min_t40d_orth_sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.6 / 1.92 


# to sql
icomskew['Ticker'] = icomskew['ticker'].str[:6]
icomskew['DataDate'] = icomskew['datadate']
param_engine = create_engine('mssql+pyodbc://summitsqldb_cndbdev') 
icomskew[['Ticker','DataDate','skew_5min_t40d_orth_sgnl3']].to_sql('F001_skew_SO', param_engine , index = False, if_exists = 'replace', chunksize = 10000)





### combine 

icom = i_sd.merge(i_1min_metrics, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(s_1min_metrics, on = ['ticker','datadate'], how = 'left')

icom = icom.sort_values(['ticker', 'datadate'])

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']



### first tests: pq correlation

icom['p_q_dpct_corr_bk'] = icom.groupby('datadate')['p_q_dpct_corr'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['p_q_dpct_corr_orth'] = icom.groupby('datadate')[COLS+['p_q_dpct_corr']].apply(lambda x: yu.orthogonalize_cn(x['p_q_dpct_corr'], x[COLS])).values
icom['p_q_dpct_corr_orth_bk'] = icom.groupby('datadate')['p_q_dpct_corr_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['p_q_pct_corr_bk'] = icom.groupby('datadate')['p_q_pct_corr'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['p_q_corr_bk'] = icom.groupby('datadate')['p_q_corr'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['p_q_dpct_corr_bk'], 'p_q_dpct_corr') # mono: +4 -8
#yu.create_cn_3x3(icom, ['p_q_pct_corr_bk'], 'p_q_pct_corr') # mono: +4 -7
#yu.create_cn_3x3(icom, ['p_q_corr_bk'], 'p_q_corr') # mono +1 -3
#yu.create_cn_3x3(icom, ['p_q_dpct_corr_orth_bk'], 'p_q_dpct_corr_orth') # 


icom['p_q_dpct_corr_sgnl'] = -icom.groupby('datadate')['p_q_dpct_corr'].apply(yu.uniformed_rank).values
icom['p_q_pct_corr_sgnl'] = -icom['p_q_pct_corr']

icom['p_q_pct_corr_t
20d'] = icom.groupby('ticker').rolling(20)['p_q_pct_corr'].mean().values
icom['p_q_pct_corr_t20d_rk'] = -icom.groupby('datadate')['p_q_pct_corr_t20d'].apply(yu.uniformed_rank).values
icom['p_q_pct_corr_rk'] = -icom.groupby('datadate')['p_q_pct_corr'].apply(yu.uniformed_rank).values

icom['p_q_pct_corr_sgnl'] = np.nan
icom.loc[icom['p_q_pct_corr_rk'].abs()>0.8, 'p_q_pct_corr_sgnl'] = icom.loc[icom['p_q_pct_corr_rk'].abs()>0.8, 'p_q_pct_corr_rk']
icom['p_q_pct_corr_sgnl'] = icom.groupby('ticker')['p_q_pct_corr_sgnl'].ffill(limit=30)

icom['p_q_pct_corr_sgnl_sgnlPos'] = np.nan
icom.loc[icom['p_q_pct_corr_sgnl']>0.4, 'p_q_pct_corr_sgnl_sgnlPos'] = icom.loc[icom['p_q_pct_corr_sgnl']>0.4, 'p_q_pct_corr_sgnl']
icom.loc[icom['p_q_pct_corr_sgnl']<0, 'p_q_pct_corr_sgnl_sgnlPos'] = 0
icom['p_q_pct_corr_sgnl_sgnlPos'] = icom.groupby('ticker')['p_q_pct_corr_sgnl_sgnlPos'].ffill(limit=20)


o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['p_q_dpct_corr_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'p_q_dpct_corr_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.36 / -16.8 ###!!!

o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['p_q_pct_corr_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'p_q_pct_corr_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.8 - 12.79


o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['p_q_pct_corr_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'p_q_pct_corr_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.82 / -1.09

o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['p_q_pct_corr_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'p_q_pct_corr_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.37 / -16.9

o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['p_q_pct_corr_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'p_q_pct_corr_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.53 / -5.06

o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['p_q_pct_corr_sgnl_sgnlPos','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'p_q_pct_corr_sgnl_sgnlPos','BarrRet_CLIP_USD+1d',
 static_data = i_sd) # 2.29 / -2.2


# to sql 
icom['Ticker'] = icom['ticker'].str[:6]
icom['DataDate'] = icom['datadate']
param_engine = create_engine('mssql+pyodbc://summitsqldb_cndbdev') 
icom[['Ticker','DataDate','p_q_dpct_corr_sgnl']].to_sql('F001_pqcorr_LS_1D', param_engine , index = False, if_exists = 'replace', chunksize = 10000)




### trailing metrics: pq correlation


#icom['pq_pct_corr_t10d_bk'] = icom.groupby('datadate')['pq_pct_corr_t10d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['pq_pct_corr_t10d_bk'], 'pq_pct_corr_t10d') # mono +3 -5
icom['pq_dpct_corr_t20d_bk'] = icom.groupby('datadate')['pq_dpct_corr_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['pq_pct_corr_t20d_bk'] = icom.groupby('datadate')['pq_pct_corr_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['podq_pct_corr_t20d_bk'] = icom.groupby('datadate')['podq_pct_corr_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['pq_dpct_corr_t20d_bk'], 'pq_dpct_corr_t20d') # mono +2.7 -5.5
# yu.create_cn_3x3(icom, ['pq_pct_corr_t20d_bk'], 'pq_pct_corr_t20d') # mono +2 -5
# yu.create_cn_3x3(icom, ['podq_pct_corr_t20d_bk'], 'podq_pct_corr_t20d') # less mono: -0.5 +2.5 -3
icom['pq_pct_corr_t40d_bk'] = icom.groupby('datadate')['pq_pct_corr_t40d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['pq_pct_corr_t40d_bk'], 'pq_pct_corr_t40d') # mono +3 -4
icom['pq_pct_corr_t60d_bk'] = icom.groupby('datadate')['pq_pct_corr_t60d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['pq_pct_corr_t60d_bk'], 'pq_pct_corr_t60d') # mono +2 -3



#icom['pq_pct_corr_t10d_sgnl'] = -icom.groupby('datadate')['pq_pct_corr_t10d'].apply(yu.uniformed_rank).values
icom['pq_pct_corr_t20d_sgnl'] = -icom.groupby('datadate')['pq_pct_corr_t20d'].apply(yu.uniformed_rank).values
icom['pq_pct_corr_t40d_sgnl'] = -icom.groupby('datadate')['pq_pct_corr_t40d'].apply(yu.uniformed_rank).values
icom['pq_pct_corr_t60d_sgnl'] = -icom.groupby('datadate')['pq_pct_corr_t60d'].apply(yu.uniformed_rank).values

icom['pq_pct_corr_t20d_sgnl_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['pq_pct_corr_t20d_sgnl'].mean().values
icom['pq_pct_corr_t20d_sgnl_t20d_rk'] = icom.groupby('datadate')['pq_pct_corr_t20d_sgnl_t20d'].apply(yu.uniformed_rank).values
icom['pq_pct_corr_t20d_sgnl_t40d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['pq_pct_corr_t20d_sgnl'].mean().valu
es
icom['pq_pct_corr_t20d_sgnl_t40d_rk'] = icom.groupby('datadate')['pq_pct_corr_t20d_sgnl_t40d'].apply(yu.uniformed_rank).values
icom['pq_pct_corr_t20d_sgnl_t60d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=84),on='datadate')['pq_pct_corr_t20d_sgnl'].mean().values
icom['pq_pct_corr_t20d_sgnl_t60d_rk'] = icom.groupby('datadate')['pq_pct_corr_t20d_sgnl_t60d'].apply(yu.uniformed_rank).values
icom['pq_pct_corr_t40d_sgnl_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['pq_pct_corr_t40d_sgnl'].mean().values
icom['pq_pct_corr_t40d_sgnl_t20d_rk'] = icom.groupby('datadate')['pq_pct_corr_t40d_sgnl_t20d'].apply(yu.uniformed_rank).values
icom['pq_pct_corr_t60d_sgnl_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['pq_pct_corr_t60d_sgnl'].mean().values
icom['pq_pct_corr_t60d_sgnl_t20d_rk'] = icom.groupby('datadate')['pq_pct_corr_t60d_sgnl_t20d'].apply(yu.uniformed_rank).values


icom['pq_pct_corr_t10d_sgnl2'] = np.nan
icom.loc[icom['pq_pct_corr_t10d_sgnl'].abs()>0.8, 'pq_pct_corr_t10d_sgnl2'] = icom.loc[icom['pq_pct_corr_t10d_sgnl'].abs()>0.8, 'pq_pct_corr_t10d_sgnl']
icom['pq_pct_corr_t10d_sgnl2'] = icom.groupby('ticker')['pq_pct_corr_t10d_sgnl2'].ffill(limit=15)

icom['pq_pct_corr_t20d_sgnl2'] = np.nan
icom.loc[icom['pq_pct_corr_t20d_sgnl'].abs()>0.8, 'pq_pct_corr_t20d_sgnl2'] = icom.loc[icom['pq_pct_corr_t20d_sgnl'].abs()>0.8, 'pq_pct_corr_t20d_sgnl']
icom['pq_pct_corr_t20d_sgnl2'] = icom.groupby('ticker')['pq_pct_corr_t20d_sgnl2'].ffill(limit=30)


o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['pq_pct_corr_t60d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pq_pct_corr_t60d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #1.89 / 0.92

o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['pq_pct_corr_t60d_sgnl_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pq_pct_corr_t60d_sgnl_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #1.21 / 0.58

o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['pq_pct_corr_t40d_sgnl_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pq_pct_corr_t40d_sgnl_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.07 / 1.29

o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['pq
_pct_corr_t40d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pq_pct_corr_t40d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.15 / 0.72

o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['pq_pct_corr_t20d_sgnl_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pq_pct_corr_t20d_sgnl_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.67 / 1.62

o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['pq_pct_corr_t20d_sgnl_t40d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pq_pct_corr_t20d_sgnl_t40d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.5 / 1.78 ###!!!


# to sql
icom['Ticker'] = icom['ticker'].str[:6]
icom['DataDate'] = icom['datadate']
param_engine = create_engine('mssql+pyodbc://summitsqldb_cndbdev') 
icom[['Ticker','DataDate','pq_pct_corr_t20d_sgnl_t40d_rk']].to_sql('F001_pqcorr_LS_MA', param_engine , index = False, if_exists = 'replace', chunksize = 10000)



o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['pq_pct_corr_t20d_sgnl_t60d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pq_pct_corr_t20d_sgnl_t60d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.06 / 1.45

o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['pq_pct_corr_t10d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pq_pct_corr_t10d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.05 / -2.26

o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['pq_pct_corr_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pq_pct_corr_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.36 / -0.51

o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['pq_pct_corr_t10d_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pq_pct_corr_t10d_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom [(icom ['datadate']<='2020-12-31')].\
            dropna(subset=['pq_pct_corr_t20d_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pq_pct_corr_t20d_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.5 / 1.22

