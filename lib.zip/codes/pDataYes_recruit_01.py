﻿#$%^&* pDataYes_recruit_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 13 09:26:16 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import zipfile
import csv

import jieba

### read recruitment data


'''
i_files = os.listdir('/dat/mdwarehouse/public/502897/DATA-9097/trial_20210811/Recruitment_History')

for f in i_files:
    zf = zipfile.ZipFile(os.path.join('/dat/mdwarehouse/public/502897/DATA-9097/trial_20210811/Recruitment_History', f)) 
    t_data = pd.read_csv(zf.open(f.replace('.zip', '.csv')), dtype = {'ticker_symbol': str})
    t_data['title'] = t_data['title'].str.replace(',', ';')
    t_data['employer'] = t_data['employer'].str.replace(',', ';')
    if t_data['lagou_position_type'].isnull().sum() != len(t_data):
        t_data['lagou_position_type'] = t_data['lagou_position_type'].str.replace(',', ';')
    if t_data['liepin_position_type'].isnull().sum() != len(t_data):
        t_data['liepin_position_type'] = t_data['liepin_position_type'].str.replace(',', ';')
    t_data['salary_range'] = t_data['salary_range'].str.replace(',', ';')
    if t_data['working_experience'].isnull().sum() != len(t_data):
        t_data['working_experience'] = t_data['working_experience'].str.replace(',', ';')
    t_data['working_location'] = t_data['working_location'].str.replace(',', ';')
    t_data['working_address'] = t_data['working_address'].str.replace(',', ';')
    t_data['educational_requirement'] = t_data['educational_requirement'].str.replace(',', ';')
    t_data['employment_type'] = t_data['employment_type'].str.replace(',', ';')
    t_data['language_requirements'] = t_data['language_requirements'].str.replace(',', ';')
    t_data['age_requirement'] = t_data['age_requirement'].str.replace(',', ';')
    if t_data['working_department'].isnull().sum() != len(t_data):
        t_data['working_department'] = t_data['working_department'].str.replace(',', ';')
    if t_data['major_requirements'].isnull().sum() != len(t_data):
        t_data['major_requirements'] = t_data['major_requirements'].str.replace(',', ';')
    #t_data.to_csv(os.path.join('/dat/summit_capital/Data/China Data Hunt/Datayes/recruitment', f+'.txt'), index = False, line_terminator = '\r\n')
    t_data.to_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet', f+'.parquet'))



CREATE TABLE [dbo].[datayes_recruitment](
	[id] [bigint] NULL,
	[company_info_id] [bigint] NULL,
	[ticker_symbol
] varchar(100) NULL,
	[link_url] [varchar](max) NULL,
	[title] [varchar](max) NULL,
	[source] [varchar](max) NULL,
	[level] [varchar](max)NULL,
	[lagou_position_type] [varchar](max) NULL,
	[liepin_position_type] [varchar](max) NULL,
	[employer] [varchar](max) NULL,
	[salary_range] [varchar](max) NULL,
	[annual_salary_range_start] [varchar](max) NULL,
	[annual_salary_range_end] [varchar](max) NULL,
	[working_experience] [varchar](max) NULL,
	[working_location] [varchar](max) NULL,
	[working_address] [varchar](max) NULL,
	[educational_requirement] [varchar](max) NULL,
	[employment_type] [varchar](max) NULL,
	[publisher_name] varchar(max) NULL,
	[published_at] [varchar](max) NULL,
	[language_requirements] [varchar](max) NULL,
	[age_requirement] [varchar](max) NULL,
	[working_department] [varchar](max) NULL,
	[major_requirements] [varchar](max) NULL,
	[created_at] [varchar](max) NULL,
	[updated_at] [varchar](max) NULL) 



bcp [CNDB].[dbo].[datayes_recruitment] in "S:\Data\China Data Hunt\Datayes\recruitment\recruitment_infos_meta_20160101.zip.txt" -c -C 65001 -t  , -S summitsqldb -U AD\thzhang -T -F 2
bcp [CNDB].[dbo].[datayes_recruitment] in "S:\Data\China Data Hunt\Datayes\recruitment\test.csv" -c -q -C 65001 -t  , -S summitsqldb -U AD\thzhang -T -F 2
'''
### inspect data

t1 = pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet', 'recruitment_infos_meta_20210101.zip.parquet'))
t2 = t1[t1.ticker_symbol.notnull()].tail(10000)

t1 = yu.get_sql('select top 1000 * from cndb.dbo.datayes_recruitment')

t11 = pd.read_csv(r"S:\Data\China Data Hunt\Datayes\recruitment\recruitment_infos_meta_20180101.zip.txt")


#--------------------------------------------------
### get strings 

# collect data

i_p = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet')

i_tk_str = pd.DataFrame()
for p in i_p:
    t_data = pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet', p),
                             columns = ['id','ticker_symbol','title','created_at'])
    t_data = t_data[t_data['ticker_symbol'].notnull()]
    t_data = t_data[t_data['ticker_symbol'].str.contains('\d{6}')]
    t_data['datadate'] = pd.to_datetime(pd.to_datetime(t_data['created_at']).dt.date)
    
    i_tk_str = i_tk_str.append(t_data, sort = False)


#i_tk_str = pd.read_parquet(r'S:\Data\China Data Hunt\Datayes\recruitment\tagged_raw_data.parquet',
#                           columns = ['ticker','id','title','datadate'])

# cleanse d
ata

i_tk_str['title2'] = i_tk_str['title'].str.replace('\d','').\
                     str.replace('（|）|,|，|\.|。|:|：|;|；|\(|\)|\*|/',' ').\
                     str.replace('职位编号','')
i_tk_str['seg_title'] = i_tk_str['title2'].apply(lambda x: '@'.join(jieba.cut(x)))

i_tk_str['title3'] = i_tk_str['title'].str.replace('\(.*\)','').str.replace('（.*）','').\
                     str.replace('\d','').\
                     str.replace('（|）|,|，|\.|。|:|：|;|；|\(|\)|\*',' ').\
                     str.replace('职位编号','')
i_tk_str['seg_title_short'] = i_tk_str['title3'].apply(lambda x: '@'.join(jieba.cut(x)))

c_sz = i_tk_str['ticker_symbol'].str[0].isin(['0', '3'])
c_sh = i_tk_str['ticker_symbol'].str[0].isin(['6'])
i_tk_str.loc[c_sz, 'ticker'] = i_tk_str.loc[c_sz, 'ticker_symbol'] + '.SZ'
i_tk_str.loc[c_sh, 'ticker'] = i_tk_str.loc[c_sh, 'ticker_symbol'] + '.SH'





# trailing 1 year segments , each ticker and date

i_tk_t1y_seg = pd.DataFrame()
for dt in pd.date_range(start = '2016-04-01', end = '2021-08-01'):
    print('.', end='')
    t_str = i_tk_str[(i_tk_str['datadate']<=dt) & (i_tk_str['datadate']>=dt-pd.to_timedelta('91 days'))]

    t_seg = t_str.groupby('ticker')['seg_title'].\
            apply(lambda x: '@'.join(list(set(('@'.join(x.tolist())).split('@'))))).reset_index()
    
    t_seg_short = t_str.groupby('ticker')['seg_title_short'].\
            apply(lambda x: '@'.join(list(set(('@'.join(x.tolist())).split('@'))))).reset_index()
    
    t_seg = t_seg.merge(t_seg_short, on = 'ticker', how = 'outer')
    
    t_seg['datadate'] = dt
    i_tk_t1y_seg = i_tk_t1y_seg.append(t_seg, sort = False)
    
# calculate growth

i_tk_t1y_seg['datadate_1y'] = i_tk_t1y_seg['datadate'] - pd.to_timedelta('365 days')
i_tk_t1y_seg['datadate_1h'] = i_tk_t1y_seg['datadate'] - pd.to_timedelta('182 days')
i_tk_t1y_seg['datadate_1q'] = i_tk_t1y_seg['datadate'] - pd.to_timedelta('91 days')
i_tk_t1y_seg['datadate_1m'] = i_tk_t1y_seg['datadate'] - pd.to_timedelta('30 days')

i_tk_t1y_seg = i_tk_t1y_seg.merge(i_tk_t1y_seg[['ticker', 'datadate','seg_title','seg_title_short']],
                                        left_on = ['datadate_1y', 'ticker'], right_on = ['datadate', 'ticker'],
                                        how = 'left', suffixes = ['', '_merge'])
i_tk_t1y_seg = i_tk_t1y_seg.drop(columns = ['datadate_merge'])
i_tk_t1y_seg = i_tk_t1y_seg.rename(columns = {'seg_title_merge': 'seg_title_1y', 'seg_title_short_merge':'seg_title_short_1y'})

# the main count metr
ics
i_tk_t1y_seg['seg_title_1y'] = i_tk_t1y_seg['seg_title_1y'].fillna('')
i_tk_t1y_seg['seg_title_short_1y'] = i_tk_t1y_seg['seg_title_short_1y'].fillna('')

i_tk_t1y_seg['seg_cnt'] = i_tk_t1y_seg['seg_title'].apply(lambda x: len(x.split('@')) if pd.notnull(x) else np.nan)
i_tk_t1y_seg['seg_cnt_1y'] = i_tk_t1y_seg['seg_title_1y'].apply(lambda x: len(x.split('@')) if pd.notnull(x) else np.nan)
i_tk_t1y_seg['segNew_cnt'] = i_tk_t1y_seg[['seg_title','seg_title_1y']].\
                                    apply(lambda x: len(set(x['seg_title'].split('@')).difference(set(x['seg_title_1y'].split('@'))) ), axis = 1)
i_tk_t1y_seg['segGone_cnt'] = i_tk_t1y_seg[['seg_title','seg_title_1y']].\
                                    apply(lambda x: len(set(x['seg_title_1y'].split('@')).difference(set(x['seg_title'].split('@')))  ), axis = 1)

# the growth metrics
i_tk_t1y_seg['seg_cnt_yy'] = i_tk_t1y_seg['seg_cnt'].divide(i_tk_t1y_seg['seg_cnt_1y'])-1

i_tk_t1y_seg['segShort_yy'] = i_tk_t1y_seg['seg_title_short'].apply(lambda x: len(x.split('@')) if pd.notnull(x) else np.nan).\
                         divide( i_tk_t1y_seg['seg_title_short_1y'].apply(lambda x: len(x.split('@')) if pd.notnull(x) else np.nan) )\
                         -1

i_tk_t1y_seg['new_seg_dv_seg_1y'] = i_tk_t1y_seg['segNew_cnt'].\
                                    divide(i_tk_t1y_seg['seg_title_1y'].apply(lambda x: len(x.split('@'))) )
i_tk_t1y_seg['new_segShort_dv_seg_1y'] = i_tk_t1y_seg[['seg_title_short','seg_title_short_1y']].\
                                    apply(lambda x: len(set(x['seg_title_short'].split('@')).difference(set(x['seg_title_short_1y'].split('@'))) ), axis = 1).\
                                    divide(i_tk_t1y_seg['seg_title_short_1y'].apply(lambda x: len(x.split('@'))) )
i_tk_t1y_seg['chg_seg_dv_seg_1y'] = i_tk_t1y_seg[['seg_title','seg_title_1y']].\
                                    apply(lambda x: len(set(x['seg_title'].split('@')).difference(set(x['seg_title_1y'].split('@'))) ) +\
                                                    len(set(x['seg_title_1y'].split('@')).difference(set(x['seg_title'].split('@')))  ), axis = 1).\
                                    divide(i_tk_t1y_seg['seg_title_1y'].apply(lambda x: len(x.split('@'))) )
i_tk_t1y_seg['chg_segShort_dv_seg_1y'] = (i_tk_t1y_seg['segGone_cnt'] + i_tk_t1y_seg['segNew_cnt']).\
                                    divide(i_tk_t1y_seg['seg_title_short_1y'].apply(lambda x: len(x.split('@'))) )

i_tk_t1y_seg =
 i_tk_t1y_seg.drop(columns = ['datadate_1y', 'datadate_1h', 'datadate_1q', 'datadate_1m'])

#--------------------------------------------------
### calculate 1 day metrics: sum of job counts per ticker, salary range

i_p = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet')


i_tk_stat = pd.DataFrame()
for p in i_p:
    t_data = pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet', p))
    t_data = t_data[t_data['ticker_symbol'].notnull()]
    t_data = t_data[t_data['ticker_symbol'].str.contains('\d{6}')]
    t_data = t_data[t_data.source == '51job'] ###!!!
    t_data['datadate'] = pd.to_datetime(pd.to_datetime(t_data['created_at']).dt.date)
    t_data['salary'] = (t_data['annual_salary_range_start'] + t_data['annual_salary_range_end'])/2
    t_data['salaryMin'] = t_data['annual_salary_range_start']
    t_sum = t_data.groupby(['ticker_symbol', 'datadate']).agg({'id':'count', 'salary': ['sum', 'mean'], 'salaryMin': ['sum', 'mean']}).reset_index()
    t_sum.columns = ['%s%s' % (a, '_%s' % b if b else '') for a, b in t_sum.columns]
    i_tk_stat = i_tk_stat.append(t_sum, sort = False)


### calculate t1w - job counts


i_tk_t7d_cnt = pd.DataFrame()
for dt in pd.date_range(start = '2016-04-01', end = '2021-08-01'):
    print('.', end='')
    t_tk_cnt = i_tk_stat[(i_tk_stat['datadate']<=dt) & (i_tk_stat['datadate']>=dt-pd.to_timedelta('7 days'))]
    t_tk_t7d_cnt = t_tk_cnt.groupby('ticker_symbol')['id_count'].sum().reset_index()
    t_tk_t7d_cnt['datadate'] = dt
    i_tk_t7d_cnt = i_tk_t7d_cnt.append(t_tk_t7d_cnt, sort = False)
    
i_tk_t7d_cnt = i_tk_t7d_cnt[i_tk_t7d_cnt['ticker_symbol'].str.len()==6]
c_sz = i_tk_t7d_cnt['ticker_symbol'].str[0].isin(['0', '3'])
c_sh = i_tk_t7d_cnt['ticker_symbol'].str[0].isin(['6'])
i_tk_t7d_cnt.loc[c_sz, 'ticker'] = i_tk_t7d_cnt.loc[c_sz, 'ticker_symbol'] + '.SZ'
i_tk_t7d_cnt.loc[c_sh, 'ticker'] = i_tk_t7d_cnt.loc[c_sh, 'ticker_symbol'] + '.SH'

i_tk_t7d_cnt = i_tk_t7d_cnt.rename(columns = {'id_count':'id_t1w'})
i_tk_t7d_cnt = i_tk_t7d_cnt.drop(columns = 'ticker_symbol')

# calculate growth

i_tk_t7d_cnt['datadate_1w'] = i_tk_t7d_cnt['datadate'] - pd.to_timedelta('7 days')

i_tk_t7d_cnt = i_tk_t7d_cnt.merge(i_tk_t7d_cnt[['ticker', 'datadate','id_t1w']],
                                        left_on = ['datadate_1w', 'ticker'], right_on = ['datadate', 'ticker'],
                                        how = 'left', suffixes = ['', '_merge'])
i_tk_t7d_cnt = i_tk_t7d_cnt.drop(col
umns = ['datadate_merge'])
i_tk_t7d_cnt = i_tk_t7d_cnt.rename(columns = {'id_t1w_merge': 'id_t1w_1w'})

i_tk_t7d_cnt['id_t1w_ww'] = (i_tk_t7d_cnt['id_t1w']-i_tk_t7d_cnt['id_t1w_1w']).divide(i_tk_t7d_cnt['id_t1w']+i_tk_t7d_cnt['id_t1w_1w'])
i_tk_t7d_cnt['id_t1w_ww'] = i_tk_t7d_cnt['id_t1w_ww'].replace(np.inf, np.nan).replace(-np.inf, np.nan)

i_tk_t7d_cnt = i_tk_t7d_cnt.drop(columns = ['datadate_1w'])


### calculate t1m - job counts


i_tk_t30d_cnt = pd.DataFrame()
for dt in pd.date_range(start = '2016-04-01', end = '2021-08-01'):
    print('.', end='')
    t_tk_cnt = i_tk_stat[(i_tk_stat['datadate']<=dt) & (i_tk_stat['datadate']>=dt-pd.to_timedelta('30 days'))]
    t_tk_t30d_cnt = t_tk_cnt.groupby('ticker_symbol')['id_count'].sum().reset_index()
    t_tk_t30d_cnt['datadate'] = dt
    i_tk_t30d_cnt = i_tk_t30d_cnt.append(t_tk_t30d_cnt, sort = False)
    
i_tk_t30d_cnt = i_tk_t30d_cnt[i_tk_t30d_cnt['ticker_symbol'].str.len()==6]
c_sz = i_tk_t30d_cnt['ticker_symbol'].str[0].isin(['0', '3'])
c_sh = i_tk_t30d_cnt['ticker_symbol'].str[0].isin(['6'])
i_tk_t30d_cnt.loc[c_sz, 'ticker'] = i_tk_t30d_cnt.loc[c_sz, 'ticker_symbol'] + '.SZ'
i_tk_t30d_cnt.loc[c_sh, 'ticker'] = i_tk_t30d_cnt.loc[c_sh, 'ticker_symbol'] + '.SH'

i_tk_t30d_cnt = i_tk_t30d_cnt.rename(columns = {'id_count':'id_t1m'})
i_tk_t30d_cnt = i_tk_t30d_cnt.drop(columns = 'ticker_symbol')


# calculate growth

i_tk_t30d_cnt['datadate_1m'] = i_tk_t30d_cnt['datadate'] - pd.to_timedelta('30 days')

i_tk_t30d_cnt = i_tk_t30d_cnt.merge(i_tk_t30d_cnt[['ticker', 'datadate','id_t1m']],
                                        left_on = ['datadate_1m', 'ticker'], right_on = ['datadate', 'ticker'],
                                        how = 'left', suffixes = ['', '_merge'])
i_tk_t30d_cnt = i_tk_t30d_cnt.drop(columns = ['datadate_merge'])
i_tk_t30d_cnt = i_tk_t30d_cnt.rename(columns = {'id_t1m_merge': 'id_t1m_1m'})

i_tk_t30d_cnt['id_t1m_mm'] = (i_tk_t30d_cnt['id_t1m']-i_tk_t30d_cnt['id_t1m_1m']).divide(i_tk_t30d_cnt['id_t1m']+i_tk_t30d_cnt['id_t1m_1m'])
i_tk_t30d_cnt['id_t1m_mm'] = i_tk_t30d_cnt['id_t1m_mm'].replace(np.inf, np.nan).replace(-np.inf, np.nan)

i_tk_t30d_cnt = i_tk_t30d_cnt.drop(columns = ['datadate_1m'])


### calculate t1q job counts

i_tk_t90d_cnt = pd.DataFrame()
for dt in pd.date_range(start = '2016-04-01', end = '2021-08-01'):
    print('.', end='')
    t_tk_cnt = i_tk_stat[(i_tk_stat['datadate']<=dt) & (i_tk_stat['datadate']>=dt-pd.to_timedelta('91 days'))]
    t_tk_t90d_cnt = t_tk_cnt.grou
pby('ticker_symbol')['id_count'].sum().reset_index()
    t_tk_t90d_cnt['datadate'] = dt
    i_tk_t90d_cnt = i_tk_t90d_cnt.append(t_tk_t90d_cnt, sort = False)
    
i_tk_t90d_cnt = i_tk_t90d_cnt[i_tk_t90d_cnt['ticker_symbol'].str.len()==6]
c_sz = i_tk_t90d_cnt['ticker_symbol'].str[0].isin(['0', '3'])
c_sh = i_tk_t90d_cnt['ticker_symbol'].str[0].isin(['6'])
i_tk_t90d_cnt.loc[c_sz, 'ticker'] = i_tk_t90d_cnt.loc[c_sz, 'ticker_symbol'] + '.SZ'
i_tk_t90d_cnt.loc[c_sh, 'ticker'] = i_tk_t90d_cnt.loc[c_sh, 'ticker_symbol'] + '.SH'

i_tk_t90d_cnt = i_tk_t90d_cnt.rename(columns = {'id_count':'id_t1q'})
i_tk_t90d_cnt = i_tk_t90d_cnt.drop(columns = 'ticker_symbol')

# calculate growth

i_tk_t90d_cnt['datadate_1q'] = i_tk_t90d_cnt['datadate'] - pd.to_timedelta('30 days')

i_tk_t90d_cnt = i_tk_t90d_cnt.merge(i_tk_t90d_cnt[['ticker', 'datadate','id_t1q']],
                                        left_on = ['datadate_1q', 'ticker'], right_on = ['datadate', 'ticker'],
                                        how = 'left', suffixes = ['', '_merge'])
i_tk_t90d_cnt = i_tk_t90d_cnt.drop(columns = ['datadate_merge'])
i_tk_t90d_cnt = i_tk_t90d_cnt.rename(columns = {'id_t1q_merge': 'id_t1q_1q'})

i_tk_t90d_cnt['id_t1q_qq'] = (i_tk_t90d_cnt['id_t1q']-i_tk_t90d_cnt['id_t1q_1q']).divide(i_tk_t90d_cnt['id_t1q']+i_tk_t90d_cnt['id_t1q_1q'])
i_tk_t90d_cnt['id_t1q_qq'] = i_tk_t90d_cnt['id_t1q_qq'].replace(np.inf, np.nan).replace(-np.inf, np.nan)


i_tk_t90d_cnt = i_tk_t90d_cnt.drop(columns = ['datadate_1q'])


### calculate ttm job counts

i_tk_t1y_cnt = pd.DataFrame()
for dt in pd.date_range(start = '2016-04-01', end = '2021-08-01'):
    print('.', end='')
    t_tk_cnt = i_tk_stat[(i_tk_stat['datadate']<=dt) & (i_tk_stat['datadate']>=dt-pd.to_timedelta('365 days'))]
    t_tk_t90d_cnt = t_tk_cnt.groupby('ticker_symbol')['id_count'].sum().reset_index()
    t_tk_t90d_cnt['datadate'] = dt
    i_tk_t1y_cnt = i_tk_t1y_cnt.append(t_tk_t90d_cnt, sort = False)
    
i_tk_t1y_cnt = i_tk_t1y_cnt[i_tk_t1y_cnt['ticker_symbol'].str.len()==6]
c_sz = i_tk_t1y_cnt['ticker_symbol'].str[0].isin(['0', '3'])
c_sh = i_tk_t1y_cnt['ticker_symbol'].str[0].isin(['6'])
i_tk_t1y_cnt.loc[c_sz, 'ticker'] = i_tk_t1y_cnt.loc[c_sz, 'ticker_symbol'] + '.SZ'
i_tk_t1y_cnt.loc[c_sh, 'ticker'] = i_tk_t1y_cnt.loc[c_sh, 'ticker_symbol'] + '.SH'

i_tk_t1y_cnt = i_tk_t1y_cnt.rename(columns = {'id_count':'id_t1y'})
i_tk_t1y_cnt = i_tk_t1y_cnt.drop(columns = 'ticker_symbol')


# Calculate various job count growth 

i_tk_t1y_cnt['data
date_1y'] = i_tk_t1y_cnt['datadate'] - pd.to_timedelta('365 days')
i_tk_t1y_cnt['datadate_1h'] = i_tk_t1y_cnt['datadate'] - pd.to_timedelta('182 days')
i_tk_t1y_cnt['datadate_1q'] = i_tk_t1y_cnt['datadate'] - pd.to_timedelta('91 days')
i_tk_t1y_cnt['datadate_1m'] = i_tk_t1y_cnt['datadate'] - pd.to_timedelta('30 days')
i_tk_t1y_cnt['datadate_1w'] = i_tk_t1y_cnt['datadate'] - pd.to_timedelta('7 days')

i_tk_t1y_cnt = i_tk_t1y_cnt.merge(i_tk_t1y_cnt[['ticker', 'datadate','id_t1y']],
                                        left_on = ['datadate_1y', 'ticker'], right_on = ['datadate', 'ticker'],
                                        how = 'left', suffixes = ['', '_merge'])
i_tk_t1y_cnt = i_tk_t1y_cnt.drop(columns = ['datadate_merge'])
i_tk_t1y_cnt = i_tk_t1y_cnt.rename(columns = {'id_t1y_merge': 'id_t1y_1y'})

i_tk_t1y_cnt = i_tk_t1y_cnt.merge(i_tk_t1y_cnt[['ticker', 'datadate','id_t1y']],
                                        left_on = ['datadate_1q', 'ticker'], right_on = ['datadate', 'ticker'],
                                        how = 'left', suffixes = ['', '_merge'])
i_tk_t1y_cnt = i_tk_t1y_cnt.drop(columns = ['datadate_merge'])
i_tk_t1y_cnt = i_tk_t1y_cnt.rename(columns = {'id_t1y_merge': 'id_t1y_1q'})

i_tk_t1y_cnt = i_tk_t1y_cnt.merge(i_tk_t1y_cnt[['ticker', 'datadate','id_t1y']],
                                        left_on = ['datadate_1h', 'ticker'], right_on = ['datadate', 'ticker'],
                                        how = 'left', suffixes = ['', '_merge'])
i_tk_t1y_cnt = i_tk_t1y_cnt.drop(columns = ['datadate_merge'])
i_tk_t1y_cnt = i_tk_t1y_cnt.rename(columns = {'id_t1y_merge': 'id_t1y_1h'})


i_tk_t1y_cnt = i_tk_t1y_cnt.merge(i_tk_t1y_cnt[['ticker', 'datadate','id_t1y']],
                                        left_on = ['datadate_1m', 'ticker'], right_on = ['datadate', 'ticker'],
                                        how = 'left', suffixes = ['', '_merge'])
i_tk_t1y_cnt = i_tk_t1y_cnt.drop(columns = ['datadate_merge'])
i_tk_t1y_cnt = i_tk_t1y_cnt.rename(columns = {'id_t1y_merge': 'id_t1y_1m'})

i_tk_t1y_cnt = i_tk_t1y_cnt.merge(i_tk_t1y_cnt[['ticker', 'datadate','id_t1y']],
                                        left_on = ['datadate_1w', 'ticker'], right_on = ['datadate', 'ticker'],
                                        how = 'left', suffixes = ['', '_merge'])
i_tk_t1y_cnt = i_tk_t1y_cnt.drop(columns = ['datadate_merge'])
i_tk_t1y_cnt = i_tk_t1y_cnt.rename(columns = {'id_t1y_merge': 'id_t1y_1w'})

i_tk_t1y_cnt['id_t1y_yy']
 = (i_tk_t1y_cnt['id_t1y']-i_tk_t1y_cnt['id_t1y_1y']).divide(i_tk_t1y_cnt['id_t1y']+i_tk_t1y_cnt['id_t1y_1y'])
i_tk_t1y_cnt['id_t1y_yy'] = i_tk_t1y_cnt['id_t1y_yy'].replace(np.inf, np.nan).replace(-np.inf, np.nan)

i_tk_t1y_cnt['id_t1y_qq'] = (i_tk_t1y_cnt['id_t1y']-i_tk_t1y_cnt['id_t1y_1q']).divide(i_tk_t1y_cnt['id_t1y']+i_tk_t1y_cnt['id_t1y_1y'])
i_tk_t1y_cnt['id_t1y_qq'] = i_tk_t1y_cnt['id_t1y_qq'].replace(np.inf, np.nan).replace(-np.inf, np.nan)


i_tk_t1y_cnt = i_tk_t1y_cnt.drop(columns = ['datadate_1y', 'datadate_1h', 'datadate_1q', 'datadate_1m', 'datadate_1w'])



### calculate t2y - job counts


i_tk_t2y_cnt = pd.DataFrame()
for dt in pd.date_range(start = '2016-04-01', end = '2021-08-01'):
    print('.', end='')
    t_tk_cnt = i_tk_stat[(i_tk_stat['datadate']<=dt) & (i_tk_stat['datadate']>=dt-pd.to_timedelta('730 days'))]
    t_tk_t2y_cnt = t_tk_cnt.groupby('ticker_symbol')['id_count'].sum().reset_index()
    t_tk_t2y_cnt['datadate'] = dt
    i_tk_t2y_cnt = i_tk_t2y_cnt.append(t_tk_t2y_cnt, sort = False)
    
i_tk_t2y_cnt = i_tk_t2y_cnt[i_tk_t2y_cnt['ticker_symbol'].str.len()==6]
c_sz = i_tk_t2y_cnt['ticker_symbol'].str[0].isin(['0', '3'])
c_sh = i_tk_t2y_cnt['ticker_symbol'].str[0].isin(['6'])
i_tk_t2y_cnt.loc[c_sz, 'ticker'] = i_tk_t2y_cnt.loc[c_sz, 'ticker_symbol'] + '.SZ'
i_tk_t2y_cnt.loc[c_sh, 'ticker'] = i_tk_t2y_cnt.loc[c_sh, 'ticker_symbol'] + '.SH'

i_tk_t2y_cnt = i_tk_t2y_cnt.rename(columns = {'id_count':'id_t2y'})
i_tk_t2y_cnt = i_tk_t2y_cnt.drop(columns = 'ticker_symbol')

# calculate growth

i_tk_t2y_cnt['datadate_2y'] = i_tk_t2y_cnt['datadate'] - pd.to_timedelta('730 days')

i_tk_t2y_cnt = i_tk_t2y_cnt.merge(i_tk_t2y_cnt[['ticker', 'datadate','id_t2y']],
                                        left_on = ['datadate_2y', 'ticker'], right_on = ['datadate', 'ticker'],
                                        how = 'left', suffixes = ['', '_merge'])
i_tk_t2y_cnt = i_tk_t2y_cnt.drop(columns = ['datadate_merge'])
i_tk_t2y_cnt = i_tk_t2y_cnt.rename(columns = {'id_t2y_merge': 'id_t2y_2y'})

i_tk_t2y_cnt['id_t2y_yy'] = (i_tk_t2y_cnt['id_t2y']-i_tk_t2y_cnt['id_t2y_2y']).divide(i_tk_t2y_cnt['id_t2y']+i_tk_t2y_cnt['id_t2y_2y'])
i_tk_t2y_cnt['id_t2y_yy'] = i_tk_t2y_cnt['id_t2y_yy'].replace(np.inf, np.nan).replace(-np.inf, np.nan)

i_tk_t2y_cnt = i_tk_t2y_cnt.drop(columns = ['datadate_2y'])




#------------------------------------------------------------------------------
### calculate ttm job counts (only jobs that existed before)

i_p = os.listd
ir(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet')

def helper1(title_str, seg_title_str):
    t_jieba1 = list(jieba.cut(title_str))
    t_jieba2 = set([i for i in t_jieba1 if i.strip()!=''])
    seg_title_lst = set(seg_title_str.split('@'))
    return t_jieba2.issubset(seg_title_lst)

i_tk_stat_v2 = pd.DataFrame()
for p in i_p:
    print(p)
    t_data = pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet', p))
    t_data = t_data[t_data['ticker_symbol'].notnull()]
    t_data = t_data[t_data['ticker_symbol'].str.contains('\d{6}')]
    t_data = t_data[t_data.source == '51job'] ###!!!
    t_data['datadate'] = pd.to_datetime(pd.to_datetime(t_data['created_at']).dt.date)
    
    c_sh = t_data['ticker_symbol'].str[0].isin(['6'])
    c_sz = t_data['ticker_symbol'].str[0].isin(['0', '3'])
    t_data.loc[c_sh, 'ticker'] = t_data.loc[c_sh, 'ticker_symbol'] + '.SH'
    t_data.loc[c_sz, 'ticker'] = t_data.loc[c_sz, 'ticker_symbol'] + '.SZ'
    
    t_data['title3'] = t_data['title'].str.replace('\(.*\)','').str.replace('（.*）','').\
                     str.replace('\d','').\
                     str.replace('（|）|,|，|\.|。|:|：|;|；|\(|\)|\*',' ').\
                     str.replace('职位编号','')
    
    t_data = t_data.merge(i_tk_t1y_seg[['ticker', 'datadate', 'seg_title_1y']], 
                          on = ['ticker', 'datadate'], how = 'left')
    t_data['title3'] = t_data['title3'].fillna('')
    t_data['seg_title_1y'] = t_data['seg_title_1y'].fillna('')
    t_data['same_concept_flag'] = t_data[['title3', 'seg_title_1y']].\
                                    apply(lambda x: helper1(x['title3'],x['seg_title_1y']), axis=1)
    
    t_sum = t_data.groupby(['ticker', 'datadate'])['id'].count().reset_index()
    t_sum_same = t_data[t_data['same_concept_flag']].groupby(['ticker', 'datadate'])['id'].count().reset_index()
    t_sum_same = t_sum_same.rename(columns = {'id':'id_same'})
    
    t_sum = t_sum.merge(t_sum_same, on = ['ticker','datadate'], how = 'outer')
    
    i_tk_stat_v2 = i_tk_stat_v2.append(t_sum, sort = False)

# now we get summarized data per ticker per datadate
# next we calculate t1y metrics

i_tk_t1y_same_cnt = pd.DataFrame()
for dt in pd.date_range(start = '2016-04-01', end = '2021-08-01'):
    print('.', end='')
    t_tk_cnt = i_tk_stat_v2[(i_tk_stat_v2['datadate']<=dt) & (i_tk_stat_v2['datadate']>=dt-pd.to_timedelta('365 days'))]
    t_tk_t1y_cnt = t_tk_cnt.groupby('ticker')['id_same'].sum().reset_index()
    
t_tk_t1y_cnt['datadate'] = dt
    i_tk_t1y_same_cnt = i_tk_t1y_same_cnt.append(t_tk_t1y_cnt, sort = False)
    
i_tk_t1y_same_cnt = i_tk_t1y_same_cnt.rename(columns = {'id_same':'id_same_t1y'})



# Calculate various job count growth 

i_tk_t1y_same_cnt['datadate_1y'] = i_tk_t1y_same_cnt['datadate'] - pd.to_timedelta('365 days')


i_tk_t1y_same_cnt = i_tk_t1y_same_cnt.merge(i_tk_t1y_same_cnt[['ticker', 'datadate','id_same_t1y']],
                                        left_on = ['datadate_1y', 'ticker'], right_on = ['datadate', 'ticker'],
                                        how = 'left', suffixes = ['', '_merge'])
i_tk_t1y_same_cnt = i_tk_t1y_same_cnt.drop(columns = ['datadate_merge'])
i_tk_t1y_same_cnt = i_tk_t1y_same_cnt.rename(columns = {'id_same_t1y_merge': 'id_same_t1y_1y'})
i_tk_t1y_same_cnt = i_tk_t1y_same_cnt.drop(columns = ['datadate_1y'])


#------------------------------------------------------------------------------
### Calculate ttm salary (sum and mean)


i_tk_t1y_salary = pd.DataFrame()
for dt in pd.date_range(start = '2016-04-01', end = '2021-08-01'):
    print('.', end='')
    t_tk_salary = i_tk_stat[(i_tk_stat['datadate']<=dt) & (i_tk_stat['datadate']>=dt-pd.to_timedelta('365 days'))]
    t_tk_salary['cnt_x_salaryMean'] = t_tk_salary['id_count'].multiply(t_tk_salary['salary_mean'])
    t_tk_salary['cnt_x_salaryMinMean'] = t_tk_salary['id_count'].multiply(t_tk_salary['salaryMin_mean'])
    t_tk_t1y_salary = t_tk_salary.groupby('ticker_symbol').\
                      agg({'salary_sum':'sum', 'salaryMin_sum':'sum', 
                           'cnt_x_salaryMean':'sum', 'cnt_x_salaryMinMean':'sum',
                           'id_count': 'sum'}).reset_index()
    t_tk_t1y_salary['salary_mean'] = t_tk_t1y_salary['cnt_x_salaryMean'].divide(t_tk_t1y_salary['id_count'])
    t_tk_t1y_salary['salaryMin_mean'] = t_tk_t1y_salary['cnt_x_salaryMinMean'].divide(t_tk_t1y_salary['id_count'])
    t_tk_t1y_salary = t_tk_t1y_salary.drop(columns = ['cnt_x_salaryMean', 'cnt_x_salaryMinMean', 'id_count'])
    t_tk_t1y_salary['datadate'] = dt
    i_tk_t1y_salary = i_tk_t1y_salary.append(t_tk_t1y_salary, sort = False)
    
i_tk_t1y_salary = i_tk_t1y_salary[i_tk_t1y_salary['ticker_symbol'].str.len()==6]
c_sz = i_tk_t1y_salary['ticker_symbol'].str[0].isin(['0', '3'])
c_sh = i_tk_t1y_salary['ticker_symbol'].str[0].isin(['6'])
i_tk_t1y_salary.loc[c_sz, 'ticker'] = i_tk_t1y_salary.loc[c_sz, 'ticker_symbol'] + '.SZ'
i_tk_t1y_salary.loc[c_sh, 'ticker'] = i_tk_t1y_s
alary.loc[c_sh, 'ticker_symbol'] + '.SH'

i_tk_t1y_salary = i_tk_t1y_salary.rename(columns = {'salary_sum':'salary_sum_t1y', 
                                                    'salary_mean':'salary_mean_t1y',
                                                    'salaryMin_sum':'salaryMin_sum_t1y',
                                                    'salaryMin_mean':'salaryMin_mean_t1y'})
i_tk_t1y_salary = i_tk_t1y_salary.drop(columns = 'ticker_symbol')

# past number

i_tk_t1y_salary['datadate_1y'] = i_tk_t1y_salary['datadate'] - pd.to_timedelta('365 days')
i_tk_t1y_salary = i_tk_t1y_salary.merge(i_tk_t1y_salary,
                                        left_on = ['datadate_1y', 'ticker'], 
                                        right_on = ['datadate', 'ticker'],
                                        how = 'left', suffixes = ['', '_merge'])
i_tk_t1y_salary = i_tk_t1y_salary.drop(columns = ['datadate_merge','datadate_1y_merge','datadate_1y'])
i_tk_t1y_salary = i_tk_t1y_salary.rename(columns = {'salary_mean_t1y_merge': 'salary_mean_t1y_1y',
                                                    'salaryMin_sum_t1y_merge': 'salaryMin_sum_t1y_1y',
                                                    'salaryMin_mean_t1y_merge': 'salaryMin_mean_t1y_1y',
                                                    'salary_sum_t1y_merge':'salary_sum_t1y_1y'})

#--------------------------------------
### get reported employee count

i_emp = pd.read_parquet(r'S:\Data\China Data Hunt\cache\cninfo_ashare_employee_cnt.parquet')

i_emp['datadate'] = pd.to_datetime(i_emp['DECLAREDATE'])
c_sh = i_emp['SECCODE'].str[0].isin(['6'])
c_sz = i_emp['SECCODE'].str[0].isin(['0','3'])
i_emp.loc[c_sz, 'ticker'] = i_emp.loc[c_sz, 'SECCODE'] + '.SZ'
i_emp.loc[c_sh, 'ticker'] = i_emp.loc[c_sh, 'SECCODE'] + '.SH'
i_emp = i_emp[['datadate', 'ticker', 'STAFFNUM']]
i_emp = i_emp[i_emp['datadate'].notnull()]

i_emp = i_emp.sort_values('datadate')
i_emp['datadate_1y'] = i_emp['datadate'] - pd.to_timedelta('365 days')
i_emp = pd.merge_asof(i_emp, i_emp[['datadate','ticker','STAFFNUM']], 
                      by = 'ticker', left_on='datadate_1y', right_on = 'datadate',
                      suffixes = ['','_merge'])
i_emp = i_emp.drop(columns = ['datadate_merge'])
i_emp = i_emp.rename(columns = {'STAFFNUM_merge':'STAFFNUM_1y'})
i_emp['STAFFNUM_yy'] = i_emp['STAFFNUM'].divide(i_emp['STAFFNUM_1y'])-1
i_emp['STAFFNUM_yy'] = i_emp['STAFFNUM_yy'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
i_emp = i_em
p.drop(columns = ['STAFFNUM_1y','datadate_1y'])

i_emp = i_emp.sort_values(['ticker', 'datadate'])



### get sd
i_sd = pw.get_ashare_hk_sd_v2()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','a50_300_flag','a50_flag']]

i_sd_map_300  =i_sd_map[i_sd_map['a50_300_flag']==1]
i_sd_map_50  = i_sd_map[i_sd_map['a50_flag']==1]


### get historical mc

i_mc = yu.get_sql('''select ticker, datadate, mc from [CNDB].[dbo].[UNIVERSE_ALL_CN] 
                    where ticker in ('{0}') '''.format("','".join( i_sd_map['ticker'].str[:6].unique().tolist() )))
i_mc['datadate_2y'] = i_mc['datadate'] - pd.to_timedelta('730 days')
i_mc['datadate_1y'] = i_mc['datadate'] - pd.to_timedelta('365 days')
i_mc['datadate_1h'] = i_mc['datadate'] - pd.to_timedelta('182 days')
i_mc['datadate_1q'] = i_mc['datadate'] - pd.to_timedelta('91 days')
i_mc['datadate_1m'] = i_mc['datadate'] - pd.to_timedelta('30 days')
i_mc['datadate_1w'] = i_mc['datadate'] - pd.to_timedelta('7 days')

i_mc = i_mc.sort_values('datadate')

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1q', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1q'})

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1y', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1y'})
i_mc = i_mc.drop(columns = ['datadate_1q', 'datadate_1y'])

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_2y', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_2y'})
i_mc = i_mc.drop(columns = ['datadate_2y'])

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1h', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1
h'})
i_mc = i_mc.drop(columns = ['datadate_1h'])

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1m', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1m'})
i_mc = i_mc.drop(columns = ['datadate_1m'])

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1w', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1w'})
i_mc = i_mc.drop(columns = ['datadate_1w'])

c_sh = i_mc['ticker'].str[0].isin(['6'])
c_sz = i_mc['ticker'].str[0].isin(['0', '3'])
i_mc.loc[c_sz, 'ticker'] = i_mc.loc[c_sz, 'ticker'] + '.SZ'
i_mc.loc[c_sh, 'ticker'] = i_mc.loc[c_sh, 'ticker'] + '.SH'

i_mc = i_mc.drop(columns = 'mc')


### get sales growth

i_sales_yy = yu.get_sql('''select s_info_windcode as ticker, ann_dt as datadate,
                        report_period, TOT_OPER_REV as rev 
                        from wind.dbo.ashareincome 
                        where statement_type = '408001000' ''')
i_sales_yy = i_sales_yy[i_sales_yy['datadate'].notnull()]
i_sales_yy['datadate'] = pd.to_datetime(i_sales_yy['datadate'], format='%Y%m%d')

i_sales_yy['report_period'] = i_sales_yy['report_period'].astype(int)
i_sales_yy['report_period_1y'] = (i_sales_yy['report_period'] - 10000).astype(int)

i_sales_yy = i_sales_yy.sort_values('datadate')
i_sales_yy = pd.merge_asof(i_sales_yy, i_sales_yy[['ticker','datadate','report_period','rev']],
                           left_by = ['ticker','report_period_1y'], right_by = ['ticker', 'report_period'],
                           on = 'datadate', suffixes = ['', '_merge'])
i_sales_yy = i_sales_yy.drop(columns = ['report_period_merge','report_period_1y'])
i_sales_yy = i_sales_yy.rename(columns = {'rev_merge': 'rev_1y'})

i_sales_yy = i_sales_yy.sort_values(['ticker','datadate'])
i_sales_yy['max_report_date'] = i_sales_yy.groupby('ticker')['report_period'].cummax()
i_sales_yy = i_sales_yy[i_sales_yy['report_period']>=i_sales_yy['max_report_date']]

i_sales_yy['rev_yy'] = i_sales_yy['rev'].divide(i_sales_yy['rev_1y'])
i_sales_yy['rev_yy'] = i_sales_yy['rev_yy'].replace(np.inf, np.nan).replace(-np.inf, np.nan)

i_sales_yy = i_sales_yy.drop(columns = ['report_period', 'max_report_date'])
i_sales_yy = i_sa
les_yy.sort_values('datadate')

### get asset 
i_bs = yu.get_sql('''select ann_dt, s_info_windcode as ticker, report_period, 
                  TOT_CUR_ASSETS as c_asset, TOT_ASSETS as t_asset,
                  TOT_SHRHLDR_EQY_INCL_MIN_INT as eqy, TOT_LIAB as liab 
                  from [WIND].[dbo].[ASHAREBALANCESHEET]
                  where statement_type = '408001000' ''')

i_bs = i_bs[i_bs['ann_dt'].notnull()]
i_bs['datadate'] = pd.to_datetime(i_bs['ann_dt'], format='%Y%m%d')
i_bs['report_period'] = pd.to_datetime(i_bs['report_period'], format = '%Y%m%d')
i_bs = i_bs.drop(columns = ['ann_dt'])

i_bs = i_bs.sort_values(['ticker','datadate'])
i_bs['max_report_date'] = i_bs.groupby('ticker')['report_period'].cummax()
i_bs = i_bs[i_bs['report_period']>=i_bs['max_report_date']]

i_bs = i_bs.drop(columns = ['report_period', 'max_report_date'])
i_bs = i_bs.sort_values('datadate')

#------------------------------------------------------------------------------
### combine (hk universe)
#------------------------------------------------------------------------------

icom = i_sd_map.merge(i_tk_t90d_cnt, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_tk_t1y_cnt, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_tk_t1y_salary, on = ['ticker', 'datadate'], how = 'left')

icom = icom.sort_values('datadate')

icom = pd.merge_asof(icom, i_emp, by = 'ticker', on = 'datadate')

icom['mc_rk'] = icom.groupby('datadate')['MC_l1d'].apply(yu.uniformed_rank).values

icom['id_t1q_dv_mc'] = icom['id_t1q'].divide(icom['MC_l1d'])
icom['id_t1q_dv_staff'] = icom['id_t1q'].divide(icom['STAFFNUM'])

icom['job_t1q_rk'] = icom.groupby('datadate')['id_t1q'].apply(yu.uniformed_rank).values
icom['job_t1q_bk'] = icom.groupby('datadate')['id_t1q'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['job_t1q_indbk'] = icom.groupby(['datadate','GSECTOR'])['id_t1q'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['job_t1q_dv_mc_rk'] = icom.groupby(['datadate'])['id_t1q_dv_mc'].apply(yu.uniformed_rank).values
icom['job_t1q_dv_mc_indrk'] = icom.groupby(['datadate','GSECTOR'])['id_t1q_dv_mc'].apply(yu.uniformed_rank).values
icom['job_t1q_dv_mc_bk'] = icom.groupby(['datadate'])['id_t1q_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['job_t1q_dv_staff_rk'] = icom.groupby(['datadate'])['id_t1q_dv_staff'].apply(yu.uniformed_rank).values
icom['job_t1q_dv_staff_bk'] = icom.groupby(['datadate'])['id_t1q_dv_staff'].apply(lambda x: yu.pdqcut(x,bins=10)).values

ic
om['id_t1y_dv_mc'] = icom['id_t1y'].divide(icom['MC_l1d'])
icom['id_t1y_dv_staff'] = icom['id_t1y'].divide(icom['STAFFNUM'])

icom['id_t1y_yy_indrk'] = icom.groupby(['datadate','GSECTOR'])['id_t1y_yy'].apply(yu.uniformed_rank).values
icom['id_t1y_yy_indbk'] = icom.groupby(['datadate','GSECTOR'])['id_t1y_yy'].apply(lambda x: yu.pdqcut(x, bins = 10)).values


icom['job_t1y_rk'] = icom.groupby('datadate')['id_t1y'].apply(yu.uniformed_rank).values
icom['job_t1y_bk'] = icom.groupby('datadate')['id_t1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['job_t1y_indbk'] = icom.groupby(['datadate','GSECTOR'])['id_t1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['job_t1y_mc_rk_df'] = icom['job_t1y_rk'] - icom['mc_rk']
icom['job_t1y_mc_rk_df_rk'] = icom.groupby('datadate')['job_t1y_mc_rk_df'].apply(yu.uniformed_rank).values

icom['job_t1y_dv_mc_rk'] = icom.groupby(['datadate'])['id_t1y_dv_mc'].apply(yu.uniformed_rank).values
icom['job_t1y_dv_mc_indrk'] = icom.groupby(['datadate','GSECTOR'])['id_t1y_dv_mc'].apply(yu.uniformed_rank).values
icom['job_t1y_dv_mc_bk'] = icom.groupby(['datadate'])['id_t1y_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['job_t1y_dv_staff_rk'] = icom.groupby(['datadate'])['id_t1y_dv_staff'].apply(yu.uniformed_rank).values
icom['job_t1y_dv_staff_bk'] = icom.groupby(['datadate'])['id_t1y_dv_staff'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['salary_sum_t1y_dv_mc'] = icom['salary_sum_t1y'].divide(icom['MC_l1d'])
icom['salary_sum_t1y_dv_mc_indrk'] = icom.groupby(['datadate','GSECTOR'])['salary_sum_t1y_dv_mc'].apply(yu.uniformed_rank).values

icom['salary_sum_t1y_indrk'] = icom.groupby(['datadate','GSECTOR'])['salary_sum_t1y'].apply(yu.uniformed_rank).values
icom['salary_mean_t1y_indrk'] = icom.groupby(['datadate','GSECTOR'])['salary_mean_t1y'].apply(yu.uniformed_rank).values

icom['salary_mean_yy_indrk'] = icom.groupby(['datadate','GSECTOR'])['salary_mean_t1y_yy'].apply(yu.uniformed_rank).values
icom['salary_mean_yy_indbk'] = icom.groupby(['datadate','GSECTOR'])['salary_mean_t1y_yy'].apply(lambda x: yu.pdqcut(x, bins = 10)).values

# bar chart

yu.create_cn_3x3(icom, ['job_bk'], 'id_count')
yu.create_cn_3x3(icom, ['job_indbk'], 'id_count')
yu.create_cn_3x3(icom, ['job_dv_mc_bk'], 'id_dv_mc')
yu.create_cn_3x3(icom, ['job_dv_staff_bk'], 'id_dv_staff')

yu.create_cn_3x3(icom, ['job_t1y_bk'], 'id_t1y')
yu.create_cn_3x3(icom, ['job_t1y_dv_staff_bk'], 'id_t1y_dv_staff')

yu.create_cn_3x3(icom, ['salary_mean_yy_indbk'], 'sa
lary_mean_t1y_yy')
yu.create_cn_3x3(icom, ['id_t1y_yy_indbk'], 'id_t1y_yy')


### backtest


### 90 day signals, count

icom2 = icom.copy()

c1 = icom2['job_t1q_dv_staff_rk']>0.9
icom2.loc[c1, 'sgnl'] = icom2.loc[c1, 'job_t1q_dv_staff_rk']

c1 = icom2['job_t1q_rk']>0.9
icom2.loc[c1, 'sgnl2'] = icom2.loc[c1, 'job_t1q_rk']

c1 = icom2['job_t1q_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl3'] = icom2.loc[c1, 'job_t1q_dv_mc_rk']


c1 = icom2['job_t1q_dv_mc_indrk']>0.8
icom2.loc[c1, 'sgnl4'] = icom2.loc[c1, 'job_t1q_dv_mc_indrk']

c1 = icom2['id_t1y_yy_indrk'] > 0.8
icom2.loc[c1, 'sgnl5'] = icom2.loc[c1, 'id_t1y_yy_indrk']

c1 = icom2['job_t1y_mc_rk_df_rk'] > 0.8
icom2.loc[c1, 'sgnl6'] = icom2.loc[c1, 'job_t1y_mc_rk_df_rk']



o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.1 / -0.15


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.56 / 1.23


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.68 / 1.09


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl4','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl4','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.81 / 0.98



o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')&(icom2['a50_300_flag']==1)].\
            dropna(subset=['sgnl4','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl4','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.71 / 1.21



o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1q_dv_mc_indrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t1q_dv_mc_indrk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl5','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl5','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 
-0.8 / -1.49


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['id_t1y_yy_indrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'id_t1y_yy_indrk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.45 / -0.52


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl6','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl6','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.71 / -0.02



### 1 year signals, count


icom2 = icom.copy()


c1 = icom2['job_t1y_dv_staff_rk']>0.8
icom2.loc[c1, 'sgnl'] = icom2.loc[c1, 'job_t1y_dv_staff_rk']

c1 = icom2['job_t1y_rk']>0.8
icom2.loc[c1, 'sgnl2'] = icom2.loc[c1, 'job_t1y_rk']

c1 = icom2['job_t1y_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl3'] = icom2.loc[c1, 'job_t1y_dv_mc_rk']

c1 = icom2['job_t1y_dv_mc_indrk']>0.8
icom2.loc[c1, 'sgnl4'] = icom2.loc[c1, 'job_t1y_dv_mc_indrk']



o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl4','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl4','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 


### 1 year signals, salary

icom2 = icom.copy()

c1 = icom2['salary_sum_t1y_dv_mc_indrk']>0.8
icom2.loc[c1, 'sgnl'] = icom2.loc[c1, 'salary_sum_t1y_dv_mc_indrk']

c1 = icom2['salary_mean_t1y_indrk']>0.8
icom2.loc[c1, 'sgnl2'] = icom2.loc[c1, 'salary_mean_t1y_indrk']

c1 = icom2['salary_sum_t1y_indrk']>0.8
icom2.loc[c1, 'sgnl3'] = icom2.loc[c1, 'salary_sum_t1y_indrk']



c1 = icom2['salary_mean_yy_indrk']>0.8
icom2.loc[c1, 'sgnl5'] = icom2.loc[c1, 'salary_mean_yy_indrk']




o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','BarrRet_
CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.41 / 0.84


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.04 / -0.38


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.37 / 1.07



o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl5','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl5','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 




o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['salary_mean_yy_indrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'salary_mean_yy_indrk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 







#------------------------------------------------------------------------------
### ---- combine (csi300 universe)
#------------------------------------------------------------------------------

icom_300 = i_sd[i_sd['a50_300_flag']==1].merge(i_tk_t90d_cnt, on = ['ticker', 'datadate'], how = 'left')
icom_300 = icom_300.merge(i_tk_t2y_cnt, on = ['ticker', 'datadate'], how = 'left')
icom_300 = icom_300.merge(i_tk_t1y_cnt, on = ['ticker', 'datadate'], how = 'left')
icom_300 = icom_300.merge(i_tk_t30d_cnt, on = ['ticker', 'datadate'], how = 'left')
icom_300 = icom_300.merge(i_tk_t7d_cnt, on = ['ticker', 'datadate'], how = 'left')
icom_300 = icom_300.merge(i_tk_t1y_same_cnt, on = ['ticker', 'datadate'], how = 'left')

icom_300 = icom_300.merge(i_mc, on = ['ticker', 'datadate'], how = 'left')
icom_300 = icom_300.merge(i_tk_t1y_seg, on = ['ticker', 'datadate'], how = 'left')

icom_300 = icom_300.merge(i_tk_t1y_salary, on = ['ticker', 'datadate'], how = 'left')


icom_300 = icom_300.sort_values('datadate')

icom_300['datadate_1y'] = icom_300['datadate'] - pd.to_timedelta('365 days')
icom_300 = pd.merge_asof(icom_300, i_bs, by = 'ticker', left_on = 'datadate_1y', right_on = 'datadate',
                         suffixes = ['', '_merge']) 
icom_300 = icom_300.rename(columns = {'c_asset':'c_asset_1y', 't_asset':'t_asset_1y','eqy'
:'eqy_1y', 'liab':'liab_1y'})
icom_300 = icom_300.drop(columns = ['datadate_merge'])

icom_300 = pd.merge_asof(icom_300, i_emp, by = 'ticker', left_on = 'datadate_1y', right_on = 'datadate',
                         suffixes = ['', '_merge'])
icom_300 = icom_300.rename(columns = {'STAFFNUM':'STAFFNUM_1y', 'STFFNUM_yy':'STFFNUM_yy_1y'})
icom_300 = icom_300.drop(columns = ['datadate_merge'])

icom_300 = pd.merge_asof(icom_300, i_sales_yy[['ticker', 'datadate', 'rev_yy']], 
                         by = 'ticker', left_on = 'datadate_1y', right_on = 'datadate',
                         suffixes = ['', '_merge'])
icom_300 = icom_300.rename(columns = {'rev_yy':'rev_yy_1y'})
icom_300 = icom_300.drop(columns = ['datadate_merge'])

icom_300 = icom_300.sort_values(['ticker','datadate'])



# Frequency comparison
icom2 = icom_300.copy()

icom2['job_t2y_df2y_dv_mc'] = (icom2['id_t2y'] - icom2['id_t2y_2y']).divide(icom2['mc_2y'])
icom2['job_t2y_df2y_dv_mc_rk'] = icom2.groupby('datadate')['job_t2y_df2y_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_t1y_df1y_dv_mc'] = (icom2['id_t1y'] - icom2['id_t1y_1y']).divide(icom2['mc_1y'])
icom2['job_t1y_df1y_dv_mc_rk'] = icom2.groupby('datadate')['job_t1y_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_t1q_df1q_dv_mc'] = (icom2['id_t1q'] - icom2['id_t1q_1q']).divide(icom2['mc_1q'])
icom2['job_t1q_df1q_dv_mc_rk'] = icom2.groupby('datadate')['job_t1q_df1q_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_t1m_df1m_dv_mc'] = (icom2['id_t1m'] - icom2['id_t1m_1m']).divide(icom2['mc_1m'])
icom2['job_t1m_df1m_dv_mc_rk'] = icom2.groupby('datadate')['job_t1m_df1m_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_t1w_df1w_dv_mc'] = (icom2['id_t1w'] - icom2['id_t1w_1w']).divide(icom2['mc_1w'])
icom2['job_t1w_df1w_dv_mc_rk'] = icom2.groupby('datadate')['job_t1w_df1w_dv_mc'].apply(yu.uniformed_rank).values



icom2['sgnl0'] = np.nan
c1 = icom2['job_t2y_df2y_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl0'] = icom2.loc[c1, 'job_t2y_df2y_dv_mc_rk']


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl0','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl0','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t2y_df2y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t2y_df2y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #pr
cs 


icom2['sgnl1'] = np.nan
c1 = icom2['job_t1y_df1y_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl1'] = icom2.loc[c1, 'job_t1y_df1y_dv_mc_rk']


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.01 / 1.69

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1y_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t1y_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 


icom2['sgnl2'] = np.nan
c1 = icom2['job_t1q_df1q_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl2'] = icom2.loc[c1, 'job_t1q_df1q_dv_mc_rk']

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1q_df1q_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t1q_df1q_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

icom2['sgnl3'] = np.nan
c1 = icom2['job_t1m_df1m_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl3'] = icom2.loc[c1, 'job_t1m_df1m_dv_mc_rk']


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1m_df1m_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t1m_df1m_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 


icom2['sgnl4'] = np.nan
c1 = icom2['job_t1w_df1w_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl4'] = icom2.loc[c1, 'job_t1w_df1w_dv_mc_rk']

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl4','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl4','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1w_df1w_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t
1w_df1w_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 




# Frequency comparison #2

icom2 = icom_300.copy()

icom2['job_t1y_df1y_dv_mc'] = (icom2['id_t1y'] - icom2['id_t1y_1y']).divide(icom2['mc_1y'])
icom2['job_t1y_df1y_dv_mc_rk'] = icom2.groupby('datadate')['job_t1y_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_t1y_df1q_dv_mc'] = (icom2['id_t1y'] - icom2['id_t1y_1q']).divide(icom2['mc_1q'])
icom2['job_t1y_df1q_dv_mc_rk'] = icom2.groupby('datadate')['job_t1y_df1q_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_t1y_df1m_dv_mc'] = (icom2['id_t1y'] - icom2['id_t1y_1m']).divide(icom2['mc_1m'])
icom2['job_t1y_df1m_dv_mc_rk'] = icom2.groupby('datadate')['job_t1y_df1m_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_t1y_df1w_dv_mc'] = (icom2['id_t1y'] - icom2['id_t1y_1w']).divide(icom2['mc_1w'])
icom2['job_t1y_df1w_dv_mc_rk'] = icom2.groupby('datadate')['job_t1y_df1w_dv_mc'].apply(yu.uniformed_rank).values


icom2['sgnl1'] = np.nan
c1 = icom2['job_t1y_df1y_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl1'] = icom2.loc[c1, 'job_t1y_df1y_dv_mc_rk']


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.01 / 1.69

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1y_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t1y_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 


icom2['sgnl2'] = np.nan
c1 = icom2['job_t1y_df1q_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl2'] = icom2.loc[c1, 'job_t1y_df1q_dv_mc_rk']

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1y_df1q_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t1y_df1q_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

icom2['sgnl3'] = np.nan
c1 = icom2['job_t1y_df1m_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl3'] = icom2.loc[c1, 'job_t1y_df1m_dv_mc_rk']


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(s
ubset=['ticker','datadate']),
            'sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1y_df1m_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t1y_df1m_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 


icom2['sgnl4'] = np.nan
c1 = icom2['job_t1y_df1w_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl4'] = icom2.loc[c1, 'job_t1y_df1w_dv_mc_rk']

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl4','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl4','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1y_df1w_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t1y_df1w_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 





# Denominator comparison


icom2 = icom_300.copy()

icom2['btop_rk'] = icom2.groupby('datadate')['BTOP'].apply(yu.uniformed_rank).values
icom2.loc[icom2['btop_rk']>=0, 'btop_2bk'] = 1
icom2.loc[icom2['btop_rk']<0, 'btop_2bk'] = 0
icom2['growth_rk'] = icom2.groupby('datadate')['GROWTH'].apply(yu.uniformed_rank).values
icom2.loc[icom2['growth_rk']>=0, 'growth_2bk'] = 1
icom2.loc[icom2['growth_rk']<0, 'growth_2bk'] = 0
icom2['earn_rk'] = icom2.groupby('datadate')['EARNYILD'].apply(yu.uniformed_rank).values
icom2.loc[icom2['earn_rk']>=0, 'earn_2bk'] = 1
icom2.loc[icom2['earn_rk']<0, 'earn_2bk'] = 0


icom2['job_t1y_df1y_dv_mc'] = (icom2['id_t1y'] - icom2['id_t1y_1y']).divide(icom2['mc_1y'])
icom2['job_t1y_df1y_dv_mc_rk'] = icom2.groupby('datadate')['job_t1y_df1y_dv_mc'].apply(yu.uniformed_rank).values

icom2['job_t1y_df1y_dv_ca'] = (icom2['id_t1y'] - icom2['id_t1y_1y']).divide(icom2['c_asset_1y'])
icom2['job_t1y_df1y_dv_ca_rk'] = icom2.groupby('datadate')['job_t1y_df1y_dv_ca'].apply(yu.uniformed_rank).values

icom2['job_t1y_df1y_dv_ta'] = (icom2['id_t1y'] - icom2['id_t1y_1y']).divide(icom2['t_asset_1y'])
icom2['job_t1y_df1y_dv_ta_rk'] = icom2.groupby('datadate')['job_t1y_df1y_dv_ta'].apply(yu.uniformed_rank).values

icom2['job_t1y_df1y_dv_emp'] = (icom2['id_t1y'] - icom2['id_t1y_1y']).divide(icom2['STAFFNUM_1y'])
icom2['job_t1y_df1y_dv_emp_rk'] = icom2.groupby('datadate')['job_t1y_df1y_dv_emp'].apply(yu.uniformed_rank).values

icom2['job_t1y_df1y_dv_eqy'] = (icom2['i
d_t1y'] - icom2['id_t1y_1y']).divide(icom2['eqy_1y'])
icom2['job_t1y_df1y_dv_eqy_rk'] = icom2.groupby('datadate')['job_t1y_df1y_dv_eqy'].apply(yu.uniformed_rank).values

icom2['job_t1y_df1y_dv_eqy2'] = (icom2['id_t1y'] - icom2['id_t1y_1y']).divide(icom2['t_asset_1y']-icom2['liab_1y'])
icom2['job_t1y_df1y_dv_eqy2_rk'] = icom2.groupby('datadate')['job_t1y_df1y_dv_eqy2'].apply(yu.uniformed_rank).values


icom2['sgnl1'] = np.nan
c1 = icom2['job_t1y_df1y_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl1'] = icom2.loc[c1, 'job_t1y_df1y_dv_mc_rk']

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.01 / 1.69


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1y_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t1y_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')&(icom2['btop_2bk']==1)].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.54 / 0.25
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')&(icom2['btop_2bk']==0)].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.0 / 1.74

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')&(icom2['growth_2bk']==1)].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.62 / 1.39
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')&(icom2['growth_2bk']==0)].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.13 / 0.84

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')&(icom2['earn_2bk']==1)].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.62 / 1.39
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')&(icom2['earn_2bk']==0)].\
  
          dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.13 / 0.84


icom2['sgnl2'] = np.nan
c1 = icom2['job_t1y_df1y_dv_ca_rk']>0.8
icom2.loc[c1, 'sgnl2'] = icom2.loc[c1, 'job_t1y_df1y_dv_ca_rk']

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1y_df1y_dv_ca_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t1y_df1y_dv_ca_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 


icom2['sgnl3'] = np.nan
c1 = icom2['job_t1y_df1y_dv_ta_rk']>0.8
icom2.loc[c1, 'sgnl3'] = icom2.loc[c1, 'job_t1y_df1y_dv_ta_rk']

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.72 / 0.5

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1y_df1y_dv_ta_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t1y_df1y_dv_ta_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 


icom2['sgnl4'] = np.nan
c1 = icom2['job_t1y_df1y_dv_emp_rk']>0.8
icom2.loc[c1, 'sgnl4'] = icom2.loc[c1, 'job_t1y_df1y_dv_emp_rk']

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl4','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl4','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1y_df1y_dv_emp_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t1y_df1y_dv_emp_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 


icom2['sgnl5'] = np.nan
c1 = icom2['job_t1y_df1y_dv_eqy_rk']>0.8
icom2.loc[c1, 'sgnl5'] = icom2.loc[c1, 'job_t1y_df1y_dv_eqy_rk']

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl5','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl5','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_1
5(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1y_df1y_dv_eqy_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t1y_df1y_dv_eqy_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 




icom2['sgnl6'] = np.nan
c1 = icom2['job_t1y_df1y_dv_eqy2_rk']>0.8
icom2.loc[c1, 'sgnl6'] = icom2.loc[c1, 'job_t1y_df1y_dv_eqy2_rk']

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl6','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl6','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1y_df1y_dv_eqy2_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t1y_df1y_dv_eqy2_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 




# count the jobs that are similar as before


icom2 = icom_300.copy()

icom2['jobSame_t1y_df1y'] = icom2['id_same_t1y'] - icom2['id_same_t1y_1y']
icom2['jobSame_t1y_df1y_dv_mc'] = icom2['jobSame_t1y_df1y'].divide(icom2['mc_1y'])
icom2['jobSame_t1y_df1y_dv_mc_rk'] = icom2.groupby('datadate')['jobSame_t1y_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['jobSame_t1y_df1y_dv_mc_bk'] = icom2.groupby('datadate')['jobSame_t1y_df1y_dv_mc'].apply(lambda x: yu.pdqcut(x, bins = 10)).values


icom2['sgnl4'] = np.nan
c1 = icom2['jobSame_t1y_df1y_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl4'] = icom2.loc[c1, 'jobSame_t1y_df1y_dv_mc_rk']


yu.create_cn_3x3(icom2, ['jobSame_t1y_df1y_dv_mc_bk'], 'jobSame_t1y_df1y_dv_mc')

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl4','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl4','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.48 / 2.24

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['jobSame_t1y_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jobSame_t1y_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.24 / 0.82



# txt segment ideas

icom2 = icom_300.copy()


icom2['seg_cnt_dv_mc'] = icom2['seg_cnt'].divide(icom2['mc_1y'])
icom2['seg_cnt_dv_mc_rk']  = icom2.groupby('datadate')['seg_cnt_dv_mc'].apply(yu.uniformed_rank).values
icom2['sgnl1'] = np.nan
c1 = icom2['seg_cnt_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl1'] = icom2.loc[c1, 'seg_cnt_dv_mc_rk']
o_1 = yu.b
t_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.06 / 0.7


icom2['seg_cnt_yy'] = icom2['seg_cnt'].divide(icom2['seg_cnt_1y'])
icom2['seg_cnt_yy_rk'] = icom2.groupby('datadate')['seg_cnt_yy'].apply(yu.uniformed_rank).values
icom2['sgnl2'] = np.nan
c1 = icom2['seg_cnt_yy_rk']>0.8
icom2.loc[c1, 'sgnl2'] = icom2.loc[c1, 'seg_cnt_yy_rk']
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.5 / 0.15


icom2['seg_cnt_df1y'] = icom2['seg_cnt'] - icom2['seg_cnt_1y']
icom2['seg_cnt_df1y_rk'] = icom2.groupby('datadate')['seg_cnt_df1y'].apply(yu.uniformed_rank).values
icom2['sgnl3'] = np.nan
c1 = icom2['seg_cnt_df1y_rk']>0.8
icom2.loc[c1, 'sgnl3'] = icom2.loc[c1, 'seg_cnt_df1y_rk']
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.81 / 1.32


icom2['segNew_cnt_df1y'] = icom2['segNew_cnt'] - icom2['seg_cnt_1y']
icom2['segNew_cnt_df1y_dv_mc'] = icom2['segNew_cnt_df1y'].divide(icom2['mc_1y'])
icom2['segNew_cnt_df1y_dv_mc_rk'] = icom2.groupby('datadate')['segNew_cnt_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['sgnl4'] = np.nan
c1 = icom2['segNew_cnt_df1y_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl4'] = icom2.loc[c1, 'segNew_cnt_df1y_dv_mc_rk']
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl4','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl4','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.81 / 1.32



icom2['segGone_cnt_df1y'] = icom2['segGone_cnt'] - icom2['seg_cnt_1y']
icom2['segGone_cnt_df1y_dv_mc'] = icom2['segGone_cnt_df1y'].divide(icom2['mc_1y'])
icom2['segGone_cnt_df1y_dv_mc_rk'] = icom2.groupby('datadate')['segGone_cnt_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['sgnl5'] = np.nan
c1 = icom2['segGone_cnt_df1y_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl5'] = icom2.loc[c1, 'segGone_cnt_df1y_dv_mc_rk']
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl5','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','dat
adate']),
            'sgnl5','BarrRet_CLIP_USD+1d', static_data = i_sd) # -0.05 / -0.65



# salary

icom2 = icom_300.copy()

icom2['salary_sum_df1y'] = icom2['salary_sum_t1y'] - icom2['salary_sum_t1y_1y']
icom2['salary_sum_df1y_dv_mc'] = icom2['salary_sum_df1y'].divide(icom2['mc_1y'])
icom2['salary_sum_df1y_dv_mc_rk'] = icom2.groupby('datadate')['salary_sum_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['sgnl1'] = np.nan
c1 = icom2['salary_sum_df1y_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl1'] = icom2.loc[c1, 'salary_sum_df1y_dv_mc_rk']
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['salary_sum_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'salary_sum_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 



icom2['salaryMin_sum_df1y'] = icom2['salaryMin_sum_t1y'] - icom2['salaryMin_sum_t1y_1y']
icom2['salaryMin_sum_df1y_dv_mc'] = icom2['salary_sum_df1y'].divide(icom2['mc_1y'])
icom2['salaryMin_sum_df1y_dv_mc_rk'] = icom2.groupby('datadate')['salaryMin_sum_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['sgnl2'] = np.nan
c1 = icom2['salaryMin_sum_df1y_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl2'] = icom2.loc[c1, 'salaryMin_sum_df1y_dv_mc_rk']
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['salaryMin_sum_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'salaryMin_sum_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 


icom2['salary_sum_df1y_dv_ta'] = icom2['salary_sum_df1y'].divide(icom2['t_asset_1y'])
icom2['salary_sum_df1y_dv_ta_rk'] = icom2.groupby('datadate')['salary_sum_df1y_dv_ta'].apply(yu.uniformed_rank).values
icom2['sgnl3'] = np.nan
c1 = icom2['salary_sum_df1y_dv_ta_rk']>0.8
icom2.loc[c1, 'sgnl3'] = icom2.loc[c1, 'salary_sum_df1y_dv_ta_rk']
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate'
]),
            'sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['salary_sum_df1y_dv_ta_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'salary_sum_df1y_dv_ta_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 


icom2['salaryMin_sum_df1y_dv_ta'] = icom2['salaryMin_sum_df1y'].divide(icom2['t_asset_1y'])
icom2['salaryMin_sum_df1y_dv_ta_rk'] = icom2.groupby('datadate')['salaryMin_sum_df1y_dv_ta'].apply(yu.uniformed_rank).values
c1 = icom2['salaryMin_sum_df1y_dv_ta_rk']>0.8
icom2.loc[c1, 'sgnl4'] = icom2.loc[c1, 'salaryMin_sum_df1y_dv_ta_rk']
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl4','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl4','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['salaryMin_sum_df1y_dv_ta_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'salaryMin_sum_df1y_dv_ta_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 




# conditioning on previous employee growth / sales growth 

icom2 = icom_300.copy()

icom2['job_t1y_df1y_dv_mc'] = (icom2['id_t1y'] - icom2['id_t1y_1y']).divide(icom2['mc_1y'])
icom2['job_t1y_df1y_dv_mc_rk'] = icom2.groupby('datadate')['job_t1y_df1y_dv_mc'].apply(yu.uniformed_rank).values

icom2['STFFNUM_yy_1y_rk'] = icom2.groupby('datadate')['STFFNUM_yy_1y'].apply(yu.uniformed_rank).values
icom2['rev_yy_1y_rk'] = icom2.groupby('datadate')['rev_yy_1y'].apply(yu.uniformed_rank).values


icom2['sgnl1'] = np.nan
c1 = icom2['job_t1y_df1y_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl1'] = icom2.loc[c1, 'job_t1y_df1y_dv_mc_rk']

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')&(icom2['STFFNUM_yy_1y_rk']>0)].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')&(icom2['STFFNUM_yy_1y_rk']<0)].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')&(icom2['rev_yy_1y_rk']>0)].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_dup
licates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')&(icom2['rev_yy_1y_rk']<0)].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 



#------------------------------------------------------------------------------
### ---- combine (a50 universe)
#------------------------------------------------------------------------------


icom_50 = i_sd_map[i_sd_map['a50_flag']==1].merge(i_tk_t1y_cnt, on = ['ticker', 'datadate'], how = 'left')
icom_50 = icom_50.merge(i_mc, on = ['ticker', 'datadate'], how = 'left')

icom_50['job_t1y_hhdf'] = icom_50['id_t1y'] - icom_50['id_t1y_1h']
icom_50['job_t1y_hhdf_dv_mc'] = icom_50['job_t1y_hhdf'].divide(icom_50['mc_1h'])
icom_50['job_t1y_hhdf_dv_mc_rk'] = icom_50.groupby('datadate')['job_t1y_hhdf_dv_mc'].apply(yu.uniformed_rank).values


icom_50['sgnl1'] = np.nan
c1 = (icom_50['job_t1y_hhdf_dv_mc_rk']>0.8) 
icom_50.loc[c1, 'sgnl1'] = icom_50.loc[c1, 'job_t1y_hhdf_dv_mc_rk']



o_1 = yu.bt_cn_15(icom_50[(icom_50['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.86 / 0.17


o_1 = yu.bt_cn_15(icom_50[(icom_50['datadate']<='2019-12-31')].\
            dropna(subset=['job_t1y_hhdf_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'job_t1y_hhdf_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.86 / 0.17




