﻿#$%^&* pVA_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat May 30 13:12:00 2020

@author: thzhang
"""

import pandas as pd
import numpy as np
import os 

from yz import tic, toc

import time

import gc

# this script feteches normalized data from Z drive and save parquet per ticker


# get all normalized file names 

filelist = []
t1 = time.time()
for root, dirs, files in os.walk(r'Z:\VisibleAlpha\Normalized'):
	for file in files:
		filelist.append(os.path.join(root,file))
print (time.time()-t1) # 1200s



# process and classify the file names

va = pd.DataFrame(filelist, columns = ['raw_dir_file_name'])

va['raw_file_name'] = va['raw_dir_file_name'].str.split('\\').str[-1]
va['raw_file_name'] = va['raw_file_name'].str.extract('(.*?).csv')

va['meta_data'] = ''
va.loc[va['raw_file_name'].str[:4].str.lower()=='meta','meta_data'] = 'm'
va.loc[va['raw_file_name'].str[:4].str.lower()=='data','meta_data'] = 'd'
va.loc[va['raw_file_name'].str[:4].str.lower()=='symb','meta_data'] = 'symbology'
va.loc[va['raw_file_name'].str[:4].str.lower()=='view','meta_data'] = 'viewname'

cond_not_s_v = (va['meta_data']!='symbology') & (va['meta_data']!='viewname')

va['id'] = ''
va.loc[cond_not_s_v,'id'] = va.loc[cond_not_s_v,'raw_file_name'].str.split('_').str[1]

va['ticker'] = ''
va.loc[cond_not_s_v,'ticker'] = va.loc[cond_not_s_v,'raw_file_name'].str.split('_').str[2]

va['std_nme'] = ''
va.loc[cond_not_s_v,'std_nme'] = va.loc[cond_not_s_v,'raw_file_name'].str.split('_').str[-3].str[0]

va['broker'] = ''
va.loc[cond_not_s_v,'broker'] = va.loc[cond_not_s_v,'raw_file_name'].str.split('_').str[-2]

va['loaddate'] = pd.to_datetime(va['raw_file_name'].str.split('_').str[-1].str.split('.').str[0], format = '%Y%m%dT%H%M%S%f')

va.to_parquet(r'S:\Data\CHC_research\VA\ref\va_normalized_full_file_dir.parquet',allow_truncated_timestamps=True)

# Just focus on aggregated data for now

# consensus data
va_con = va[(va['broker']=='CONSENSUS') & (va['meta_data']=='d')]
va_con['loaddatestr'] = va_con['raw_file_name'].str.split('_').str[-1]

###############################################################################
# fetch consensus data save it as parquets
###############################################################################

def fetch_files(i, r):
    f = r['raw_dir_file_name']
    try:
        d1 = pd.read_csv(f, encoding = 'latin1')
        d1 = d1[d1['Datapoint type']!='Actual']
    except pd.io.common.EmptyDataError:
        d1 = pd.DataFrame([], columns = ['Pa
rameter ID','Period','Revision Date','Value','Datapoint type',
                          'Number of Brokers','Min','Max','Median','Standard Deviation','Mode'])
    
    try:
        m1 = pd.read_csv(f.replace('data_','meta_'), encoding = 'latin1')
    except FileNotFoundError:
        m1 = pd.read_csv(f.replace('data_','meta_').split('.csv')[0]+'.csv', encoding = 'latin1')
    a1 = d1.merge(m1, on = 'Parameter ID', how = 'left')
    return a1
    




for symb in va_con['id'].unique().tolist()[647:1000]:
    
    tic()
    
    file_lists = va_con[va_con['id']==symb]

    stock_data = pd.concat((fetch_files(i,r) for i, r in file_lists.iterrows()), ignore_index = True, sort = False)
    stock_data['asofdate'] = pd.to_datetime(stock_data['Revision Date'], format='%Y%m%dT%H%M%S%f', errors = 'coerce')
    cond_nan_ts = pd.isnull(stock_data['asofdate'])
    stock_data.loc[cond_nan_ts,'asofdate'] = pd.to_datetime(stock_data.loc[cond_nan_ts,'Revision Date'])
    stock_data = stock_data.drop(columns = ['Revision Date'])
    stock_data = stock_data.drop_duplicates()
    stock_data['Symbology_ID'] = symb
    stock_data.to_parquet(os.path.join(r'S:\Data\CHC_research\VA\consensus_1',symb + '.parquet' ),allow_truncated_timestamps=True)
    
    del stock_data
    gc.collect()
    
    toc(' ' +symb+ ', ')






###############################################################################
# actual data
###############################################################################

va_a = va[(va['broker']=='VAACTUALS') & (va['meta_data']=='d')]
va_a['loaddatestr'] = va_a['raw_file_name'].str.split('_').str[-1]


def fetch_files2(i, r):
    f = r['raw_dir_file_name']
    
    try:
        d1 = pd.read_csv(f, encoding = 'latin1')
        d1 = d1[d1['Datapoint type']=='Actual']
    except pd.io.common.EmptyDataError:
        d1 = pd.DataFrame([], columns = ['Parameter ID','Period','Revision Date','Value','Datapoint type','Mode of Calculation'])
    try:
        m1 = pd.read_csv(f.replace('data_','meta_'), encoding = 'latin1')
    except FileNotFoundError:
        m1 = pd.read_csv(f.replace('data_','meta_').split('.csv')[0]+'.csv', encoding = 'latin1')
    a1 = d1.merge(m1, on = 'Parameter ID', how = 'left')
    return a1
    

for symb in va_a['id'].unique().tolist()[5000:]:
    
    tic()
    
    file_lists = va_a[va_a['id']==symb]

    stock_data = pd.concat((fetch_files2(i,r) for i, r in file_lists.iterrows()), ignore_index = True, sort = False)
    stock_data['asofd
ate'] = pd.to_datetime(stock_data['Revision Date'], format='%Y%m%dT%H%M%S%f', errors = 'coerce')
    cond_nan_ts = pd.isnull(stock_data['asofdate'])
    stock_data.loc[cond_nan_ts,'asofdate'] = pd.to_datetime(stock_data.loc[cond_nan_ts,'Revision Date'])
    stock_data = stock_data.drop(columns = ['Revision Date'])
    stock_data = stock_data.drop_duplicates()
    stock_data['Symbology_ID'] = symb
    stock_data.to_parquet(os.path.join(r'S:\Data\CHC_research\VA\actual_1',symb + '.parquet' ),allow_truncated_timestamps=True)
    
    del stock_data
    gc.collect()
    
    toc(' ' +symb+ ', ')





###############################################################################
# filing data
###############################################################################

va_f = va[(va['broker']=='Filings') & (va['meta_data']=='d')]
va_f['loaddatestr'] = va_f['raw_file_name'].str.split('_').str[-1]


def fetch_files3(i, r):
    f = r['raw_dir_file_name']
    d1 = pd.read_csv(f, encoding = 'latin1')
    d1 = d1[d1['Datapoint type']=='Actual']
    try:
        m1 = pd.read_csv(f.replace('data_','meta_'), encoding = 'latin1')
    except FileNotFoundError:
        m1 = pd.read_csv(f.replace('data_','meta_').split('.csv')[0]+'.csv', encoding = 'latin1')
    a1 = d1.merge(m1, on = 'Parameter ID', how = 'left')
    return a1
    

for symb in va_f['id'].unique().tolist()[4000:]:
    
    tic()
    
    file_lists = va_f[va_f['id']==symb]

    stock_data = pd.concat((fetch_files3(i,r) for i, r in file_lists.iterrows()), ignore_index = True, sort = False)
    stock_data['asofdate'] = pd.to_datetime(stock_data['Revision Date'], format='%Y%m%dT%H%M%S%f', errors = 'coerce')
    cond_nan_ts = pd.isnull(stock_data['asofdate'])
    stock_data.loc[cond_nan_ts,'asofdate'] = pd.to_datetime(stock_data.loc[cond_nan_ts,'Revision Date'])
    stock_data = stock_data.drop(columns = ['Revision Date'])
    stock_data = stock_data.drop_duplicates()
    stock_data ['Effective End'] = pd.to_datetime(stock_data ['Effective End'])
    stock_data['Symbology_ID'] = symb
    stock_data.to_parquet(os.path.join(r'S:\Data\CHC_research\VA\nme_Filings',symb + '.parquet' ),allow_truncated_timestamps=True)
    
    del stock_data
    gc.collect()
    
    toc(' ' +symb+ ', ')


