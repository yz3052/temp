﻿#$%^&* pL2_cn_order_onTopBidAsk.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 29 22:31:00 2022

@author: thzhang
"""


import pandas as pd 
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime


### get sd


i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values('datadate')


### get q 

i_metrics = yu.get_q('get `:/export/datadev/Data/SHSZ/ORDER_metrics/orderbook_metrics_batch1_08', port=5001)

i_metrics['code'] = i_metrics['code'].str.decode('utf8')
c_sh = i_metrics['code'].str[0].isin(['6'])
c_sz = i_metrics['code'].str[0].isin(['0','3'])
i_metrics.loc[c_sh, 'ticker'] = i_metrics.loc[c_sh, 'code'] + '.SH'
i_metrics.loc[c_sz, 'ticker'] = i_metrics.loc[c_sz, 'code'] + '.SZ'
i_metrics['datadate'] = pd.to_datetime(i_metrics['date'])
i_metrics = i_metrics.sort_values(['ticker', 'datadate'])
i_metrics = i_metrics[i_metrics['ticker'].notnull()]


###

icom = i_sd.merge(i_metrics, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom_ind = pd.get_dummies(icom['GIND'])
icom = pd.concat([icom, icom_ind], axis = 1)
cols_i = icom_ind.columns.tolist()
cols_f =  ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 
           'LEVERAGE', 'LIQUIDTY', 'SIZENL']


### net

icom['net_dv_v'] = (icom['v_buy_ontop'] - icom['v_sell_ontop']) / icom['V_l1d']
icom['net_dv_v_bk'] = icom.groupby('datadate')['net_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['pv_bk'] = icom.groupby('datadate')['avgPVadj'].apply(lambda x: yu.pdqcut(x,bins=5)).values
icom['net_dv_v_pvbk'] = icom.groupby(['datadate','pv_bk'])['net_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['net_dv_v_orth'] = icom.groupby('datadate')[cols_i + cols_f + ['net_dv_v', 'SRISK']].apply(lambda x: yu.orthogonalize_cn_v3(x['net_dv_v'], x[cols_f], x[cols_i], x['SRISK'])).values
icom['net_dv_v_orth_bk'] = icom.groupby('datadate')['net_dv_v_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values


icom['net_dv_v_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),min_periods=5,on='datadate')['net_dv_v'].mean().values
icom['net_dv_v_t20d_orth'] = icom.groupby('datadate')[cols_i + cols_f + ['net_dv_v_orth', 'SRISK']].apply(lambda x: yu.orthogonalize_cn_v3(x['net_dv_v_orth'], x[cols_f], x[cols_i], x['SRISK'])).values
icom['net_dv_v_t20d_orth_bk'] = icom.groupby('datadate')['net_dv_v_t20d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['net_dv_v_pvbk'], 'net_dv_v') # al
l v-shaped
yu.create_cn_3x3(icom, ['net_dv_v_bk'], 'net_dv_v')
yu.create_cn_3x3(icom, ['net_dv_v_orth_bk'], 'net_dv_v')
yu.create_cn_3x3(icom, ['net_dv_v_t20d_orth_bk'], 'net_dv_v_t20d_orth')


### sum

icom['sum_dv_v'] = (icom['v_buy_ontop'] + icom['v_sell_ontop']) / icom['V_l1d']
icom['sum_dv_od'] = (icom['v_buy_ontop'] + icom['v_sell_ontop']) / icom['V_l1d']
icom['sum_dv_v_bk'] = icom.groupby('datadate')['sum_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['sum_dv_od_bk'] = icom.groupby('datadate')['sum_dv_od'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['sum_dv_v_bk'], 'sum_dv_v') # mono: -3 -4 +4
yu.create_cn_3x3(icom, ['sum_dv_od_bk'], 'sum_dv_od') # mono: -3 -4 +4

icom['sum_dv_v_orth'] = icom.groupby('datadate')[cols_i + cols_f + ['sum_dv_v', 'SRISK']].apply(lambda x: yu.orthogonalize_cn_v3(x['sum_dv_v'], x[cols_f], x[cols_i], x['SRISK'])).values
icom['sum_dv_v_orth_bk'] = icom.groupby('datadate')['sum_dv_v_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['sum_dv_v_orth_bk'], 'sum_dv_v_orth') # mono: -6 +4

icom['sum_dv_v_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate',min_periods=5)['sum_dv_v'].mean().values
icom['sum_dv_v_t20d_orth'] = icom.groupby('datadate')[cols_i + cols_f + ['sum_dv_v_t20d', 'SRISK']].apply(lambda x: yu.orthogonalize_cn_v3(x['sum_dv_v_t20d'], x[cols_f], x[cols_i], x['SRISK'])).values
icom['sum_dv_v_t20d_orth_bk'] = icom.groupby('datadate')['sum_dv_v_t20d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['sum_dv_v_t20d_orth_bk'], 'sum_dv_v_t20d') # mono: -2.5 +3


icom['sum_dv_v_t20d_orth_rk'] = icom.groupby('datadate')['sum_dv_v_t20d_orth'].apply(yu.uniformed_rank)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sum_dv_v_t20d_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sum_dv_v_t20d_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.0/0.92/-1.22

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31') & icom['sum_dv_v_t20d_orth_rk'].abs().gt(0.8)].\
            dropna(subset=['sum_dv_v_t20d_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sum_dv_v_t20d_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #1.52/0.25/-1.06
