﻿#$%^&* pL2_cn_order_captureTWAP3s60s.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 24 16:04:09 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime



#  This studies TWAP capture data



### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])




### get TWAP capture data v2

i_captwap36 = yu.get_q('''(get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sh_captureTWAP_3s60s),
                         (get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sz_captureTWAP_3s60s) ''')

i_captwap36['code'] = i_captwap36['code'].str.decode('utf8')
c_sh = i_captwap36['code'].str[0].isin(['6'])
c_sz = i_captwap36['code'].str[0].isin(['0','3'])
i_captwap36.loc[c_sh, 'ticker'] = i_captwap36.loc[c_sh, 'code'] + '.SH'
i_captwap36.loc[c_sz, 'ticker'] = i_captwap36.loc[c_sz, 'code'] + '.SZ'
i_captwap36['datadate'] = pd.to_datetime(i_captwap36['date'])
i_captwap36 = i_captwap36.sort_values(['ticker', 'datadate'])
i_captwap36 = i_captwap36[i_captwap36['ticker'].notnull()]



### combine

icom = i_sd.merge(i_captwap36, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
#'cntV2_3s_periods', 'cntV2_tot_x3', 'cntV2_tot_top3s_x3', 'cntV2_b_tot_x3', 'cntV2_b_tot_top3s_x3', 
#'cnt_lt3s_avgPs', 'cnt_gt3s_avgPs', 'cnt_lt3s_tot', 'cnt_gt3s_tot', 'cnt_order_tot', 
#'cnt_b_lt3s_tot', 'cnt_b_gt3s_tot', 'cnt_b_order_tot'



### 3s signal


icom['v2_top3s_x3_dv_tot'] = icom['cntV2_tot_top3s_x3'].divide(icom['cntV2_tot_x3'])
icom['v2_top3s_x3_dv_tot_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['v2_top3s_x3_dv_tot'].mean().values
icom['v2_top3s_x3_dv_tot_t20d_orth'] = icom.groupby('datadate')[['v2_top3s_x3_dv_tot_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['v2_top3s_x3_dv_tot_t20d'], x[COLS])).values
icom['v2_top3s_x3_dv_tot_t20d_orth_bk'] = icom.groupby('datadate')['v2_top3s_x3_dv_tot_t20d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['v2_top3s_x3_dv_tot_t20d_orth_sgnl'] = icom.groupby('datadate')['v2_top3s_x3_dv_tot_t20d_orth'].apply(yu.uniformed_rank).values

#yu.create_cn_3x3(icom, ['v2_top3s_x3_dv_tot_t20d_orth_bk'], 'v2_top3s_x3_dv_tot_t20d_orth') # mono: -8 +6 +4
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna
(subset=['v2_top3s_x3_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v2_top3s_x3_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.26/3.08 5e7




### 60s signal
# bid only is worse than tot


icom['lt3s_b_dv_tot'] = icom['cnt_b_lt3s_tot'].divide(icom['cnt_b_order_tot'])
icom.loc[icom['cnt_lt3s_avgPs']<icom['cnt_gt3s_avgPs'], 'lt3s_b_dv_tot'] = np.nan
icom['lt3s_b_dv_tot_bk'] = icom.groupby('datadate')['lt3s_b_dv_tot'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom,['lt3s_b_dv_tot_bk'], 'lt3s_b_dv_tot') # less mono

icom['lt3s_dv_tot'] = icom['cnt_lt3s_tot'].divide(icom['cnt_order_tot'])
icom.loc[icom['cnt_lt3s_avgPs']<icom['cnt_gt3s_avgPs']*1.01, 'lt3s_dv_tot'] = np.nan
icom['lt3s_dv_tot_bk'] = icom.groupby('datadate')['lt3s_dv_tot'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['lt3s_dv_tot_orth'] = icom.groupby('datadate')[['lt3s_dv_tot']+COLS].apply(lambda x: yu.orthogonalize_cn(x['lt3s_dv_tot'], x[COLS])).values
icom['lt3s_dv_tot_orth_bk'] = icom.groupby('datadate')['lt3s_dv_tot_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['lt3s_dv_tot_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['lt3s_dv_tot'].mean().values
icom['lt3s_dv_tot_t20d_orth'] = icom.groupby('datadate')[['lt3s_dv_tot_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['lt3s_dv_tot_t20d'], x[COLS])).values
icom['lt3s_dv_tot_t20d_orth_bk'] = icom.groupby('datadate')['lt3s_dv_tot_t20d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['lt3s_dv_tot_t20d_orth_sgnl'] = icom.groupby('datadate')['lt3s_dv_tot_t20d_orth'].apply(yu.uniformed_rank).values

#yu.create_cn_3x3(icom,['lt3s_dv_tot_bk'], 'lt3s_dv_tot') # mono: -3.5 +5
#yu.create_cn_3x3(icom,['lt3s_dv_tot_orth_bk'], 'lt3s_dv_tot_orth') #  less mono: -2 -4 +6
#yu.create_cn_3x3(icom,['lt3s_dv_tot_t20d_orth_bk'], 'lt3s_dv_tot_t20d_orth') # mono: -9 +6

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['lt3s_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'lt3s_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 5.21/3.04 4.5e7




### 3s 60s

icom['lt3s_dv_tot'] = icom['cnt_lt3s_tot'].divide(icom['cnt_order_tot'])
icom.loc[icom['cnt_lt3s_avgPs']<icom['cnt_gt3s_avgPs']*1.01, 'lt3s_dv_tot'] = np.nan
icom['lt3s_dv_tot_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=2
8),on='datadate')['lt3s_dv_tot'].mean().values
icom['lt3s_dv_tot_t20d_orth'] = icom.groupby('datadate')[['lt3s_dv_tot_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['lt3s_dv_tot_t20d'], x[COLS])).values
icom['lt3s_dv_tot_t20d_orth_sgnl'] = icom.groupby('datadate')['lt3s_dv_tot_t20d_orth'].apply(yu.uniformed_rank).values

icom['v2_top3s_x3_dv_tot'] = icom['cntV2_tot_top3s_x3'].divide(icom['cnt_order_tot'])
icom['v2_top3s_x3_dv_tot_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['v2_top3s_x3_dv_tot'].mean().values
icom['v2_top3s_x3_dv_tot_t20d_orth'] = icom.groupby('datadate')[['v2_top3s_x3_dv_tot_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['v2_top3s_x3_dv_tot_t20d'], x[COLS])).values
icom['v2_top3s_x3_dv_tot_t20d_orth_sgnl'] = icom.groupby('datadate')['v2_top3s_x3_dv_tot_t20d_orth'].apply(yu.uniformed_rank).values

icom['test1'] = icom['lt3s_dv_tot'].add(icom['v2_top3s_x3_dv_tot'], fill_value = 0)
icom['test1_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['test1'].mean().values
icom['test1_t20d_orth'] = icom.groupby('datadate')[['test1_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['test1_t20d'], x[COLS])).values
icom['test1_t20d_orth_sgnl'] = icom.groupby('datadate')['test1_t20d_orth'].apply(yu.uniformed_rank).values

icom['test1b'] = icom[['lt3s_dv_tot','v2_top3s_x3_dv_tot']].mean(axis=1)
icom['test1b_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['test1b'].mean().values
icom['test1b_t20d_orth'] = icom.groupby('datadate')[['test1b_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['test1b_t20d'], x[COLS])).values
icom['test1b_t20d_orth_sgnl'] = icom.groupby('datadate')['test1b_t20d_orth'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['test1_t20d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test1_t20d_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.47 / 1.54
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['test1b_t20d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test1b_t20d_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.03/-1.84




icom['test2'] = icom[['lt3s_dv_tot_t20d_orth_sgnl', 'v2_top3s_x3_dv_tot_t20d_orth_sgnl']].sum(axis = 1)
icom['test2_sgnl'] = icom.groupby('datadate')['test2'].apply(yu.uniformed_r
ank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['test2_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test2_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #4.98 / 3.5 6e7 ###!!!


icom['test3'] = icom[['lt3s_dv_tot_t20d_orth_sgnl', 'v2_top3s_x3_dv_tot_t20d_orth_sgnl']].mean(axis = 1)
icom['test3_sgnl'] = icom.groupby('datadate')['test3'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['test3_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test3_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #5.01/3.53 6e7






#------------------------------------------------------------------------------
### variations #1 gf
#------------------------------------------------------------------------------




i_captwaprn = yu.get_q('''(get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sh_captureTWAP_3s_v2_random),
                         (get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sz_captureTWAP_3s_v2_random) ''')

i_captwaprn['code'] = i_captwaprn['code'].str.decode('utf8')
c_sh = i_captwaprn['code'].str[0].isin(['6'])
c_sz = i_captwaprn['code'].str[0].isin(['0','3'])
i_captwaprn.loc[c_sh, 'ticker'] = i_captwaprn.loc[c_sh, 'code'] + '.SH'
i_captwaprn.loc[c_sz, 'ticker'] = i_captwaprn.loc[c_sz, 'code'] + '.SZ'
i_captwaprn['datadate'] = pd.to_datetime(i_captwaprn['date'])
i_captwaprn = i_captwaprn.sort_values(['ticker', 'datadate'])
i_captwaprn = i_captwaprn[i_captwaprn['ticker'].notnull()]



icom2 = i_sd.merge(i_captwaprn, on = ['ticker', 'datadate'], how = 'left')
icom2 = icom2.merge(i_captwap36[['ticker','datadate','cnt_order_tot']], on = ['ticker', 'datadate'], how = 'left')
icom2 = icom2.sort_values(['ticker', 'datadate'])

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
#   'cntV2_3s_periods', 'cntV2_tot_x3',
#   'cntV2_tot_top3s_x3', 'cntV3_tot_x3', 'cntV3_tot_top3s_x3',
#   'cntV4_tot_x3', 'cntV4_tot_top3s_x3', 'cntV2_b_tot_x3',
#   'cntV2_b_tot_top3s_x3', 'cntV2_tot_x3_strict',
#   'cntV2_tot_top3s_x3_strict', 'cntV2_3s_periods_strict'



icom2['v2_top3s_x3_dv_tot'] = icom2['cntV2_tot_top3s_x3'].divide(icom2['cntV2_tot_x3']).replace(0,np.nan)
icom2['v2_top3s_x3_dv_tot_t20d'] = icom2.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['v2_top3s_x3_dv_tot']
.mean().values
icom2['v2_top3s_x3_dv_tot_t20d_orth'] = icom2.groupby('datadate')[['v2_top3s_x3_dv_tot_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['v2_top3s_x3_dv_tot_t20d'], x[COLS])).values
icom2['v2_top3s_x3_dv_tot_t20d_orth_sgnl'] = icom2.groupby('datadate')['v2_top3s_x3_dv_tot_t20d_orth'].apply(yu.uniformed_rank).values

icom2['v3_top3s_x3_dv_tot'] = icom2['cntV3_tot_top3s_x3'].divide(icom2['cntV2_tot_x3'])
icom2['v3_top3s_x3_dv_tot_t20d'] = icom2.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['v3_top3s_x3_dv_tot'].mean().values
icom2['v3_top3s_x3_dv_tot_t20d_orth'] = icom2.groupby('datadate')[['v3_top3s_x3_dv_tot_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['v3_top3s_x3_dv_tot_t20d'], x[COLS])).values
icom2['v3_top3s_x3_dv_tot_t20d_orth_sgnl'] = icom2.groupby('datadate')['v3_top3s_x3_dv_tot_t20d_orth'].apply(yu.uniformed_rank).values

icom2['v4_top3s_x3_dv_tot'] = icom2['cntV4_tot_top3s_x3'].divide(icom2['cntV2_tot_x3'])
icom2['v4_top3s_x3_dv_tot_t20d'] = icom2.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['v4_top3s_x3_dv_tot'].mean().values
icom2['v4_top3s_x3_dv_tot_t20d_orth'] = icom2.groupby('datadate')[['v4_top3s_x3_dv_tot_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['v4_top3s_x3_dv_tot_t20d'], x[COLS])).values
icom2['v4_top3s_x3_dv_tot_t20d_orth_sgnl'] = icom2.groupby('datadate')['v4_top3s_x3_dv_tot_t20d_orth'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom2[(icom2['datadate'].dt.year<=2020)].\
            dropna(subset=['v2_top3s_x3_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v2_top3s_x3_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd)

o_1 = yu.bt_cn_15(icom2[(icom2['datadate'].dt.year<=2020)].\
            dropna(subset=['v3_top3s_x3_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v3_top3s_x3_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # this is the best

o_1 = yu.bt_cn_15(icom2[(icom2['datadate'].dt.year<=2020)].\
            dropna(subset=['v4_top3s_x3_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v4_top3s_x3_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd)







#------------------------------------------------------------------------------
### variations 2 
#---------------------------------------------------------------------------
---




i_captwap3 = yu.get_q('''(get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sh_captureTWAP_3s_v3),
                         (get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sz_captureTWAP_3s_v3) ''')

i_captwap3['code'] = i_captwap3['code'].str.decode('utf8')
c_sh = i_captwap3['code'].str[0].isin(['6'])
c_sz = i_captwap3['code'].str[0].isin(['0','3'])
i_captwap3.loc[c_sh, 'ticker'] = i_captwap3.loc[c_sh, 'code'] + '.SH'
i_captwap3.loc[c_sz, 'ticker'] = i_captwap3.loc[c_sz, 'code'] + '.SZ'
i_captwap3['datadate'] = pd.to_datetime(i_captwap3['date'])
i_captwap3 = i_captwap3.sort_values(['ticker', 'datadate'])
i_captwap3 = i_captwap3[i_captwap3['ticker'].notnull()]



icom2 = i_sd.merge(i_captwap3, on = ['ticker', 'datadate'], how = 'left')
icom2 = icom2.merge(i_captwap36[['ticker','datadate','cnt_order_tot']], on = ['ticker', 'datadate'], how = 'left')
icom2 = icom2.sort_values(['ticker', 'datadate'])

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
#   'cntV2_3s_periods', 'cntV2_tot_x3',
#   'cntV2_tot_top3s_x3', 'cntV3_tot_x3', 'cntV3_tot_top3s_x3',
#   'cntV4_tot_x3', 'cntV4_tot_top3s_x3', 'cntV2_b_tot_x3',
#   'cntV2_b_tot_top3s_x3', 'cntV2_tot_x3_strict',
#   'cntV2_tot_top3s_x3_strict', 'cntV2_3s_periods_strict'



icom2['v3p5_top3s_x3_dv_tot'] = icom2['cntV3p5_tot_top3s_x3'].divide(icom2['cnt_tot_x3']).replace(0,np.nan)
icom2['v3p5_top3s_x3_dv_tot_t20d'] = icom2.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['v3p5_top3s_x3_dv_tot'].mean().values
icom2['v3p5_top3s_x3_dv_tot_t20d_orth'] = icom2.groupby('datadate')[['v3p5_top3s_x3_dv_tot_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['v3p5_top3s_x3_dv_tot_t20d'], x[COLS])).values
icom2['v3p5_top3s_x3_dv_tot_t20d_orth_sgnl'] = icom2.groupby('datadate')['v3p5_top3s_x3_dv_tot_t20d_orth'].apply(yu.uniformed_rank).values


icom2['v3p6_top3s_x3_dv_tot'] = icom2['cntV3p6_tot_top3s_x3'].divide(icom2['cnt_tot_x3']).replace(0,np.nan)
icom2['v3p6_top3s_x3_dv_tot_t20d'] = icom2.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['v3p6_top3s_x3_dv_tot'].mean().values
icom2['v3p6_top3s_x3_dv_tot_t20d_orth'] = icom2.groupby('datadate')[['v3p6_top3s_x3_dv_tot_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['v3p6_top3s_x3_dv_tot_t20d'], x[COLS])).values
icom2['v3p6_top3s_x3_dv_tot_t20d_orth_sgnl'] = icom2.groupby('datadate')['v3p6_top3s_x3_dv_tot_t20d_orth'].apply(yu.uniformed_rank).values


o_1 = yu.bt_cn_15(icom2[(icom2['datadate'].dt.year<=2020)].\
            dropna(subset=['v3p5_top3s_x3_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v3p5_top3s_x3_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #1.22 / 0.2

o_1 = yu.bt_cn_15(icom2[(icom2['datadate'].dt.year<=2020)].\
            dropna(subset=['v3p6_top3s_x3_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v3p6_top3s_x3_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.24/0.35
