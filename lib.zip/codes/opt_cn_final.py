﻿#$%^&* opt_cn_final.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 26 10:23:12 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import os
import datetime

import util as yu
import opt_cn_lib as opt

# input: a signal
# output: PNL of optimized portfoliko


### get alpha

i_sd = yu.get_sd_cn_1800()
#i_sd = yu.get_sd_cn_3000()


root = '/dat/summit_capital/TZ/backtester/xg'

i_folders = os.listdir(root)
i_folders = [i for i in i_folders if i in ['test_enrich_20230423_imm20retv1_perday_insigvalue_2pct']]
i_txt = []
for fd in i_folders:
    for f in os.listdir(os.path.join(root, fd)):
        if f.endswith('.txt') and (not 'fscore' in f):
            i_txt.append(os.path.join(root, fd, f))

i_xg = pd.concat(pd.read_csv(f,sep='|') for f in i_txt)

i_xg['Ticker']  = i_xg['Ticker'].astype(str).str.zfill(6)
i_xg['DataDate'] = pd.to_datetime(i_xg['DataDate'])

# i_xg = pd.read_parquet('/dat/summit_capital/TZ/tmp/vz_pnl_alpha2.parquet')


### combine

icom = i_sd.merge(i_xg, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom.sort_values(['Ticker', 'DataDate'])
#icom = icom.drop_duplicates(subset=['Ticker', 'DataDate'], keep = 'last')

icom['yhat_t10d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=14),on='DataDate',min_periods=1)['yhat'].mean().values 

#icom['alpha'] = icom.groupby('DataDate')['yhat'].apply(yu.uniformed_rank)
icom['alpha'] = icom.groupby('DataDate')['yhat_t10d'].apply(yu.uniformed_rank)





# o_1 = yu.bt_cn_15_linux(icom[ icom['DataDate'].between('2018-01-01', '2020-12-31') ].\
#             dropna(subset=['alpha','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
#             'alpha','BarrRet_CLIP_USD+1d', static_data = i_sd)


opt.serchopt(50e6, 0.5, 0.3, True, True, '20190101', '20211231', icom , False)
#opt.serchopt(50e6, 0.5, 0.3, True, True, '20190101', '20221015', icom , False)
#opt.serchopt(50e6, 0.5, 0.3, True, True, '20210101', '20221015', icom , False)


#from sqlalchemy import create_engine
#import urllib
#engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
#icom[['Ticker', 'DataDate', 'alpha']].to_sql('xgb_results_221102', engine)
#icom[['Ticker', 'DataDate', 'alpha']].to_csv('/dat/summit_capital/TZ/tmp/xgboost_result_221103.txt', index=False)
#freebcp [CNDBDEV].[dbo].[xgb_results_221102] in /d
at/summit_capital/TZ/tmp/xgboost_result_221103.txt -S summitsqldb -U svc_tz_dbo -P 1wutRe2tidripri -c -t ','
	


