﻿#$%^&* pWIND_strat_mutualfund_03.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 29 12:10:18 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu



# this studies the asset fire sales paper, by Coval and Stafford 2005
# https://www.nber.org/system/files/working_papers/w11357/w11357.pdf



### estimated position

i_estpos = yu.get_sql('''select * 
                      from wind.dbo.ChinaMutualFundPosEstimation a
                      inner join ''')

### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['ticker','datadate'])
i_sd['adv_t20d'] = i_sd.groupby('ticker').rolling(20)['V_l1d'].mean().values
i_sd = i_sd.sort_values('datadate')

i_sd_dd = i_sd['datadate'].drop_duplicates()


### fund type

i_mf_style = yu.get_sql('''select f_info_windcode, f_info_fund_id as s_info_compcode, 
                        f_info_firstinvesttype, f_info_firstinveststyle 
                        from wind.dbo.ChinaMutualFundDescription''')
i_mf_style = i_mf_style[i_mf_style['f_info_firstinvesttype'].isin(['混合型','股票型']) &\
                        (i_mf_style['f_info_firstinveststyle']!='被动指数型')]


### NAV / unit 
# 复权单位净值=单位净值F_NAV_UNIT*复权因子；

i_nav = yu.get_sql('''select a.f_info_windcode as ticker_fund,
                   a.ann_Date as datadate,
                   a.price_date as report_period, 
                   a.f_nav_unit * a.F_NAV_ADJUSTED as nav, 
                   b.s_info_compcode 
                   from [WIND].[dbo].[CHINAMUTUALFUNDNAV] a
                   left join wind.dbo.windcustomcode b
                   on a.f_info_windcode = b.s_info_windcode
                   ''')
i_nav['datadate'] = pd.to_datetime(i_nav['datadate'])
i_nav['report_period'] = pd.to_datetime(i_nav['report_period'])
i_nav['q'] = i_nav['report_period'].dt.quarter + i_nav['report_period'].dt.year*10
#i_nav = i_nav[i_nav['ticker_fund'].str.endswith('OF')]

i_nav = i_nav.sort_values(['s_info_compcode','ticker_fund','report_period','datadate'])
#i_nav = i_nav.drop_duplicates(subset = ['s_info_compcode','report_period','datadate','nav'], keep = 'first')
i_nav = i_nav.drop_duplicates(subset = ['s_info_compcode','report_period','datadate'], keep = 'first')

i_nav = i_nav.reset_index(drop = True)






### quarterly return 


i_nav_ret = i_nav.groupby(['s_info_compcode','ticker_fund','q']).agg({'nav':['first','last'],'datadate':'max'})
i_nav_ret.columns = ['nav_first','nav_last','datadate_nav_ret']
i_na
v_ret = i_nav_ret.reset_index()




### TNA

i_tna = yu.get_sql('''select a.s_info_windcode as ticker_fund,
                   a.f_prt_enddate as report_period,
                   a.F_PRT_STOCKVALUE as tna_stock,
                   a.F_PRT_NETASSET as tna_total,
                   a.f_ann_date as datadate,
                   b.s_info_compcode
                   from [WIND].[dbo].[CHINAMUTUALFUNDASSETPORTFOLIO]  a
                   left join wind.dbo.windcustomcode b
                   on a.s_info_windcode = b.s_info_windcode
                   ''') # F_PRT_NETASSET
i_tna['datadate'] = pd.to_datetime(i_tna['datadate'])
i_tna['report_period'] = pd.to_datetime(i_tna['report_period'])
#i_tna = i_tna[i_tna['ticker_fund'].str.endswith('OF')]

i_tna = i_tna.sort_values(['s_info_compcode','ticker_fund','report_period','datadate','tna_stock'])
#i_tna = i_tna.drop_duplicates(subset = ['s_info_compcode','report_period','datadate','tna_stock'], keep = 'first')
i_tna = i_tna.drop_duplicates(subset = ['s_info_compcode','report_period','datadate'], keep = 'first')
i_tna = i_tna.reset_index(drop = True)



### get flow data
i_flow = yu.get_sql('''select S_INFO_WINDCODE as ticker, trade_dt as datadate, 
                    BUY_VALUE_SMALL_ORDER - SELL_VALUE_SMALL_ORDER as retail_net_amt
                    from wind.dbo.ASHAREMONEYFLOW order by ticker, datadate''')
i_flow['datadate'] = pd.to_datetime(i_flow['datadate'], format='%Y%m%d')

i_flow['retail_net_amt_t20d'] = i_flow.groupby('ticker').rolling(20)['retail_net_amt'].sum().values
i_flow['retail_net_amt_t60d'] = i_flow.groupby('ticker').rolling(60)['retail_net_amt'].sum().values







### each fund, each quarter, calculate return, NA, NA_1
# net flow 
# flow = [NA - NA_1 * (1 + fund return)] / NA_1
# A large investor can orderly liquidate a large position, but a large number of small 
# investors cannot orderly liquidate a similar size aggregate position. 

i_tna_s2 = i_tna[i_tna['report_period'].dt.strftime('%m%d').isin(['0331','0630','0930','1231'])]
i_tna_s2 = i_tna_s2.sort_values(['s_info_compcode','report_period'])
i_tna_s2['tna_stock_1q'] = i_tna_s2.groupby('s_info_compcode')['tna_stock'].shift().values
i_tna_s2['tna_total_1q'] = i_tna_s2.groupby('s_info_compcode')['tna_total'].shift().values
i_tna_s2['q'] = i_tna_s2['report_period'].dt.year*10 + i_tna_s2['report_period'].dt.quarter
i_tna_s2 = i_tna_s2.rename(columns = {'datadate':'datadate_tna'})

i_tna_s2 = i_tna_s2[i_tna_s2['tna_stock'].notnull() &\
       
             i_tna_s2['tna_stock_1q'].notnull() &\
                    (i_tna_s2['tna_stock']>1e6) &\
                    (i_tna_s2['tna_stock_1q']>1e6) ]

i_tna_s3 = i_tna_s2.merge(i_nav_ret, on = ['s_info_compcode','ticker_fund','q'], how = 'inner')
i_tna_s3 = i_tna_s3[['s_info_compcode','ticker_fund','datadate_tna','datadate_nav_ret',
                     'q','report_period',
                     'tna_stock','tna_stock_1q','tna_total','tna_total_1q','nav_first','nav_last']]

i_tna_s3['flow_rmb'] = i_tna_s3['tna_stock'] - i_tna_s3['tna_stock_1q'].\
                       multiply(i_tna_s3['nav_last']).divide(i_tna_s3['nav_first'])
i_tna_s3['flow'] = i_tna_s3['flow_rmb'].divide(i_tna_s3['tna_stock_1q'])

i_tna_s3['datadate'] = i_tna_s3[['datadate_tna','datadate_nav_ret']].max(axis = 1)


# test regression
#i_tna_test = i_tna_s3.sort_values(['s_info_compcode','report_period'])
#
#i_tna_test = i_tna_test[i_tna_test['q']>=20141]
#i_tna_test = i_tna_test[i_tna_test['flow'].between(-0.5, 2)]
#
#i_tna_test['flow_rk']= i_tna_test.groupby('q')['flow'].apply(yu.uniformed_rank).values
#i_tna_test.loc[i_tna_test['flow_rk']>0.9, 'flow_rk'] = np.nan
#i_tna_test.loc[i_tna_test['flow_rk']<-0.9, 'flow_rk'] = np.nan
#i_tna_test['flow_1q'] = i_tna_test.groupby('s_info_compcode')['flow'].shift().values
#i_tna_test['flow_1q_rk']= i_tna_test.groupby('q')['flow_1q'].apply(yu.uniformed_rank).values
#i_tna_test['r'] = i_tna_test['nav_last'].divide(i_tna_test['nav_first'])-1
#i_tna_test['r_1q'] = i_tna_test.groupby('s_info_compcode')['r'].shift().values
#i_tna_test['r_1q_rk']= i_tna_test.groupby('q')['r_1q'].apply(yu.uniformed_rank).values
#
#i_tna_test_ols = i_tna_test.groupby('q')[['r_1q_rk','flow_1q','flow']].apply(lambda x: yu.ols_beta(x[['r_1q_rk','flow_1q']].values, x['flow'].values))
#i_tna_test_ols = i_tna_test_ols.reset_index()
#i_tna_test_ols['intercept'] = i_tna_test_ols[0].apply(lambda x:x[0])
#i_tna_test_ols['coef_r_1q'] = i_tna_test_ols[0].apply(lambda x:x[1])
#i_tna_test_ols['coef_flow_1q'] = i_tna_test_ols[0].apply(lambda x:x[2])
#i_tna_test_ols = i_tna_test_ols.dropna()
#
#i_tna_test_ols['coef_r_1q'].mean()
#i_tna_test_ols['coef_r_1q'].mean() / i_tna_test_ols['coef_r_1q'].std() * np.sqrt(i_tna_test_ols['coef_r_1q'].count())
#i_tna_test_ols['coef_flow_1q'].mean()
#i_tna_test_ols['coef_flow_1q'].mean() / i_tna_test_ols['coef_flow_1q'].std() * np.sqrt(i_tna_test_ols['coef_flow_1q'].count())




### calculate pressure (special version based fil and fit MF shares # ho
lding)

i_mf_gf = yu.get_sql('''select * from [CNDBPROD].[dbo].[F005_MF_CN_FORMAT]''')
i_mf_gf = i_mf_gf.rename(columns = {'DataDate':'datadate', 'Ticker':'ticker'})
c_sh = i_mf_gf['ticker'].str[0].isin(['6'])
c_sz = i_mf_gf['ticker'].str[0].isin(['3','0'])
i_mf_gf.loc[c_sh, 'ticker'] = i_mf_gf.loc[c_sh, 'ticker'] + '.SH'
i_mf_gf.loc[c_sz, 'ticker'] = i_mf_gf.loc[c_sz, 'ticker'] + '.SZ'
i_mf_gf['q'] = i_mf_gf['datadate'].dt.year * 10 + i_mf_gf['datadate'].dt.quarter

i_mf_gf = i_mf_gf.sort_values(['ticker', 'datadate'])
i_mf_gf_q = i_mf_gf.groupby(['ticker','q'])[['holding_shr_all_fil','holding_shr_all_fit']].apply(lambda x: -x.iloc[0]+x.iloc[-1])
i_mf_gf_q = i_mf_gf_q.reset_index()

i_adv = yu.get_sql('''select [T-1d] as datadate, ticker, avgVadj from cndbprod.dbo.Static_Data_HC_GEM3L ''')
c_sh = i_adv['ticker'].str[0].isin(['6'])
c_sz = i_adv['ticker'].str[0].isin(['3','0'])
i_adv.loc[c_sh, 'ticker'] = i_adv.loc[c_sh, 'ticker'] + '.SH'
i_adv.loc[c_sz, 'ticker'] = i_adv.loc[c_sz, 'ticker'] + '.SZ'
i_adv['q'] = i_adv['datadate'].dt.year * 10 + i_adv['datadate'].dt.quarter

i_adv = i_adv.sort_values(['ticker','datadate'])
i_adv = i_adv.groupby(['ticker','q']).last().reset_index()

i_mf_gf_q = i_mf_gf_q.merge(i_adv, on = ['ticker','q'], how = 'left')
i_mf_gf_q = i_mf_gf_q.sort_values(['ticker','q'])
i_mf_gf_q['q'] = i_mf_gf_q.groupby('ticker')['q'].shift()
i_mf_gf_q['datadate'] = i_mf_gf_q.groupby('ticker')['datadate'].shift()
i_mf_gf_q = i_mf_gf_q.dropna()

i_mf_gf_q['p_fil'] = i_mf_gf_q['holding_shr_all_fil'].divide(i_mf_gf_q['avgVadj'])
i_mf_gf_q['p_fit'] = i_mf_gf_q['holding_shr_all_fit'].divide(i_mf_gf_q['avgVadj'])
i_mf_gf_q = i_mf_gf_q.sort_values('datadate')

icom_test = pd.merge_asof(i_sd, i_mf_gf_q, by = 'ticker', on = 'datadate')
icom_test['p_fil_bk'] = icom_test.groupby('datadate')['p_fil'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom_test['p_fit_bk'] = icom_test.groupby('datadate')['p_fit'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom_test['p_fil'].hist(bins=30)
yu.create_cn_3x3(icom_test, ['p_fil_bk'], 'p_fil')
yu.create_cn_3x3(icom_test, ['p_fit_bk'], 'p_fit')




### calculate pressure

i_mf = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_wind_holding_mf_q_est.parquet')
i_mf['report_period'] = pd.to_datetime(i_mf['report_period'])
i_mf['q'] = i_mf['report_period'].dt.year*10 + i_mf['report_period'].dt.quarter

o_pressure_gf = []

for dt_str in [str(y)+d for y in list(range(2016, 2021)) for d in ['0331','0630','
0930','1231'] ]:
    print(dt_str, end = ' ')    
    dt = pd.to_datetime(dt_str, format = '%Y%m%d')
    if dt_str.endswith('0331'):
        q_int = (int(dt_str[:4]))*10+1
    elif dt_str.endswith('0630'):
        q_int = (int(dt_str[:4]))*10+2
    elif dt_str.endswith('0930'):
        q_int = (int(dt_str[:4]))*10+3
    elif dt_str.endswith('1231'):
        q_int = (int(dt_str[:4]))*10+4
    else:
        raise Exception()
    
    t_sd = i_sd[i_sd['datadate']==i_sd_dd[i_sd_dd<=dt].max()]
    t_sd = t_sd[['ticker','avgPVadj']]
    
    
    t_mf = i_mf[i_mf['q']==q_int]
    t_mf = t_mf[t_mf['held_dollar']>0]
    t_mf['flag_held'] = 1
    t_mf = t_mf[['s_info_compcode','ticker_fund','q','ticker','flag_held','pctOfMFSTK']]
    
    t_tna_s3 = i_tna_s3[(i_tna_s3['q']==q_int)]
    t_tna_s3 = t_tna_s3[['s_info_compcode','ticker_fund','q','flow','flow_rmb']]
    #t_tna_s3 = t_tna_s3[t_tna_s3['flow'].between(-2, 2)]
    
    t_pressure = t_mf.merge(t_tna_s3, on = ['s_info_compcode','ticker_fund','q'], how = 'inner')
    t_pressure = t_pressure.merge(t_sd, on = ['ticker'], how = 'inner')
    
    t_pressure.loc[t_pressure['flow']>0.75, 'flag_flow'] = 1
    t_pressure.loc[t_pressure['flow']<-0.75, 'flag_flow'] = -1
    
    c1 = t_pressure['flow_rmb'].multiply(t_pressure['pctOfMFSTK']) > 0.1 * t_pressure['avgPVadj']
    c2 = t_pressure['flow_rmb'].multiply(t_pressure['pctOfMFSTK']) < - 0.1 * t_pressure['avgPVadj']
    t_pressure.loc[c1, 'flag_flow_v2'] = 1
    t_pressure.loc[c2, 'flag_flow_v2'] = -1
    
    o_nom = t_pressure.groupby('ticker')['flag_flow'].sum().reset_index()
    o_denom = t_pressure.groupby('ticker')['s_info_compcode'].nunique().reset_index()
    o_denom = o_denom.rename(columns = {'s_info_compcode': 'mf_cnt'})
    
    o_nom_v2 = t_pressure.groupby('ticker')['flag_flow_v2'].sum().reset_index()
    
    o_metric = o_denom.merge(o_nom, on = ['ticker'], how = 'inner')
    o_metric = o_metric.merge(o_nom_v2, on = 'ticker', how = 'outer')
    
    o_metric['pressure'] = o_metric['flag_flow'].divide(o_metric['mf_cnt'])
    o_metric['pressure'] = o_metric['pressure'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
    o_metric['pressure_v2'] = o_metric['flag_flow_v2'].divide(o_metric['mf_cnt'])
    o_metric['pressure_v2'] = o_metric['pressure_v2'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
    
    o_metric['datadate'] = dt + pd.to_timedelta('30 days')
    
    o_pressure_gf.append(o_metric)
    
o_pressure_gf = pd.concat(o_pressure_gf, axis = 0
)




### calendar

#i_cal = yu.get_sql('''select datadate as datadate_cal, tradedate_next as datadate 
#                   FROM [CNDBPROD].[dbo].[Calendar_Dates_HC]''')
#o_pressure_gf = o_pressure_gf.merge(i_cal, on = ['datadate_cal'], how = 'left')
#o_pressure_gf = o_pressure_gf.sort_values('datadate')


### combine (gf)


icomgf = pd.merge_asof(i_sd, o_pressure_gf, on = 'datadate', by = 'ticker', 
                       tolerance = pd.to_timedelta('90 days'))
icomgf = icomgf.sort_values(['ticker','datadate'])

icomgf = icomgf.merge(i_flow, on = ['ticker','datadate'], how = 'left')


# 1

icomgf.loc[icomgf['mf_cnt']>=10, 'pressure_xlt10'] = icomgf.loc[icomgf['mf_cnt']>=10, 'pressure']
icomgf.loc[icomgf['mf_cnt']>=10, 'pressure_v2_xlt10'] = icomgf.loc[icomgf['mf_cnt']>=10, 'pressure_v2']
icomgf['pressure_xlt10_bk'] = icomgf.groupby('datadate')['pressure_xlt10'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomgf['pressure_xlt10_rk'] = icomgf.groupby('datadate')['pressure_xlt10'].apply(yu.uniformed_rank).values
icomgf['pressure_v2_xlt10_bk'] = icomgf.groupby('datadate')['pressure_v2_xlt10'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icomgf['pressure_bk'] = icomgf.groupby('datadate')['pressure'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomgf['pressure_v2_bk'] = icomgf.groupby('datadate')['pressure_v2'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icomgf['flag_sell'] = np.nan
icomgf.loc[icomgf['pressure_xlt10']>0.25, 'flag_sell'] = -1

icomgf['flag_buy'] = np.nan
icomgf.loc[icomgf['pressure_xlt10']<-0.25, 'flag_buy'] = 1



yu.create_cn_3x3(icomgf, ['pressure_xlt10_bk'], 'pressure_xlt10') # mono if flow: <>+-0.75
yu.create_cn_3x3(icomgf, ['pressure_v2_xlt10_bk'], 'pressure_v2_xlt10')

yu.create_cn_3x3(icomgf, ['pressure_bk'], 'pressure') # random


o_1 = yu.bt_cn_15(icomgf[(icomgf['datadate']<='2020-12-31')].\
            dropna(subset=['flag_buy','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flag_buy','BarrRet_CLIP_USD+1d', static_data = i_sd) 

o_1 = yu.bt_cn_15(icomgf[(icomgf['datadate']<='2020-12-31')].\
            dropna(subset=['flag_sell','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flag_sell','BarrRet_CLIP_USD+1d', static_data = i_sd) #

o_1 = yu.bt_cn_15(icomgf[(icomgf['datadate']<='2020-12-31')].\
            dropna(subset=['pressure_xlt10_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pressure_xlt10_rk','BarrRet_CLIP_USD+
1d', static_data = i_sd)


### pressure + small flow
