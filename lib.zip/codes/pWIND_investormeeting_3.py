﻿#$%^&* pWIND_investormeeting_3.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue May 18 21:50:45 2021

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime


# this script includes data scraped from yuediaoyan + jihuibao 


### get jihuibao data
i_jhb = pd.read_parquet(r"\\vfudat04\udat04\thzhang\Downloads\jihuibao_history_20210521.parquet")
i_jhb = i_jhb[i_jhb['ticker'].notnull()]
i_jhb = i_jhb[(i_jhb['ticker'].str.len()==6)&(~i_jhb['ticker'].str.contains('.',regex=False))]
c_sz = i_jhb['ticker'].str[0].isin(['0','3'])
c_sh = i_jhb['ticker'].str[0].isin(['6'])
i_jhb.loc[c_sz, 'ticker'] = i_jhb.loc[c_sz, 'ticker'] + '.SZ'
i_jhb.loc[c_sh, 'ticker'] = i_jhb.loc[c_sh, 'ticker'] + '.SH'
i_jhb = i_jhb[i_jhb['activityType']!=12] # exclude 
i_jhb = i_jhb[~i_jhb['title'].str.contains('')] # exclude 
i_jhb['jhb_datadate'] = pd.to_datetime(i_jhb['end_datetime'].dt.date)
i_jhb['jhb_datadate_2'] = i_jhb['jhb_datadate'] - pd.to_timedelta('2 days')
i_jhb['jhb_flag_2'] = 1
i_jhb['jhb_datadate_3'] = i_jhb['jhb_datadate'] - pd.to_timedelta('3 days')
i_jhb['jhb_flag_3'] = 1
i_jhb['jhb_datadate_5'] = i_jhb['jhb_datadate'] - pd.to_timedelta('5 days')
i_jhb['jhb_flag_5'] = 1
i_jhb['jhb_datadate_10'] = i_jhb['jhb_datadate'] - pd.to_timedelta('10 days')
i_jhb['jhb_flag_10'] = 1
i_jhb = i_jhb.sort_values('jhb_datadate_3')
i_jhb['isin_tier1city_jhb'] = i_jhb['list_city'].str.contains('')

i_jhb = i_jhb[i_jhb['activityForm']==3]
i_jhb['jhb_flag'] = 1


### get yuediaoyan data

i_yuediaoyan = pd.read_parquet(r"S:\Data\China Data Hunt\yuediaoyan_history_20210516.parquet")

i_yuediaoyan.columns = ['id', 'scraper_ts', 'public_comp', 'no_outof', 'planned_time', 
                        'deadline', 'location', 'add', 'host', 'contact', 'fee', 'dinner', 'url', 'ind' ]
i_yuediaoyan = i_yuediaoyan[(i_yuediaoyan['public_comp']!='()') & (i_yuediaoyan['public_comp'].notnull())]
i_yuediaoyan['ticker'] = i_yuediaoyan['public_comp'].str.extract('(\d{6})')
i_yuediaoyan = i_yuediaoyan[i_yuediaoyan['ticker'].notnull()]
c_sz = i_yuediaoyan['ticker'].str[0].isin(['0','3'])
c_sh = i_yuediaoyan['ticker'].str[0].isin(['6'])
i_yuediaoyan.loc[c_sz, 'ticker'] = i_yuediaoyan.loc[c_sz, 'ticker'] + '.SZ'
i_yuediaoyan.loc[c_sh, 'ticker'] = i_yuediaoyan.loc[c_sh, 'ticker'] + '.SH'
i_yuediaoyan = i_yuediaoyan[c_sz | c_sh]
i_yuediaoyan['comp_name'] = i_yuediaoyan['public_comp'].str.split('(').str[0]
i_yuediaoyan['planned_date'] = pd.to_dat
etime(i_yuediaoyan['planned_time'].str[:10])
i_yuediaoyan['deadline_date'] = pd.to_datetime(i_yuediaoyan['deadline'].str[:10])
i_yuediaoyan['participant_no'] = pd.to_numeric(i_yuediaoyan['no_outof'].str.split('/').str[0])
i_yuediaoyan['quota_no'] = pd.to_numeric(i_yuediaoyan['no_outof'].str.split('/').str[1])
i_yuediaoyan['ydy_datadate_2'] = i_yuediaoyan['deadline_date'] - pd.to_timedelta('2 days')
i_yuediaoyan['ydy_flag_2'] = 1
i_yuediaoyan['ydy_datadate_3'] = i_yuediaoyan['deadline_date'] - pd.to_timedelta('3 days')
i_yuediaoyan['ydy_flag_3'] = 1
i_yuediaoyan['ydy_datadate_5'] = i_yuediaoyan['deadline_date'] - pd.to_timedelta('5 days')
i_yuediaoyan['ydy_flag_5'] = 1
i_yuediaoyan['ydy_datadate_10'] = i_yuediaoyan['deadline_date'] - pd.to_timedelta('10 days')
i_yuediaoyan['ydy_flag_10'] = 1
c_is_gaoguan = i_yuediaoyan['host'].str.contains('')
c_excl_list = i_yuediaoyan['host'].str.contains('')
i_yuediaoyan.loc[c_excl_list, 'is_gaoguan'] = 0
i_yuediaoyan.loc[c_is_gaoguan, 'is_gaoguan'] = 1
i_yuediaoyan['isin_tier1city_ydy'] = i_yuediaoyan['location'].str.contains('')
i_yuediaoyan = i_yuediaoyan[i_yuediaoyan['no_outof'].str[:2]!='0/']
i_yuediaoyan = i_yuediaoyan[['ticker', 'comp_name', 'planned_date', 'deadline_date', 
                             'quota_no', 'participant_no', 'ydy_datadate_2', 'ydy_datadate_3', 'ydy_datadate_5',
                             'ydy_datadate_10', 'ydy_flag_2','ydy_flag_3', 'ydy_flag_5', 'ydy_flag_10',
                             'is_gaoguan','isin_tier1city_ydy']]
i_yuediaoyan = i_yuediaoyan.sort_values('deadline_date')

### get comein data
i_comein = pd.read_parquet(r"\\vfudat04\udat04\thzhang\Downloads\comein.parquet")

#c_has_bar = i_comein['title'].str.contains(' | ', regex = False)
#i_comein.loc[c_has_bar, 'ticker'] = i_comein.loc[c_has_bar, 'title'].str.split(' | ')[1].str[4]

c_has_ticker = i_comein['title'].str.contains('（\d{6}）')
i_comein.loc[c_has_ticker,'ticker'] = i_comein.loc[c_has_ticker,'title'].str.extract('（(\d{6}?)）').values

#? omitteda few lines of chinese codes here
i_comein['broker'] = i_comein['broker'].fillna('')
i_comein['creator_company'] = i_comein['creator_company'].fillna('')
i_comein.loc[~i_comein['creator_company'].str.contains(''), 'broker'] = ''

i_comein['title_1'] = i_comein['title'].str.split('|').str[0].str.strip().str[:4]
i_comein['title_2'] = i_comein['title'].str.split('|').str[1].str.strip().str[:4]
i_comein['title_2'] = i_comein['title_2'].fillna('@@@@')

i_comein['tk_name_implied'] = 
np.nan
c_t2_is_broker = i_comein[['broker','title_2']].apply(lambda x: (x['broker'] in x['title_2']) & (x['broker'] != ''), axis=1)
i_comein.loc[c_t2_is_broker, 'tk_name_implied'] = i_comein.loc[c_t2_is_broker, 'title_1']
i_comein.loc[~c_t2_is_broker, 'tk_name_implied'] = i_comein.loc[~c_t2_is_broker, 'title_2']

i_comein['tk_name_implied'] = i_comein['tk_name_implied'].str.replace('\d','', regex = True)

#i_comein.to_csv(r'S:\Data\China Data Hunt\comein_ticker_inferred.csv', quoting=csv.QUOTE_ALL)

i_wind_name = yu.get_sql('''select s_info_windcode as ticker, s_info_name from wind.dbo.ASharePreviousName
                         union
                         select s_info_windcode as ticker, s_info_name from wind.dbo.AShareDescription''')
i_wind_name = i_wind_name.drop_duplicates()
d_wind_name = {}
for i, r in i_wind_name.iterrows():
    d_wind_name[r['s_info_name']] = r['ticker']

def helper1(name):
    try:
        return d_wind_name[name]
    except:
        return np.nan
i_comein['tk_implied'] = i_comein['tk_name_implied'].apply(helper1).values

i_comein.loc[i_comein['ticker'].isnull(), 'ticker'] = i_comein.loc[i_comein['ticker'].isnull(), 'tk_implied']
i_comein['ticker'].notnull().sum()

i_comein['date_logo'] = i_comein['logo'].str.extract('(\d{4}-\d{2}-\d{2})')
i_comein['date_logowall'] = i_comein['logowall'].str.extract('(\d{4}-\d{2}-\d{2})')
i_comein['date_logoweb'] = i_comein['logoweb'].str.extract('(\d{4}-\d{2}-\d{2})')
i_comein['date_logo'] = pd.to_datetime(i_comein['date_logo'])
i_comein['date_logowall'] = pd.to_datetime(i_comein['date_logowall'])
i_comein['date_logoweb'] = pd.to_datetime(i_comein['date_logoweb'])
i_comein['datadate'] = i_comein[['date_logo', 'date_logowall', 'date_logoweb']].max(axis=1)
i_comein['start_date'] = pd.to_datetime(i_comein['start_time'].dt.date)

i_comein_useful = i_comein[i_comein['ticker'].notnull()&\
                           ((i_comein['start_date'] - i_comein['datadate']).dt.days>=2)&\
                           (~i_comein['title'].str.contains(''))]

#i_comein_useful = i_comein[i_comein['ticker'].notnull()&\
#                           ((i_comein['start_date'] - i_comein['datadate']).dt.days>=2)]

i_comein2 = pd.DataFrame()
for i,r in i_comein_useful.iterrows():
    t_data = pd.DataFrame({'datadate':pd.date_range(start = r['datadate'], end = r['start_date']),
                           'comein_flag':1,
                           'ticker': r['ticker'],
                           'event_date': r['start_date']
})
    i_comein2 = i_comein2.append(t_data, sort = False)
i_comein2['days2event'] = (i_comein2['event_date'] - i_comein2['datadate']).dt.days


### WIND meetings

# get raw data
i_meeting = yu.get_sql('''select S_INFO_WINDCODE as ticker, [EVENT_ID], [S_ACTIVITIESTYPE], 
                    [S_SURVEYDATE], [S_SURVEYTIME], [ANN_DT] as datadate, [S_SURVEYTYPECODE], 
                    [S_SURVEYINSTIS_TOT] from [WIND].[dbo].[ASHAREISACTIVITY] 
                    where len(S_SURVEYDATE)=8 ''')
i_meeting = i_meeting[i_meeting['S_SURVEYDATE'].notnull()]
i_meeting['datadate'] = pd.to_datetime(i_meeting['datadate'], format='%Y%m%d')
    
# get avg PV  / MC
i_pv_dv_mc = yu.get_sql_prod("select ric as ticker, datadate, avgPVadj / mc_l1d / 10000 as pv_dv_mc FROM [SUMMITDBPROD].[dbo].[Static_Data_CN]")    

# meeting participants
i_participants = yu.get_sql('''SELECT [EVENT_ID], [S_INSTITUTIONNAME], [S_INSTITUTIONCODE] as S_INFO_COMPCODE,
                         [S_INSTITUTIONTYPE], [S_ANALYSTNAME],[S_INSTITUTIONTYPECODE],[MANAGER_POST],[S_ANALYST_ID] 
                         FROM [WIND].[dbo].[ASHAREISPARTICIPANT]''')
i_participants = i_participants[i_participants['S_INSTITUTIONTYPE'].notnull()]
i_participants['S_INSTITUTIONTYPE'] = i_participants['S_INSTITUTIONTYPE'].astype(int)
i_participants.loc[i_participants['S_ANALYSTNAME'].isnull(), 'S_ANALYSTNAME'] = 'unknown'
i_part_cnt = i_participants.groupby(['EVENT_ID','S_INSTITUTIONTYPE'])['S_INFO_COMPCODE'].nunique().reset_index()
i_part_cnt = i_part_cnt.rename(columns={'S_INFO_COMPCODE':'cnt'})
i_part_cnt = pd.pivot_table(i_part_cnt, index='EVENT_ID', columns='S_INSTITUTIONTYPE', values = 'cnt')
i_part_cnt = i_part_cnt.reset_index()
    

# participants' most recent holding and holding in the future
i_participants = i_participants.merge(i_meeting[['EVENT_ID','datadate','ticker']], on=['EVENT_ID'], how = 'left')
i_participants = i_participants.rename(columns={'S_INFO_COMPCODE': 's_holder_compcode'})
i_participants = i_participants[i_participants['datadate'].notnull()]
i_participants = i_participants.sort_values(['datadate','s_holder_compcode'])

# aggregate mutual fund participant's holding to event
i_mf = i_participants[i_participants['S_INSTITUTIONTYPE']==257001003]
i_mf = i_mf.merge(i_pv_dv_mc, on = ['ticker','datadate'], how = 'left')
i_mf = i_mf.drop_duplicates(subset=['EVENT_ID','S_INSTITUTIONNAME'], keep = 'last')

i_mf_stats_grp = i_mf.groupby(['EVENT_ID','ticker'])
i_mf_stats = pd.concat([i_mf_stats_grp['S_
INSTITUTIONNAME'].nunique()],axis=1)
i_mf_stats = i_mf_stats.reset_index().rename(columns = {'S_INSTITUTIONNAME':'num_mf'})

# count no of mf + am per meeting
i_am = i_participants[(i_participants['S_INSTITUTIONTYPE']==257001005)&(i_participants['S_INSTITUTIONNAME'].str.contains('资管|资产管理'))]
i_am_stats = i_am.groupby(['EVENT_ID','ticker'])['S_INSTITUTIONNAME'].nunique().reset_index()
i_am_stats = i_am_stats.rename(columns = {'S_INSTITUTIONNAME':'num_am'})
    
# output
o_investor_meeting = i_meeting.merge(i_part_cnt, on = ['EVENT_ID'], how = 'left')
o_investor_meeting = o_investor_meeting.merge(i_mf_stats, on = ['EVENT_ID','ticker'], how = 'left')
o_investor_meeting = o_investor_meeting.merge(i_am_stats, on = ['EVENT_ID','ticker'], how = 'left')
o_investor_meeting = o_investor_meeting[['ticker','datadate','EVENT_ID','S_ACTIVITIESTYPE',
                                         'S_SURVEYDATE', 'S_SURVEYTIME', 
                                         'S_SURVEYTYPECODE', 'S_SURVEYINSTIS_TOT',
                                         257001001, 257001002, 257001003, 257001004,
                                         257001005, 257001006, 257001007, 257002001,
                                         'num_mf', 'num_am']]
o_investor_meeting['datadate'] = pd.to_datetime(o_investor_meeting['datadate'], format='%Y%m%d')

# get buy-side meeting counts
o_investor_meeting = o_investor_meeting[o_investor_meeting['S_ACTIVITIESTYPE'].astype(int).isin([254001000,254007000,254009000,254010000])]
o_investor_meeting['buyside_ins_visit'] = o_investor_meeting[[257001001,257001002,257001003,257001004,257001005,257001006]].sum(axis=1,skipna=True)
o_investor_meeting.loc[o_investor_meeting['S_SURVEYINSTIS_TOT'].isnull(), 'S_SURVEYINSTIS_TOT'] = 1
o_investor_meeting['S_SURVEYDATE'] = pd.to_datetime(o_investor_meeting['S_SURVEYDATE'],format='%Y%m%d')

# combine multiple meetings on the same day
i_meeting_dedup = o_investor_meeting.drop(columns = ['EVENT_ID','S_ACTIVITIESTYPE','S_SURVEYTIME',
                                                     'S_SURVEYTYPECODE','S_SURVEYDATE'])
cols_numeric = ['S_SURVEYINSTIS_TOT', 257001001, 257001002, 257001003, 257001004, 257001005,
                257001006, 257001007, 257002001, 'buyside_ins_visit',
                'num_mf', 'num_am']
i_meeting_dedup[cols_numeric] = i_meeting_dedup[cols_numeric].fillna(0)
i_meeting_dedup['event_cnt'] = 1
i_meeting_dedup = i_meeting_dedup.groupby(['ticker','datadate'])[cols_numeric+['event_cnt']].sum()
i_meeti
ng_dedup = i_meeting_dedup.reset_index()


### sd

i_sd_fx = pw.get_ashare_hk_sd_v2()
i_sd_map_fx = i_sd_fx[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni']]
i_sd_map_fx = i_sd_map_fx.sort_values('datadate')



### combine fx - Shenzhen

icomfx = pd.merge_asof(i_sd_map_fx, i_jhb[['ticker','jhb_datadate_5','jhb_flag_5']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['jhb_datadate_5'], 
                     tolerance = pd.to_timedelta('5 days') )

icomfx = icomfx[icomfx['ticker'].str.contains('SZ')]

icomfx = pd.merge_asof(icomfx, i_yuediaoyan[['ticker','ydy_datadate_5','ydy_flag_5']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['ydy_datadate_5'], 
                     tolerance = pd.to_timedelta('5 days') )

icomfx = icomfx.merge(i_meeting_dedup, on = ['ticker','datadate'], how = 'left')

icomfx = icomfx.sort_values(['ticker', 'datadate'])


# combine actuals
icomfx = icomfx.merge(i_sd_fx[['ticker','datadate','SIZE']], on = ['datadate','ticker'], how = 'left')
icomfx['SIZE_bk'] = icomfx.groupby('datadate')['SIZE'].apply(lambda x: pd.qcut(x,q=10,labels=range(10))).values

i_sd_fx['turnover'] = i_sd_fx['avgPVadj'].divide(i_sd_fx['MC_l1d'])
icomfx = icomfx.merge(i_sd_fx[['ticker','datadate','turnover']], on = ['datadate','ticker'], how = 'left')

i_sd_fx = i_sd_fx.sort_values(['ticker', 'datadate'])
i_sd_fx['BarrRet_CLIP_t60d'] = i_sd_fx.groupby('ticker').rolling(60)['BarrRet_CLIP-1d'].apply(lambda x: (x+1).prod()-1).values
icomfx = icomfx.merge(i_sd_fx[['ticker','datadate','BarrRet_CLIP_t60d']], on = ['datadate','ticker'], how = 'left')
icomfx['BarrRet_CLIP_t60d_rk'] = icomfx.groupby('datadate')['BarrRet_CLIP_t60d'].apply(lambda x: yu.uniformed_rank(x)).values

i_roa = pw.get_wind_actuals('S_FA_ROA2')
icomfx = icomfx.merge(i_roa, on = ['ticker', 'datadate'], how = 'left')

i_ed = pw.get_wind_ed_calendar()
i_ed = i_ed[['ticker','datadate','cdae','bdae','bd2e','bd2e_fwdlk']]
icomfx = icomfx.merge(i_ed, on = ['ticker', 'datadate'], how = 'left')

# calculate trailing meetings

icomfx['mf_t90d'] = icomfx.groupby('ticker').rolling(datetime.timedelta(days=91),on = 'datadate')['num_mf'].sum().values
icomfx['am_t90d'] = icomfx.groupby('ticker').rolling(datetime.timedelta(days=91),on = 'datadate')['num_am'].sum().values

icomfx['ydy_datadate_5'] = icomfx['ydy_datadate_5'].dt.strftime('%Y%m%d').replace('NaT',np.nan).astype(
np.float64)
icomfx['jhb_datadate_5'] = icomfx['jhb_datadate_5'].dt.strftime('%Y%m%d').replace('NaT',np.nan).astype(np.float64)
icomfx.loc[icomfx['S_SURVEYINSTIS_TOT']>=1,'ydy_datadate_5'] = np.nan
icomfx.loc[icomfx['S_SURVEYINSTIS_TOT']>=1,'jhb_datadate_5'] = np.nan
icomfx['jhb_t90d'] = icomfx.groupby('ticker').rolling(datetime.timedelta(days=91),on = 'datadate')['jhb_datadate_5'].apply(lambda x: len(np.unique(x))).values
icomfx['ydy_t90d'] = icomfx.groupby('ticker').rolling(datetime.timedelta(days=91),on = 'datadate')['ydy_datadate_5'].apply(lambda x: len(np.unique(x))).values

icomfx['mfamextra_t90d'] = icomfx['am_t90d'].fillna(0) + icomfx['mf_t90d'].fillna(0) +\
                           icomfx['jhb_t90d'].fillna(0) + icomfx['ydy_t90d'].fillna(0)
                           
                           

### combine fx - Shanghai

icomfxsh = pd.merge_asof(i_sd_map_fx, i_jhb[['ticker','jhb_datadate_5','jhb_flag_5']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['jhb_datadate_5'], 
                     tolerance = pd.to_timedelta('5 days') )

icomfxsh = icomfxsh[icomfxsh['ticker'].str.contains('SZ')]

icomfxsh = pd.merge_asof(icomfxsh, i_yuediaoyan[['ticker','ydy_datadate_5','ydy_flag_5']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['ydy_datadate_5'], 
                     tolerance = pd.to_timedelta('5 days') )

icomfxsh = icomfxsh.merge(i_meeting_dedup, on = ['ticker','datadate'], how = 'left')

icomfxsh = icomfxsh.sort_values(['ticker', 'datadate'])


# combine actuals
icomfxsh = icomfxsh.merge(i_sd_fx[['ticker','datadate','SIZE']], on = ['datadate','ticker'], how = 'left')
icomfxsh['SIZE_bk'] = icomfxsh.groupby('datadate')['SIZE'].apply(lambda x: pd.qcut(x,q=10,labels=range(10))).values

i_sd_fx['turnover'] = i_sd_fx['avgPVadj'].divide(i_sd_fx['MC_l1d'])
icomfxsh = icomfxsh.merge(i_sd_fx[['ticker','datadate','turnover']], on = ['datadate','ticker'], how = 'left')

i_sd_fx = i_sd_fx.sort_values(['ticker', 'datadate'])
i_sd_fx['BarrRet_CLIP_t60d'] = i_sd_fx.groupby('ticker').rolling(60)['BarrRet_CLIP-1d'].apply(lambda x: (x+1).prod()-1).values
icomfxsh = icomfxsh.merge(i_sd_fx[['ticker','datadate','BarrRet_CLIP_t60d']], on = ['datadate','ticker'], how = 'left')
icomfxsh['BarrRet_CLIP_t60d_rk'] = icomfxsh.groupby('datadate')['BarrRet_CLIP_t60d'].apply(lambda x: yu.uniformed_rank(x)).values

i_roa = pw.get_wind_actuals('S_FA_ROA2')
icomfxsh = icomfxsh.merge(i_roa, on = ['ticker', 'datadate'], ho
w = 'left')

i_ed = pw.get_wind_ed_calendar()
i_ed = i_ed[['ticker','datadate','cdae','bdae','bd2e','bd2e_fwdlk']]
icomfxsh = icomfxsh.merge(i_ed, on = ['ticker', 'datadate'], how = 'left')

# calculate trailing meetings

icomfxsh['mf_t90d'] = icomfxsh.groupby('ticker').rolling(datetime.timedelta(days=91),on = 'datadate')['num_mf'].sum().values
icomfxsh['am_t90d'] = icomfxsh.groupby('ticker').rolling(datetime.timedelta(days=91),on = 'datadate')['num_am'].sum().values

icomfxsh['ydy_datadate_5'] = icomfxsh['ydy_datadate_5'].dt.strftime('%Y%m%d').replace('NaT',np.nan).astype(np.float64)
icomfxsh['jhb_datadate_5'] = icomfxsh['jhb_datadate_5'].dt.strftime('%Y%m%d').replace('NaT',np.nan).astype(np.float64)
icomfxsh.loc[icomfxsh['S_SURVEYINSTIS_TOT']>=1,'ydy_datadate_5'] = np.nan
icomfxsh.loc[icomfxsh['S_SURVEYINSTIS_TOT']>=1,'jhb_datadate_5'] = np.nan
icomfxsh['jhb_t90d'] = icomfxsh.groupby('ticker').rolling(datetime.timedelta(days=91),on = 'datadate')['jhb_datadate_5'].apply(lambda x: len(np.unique(x))).values
icomfxsh['ydy_t90d'] = icomfxsh.groupby('ticker').rolling(datetime.timedelta(days=91),on = 'datadate')['ydy_datadate_5'].apply(lambda x: len(np.unique(x))).values

icomfxsh['mfamextra_t90d'] = icomfxsh['am_t90d'].fillna(0) + icomfxsh['mf_t90d'].fillna(0) +\
                           icomfxsh['jhb_t90d'].fillna(0) + icomfxsh['ydy_t90d'].fillna(0)
                           


### combine fx - all

icomfxall = pd.merge_asof(i_sd_map_fx, i_jhb[['ticker','jhb_datadate_5','jhb_flag_5']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['jhb_datadate_5'], 
                     tolerance = pd.to_timedelta('5 days') )


icomfxall = pd.merge_asof(icomfxall, i_jhb[['ticker','jhb_datadate_2','jhb_flag_2']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['jhb_datadate_2'], 
                     tolerance = pd.to_timedelta('2 days') )

icomfxall = pd.merge_asof(icomfxall, i_jhb[['ticker','jhb_datadate_10','jhb_flag_10','isin_tier1city_jhb']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['jhb_datadate_10'], 
                     tolerance = pd.to_timedelta('10 days') )

icomfxall = icomfxall.merge(i_jhb[['ticker','jhb_datadate','jhb_flag']], 
                            left_on = ['ticker','datadate'], right_on = ['ticker','jhb_datadate'], how = 'left')

icomfxall = pd.merge_asof(icomfxall, i_yuediaoyan[['ticker','ydy_datadate_2','ydy_flag_2']], 
                     by = ['ticker'], 
left_on = ['datadate'], right_on = ['ydy_datadate_2'], 
                     tolerance = pd.to_timedelta('2 days') )

icomfxall = pd.merge_asof(icomfxall, i_yuediaoyan[['ticker','ydy_datadate_5','ydy_flag_5']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['ydy_datadate_5'], 
                     tolerance = pd.to_timedelta('5 days') )

icomfxall = pd.merge_asof(icomfxall, i_yuediaoyan[['ticker','ydy_datadate_10','ydy_flag_10','isin_tier1city_ydy']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['ydy_datadate_10'], 
                     tolerance = pd.to_timedelta('10 days') )

icomfxall = icomfxall.merge(i_yuediaoyan[['ticker','planned_date','participant_no']], 
                            left_on = ['ticker','datadate'], right_on = ['ticker','planned_date'], how = 'left')

icomfxall = icomfxall.merge(i_meeting_dedup, on = ['ticker','datadate'], how = 'left')

icomfxall = icomfxall.sort_values(['ticker', 'datadate'])

icomfxall = icomfxall.merge(i_comein2, on = ['ticker', 'datadate'], how = 'left')


i_sd_fx = i_sd_fx.sort_values(['ticker', 'datadate'])
i_sd_fx['BarrRet_CLIP_t60d'] = i_sd_fx.groupby('ticker').rolling(60)['BarrRet_CLIP_USD-1d'].apply(lambda x: (x+1).prod()-1).values
icomfxall = icomfxall.merge(i_sd_fx[['ticker','datadate','BarrRet_CLIP_t60d']], on = ['datadate','ticker'], how = 'left')
icomfxall['BarrRet_CLIP_t60d_rk'] = icomfxall.groupby('datadate')['BarrRet_CLIP_t60d'].apply(lambda x: yu.uniformed_rank(x)).values


# calculate trailing meetings

icomfxall['mf_t30d'] = icomfxall.groupby('ticker').rolling(datetime.timedelta(days=30),on = 'datadate')['num_mf'].sum().values
icomfxall['am_t30d'] = icomfxall.groupby('ticker').rolling(datetime.timedelta(days=30),on = 'datadate')['num_am'].sum().values

icomfxall['mf_t90d'] = icomfxall.groupby('ticker').rolling(datetime.timedelta(days=91),on = 'datadate')['num_mf'].sum().values
icomfxall['am_t90d'] = icomfxall.groupby('ticker').rolling(datetime.timedelta(days=91),on = 'datadate')['num_am'].sum().values

icomfxall['ydy_datadate_5'] = icomfxall['ydy_datadate_5'].dt.strftime('%Y%m%d').replace('NaT',np.nan).astype(np.float64)
icomfxall['jhb_datadate_5'] = icomfxall['jhb_datadate_5'].dt.strftime('%Y%m%d').replace('NaT',np.nan).astype(np.float64)
icomfxall.loc[icomfxall['S_SURVEYINSTIS_TOT']>=1,'ydy_datadate_5'] = np.nan
icomfxall.loc[icomfxall['S_SURVEYINSTIS_TOT']>=1,'jhb_datadate_5'] = np.nan
icomfxall['jhb_t90d'] = icomfxall.groupby('ticker
').rolling(datetime.timedelta(days=91),on = 'datadate')['jhb_flag'].sum().values
icomfxall['ydy_t90d'] = icomfxall.groupby('ticker').rolling(datetime.timedelta(days=91),on = 'datadate')['participant_no'].sum().values

icomfxall['mfam_t30d'] = icomfxall['mf_t30d'].fillna(0) + icomfxall['am_t30d'].fillna(0)
icomfxall['mfamextra_t90d'] = icomfxall['am_t90d'].fillna(0) + icomfxall['mf_t90d'].fillna(0) +\
                           icomfxall['jhb_t90d'].fillna(0) + icomfxall['ydy_t90d'].fillna(0)


#------------------------------------------------------------------------------
### Idea 1: long before meetings
#------------------------------------------------------------------------------


### comein
icom2 = icomfxall.copy()
c_sgnl = (icom2['comein_flag'] == 1)
icom2.loc[c_sgnl, 'sgnl'] = 1

o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2020-12-31') & (icom2.datadate>='2019-09-01')].\
        dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_fx) #3.13 / 2.77


### comein
icom2 = icomfxall.copy()
c_sgnl = (icom2['comein_flag'] == 1) & (icom2['days2event']<=5)
icom2.loc[c_sgnl, 'sgnl'] = 1

o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2020-12-31')& (icom2.datadate>='2019-09-01')&(icom2['isin_hk_uni']==1)].\
        dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_fx)
                         
            


#import os
#f1 = os.listdir(r"\\vfudat04\udat04\thzhang\Downloads\yuediaoyan")
#t1 = pd.concat(pd.read_parquet(os.path.join(r"\\vfudat04\udat04\thzhang\Downloads\yuediaoyan",f)) for f in f1)
#t1.loc[t1['调研时间'].notnull(), 'event_dt'] = t1.loc[t1['调研时间'].notnull(), '调研时间']
#t1.loc[t1['会议时间'].notnull(), 'event_dt'] = t1.loc[t1['会议时间'].notnull(), '会议时间']
#t1.loc[t1['时间'].notnull(), 'event_dt'] = t1.loc[t1['时间'].notnull(), '时间']
#t1['event_dt'] = pd.to_datetime(t1['event_dt'].str.strip().str[:10])
#t2 = t1.groupby('link').agg({'scraper_ts':min,'event_dt':min}).reset_index()
#t2['scraper_ts'] = pd.to_datetime(t2['scraper_ts'].dt.date)
#t2['diff'] = (t2['event_dt'] - t2['scraper_ts']).dt.days
#t2 = t2[t2['scraper_ts']>'2021-05-16']

### ydy + jhb: long 10 days before, hold 10 days
icom2 = icomfxall.copy()
c_sgnl = (icom2['jhb_flag_10'] == 1) | (icom2['ydy_flag_10'] == 1)
icom2.loc[c_sgnl, 'sgnl'] = 1

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna
(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 4.86 / 3.81

o_1 = yu.bt_cn(icom2[(icom2['datadate']<='2019-12-31')&((icom2['isin_tier1city_jhb'])|(icom2['isin_tier1city_ydy']))].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 1.52 / 1.42


o_1 = yu.bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['isin_hk_uni']==1)].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 2.95 / 2.62



### ydy + jhb: long 5 days before, hold 5 days ###!!!
icom2 = icomfxall.copy()
c_sgnl = (icom2['jhb_flag_5'] == 1) | (icom2['ydy_flag_5'] == 1)
icom2.loc[c_sgnl, 'sgnl'] = 1

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 2.0 / 1.36

# if we exlude zero-attending in yuediaoyan, we get: 2.34 / 1.89

o_1 = yu.bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['isin_hk_uni']==1)].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 1.77 / 1.42

o_1 = yu.bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['isin_hk_uni']==1)&(icom2['BarrRet_CLIP_t60d_rk']<0)].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 0.51 / 0.22

o_1 = yu.bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['isin_hk_uni']==1)&(icom2['mfam_t30d']==0)].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 1.33 / 0.99





### long 5 days before, hold 10 days
icom2 = icomfxall.copy()
c_sgnl = (icom2['jhb_flag_5'] == 1) | (icom2['ydy_flag_5'] == 1)
icom2.loc[c_sgnl, 'sgnl'] = 1
icom2['sgnl'] = icom2.groupby('ticker')['sgnl'].ffill(limit = 5)

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['t
icker','datadate']),
        'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 0.99 / 0.76

o_1 = yu.bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['isin_hk_uni']==1)].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 1.28 / 1.05

o_1 = yu.bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 1.94 / 1.64

#inspection
o_1.groupby('ticker')['pnl_tcost'].sum().sort_values().head(5)
t1 = icom2[icom2.ticker=='000027.SZ']
plot_sgnl('601231.SH')


### ydy + jhb: long 2 days before, hold 2 days
icom2 = icomfxall.copy()
c_sgnl = (icom2['jhb_flag_2'] == 1) | (icom2['ydy_flag_2'] == 1)
icom2.loc[c_sgnl, 'sgnl'] = 1

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 0.61 / -0.21


### ydy + jhb: long 2 days before, hold 5 days
icom2 = icomfxall.copy()
c_sgnl = (icom2['jhb_flag_2'] == 1) | (icom2['ydy_flag_2'] == 1)
icom2.loc[c_sgnl, 'sgnl'] = 1
icom2['sgnl'] = icom2.groupby('ticker')['sgnl'].ffill(limit=3)

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 




### ydy + jhb: long 3 days before, hold 3 days
icom2 = icomfxall.copy()
c_sgnl = (icom2['jhb_flag_3'] == 1) | (icom2['ydy_flag_3'] == 1)
icom2.loc[c_sgnl, 'sgnl'] = 1

o_1 = yu.bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
        dropna(subset=['sgnl','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
        'sgnl','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 0.74 / 0.2


#------------------------------------------------------------------------------
### Idea 2: residual buyside meetings 
#------------------------------------------------------------------------------

### Shenzhen

i_combine2 = icomfx.copy()

o_resid_df = pd.DataFrame()

for d in pd.date_range(start=i_combine2.datadate.min()+pd.to_timedelta('365 days'), end = i_combine2.datadate.max()):
    print(d, end=',')
    t_
data = i_combine2[(i_combine2['datadate']>=d-pd.to_timedelta('365 days'))&(i_combine2['datadate']<d)]
    t_data_today = i_combine2[(i_combine2['datadate']==d)]
    ols_buyside_beta = yu.ols_beta(t_data[['SIZE','turnover','BarrRet_CLIP_t60d_rk']].values,t_data['mfamextra_t90d'].values)
    t_data_today['residual_buyside'] = t_data_today['mfamextra_t90d'] - ols_buyside_beta[0] - t_data_today['SIZE']*ols_buyside_beta[1] - t_data_today['turnover']*ols_buyside_beta[2] - t_data_today['BarrRet_CLIP_t60d_rk']*ols_buyside_beta[3]
    t_data_today = t_data_today[t_data_today['residual_buyside'].notnull()]
    o_resid_df = o_resid_df.append(t_data_today, ignore_index = True)

i_combine2 = i_combine2.merge(o_resid_df[['ticker','datadate',
                              'residual_buyside']], on = ['datadate', 'ticker'], how = 'left')

i_combine2['residual_buyside_rk'] = i_combine2.groupby('datadate')['residual_buyside'].apply(lambda x: yu.uniformed_rank(x)).values


# i_combine2[['ticker', 'datadate', 'mf_t90d', 'am_t90d', 'jhb_t90d', 'ydy_t90d', 'mfamextra_t90d', 'residual_buyside', 'residual_buyside_rk']].to_parquet(r'S:\Data\China Data Hunt\cache\pWIND_investormeeting_3_t90d_mfam_cnt.paruqet')

i_combine2 = i_combine2.drop(columns=['fxRet_CLIP+1d'])
i_combine2 = i_combine2.merge(i_sd, on = ['ticker','datadate'], how = 'left')

o_1 = yu.bt_cn(i_combine2[i_combine2['datadate']<='2019-12-31'].\
            dropna(subset=['residual_buyside_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'residual_buyside_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) #prcs 2.6 / 1.98 vs 2.08 / 1.64


o_1 = yu.bt_cn(i_combine2[i_combine2['datadate']<='2019-12-31'].\
            dropna(subset=['residual_buyside_rk','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'residual_buyside_rk','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) #prcs 2.58 / 1.89 vs 2.08 / 1.64


o_1 = yu.bt_cn_2(i_combine2[(i_combine2['datadate']<='2019-12-31')&(i_combine2['isin_hk_uni']==1)].\
            dropna(subset=['residual_buyside_rk','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'residual_buyside_rk','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx, test_short_limit = True) #prcs 0.09 / -0.96




o_1 = yu.bt_cn(i_combine2[(i_combine2['datadate']<='2019-12-31') & (i_combine2['residual_buyside_rk']>0)].\
            dropna(subset=['residual_buyside_rk','fxRet_CLIP+1
d']).drop_duplicates(subset=['ticker','datadate']),
            'residual_buyside_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) #prcs 0.67 / 0.51

o_1 = yu.bt_cn(i_combine2[(i_combine2['datadate']<='2019-12-31') & (i_combine2['residual_buyside_rk']>0.8)].\
            dropna(subset=['residual_buyside_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'residual_buyside_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) #prcs 0.43 / 0.3


o_1 = yu.bt_cn(i_combine2[(i_combine2['datadate']<='2019-12-31') & (i_combine2['residual_buyside_rk']<0)].\
            dropna(subset=['residual_buyside_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'residual_buyside_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) #prcs 0.85 / 0.71


### shenzhen, replace 0 with nan

i_combine2 = icomfx.copy()
i_combine2['mfamextra_t90d'] = i_combine2['mfamextra_t90d'].replace(0, np.nan)

o_resid_df = pd.DataFrame()
for d in pd.date_range(start=i_combine2.datadate.min()+pd.to_timedelta('365 days'), end = i_combine2.datadate.max()):
    print(d, end=',')
    t_data = i_combine2[(i_combine2['datadate']>=d-pd.to_timedelta('365 days'))&(i_combine2['datadate']<d)]
    t_data_today = i_combine2[(i_combine2['datadate']==d)]
    ols_buyside_beta = yu.ols_beta(t_data[['SIZE','turnover','BarrRet_CLIP_t60d_rk']].values,t_data['mfamextra_t90d'].values)
    t_data_today['residual_buyside'] = t_data_today['mfamextra_t90d'] - ols_buyside_beta[0] - t_data_today['SIZE']*ols_buyside_beta[1] - t_data_today['turnover']*ols_buyside_beta[2] - t_data_today['BarrRet_CLIP_t60d_rk']*ols_buyside_beta[3]
    t_data_today = t_data_today[t_data_today['residual_buyside'].notnull()]
    o_resid_df = o_resid_df.append(t_data_today, ignore_index = True)

i_combine2 = i_combine2.merge(o_resid_df[['ticker','datadate',
                              'residual_buyside']], on = ['datadate', 'ticker'], how = 'left')
i_combine2['residual_buyside_rk'] = i_combine2.groupby('datadate')['residual_buyside'].apply(lambda x: yu.uniformed_rank(x)).values

i_combine2 = i_combine2.drop(columns=['fxRet_CLIP+1d'])
i_combine2 = i_combine2.merge(i_sd, on = ['ticker','datadate'], how = 'left')

o_1 = yu.bt_cn(i_combine2[i_combine2['datadate']<='2019-12-31'].\
            dropna(subset=['residual_buyside_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'residual_buyside_rk','fxRet_CLIP+1d', sgnl_b
efore_3pm=False, static_data = i_sd_fx) #prcs 1.36 / 0.86


### shenzhen, replace nan with 0

i_combine2 = icomfx.copy()
i_combine2['mfamextra_t90d'] = i_combine2['mfamextra_t90d'].fillna(0)

o_resid_df = pd.DataFrame()
for d in pd.date_range(start=i_combine2.datadate.min()+pd.to_timedelta('365 days'), end = i_combine2.datadate.max()):
    print(d, end=',')
    t_data = i_combine2[(i_combine2['datadate']>=d-pd.to_timedelta('365 days'))&(i_combine2['datadate']<d)]
    t_data_today = i_combine2[(i_combine2['datadate']==d)]
    ols_buyside_beta = yu.ols_beta(t_data[['SIZE','turnover','BarrRet_CLIP_t60d_rk']].values,t_data['mfamextra_t90d'].values)
    t_data_today['residual_buyside'] = t_data_today['mfamextra_t90d'] - ols_buyside_beta[0] - t_data_today['SIZE']*ols_buyside_beta[1] - t_data_today['turnover']*ols_buyside_beta[2] - t_data_today['BarrRet_CLIP_t60d_rk']*ols_buyside_beta[3]
    t_data_today = t_data_today[t_data_today['residual_buyside'].notnull()]
    o_resid_df = o_resid_df.append(t_data_today, ignore_index = True)

i_combine2 = i_combine2.merge(o_resid_df[['ticker','datadate',
                              'residual_buyside']], on = ['datadate', 'ticker'], how = 'left')
i_combine2['residual_buyside_rk'] = i_combine2.groupby('datadate')['residual_buyside'].apply(lambda x: yu.uniformed_rank(x)).values

i_combine2 = i_combine2.drop(columns=['fxRet_CLIP+1d'])
i_combine2 = i_combine2.merge(i_sd, on = ['ticker','datadate'], how = 'left')

o_1 = yu.bt_cn(i_combine2[i_combine2['datadate']<='2019-12-31'].\
            dropna(subset=['residual_buyside_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'residual_buyside_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) #prcs 2.6 / 1.98

o_1 = yu.bt_cn(i_combine2[i_combine2['datadate']<='2019-12-31'].\
            dropna(subset=['residual_buyside_rk','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'residual_buyside_rk','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) #prcs 





# all a share

i_combine2 = icomfx[icomfx['ticker'].str.contains('SZ')].copy()

o_resid_df = pd.DataFrame()

for d in pd.date_range(start=i_combine2.datadate.min()+pd.to_timedelta('365 days'), end = i_combine2.datadate.max()):
    print(d, end=',')
    t_data = i_combine2[(i_combine2['datadate']>=d-pd.to_timedelta('365 days'))&(i_combine2['datadate']<d)]
    t_data_today = i_combine2[(i_combine2['datadate']==d)]
    ols_buyside_beta = yu.ols
_beta(t_data[['SIZE','turnover','BarrRet_CLIP_t60d_rk']].values,t_data['mfamextra_t90d'].values)
    t_data_today['residual_buyside'] = t_data_today['mfamextra_t90d'] - ols_buyside_beta[0] - t_data_today['SIZE']*ols_buyside_beta[1] - t_data_today['turnover']*ols_buyside_beta[2] - t_data_today['BarrRet_CLIP_t60d_rk']*ols_buyside_beta[3]
    t_data_today = t_data_today[t_data_today['residual_buyside'].notnull()]
    o_resid_df = o_resid_df.append(t_data_today, ignore_index = True)

i_combine2 = i_combine2.merge(o_resid_df[['ticker','datadate',
                              'residual_buyside']], on = ['datadate', 'ticker'], how = 'left')

i_combine2['residual_buyside_rk'] = i_combine2.groupby('datadate')['residual_buyside'].apply(lambda x: yu.uniformed_rank(x)).values


o_1 = yu.bt_cn(i_combine2[i_combine2['datadate']<='2019-12-31'].\
            dropna(subset=['residual_buyside_rk','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'residual_buyside_rk','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) #prcs 3.11 / 2.26

o_1 = yu.bt_cn_15(i_combine2[i_combine2['datadate']<='2019-12-31'].\
            dropna(subset=['residual_buyside_rk','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'residual_buyside_rk','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) #prcs 2.04

i_combine2 = i_combine2.drop(columns=['fxRet_CLIP+1d'])
i_combine2 = i_combine2.merge(i_sd, on = ['ticker','datadate'], how = 'left')

o_1 = yu.bt_cn(i_combine2[i_combine2['datadate']<='2019-12-31'].\
            dropna(subset=['residual_buyside_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'residual_buyside_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) #prcs 2.89 / 2.18 vs 2.08 / 1.64



#------------------------------------------------------------------------------
### Idea 3: assume we can get data early ... 
#------------------------------------------------------------------------------
hyp_meeting = yu.get_sql('''select S_INFO_WINDCODE as ticker, [EVENT_ID], [S_ACTIVITIESTYPE], 
                    [S_SURVEYDATE], [S_SURVEYTIME], [ANN_DT] as datadate, [S_SURVEYTYPECODE], 
                    [S_SURVEYINSTIS_TOT] from [WIND].[dbo].[ASHAREISACTIVITY] 
                    where len(S_SURVEYDATE)=8 ''')
hyp_meeting = hyp_meeting[['ticker','datadate','S_SURVEYINSTIS_TOT']]
hyp_meeting['datadate'] = pd.to_datetime(hyp_meeting['datadate'])
hyp_meeting['dat
adate_2d'] = hyp_meeting['datadate'] - pd.to_timedelta('2 days')
hyp_meeting['flag_2d'] = 1
hyp_meeting['datadate_4d'] = hyp_meeting['datadate'] - pd.to_timedelta('4 days')
hyp_meeting['flag_4d'] = 1
hyp_meeting['datadate_6d'] = hyp_meeting['datadate'] - pd.to_timedelta('6 days')
hyp_meeting['flag_6d'] = 1
hyp_meeting['datadate_8d'] = hyp_meeting['datadate'] - pd.to_timedelta('8 days')
hyp_meeting['flag_8d'] = 1
hyp_meeting['datadate_10d'] = hyp_meeting['datadate'] - pd.to_timedelta('10 days')
hyp_meeting['flag_10d'] = 1
hyp_meeting['datadate_15d'] = hyp_meeting['datadate'] - pd.to_timedelta('15 days')
hyp_meeting['flag_15d'] = 1
hyp_meeting['datadate_20d'] = hyp_meeting['datadate'] - pd.to_timedelta('20 days')
hyp_meeting['flag_20d'] = 1

hyp_meeting = hyp_meeting.sort_values('datadate')


icom_hyp = pd.merge_asof(i_sd_map_fx, hyp_meeting[['ticker','datadate_2d','flag_2d']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_2d'], 
                     tolerance = pd.to_timedelta('2 days') )

icom_hyp = pd.merge_asof(icom_hyp, hyp_meeting[['ticker','datadate_4d','flag_4d']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_4d'], 
                     tolerance = pd.to_timedelta('4 days') )

icom_hyp = pd.merge_asof(icom_hyp, hyp_meeting[['ticker','datadate_6d','flag_6d']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_6d'], 
                     tolerance = pd.to_timedelta('6 days') )

icom_hyp = pd.merge_asof(icom_hyp, hyp_meeting[['ticker','datadate_8d','flag_8d']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_8d'], 
                     tolerance = pd.to_timedelta('8 days') )

icom_hyp = pd.merge_asof(icom_hyp, hyp_meeting[['ticker','datadate_10d','flag_10d']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_10d'], 
                     tolerance = pd.to_timedelta('10 days') )

icom_hyp = pd.merge_asof(icom_hyp, hyp_meeting[['ticker','datadate_15d','flag_15d']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_15d'], 
                     tolerance = pd.to_timedelta('15 days') )


icom_hyp = pd.merge_asof(icom_hyp, hyp_meeting[['ticker','datadate_20d','flag_20d','S_SURVEYINSTIS_TOT']], 
                     by = ['ticker'], left_on = ['datadate'], right_on = ['datadate_20d'], 
                     tolerance = pd.to_timedelta('20 days'
) )

o_1 = yu.bt_cn(icom_hyp[(icom_hyp['datadate']<='2019-12-31')&(icom_hyp['isin_hk_uni']==1)].\
            dropna(subset=['flag_2d','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flag_2d','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 3.43 / 2.53

o_1 = yu.bt_cn(icom_hyp[(icom_hyp['datadate']<='2019-12-31')&(icom_hyp['isin_hk_uni']==1)&(icom_hyp['S_SURVEYINSTIS_TOT']>1)].\
            dropna(subset=['flag_2d','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flag_2d','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 3.73 / 2.91

o_1 = yu.bt_cn(icom_hyp[(icom_hyp['datadate']<='2019-12-31')&(icom_hyp['isin_hk_uni']==1)&(icom_hyp['S_SURVEYINSTIS_TOT']>5)].\
            dropna(subset=['flag_2d','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flag_2d','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 

o_1 = yu.bt_cn(icom_hyp[(icom_hyp['datadate']<='2019-12-31')&(icom_hyp['isin_hk_uni']==1)].\
            dropna(subset=['flag_4d','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flag_4d','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 3.73 / 3.05

o_1 = yu.bt_cn(icom_hyp[(icom_hyp['datadate']<='2019-12-31')&(icom_hyp['isin_hk_uni']==1)].\
            dropna(subset=['flag_6d','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flag_6d','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 4 / 3.45

o_1 = yu.bt_cn(icom_hyp[(icom_hyp['datadate']<='2019-12-31')&(icom_hyp['isin_hk_uni']==1)].\
            dropna(subset=['flag_8d','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flag_8d','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 

o_1 = yu.bt_cn(icom_hyp[(icom_hyp['datadate']<='2019-12-31')&(icom_hyp['isin_hk_uni']==1)].\
            dropna(subset=['flag_10d','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flag_10d','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 


o_1 = yu.bt_cn(icom_hyp[(icom_hyp['datadate']<='2019-12-31')&(icom_hyp['isin_hk_uni']==1)].\
            dropna(subset=['flag_20d','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flag_20d','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd_fx) # 
