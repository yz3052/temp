﻿#$%^&* pDataYes_recruit_03.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 19 13:51:18 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import zipfile
import csv

import jieba


# this studies 51 + liepin + others
# this studies different cities 
# this studies dedup
# this studies panel % metrics
# this studies education level
# this studies exp level



#--------------------------------------------------
### calculate 1 day metrics: sum of job counts per ticker, salary range

i_p = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet')


i_tk_stat = pd.DataFrame()
for p in i_p:
    t_data = pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet', p))
    
    t_data = t_data[t_data['ticker_symbol'].notnull()]
    t_data = t_data[t_data['ticker_symbol'].str.contains('\d{6}')]
    t_data = t_data[t_data['working_location'].notnull()]
    #t_data = t_data[t_data['working_location'].str.contains('重庆')] ###!!! city selection
    t_data = t_data[t_data.source.isin(['51job'])] ###!!! '51job','猎聘网', '拉勾网', '智联招聘', 'BOSS直聘'
    t_data['datadate'] = pd.to_datetime((pd.to_datetime(t_data['published_at'])+pd.to_timedelta('1 day')).dt.date)###!!!
    t_data['publish_date'] = pd.to_datetime(pd.to_datetime(t_data['published_at']).dt.date)
    t_data = t_data.drop_duplicates(subset = ['ticker_symbol', 'title', 'company_info_id', 'working_address', 
                                              'publish_date','datadate'], keep = 'last') ###!!! dedup
    t_data['salary'] = (t_data['annual_salary_range_start'] + t_data['annual_salary_range_end'])/2
    t_data['salaryMin'] = t_data['annual_salary_range_start']
    
    t_data['educational_requirement'] = t_data['educational_requirement'].fillna('')
    c1 = (t_data['educational_requirement']=='') | t_data['educational_requirement'].str.contains('限') | t_data['educational_requirement'].str.contains('小学')
    t_data.loc[c1, 'edu'] = 1
    c2 = t_data['educational_requirement'].str.contains('初中')
    t_data.loc[c2, 'edu'] = 2
    c3 = t_data['educational_requirement'].str.contains('中.*技') | t_data['educational_requirement'].str.contains('中.*专')
    t_data.loc[c3, 'edu'] = 3
    c4 = t_data['educational_requirement'].str.contains('高中')
    t_data.loc[c4, 'edu'] = 4
    c5 = t_data['educational_requirement'].str.contains('大专')
    t_data.loc[c5, 'edu'] = 5
    c6 = t_data['educational_requirement'].str.cont
ains('本科|学士')
    t_data.loc[c6, 'edu'] = 6
    c7 = t_data['educational_requirement'].str.contains('硕士|MBA')
    t_data.loc[c7, 'edu'] = 7
    c8 = t_data['educational_requirement'].str.upper().str.contains('博士|PHD')
    t_data.loc[c8, 'edu'] = 8
    t_data.loc[t_data['edu'].isnull(), 'edu'] = 1
    
    t_data.loc[t_data['edu']>=6, 'edu_higher_flag'] = 1
    t_data.loc[t_data['edu']<6, 'edu_higher_flag'] = 0
    
    #t_data = t_data[t_data['edu']>=6] ###!!!
    
    
    c_0 = t_data['working_experience'].isnull()
    t_data.loc[c_0, 'working_experience'] = ''
    c_0 = t_data['working_experience'].notnull()
    t_data.loc[c_0, 'working_experience'] = t_data.loc[c_0, 'working_experience'].str.replace(' ','')
    c_n = t_data['working_experience'].str.contains('^\d+年')
    t_data.loc[c_n, 'exp'] = t_data.loc[c_n, 'working_experience'].str.extract('(\d+)年').astype(int).values
    c_n = t_data['working_experience'].str.contains('\d+-\d+年')
    t_data.loc[c_n, 'exp'] = t_data.loc[c_n, 'working_experience'].str.extract('(\d+)-\d+年').astype(int).values
    c_0 = t_data['working_experience'].str.contains('无|应届|不限|1年以下|一年以下|在读')
    t_data.loc[c_0, 'exp'] = 0
    c_1 = t_data['working_experience'].str.contains('一年经验')
    t_data.loc[c_1, 'exp'] = 1
    
    
    
    c_senior = t_data['title'].str.contains('经理|总监') & ((t_data['exp']=='')|(t_data['exp']>=5))
    t_data.loc[c_senior, 'senior_flag'] = 1
    
    
    t_sum = t_data.groupby(['ticker_symbol', 'datadate']).agg({'id':'count', 'salary': ['sum', 'mean'], 'salaryMin': ['sum', 'mean'], 'edu':'sum', 'edu_higher_flag':'sum', 'exp':'mean', 'senior_flag':'sum'}).reset_index()
    t_sum.columns = ['%s%s' % (a, '_%s' % b if b else '') for a, b in t_sum.columns]
    t_sum['id_pct'] = t_sum['id_count'].divide(len(t_data))
    t_sum['panel_size'] = len(t_data)
    i_tk_stat = i_tk_stat.append(t_sum, sort = False)


### calculate ttm job counts

i_tk_t1y_cnt = pd.DataFrame()
for dt in pd.date_range(start = '2016-04-01', end = '2021-08-01'):
    print('.', end='')
    t_tk_cnt = i_tk_stat[(i_tk_stat['datadate']<=dt) & (i_tk_stat['datadate']>=dt-pd.to_timedelta('365 days'))]
    t_tk_t1y_cnt = t_tk_cnt.groupby('ticker_symbol')[['id_count', 'id_pct','edu_sum','edu_higher_flag_sum','salaryMin_sum','senior_flag_sum']].sum().reset_index()
    t_tk_t1y_cnt['edu_mean'] = t_tk_t1y_cnt['edu_sum'].divide(t_tk_t1y_cnt['id_count'])
    t_tk_t1y_cnt['eduHigher_pct'] = t_tk_t1y_cnt['edu_higher_flag_sum'].divide(t_tk_t1y_cnt['id_c
ount'])
    t_tk_t1y_cnt['salaryMin_mean'] = t_tk_t1y_cnt['salaryMin_sum'].divide(t_tk_t1y_cnt['id_count'])
    t_tk_t1y_cnt['datadate'] = dt
    
    t_tk_t1y_mean = t_tk_cnt.groupby('ticker_symbol')['exp_mean'].mean().reset_index()
    
    t_tk_t1y_stat = t_tk_t1y_cnt.merge(t_tk_t1y_mean,on='ticker_symbol',how='outer')
    
    i_tk_t1y_cnt = i_tk_t1y_cnt.append(t_tk_t1y_stat, sort = False)
    
i_tk_t1y_cnt = i_tk_t1y_cnt[i_tk_t1y_cnt['ticker_symbol'].str.len()==6]
c_sz = i_tk_t1y_cnt['ticker_symbol'].str[0].isin(['0', '3'])
c_sh = i_tk_t1y_cnt['ticker_symbol'].str[0].isin(['6'])
i_tk_t1y_cnt.loc[c_sz, 'ticker'] = i_tk_t1y_cnt.loc[c_sz, 'ticker_symbol'] + '.SZ'
i_tk_t1y_cnt.loc[c_sh, 'ticker'] = i_tk_t1y_cnt.loc[c_sh, 'ticker_symbol'] + '.SH'

i_tk_t1y_cnt = i_tk_t1y_cnt.rename(columns = {'id_count':'id_t1y', 'id_pct':'id_pct_t1y',
                                              'edu_mean':'edu_mean_t1y', 'edu_higher_flag_sum':'edu_higher_cnt_t1y',
                                              'salaryMin_mean':'salaryMin_mean_t1y'})
i_tk_t1y_cnt = i_tk_t1y_cnt.drop(columns = 'ticker_symbol')


# Calculate various job count growth 

i_tk_t1y_cnt['datadate_1y'] = i_tk_t1y_cnt['datadate'] - pd.to_timedelta('365 days')

i_tk_t1y_cnt = i_tk_t1y_cnt.merge(i_tk_t1y_cnt[['ticker', 'datadate','id_t1y','id_pct_t1y','edu_mean_t1y','salaryMin_mean_t1y','exp_mean']],
                                        left_on = ['datadate_1y', 'ticker'], right_on = ['datadate', 'ticker'],
                                        how = 'left', suffixes = ['', '_merge'])
i_tk_t1y_cnt = i_tk_t1y_cnt.drop(columns = ['datadate_merge'])
i_tk_t1y_cnt = i_tk_t1y_cnt.rename(columns = {'id_t1y_merge': 'id_t1y_1y', 'id_pct_t1y_merge':'id_pct_t1y_1y', 'edu_mean_t1y_merge':'edu_mean_t1y_1y',
                                              'salaryMin_mean_t1y_merge':'salaryMin_mean_t1y_1y','exp_mean_merge':'exp_mean_1y'})

i_tk_t1y_cnt['id_t1y_yy'] = (i_tk_t1y_cnt['id_t1y']-i_tk_t1y_cnt['id_t1y_1y']).divide(i_tk_t1y_cnt['id_t1y']+i_tk_t1y_cnt['id_t1y_1y'])
i_tk_t1y_cnt['id_t1y_yy'] = i_tk_t1y_cnt['id_t1y_yy'].replace(np.inf, np.nan).replace(-np.inf, np.nan)

i_tk_t1y_cnt = i_tk_t1y_cnt.drop(columns = ['datadate_1y'])



#------------------------------------------------------------------------------
### get sd
i_sd = pw.get_ashare_hk_sd_v2()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_
USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','a50_300_flag','a50_flag']]

i_sd_map_300  =i_sd_map[i_sd_map['a50_300_flag']==1]
i_sd_map_50  = i_sd_map[i_sd_map['a50_flag']==1]


### get historical mc

i_mc = yu.get_sql('''select ticker, datadate, mc from [CNDB].[dbo].[UNIVERSE_ALL_CN] 
                    where ticker in ('{0}') '''.format("','".join( i_sd_map['ticker'].str[:6].unique().tolist() )))
i_mc['datadate_2y'] = i_mc['datadate'] - pd.to_timedelta('730 days')
i_mc['datadate_1y'] = i_mc['datadate'] - pd.to_timedelta('365 days')
i_mc['datadate_1h'] = i_mc['datadate'] - pd.to_timedelta('182 days')
i_mc['datadate_1q'] = i_mc['datadate'] - pd.to_timedelta('91 days')
i_mc['datadate_1m'] = i_mc['datadate'] - pd.to_timedelta('30 days')
i_mc['datadate_1w'] = i_mc['datadate'] - pd.to_timedelta('7 days')

i_mc = i_mc.sort_values('datadate')

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1q', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1q'})

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1y', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1y'})
i_mc = i_mc.drop(columns = ['datadate_1q', 'datadate_1y'])

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_2y', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_2y'})
i_mc = i_mc.drop(columns = ['datadate_2y'])

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1h', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1h'})
i_mc = i_mc.drop(columns = ['datadate_1h'])

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1m', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.r
ename(columns = {'mc_merge': 'mc_1m'})
i_mc = i_mc.drop(columns = ['datadate_1m'])

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1w', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1w'})
i_mc = i_mc.drop(columns = ['datadate_1w'])

c_sh = i_mc['ticker'].str[0].isin(['6'])
c_sz = i_mc['ticker'].str[0].isin(['0', '3'])
i_mc.loc[c_sz, 'ticker'] = i_mc.loc[c_sz, 'ticker'] + '.SZ'
i_mc.loc[c_sh, 'ticker'] = i_mc.loc[c_sh, 'ticker'] + '.SH'

i_mc = i_mc.drop(columns = 'mc')




#------------------------------------------------------------------------------
### ---- combine (csi300 universe)
#------------------------------------------------------------------------------

icom_300 = i_sd[i_sd['a50_300_flag']==1].merge(i_tk_t1y_cnt, on = ['ticker', 'datadate'], how = 'left')
icom_300 = icom_300.merge(i_mc, on = ['ticker', 'datadate'], how = 'left')

icom_300 = icom_300.sort_values(['ticker','datadate'])



# benchmark alpha


icom2 = icom_300.copy()

icom2['job_t1y_df1y_dv_mc'] = (icom2['id_t1y'] - icom2['id_t1y_1y']).divide(icom2['mc_1y'])
icom2['job_t1y_df1y_dv_mc_rk'] = icom2.groupby('datadate')['job_t1y_df1y_dv_mc'].apply(yu.uniformed_rank).values

icom2['sgnl1'] = np.nan
c1 = icom2['job_t1y_df1y_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl1'] = icom2.loc[c1, 'job_t1y_df1y_dv_mc_rk']

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.01 / 1.69 if datadate=created_at, else: lower

icom2['job_t1y_df1y_dv_mc_bk'] = icom2.groupby('datadate')['job_t1y_df1y_dv_mc'].apply(lambda x: yu.pdqcut(x, bins=10)).values
yu.create_cn_3x3(icom2, ['job_t1y_df1y_dv_mc_bk'], 'job_t1y_df1y_dv_mc')


# benchmark alpha (in %)

icom2 = icom_300.copy()

icom2['jobPct_t1y_df1y_dv_mc'] = (icom2['id_pct_t1y'] - icom2['id_pct_t1y_1y']).divide(icom2['mc_1y'])
icom2['jobPct_t1y_df1y_dv_mc_rk'] = icom2.groupby('datadate')['jobPct_t1y_df1y_dv_mc'].apply(yu.uniformed_rank).values

icom2['sgnl1'] = np.nan
c1 = icom2['jobPct_t1y_df1y_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl1'] = icom2.loc[c1, 'jobPct_t1y_df1y_dv_mc_rk']

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_
duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.01 / 1.33

# education alpha 


icom2 = icom_300.copy()

icom2['edu_mean_t1y_rk'] = icom2.groupby('datadate')['edu_mean_t1y'].apply(yu.uniformed_rank).values
icom2['edu_mean_t1y_bk'] = icom2.groupby('datadate')['edu_mean_t1y'].apply(lambda x: yu.pdqcut(x, bins = 10)).values

icom2['edu_mean_t1y_secrk'] = icom2.groupby(['datadate','GSECTOR'])['edu_mean_t1y'].apply(yu.uniformed_rank).values
icom2['edu_mean_t1y_secbk'] = icom2.groupby(['datadate','GSECTOR'])['edu_mean_t1y'].apply(lambda x: yu.pdqcut(x, bins = 10)).values

icom2['edu_mean_t1y_df1y'] = icom2['edu_mean_t1y'].divide(icom2['edu_mean_t1y_1y'])
icom2['edu_mean_t1y_df1y_rk'] = icom2.groupby('datadate')['edu_mean_t1y_df1y'].apply(yu.uniformed_rank).values
icom2['edu_mean_t1y_df1y_bk'] = icom2.groupby('datadate')['edu_mean_t1y_df1y'].apply(lambda x: yu.pdqcut(x, bins = 10)).values

icom2['eduHigher_pct'] = icom2['edu_higher_cnt_t1y'].divide(icom2['id_t1y'])
icom2['eduHigher_pct_secrk'] = icom2.groupby(['datadate','GSUBIND'])['eduHigher_pct'].apply(yu.uniformed_rank).values
icom2['eduHigher_pct_secbk'] = icom2.groupby(['datadate','GSUBIND'])['eduHigher_pct'].apply(lambda x: yu.pdqcut(x, bins = 10)).values

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['edu_mean_t1y_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'edu_mean_t1y_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 


yu.create_cn_3x3(icom2, ['edu_mean_t1y_bk'], 'edu_mean_t1y')
yu.create_cn_3x3(icom2, ['edu_mean_t1y_secbk'], 'edu_mean_t1y')
yu.create_cn_3x3(icom2, ['edu_mean_t1y_df1y_bk'], 'edu_mean_t1y_df1y')
yu.create_cn_3x3(icom2, ['eduHigher_pct_secbk'], 'eduHigher_pct')


# salary related alpha

icom2 = icom_300.copy()

icom2['salaryMin_sum_df1y'] = icom2['salaryMin_mean_t1y'] - icom2['salaryMin_mean_t1y_1y']
icom2['salaryMin_sum_df1y_dv_mc'] = icom2['salaryMin_sum_df1y'].divide(icom2['mc_1y'])
icom2['salaryMin_sum_df1y_dv_mc_rk'] = icom2.groupby('datadate')['salaryMin_sum_df1y_dv_mc'].apply(yu.uniformed_rank).values

icom2['salaryMin_mean_t1y_rk'] = icom2.groupby('datadate')['salaryMin_mean_t1y'].apply(yu.uniformed_rank).values
icom2['salaryMin_mean_t1y_bk'] = icom2.groupby('datadate')['salaryMin_mean_t1y'].apply(lambda x: yu.pdqcut(x, bins = 10)).values
icom2['salaryMin_mean_t1y_5bk'] = icom2.groupby('datadate')['salaryMin_mean_t1y'].apply(lam
bda x: yu.pdqcut(x, bins = 5)).values

icom2['job_t1y_df1y_dv_mc'] = (icom2['id_t1y'] - icom2['id_t1y_1y']).divide(icom2['mc_1y'])
icom2['job_t1y_df1y_dv_mc_rk'] = icom2.groupby('datadate')['job_t1y_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_t1y_df1y_dv_mc_salaryRk'] = icom2.groupby(['datadate','salaryMin_mean_t1y_5bk'])['job_t1y_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_t1y_df1y_dv_mc_salaryBk'] = icom2.groupby(['datadate','salaryMin_mean_t1y_5bk'])['job_t1y_df1y_dv_mc'].apply(lambda x: yu.pdqcut(x, bins = 5)).values


icom2['sgnl2'] = np.nan
c1 = icom2['salaryMin_sum_df1y_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl2'] = icom2.loc[c1, 'salaryMin_sum_df1y_dv_mc_rk']
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['salaryMin_sum_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'salaryMin_sum_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 


yu.create_cn_3x3(icom2, ['salaryMin_mean_t1y_bk'], 'salaryMin_mean_t1y')
yu.create_cn_3x3(icom2, ['job_t1y_df1y_dv_mc_salaryBk'], 'job_t1y_df1y_dv_mc')


# exp alpha

icom2 = icom_300.copy()

icom2['growth_rk'] = icom2.groupby('datadate')['GROWTH'].apply(yu.uniformed_rank).values
icom2['growth_2bk'] = icom2.groupby('datadate')['GROWTH'].apply(lambda x: yu.pdqcut(x,bins=2)).values

icom2['exp_mean_df'] = icom2['exp_mean'] - icom2['exp_mean_1y']
icom2['exp_mean_df_bk'] = icom2.groupby('datadate')['exp_mean_df'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['exp_mean_df_ind5bk'] = icom2.groupby(['datadate','GIND'])['exp_mean_df'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom2['exp_mean_rk'] = icom2.groupby('datadate')['exp_mean'].apply(yu.uniformed_rank).values
icom2['exp_mean_5bk'] = icom2.groupby('datadate')['exp_mean'].apply(lambda x: yu.pdqcut(x,bins=5)).values
icom2['exp_mean_10bk'] = icom2.groupby('datadate')['exp_mean'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['exp_mean_sec5bk'] = icom2.groupby(['datadate','GSECTOR'])['exp_mean'].apply(lambda x: yu.pdqcut(x,bins=5)).values
icom2['exp_mean_ind5bk'] = icom2.groupby(['datadate','GIND'])['exp_mean'].apply(lambda x: yu.pdqcut(x,bins=5)).values
icom2['exp_mean_ind10bk'] = icom2.groupby(['datadate','GIND'])['
exp_mean'].apply(lambda x: yu.pdqcut(x,bins=10)).values


icom2['job_t1y_df1y_dv_mc'] = (icom2['id_t1y'] - icom2['id_t1y_1y']).divide(icom2['mc_1y'])
icom2['job_t1y_df1y_dv_mc_rk'] = icom2.groupby('datadate')['job_t1y_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_t1y_df1y_dv_mc_salaryRk'] = icom2.groupby(['datadate','exp_mean_5bk'])['job_t1y_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['job_t1y_df1y_dv_mc_salaryBk'] = icom2.groupby(['datadate','exp_mean_5bk'])['job_t1y_df1y_dv_mc'].apply(lambda x: yu.pdqcut(x, bins = 5)).values

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

yu.create_cn_3x3(icom2[icom2.datadate>='2018-01-01'], ['exp_mean_5bk'], 'exp_mean')
yu.create_cn_3x3(icom2[icom2.datadate>='2020-01-01'], ['exp_mean_5bk'], 'exp_mean')
yu.create_cn_3x3(icom2[icom2.datadate<='2020-01-01'], ['exp_mean_5bk'], 'exp_mean')

yu.create_cn_3x3(icom2[icom2.datadate>='2020-01-01'], ['exp_mean_10bk'], 'exp_mean')
yu.create_cn_3x3(icom2[icom2.datadate>='2020-01-01'], ['exp_mean_sec5bk'], 'exp_mean')
yu.create_cn_3x3(icom2[icom2.datadate>='2020-01-01'], ['exp_mean_ind5bk'], 'exp_mean')
yu.create_cn_3x3(icom2[icom2.datadate>='2020-01-01'], ['exp_mean_ind10bk'], 'exp_mean')
yu.create_cn_3x3(icom2[icom2.datadate>='2020-01-01'], ['job_t1y_df1y_dv_mc_salaryBk'], 'job_t1y_df1y_dv_mc')
yu.create_cn_3x3(icom2[icom2.datadate>='2020-01-01'], ['exp_mean_df_bk'], 'exp_mean_df')
yu.create_cn_3x3(icom2[icom2.datadate>='2020-01-01'], ['exp_mean_df_ind5bk'], 'exp_mean_df')



# senior position


icom2 = icom_300.copy()

icom2 = icom2.sort_values(['ticker', 'datadate'])
icom2['senior_flag_sum_t1d'] = icom2.groupby('ticker')['senior_flag_sum'].shift()

c1 = (icom2['senior_flag_sum_t1d']<icom2['senior_flag_sum'])
icom2.loc[c1, 'sgnl'] = 1

yu.create_cn_decay(icom2, 'sgnl')

