﻿#$%^&* pTA_cn_zigzag_features.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 24 15:39:44 2023

@author: thzhang
"""



import pandas as pd 
import numpy as np

import util as yu



#------------------------------------------------------------------------------
### window = 60, 15 vertex, history-initial-price-normalized, including future vertex 
#------------------------------------------------------------------------------



### get price

i_ohlc = yu.get_sql_wind('''select s_info_windcode as ticker, trade_dt as [T-1d],
                    s_dq_adjhigh as h, s_dq_adjlow as l, s_dq_adjclose as c, s_dq_amount as amt 
                    from wind_prod.dbo.ashareeodprices
                    where trade_dt >= '20140101' ''')

i_ohlc['T-1d'] = pd.to_datetime(i_ohlc['T-1d'], format = '%Y%m%d')
i_ohlc['Ticker'] = i_ohlc['ticker'].str[:6]
i_ohlc = i_ohlc[i_ohlc['ticker'].str.endswith('SH') | i_ohlc['ticker'].str.endswith('SZ')]
i_ohlc = i_ohlc.sort_values(['Ticker', 'T-1d'])
i_ohlc = i_ohlc.reset_index(drop = True)
i_ohlc = i_ohlc[['Ticker','T-1d','h','l','c','amt']]


cols_zigzag = ['zz_curr_trend','zz_curr_idx','zz_vertex_1','zz_vertex_idx1','zz_vertex_2','zz_vertex_idx2',
               'zz_vertex_3','zz_vertex_idx3','zz_vertex_4','zz_vertex_idx4','zz_vertex_5','zz_vertex_idx5',
               'zz_vertex_6','zz_vertex_idx6','zz_vertex_7','zz_vertex_idx7','zz_vertex_8','zz_vertex_idx8',
               'zz_vertex_9','zz_vertex_idx9','zz_vertex_10','zz_vertex_idx10',
               'zz_vertex_11','zz_vertex_idx11',
               'zz_vertex_12','zz_vertex_idx12',
               'zz_vertex_13','zz_vertex_idx13',
               'zz_vertex_14','zz_vertex_idx14',
               'zz_vertex_15','zz_vertex_idx15' ]


yu.tic()
i_ohlc[cols_zigzag] =\
   pd.DataFrame(i_ohlc.groupby('Ticker')[['c','h','l',]].\
   apply(lambda x: pd.DataFrame(yu.ta_zigzag15(x['c'].values, x['h'].values,x['l'].values, 60, 3))).values)
yu.toc()
             
       

i_ohlc = i_ohlc[i_ohlc['zz_curr_trend'].notnull()]
i_ohlc = i_ohlc[i_ohlc['zz_curr_trend']!=9]


# normalize prices w.r.t to the first vertex ever 

i_ohlc = i_ohlc.sort_values(['Ticker', 'T-1d'])
i_ohlc = i_ohlc.reset_index(drop = True)
i_ohlc_1st_vertex = i_ohlc.groupby('Ticker')['zz_vertex_1'].first().reset_index()
i_ohlc_1st_vertex = i_ohlc_1st_vertex.rename(columns = {'zz_vertex_1':'zz_vertex_hist1'})
i_ohlc = i_ohlc.merge(i_ohlc_1st_vertex, on = 'Ticker', how = 'left')

cols = ['zz_vertex_1
', 'zz_vertex_2', 'zz_vertex_3', 'zz_vertex_4', 'zz_vertex_5', 
        'zz_vertex_6', 'zz_vertex_7', 'zz_vertex_8', 'zz_vertex_9', 'zz_vertex_10',
        'zz_vertex_11', 'zz_vertex_12', 'zz_vertex_13', 'zz_vertex_14', 'zz_vertex_15']
for c in ['c', 'zz_vertex_1', 'zz_vertex_2', 'zz_vertex_3', 'zz_vertex_4', 'zz_vertex_5',
          'zz_vertex_6', 'zz_vertex_7', 'zz_vertex_8', 'zz_vertex_9', 'zz_vertex_10',
          'zz_vertex_11', 'zz_vertex_12', 'zz_vertex_13', 'zz_vertex_14', 'zz_vertex_15']:
    i_ohlc[c] = i_ohlc[c] / i_ohlc['zz_vertex_hist1']


# get future vertex and idx
    
i_zz_unique = i_ohlc[['Ticker', 'zz_vertex_1', 'zz_vertex_idx1', 'T-1d']].sort_values('T-1d').groupby(['Ticker', 'zz_vertex_1', 'zz_vertex_idx1']).first().reset_index()
i_zz_unique = i_zz_unique.sort_values(['Ticker', 'zz_vertex_idx1'])
i_zz_unique['zz_vertex_fut1'] = i_zz_unique.groupby('Ticker')['zz_vertex_1'].shift(-1)
i_zz_unique['zz_vertex_idx_fut1'] = i_zz_unique.groupby('Ticker')['zz_vertex_idx1'].shift(-1)
i_zz_unique['zz_date_fut1'] = i_zz_unique.groupby('Ticker')['T-1d'].shift(-1)
i_zz_unique = i_zz_unique.drop(columns = ['zz_vertex_1', 'T-1d'])

i_ohlc = i_ohlc.merge(i_zz_unique, on = ['Ticker', 'zz_vertex_idx1'], how = 'left')



# calc segment duration
# calculate future segment duration

i_ohlc['seg_len_curr'] = i_ohlc['zz_curr_idx'] - i_ohlc['zz_vertex_idx1']
i_ohlc['seg_len_idx1'] = i_ohlc['zz_vertex_idx1'] - i_ohlc['zz_vertex_idx2']
i_ohlc['seg_len_idx2'] = i_ohlc['zz_vertex_idx2'] - i_ohlc['zz_vertex_idx3']
i_ohlc['seg_len_idx3'] = i_ohlc['zz_vertex_idx3'] - i_ohlc['zz_vertex_idx4']
i_ohlc['seg_len_idx4'] = i_ohlc['zz_vertex_idx4'] - i_ohlc['zz_vertex_idx5']
i_ohlc['seg_len_idx5'] = i_ohlc['zz_vertex_idx5'] - i_ohlc['zz_vertex_idx6']
i_ohlc['seg_len_idx6'] = i_ohlc['zz_vertex_idx6'] - i_ohlc['zz_vertex_idx7']
i_ohlc['seg_len_idx7'] = i_ohlc['zz_vertex_idx7'] - i_ohlc['zz_vertex_idx8']
i_ohlc['seg_len_idx8'] = i_ohlc['zz_vertex_idx8'] - i_ohlc['zz_vertex_idx9']
i_ohlc['seg_len_idx9'] = i_ohlc['zz_vertex_idx9'] - i_ohlc['zz_vertex_idx10']

i_ohlc['seg_len_idx10'] = i_ohlc['zz_vertex_idx10'] - i_ohlc['zz_vertex_idx11']
i_ohlc['seg_len_idx11'] = i_ohlc['zz_vertex_idx11'] - i_ohlc['zz_vertex_idx12']
i_ohlc['seg_len_idx12'] = i_ohlc['zz_vertex_idx12'] - i_ohlc['zz_vertex_idx13']
i_ohlc['seg_len_idx13'] = i_ohlc['zz_vertex_idx13'] - i_ohlc['zz_vertex_idx14']
i_ohlc['seg_len_idx14'] = i_ohlc['zz_vertex_idx14'] - i_ohlc['zz_vertex_idx15']

i_ohlc['seg_len_idx1_fut1']
 = i_ohlc['zz_vertex_idx_fut1'] - i_ohlc['zz_vertex_idx1']

# calc segment height
# calc future segment height

i_ohlc['seg_hgt_curr'] = (i_ohlc['c'] - i_ohlc['zz_vertex_1']).abs()
i_ohlc['seg_hgt_idx1'] = (i_ohlc['zz_vertex_2'] - i_ohlc['zz_vertex_1']).abs()
i_ohlc['seg_hgt_idx2'] = (i_ohlc['zz_vertex_3'] - i_ohlc['zz_vertex_2']).abs()
i_ohlc['seg_hgt_idx3'] = (i_ohlc['zz_vertex_4'] - i_ohlc['zz_vertex_3']).abs()
i_ohlc['seg_hgt_idx4'] = (i_ohlc['zz_vertex_5'] - i_ohlc['zz_vertex_4']).abs()
i_ohlc['seg_hgt_idx5'] = (i_ohlc['zz_vertex_6'] - i_ohlc['zz_vertex_5']).abs()
i_ohlc['seg_hgt_idx6'] = (i_ohlc['zz_vertex_7'] - i_ohlc['zz_vertex_6']).abs()
i_ohlc['seg_hgt_idx7'] = (i_ohlc['zz_vertex_8'] - i_ohlc['zz_vertex_7']).abs()
i_ohlc['seg_hgt_idx8'] = (i_ohlc['zz_vertex_9'] - i_ohlc['zz_vertex_8']).abs()
i_ohlc['seg_hgt_idx9'] = (i_ohlc['zz_vertex_10'] - i_ohlc['zz_vertex_9']).abs()

i_ohlc['seg_hgt_idx10'] = (i_ohlc['zz_vertex_11'] - i_ohlc['zz_vertex_10']).abs()
i_ohlc['seg_hgt_idx11'] = (i_ohlc['zz_vertex_12'] - i_ohlc['zz_vertex_11']).abs()
i_ohlc['seg_hgt_idx12'] = (i_ohlc['zz_vertex_13'] - i_ohlc['zz_vertex_12']).abs()
i_ohlc['seg_hgt_idx13'] = (i_ohlc['zz_vertex_14'] - i_ohlc['zz_vertex_13']).abs()
i_ohlc['seg_hgt_idx14'] = (i_ohlc['zz_vertex_15'] - i_ohlc['zz_vertex_14']).abs()

i_ohlc['seg_hgt_idx1_fut1'] = (i_ohlc['zz_vertex_1'] - i_ohlc['zz_vertex_fut1']).abs()




# output

i_ohlc[['zz_vertex_1', 'zz_vertex_2', 'zz_vertex_3', 'zz_vertex_4', 'zz_vertex_5', 
        'zz_vertex_6', 'zz_vertex_7', 'zz_vertex_8', 'zz_vertex_9', 'zz_vertex_10',
        'zz_vertex_11','zz_vertex_12','zz_vertex_13','zz_vertex_14','zz_vertex_15',
        
        'seg_len_idx1', 'seg_len_idx2', 'seg_len_idx3', 'seg_len_idx4', 
        'seg_len_idx5', 'seg_len_idx6', 'seg_len_idx7', 'seg_len_idx8', 'seg_len_idx9',
        'seg_len_idx10', 'seg_len_idx11', 'seg_len_idx12', 'seg_len_idx13', 'seg_len_idx14',
        
        'seg_hgt_idx1', 'seg_hgt_idx2', 'seg_hgt_idx3', 'seg_hgt_idx4',
        'seg_hgt_idx5', 'seg_hgt_idx6', 'seg_hgt_idx7', 'seg_hgt_idx8', 'seg_hgt_idx9',
        'seg_hgt_idx10', 'seg_hgt_idx11', 'seg_hgt_idx12', 'seg_hgt_idx13', 'seg_hgt_idx14',        
        
        'c', 'seg_len_curr','zz_curr_trend','seg_hgt_curr', 
        'zz_date_fut1', 'seg_hgt_idx1_fut1','seg_len_idx1_fut1', 'zz_vertex_fut1',
        'Ticker', 'T-1d']].to_parquet(r'S:\TZ\tmp\pTA_cn_zigzag_featurepool7.parquet')
