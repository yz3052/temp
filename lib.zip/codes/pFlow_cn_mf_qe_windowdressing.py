﻿#$%^&* pFlow_cn_mf_qe_windowdressing.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 21 20:16:40 2023

@author: thzhang
"""



import pandas as pd
import numpy as np

import datetime
import util as yu
import os



# there is no window dressing alpha by late June. 


#---- sd 

i_sd = yu.get_sd_cn_1800()



#---- cal 

i_cal = yu.get_cn_cal()
i_cal = i_cal[['TradeDate_next']].sort_values('TradeDate_next').drop_duplicates()
i_cal = i_cal.rename(columns = {'TradeDate_next': 'DataDate'})
i_cal['T-1d'] = i_cal['DataDate'].shift()
i_cal = i_cal.dropna()
i_cal['june30th'] = pd.to_datetime(i_cal['DataDate'].dt.year.astype(str) + '-06-30')
i_cal['year'] = i_cal['DataDate'].dt.year

dates_to_query = i_cal.loc[i_cal['T-1d'].between('2017-01-01', '2021-12-31'), 'T-1d'].tolist()



#---- rawret

i_rawret = yu.get_sql('''select DataDate as [T-1d], Ticker, adjret_cny as rawret 
                      FROM [CNDBPROD].[dbo].[UNIVERSE_ALL_CN_GEM3L]  
                      order by Ticker, [T-1d]
                      ''')
i_rawret['T-1d'] = pd.to_datetime(i_rawret['T-1d'])

#--- fund type 


i_mf_style = yu.get_sql_wind('''select a.f_info_windcode, 
                        a.f_info_firstinvesttype, b.s_info_compcode 
                        from wind.dbo.ChinaMutualFundDescription a 
                        inner join wind.dbo.WindCustomCode b
                        on  a.f_info_windcode = b.s_info_windcode
                        ''')
i_mf_style = i_mf_style[i_mf_style['f_info_firstinvesttype'].isin(['混合型', '股票型'])]
i_mf_style = i_mf_style.dropna(subset = ['f_info_firstinvesttype'])

i_mf_style = i_mf_style.drop_duplicates(subset = ['s_info_compcode'], keep = 'first')
i_mf_style = i_mf_style[['s_info_compcode', 'f_info_firstinvesttype']]



#---- calc qualified trading dates (last week before end of June)

i_cal_june = i_cal[i_cal['DataDate']<=i_cal['june30th']]
i_cal_june = i_cal_june.sort_values(['year', 'DataDate'], ascending = True)
i_cal_june = i_cal_june.groupby('year').tail(11)
i_cal_june = i_cal_june.groupby('year').head(10)
i_cal_june = i_cal_june[i_cal_june['DataDate'].ge('2016-01-01')]

o_metrics = []

for dd in i_cal_june['DataDate'].tolist():
    print(dd.strftime('%Y%m%d'), end = ',')
    
    t1d = dd - pd.to_timedelta('1 day')
    t91d = dd - pd.to_timedelta('91 days')
    yyyy0331 = dd.strftime('%Y')+'0331'
    
    # get rawret
    
    t_rawret = i_rawret[i_rawret['T-1d'].between(t91d, t1d)]
    t_rawret = t_rawret.groupby
('Ticker')['rawret'].mean().reset_index()
    
    # get march top 10 pst
    
    i_march_pst = yu.get_sql_wind('''select a.s_info_stockwindcode as Ticker, a.s_info_windcode,
                             b.s_info_compcode, 
                             a.ann_date as [T-1d],
                             a.f_prt_stkvalue as h_dollar 
                             from wind_prod.dbo.ChinaMutualFundStockPortfolio a
                             left join wind_prod.dbo.windcustomcode b
                             on a.s_info_windcode = b.s_info_windcode 
                             where a.f_prt_enddate = '{0}'
                             '''.format(yyyy0331))
    i_march_pst = i_march_pst.drop_duplicates(subset = ['s_info_compcode','T-1d','Ticker'], keep = 'last')
    
    
    
    
    # select active equity funds
    
    i_march_pst_s2 = i_march_pst[i_march_pst['s_info_compcode'].isin(i_mf_style['s_info_compcode'].tolist())]
    
    # 
    
    i_march_pst_s3 = i_march_pst_s2.groupby('Ticker')['h_dollar'].sum().reset_index()
    i_march_pst_s3['Ticker'] = i_march_pst_s3['Ticker'].str[:6]
    
    i_march_pst_s3 = i_march_pst_s3.merge(t_rawret, on = 'Ticker', how = 'left')
    i_march_pst_s3['rawret_rk'] = yu.uniformed_rank(i_march_pst_s3['rawret'])
    i_march_pst_s3['h_dollar_rk'] = yu.uniformed_rank(i_march_pst_s3['h_dollar'])
    i_march_pst_s3['DataDate'] = dd
    
    
    o_metrics.append( i_march_pst_s3[['Ticker', 'DataDate', 'rawret_rk', 'h_dollar', 'h_dollar_rk']] )
        
        
o_metrics = pd.concat(o_metrics, axis = 0)
    



### combine

icom = i_sd.merge(o_metrics, on = ['Ticker', 'DataDate'], how = 'left')
icom = icom.sort_values(['Ticker', 'DataDate'])

icom['h_dollar_dv_pv'] = icom['h_dollar'] / icom['avgPVadj']
icom['h_dollar_dv_pv_bk'] = icom.groupby('DataDate')['h_dollar_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['h_dollar_bk'] = icom.groupby('DataDate')['h_dollar_rk'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['rawret_bk'] = icom.groupby('DataDate')['rawret_rk'].apply(lambda x: yu.pdqcut(x,bins=10)).values


c1 = icom['rawret_rk'].gt(0.8)
yu.create_cn_3x3_linux(icom[c1], ['h_dollar_dv_pv_bk'], 'h_dollar_dv_pv') # 
c1 = icom['rawret_rk'].lt(-0.8)
yu.create_cn_3x3_linux(icom[c1], ['h_dollar_dv_pv_bk'], 'h_dollar_dv_pv') # 


c1 = icom['h_dollar_dv_pv_bk'].ge(8)
yu.create_cn_3x3_linux(icom[c1], ['rawret_bk'], 'rawret_rk') # 



