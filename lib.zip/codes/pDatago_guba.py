﻿#$%^&* pDatago_guba.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  7 13:06:25 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw

import zipfile
import io

from yz.util import uniformed_rank, bt_cn, create_cn_3x3, get_sql



# get sd
i_sd = pw.get_china_sd()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d','avgPVadj','volatility','spread',
                 'BarrRet_CLIP+0d', 'BarrRet_CLIP+1d','BarrRet_SRISK+0d','BarrRet_SRISK+1d','RawRet+1d','fxRet_SRISK+1d',
                 'fxRet_CLIP+1d','isin_hk_uni']]
i_sd_map['ticker_int'] = i_sd_map['ticker'].str[:6].astype(int)


# get data

i15 = pd.read_csv(r"Z:\145825\DATA-7816\Retail_Investor_Sentiment\trial_20210406\guba\guba_natural_day_basic_stat_20150101to20151231.csv")
i16 = pd.read_csv(r"Z:\145825\DATA-7816\Retail_Investor_Sentiment\trial_20210406\guba\guba_natural_day_basic_stat_20160101to20161231.csv")
i17 = pd.read_csv(r"Z:\145825\DATA-7816\Retail_Investor_Sentiment\trial_20210406\guba\guba_natural_day_basic_stat_20170101to20171231.csv")
i18 = pd.read_csv(r"Z:\145825\DATA-7816\Retail_Investor_Sentiment\trial_20210406\guba\guba_natural_day_basic_stat_20180101to20181231.csv")
i19 = pd.read_csv(r"Z:\145825\DATA-7816\Retail_Investor_Sentiment\trial_20210406\guba\guba_natural_day_basic_stat_20190101to20191231.csv")

i_guba = pd.concat([i15, i16, i17, i18, i19], axis = 0)
i_guba['pub_date']  = pd.to_datetime(i_guba['pub_date'])
i_guba['datadate'] = i_guba['pub_date'] + pd.to_timedelta('1 day')
i_guba = i_guba.rename(columns = {'stock_id': 'ticker_int'})

i_guba.to_parquet(r'S:\Data\China Data Hunt\Datago\guba.parquet')
i_guba = pd.read_parquet(r'S:\Data\China Data Hunt\Datago\guba.parquet')

# Posts_Neg_AllUser_Sum  / Total number of negative posts sent by all users
# Reads_Neu_AllUser_Sum / Total read number of neutral posts sent by all users
# Replies_Neu_AllUser_Sum / Total reply number of neutral posts sent by all users
# Posts_Neu_AllUser_Sum / Total number of neutral posts sent by all users
# Reads_Pos_AllUser_Sum / Total read number of positive posts sent by all users
# Replies_Pos_AllUser_Sum / Total reply number of positive posts sent by all users
# Posts_Pos_AllUser_Sum / Total number of positive posts sent by all users
# Reads_All_AllUser_Sum / Total read number of all posts sent by all users
# Replies_All_AllUser_Sum / Total reply number of all posts sent by all users




# get o_c_ret

i_o_c_ret = pw.get_wind_mk
t_data(col_list = ['ticker', 'datadate', 'adjret_o_c'])
i_o_c_ret = i_o_c_ret.sort_values(['ticker', 'datadate'])
i_o_c_ret['adjret_o_c_l1d'] = i_o_c_ret.groupby('ticker')['adjret_o_c'].shift()
i_o_c_ret['adjret_o_c_bk'] = i_o_c_ret.groupby('datadate')['adjret_o_c'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values

i_o_c_ret['adjret_o_c_t5d'] = i_o_c_ret.groupby('ticker').rolling(5)['adjret_o_c'].sum().values
i_o_c_ret['adjret_o_c_t10d'] = i_o_c_ret.groupby('ticker').rolling(10)['adjret_o_c'].sum().values
i_o_c_ret['adjret_o_c_t20d'] = i_o_c_ret.groupby('ticker').rolling(20)['adjret_o_c'].sum().values
i_o_c_ret['adjret_o_c_t63d'] = i_o_c_ret.groupby('ticker').rolling(63)['adjret_o_c'].sum().values
i_o_c_ret = i_o_c_ret[i_o_c_ret['datadate']>='2013-04-11']
i_o_c_ret['adjret_o_c_t5d_bk'] = i_o_c_ret.groupby('datadate')['adjret_o_c_t5d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values
i_o_c_ret['adjret_o_c_t10d_bk'] = i_o_c_ret.groupby('datadate')['adjret_o_c_t10d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values
i_o_c_ret['adjret_o_c_t20d_bk'] = i_o_c_ret.groupby('datadate')['adjret_o_c_t20d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values
i_o_c_ret['adjret_o_c_t63d_bk'] = i_o_c_ret.groupby('datadate')['adjret_o_c_t63d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values


# get c_c_ret

i_c_c_ret = pw.get_wind_mkt_data(col_list = ['ticker', 'datadate', 'adjret'])
i_c_c_ret = i_c_c_ret.sort_values(['ticker', 'datadate'])
i_c_c_ret['adjret_l1d'] = i_c_c_ret.groupby('ticker')['adjret'].shift()
i_c_c_ret['adjret_bk'] = i_c_c_ret.groupby('datadate')['adjret'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values

i_c_c_ret['adjret_t5d'] = i_c_c_ret.groupby('ticker').rolling(5)['adjret'].sum().values
i_c_c_ret['adjret_t10d'] = i_c_c_ret.groupby('ticker').rolling(10)['adjret'].sum().values
i_c_c_ret['adjret_t20d'] = i_c_c_ret.groupby('ticker').rolling(20)['adjret'].sum().values
i_c_c_ret['adjret_t63d'] = i_c_c_ret.groupby('ticker').rolling(63)['adjret'].sum().values
i_c_c_ret = i_c_c_ret[i_c_c_ret['datadate']>='2014-04-11']
i_c_c_ret['adjret_t5d_bk'] = i_c_c_ret.groupby('datadate')['adjret_t5d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values
i_c_c_ret['adjret_t10d_bk'] = i_c_c_ret.groupby('datadate')['adjret_t10d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values
i_c_c_ret['adjret_t20d_bk'] = i_c_c_ret.groupby('datadate')['adjret_t
20d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values
i_c_c_ret['adjret_t63d_bk'] = i_c_c_ret.groupby('datadate')['adjret_t63d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values



# get 300 + 500 uni
i_mem = pw.get_index_membership()


# get limit up / down flags

i_updown = pw.get_wind_limit()

i_updown['datadate'] = pd.to_datetime(i_updown['datadate'], format= '%Y%m%d')

# macd

i_macd = get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                 MACD_MACD as macd 
                 from wind.dbo.AshareintensitytrendADJ''')
i_macd['datadate'] = pd.to_datetime(i_macd['datadate'], format='%Y%m%d')
i_macd = i_macd.sort_values(['ticker','datadate'])
i_macd['macd_l1d'] = i_macd.groupby('ticker')['macd'].shift(1)
i_macd['macd_l2d'] = i_macd.groupby('ticker')['macd'].shift(2)
i_macd['macd_l3d'] = i_macd.groupby('ticker')['macd'].shift(3)



# combine
icom = i_sd_map.merge(i_guba, on = ['ticker_int', 'datadate'], how = 'left')

icom = icom.merge(i_o_c_ret, on = ['ticker', 'datadate'], how = 'left')

icom = icom.merge(i_c_c_ret, on = ['ticker', 'datadate'], how = 'left')

icom = icom.merge(i_updown, on = ['ticker', 'datadate'], how = 'left')

icom = icom.merge(i_macd, on = ['ticker', 'datadate'], how = 'left')

icom = icom.merge(i_sd[['ticker','datadate','LIQUIDTY']],on=['ticker','datadate'],how='left')


#------------------------------------------------------------------------------
### Back test



#------------------------------------------------------------------------------
### number of posts from guba, also differentiate between T-1 o-c ret

col = 'posts_all_alluser_sum'

icom2 = icom.copy()
icom2 = icom2.merge(i_mem, on = ['datadate', 'ticker'], how = 'left')
icom2 = icom2.sort_values(['ticker', 'datadate'])

icom2[col] = icom2[col].replace(np.nan, 0)
icom2['cnt_t5d'] = icom2.groupby('ticker').rolling(5)[col].sum().values
icom2 = icom2[icom2['datadate']>='2014-01-01']
icom2['cnt_t5d_rk_bk'] = icom2.groupby('datadate')['cnt_t5d'].apply(lambda x: pd.cut(x.rank(), bins=10, labels = range(10))).values

icom2['adjret_o_c_t5d_bk'] = icom2.groupby(['datadate'])['adjret_o_c_t5d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values


# 5d cnt top bk, 5d o_c_ret top bk
icom2['sgnl'] = np.nan
icom2.loc[(icom2['cnt_t5d_rk_bk'] == 9) & (icom2['adjret_o_c_t5d_bk']==9), 'sgnl'] = -1
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_dupli
cates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 5.01 / 4.52 vs datayes 4.54 (4.02)


#------------------------------------------------------------------------------
### number of posts from guba, also differentiate between T-1 o-c ret, hk uni as a filter by the end

col = 'posts_all_alluser_sum'

icom2 = icom.copy()
icom2 = icom2.merge(i_mem, on = ['datadate', 'ticker'], how = 'left')
icom2 = icom2.sort_values(['ticker', 'datadate'])

icom2[col] = icom2[col].replace(np.nan, 0)
icom2['cnt_t5d'] = icom2.groupby('ticker').rolling(5)[col].sum().values
icom2 = icom2[icom2['datadate']>='2014-01-01']
icom2['cnt_t5d_rk_bk'] = icom2.groupby('datadate')['cnt_t5d'].apply(lambda x: pd.cut(x.rank(), bins=10, labels = range(10))).values

icom2['adjret_o_c_t5d_bk'] = icom2.groupby(['datadate'])['adjret_o_c_t5d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values


# 5d cnt top bk, 5d o_c_ret top bk
icom2['sgnl'] = np.nan
icom2.loc[(icom2['cnt_t5d_rk_bk'] == 9) & (icom2['adjret_o_c_t5d_bk']==9) , 'sgnl'] = -1
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')& (icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 2.82 / 2.39 vs full uni 5.01 / 4.52 


#------------------------------------------------------------------------------
### number of posts from guba, also differentiate between T-1 o-c ret, hk uni as a filter before ranking

col = 'posts_all_alluser_sum'

icom2 = icom.copy()
icom2 = icom2[icom2['isin_hk_uni']==1]
icom2 = icom2.merge(i_mem, on = ['datadate', 'ticker'], how = 'left')
icom2 = icom2.sort_values(['ticker', 'datadate'])

icom2[col] = icom2[col].replace(np.nan, 0)
icom2['cnt_t5d'] = icom2.groupby('ticker').rolling(5)[col].sum().values
icom2 = icom2[icom2['datadate']>='2014-01-01']
icom2['cnt_t5d_rk_bk'] = icom2.groupby('datadate')['cnt_t5d'].apply(lambda x: pd.cut(x.rank(), bins=10, labels = range(10))).values

icom2['adjret_o_c_t5d_bk'] = icom2.groupby(['datadate'])['adjret_o_c_t5d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values


# 5d cnt top bk, 5d o_c_ret top bk
icom2['sgnl'] = np.nan
icom2.loc[(icom2['cnt_t5d_rk_bk'] == 9) , 'sgnl'] = -1
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate
']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.8 / 0.57 vs full uni 5.01 / 4.52 



#------------------------------------------------------------------------------
### number of posts from guba, also differentiate between T-1 o-c ret

col = 'posts_all_alluser_sum'

icom2 = icom.copy()
icom2 = icom2.merge(i_mem, on = ['datadate', 'ticker'], how = 'left')
icom2 = icom2.sort_values(['ticker', 'datadate'])

icom2[col] = icom2[col].replace(np.nan, 0)
icom2['cnt_t5d'] = icom2.groupby('ticker').rolling(5)[col].sum().values
icom2 = icom2[icom2['datadate']>='2014-01-01']
icom2['cnt_t5d_rk_bk'] = icom2.groupby('datadate')['cnt_t5d'].apply(lambda x: pd.cut(x.rank(), bins=10, labels = range(10))).values

icom2['adjret_o_c_t5d_bk'] = icom2.groupby(['datadate'])['adjret_o_c_t5d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values


# 5d cnt top bk, 5d o_c_ret top bk
icom2['sgnl'] = np.nan
icom2.loc[(icom2['cnt_t5d_rk_bk'] == 9) & (icom2['adjret_o_c_t5d_bk']==9), 'sgnl'] = -1
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 5.01 / 4.52 vs datayes 4.54 (4.02)




#------------------------------------------------------------------------------
### number of positive posts from guba, also differentiate between T-1 o-c ret

col = 'posts_pos_alluser_sum'

icom2 = icom.copy()
icom2 = icom2.merge(i_mem, on = ['datadate', 'ticker'], how = 'left')
icom2 = icom2.sort_values(['ticker', 'datadate'])

icom2[col] = icom2[col].replace(np.nan, 0)
icom2['cnt_t5d'] = icom2.groupby('ticker').rolling(5)[col].sum().values
icom2 = icom2[icom2['datadate']>='2014-01-01']
icom2['cnt_t5d_rk_bk'] = icom2.groupby('datadate')['cnt_t5d'].apply(lambda x: pd.cut(x.rank(), bins=10, labels = range(10))).values

icom2['adjret_o_c_t5d_bk'] = icom2.groupby(['datadate'])['adjret_o_c_t5d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values


# 5d cnt top bk, 5d o_c_ret top bk
icom2['sgnl'] = np.nan
icom2.loc[(icom2['cnt_t5d_rk_bk'] == 9) & (icom2['adjret_o_c_t5d_bk']==9), 'sgnl'] = -1
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 5.08 / 4.57




#--------------
----------------------------------------------------------------
### number of negative posts from guba, also differentiate between T-1 o-c ret

col = 'posts_neg_alluser_sum'

icom2 = icom.copy()
icom2 = icom2.merge(i_mem, on = ['datadate', 'ticker'], how = 'left')
icom2 = icom2.sort_values(['ticker', 'datadate'])

icom2[col] = icom2[col].replace(np.nan, 0)
icom2['cnt_t5d'] = icom2.groupby('ticker').rolling(5)[col].sum().values
icom2 = icom2[icom2['datadate']>='2014-01-01']
icom2['cnt_t5d_rk_bk'] = icom2.groupby('datadate')['cnt_t5d'].apply(lambda x: pd.cut(x.rank(), bins=10, labels = range(10))).values

icom2['adjret_o_c_t5d_bk'] = icom2.groupby(['datadate'])['adjret_o_c_t5d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values


# 5d cnt top bk, 5d o_c_ret top bk
icom2['sgnl'] = np.nan
icom2.loc[(icom2['cnt_t5d_rk_bk'] == 9) & (icom2['adjret_o_c_t5d_bk']==9), 'sgnl'] = -1
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 5.06 / 4.55



#------------------------------------------------------------------------------
### number of reads from guba, also differentiate between T-1 o-c ret

col = 'reads_all_alluser_sum'

icom2 = icom.copy()
icom2 = icom2.merge(i_mem, on = ['datadate', 'ticker'], how = 'left')
icom2 = icom2.sort_values(['ticker', 'datadate'])

icom2[col] = icom2[col].replace(np.nan, 0)
icom2['cnt_t5d'] = icom2.groupby('ticker').rolling(5)[col].sum().values
icom2 = icom2[icom2['datadate']>='2014-01-01']
icom2['cnt_t5d_rk_bk'] = icom2.groupby('datadate')['cnt_t5d'].apply(lambda x: pd.cut(x.rank(), bins=10, labels = range(10))).values

icom2['adjret_o_c_t5d_bk'] = icom2.groupby(['datadate'])['adjret_o_c_t5d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values


# 5d cnt top bk, 5d o_c_ret top bk
icom2['sgnl'] = np.nan
icom2.loc[(icom2['cnt_t5d_rk_bk'] == 9) & (icom2['adjret_o_c_t5d_bk']==9), 'sgnl'] = -1
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 4.56 / 4.05

#------------------------------------------------------------------------------
### number of posts from guba (unregistered users), also differentiate between T-1 o-c ret

col = 'posts_a
ll_unregi_sum'

icom2 = icom.copy()
icom2 = icom2.merge(i_mem, on = ['datadate', 'ticker'], how = 'left')
icom2 = icom2.sort_values(['ticker', 'datadate'])

icom2[col] = icom2[col].replace(np.nan, 0)
icom2['cnt_t5d'] = icom2.groupby('ticker').rolling(5)[col].sum().values
icom2 = icom2[icom2['datadate']>='2014-01-01']
icom2['cnt_t5d_rk_bk'] = icom2.groupby('datadate')['cnt_t5d'].apply(lambda x: pd.cut(x.rank(), bins=10, labels = range(10))).values

icom2['adjret_o_c_t5d_bk'] = icom2.groupby(['datadate'])['adjret_o_c_t5d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values


# 5d cnt top bk, 5d o_c_ret top bk
icom2['sgnl'] = np.nan
icom2.loc[(icom2['cnt_t5d_rk_bk'] == 9) & (icom2['adjret_o_c_t5d_bk']==9), 'sgnl'] = -1
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 3.49



#------------------------------------------------------------------------------
### number of posts from guba (registered users), also differentiate between T-1 o-c ret

col = 'posts_all_regi_sum'

icom2 = icom.copy()
icom2 = icom2.merge(i_mem, on = ['datadate', 'ticker'], how = 'left')
icom2 = icom2.sort_values(['ticker', 'datadate'])

icom2[col] = icom2[col].replace(np.nan, 0)
icom2['cnt_t5d'] = icom2.groupby('ticker').rolling(5)[col].sum().values
icom2 = icom2[icom2['datadate']>='2014-01-01']
icom2['cnt_t5d_rk_bk'] = icom2.groupby('datadate')['cnt_t5d'].apply(lambda x: pd.cut(x.rank(), bins=10, labels = range(10))).values

icom2['adjret_o_c_t5d_bk'] = icom2.groupby(['datadate'])['adjret_o_c_t5d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values


# 5d cnt top bk, 5d o_c_ret top bk
icom2['sgnl'] = np.nan
icom2.loc[(icom2['cnt_t5d_rk_bk'] == 9) & (icom2['adjret_o_c_t5d_bk']==9), 'sgnl'] = -1
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 5.15 / 4.65




#------------------------------------------------------------------------------
### net number of positive posts from guba, also differentiate between T-1 o-c ret

icom2 = icom.copy()
icom2 = icom2.merge(i_mem, on = ['datadate', 'ticker'], how = 'left')
icom2 = icom2.sort_values(['ticker', 'datadate'])

icom2['net_pos'] = (icom2['po
sts_pos_alluser_sum'] - icom2['posts_neg_alluser_sum']).divide(icom2['posts_pos_alluser_sum'] + icom2['posts_neg_alluser_sum'])
icom2['net_pos'] = icom2['net_pos'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
icom2['cnt_t5d'] = icom2.groupby('ticker').rolling(5)['net_pos'].sum().values
icom2 = icom2[icom2['datadate']>='2015-02-01']
icom2 = icom2[icom2['datadate']<='2019-11-01']
icom2['cnt_t5d_rk_bk'] = icom2.groupby('datadate')['cnt_t5d'].apply(lambda x: pd.cut(x.rank(), bins=10, labels = range(10))).values

icom2['adjret_o_c_t5d_bk'] = icom2.groupby(['datadate'])['adjret_o_c_t5d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values


# 5d cnt top bk, 5d o_c_ret top bk
icom2['sgnl'] = np.nan
icom2.loc[(icom2['cnt_t5d_rk_bk'] == 9) & (icom2['adjret_o_c_t5d_bk']==9), 'sgnl'] = -1
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 3.71 / 2.98



#------------------------------------------------------------------------------
### top post count + top past performance, for HK uni


icom2 = icom.copy()
icom2 = icom2[icom2['isin_hk_uni']==1]

icom2 = icom2.sort_values(['ticker', 'datadate']).reset_index(drop=True)
icom2['GUBA_POST_NUM'] = icom2['posts_all_alluser_sum'].replace(np.nan, 0)
icom2['cnt_t5d'] = icom2.groupby('ticker').rolling(5)['GUBA_POST_NUM'].sum().values
icom2['cnt_t10d'] = icom2.groupby('ticker').rolling(10)['GUBA_POST_NUM'].sum().values
icom2['cnt_t20d'] = icom2.groupby('ticker').rolling(20)['GUBA_POST_NUM'].sum().values
icom2['cnt_t63d'] = icom2.groupby('ticker').rolling(63)['GUBA_POST_NUM'].sum().values

icom2 = icom2[(icom2['datadate']>='2015-03-11')&(icom2['datadate']<='2019-12-31')]

icom2['cnt_t5d_rk'] = icom2.groupby('datadate')['cnt_t5d'].apply(lambda x: uniformed_rank(x)).values
icom2['cnt_t5d_rk_bk'] = icom2.groupby('datadate')['cnt_t5d_rk'].apply(lambda x: pd.qcut(x, q=10, labels = range(10))).values
icom2['cnt_t5d_rk_20bk'] = icom2.groupby('datadate')['cnt_t5d_rk'].apply(lambda x: pd.qcut(x, q=20, labels = range(20))).values

icom2['cnt_t5d_indrk'] = icom2.groupby(['datadate','GSECTOR'])['cnt_t5d'].apply(lambda x: uniformed_rank(x)).values
icom2['cnt_t5d_indrk_bk'] = icom2.groupby(['datadate'])['cnt_t5d_indrk'].apply(lambda x: pd.cut(x, bins=10, labels = range(10))).values

icom2['cnt_t10d_rk'] = icom2.groupby('datadate')['cnt_t10d'
].apply(lambda x: uniformed_rank(x)).values
icom2['cnt_t10d_rk_bk'] = icom2.groupby('datadate')['cnt_t10d_rk'].apply(lambda x: pd.qcut(x, q=10, labels = range(10))).values
icom2['cnt_t10d_rk_20bk'] = icom2.groupby('datadate')['cnt_t10d_rk'].apply(lambda x: pd.qcut(x, q=20, labels = range(20))).values
icom2['cnt_t20d_rk'] = icom2.groupby('datadate')['cnt_t20d'].apply(lambda x: uniformed_rank(x)).values
icom2['cnt_t20d_rk_bk'] = icom2.groupby('datadate')['cnt_t20d_rk'].apply(lambda x: pd.qcut(x, q=10, labels = range(10))).values
icom2['cnt_t20d_rk_20bk'] = icom2.groupby('datadate')['cnt_t20d_rk'].apply(lambda x: pd.qcut(x, q=20, labels = range(20))).values

icom2['cnt_rk'] = icom2.groupby('datadate')['GUBA_POST_NUM'].apply(lambda x: uniformed_rank(x)).values
icom2['cnt_rk_bk'] = icom2.groupby('datadate')['cnt_rk'].apply(lambda x: pd.cut(x, bins=10, labels = range(10))).values

icom2['adjret_o_c_t5d_indbk'] = icom2.groupby(['datadate','GSECTOR'])['adjret_o_c_t5d'].apply(lambda x: pd.cut(x.rank(),bins=10,labels=range(10))).values
icom2['adjret_o_c_t5d_20bk'] = icom2.groupby(['datadate'])['adjret_o_c_t5d'].apply(lambda x: pd.cut(x.rank(),bins=20,labels=range(20))).values
icom2['adjret_o_c_t10d_20bk'] = icom2.groupby(['datadate'])['adjret_o_c_t10d'].apply(lambda x: pd.cut(x.rank(),bins=20,labels=range(20))).values
icom2['adjret_o_c_t20d_20bk'] = icom2.groupby(['datadate'])['adjret_o_c_t20d'].apply(lambda x: pd.cut(x.rank(),bins=20,labels=range(20))).values


# 5d cnt top bk, 5d o_c_ret top bk
icom2['sgnl'] = np.nan
icom2.loc[(icom2['cnt_t5d_rk_bk'] == 9) & (icom2['adjret_o_c_t5d_bk']==9), 'sgnl'] = -1
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 2.61 / 2.22 vs 2.71 / 2.32 datayes



# 5d + 10d + 20d cnt top bk, o_c_ret top bk
icom2['sgnl'] = np.nan
c5 = (icom2['cnt_t5d_rk_bk'] == 9) & (icom2['adjret_o_c_t5d_bk']==9)
c10 = (icom2['cnt_t10d_rk_bk'] == 9) & (icom2['adjret_o_c_t10d_bk']==9)
c20 = (icom2['cnt_t20d_rk_bk'] == 9) & (icom2['adjret_o_c_t20d_bk']==9)
icom2.loc[c5 | c10 | c20, 'sgnl'] = -1
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 2.42 / 2.1 vs 2.23 / 1.9 datayes



# 5d c
nt top bk, 5d o_c_ret texp form, only trade past return bk > 4 and post bk > 4
icom2['sgnl'] = np.nan
icom2.loc[icom2['cnt_t5d_rk_bk'] == 9, 'sgnl'] = -1
icom2['sgnl'] = icom2['sgnl'].multiply(np.exp((icom2['adjret_o_c_t5d_bk'].astype(int)-9)/5))

icom2.loc[(icom2['adjret_o_c_t5d_bk']<=4)|(icom2['cnt_t5d_rk_bk']<=4),'sgnl'] = np.nan
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 2.36/1.82 vs 2.71 / 2.32 top bk


