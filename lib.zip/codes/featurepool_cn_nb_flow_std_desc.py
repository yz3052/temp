﻿#$%^&* featurepool_cn_nb_flow_std_desc.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  7 12:40:29 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import os

import datetime

from sqlalchemy import create_engine
import urllib
import pyodbc


# to be scheduled on crontab at 5 am




#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------

save_path = '/export/dataprod/Feature_Pool_CN/featurepool_desc_nb_flow_std'

conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
conn_wind = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=WIND_PROD;UID=svc_wind_dbo;PWD=DusONA3Habredl;TDS_Version=8.0;')

today = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
today = pd.to_datetime(today.date())
today_str = today.strftime('%Y%m%d')




#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------

i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal['T-2d'] = i_cal['T-1d'].shift()
i_cal = i_cal.dropna()



#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------

dates_existing = os.listdir(save_path)
dates_existing = [i.replace('.parquet','').replace('.','') for i in dates_existing]

dates_avail = i_cal[i_cal['T-1d'].lt(today) & i_cal['T-1d'].ge('2017-01-01')]
dates_avail['yyyymmdd'] = dates_avail['T-1d'].dt.strftime('%Y%m%d')

dates_to_query = dates_avail[~dates_avail['yyyymmdd'].isin(dates_existing)]
dates_to_query = dates_to_query.sort_values('T-1d')

dates_to_query_min_1w_str = (dates_to_query['T-1d'].min()-pd.to_timedelta('7 days')).strftime('%Y%m%d')




#------------------------------------------------------------------------------
### get NB data
#---------------------------------------------------------------------------
---

i_hk_bb_dd = pd.read_sql('''select distinct s_holder_num, s_holder_enddate 
                        from [WIND_PROD].[dbo].[SHSCMECHANISMOWNERSHIP]
                        where 
                        s_holder_num in ('B01110', 'C00010', 'B01274', 'B01161', 'B01451', 'B01224') 
                        ''', conn_wind)
i_hk_bb_dd['s_holder_enddate'] = pd.to_datetime(i_hk_bb_dd['s_holder_enddate'], format = '%Y%m%d')

i_hk_bb = pd.read_sql('''select s_holder_num, s_holder_enddate,
                               s_info_windcode as ticker, S_HOLDER_QUANTITY as bb_shares
                        from [WIND_PROD].[dbo].[SHSCMECHANISMOWNERSHIP]
                        where 
                        s_holder_num in ('B01110', 'C00010', 'B01274', 'B01161', 'B01451', 'B01224') 
                        and s_info_windcode not like '%HK' 
                        and s_info_windcode not like '%OF'
                        and s_holder_enddate<'{0}'
                        and s_holder_enddate>='{1}'
                        '''.format(today_str, dates_to_query_min_1w_str), conn_wind)
i_hk_bb['Ticker'] = i_hk_bb['ticker'].str[:6]
i_hk_bb['s_holder_enddate'] = pd.to_datetime(i_hk_bb['s_holder_enddate'], format = '%Y%m%d')



#------------------------------------------------------------------------------
### metrics
#------------------------------------------------------------------------------

for i,r  in dates_to_query.iterrows():
    
    # get date string
    
    t_1d_str = r['T-1d'].strftime('%Y%m%d')
    
    # get universe and avgVadj
    
    i_dtk = pd.read_sql('''select datadate as [T-1d], ticker as Ticker
                        from cndbprod.dbo.universe_all_cn_gem3l 
                        with (nolock)
                        where datadate = '{0}' 
                        '''.format(t_1d_str), conn)
    i_dtk = i_dtk.drop_duplicates(subset = ['T-1d', 'Ticker'], keep = 'last')
        
    i_avgv = pd.read_sql('''select Ticker, avgVadj
                          from [CNDBPROD].[dbo].[universe_all_cn_gem3l]
                          where datadate = '{0}'
                          '''.format(t_1d_str), conn)
                          
    # calculate T-1d bb holding
    
    t_hk_bb_dd_1d = i_hk_bb_dd[i_hk_bb_dd['s_holder_enddate']<=r['T-1d']].groupby('s_holder_num')['s_holder_enddate'].max()
    t_hk_bb_dd_1d = t_hk_bb_dd_1d.reset_index()
    
    t_hk_bb_1d = i_hk_bb.merge(t_hk_bb_dd_1d, on = ['s_holder_num', 's_holder_enddate'], how = 'inner')
    t_
hk_bb_1d = t_hk_bb_1d.groupby(['Ticker', 's_holder_enddate'])['bb_shares'].sum().reset_index()
    t_hk_bb_1d = t_hk_bb_1d.rename(columns={'bb_shares':'bb_shares_1d'})
    t_hk_bb_1d = t_hk_bb_1d[['Ticker', 'bb_shares_1d']]
    
    # calculate T-2d bb holding 
    
    t_hk_bb_dd_2d = i_hk_bb_dd[i_hk_bb_dd['s_holder_enddate']<=r['T-2d']].groupby('s_holder_num')['s_holder_enddate'].max()
    t_hk_bb_dd_2d = t_hk_bb_dd_2d.reset_index()
    
    t_hk_bb_2d = i_hk_bb.merge(t_hk_bb_dd_2d, on = ['s_holder_num', 's_holder_enddate'], how = 'inner')
    t_hk_bb_2d = t_hk_bb_2d.groupby(['Ticker', 's_holder_enddate'])['bb_shares'].sum().reset_index()
    t_hk_bb_2d = t_hk_bb_2d.rename(columns={'bb_shares':'bb_shares_2d'})
    t_hk_bb_2d = t_hk_bb_2d[['Ticker', 'bb_shares_2d']]
    
    
    # calculate flow 
    
    t_hk_bb_1d2d = t_hk_bb_1d.merge(t_hk_bb_2d, on = 'Ticker', how = 'outer')
    t_hk_bb_1d2d = t_hk_bb_1d2d.fillna(0)
                  
    icom = i_dtk.merge(t_hk_bb_1d2d, on = ['Ticker'], how = 'left')
    icom = icom.merge(i_avgv, on = ['Ticker'], how = 'left')
    icom = icom.sort_values(['Ticker', 'T-1d'])    
    
    #---- note: if a ticker is not held by bb on -1d and -2d at all, we keep it nan here
    icom['nb_absflow_dv_v_abs'] = (icom['bb_shares_1d'] - icom['bb_shares_2d']).abs() / icom['avgVadj']  
    icom = icom.merge(i_cal, on = 'T-1d', how = 'left')
        
    file_name = r['T-1d'].strftime('%Y.%m.%d.parquet')
    icom[['T-1d', 'DataDate', 'Ticker', 'nb_absflow_dv_v_abs']].to_parquet(os.path.join(save_path, file_name))
    
    os.system("chgrp summit_thzhang "+os.path.join(save_path, file_name)+";")
    os.system("chmod 770 "+os.path.join(save_path, file_name)+";")
    
