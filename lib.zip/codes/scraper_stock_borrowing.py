﻿#$%^&* scraper_stock_borrowing.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 28 09:23:41 2021

@author: thzhang
"""

import pandas as pd
import requests

proxy_dict = {'http':'http://proxy.mlp.com:3128','https':'https://proxy.mlp.com:3128'} 


### Shanghai
for dt in pd.date_range(start = '2013-01-01', end = '2021-03-26'):
    d = dt.strftime('%Y%m%d')
    print(d,end=' ')
    
    url = 'http://www.sse.com.cn/market/dealingdata/overview/margin/a/rzrqjygk'+d+'.xls'

    try:
        r = requests.get(url, stream=True, proxies=proxy_dict)
        print('ok.')
    except:
        print('not available.')
        continue

    with open(r'S:\Data\China Data Hunt\stock_borrowing\rzrqjygk'+d+'.xls', 'wb') as f:
        for chunk in r:
            f.write(chunk)



### Shenzhen
for dt in pd.date_range(start = '2018-07-27', end = '2021-03-26'):
    d = dt.strftime('%Y-%m-%d')
    print(d,end=' ')
    
    url = 'http://www.szse.cn/api/report/ShowReport?SHOWTYPE=xlsx&CATALOGID=1834_xxpl&txtDate='+d+'&tab1PAGENO=1&random=0.820620309569152&TABKEY=tab1'

    try:
        r = requests.get(url, stream=True, proxies=proxy_dict)
        print('ok.')
    except:
        print('not available.')
        continue

    with open(r'S:\Data\China Data Hunt\stock_borrowing\shenzhen_'+d+'.xlsx', 'wb') as f:
        for chunk in r:
            f.write(chunk)


