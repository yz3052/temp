﻿#$%^&* pGraph_cn_ret_barra.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri May  6 09:29:00 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sklearn.linear_model import LinearRegression

# this studies correlation between barra returns



COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD',
       'RESVOL', 'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL',
       'AIRLINES', 'AUTOCOMP', 'BANKS', 'BIOTECH', 'CAPGOODS', 'CHEMICAL',
       'COMMSVCS', 'COMMUNIC', 'COMPUTER', 'CONSDUR', 'CONSTPP', 'CONSVCS',
       'DIVFINAN', 'DIVMETAL', 'ENERGY', 'FOODPRD', 'FOODRETL', 'HEALTH',
       'HSHLDPRD', 'INSURAN', 'INTERNET', 'MEDIA', 'OILEXPL', 'OILGAS',
       'PHARMAC', 'PRECMETL', 'REALEST', 'RETAIL', 'SEMICOND', 'SOFTWARE',
       'STEEL', 'TELECOM', 'TRANSPRT', 'UTILITY']

### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])


### get trading dates 

tdates = yu.get_sql("select distinct trade_dt as datadate from wind_prod.dbo.ashareeodprices where trade_dt >= '20160101' ")
tdates['datadate'] = pd.to_datetime(tdates['datadate'], format='%Y%m%d')
tdates = tdates.sort_values('datadate').reset_index(drop = True)

### Loop to get Barra and return data, the ncalculate resid return

resid_ret = []

for dt in tdates['datadate']: 
    print(dt.strftime('%Y%m%d')[2:], end = ' ')
    
    i_b = yu.get_sql('''select * FROM [CNDBPROD].[dbo].[BARRA_GEM3L_CN_FORMAT] 
                        where datadate = '{0}' '''.format( dt.strftime('%Y-%m-%d') ) )
    c_sh = i_b['Ticker'].str[0].isin(['6'])
    c_sz = i_b['Ticker'].str[0].isin(['0','3'])
    i_b.loc[c_sh, 'ticker'] = i_b.loc[c_sh, 'Ticker'] + '.SH'
    i_b.loc[c_sz, 'ticker'] = i_b.loc[c_sz, 'Ticker'] + '.SZ'
    i_b = i_b.drop(columns = ['Ticker'])
    i_b = i_b.rename(columns = {'DataDate':'datadate'})
    
    i_ret = yu.get_sql('''select s_info_windcode as ticker,  s_dq_tradestatus, s_dq_tradestatuscode,
                          s_dq_close/s_dq_preclose-1 as ret_c_c, s_dq_close/s_dq_open-1 ret_o_c
                          from wind_prod.dbo.ashareeodprices 
                          where trade_dt = '{0}' '''.format( dt.strftime('%Y%m%d') ))
    i_ret = i_ret[i_ret['s_dq_tradestatuscode']!=0]
    
    tcom = i_ret.merge(i_b, on = 'ticker', how = 'inner')
    if tcom.isnull().any(axis=1).sum() > 0:
        print (tcom.isnull().any(axis=1).sum())
    tcom = tcom.dropna(
)
    if len(tcom) == 0:
        continue
        
    regr = LinearRegression(fit_intercept=False).fit(tcom[COLS].values, tcom['ret_c_c'].values)
    tcom['bret_c_c'] = tcom['ret_c_c'] - regr.predict(tcom[COLS].values)
    
    regr2 = LinearRegression(fit_intercept=False).fit(tcom[COLS].values, tcom['ret_o_c'].values)
    tcom['bret_o_c'] = tcom['ret_o_c'] - regr2.predict(tcom[COLS].values)
    
    resid_ret.append(tcom[['ticker', 'datadate', 'bret_c_c', 'bret_o_c']])

resid_ret = pd.concat(resid_ret, axis = 0)

#resid_ret.to_parquet(r'S:\Data\China Data Hunt\cache\pGRAPH_cn_bret.parquet')
#resid_ret = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pGRAPH_cn_bret.parquet')



### calculate correlation matrix of bret 

o_corr_sum = []

for dt in resid_ret['datadate'].drop_duplicates():
    print (dt.strftime('%Y%m%d'), end = ' ')
    
    t_resid_ret = resid_ret[(resid_ret['datadate']<=dt) & (resid_ret['datadate']>=dt-pd.to_timedelta('91 days'))]
        
    t_bret_c_c_pv = t_resid_ret.pivot_table(index = 'datadate', columns = 'ticker', values = 'bret_c_c')
    t_corr_c_c = t_bret_c_c_pv.corr()
    t_corr_c_c.values[[np.arange(len(t_corr_c_c))]*2] = np.nan
    if len(t_corr_c_c) == 0:
        continue
    
    t_bret_o_c_pv = t_resid_ret.pivot_table(index = 'datadate', columns = 'ticker', values = 'bret_o_c')
    t_corr_o_c = t_bret_o_c_pv.corr()
    t_corr_o_c.values[[np.arange(len(t_corr_o_c))]*2] = np.nan
    if len(t_corr_o_c) == 0:
        continue
    
    t_corr_c_c_mean = t_corr_c_c.mean(axis = 1)
    t_corr_c_c_mean = t_corr_c_c_mean.reset_index().rename(columns={0: 'bret_c_c_corr_mean'})
    
    t_corr_o_c_mean = t_corr_o_c.mean(axis = 1)
    t_corr_o_c_mean = t_corr_o_c_mean.reset_index().rename(columns={0: 'bret_o_c_corr_mean'})
    
    t_corr_mean = t_corr_c_c_mean.merge(t_corr_o_c_mean, on = 'ticker', how = 'outer')
    t_corr_mean['datadate'] = dt
    o_corr_sum.append(t_corr_mean)

o_corr_sum = pd.concat(o_corr_sum, axis = 0)
o_corr_sum = o_corr_sum.sort_values('datadate')

o_corr_sum.to_parquet(r'S:\Data\China Data Hunt\cache\pGraph_cn_ret_2_o_bret_corr.parquet')



### combine

icom = pd.merge_asof(i_sd, o_corr_sum, by='ticker', on='datadate')
icom = icom.sort_values(['ticker','datadate'])

icom['bret_c_c_corr_mean_bk'] = icom.groupby('datadate')['bret_c_c_corr_mean'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['bret_o_c_corr_mean_bk'] = icom.groupby('datadate')['bret_o_c_corr_mean'].apply(lambda x: yu.pdqcut(x,bins=10)).value
s
icom['bret_o_c_corr_mean_rk'] = icom.groupby('datadate')['bret_o_c_corr_mean'].apply(yu.uniformed_rank).values


yu.create_cn_3x3(icom, ['bret_c_c_corr_mean_bk'], 'bret_c_c_corr_mean') # random
yu.create_cn_3x3(icom, ['bret_o_c_corr_mean_bk'], 'bret_o_c_corr_mean') # random

