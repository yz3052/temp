﻿#$%^&* scraper_nb_flow_ths.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 30 10:46:26 2023

@author: thzhang
"""

import pandas as pd

import requests

import time
from datetime import datetime



### prepare 

proxies = {'http':'http://svc_pm_summit_dev:Feng_001!@proxy.mlp.com:3128',
       'https':'https://svc_pm_summit_dev:Feng_001!@proxy.mlp.com:3128'}

header = {'Accept': 'application/json, text/plain, */*',
          'Accept-Encoding': 'gzip, deflate',
          'Accept-Language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
          'Cookie': 'v=A84oi_PhJk_c65JrInrA-4PFH6-VT5JhpBNGLfgXOlGMW2KRYN_iWXSjliXL',
          'hexin-v': 'A84oi_PhJk_c65JrInrA-4PFH6-VT5JhpBNGLfgXOlGMW2KRYN_iWXSjliXL',
          'Host': 'data.10jqka.com.cn',
          'Proxy-Connection': 'keep-alive',
          'Referer': 'http://data.10jqka.com.cn/hsgt/index',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'}

header2 = {'Access-Control-Allow-Origin': '*',
           'Age': '0',
           'Cache-Control': 'max-age=60',
           'Content-Encoding': 'gzip',
           'Content-Type': 'application/json; charset=utf-8',
           'Date': 'Tue, 30 May 2023 15:32:37 GMT',
           'Expires': 'Tue, 30 May 2023 15:33:37 GMT',
           'Last-Modified': 'Tue, 30 May 2023 15:32:31 GMT',
           'news': '10.201.65.16|127.0.0.1|',
           'pass': '205_129',
           'Server': 'openresty',
           'Vary': 'Accept-Encoding',
           'Via': '1.1 cachemd215220.10jqka.com.cn (squid/3.5.20), 1.1 cachedxwh3 (squid/3.5.20)',
           #'X-Cache': 'MISS from cachemd215220.10jqka.com.cn',
           'X-Cache': 'MISS from cachedxwh3}'}

now = pd.to_datetime(datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
filename = now.strftime('%Y%m%d.parquet')
ts = int(datetime.timestamp(datetime.now()) * 1000)

root = '/dat/summit_capital/PROD/TZ/hk_flow_intraday_10jqka/'



### NB data
# all the net_buy and net_flow data points are intraday cumulative
# the units are RMB
# net_buy = total buy $ - total sell $
# net_inflow = quota_balance - quota
# net_inflow = net_buy + net_unfilled_buy_orders


url_nb = 'http://data.10jqka.com.cn/dataapi/hk_stock_connect/moneyflow/north?_='+str(ts)
try:
    r = requests.get(url_nb, headers = header, proxies=proxies, verify = False)
except:
    try:
        time.sleep(60)
        r = requests.get(url_nb
, headers = header, proxies=proxies, verify = False)
    except:
        raise Exception('nb request failed')
try:
    i_dict = r.json()
except:
    raise Exception('nb json parse failed')
    
    

i_netbuy = pd.DataFrame(i_dict['data']['net_buy'])
i_netbuy['trade_dt'] = pd.to_datetime(i_dict['data']['update'])
i_netbuy['scraper_ts_cn'] = now
i_netbuy.to_parquet(root+'nb_net_buy/'+filename, allow_truncated_timestamps = True)


i_netinflow = pd.DataFrame(i_dict['data']['net_inflow'])
i_netinflow['trade_dt'] = pd.to_datetime(i_dict['data']['update'])
i_netinflow['scraper_ts_cn'] = now
i_netbuy.to_parquet(root+'nb_net_inflow/'+filename, allow_truncated_timestamps = True)




### sb data
# all the net_buy and net_flow data points are intraday cumulative
# the units are HKD
# net_buy = total buy $ - total sell $
# net_inflow = quota_balance - quota
# net_inflow = net_buy + net_unfilled_buy_orders


url_sb = 'http://data.10jqka.com.cn/hsgt/timedia/type/south/'
try:
    r2 = requests.get(url_sb, headers = header, proxies=proxies, verify = False)
except:
    try:
        time.sleep(60)
        r2 = requests.get(url_sb, proxies=proxies, verify = False)
    except:
        raise Exception('sb request failed')
try:
    i_dict2 = r2.json()
except:
    raise Exception('sb json parse failed')
    

i_netbuy = pd.DataFrame({'ts': i_dict2['data']['date_buy'], 'sh_buy': i_dict2['data']['h_buy'], 
                         'sz_buy': i_dict2['data']['s_buy'], 'total_buy': i_dict2['data']['total_buy'] })
i_netbuy['trade_dt'] = pd.to_datetime(i_dict2['data']['update'])
i_netbuy['scraper_ts_cn'] = now
i_netbuy.to_parquet(root+'sb_net_buy/'+filename, allow_truncated_timestamps = True)

i_netinflow = pd.DataFrame({'ts': i_dict2['data']['date'], 'sh_inflow': i_dict2['data']['h'], 
                            'sz_inflow': i_dict2['data']['s'], 'total_flow': i_dict2['data']['total'] })
i_netinflow['trade_dt'] = pd.to_datetime(i_dict2['data']['update'])
i_netinflow['scraper_ts_cn'] = now
i_netinflow.to_parquet(root+'sb_net_inflow/'+filename, allow_truncated_timestamps = True)

