﻿#$%^&* prodSSE_rzrq.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 20 14:05:06 2022

@author: thzhang
"""



import requests
import itertools

import pandas as pd
import os

import urllib
import time
import datetime

import pyodbc
from sqlalchemy import create_engine

# http://www.sse.com.cn/market/othersdata/margin/sum/
# In WIND, Shanghai's rzrq biaodi data is published at ~8 am T+0 if effective date is T+0.
# On SSE website, the only machine-readable data is daily rzrq stat summary. T-1 data is published at ~8 am T+1. T is tdate. 
# to be scheduled 0845 BJ





#---- get proxy  

proxies = {'http':'http://svc_pm_summit_dev:Feng_001!@proxy.mlp.com:3128',
           'https':'https://svc_pm_summit_dev:Feng_001!@proxy.mlp.com:3128'}



#---- now    
    
NOW = pd.to_datetime(datetime.datetime.today()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)



#---- get the latest trading date that is < today

conn = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=CNDBPROD;UID=svc_fg_dbo;PWD=1eDecejiqu39;TDS_Version=8.0;')

sql = '''
select max (TradeDate_next) as prev_tdate
from CNDBPROD.dbo.Calendar_Dates_CN
where TradeDate_next < '{0}'
'''.format(NOW.strftime('%Y%m%d'))
PREVTDATE = pd.read_sql(sql,conn)
PREVTDATE = PREVTDATE['prev_tdate'].dt.strftime('%Y%m%d').values[0]



#---- scrape

try:

    obj_proxy = urllib.request.ProxyHandler(proxies)
    opener = urllib.request.build_opener(obj_proxy)
    urllib.request.install_opener(opener)
    
    urllib.request.urlretrieve("http://www.sse.com.cn/market/dealingdata/overview/margin/a/rzrqjygk"+PREVTDATE+".xls", 
                               os.path.join('/export/datadev/Data/Scrapers/rzrq_sh','rzrqjygk'+PREVTDATE+'.xls'))
    
except urllib.error.HTTPError as err: 
    if err.msg == 'Not Found':
        raise Exception('File not found on SSE.')

except BaseException:
    
    time.sleep(10)
    
    obj_proxy = urllib.request.ProxyHandler(proxies)
    opener = urllib.request.build_opener(obj_proxy)
    urllib.request.install_opener(opener)
    
    urllib.request.urlretrieve("http://www.sse.com.cn/market/dealingdata/overview/margin/a/rzrqjygk"+PREVTDATE+".xls", 
                               os.path.join('/export/datadev/Data/Scrapers/rzrq_sh','rzrqjygk'+PREVTDATE+'.xls'))
    
    
    
#---- read file 

i_df = pd.read_excel("/export/datadev/Data/Scrapers/rzrq_sh/rzrqjygk"+PREVTDATE+".xls", sheet_name = '明细信息')
i_df = i_df.rename(col
umns = {'标的证券代码':'Ticker', 
                              '本日融资余额(元)':'benri_rongzi_yue_tmb', 
                              '本日融资买入额(元)':'benri_rongzi_mairue_rmb', 
                              '本日融资偿还额(元)':'benri_rongzi_changhuane_rmb', 
                              '本日融券余量':'benri_rongquan_yuliang', 
                              '本日融券卖出量':'benri_rongquan_maichuliang', 
                              '本日融券偿还量':'benri_rongquan_changhuanliang'})
i_df['Ticker']  =i_df['Ticker'].astype(int).astype(str).str.zfill(6)
i_df['T-1d'] = pd.to_datetime(PREVTDATE, format='%Y%m%d')
i_df['scraper_ts_cn'] = NOW
i_df = i_df[['Ticker', 'T-1d', 'scraper_ts_cn', 'benri_rongzi_yue_tmb', 'benri_rongzi_mairue_rmb',
             'benri_rongzi_changhuane_rmb', 'benri_rongquan_yuliang',
             'benri_rongquan_maichuliang', 'benri_rongquan_changhuanliang']]



#---- send to sql, if there is no duplicates

sql_max_tm1d = pd.read_sql('''select max([T-1d]) as max_tm1d from [CNDBDEV].dbo.sse_rzrq_stats''', conn)
sql_max_tm1d = sql_max_tm1d['max_tm1d'].dt.strftime('%Y%m%d').values[0]

if sql_max_tm1d < PREVTDATE:
    engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
    i_df.to_sql('sse_rzrq_stats', con=engine, if_exists = 'append', index = False)











#------------------------------------------------------------------------------
# create sql table
#------------------------------------------------------------------------------

# create table sse_rzrq_stats (Ticker varchar(20), [T-1d] datetime, scraper_ts_cn datetime, benri_rongzi_yue_tmb float, benri_rongzi_mairue_rmb float,
# benri_rongzi_changhuane_rmb float, benri_rongquan_yuliang float, benri_rongquan_maichuliang float, benri_rongquan_changhuanliang float)



#------------------------------------------------------------------------------
# bkfil
#------------------------------------------------------------------------------


# i_files = [i for i in os.listdir('/export/datadev/Data/Scrapers/rzrq_sh')]
# for i in i_files:
#     print (i, end=',')
#     i_df = pd.read_excel("/export/datadev/Data/Scrapers/rzrq_sh/"+i, sheet_name = '明细信息')
#     i_df = i_df.rename(columns = {'标的证券代码':'Ticker', 
#                                   '本日融资余额(元)':'benri_rongzi_yue_tmb', 
#                                   '本日融资买入额(元)':'benri_rongzi_mairue_rmb', 
#                     
              '本日融资偿还额(元)':'benri_rongzi_changhuane_rmb', 
#                                   '本日融券余量':'benri_rongquan_yuliang', 
#                                   '本日融券卖出量':'benri_rongquan_maichuliang', 
#                                   '本日融券偿还量':'benri_rongquan_changhuanliang'})
#     i_df['Ticker']  =i_df['Ticker'].astype(int).astype(str).str.zfill(6)
#     i_df['T-1d'] = pd.to_datetime(i.replace('.xls','').replace('rzrqjygk',''), format='%Y%m%d')
#     i_df['scraper_ts_cn'] = NOW
#     i_df = i_df[['Ticker', 'T-1d', 'scraper_ts_cn', 'benri_rongzi_yue_tmb', 'benri_rongzi_mairue_rmb',
#                  'benri_rongzi_changhuane_rmb', 'benri_rongquan_yuliang',
#                  'benri_rongquan_maichuliang', 'benri_rongquan_changhuanliang']]
    
#     engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
#     i_df.to_sql('sse_rzrq_stats', con=engine, if_exists = 'append', index = False)
#     i_df = None

