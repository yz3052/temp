﻿#$%^&* prod_process_wind_concept.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 15 06:42:58 2022

@author: thzhang
"""



import pandas as pd

import pyodbc

import datetime
import os



#==============================================================================
#   
#==============================================================================

conn_wind = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=WIND_PROD;UID=svc_wind_dbo;PWD=DusONA3Habredl;TDS_Version=8.0;')





#==============================================================================
#   
#==============================================================================

TS = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)


i_tk_cpt = pd.read_sql('''select s_info_windcode as ticker, wind_sec_code 
                          from wind_prod.dbo.[ASHARECONSEPTION] 
                          where cur_sign = 1 
                          order by wind_sec_code''', conn_wind)
i_tk_cpt['ts_cn'] = TS
i_tk_cpt.to_parquet(os.path.join('/dat/summit_capital/PROD/TZ/wind_concept', TS.strftime('%Y%m%d')+'.parquet'), allow_truncated_timestamps = True)

                          
i_cpt_name = pd.read_sql('''select distinct wind_sec_code, wind_sec_name
                            from wind_prod.dbo.[ASHARECONSEPTION] 
                            where cur_sign = 1 ''', conn_wind)
i_cpt_name['ts_cn'] = TS
i_cpt_name.to_parquet(os.path.join('/dat/summit_capital/PROD/TZ/wind_concept', TS.strftime('%Y%m%d')+'_map.parquet'), allow_truncated_timestamps = True)




