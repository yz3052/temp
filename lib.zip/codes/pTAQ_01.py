﻿#$%^&* pTAQ_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 28 11:40:28 2020

@author: thzhang
"""

import gzip 
import io

import pandas as pd
import dask.dataframe as dd


from yz import tic, toc, get_sql

# this script is used to scan thru TAQ's file for inspection + quality check purposes


#------------------------------------------------------------------------------
# Dask

tic()
dd_data = dd.read_csv(r"Z:\US-TAQ\v4\EQY_US_ALL_NBBO\2016\09\23\EQY_US_ALL_NBBO_20160923.gz", 
                   sep = '|', lineterminator = "\n",  header = 0, compression = 'gzip',
                   usecols = ['Time', 'Exchange', 'Symbol', 'Best_Bid_Price', 'Best_Offer_Price'],
                   dtype={'Time': 'object'})


#DataDate, Time, Hour, Min, Ticker, bid (which is the last best bid), ask ( which is the last best ask)

dd_data3 = dd_data.compute()
toc() #326s


#------------------------------------------------------------------------------
# Pandas

tic()
i_data = pd.read_csv(gzip.open(r"Z:\US-TAQ\v4\EQY_US_ALL_NBBO\2016\09\30\EQY_US_ALL_NBBO_20160930.gz", 'rb'), 
                     sep = '|', lineterminator="\n", header=0, 
                     usecols = ['Time', 'Symbol', 'Best_Bid_Price', 'Best_Offer_Price'],
                     dtype={'Time': 'object'})
toc() #247s

tic()
i_data['hour'] = i_data['Time'].str[:2]
i_data['minute'] = i_data['Time'].str[2:4]
toc() #60s, qa ok

tic()
i_data2 = i_data.drop_duplicates(subset = ['Symbol', 'hour', 'minute'], keep = 'last')
toc() #30s

tic()
i_data2['DataDate'] = pd.to_datetime('2016-09-30')
i_data2 = i_data2.rename(columns={'Symbol':'Ticker','hour':'Hour','minute':'Minute','Best_Bid_Price':'bid','Best_Offer_Price':'ask'})
toc() #0s

tt1 = pd.read_csv(r"S:\Data\TAQ\bidask_1min_20161227.txt", sep = '|', header = None)
tt1_h1 = tt1.head(100)
i_data_h1 = i_data2.head(100)


t1 = i_data2[i_data2.Ticker=='199303627']
i_data2[i_data2.Ticker=='A'].to_csv(r'S:\Infrastructure\q\taq_example_a.csv')

#------------------------------------------------------------------------------
# v3 full sample

import os
import zipfile

# walk thru all folders
o1 = [] #path, yyyymmdd, size, str
for root, dirs, files in os.walk(r'Z:\US-TAQ\v3\2011'):
    for f in files:
        if ('taqnbbo2010' in f) or ('taqnbbo2011' in f) or ('taqnbbo2012' in f):
            print (f.split('.')[0][-6:], end = ',')
        else:
            continue
        if ('taqnbbo' in f) and f.endswith('.zip') and (not f.endswith('.new.zip')):
            f
_path = os.path.join(root, f)
            f_date = f.split('.')[0][-8:]
            #if os.path.getsize(f_path) > 10240:
            zf = zipfile.ZipFile(f_path)
            if len(zf.namelist())!=1:
                raise Exception('more than one files in zip.')
            else:
                data_name = zf.namelist()[0]
            df = pd.read_csv(zf.open(data_name), nrows = 2, header = None)
            df_len = len(df.loc[1].iloc[0])
            o1.append([f_path, data_name,f_date, os.path.getsize(f_path), df.loc[1].iloc[0]])
o1 = pd.DataFrame(o1, columns = ['path', 'file','date', 'size', 'data'])
o1['data_len'] = o1['data'].str.len()
o1 = o1.sort_values('date')
o1.to_parquet(r'S:\Data\TAQ\daily_data_sample2011.parquet')


a = open(r"S:\Data\TAQ\110711.csv\taqnbbo20110711").read(10000)


zf = zipfile.ZipFile(r'Z:\US-TAQ\v3\2015\07\24\taqnbbo20150724.zip')
df = pd.read_csv(zf.open('taqnbbo20150724'), nrows = 10, header = 0)

df.iloc[9,0][90:125]
df.iloc[9,0][91:102] #!
df.iloc[9,0][117:128] #!

zf = zipfile.ZipFile(r'Z:\US-TAQ\v3\2015\11\10\taqnbbo20151110.zip')
df = pd.read_csv(zf.open('taqnbbo20151110'), nrows = 10, header = 0)

df.iloc[9,0][90:120]
df.iloc[9,0][94:105] #!
df.iloc[9,0][119:141]
df.iloc[9,0][120:131] #!


#------------------------------------------------------------------------------
# v4 full sample

import os
import zipfile

# walk thru all folders
o2 = [] #path, yyyymmdd, size, str
for root, dirs, files in os.walk(r'Z:\US-TAQ\v4\EQY_US_ALL_NBBO'):
    for f in files:
        print (f.split('.')[0][-6:], end = ',')
        if ('EQY_US_ALL_NBBO' in f) and f.endswith('.gz'):
            f_path = os.path.join(root, f)
            f_date = f.split('.')[0][-8:]
            if os.path.getsize(f_path) > 10240:
                df = pd.read_csv(gzip.open(f_path, 'rb'), nrows = 2, header = None)
                df_len = len(df.loc[1].iloc[0])
                o2.append([f_path, f_date, os.path.getsize(f_path), df.loc[0].iloc[0]])
            else:
                raise Exception('file size small')
        elif ('EQY_US_ALL_NBBO' in f) and ('.gz' in f) and (f[-1]).isnumeric(): 
            pass
        else:
            raise Exception('check file format')
            
o2 = pd.DataFrame(o2, columns = ['path','date', 'size', 'data'])
o2 = o2.sort_values('date')
o2['data_len'] = o2['data'].str.len()
o2['data_same'] = o2['data'] == o2['data'].shift()

o2['path_same'] = o2['path'].str.split('\\').str[4]+o2['path'].str.split('\\').str[5]+o2['path'
].str.split('\\').str[6] == o2['date']

o2
o2.to_parquet(r'S:\Data\TAQ\daily_data_sample_v4.parquet')





zf = zipfile.ZipFile(r'Z:\US-TAQ\v3\2015\07\24\taqnbbo20150724.zip')
df = pd.read_csv(zf.open('taqnbbo20150724'), nrows = 10, header = 0)

df.iloc[9,0][90:125]
df.iloc[9,0][91:102] #!
df.iloc[9,0][117:128] #!

zf = zipfile.ZipFile(r'Z:\US-TAQ\v3\2015\11\10\taqnbbo20151110.zip')
df = pd.read_csv(zf.open('taqnbbo20151110'), nrows = 10, header = 0)

df.iloc[9,0][90:120]
df.iloc[9,0][94:105] #!
df.iloc[9,0][119:141]
df.iloc[9,0][120:131] #!

