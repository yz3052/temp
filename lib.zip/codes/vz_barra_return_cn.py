﻿#$%^&* vz_barra_return_cn.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Sep  1 10:58:05 2020

@author: thzhang
"""

import pandas as pd
import numpy as np

import random

from yz import get_sql

from bokeh.io import show
from bokeh.layouts import column, gridplot
from bokeh.models import ColumnDataSource, RangeTool, HoverTool, CustomJS, CrosshairTool, LinearAxis, Range1d
from bokeh.plotting import figure


###############################################################################
# Param
###############################################################################

TICKER = '000058' # a real ticker or "random"
RET_TYPE = 'bret' #'hret', 'bret' 

###############################################################################
# Get data
###############################################################################

# ticker
if TICKER == 'random':
    t_tk_list = get_sql("select ticker FROM [BackTest].[dbo].[BARRA_CNE5L_RRET_HC] group by ticker having count(ticker)>200")
    TICKER = random.choice(t_tk_list.ticker.tolist())
    print(TICKER)

# get ret from static data
if RET_TYPE == 'rret':
    RET_TYPE2 = '[RawRet_CNY]'
elif RET_TYPE == 'bret':
    RET_TYPE2 = '[BarrRet_CLIP_USD]'
else:
    raise Exception('ret_type input error.')    
i_sd = get_sql('''select ticker, datadate, {0} as {1} FROM [CNDBPROD].[dbo].[BARRA_CNE5L_RRET_HC]  
                where ticker = '{2}' order by datadate '''.format(RET_TYPE2, RET_TYPE, TICKER) )

# calc pid
i_sd['p_index'] = (i_sd[RET_TYPE]+1).cumprod()


# get price from wind
i_wind = get_sql('''select s_info_windcode as ticker, trade_dt as datadate, 
                   s_dq_adjopen as o, s_dq_adjhigh as h, s_dq_adjlow as l, s_dq_adjclose as c 
                from [wind_prod].[dbo].[ashareeodprices] 
                where s_info_windcode like '{0}%' and trade_dt >= '{1}' and trade_dt <= '{2}' 
                order by trade_dt '''.\
                format(TICKER, i_sd.datadate.min().strftime('%Y-%m-%d'), i_sd.datadate.max().strftime('%Y-%m-%d')) )
i_wind['datadate'] = pd.to_datetime(i_wind['datadate'], format = '%Y%m%d')
i_wind['ticker'] = i_wind['ticker'].str[:6]

# merge bbg and static data
i_data = i_wind.merge(i_sd, on = ['ticker','datadate'], how = 'left')

###############################################################################
# Viz
###############################################################################

# Main chart: bret/ hret and technical indicators

p_main = figure(plot_height=400,
 plot_width=1600, tools="pan,wheel_zoom,reset", toolbar_location='right',
           x_axis_type="datetime", x_axis_location="below", title = TICKER,
           background_fill_color="#ffffff",x_range=(i_data.datadate.min(), i_data.datadate.max()))
p_main.xaxis.major_label_orientation = 3.1415/4
p_main_p_index = ColumnDataSource(data=dict(date=i_data['datadate'], p_index = i_data.set_index('datadate')['p_index'] ))
p_main.circle('date', 'p_index', source=p_main_p_index, fill_color = 'indigo', size = 4)
p_main.yaxis.axis_label = RET_TYPE
p_main.xaxis[0].ticker.desired_num_ticks = 40


# main chart: boll        

o_boll_u = i_data['p_index'].ewm(span=90, ignore_na = True).mean() + 2 * i_data['p_index'].rolling(90,min_periods=20).std()
o_boll_l = i_data['p_index'].ewm(span=90, ignore_na = True).mean() - 2 * i_data['p_index'].rolling(90,min_periods=20).std()

boll_u = ColumnDataSource(data=dict(date=i_data['datadate'], bollu=o_boll_u))
p_main.line('date', 'bollu', source=boll_u, line_color = 'coral', line_width = 0.8, line_alpha = 0.7)

boll_l = ColumnDataSource(data=dict(date=i_data['datadate'], bolll=o_boll_l))
p_main.line('date', 'bolll', source=boll_l, line_color = 'coral', line_width = 0.8, line_alpha = 0.7)

# main chart: ema
o_ema = i_data['p_index'].ewm(span=90, ignore_na = True).mean()
ema = ColumnDataSource(data=dict(date=i_data['datadate'], ema=o_ema))
p_main.line('date', 'ema', source=ema, line_color = 'green', line_width = 0.8, line_alpha = 0.7)

# main chart: mouse hovering tool
p_main.add_tools(HoverTool(tooltips=[('date','@date{%F}'),('p_index','@{p_index}{0.3f}')],formatters ={'date':'datetime'}))

# second chart: OHLC

cond_yang = i_data.c >= i_data.o
cond_yin = i_data.o > i_data.c

p_2 = figure(x_axis_type="datetime", tools="pan,wheel_zoom,box_zoom,reset", plot_width=1600, plot_height = 250,
             x_range = p_main.x_range)
p_2.xaxis.major_label_orientation = 3.1415/4
p_2.grid.grid_line_alpha=0.3
p_2.xaxis[0].ticker.desired_num_ticks = 40

p_2.segment(i_data.datadate, i_data.h, i_data.datadate, i_data.l, color="black")
p_2.vbar(i_data.datadate[cond_yang], 12*60*60*1000, i_data.o[cond_yang], i_data.c[cond_yang], fill_color="green", line_color="green")
p_2.vbar(i_data.datadate[cond_yin], 12*60*60*1000, i_data.o[cond_yin], i_data.c[cond_yin], fill_color="#F2583E", line_color="#F2583E")
         
p_2.add_tools(HoverTool(tooltips=[('date','@datadate{%F}'),('top','@{top}{0.3f}'),('bottom','@{bottom}{0.3f}')],
                                
  formatters ={'date':'datetime'}))

# second chart: ema 
o_ema2 = i_data['c'].ewm(span=40, ignore_na = True).mean()
ema2 = ColumnDataSource(data=dict(date=i_data['datadate'], ema=o_ema2))
p_2.line('date', 'ema', source=ema2, line_color = 'orange', line_width = 0.8, line_alpha = 0.7)

# slider
slider = figure(plot_height=40, plot_width=1600, #y_range=p_main.y_range,
                x_axis_type="datetime", y_axis_type=None,
                tools="", toolbar_location=None, background_fill_color="#efefef")        
slider_range_tool = RangeTool(x_range=p_main.x_range)
slider_range_tool.overlay.fill_color = "navy"
slider_range_tool.overlay.fill_alpha = 0.2
slider_c = ColumnDataSource(data=dict(date=i_data.datadate, slider_c=i_data.c))
slider.line('date', 'slider_c', source=slider_c, line_color = 'blue', line_width = 1)
slider.ygrid.grid_line_color = None
slider.add_tools(slider_range_tool)
slider.toolbar.active_multi = slider_range_tool
slider.axis.visible = False



show(gridplot([[p_main],[p_2], [slider]]))
