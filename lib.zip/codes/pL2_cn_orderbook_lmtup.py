﻿#$%^&* pL2_cn_orderbook_lmtup.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  6 13:56:21 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine



### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])


### prepare limit-up prices

#i_lmtupp = yu.get_sql('''select substring(s_info_windcode,1,6) as code, 
#                               cast(trade_dt as date) as date,
#                               s_dq_limit as lmtup 
#                        from  wind_prod.dbo.ASHAREEODPRICES
#                        where trade_dt >= '20130101' ''')
#i_lmtupp.to_csv(r'S:\Data\China Data Hunt\cache\ashare_lmtup_prices.csv', index = False)



### get lmtup metrics

i_lmtup = yu.get_q("get `:/export/datadev/Data/SHSZ/ORDER_metrics/orderbook_metrics_batch1_05")

i_lmtup['code'] = i_lmtup['code'].str.decode('utf8')
c_sh = i_lmtup['code'].str[0].isin(['6'])
c_sz = i_lmtup['code'].str[0].isin(['0','3'])
i_lmtup.loc[c_sh, 'ticker'] = i_lmtup.loc[c_sh, 'code'] + '.SH'
i_lmtup.loc[c_sz, 'ticker'] = i_lmtup.loc[c_sz, 'code'] + '.SZ'
i_lmtup['datadate'] = pd.to_datetime(i_lmtup['date'])
i_lmtup = i_lmtup.sort_values(['ticker', 'datadate'])




### get rzrq data

o_rzrq = pd.read_parquet(r'S:\Data\China Data Hunt\cache\cninfo_rzrq.parquet')
o_rzrq['datadate'] = pd.to_datetime(o_rzrq['datadate'])
o_rzrq = o_rzrq.drop(columns = ['SECNAME','MEMO'])


### combine

icom = i_sd.merge(i_lmtup, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(o_rzrq, on = ['ticker', 'datadate'], how = 'left')
icom['p'] = icom['PV_l1d'].divide(icom['V_l1d'])
icom['rq_v'] = icom['F008N'].divide(icom['p'])

icom = icom.sort_values(['ticker', 'datadate'])
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']



### 9:16

icom['v1_0916_dv_so'] = icom['ask_1st_maxp_v_0916'].divide(icom['FLOAT_l1d'])
icom['v1_0916_dv_so_bk'] = icom.groupby('datadate')['v1_0916_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['v1_0916_dv_so_orth'] = icom.groupby('datadate')[COLS+['v1_0916_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['v1_0916_dv_so'], x[COLS])).values
icom['v1_0916_dv_so_orth_bk'] = icom.groupby('datadate')['v1_0916_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['v1_0916_dv_so_orth_sgnl'] = - icom.groupby('datadate')['v1_0916_dv_so_orth'].apply(yu.uniformed
_rank).values
icom['v1_0916_dv_so_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=20),on='datadate')['v1_0916_dv_so_orth'].mean().values
icom['v1_0916_dv_so_orth_t20d_sgnl'] = -icom.groupby('datadate')['v1_0916_dv_so_orth_t20d'].apply(yu.uniformed_rank).values

icom['v2_0916_dv_so'] = (icom['ask_1st_maxp_v_0916']+icom['ask_2nd_maxp_v_0916']).divide(icom['FLOAT_l1d'])
icom['v2_0916_dv_so_orth'] = icom.groupby('datadate')[COLS+['v2_0916_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['v2_0916_dv_so'], x[COLS])).values
icom['v2_0916_dv_so_orth_bk'] = icom.groupby('datadate')['v2_0916_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['v1_0916_dv_so_bk'], 'v1_0916_dv_so') # mono +1 +2 -5
yu.create_cn_3x3(icom, ['v1_0916_dv_so_orth_bk'], 'v1_0916_dv_so_orth') # mono: +3 -6
yu.create_cn_3x3(icom, ['v2_0916_dv_so_orth_bk'], 'v2_0916_dv_so_orth') # mono: +3 -6


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['v1_0916_dv_so_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v1_0916_dv_so_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.55/-8.95
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['v1_0916_dv_so_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v1_0916_dv_so_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.5/1.3
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['v1_0916_dv_so_orth_t20d_sgnl']>0)].\
            dropna(subset=['v1_0916_dv_so_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v1_0916_dv_so_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.87/0.66




### 9:31 

icom['v1_0931_dv_so'] = icom['ask_1st_maxp_v_0931'].divide(icom['FLOAT_l1d'])
icom['v1_0931_dv_so_bk'] = icom.groupby('datadate')['v1_0931_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['v1_0931_dv_so_orth'] = icom.groupby('datadate')[COLS+['v1_0931_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['v1_0931_dv_so'], x[COLS])).values
icom['v1_0931_dv_so_orth_bk'] = icom.groupby('datadate')['v1_0931_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['v1_091631_dv_so'] = (icom['ask_1st_maxp_v_0931']-icom['ask_1st_maxp_v_0916']).divide(icom['FLOAT_l1d'])
icom['v1_091631_dv_so_bk'] = icom.groupby('datadate')['v1_091631_dv_so'].apply(lambda x: yu.pdqcut(
x,bins=10)).values

yu.create_cn_3x3(icom, ['v1_0931_dv_so_bk'], 'v1_0931_dv_so') # less mono: +2 +2 -6
yu.create_cn_3x3(icom, ['v1_0931_dv_so_orth_bk'], 'v1_0931_dv_so_orth') # mono: +2 -8
yu.create_cn_3x3(icom, ['v1_091631_dv_so_bk'], 'v1_091631_dv_so') # mono: +2 -6


### 14:55


icom['v1_1455_dv_so'] = icom['ask_1st_maxp_v_1455'].divide(icom['FLOAT_l1d'])
icom['v1_1455_dv_so_bk'] = icom.groupby('datadate')['v1_1455_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['v1_1455_dv_so_orth'] = icom.groupby('datadate')[COLS+['v1_1455_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['v1_1455_dv_so'], x[COLS])).values
icom['v1_1455_dv_so_orth_bk'] = icom.groupby('datadate')['v1_1455_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['v1_1455_dv_so_orth_sgnl'] = - icom.groupby('datadate')['v1_1455_dv_so_orth'].apply(yu.uniformed_rank).values
icom['v1_1455_dv_so_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=20),on='datadate')['v1_1455_dv_so_orth'].mean().values
icom['v1_1455_dv_so_orth_t20d_sgnl'] = -icom.groupby('datadate')['v1_1455_dv_so_orth_t20d'].apply(yu.uniformed_rank).values

icom['v1_09161455_dv_so'] = (icom['ask_1st_maxp_v_1455']-icom['ask_1st_maxp_v_0916']).divide(icom['FLOAT_l1d'])
icom['v1_09161455_dv_so_bk'] = icom.groupby('datadate')['v1_09161455_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['v1_09161455_dv_0916'] = (icom['ask_1st_maxp_v_1455']-icom['ask_1st_maxp_v_0916']).divide(icom['ask_1st_maxp_v_0916'])
icom['v1_09161455_dv_0916_bk'] = icom.groupby('datadate')['v1_09161455_dv_0916'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['v1_1455_dv_so_df20']  = icom.groupby('ticker')['v1_1455_dv_so'].apply(lambda x: x-x.shift(20)).values
icom['v1_1455_dv_so_df20_bk'] = icom.groupby('datadate')['v1_1455_dv_so_df20'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['v1_1455_dv_so_t20dSTD'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['v1_1455_dv_so'].std().values
icom['v1_1455_dv_so_t20dSTD_bk'] = icom.groupby('datadate')['v1_1455_dv_so_t20dSTD'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['v1_1455_dv_so_t40dSTD'] = icom.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['v1_1455_dv_so'].std().values
icom['v1_1455_dv_so_t40dSTD_bk'] = icom.groupby('datadate')['v1_1455_dv_so_t40dSTD'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['v1_1455_dv_so_t40dSTD_orth'] = icom.groupby('datadate')[COLS+['v1_1455_dv_so_t40dSTD']].apply(lambda x: yu.
orthogonalize_cn(x['v1_1455_dv_so_t40dSTD'], x[COLS])).values
icom['v1_1455_dv_so_t40dSTD_orth_bk'] = icom.groupby('datadate')['v1_1455_dv_so_t40dSTD_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['v1_1455_dv_so_t40dSTD_orth_sgnl'] = - icom.groupby('datadate')['v1_1455_dv_so_t40dSTD_orth'].apply(yu.uniformed_rank).values
icom['v1_1455_dv_so_t60dSTD'] = icom.groupby('ticker').rolling(datetime.timedelta(days=84),on='datadate')['v1_1455_dv_so'].std().values
icom['v1_1455_dv_so_t60dSTD_orth'] = icom.groupby('datadate')[COLS+['v1_1455_dv_so_t60dSTD']].apply(lambda x: yu.orthogonalize_cn(x['v1_1455_dv_so_t60dSTD'], x[COLS])).values
icom['v1_1455_dv_so_t60dSTD_orth_sgnl'] = - icom.groupby('datadate')['v1_1455_dv_so_t60dSTD_orth'].apply(yu.uniformed_rank).values


yu.create_cn_3x3(icom, ['v1_1455_dv_so_bk'], 'v1_1455_dv_so') # less mono: +2 -9
yu.create_cn_3x3(icom, ['v1_1455_dv_so_orth_bk'], 'v1_1455_dv_so_orth') # mono: +3 -11
yu.create_cn_3x3(icom, ['v1_09161455_dv_so_bk'], 'v1_09161455_dv_so') # mono: +2 -9
yu.create_cn_3x3(icom, ['v1_09161455_dv_0916_bk'], 'v1_09161455_dv_0916') # mono: +1.5 -1.5
yu.create_cn_3x3(icom, ['v1_1455_dv_so_df20_bk'], 'v1_1455_dv_so_df20') 
yu.create_cn_3x3(icom, ['v1_1455_dv_so_t20dSTD_bk'], 'v1_1455_dv_so_t20dSTD') # mono: +1 -4
yu.create_cn_3x3(icom, ['v1_1455_dv_so_t40dSTD_bk'], 'v1_1455_dv_so_t40dSTD') # less mono: 0 1 -5
yu.create_cn_3x3(icom, ['v1_1455_dv_so_t40dSTD_orth_bk'], 'v1_1455_dv_so_t40dSTD_orth') # mono: +2 -6


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['v1_1455_dv_so_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v1_1455_dv_so_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.22/-5.6
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['v1_1455_dv_so_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v1_1455_dv_so_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.54/1.55 ###!!!
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['v1_1455_dv_so_orth_t20d_sgnl']>0)].\
            dropna(subset=['v1_1455_dv_so_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v1_1455_dv_so_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.79/0.84
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['v1_1455_dv_so_t40dSTD_orth_sg
nl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v1_1455_dv_so_t40dSTD_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.11/1.06
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['v1_1455_dv_so_t60dSTD_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v1_1455_dv_so_t60dSTD_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.15 / 1.22



# to sql
icom['Ticker'] = icom['ticker'].str[:6]
icom['DataDate'] = icom['datadate']
param_engine = create_engine('mssql+pyodbc://summitsqldb_cndbdev') 
icom[['Ticker','DataDate','v1_1455_dv_so_orth_t20d_sgnl']].to_sql('F001_ODBK_lmtup_LS_MA', param_engine , index = False, if_exists = 'replace', chunksize = 10000)
icom[['Ticker','DataDate','v1_1455_dv_so_orth_sgnl']].to_sql('F001_ODBK_lmtup_LS_1D', param_engine , index = False, if_exists = 'replace', chunksize = 10000)



### 14:55 + RQ
# RQ itself isn't super helpful

icom['sell_pressure2'] = (icom['rq_v'] + icom['ask_1st_maxp_v_1455']).divide(icom['FLOAT_l1d'])
icom['sell_pressure2_bk'] = icom.groupby('datadate')['sell_pressure'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['sell_pressure'] = (icom['rq_v'] + icom['ask_1st_maxp_v_1455']).divide(icom['avgPVadj'])
icom['sell_pressure_bk'] = icom.groupby('datadate')['sell_pressure'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['sell_pressure3'] = (icom['rq_v'] - icom['ask_1st_maxp_v_1455']).divide(icom['FLOAT_l1d'])
icom['sell_pressure3_bk'] = icom.groupby('datadate')['sell_pressure3'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['rq_dv_so'] = icom['rq_v'].divide(icom['FLOAT_l1d'])
icom['rq_dv_so_bk'] = icom.groupby('datadate')['rq_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['rq_dv_so_orth'] = icom.groupby('datadate')[COLS+['rq_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['rq_dv_so'], x[COLS])).values
icom['rq_dv_so_orth_bk'] = icom.groupby('datadate')['rq_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['sell_pressure_bk'], 'sell_pressure') # less mono
yu.create_cn_3x3(icom, ['sell_pressure2_bk'], 'sell_pressure') # less mono
yu.create_cn_3x3(icom, ['sell_pressure3_bk'], 'sell_pressure3') # mono: -4 +2
yu.create_cn_3x3(icom, ['rq_dv_so_bk'], 'rq_dv_so') # random
yu.create_cn_3x3(icom, ['rq_dv_so_orth_bk'], 'rq_dv_so_orth') # random 





# rq balance - lmtup 
# unused quota? (thru 1500)


t1 = icom[icom['ticker']=='000001.SZ'][
['v1_0916_dv_so','datadate']]

icom['v1_0916_t200d_mean'] = icom.groupby('ticker').rolling(200,min_periods=100)['v1_0916_dv_so'].mean().values
icom['v1_0916_t200d_std'] = icom.groupby('ticker').rolling(200,min_periods=100)['v1_0916_dv_so'].std().values

icom['v1_0916_dv_so_z'] = (icom['v1_0916_dv_so']-icom['v1_0916_t200d_mean']).divide(icom['v1_0916_t200d_std'])

t1 = icom[icom['ticker']=='000001.SZ'].set_index('datadate')[['v1_0916_dv_so_z','v1_0916_dv_so','v1_0916_t200d_mean','v1_0916_t200d_std']]
icom[icom['ticker']=='000001.SZ'].set_index('datadate')['v1_0916_dv_so_z'].plot()
icom[icom['ticker']=='000001.SZ'].set_index('datadate')['v1_0916_dv_so'].plot()
icom[icom['ticker']=='300750.SZ'].set_index('datadate')['v1_0916_dv_so'].plot()


