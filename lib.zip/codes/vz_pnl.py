﻿#$%^&* vz_pnl.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 13 08:42:12 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import util as yu


i_sd = pd.read_parquet('/dat/summit_capital/TZ/China Data Hunt/cache/util_prepare_sd_cn_1800.parquet')


cols_features = ['F001_SHSZ', 'F001_LT', 'F001_ST', 'F001_TWAP2M', 'F001_TWAP3SV2', 
              'F001_TWAP60SV2', 'F001_PVAR', 'F001_CANC', 'F001_CAV', 'F001_BAR', 
              'F001_ACT', 'F002_GB', 'F004_NB', 'F005_IRSN', 'F007_JM', 'F008_ERNUG', 
              'F008_ERNFT']


i_wts = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDWTS_CSI1800_SLOW''')
i_wts = i_wts.melt(id_vars = 'DataDate', value_vars=cols_features, value_name='wts', var_name='feature_name')


i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F001_ACT_CSI1800_SLOW_LS''')
i_data['feature_name'] = 'F001_ACT'
i_features = i_data.copy()

i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F001_BAR_CSI1800_SLOW_LS''')
i_data['feature_name'] = 'F001_BAR'
i_features = i_features.append(i_data)

i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F001_CANC_CSI1800_SLOW_LS''')
i_data['feature_name'] = 'F001_CANC'
i_features = i_features.append(i_data)

i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F001_LT_CSI1800_SLOW_LS''')
i_data['feature_name'] = 'F001_CAV'
i_features = i_features.append(i_data)

i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F001_LT_CSI1800_SLOW_LS''')
i_data['feature_name'] = 'F001_LT'
i_features = i_features.append(i_data)

i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F001_ST_CSI1800_SLOW_LS''')
i_data['feature_name'] = 'F001_ST'
i_features = i_features.append(i_data)

i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F001_PVAR_CSI1800_SLOW_LS''')
i_data['feature_name'] = 'F001_PVAR'
i_features = i_features.append(i_data)

i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F001_SHSZ_CSI1800_SLOW_LS''')
i_data['feature_name'] = 'F001_SHSZ'
i_features = i_features.append(i_data)

i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F001_TWAP2M_CSI1800_SLOW_LS''')
i_data['feature_name'] = 'F001_TWAP2M'
i_features = i_features.append(i_data)

i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F001_TWAP3SV2_CSI1800_SLOW_LS''')
i_data['feature_name'] = 'F001_TWAP3SV2'
i_features = i_features.append(i_data)


i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F001_TWAP60SV2_CSI1800_SLOW_LS''')
i_data['feature_name'] = 'F001_TWAP60SV2'
i_features = i_features.append(i_data)

i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F002_GB_CSI1800_SLOW_LS''')
i_data['feature_name'] = 'F002_GB'
i_features = i_features.append(i_data)

i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F004_NB_CSI1800_SLOW_LS''')
i_data['feature_name'] = 'F004_NB'
i_features = i_features.append(i_data)

i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F005_IRSN_LS''')
i_data['feature_name'] = 'F005_IRSN'
i_features = i_features.append(i_data)

i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F007_JM5d_CSI1800_LO''')
i_data['feature_name'] = 'F007_JM'
i_features = i_features.append(i_data)

i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F008_ERNFT_T2000_SLOW_LO''')
i_data['feature_name'] = 'F008_ERNFT'
i_features = i_features.append(i_data)

i_data = yu.get_sql('''select * from cndbprod.dbo.SMTCN_CHILDALPHA_F008_ERNUG_T2000_SLOW_LO''')
i_data['feature_name'] = 'F008_ERNUG'
i_features = i_features.append(i_data)



i_features_s2 = i_features.merge(i_wts, on = ['DataDate','feature_name'], how = 'left')

i_features_s2 = i_features_s2.dropna()

s1 = i_features_s2.groupby(['Ticker','DataDate'])[['alpha','wts']].apply(lambda x: x['alpha'].multiply(x['wts']).sum() / x['wts'].sum())
s1 = s1.reset_index()
s1 = s1.rename(columns = {0: 'alpha'})
s1 = s1.to_parquet('/dat/summit_capital/TZ/tmp/vz_pnl_alpha.parquet')

s2 = i_features_s2.groupby(['Ticker','DataDate'])['alpha'].mean()
s2 = s2.reset_index()
s2.to_parquet('/dat/summit_capital/TZ/tmp/vz_pnl_alpha2.parquet')



### pnl in backtest environment


icom = i_sd.merge(s1, on = ['Ticker', 'DataDate'], how = 'left')
icom['alpha'] = icom.groupby('DataDate')['alpha'].apply(yu.uniformed_rank)

o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2019-01-01', '2022-12-31')].\
            dropna(subset=['alpha','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'alpha','BarrRet_CLIP_USD+1d', static_data = i_sd) # 14% gmvret
o_1 = yu.bt_cn_15_linux(icom[icom['DataDate'].between('2022-01-01', '2022-12-31')].\
            dropna(subset=['alpha','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
            'alpha','BarrRet_CLIP_USD+1d', static_data = i_sd) # 8% gmvret
o_1 = yu.bt_cn_15_linux(icom[icom
['DataDate'].between('2019-01-01', '2021-12-31')].\
        dropna(subset=['alpha','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['Ticker','DataDate']),
        'alpha','BarrRet_CLIP_USD+1d', static_data = i_sd) # 17% gmvret

    
    
    
