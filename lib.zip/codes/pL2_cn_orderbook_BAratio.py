﻿#$%^&* pL2_cn_orderbook_BAratio.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  6 18:00:28 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine


# this studies bid ask ratio in full order book
# this signal decays very quickly - unfilled orders only impact very short term returns


### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])


### pv
i_pv_93045 = yu.get_sql('''(select ticker, datadate, sum(volume) as v_093045 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_17]
                            where time between 930 and 945 group by ticker, datadate)
                           union
                           (select ticker, datadate, sum(volume) as v_093045 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_18]
                            where time between 930 and 945 group by ticker, datadate)
                           union
                           (select ticker, datadate, sum(volume) as v_093045 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_19]
                            where time between 930 and 945 group by ticker, datadate)
                           union
                           (select ticker, datadate, sum(volume) as v_093045 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_20]
                            where time between 930 and 945 group by ticker, datadate)''')
i_pv_93045['ticker'] = i_pv_93045['ticker'].str.replace('SS','SH')

i_pv_94510 = yu.get_sql('''(select ticker, datadate, sum(volume) as v_094510 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_17]
                            where time between 945 and 1000 group by ticker, datadate)
                           union
                           (select ticker, datadate, sum(volume) as v_094510 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_18]
                            where time between 945 and 1000 group by ticker, datadate)
                           union
                           (select ticker, datadate, sum(volume) as v_094510 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_19]
                            where time between 945 and 1000 group by ticker, datadate)
                           union
                           (select ticker, datadate, sum(volume) as v_094510 from [CNDBPROD].[dbo].[TRTH_CN_TRADE_20]
                            where time between 945 and 1000 group by ticker, datadate)''')
i_pv_94510['ticker'] = i_pv_94510['ticker'].str.replace('SS','SH')

### o
2c


i_oc_c_ret = pw.get_wind_mkt_data(col_list = ['ticker', 'datadate', 'adjret_o_c', 'adjret_c_c','adjret'])
i_oc_c_ret = i_oc_c_ret.sort_values(['ticker', 'datadate'])
i_oc_c_ret['adjret_o_c_t20d'] = i_oc_c_ret.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['adjret_o_c'].sum().values
i_oc_c_ret['adjret_o_c_t40d'] = i_oc_c_ret.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['adjret_o_c'].sum().values
i_oc_c_ret['adjret_c_c_t20d'] = i_oc_c_ret.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['adjret'].sum().values
i_oc_c_ret['adjret_c_c_t40d'] = i_oc_c_ret.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['adjret'].sum().values



### order book metrics

i_odbk1 = yu.get_q("get `:/export/datadev/Data/SHSZ/ORDER_metrics/orderbook_metrics_batch1_01")

i_odbk1['code'] = i_odbk1['code'].str.decode('utf8')
c_sh = i_odbk1['code'].str[0].isin(['6'])
c_sz = i_odbk1['code'].str[0].isin(['0','3'])
i_odbk1.loc[c_sh, 'ticker'] = i_odbk1.loc[c_sh, 'code'] + '.SH'
i_odbk1.loc[c_sz, 'ticker'] = i_odbk1.loc[c_sz, 'code'] + '.SZ'
i_odbk1['datadate'] = pd.to_datetime(i_odbk1['date'])
i_odbk1 = i_odbk1.sort_values(['ticker', 'datadate'])






### combine 

icom = i_sd.merge(i_odbk1, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_oc_c_ret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['adjret_o_c_t40d_rk'] = icom.groupby('datadate')['adjret_o_c_t40d'].apply(yu.uniformed_rank).values



### bid / SO

icom['bid_dv_so'] = icom['bid_avg_v'].divide(icom['FLOAT_l1d'])
icom['bid_dv_so_bk'] = icom.groupby('datadate')['bid_dv_so'].apply(lambda x:yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['bid_dv_so_bk'], 'bid_dv_so') # random 




### ask / SO

icom['ask_dv_so'] = icom['ask_avg_v'].divide(icom['FLOAT_l1d'])
icom['ask_dv_so_bk'] = icom.groupby('datadate')['ask_dv_so'].apply(lambda x:yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['ask_dv_so_bk'], 'ask_dv_so') # a-shaped: 1 3 -10


icom['ask_avg_v_x7pct'] = np.nan
c1 = icom['BarrRet_SRISK_USD-1d'].abs()<0.03
icom.loc[c1, 'ask_avg_v_x7pct'] = icom.loc[c1, 'ask_avg_v']
icom['ask_dv_so_x7pct'] = icom['ask_avg_v_x7pct'].divide(icom['FLOAT_l1d'])
icom['ask_dv_so_x7pct_bk'] = icom.groupby('datadate')['ask_dv_so_x7pct'].apply(lambda x:yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['ask_dv_so_x7pct_bk'], 'ask_dv_so_x7pct') # 



### (bid_weighted - ask_weighted) / SO

icom['n
etw_dv_so'] = (icom['bid_tot_wv']-icom['ask_tot_wv']).divide(icom['FLOAT_l1d'])
icom['netw_dv_so_bk'] = icom.groupby('datadate')['netw_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['netw_dv_so_bk'], 'netw_dv_so') # r-shaped: -8 +1



### (bid-ask) / SO

icom['net_dv_so'] = (icom['bid_avg_v']-icom['ask_avg_v']).divide(icom['FLOAT_l1d'])
icom['net_dv_so_sgnl'] = icom.groupby('datadate')['net_dv_so'].apply(yu.uniformed_rank).values
icom['net_dv_so_sgnl_t5d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=7),on='datadate')['net_dv_so_sgnl'].mean().values
icom['net_dv_so_sgnl_t5d_sgnl'] = icom.groupby('datadate')['net_dv_so_sgnl_t5d'].apply(yu.uniformed_rank).values
icom['net_dv_so_bk'] = icom.groupby('datadate')['net_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['net_dv_so_t5d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=7),on='datadate')['net_dv_so'].mean().values
icom['net_dv_so_t5d_sgnl'] = icom.groupby('datadate')['net_dv_so_t5d'].apply(yu.uniformed_rank).values
icom['net_dv_so_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['net_dv_so'].mean().values
icom['net_dv_so_t20d_sgnl'] = icom.groupby('datadate')['net_dv_so_t20d'].apply(yu.uniformed_rank).values
#yu.create_cn_3x3(icom, ['net_dv_so_bk'], 'net_dv_so') # sharpe mono: -10 +4


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['net_dv_so_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'net_dv_so_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.94/-9.29
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['net_dv_so_sgnl_t5d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'net_dv_so_sgnl_t5d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.65/-1.39
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['net_dv_so_t5d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'net_dv_so_t5d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.92/-1.14
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['net_dv_so_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'net_dv_so_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.44/0.08



icom['net_dv_so_sgnl2'] = np.nan
icom.loc[icom['net_dv_so_sgnl']>0.9, 'n
et_dv_so_sgnl2'] = 1
icom.loc[icom['net_dv_so_sgnl']<-0.9, 'net_dv_so_sgnl2'] = -1
icom['net_dv_so_sgnl2'] = icom.groupby('ticker')['net_dv_so_sgnl2'].ffill(limit=40)
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['net_dv_so_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'net_dv_so_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.19 / 1.01s


### (bid-ask) / SO and o2C


icom['net_dv_so'] = (icom['bid_avg_v']-icom['ask_avg_v']).divide(icom['FLOAT_l1d'])
icom['net_dv_so_sgnl'] = icom.groupby('datadate')['net_dv_so'].apply(yu.uniformed_rank).values

icom['net_dv_so_o2c'] = icom['net_dv_so_sgnl'] - icom['adjret_o_c_t40d_rk']
icom['net_dv_so_o2c_sgnl'] = icom.groupby('datadate')['net_dv_so_o2c'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['net_dv_so_o2c_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'net_dv_so_o2c_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # not working


icom['net_dv_so_o2c_sgnl2'] = np.nan
c1 = (icom['adjret_o_c_t40d_rk']<-0.8)&(icom['net_dv_so_sgnl']>0.8)
icom.loc[c1, 'net_dv_so_o2c_sgnl2'] = 1
icom['net_dv_so_o2c_sgnl2'] = icom.groupby('ticker')['net_dv_so_o2c_sgnl2'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['net_dv_so_o2c_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'net_dv_so_o2c_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.03/0.92 LO poor SO ok


### (bid-ask) / SO time-series

icom['net_dv_so'] = (icom['bid_avg_v']-icom['ask_avg_v']).divide(icom['FLOAT_l1d'])
icom['net_dv_so_t200dAVG'] = icom.groupby('ticker').rolling(200,min_periods=100)['net_dv_so'].mean().values
icom['net_dv_so_t200dSTD'] = icom.groupby('ticker').rolling(200,min_periods=100)['net_dv_so'].std().values
icom['net_dv_so_z'] = (icom['net_dv_so'] - icom['net_dv_so_t200dAVG']).divide(icom['net_dv_so_t200dSTD'])

icom['net_dv_so_z_sgnl'] = np.nan
icom.loc[icom['net_dv_so_z']<-4, 'net_dv_so_z_sgnl'] = 1
icom['net_dv_so_z_sgnl'] = icom.groupby('ticker')['net_dv_so_z_sgnl'].ffill(limit=40)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['net_dv_so_z_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'net_dv_so_z_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # not working 




##
# (bid-ask) / SO in 14:30 - 15:00

icom['net14301500_dv_so'] = (icom['bid_v_14301500']-icom['ask_v_14301500']).divide(icom['FLOAT_l1d'])
icom['net14301500_dv_so_sgnl'] = icom.groupby('datadate')['net14301500_dv_so'].apply(yu.uniformed_rank).values
icom['net14301500_dv_so_bk'] = icom.groupby('datadate')['net14301500_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['net14301500_dv_so_bk'], 'net14301500_dv_so') # -9 +3


icom['net900930_dv_so'] = (icom['bid_v_09000930']-icom['ask_v_09000930']).divide(icom['FLOAT_l1d'])

icom['test'] = icom['net14301500_dv_so'] - icom['net900930_dv_so']
icom['test_bk'] = icom.groupby('datadate')['test'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['test_bk'], 'test') # v-shape: 0.5 -2 +1.5

icom['test2'] = (icom['bid_v_14301500'].divide(icom['ask_v_14301500']) - icom['bid_v_09000930'].divide(icom['ask_v_09000930'])).abs()
icom['test2_bk'] = icom.groupby('datadate')['test2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['test2_bk'], 'test2') #  mono: -1 +3


### (bid-ask) / SO in 09:00 - 09:30

icom['net900930_dv_so'] = (icom['bid_v_09000930']-icom['ask_v_09000930']).divide(icom['FLOAT_l1d'])
icom['net900930_dv_so_sgnl'] = icom.groupby('datadate')['net900930_dv_so'].apply(yu.uniformed_rank).values
icom['net900930_dv_so_bk'] = icom.groupby('datadate')['net900930_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['net900930_dv_so_t5d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=7),on='datadate')['net900930_dv_so'].mean().values
icom['net900930_dv_so_t5d_sgnl'] = icom.groupby('datadate')['net900930_dv_so_t5d'].apply(yu.uniformed_rank).values
icom['net900930_dv_so_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['net900930_dv_so'].mean().values
icom['net900930_dv_so_t20d_sgnl'] = icom.groupby('datadate')['net900930_dv_so_t20d'].apply(yu.uniformed_rank).values
yu.create_cn_3x3(icom, ['net900930_dv_so_bk'], 'net900930_dv_so') # smooth mono: -7 +3.5

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['net900930_dv_so_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'net900930_dv_so_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.19 / -10.54 ###!!!
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['net900930_dv_so_t5d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),

            'net900930_dv_so_t5d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.45/-0.7
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['net900930_dv_so_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'net900930_dv_so_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.34 / 0.53


# to sql
icom['Ticker'] = icom['ticker'].str[:6]
icom['DataDate'] = icom['datadate']
param_engine = create_engine('mssql+pyodbc://summitsqldb_cndbdev') 
icom[['Ticker','DataDate','net900930_dv_so_sgnl']].to_sql('F001_ODBK_BAratio_LS_1D', param_engine , index = False, if_exists = 'replace', chunksize = 10000)



icom['net900930_dv_so_sgnl2'] = np.nan
icom.loc[(icom['net900930_dv_so_sgnl']>0.9)&(icom['adjret_o_c_t40d_rk']<-0.5), 'net900930_dv_so_sgnl2'] = 1
icom.loc[(icom['net900930_dv_so_sgnl']<-0.9)&(icom['adjret_o_c_t40d_rk']>0.5), 'net900930_dv_so_sgnl2'] = -1
icom['net900930_dv_so_sgnl2'] = icom.groupby('ticker')['net900930_dv_so_sgnl2'].ffill(limit=40)
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['net900930_dv_so_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'net900930_dv_so_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.18 / 2.33 ###!!!
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['net900930_dv_so_sgnl2']>0)].\
            dropna(subset=['net900930_dv_so_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'net900930_dv_so_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.2 / 1.4 only minor improvements
