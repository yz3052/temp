﻿#$%^&* pSYNC_ml.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 24 09:43:02 2023

@author: thzhang
"""






import xgboost as xgb
import pandas as pd
import numpy as np
from typing import Tuple
import optuna
from optuna.samplers import TPESampler
import scipy.stats as ss
import json
import os


# This is the machine learning engine for signal aggregation


# =============================================================================
# 
# =============================================================================

def rerank(r):
    rindex = r.index
    res = np.zeros(len(r))
    res = res + float('nan')
    x2 = np.array(r)
    x2 = x2[~np.isnan(x2)]
    x3 = list(x2)    
    x3.reverse()
    x3 = list(ss.rankdata(x3)-1)
    x3.reverse()
    if len(x2) > 0:
        res2 = -1 + 1/len(x2) *(ss.rankdata(x2) - 1  + np.array(x3))
        res[~np.isnan(np.array(r))] = res2
    rdf = pd.DataFrame(res)
    rdf = rdf.set_index(rindex)
    return(rdf)


def RscoreMetric(predt: np.ndarray, dtrain: xgb.DMatrix) -> Tuple[str,float]:
    
    y = dtrain.get_label()
    w = dtrain.get_weight()
    msqe = np.multiply(np.power((predt - y), 2), w)
    mmu = np.multiply(np.power((y - np.mean(y)), 2), w)
    rsquare = 1 - np.sum(msqe) / np.sum(mmu)
    rscore = max([-1,np.sign(rsquare)*np.sqrt(abs(rsquare))])
    
    return 'rscore', -rscore


def NegLogLoss(predt: np.ndarray, dtrain: xgb.DMatrix) -> Tuple[str,float]:
    
    y = dtrain.get_label()
    w = dtrain.get_weight()
    
    nll = np.zeros(len(y))
    
    condition = (predt > 0.5) & (y==1)
    nll[condition] = np.log(predt[condition])
    condition = (predt < 0.5) & (y==0)
    nll[condition] = np.log(1-predt[condition])
    
    nll = np.sum(np.multiply(w,nll)) / np.sum(w)
    
    return 'nll', -nll


def PurgedKFold(df_trains,df_calendars,purged_days,fold,cv_rows):
    
    rows_windows = df_trains.groupby('DataDate')['Ticker'].count()
    rows_windows = dict(rows_windows)
    
    dates_windows = df_trains[['DataDate']].drop_duplicates()
    dates_windows = dates_windows.sort_values('DataDate',ascending=False)
    dates_windows = dates_windows['DataDate'].tolist()
    dates_max = max(dates_windows)
    
    l = 0
    c = 1
    cv_dates = []
    for dd in dates_windows:
        if c <= fold:
            l = l + len(df_trains[ df_trains['DataDate'] == dd ])
            if l < cv_rows:
                cv_dates.append([dd,c])
            else:
                l = 0
            
    c = c + 1
                
    cv_dates = pd.DataFrame(cv_dates,columns=['DataDate','cv_fold'])
            
    train_dates = []
    for f in range(1,fold+1):
        cvd_min = cv_dates[ cv_dates['cv_fold'] == f ]['DataDate'].min()
        cvd_max = cv_dates[ cv_dates['cv_fold'] == f ]['DataDate'].max()
        if f == 1:
            traind_max = df_calendars[df_calendars.index(cvd_min)-purged_days-1]
            l = 0
            for tt in [ x for x in dates_windows if x <= traind_max ]:
                    l = l + rows_windows[tt]
                    if l < cv_rows*(fold-1):
                        train_dates.append([tt,f])
        else:
            traind_min = df_calendars[df_calendars.index(cvd_max)+purged_days+1]
            traind_max = df_calendars[df_calendars.index(cvd_min)-purged_days-1]
            l = 0
            for tt in [ x for x in dates_windows if ((x >= traind_min) & (x <= dates_max)) | ((x <= traind_max)) ]:
                    l = l + rows_windows[tt]
                    if l < cv_rows*(fold-1):
                        train_dates.append([tt,f])
            
    train_dates = pd.DataFrame(train_dates,columns=['DataDate','train_fold'])
            
    return cv_dates, train_dates


def metric_rscore(cv_data_sub):

    cv_data_sub['msqe'] = cv_data_sub['wts'] * ((cv_data_sub['yhat'] - cv_data_sub['y'])**2)
    cv_data_sub['mmu'] = cv_data_sub['wts'] * ((cv_data_sub['y'] - (cv_data_sub['y'].mean()))**2)
    rsquare_cv = 1 - (cv_data_sub['msqe'].sum() / cv_data_sub['mmu'].sum())
    rscore = max( [-1,np.sign(rsquare_cv) * np.sqrt(abs(rsquare_cv))] )

    return rscore


def metric_nll(cv_data_sub):

    cv_data_sub['nll'] = 0
    condition = (cv_data_sub['yhat'] > 0.5) & (cv_data_sub['y'] == 1)
    cv_data_sub.loc[condition,'nll'] = np.log(cv_data_sub.loc[condition,'yhat'])
    condition = (cv_data_sub['yhat'] < 0.5) & (cv_data_sub['y'] == 0)
    cv_data_sub.loc[condition,'nll'] = np.log(1 - cv_data_sub.loc[condition,'yhat'])
    cv_data_sub['nll'] = cv_data_sub['nll'] * cv_data_sub['wts']
    nll =  cv_data_sub['nll'].sum() / cv_data_sub['wts'].sum()   

    return nll


def metric_to(cv_data_sub):
    
    s = cv_data_sub.copy(deep=True)
    s['alpha'] = s.groupby('DataDate')['yhat'].apply(lambda r: rerank(r))
    s['pos'] = s['alpha'] * s['clip']
    s = s[['DataDate','Ticker', 'pos']]
    s = s.sort_values('DataDate')
    s = s.reset_index(drop=True)
    spos = s.pivot_table(index='Ticker',columns=['DataDate'], values='pos')
 
   spos = spos.fillna(0)
    spos = spos.unstack()
    spos = spos.reset_index()
    spos = spos.rename(columns={0:'pos'})
    spos = spos.sort_values(['Ticker','DataDate'])
    spos['pos_pre'] = spos.groupby(['Ticker'])['pos'].shift(1)
    spos = spos.fillna(0)
    spos = spos[ ~((spos['pos']==0) & (spos['pos_pre']==0))   ]
    spos['trdd'] = abs(spos['pos'] - spos['pos_pre'])
    spos['gmv'] = abs(spos['pos'])
    to = spos['trdd'].sum() / spos['gmv'].sum()
    
    return -to


def metric_sharpe(cv_data_sub, df_universe):
    
    s = cv_data_sub.copy(deep=True)
    s['alpha'] = s.groupby('DataDate')['yhat'].apply(lambda r: rerank(r))
    s['pos'] = s['alpha'] * s['clip']
    s = s[['DataDate','Ticker', 'pos']]
    s = s.sort_values('DataDate')
    s = s.reset_index(drop=True)
    spos = s.pivot_table(index='Ticker',columns=['DataDate'], values='pos')
    spos = spos.fillna(0)
    spos = spos.unstack()
    spos = spos.reset_index()
    spos = spos.rename(columns={0:'pos'})
    spos = spos.sort_values(['Ticker','DataDate'])
    spos['pos_pre'] = spos.groupby(['Ticker'])['pos'].shift(1)
    spos = spos.fillna(0)
    spos = spos[ ~((spos['pos']==0) & (spos['pos_pre']==0))   ]
    spos['trdd'] = abs(spos['pos'] - spos['pos_pre'])
    spos['gmv'] = abs(spos['pos'])
    spos = pd.merge(spos, df_universe[['DataDate','Ticker','spread','cc_vol_21d','avgPVadj','BarrRet_CLIP1d']], on=['DataDate','Ticker'], how='inner')
    spos['volatility'] = spos['cc_vol_21d']
    spos['instcost'] = 0.3 * spos['spread'] * spos['trdd']
    spos['transcost'] = 0.09 * ((spos['volatility']/np.sqrt(252))**0.65) * ((spos['trdd']/spos['avgPVadj'])**0.6) * spos['trdd']
    spos['permcost'] = 21.46 * ((spos['volatility']/np.sqrt(252))**2) * ((spos['trdd']/spos['avgPVadj'])) * spos['trdd']
    spos['pnl_ac'] = spos['pos'] * spos['BarrRet_CLIP1d'] - spos['instcost']- spos['transcost'] - spos['permcost']
    ret = spos.groupby('DataDate')['pnl_ac'].sum()
    ret = ret.reset_index()
    sr_ac = ret['pnl_ac'].mean() / ret['pnl_ac'].std() * np.sqrt(252)
    
    return sr_ac


def objective(trial, df_data_train, df_universe, train_dates_sub, cv_dates_sub, configs):

    features = configs['features']
    monotone_features = configs['monotone_features']
    interaction_features = configs['interaction_features']
    metric_method = configs['metric_method']
    eta_min = configs['eta_min']
    eta_max = configs['eta_max']
    gamma_min = configs['gamma_min']
    gamma_max = configs['gamma_max']
 
   md_min = configs['md_min']
    md_max = configs['md_max']
    mcw_min = configs['mcw_min']
    mcw_max = configs['mcw_max']
    subsample_min = configs['subsample_min']
    subsample_max = configs['subsample_max']
    colsample_bytree_min = configs['colsample_bytree_min']
    colsample_bytree_max = configs['colsample_bytree_max']
    colsample_bylevel_min = configs['colsample_bylevel_min']
    colsample_bylevel_max = configs['colsample_bylevel_max']
    colsample_bynode_min = configs['colsample_bynode_min']
    colsample_bynode_max = configs['colsample_bynode_max']
    lambda_min = configs['lambda_min']
    lambda_max = configs['lambda_max']
    alpha_min = configs['alpha_min']
    alpha_max = configs['alpha_max']
    esr = configs['esr']
    loss_function = configs['loss_function']
    grow_policy = configs['grow_policy']
    learning_method = configs['learning_method']
    missing_data = configs['missing_data']
    if missing_data == 'NaN':
        missing_data = np.NaN
    else:
        missing_data = 0

    df_data_train = df_data_train.reset_index(drop=True)
    
    X_train = df_data_train[df_data_train['DataDate'].isin(train_dates_sub)][features]
    y_train = df_data_train[df_data_train['DataDate'].isin(train_dates_sub)][['y']]
    w_train = df_data_train[df_data_train['DataDate'].isin(train_dates_sub)][['wts']]
   
    dtrain = xgb.DMatrix(X_train,label=y_train,missing=missing_data,weight=w_train,nthread=1)
    
    cv_data_sub = df_data_train[df_data_train['DataDate'].isin(cv_dates_sub)]
    cv_data_sub = cv_data_sub.reset_index(drop=True)

    X_cv = cv_data_sub[features]
    y_cv = cv_data_sub[['y']]
    w_cv = cv_data_sub[['wts']]

    deval = xgb.DMatrix(X_cv,label=y_cv,missing=missing_data,weight=w_cv,nthread=1)
    dcv = xgb.DMatrix(X_cv,missing=missing_data,weight=w_cv,nthread=1)

    if learning_method == 'gbtree':
        params = {
                'learning_rate': trial.suggest_float('learning_rate', eta_min, eta_max),
                'gamma': trial.suggest_int('gamma', gamma_min, gamma_max), 
                'max_depth': trial.suggest_int("max_depth", md_min, md_max), 
                'min_child_weight': trial.suggest_int('min_child_weight', mcw_min, mcw_max),
                'max_delta_step': 0, 
                'subsample': trial.suggest_float('subsample', subsample_min, subsample_max),
                'sampling_method': 'uniform',
                'colsample_bytree': trial.suggest_float('colsample_bytree', colsample_bytree_min, co
lsample_bytree_max),
                'colsample_bylevel': trial.suggest_float('colsample_bylevel', colsample_bylevel_min, colsample_bylevel_max),
                'colsample_bynode': trial.suggest_float('colsample_bynode', colsample_bynode_min, colsample_bynode_max),
                'reg_lambda': trial.suggest_int("reg_lambda", lambda_min, lambda_max), 
                'reg_alpha': trial.suggest_int("reg_alpha", alpha_min, alpha_max), 
                'tree_method': 'hist',
                'monotone_constraints': monotone_features,
                'interaction_constraints': interaction_features,
                'objective': loss_function,
                'grow_policy': grow_policy,
                'seed': 123,
                'disable_default_eval_metric': 1,
                'nthread': 1,
                'booster': 'gbtree'
                }

    if learning_method == 'gblinear':
        params = {
                'reg_lambda': trial.suggest_int("reg_lambda", lambda_min, lambda_max), 
                'reg_alpha': trial.suggest_int("reg_alpha", alpha_min, alpha_max), 
                'objective': loss_function,
                'seed': 123,
                'disable_default_eval_metric': 1,
                'nthread': 1,
                'booster': 'gblinear'
                }
    
    if loss_function == 'reg:squarederror':
        bst = xgb.train(params, dtrain, num_boost_round=500, custom_metric=RscoreMetric, evals=[(dtrain,'dtrain'),(deval,'deval')], early_stopping_rounds=esr,verbose_eval=150)
    if loss_function == 'reg:logistic':
        bst = xgb.train(params, dtrain, num_boost_round=500, custom_metric=NegLogLoss, evals=[(dtrain,'dtrain'),(deval,'deval')], early_stopping_rounds=esr,verbose_eval=150)

    bst_cv = bst.predict(dcv)
    cv_data_sub['yhat'] = pd.DataFrame(bst_cv)
    
    if metric_method == 'to':
        metric = metric_to(cv_data_sub)
    if metric_method == 'rscore':
        metric = metric_rscore(cv_data_sub)
    if metric_method == 'sharpe':
        metric = metric_sharpe(cv_data_sub, df_universe)
    if metric_method == 'nll':
        metric = metric_nll(cv_data_sub)
    
    return metric
 

def get_best_params(df_data_train, df_universe, df_calendars, configs):

    df_data_train = df_data_train.reset_index(drop=True)
    
    used_ret_col = configs['used_ret_col']
    fold = configs['fold']
    purged_days = configs['purged_days']
    
    df_data_train['y'] = df_data_train[used_ret_col]
    df_data_train = df_data_train[ np.isfinit
e(df_data_train['y']) ]
    df_data_train = df_data_train.reset_index(drop=True)
    
    cv_rows = int(len(df_data_train) / fold)
    cv_dates, train_dates = PurgedKFold(df_data_train,df_calendars,purged_days,fold,cv_rows)

    n_trials = configs['n_trials']
    tot_waittime = configs['tot_waittime']
    
    def objective_cv(trial, df_data_train=df_data_train, cv_dates=cv_dates, train_dates=train_dates):
        
        dates_windows_ = cv_dates[['cv_fold']].drop_duplicates()
        dates_windows_ = dates_windows_.reset_index(drop=True)
        
        metric_values = []
        for loc, foldid in dates_windows_['cv_fold'].iteritems():
            
            train_dates_sub = train_dates[ train_dates['train_fold'] == foldid ]
            train_dates_sub = train_dates_sub['DataDate'].tolist()
    
            cv_dates_sub = cv_dates[ cv_dates['cv_fold'] == foldid ]
            cv_dates_sub = cv_dates_sub['DataDate'].tolist()
    
            metric_value = objective(trial, df_data_train, df_universe, train_dates_sub, cv_dates_sub, configs)
            metric_values.append(metric_value)
    
        return np.mean(metric_values)

    sampler = TPESampler(seed=10)
    study = optuna.create_study(sampler=sampler, direction='maximize')
    study.optimize(objective_cv, n_trials=n_trials, timeout=tot_waittime)
    trial = study.best_trial

    return trial.value, trial.params


def get_best_models(df_data_train, df_calendars, configs, best_params):
    
    df_data_train = df_data_train.reset_index(drop=True)
    
    used_ret_col = configs['used_ret_col']
    fold = configs['fold']
    purged_days = configs['purged_days']
    features = configs['features']
    monotone_features = configs['monotone_features']
    interaction_features = configs['interaction_features']
    esr = configs['esr']
    loss_function = configs['loss_function']
    grow_policy = configs['grow_policy']
    learning_method = configs['learning_method']
    missing_data = configs['missing_data']
    if missing_data == 'NaN':
        missing_data = np.NaN
    else:
        missing_data = 0

    df_data_train['y'] = df_data_train[used_ret_col]
    df_data_train['y'] = df_data_train['y'].fillna(0)
    cv_rows = int(len(df_data_train) / fold)
    cv_dates, train_dates = PurgedKFold(df_data_train,df_calendars,purged_days,fold,cv_rows)

    best_models = []
    for foldid in range(1,fold+1):
        
        train_dates_sub = train_dates[ train_dates['train_fold'] == foldid ]
        train_d
ates_sub = train_dates_sub['DataDate'].tolist()

        X_train = df_data_train[df_data_train['DataDate'].isin(train_dates_sub)][features]
        y_train = df_data_train[df_data_train['DataDate'].isin(train_dates_sub)][['y']]
        w_train = df_data_train[df_data_train['DataDate'].isin(train_dates_sub)][['wts']]
       
        dtrain = xgb.DMatrix(X_train,label=y_train,missing=missing_data,weight=w_train,nthread=1)

        cv_dates_sub = cv_dates[ cv_dates['cv_fold'] == foldid ]
        cv_dates_sub = cv_dates_sub['DataDate'].tolist()
        
        X_cv = df_data_train[df_data_train['DataDate'].isin(cv_dates_sub)][features]
        y_cv = df_data_train[df_data_train['DataDate'].isin(cv_dates_sub)][['y']]
        w_cv = df_data_train[df_data_train['DataDate'].isin(cv_dates_sub)][['wts']]
    
        deval = xgb.DMatrix(X_cv,label=y_cv,missing=missing_data,weight=w_cv,nthread=1)
    
        if learning_method == 'gbtree':
            params = {
                    'eta': best_params['learning_rate'],
                    'gamma': best_params['gamma'],
                    'max_depth': best_params['max_depth'], 
                    'min_child_weight': best_params['min_child_weight'], 
                    'max_delta_step': 0,
                    'subsample': best_params['subsample'],
                    'sampling_method': 'uniform',
                    'colsample_bytree': best_params['colsample_bytree'],
                    'colsample_bylevel': best_params['colsample_bylevel'],
                    'colsample_bynode': best_params['colsample_bynode'],
                    'lambda': best_params['reg_lambda'],
                    'alpha': best_params['reg_alpha'],
                    'tree_method': 'hist',
                    'monotone_constraints': monotone_features,
                    'interaction_constraints': interaction_features,
                    'objective': loss_function,
                    'grow_policy': grow_policy,
                    'disable_default_eval_metric': 1,
                    'seed': 123,
                    'nthread': 1,
                    'booster': 'gbtree'
                    }
            
        if learning_method == 'gblinear':
            params = {
                    'lambda': best_params['reg_lambda'],
                    'alpha': best_params['reg_alpha'],
                    'objective': loss_function,
                    'disable_default_eval_metric': 1,
                    'seed': 123,
                    'nthread
': 1,
                    'booster': 'gblinear'
                    }

        if loss_function == 'reg:squarederror':
            best_model = xgb.train(params, dtrain, num_boost_round=500, custom_metric=RscoreMetric, evals=[(dtrain,'dtrain'),(deval,'deval')], early_stopping_rounds=esr,verbose_eval=150)
        if loss_function == 'reg:logistic':
            best_model = xgb.train(params, dtrain, num_boost_round=500, custom_metric=NegLogLoss, evals=[(dtrain,'dtrain'),(deval,'deval')], early_stopping_rounds=esr,verbose_eval=150)
        
        best_models.append(best_model)

    return best_models


def get_daily_alpha(df_data, df_universe, df_calendars, alphadates, configs, save_path):
    
    purged_days = configs['purged_days']
    features = configs['features']
    wts_type = configs['wts_type']
    importance_type = configs['importance_type']
    lookback_method = configs['lookback_method']
    
    if lookback_method == 'rolling':
        rolling_days = configs['rolling_days']
        startdate = df_calendars[ df_calendars.index(alphadates[0]) - purged_days - rolling_days ]
    if lookback_method == 'expanded':
        startdate = df_data['DataDate'].min()

    enddate = df_calendars[ df_calendars.index(alphadates[0]) - purged_days - 1 ]
    
    df_data_train = df_data[ (df_data['DataDate'] >= startdate) & (df_data['DataDate'] <= enddate)  ]
    df_data_train = df_data_train.reset_index(drop=True)

    if wts_type == 'clip':
        df_data_train['wts'] = df_data_train['clip']
    elif wts_type == 'srisk':
        df_data_train['wts'] = 1 / df_data_train['SRISK']
    else:
        df_data_train['wts'] = 1e6

    best_value, best_params = get_best_params(df_data_train, df_universe, df_calendars, configs)
    best_models = get_best_models(df_data_train, df_calendars, configs, best_params)
    
    # save model
    
    fscores = []
    for j in range(0,len(best_models)):
        best_model = best_models[j]
        fscore = best_model.get_score(importance_type=importance_type)
        fscore = pd.DataFrame.from_dict(fscore,orient='index',columns=['fscore'])
        fscores.append(fscore)
        best_model.save_model(save_path + '_model' + str(j) + '.json')
    fscores = pd.concat(fscores,axis=1,sort=False)
    fscores = fscores.mean(axis=1)
    fscores = fscores.reset_index()
    fscores.columns = ['feature','fscore']
    fscores = fscores.sort_values('fscore', ascending = False)
    fscores.to_csv(save_path + '_fscore.txt',index=False,sep='|')
   
 
    # calculate daily alpha
    
    for i in range(0,len(alphadates)):
        try:
            alphadate = alphadates[i]
            alphadatestr = str(int(alphadate.year*10000 + alphadate.month*100 + alphadate.day))
            
            df_des = df_data[ df_data['DataDate'] == alphadate ]
            df_des = df_des.reset_index(drop=True)
            X_test = df_des[features]
            tickers = df_des[['Ticker']]
            dtest = xgb.DMatrix(X_test,missing=np.NaN)
        
            yhats = []
            fscores = []
            for j in range(0,len(best_models)):                
                best_model = best_models[j]
                yhat = best_model.predict(dtest)
                yhats.append(yhat)                
            yhats = np.mean(yhats,axis=0)
            
            df_des = pd.DataFrame(yhats,columns=['yhat'])
            df_des['Ticker'] = tickers
            df_des['DataDate'] = alphadate
            df_des = df_des[['DataDate','Ticker','yhat']]
            
            with open(save_path + alphadatestr + '.json','w') as f:
                json.dump(best_params,f)
        
            df_des.to_csv(save_path + alphadatestr + '.txt',index=False,sep='|')
        except:
            continue


def prepare_monthly_models(df_data, df_universe, df_calendars, alphadates, configs, save_path):
    
    purged_days = configs['purged_days']
    #features = configs['features']
    wts_type = configs['wts_type']
    importance_type = configs['importance_type']
    lookback_method = configs['lookback_method']
    
    if lookback_method == 'rolling':
        rolling_days = configs['rolling_days']
        startdate = df_calendars[ df_calendars.index(alphadates[0]) - purged_days - rolling_days ]
    if lookback_method == 'expanded':
        startdate = df_data['DataDate'].min()

    enddate = df_calendars[ df_calendars.index(alphadates[0]) - purged_days - 1 ]
    
    df_data_train = df_data[ (df_data['DataDate'] >= startdate) & (df_data['DataDate'] <= enddate)  ]
    df_data_train = df_data_train.reset_index(drop=True)

    if wts_type == 'clip':
        df_data_train['wts'] = df_data_train['clip']
    elif wts_type == 'srisk':
        df_data_train['wts'] = 1 / df_data_train['SRISK']
    else:
        df_data_train['wts'] = 1e6

    best_value, best_params = get_best_params(df_data_train, df_universe, df_calendars, configs)
    best_models = get_best_models(df_data_train, df_calendars, configs, best_params)
    
    # save mode
l
    
    fscores = []
    for j in range(0,len(best_models)):
        best_model = best_models[j]
        fscore = best_model.get_score(importance_type=importance_type)
        fscore = pd.DataFrame.from_dict(fscore,orient='index',columns=['fscore'])
        fscores.append(fscore)
        best_model.save_model(os.path.join(save_path, 'model' + str(j) + '.json'))
    fscores = pd.concat(fscores,axis=1,sort=False)
    fscores = fscores.mean(axis=1)
    fscores = fscores.reset_index()
    fscores.columns = ['feature','fscore']
    fscores = fscores.sort_values('fscore', ascending = False)
    fscores.to_csv(os.path.join(save_path, 'fscore.txt'),index=False,sep='|')
    
