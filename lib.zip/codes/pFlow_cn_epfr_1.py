﻿#$%^&* pFlow_cn_epfr_1.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Sep  1 06:28:09 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime

import xgboost as xgb


### get sd

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])



### fund count active

i_fundcnt_active = pd.read_parquet(r'S:\TZ\EPFR\fundcnt_active.parquet')

i_fundcnt_active['ReportDate'] = pd.to_datetime(i_fundcnt_active['ReportDate'])
i_fundcnt_active['datadate'] = i_fundcnt_active['ReportDate']

i_fundcnt_active['ticker'] = i_fundcnt_active['Ticker'].str.extract('(\d{6})')
c_sh = i_fundcnt_active['ticker'].str[0].isin(['6'])
c_sz = i_fundcnt_active['ticker'].str[0].isin(['0','3'])
i_fundcnt_active.loc[c_sh,'ticker'] = i_fundcnt_active.loc[c_sh,'ticker']+'.SH'
i_fundcnt_active.loc[c_sz,'ticker'] = i_fundcnt_active.loc[c_sz,'ticker']+'.SZ'



### fund count mutual

i_fundcnt_mutual = pd.read_parquet(r'S:\TZ\EPFR\fundcnt_mutual.parquet')

i_fundcnt_mutual['ReportDate'] = pd.to_datetime(i_fundcnt_mutual['ReportDate'])
i_fundcnt_mutual['datadate'] = i_fundcnt_mutual['ReportDate']

i_fundcnt_mutual['ticker'] = i_fundcnt_mutual['Ticker'].str.extract('(\d{6})')
c_sh = i_fundcnt_mutual['ticker'].str[0].isin(['6'])
c_sz = i_fundcnt_mutual['ticker'].str[0].isin(['0','3'])
i_fundcnt_mutual.loc[c_sh,'ticker'] = i_fundcnt_mutual.loc[c_sh,'ticker']+'.SH'
i_fundcnt_mutual.loc[c_sz,'ticker'] = i_fundcnt_mutual.loc[c_sz,'ticker']+'.SZ'



### flow agg

i_flow_agg = pd.read_parquet(r'S:\TZ\EPFR\stockflow_agg.parquet')

i_flow_agg['ReportDate'] = pd.to_datetime(i_flow_agg['ReportDate'])
i_flow_agg['datadate'] = i_flow_agg['ReportDate']

i_flow_agg['ticker'] = i_flow_agg['Ticker'].str.extract('(\d{6})')
c_sh = i_flow_agg['ticker'].str[0].isin(['6'])
c_sz = i_flow_agg['ticker'].str[0].isin(['0','3'])
i_flow_agg.loc[c_sh,'ticker'] = i_flow_agg.loc[c_sh,'ticker']+'.SH'
i_flow_agg.loc[c_sz,'ticker'] = i_flow_agg.loc[c_sz,'ticker']+'.SZ'



### flow etf

i_flow_etf = pd.read_parquet(r'S:\TZ\EPFR\stockflow_etf.parquet')

i_flow_etf['ReportDate'] = pd.to_datetime(i_flow_etf['ReportDate'])
i_flow_etf['datadate'] = i_flow_etf['ReportDate']

i_flow_etf['ticker'] = i_flow_etf['Ticker'].str.extract('(\d{6})')
c_sh = i_flow_etf['ticker'].str[0].isin(['6'])
c_sz = i_flow_etf['ticker'].str[0].isin(['0','3'])
i_flow_etf.loc[c_sh,'ticker'] = i_flow_etf.loc[c_sh,'ticker']+'.SH'
i_flow_etf.loc[c_sz,'ticker'] = i_flow_etf.loc
[c_sz,'ticker']+'.SZ'



### flow mutual

i_flow_mutual = pd.read_parquet(r'S:\TZ\EPFR\stockflow_mutual.parquet')

i_flow_mutual['ReportDate'] = pd.to_datetime(i_flow_mutual['ReportDate'])
i_flow_mutual['datadate'] = i_flow_mutual['ReportDate']

i_flow_mutual['ticker'] = i_flow_mutual['Ticker'].str.extract('(\d{6})')
c_sh = i_flow_mutual['ticker'].str[0].isin(['6'])
c_sz = i_flow_mutual['ticker'].str[0].isin(['0','3'])
i_flow_mutual.loc[c_sh,'ticker'] = i_flow_mutual.loc[c_sh,'ticker']+'.SH'
i_flow_mutual.loc[c_sz,'ticker'] = i_flow_mutual.loc[c_sz,'ticker']+'.SZ'



### flow passive

i_flow_passive = pd.read_parquet(r'S:\TZ\EPFR\stockflow_passive.parquet')

i_flow_passive['ReportDate'] = pd.to_datetime(i_flow_passive['ReportDate'])
i_flow_passive['datadate'] = i_flow_passive['ReportDate']

i_flow_passive['ticker'] = i_flow_passive['Ticker'].str.extract('(\d{6})')
c_sh = i_flow_passive['ticker'].str[0].isin(['6'])
c_sz = i_flow_passive['ticker'].str[0].isin(['0','3'])
i_flow_passive.loc[c_sh,'ticker'] = i_flow_passive.loc[c_sh,'ticker']+'.SH'
i_flow_passive.loc[c_sz,'ticker'] = i_flow_passive.loc[c_sz,'ticker']+'.SZ'



### flow active

i_flow_act = pd.read_parquet(r'S:\TZ\EPFR\stockflow_active.parquet')

i_flow_act['ReportDate'] = pd.to_datetime(i_flow_act['ReportDate'])
i_flow_act['datadate'] = i_flow_act['ReportDate']

i_flow_act['ticker'] = i_flow_act['Ticker'].str.extract('(\d{6})')
c_sh = i_flow_act['ticker'].str[0].isin(['6'])
c_sz = i_flow_act['ticker'].str[0].isin(['0','3'])
i_flow_act.loc[c_sh,'ticker'] = i_flow_act.loc[c_sh,'ticker']+'.SH'
i_flow_act.loc[c_sz,'ticker'] = i_flow_act.loc[c_sz,'ticker']+'.SZ'







### pastret

i_pastret = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet',
                            columns = ['ticker', 'datadate', 'c2c_bret', 'twap1000_2c_bret','twap1000_2c_bret_t4w'])
i_pastret = i_pastret.sort_values(['ticker','datadate'])






### combine flow agg

icom = i_sd.merge(i_fundcnt_active, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_flow_agg[['ticker','datadate','CalculatedStockFlow']], on = ['ticker', 'datadate'], how = 'left')


icom = icom.merge(i_pastret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['sgnl1'] = np.nan
icom.loc[icom['FundCt']>=2, 'sgnl1'] = 1
#icom['sgnl1'] = icom.groupby('ticker')['sgnl1'].ffill(limit=60)


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-06-30')].\
            dropna(subs
et=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd)
# 0.26 / 0.099


(icom['CalculatedStockFlow']*1e6/icom['avgPVadj_USD']).hist(bins=100)
(icom['CalculatedStockFlow']*1e6/icom['avgPVadj_USD']).quantile(0.1) -4e-5
(icom['CalculatedStockFlow']*1e6/icom['avgPVadj_USD']).quantile(0.9) -4e-5

t1 = icom[icom['CalculatedStockFlow']]
icom.groupby('datadate')['CalculatedStockFlow'].apply(lambda x: x.notnull().sum()).plot()













#------------------------------------------------------------------------------
### combine flow passive + active
#------------------------------------------------------------------------------



icom = i_sd.merge(i_flow_passive, on = ['ticker', 'datadate'], how = 'left')
icom = icom.rename(columns = {'CalculatedStockFlow': 'CalculatedStockFlow_pss'})
icom = icom.drop(columns = ['Ticker'])
icom = icom.merge(i_flow_act, on = ['ticker', 'datadate'], how = 'left')
icom = icom.rename(columns = {'CalculatedStockFlow': 'CalculatedStockFlow_act'})
icom = icom.drop(columns = ['Ticker'])

icom = icom.merge(i_pastret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])



icom['pss_dv_pv'] = (icom['CalculatedStockFlow_pss'] * 1e6 / icom['avgPVadj_USD'])
icom['pss_dv_pv_rk'] = icom.groupby('datadate')['pss_dv_pv'].apply(yu.uniformed_rank)
icom['pss_dv_pv_bk'] = icom.groupby('datadate')['pss_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['pss_dv_pv_bk'], 'pss_dv_pv') # random

icom['act_dv_pv'] = (icom['CalculatedStockFlow_act'] * 1e6 / icom['avgPVadj_USD'])
icom['act_dv_pv_rk'] = icom.groupby('datadate')['act_dv_pv'].apply(yu.uniformed_rank)
icom['act_dv_pv_bk'] = icom.groupby('datadate')['act_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['act_dv_pv_bk'], 'act_dv_pv') # quite random

icom['pss_dv_pv_sm20d'] = icom.groupby('ticker').rolling(20,min_periods=1)['pss_dv_pv'].sum().values
icom['pss_dv_pv_sm20d_rk'] = icom.groupby('datadate')['pss_dv_pv_sm20d'].apply(yu.uniformed_rank)
icom['pss_dv_pv_sm20d_bk'] = icom.groupby('datadate')['pss_dv_pv_sm20d'].apply(lambda x: yu.pdqcut(x,bins=20)).values
yu.create_cn_3x3(icom, ['pss_dv_pv_sm20d_bk'], 'pss_dv_pv_sm20d') # +3 -2

icom['act_dv_pv_sm20d'] = icom.groupby('ticker').rolling(20,min_periods=1)['act_dv_pv'].sum().values
icom['act_dv_pv_sm20d_rk'] = icom.groupby('datadate')['act_dv_pv_sm20d'].apply(yu.unif
ormed_rank)
icom['act_dv_pv_sm20d_bk'] = icom.groupby('datadate')['act_dv_pv_sm20d'].apply(lambda x: yu.pdqcut(x,bins=20)).values
yu.create_cn_3x3(icom, ['act_dv_pv_sm20d_bk'], 'act_dv_pv_sm20d') # 


icom['rkdf_dv_pv_sm20d'] = icom['act_dv_pv_sm20d_rk'] - icom['pss_dv_pv_sm20d_rk']
icom['rkdf_dv_pv_sm20d_bk'] = icom.groupby('datadate')['rkdf_dv_pv_sm20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['rkdf_dv_pv_sm20d_bk'], 'rkdf_dv_pv_sm20d')


icom['pss_dv_pv_sm1q'] = icom.groupby('ticker').rolling(63,min_periods=1)['pss_dv_pv'].sum().values
icom['pss_dv_pv_sm1q_rk'] = icom.groupby('datadate')['pss_dv_pv_sm1q'].apply(yu.uniformed_rank)
icom['pss_dv_pv_sm1q_bk'] = icom.groupby('datadate')['pss_dv_pv_sm1q'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['pss_dv_pv_sm1q_bk'], 'pss_dv_pv_sm1q')



icom['twap1000_2c_bret_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)
icom['twap1000_2c_bret_t4w_bk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(lambda x: yu.pdqcut(x,bins=10)).values



yu.create_cn_3x3(icom, ['twap1000_2c_bret_t4w_bk'], 'twap1000_2c_bret_t4w')
yu.create_cn_3x3(icom[icom['pss_dv_pv_sm20d_rk']<-0.5], ['twap1000_2c_bret_t4w_bk'], 'twap1000_2c_bret_t4w')

# 

icom['sgnl1'] = np.nan
icom.loc[icom['pss_dv_pv_sm20d_rk'].le(-0.5)&icom['twap1000_2c_bret_t4w_rk'].le(-0.8), 'sgnl1'] = 1
icom['sgnl1'] = icom.groupby('ticker')['sgnl1'].ffill(limit=20)

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2018-01-01','2021-06-30')].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd)
