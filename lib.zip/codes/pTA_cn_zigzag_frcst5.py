﻿#$%^&* pTA_cn_zigzag_frcst5.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 13 13:27:09 2022

@author: thzhang
"""




import pandas as pd 
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime



# this tests alternative versions of frcst1
# use both price and seg length to run correlation
# use both corr and mae to find similar patterns



### sd 

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])


### zigzag

i_zz = pd.read_parquet(r'S:\TZ\tmp\pTA_cn_zigzag_featurepool7.parquet')

c_sh = i_zz['Ticker'].str[0].isin(['6'])
c_sz = i_zz['Ticker'].str[0].isin(['0','3'])
i_zz.loc[c_sh, 'ticker'] = i_zz.loc[c_sh, 'Ticker'] + '.SH'
i_zz.loc[c_sz, 'ticker'] = i_zz.loc[c_sz, 'Ticker'] + '.SZ'

i_zz['datadate'] = pd.to_datetime(i_zz['T-1d'])

cols = ['zz_vertex_1', 'zz_vertex_2', 'zz_vertex_3', 'zz_vertex_4',
       'zz_vertex_5', 'zz_vertex_6', 'zz_vertex_7', 'zz_vertex_8',
       'zz_vertex_9', 'zz_vertex_10', 'zz_vertex_11', 'zz_vertex_12',
       'zz_vertex_13', 'zz_vertex_14', 'zz_vertex_15']
cols_nm = [c+'_nm' for c in cols]
cols_nm = [c+'_nm' for c in cols]
i_zz['range'] = i_zz[cols+['c']].max(axis=1) - i_zz[cols+['c']].min(axis=1)
i_zz[cols_nm] = i_zz[cols].sub(i_zz[cols+['c']].min(axis=1),axis=0).divide(i_zz['range'], axis = 0)
i_zz['zz_vertex_fut1_nm'] = (i_zz['zz_vertex_fut1'] - i_zz[cols].min(axis=1)) / i_zz['range']
i_zz['c_nm'] = (i_zz['c'] - i_zz[cols+['c']].min(axis=1)) / i_zz['range']

i_zz = i_zz[i_zz['zz_vertex_7'].notnull()]


from numba import njit, prange
@njit(parallel=True)
def numba_corr(matrix_1, matrix_2, matrix_3, matrix_4):
    # both matrix 1 and 2 must have at least 2 rows
    # matrix 1 is current; matrix 2 is history and future
    # matrix 3 and 4 are for seg length
    matrix_2_hist = matrix_2[:, :matrix_2.shape[1]-1]
    matrix_2_fut = matrix_2[:, matrix_2.shape[1]-1]
    
    # loop thru left targets
    lst_frcst = [[0.0, 0.0]]*0
    for n in range(len(matrix_1)):
        
        # current left target
        array_1 = matrix_1[n,:]
        array_1_0 = array_1[0]
                
        # select right history 
        if len(array_1[~np.isnan(array_1)])<14:
            lst_frcst.append([np.nan, np.nan])
            continue
        
        c_notnan = (~np.isnan(array_1))        
        array_1_s2 = array_1[c_notnan]
        matrix_2_hist_s2 = matrix_2_hist[:,c_notnan]
        
        array_3_s2 = matrix_3[n,:]
        
        
                
        # loop thru 
right history, and calc correlation
        lst_corr = [0.0]*0
        lst_mae = [0.0]*0
        lst_len_corr = [0.0]*0
        
        array_1_s2_mean = np.mean(array_1_s2)
        array_1_s2_demean = array_1_s2 - array_1_s2_mean
        array_1_s2_demean2 = array_1_s2_demean**2
        
        array_1_s2_std = np.sqrt(np.sum(array_1_s2_demean2))
        
        array_3_s2_mean = np.mean(array_3_s2)
        array_3_s2_demean = array_3_s2 - array_3_s2_mean
        array_3_s2_demean2 = array_3_s2_demean**2
        
        array_3_s2_std = np.sqrt(np.sum(array_3_s2_demean2))
        
        for r in prange(len(matrix_2_hist_s2)):
            matrix_2_hist_s2_r = matrix_2_hist_s2[r,:]
            array_2_s2_mean = np.mean(matrix_2_hist_s2_r)
            array_2_s2_demean = matrix_2_hist_s2_r - array_2_s2_mean
            array_2_s2_demean2 = array_2_s2_demean**2            
            lst_corr.append(np.dot(array_2_s2_demean, array_1_s2_demean) / array_1_s2_std / np.sqrt(np.sum(array_2_s2_demean2)))
            lst_mae.append(np.nanmean(np.abs(array_1_s2 - matrix_2_hist_s2_r)))
            
            matrix_4_r = matrix_4[r,:]
            array_4_s2_mean = np.mean(matrix_4_r)
            array_4_s2_demean = matrix_4_r - array_4_s2_mean
            array_4_s2_demean2 = array_4_s2_demean**2
            lst_len_corr.append(np.dot(array_4_s2_demean, array_3_s2_demean) / array_3_s2_std / np.sqrt(np.sum(array_4_s2_demean2)))
            
        
        # analyze 
        arr_corr = np.array(lst_corr)
        c_gud_corr = arr_corr>0.95
        
        arr_mae = np.array(lst_mae)
        c_gud_mae = arr_mae<0.1
        
        arr_len_corr = np.array(lst_len_corr)
        c_gud_len_corr = arr_len_corr>0.7
        
        c_gud_corrmaelen = c_gud_corr & c_gud_mae & c_gud_len_corr
        
        if np.sum(c_gud_corrmaelen) >= 2:
            tobemedian = array_1_0 + matrix_2_fut[c_gud_corrmaelen] - matrix_2_hist_s2[c_gud_corrmaelen,0]
            tobemedian = tobemedian[~np.isnan(tobemedian)]
            lst_frcst.append([np.median(tobemedian), np.sum(c_gud_corrmaelen)])
        else:
            lst_frcst.append([np.nan, np.nan])
            
    return np.array(lst_frcst)
            



    
o_zz_frcst = []
cols_seg = ['seg_len_idx1', 'seg_len_idx2', 'seg_len_idx3', 'seg_len_idx4', 'seg_len_idx5',
           'seg_len_idx6', 'seg_len_idx7', 'seg_len_idx8', 'seg_len_idx9', 'seg_len_idx10', 
           'seg_len_idx11', 'seg_len_idx12', 'seg_len_idx13', 's
eg_len_idx14']

for dd in i_sd[i_sd['datadate'].dt.year.isin([2021])&i_sd['datadate'].dt.month.between(1,12)]['datadate'].sort_values().drop_duplicates():
    print(dd.strftime('%Y%m%d'))
    print(datetime.datetime.now().strftime('%H%M%S'))
    
    t_sd = i_sd[i_sd['datadate']==dd]
    
    t_zz_hist = i_zz[i_zz['datadate'].lt(dd) & i_zz['zz_date_fut1'].lt(dd) & i_zz['datadate'].gt(dd-pd.to_timedelta('730 days'))]
    t_zz_hist = t_zz_hist[t_zz_hist['zz_vertex_15'].notnull()]
    t_zz_hist = t_zz_hist[cols_nm+cols_seg+['zz_vertex_fut1_nm']].drop_duplicates()
    t_zz_hist_mx2 = t_zz_hist[cols_nm+['zz_vertex_fut1_nm']].values
    t_zz_hist_mx4 = t_zz_hist[cols_seg].values
    
    t_zz_curr = i_zz[i_zz['datadate'].eq(dd) & i_zz['ticker'].isin(t_sd['ticker'].tolist())]
    t_zz_curr = t_zz_curr[['ticker','datadate']+cols_nm+cols_seg]
    
    
    s_zz_curr = pd.DataFrame(numba_corr(t_zz_curr[cols_nm].values, t_zz_hist_mx2,t_zz_curr[cols_seg].values,t_zz_hist_mx4), columns =  ['frcst','sample_cnt'])
    s_zz_curr['ticker'] = t_zz_curr['ticker'].tolist()
    s_zz_curr['datadate'] = t_zz_curr['datadate'].tolist()
    
    o_zz_frcst.append(s_zz_curr)

o_zz_frcst = pd.concat(o_zz_frcst, axis=0)
o_zz_frcst.to_parquet(r'S:\TZ\tmp\pTA_cn_zigzag_frcst5_21.parquet')






o_zz_frcst = pd.concat([pd.read_parquet(r'S:\TZ\tmp\pTA_cn_zigzag_frcst_v8b_17.parquet'),
                        pd.read_parquet(r'S:\TZ\tmp\pTA_cn_zigzag_frcst_v8b_18.parquet'),
                        pd.read_parquet(r'S:\TZ\tmp\pTA_cn_zigzag_frcst_v8b_19a.parquet'),
                        pd.read_parquet(r'S:\TZ\tmp\pTA_cn_zigzag_frcst_v8b_19b.parquet'),
                        pd.read_parquet(r'S:\TZ\tmp\pTA_cn_zigzag_frcst_v8b_20a.parquet'),
                        pd.read_parquet(r'S:\TZ\tmp\pTA_cn_zigzag_frcst_v8b_20b.parquet'),
                        pd.read_parquet(r'S:\TZ\tmp\pTA_cn_zigzag_frcst_v8b_21a.parquet'),
                        pd.read_parquet(r'S:\TZ\tmp\pTA_cn_zigzag_frcst_v8b_21b.parquet')],
                        axis=0)














#------------------------------------------------------------------------------






### combine

icom = i_sd.merge(o_zz_frcst, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_zz, on = ['ticker', 'datadate'], how = 'left')

i_daily_dir = icom.groupby('datadate')['zz_curr_trend'].sum().reset_index()
i_daily_dir = i_daily_dir.rename(columns = {'zz_curr_trend': 'sum_dir'})
icom = icom.merge(i_daily_dir, on = 'datadate', how =
 'left')





### naive



icom['m1'] = (icom['frcst'] - icom['c_nm']) / (icom['c_nm'] + icom['frcst']) * 2 * icom['range']
icom['m1'] = icom['m1'].replace(np.inf, np.nan).replace(-np.inf,np.nan)
icom.loc[icom['frcst']>1,'m1'] = np.nan
icom.loc[icom['frcst']<0,'m1'] = np.nan
icom.loc[icom['sample_cnt']>20, 'm1'] = np.nan
icom['m1_bk'] = icom.groupby('datadate')['m1'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['m1_rk'] = icom.groupby('datadate')['m1'].apply(yu.uniformed_rank)
yu.create_cn_3x3(icom[['ticker','datadate','m1','m1_bk','avgPVadj_USD','volatility','spread',
                       'BarrRet_CLIP_USD+1d','BarrRet_SRISK_USD+1d']], ['m1_bk'], 'm1')
# mono: -3 +4.5


o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-01-01','2021-12-30'))].\
            dropna(subset=['m1_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'm1_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2018-01-01','2021-12-30') & icom['m1_rk'].abs().gt(0.8)].\
            dropna(subset=['m1_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'm1_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)


### naive - up trend


icom['m1'] = (icom['frcst'] - icom['c_nm']) / (icom['frcst'] + icom['c_nm'])
# icom['m1'] = icom['m1'].replace(np.inf, np.nan).replace(-np.inf,np.nan)
icom.loc[icom['sample_cnt']>100, 'm1'] = np.nan
icom.loc[icom['zz_curr_trend']!=1, 'm1'] = np.nan
icom['m1_bk'] = icom.groupby('datadate')['m1'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['m1_rk'] = icom.groupby('datadate')['m1'].apply(yu.uniformed_rank)
yu.create_cn_3x3(icom[['ticker','datadate','m1','m1_bk','avgPVadj_USD','volatility','spread',
                       'BarrRet_CLIP_USD+1d','BarrRet_SRISK_USD+1d']], ['m1_bk'], 'm1')
# mono: -3 +5


### naive - up trend
# less mono 


### up trend ex. break thru

icom['m1'] = (icom['frcst'] - icom['c_nm']) / icom['c_nm']
icom['m1'] = icom['m1'].replace(np.inf, np.nan).replace(-np.inf,np.nan)
icom.loc[icom['sample_cnt']>100, 'm1'] = np.nan
icom.loc[icom['zz_curr_trend']!=1, 'm1'] = np.nan
icom.loc[icom['c_nm']==1 , 'm1'] = np.nan

icom['m1_bk'] = icom.groupby('datadate')['m1'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['m1_rk'] = icom.groupby('datadate')['m1'].apply(yu.uniformed_rank)
yu.create_cn_3x3(icom[['ticker','datadate','m1','m1_bk','avgPVadj_USD','volatility','spread',
                       'BarrRet_CLIP_USD+1d','BarrRet_S
RISK_USD+1d']], ['m1_bk'], 'm1')
# mono: -3.5 +4.5

icomind = pd.get_dummies(icom['GIND'])
icom = pd.concat([icom, icomind], axis = 1)
cols_i = icomind.columns.tolist()
cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']
icom['m1_orth'] = icom.groupby('datadate')[cols_i+cols_f+['m1','SRISK']].apply(lambda x: yu.orthogonalize_cn_v3(x['m1'], x[cols_f], x[cols_i], x['SRISK'])).values


icom['m1_orth_bk'] = icom.groupby('datadate')['m1_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['m1_orth_rk'] = icom.groupby('datadate')['m1_orth'].apply(yu.uniformed_rank)
yu.create_cn_3x3(icom[['ticker','datadate','m1','m1_orth_bk','avgPVadj_USD','volatility','spread',
                       'BarrRet_CLIP_USD+1d','BarrRet_SRISK_USD+1d']], ['m1_orth_bk'], 'm1')



### pulse long sgnl

icom['sgnl_up'] = np.nan
c1 =  icom['zz_curr_trend'].eq(1) & icom.groupby('ticker')['zz_curr_trend'].shift().eq(-1)
c2 = (icom['frcst'] > icom['c_nm'] + 0.1)
#c4 = icom['sum_dir'] <200
icom.loc[c1 & c2 , 'sgnl_up'] = 1
c3 = icom['zz_curr_trend'].eq(-1)
icom.loc[c3, 'sgnl_up'] = 0
icom['sgnl_up'] = icom.groupby('ticker')['sgnl_up'].ffill()


o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-01-01','2021-12-31'))].\
            dropna(subset=['sgnl_up','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_up','BarrRet_CLIP_USD+1d', static_data = i_sd)

t1 = o_1.groupby('ticker')['pnl_ac'].sum()
t1 = icom[icom.ticker=='002185.SZ']





icom['sgnl_dn'] = np.nan
c1 =  icom['zz_curr_trend'].eq(-1) & icom.groupby('ticker')['zz_curr_trend'].shift().eq(1)
c2 = (icom['frcst'] < icom['c_nm'] - 0.1)
c4 = icom['sum_dir'] >-200
icom.loc[c1 & c2 & c4, 'sgnl_dn'] = -1
c3 = icom['zz_curr_trend'].eq(1)
icom.loc[c3, 'sgnl_dn'] = 0
icom['sgnl_dn'] = icom.groupby('ticker')['sgnl_dn'].ffill()


o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-01-01','2021-12-31'))].\
            dropna(subset=['sgnl_dn','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_dn','BarrRet_CLIP_USD+1d', static_data = i_sd)

