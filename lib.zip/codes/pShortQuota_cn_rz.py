﻿#$%^&* pShortQuota_cn_rz.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Aug  8 18:48:06 2022

@author: thzhang
"""




import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime
import os
import pathlib


# this studies all types of short interest data



### sd 

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['ticker', 'datadate'])


i_sd_ss = pw.get_china_ss_sd()
i_sd_ss = i_sd_ss.sort_values(['ticker', 'datadate'])



### c

i_c = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                 s_dq_close as c 
                 from wind_prod.dbo.ashareeodprices 
                 where trade_dt >= '20160101' ''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format = '%Y%m%d')



### hl index

i_hlidx = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                 s_dq_adjclose as cadj
                 from wind_prod.dbo.ashareeodprices 
                 where trade_dt >= '20150101' ''')
i_hlidx['datadate'] = pd.to_datetime(i_hlidx['datadate'], format = '%Y%m%d')
i_hlidx = i_hlidx.sort_values(['ticker', 'datadate'])
i_hlidx['cadj_t2ymax'] = i_hlidx.groupby('ticker').rolling(504)['cadj'].max().values
i_hlidx['cadj_t2ymin'] = i_hlidx.groupby('ticker').rolling(504)['cadj'].min().values
i_hlidx['hlidx'] = (i_hlidx['cadj'] - i_hlidx['cadj_t2ymin']) / (i_hlidx['cadj_t2ymax'] - i_hlidx['cadj_t2ymin'])

i_hlidx = i_hlidx[['ticker', 'datadate', 'hlidx']]






### get rongzi 

i_rz = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                  S_MARGIN_TRADINGBALANCE, S_MARGIN_PURCHWITHBORROWMONEY,S_MARGIN_REPAYMENTTOBROKER          
                  from wind.dbo.AShareMarginTrade ''')
i_rz['datadate'] = pd.to_datetime(i_rz['datadate'], format = '%Y%m%d')




### get rongzi tickers

i_rz_tk = pw.get_stock_levbuy_list()



### reversal

i_pastret = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet',
                            columns = ['ticker', 'datadate', 'twap1000_2c_bret', 'twap1000_2c_bret_t4w'])
i_pastret = i_pastret.sort_values(['ticker','datadate'])

i_pastret['twap1000_2c_bret_t1y'] = i_pastret.groupby('ticker').rolling(252)['twap1000_2c_bret'].mean().values









#------------------------------------------------------------------------------
### combine
#------------------------------------------------------------------------------



icom = i_sd.merge(i_rz, on = ['ticker', 
'datadate'], how = 'left')
icom = icom.merge(i_rz_tk, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_c, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_pastret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_hlidx, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])


icom['o2c_t4w_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(yu.uniformed_rank)
icom['o2c_t4w_bk'] = icom.groupby('datadate')['twap1000_2c_bret_t4w'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['o2c_t1y_rk'] = icom.groupby('datadate')['twap1000_2c_bret_t1y'].apply(yu.uniformed_rank)
icom['o2c_t1y_bk'] = icom.groupby('datadate')['twap1000_2c_bret_t1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values


icom = icom[icom['flg_rz']==1]
icom['S_MARGIN_TRADINGBALANCE'] = icom['S_MARGIN_TRADINGBALANCE'].fillna(0)
icom['S_MARGIN_PURCHWITHBORROWMONEY'] = icom['S_MARGIN_PURCHWITHBORROWMONEY'].fillna(0)








### benchmark: rzbal / so

icom['rzbal_dv_so'] = icom['S_MARGIN_TRADINGBALANCE'] / icom['c'] / icom['FLOAT_l1d'] # this is mktcap biased
COLS = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL','GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']
icom['rzbal_dv_so_orth'] = icom.groupby('datadate')[COLS+['SRISK']+['rzbal_dv_so']].apply(lambda x: yu.orthogonalize_cn_v2(x['rzbal_dv_so'], x[COLS], x['SRISK'])).values
icom['rzbal_dv_so_orth_bk'] = icom.groupby('datadate')['rzbal_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['rzbal_dv_so_bk'] = icom.groupby('datadate')['rzbal_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['rzbal_dv_so_bk'], 'rzbal_dv_so') # random
yu.create_cn_3x3(icom, ['rzbal_dv_so_orth_bk'], 'rzbal_dv_so_orth') # random

icom['flg_high_rzbal'] = np.nan
icom.loc[icom['rzbal_dv_so_orth_bk']==9, 'flg_high_rzbal'] = 1

yu.create_cn_decay(icom, 'flg_high_rzbal') # very -ve before, no alpha after

icom['flg_p25_rzbal'] = np.nan
icom.loc[icom['rzbal_dv_so']>0.20, 'flg_p25_rzbal'] = 1
icom['sgnl_p25_rzbal'] = icom.groupby('ticker')['flg_p25_rzbal'].ffill(limit=63)

yu.create_cn_decay(icom, 'flg_p25_rzbal') # sample too small: 98, so 2k universe testing doesn't matter


yu.create_cn_3x3(icom, ['o2c_t4w_bk'], 'twap1000_2c_bret_t4w') # mono: +6.8 -8
yu.create_cn_3x3(icom[icom['rzbal_dv_so_bk']==9], ['o2c_t4w_bk'], 'twap1000_2c_bret_t4w') # less mono: 22 -8
yu.create_cn_3x3(icom[icom['rzbal_dv_so_orth_bk']==0], ['o2c_t4w_bk'], 'twap1000_2c_bret_t
4w') # 0 +8 -9
yu.create_cn_3x3(icom[icom['rzbal_dv_so_orth_bk']==9], ['o2c_t4w_bk'], 'twap1000_2c_bret_t4w') # random, but lowest bk has 9bp +ve ret







### benchmark: rzbal / avgPVadj

icom['rzbal_dv_avgpv'] = icom['S_MARGIN_TRADINGBALANCE'].divide(icom['avgPVadj'])
COLS = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL','GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']
icom['rzbal_dv_avgpv_orth'] = icom.groupby('datadate')[COLS+['SRISK']+['rzbal_dv_avgpv']].apply(lambda x: yu.orthogonalize_cn_v2(x['rzbal_dv_avgpv'], x[COLS], x['SRISK'])).values
icom['rzbal_dv_avgpv_orth_bk'] = icom.groupby('datadate')['rzbal_dv_avgpv_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['rzbal_dv_avgpv_bk'] = icom.groupby('datadate')['rzbal_dv_avgpv'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['rzbal_dv_avgpv_bk'], 'rzbal_dv_avgpv', col_ret='RawRet_USD+1d') # random
yu.create_cn_3x3(icom, ['rzbal_dv_avgpv_bk'], 'rzbal_dv_avgpv') # a shaped: -6 +3 0 +3 -1
yu.create_cn_3x3(icom, ['rzbal_dv_avgpv_orth_bk'], 'rzbal_dv_avgpv_orth')  # -5.5 +2.5 0



### benchmark: rzbuy / pv

icom['rzbuy_dv_pv'] = icom['S_MARGIN_PURCHWITHBORROWMONEY'].divide(icom['PV_l1d']) # this is mktcap biased
COLS = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL','GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']
icom['rzbuy_dv_pv_orth'] = icom.groupby('datadate')[COLS+['SRISK']+['rzbuy_dv_pv']].apply(lambda x: yu.orthogonalize_cn_v2(x['rzbuy_dv_pv'], x[COLS], x['SRISK'])).values
icom['rzbuy_dv_pv_orth_bk'] = icom.groupby('datadate')['rzbuy_dv_pv_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['rzbuy_dv_pv_bk'] = icom.groupby('datadate')['rzbuy_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=100)).values

yu.create_cn_3x3(icom, ['rzbuy_dv_pv_orth_bk'], 'rzbuy_dv_pv_orth') # -6 +2 0
yu.create_cn_3x3(icom, ['rzbuy_dv_pv_bk'], 'rzbuy_dv_pv') #-2.5 +2 0

icom.loc[icom['rzbuy_dv_pv_bk']==99, 'flg_100th'] = 1
yu.create_cn_decay(icom, 'flg_100th') # no alpha

icom['rzbuy_dv_pv_t20d'] = icom.groupby('ticker').rolling(20)['rzbuy_dv_pv'].mean().values
icom['rzbuy_dv_pv_t20d_bk'] = icom.groupby('datadate')['rzbuy_dv_pv_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['rzbuy_dv_pv_t20d_bk'], 'rzbuy_dv_pv_t20d') # -3 +2 0, close to random

yu.create_cn_3x3(icom[icom['rzbuy_dv_pv_orth_bk']==0], ['o2c_t4w_bk'], 'twap1000_2c_bret_t4w') # -10 +5 -32
yu.create_cn_3x3(icom[icom['rzbuy_dv_pv_orth_bk']==9], ['o2c_t4w_bk'], 'twap1000_2c_bret_t4w') # less mo
no: +17 -8 -3





### benchmark: rzrepay / pv
# repay has 94% corr with buy

icom['rzrepay_dv_pv'] = icom['S_MARGIN_REPAYMENTTOBROKER'].divide(icom['PV_l1d']) # this is mktcap biased
COLS = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL','GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']
icom['rzrepay_dv_pv_orth'] = icom.groupby('datadate')[COLS+['SRISK']+['rzrepay_dv_pv']].apply(lambda x: yu.orthogonalize_cn_v2(x['rzrepay_dv_pv'], x[COLS], x['SRISK'])).values
icom['rzrepay_dv_pv_orth_bk'] = icom.groupby('datadate')['rzrepay_dv_pv_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['rzrepay_dv_pv_bk'] = icom.groupby('datadate')['rzrepay_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['rzrepay_dv_pv_orth_bk'], 'rzrepay_dv_pv_orth') # -5 +2 0
yu.create_cn_3x3(icom, ['rzrepay_dv_pv_bk'], 'rzrepay_dv_pv') # random

yu.create_cn_3x3(icom[icom['rzrepay_dv_pv_orth_bk']==9], ['o2c_t4w_bk'], 'twap1000_2c_bret_t4w') # less mono: 15 -14 -3






### benchmark: (buy - repay) / PV

icom['net_dv_pv'] = (icom['S_MARGIN_PURCHWITHBORROWMONEY'] - icom['S_MARGIN_REPAYMENTTOBROKER']) / icom['PV_l1d']
icom['net_dv_pv_bk'] = icom.groupby('datadate')['net_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['net_dv_pv_100bk'] = icom.groupby('datadate')['net_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=100)).values

yu.create_cn_3x3(icom, ['net_dv_pv_bk'], 'net_dv_pv') # random: 0.5 +2 -2 +2

yu.create_cn_3x3(icom, ['net_dv_pv_100bk'], 'net_dv_pv') # 

icom['flg_high_net'] == np.nan
icom.loc[icom['net_dv_pv_100bk'] >= 95, 'flg_high_net'] = 1

icom['flg_high_net_low_o2c'] = np.nan
icom.loc[(icom['flg_high_net']==1)&(icom['o2c_t4w_bk']==0),'flg_high_net_low_o2c'] = 1

icom['sgnl_high_net_low_o2c'] = icom.groupby('ticker')['flg_high_net_low_o2c'].ffill(limit = 20)
yu.create_cn_decay(icom, 'flg_high_net')
yu.create_cn_decay(icom[icom['o2c_t4w_bk']<=4], 'flg_high_net')

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-06-30'))].\
            dropna(subset=['sgnl_high_net_low_o2c','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_net_low_o2c','BarrRet_CLIP_USD+1d', static_data = i_sd) #0.23/-0.19
o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2021-06-30')) & (icom['o2c_t4w_bk']<1)].\
            dropna(subset=['sgnl_high_net_low_o2c','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_high_net_low_o2c','BarrRet_CLIP_USD+1d', static_data = i_sd) #0.8/0.63
