﻿#$%^&* pDataYes_recruit_s2.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Sep  2 20:38:06 2021

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import zipfile
import csv

import jieba



# this analyzes the string data in job desc
# s2 analyzes number of word segemtns


### get ind

i_ind = yu.get_sql('''select datadate, ticker, gsector, ggrop, gind, gsubind 
                   FROM [CNDB].[dbo].[UNIVERSE_ALL_CN]
                   where datadate >= '2016-01-01' ''')
c_sh = i_ind['ticker'].str[0].isin(['6'])
c_sz = i_ind['ticker'].str[0].isin(['3','0'])
i_ind.loc[c_sh, 'ticker'] = i_ind.loc[c_sh, 'ticker'] + '.SH'
i_ind.loc[c_sz, 'ticker'] = i_ind.loc[c_sz, 'ticker'] + '.SZ'


### get sd
i_sd = pw.get_ashare_hk_sd_v2()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','a50_300_flag','a50_flag']]

i_sd_map_300 =i_sd_map[i_sd_map['a50_300_flag']==1]
i_sd_datadate_sr = i_sd_map_300['datadate'].drop_duplicates()
i_sd_map_50  = i_sd_map[i_sd_map['a50_flag']==1]



#--------------------------------------------------

### Create segments per row


i_files = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\txt_w_tk')
i_str = pd.concat(pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\txt_w_tk',f)) for f in i_files)


i_str['fuli_clean'] = i_str['fuli'].str.replace('\(.*\)','').str.replace('（.*）','').\
                     str.replace('\d+、',' ').str.replace('\d+\.',' ').\
                     str.replace('\[.*\]','').str.replace('\【.*\】','').\
                     str.replace('（|）|,|，|\.|。|:|：|;|；|\(|\)|\*|~|`|!|@|#|$|&|-|—|\+|\/|、|\?',' ').\
                     str.strip().str.replace('[ ]+', ' ').\
                     str.upper()
i_str['fuli_clean'] = i_str['fuli_clean'].fillna('')
i_str['fuli_seg'] = i_str['fuli_clean'].apply(lambda x: '@'.join( list(set(jieba.cut(x))) ))


i_str['jd_clean'] = i_str['job_desc'].str.replace('\(.*\)','').str.replace('（.*）','').\
                     str.replace('\d+、',' ').str.replace('\d+\.',' ').\
                     str.replace('\[.*\]','').str.replace('\【.*\】','').\
                     str.replace('（|）|,|，|\.|。|:|：|;|；|\(|\)|\*|~|`|!|@|#|$|&|-|—|\+|\/|、|\?',' ').\
                    
 str.strip().str.replace('[ ]+', ' ').\
                     str.upper()
i_str['jd_clean'] = i_str['jd_clean'].fillna('')
i_str['jd_seg'] = i_str['jd_clean'].apply(lambda x: '@'.join( list(set(jieba.cut(x))) ))


### Calculate trailing 1 year metrics

i_t1y = pd.DataFrame()
for dt in pd.date_range(start = '2017-01-01', end = '2020-05-31'):
    print('.', end='')
    t_str = i_str[i_str['datadate'].between(dt-pd.to_timedelta('365 days'), dt)]
    
    #t_fuli = t_str.groupby('ticker')['fuli_seg'].apply(lambda x:  len(set('@'.join(x.tolist()).split('@'))) ).reset_index()
    #t_fuli = t_fuli.rename(columns = {'fuli_seg': 'fuli_seg_cnt'})
    
    t_jd = t_str.groupby('ticker')['jd_seg'].apply(lambda x:  len(set('@'.join(x.tolist()).split('@'))) ).reset_index()
    t_jd = t_jd.rename(columns={'jd_seg': 'jd_seg_cnt'})
    
    #t_jd = t_jd.merge(t_fuli, on = ['ticker'], how = 'outer')
    t_jd['datadate'] = dt
    i_t1y = i_t1y.append(t_jd, sort = False)
    
    t_str = None





i_t1y['datadate_l1y'] = i_t1y['datadate'] - pd.to_timedelta('365 days')
i_t1y = i_t1y.merge(i_t1y[['ticker','datadate','jd_seg_cnt']], 
                    left_on = ['ticker', 'datadate_l1y'],
                    right_on = ['ticker', 'datadate'], 
                    how = 'left', suffixes = ['', '_1y'])
i_t1y = i_t1y.drop(columns = ['datadate_l1y','datadate_1y'])


i_t1y['datadate_l1q'] = i_t1y['datadate'] - pd.to_timedelta('91 days')
i_t1y = i_t1y.merge(i_t1y[['ticker','datadate','jd_seg_cnt']], 
                    left_on = ['ticker', 'datadate_l1q'],
                    right_on = ['ticker', 'datadate'], 
                    how = 'left', suffixes = ['', '_1q'])
i_t1y = i_t1y.drop(columns = ['datadate_l1q','datadate_1q'])



### Calculate trailing 1 q metrics

i_t1q = pd.DataFrame()
for dt in pd.date_range(start = '2017-01-01', end = '2020-05-31'):
    print('.', end='')
    t_str = i_str[i_str['datadate'].between(dt-pd.to_timedelta('91 days'), dt)]
    
    #t_fuli = t_str.groupby('ticker')['fuli_seg'].apply(lambda x:  len(set('@'.join(x.tolist()).split('@'))) ).reset_index()
    #t_fuli = t_fuli.rename(columns = {'fuli_seg': 'fuli_seg_cntQ'})
    t_jd = t_str.groupby('ticker')['jd_seg'].apply(lambda x:  len(set('@'.join(x.tolist()).split('@'))) ).reset_index()
    t_jd = t_jd.rename(columns = {'jd_seg': 'jd_seg_cntQ'})
    
    #t_metrics = t_fuli.merge(t_jd, on = ['ticker'], how = 'outer')
    t_jd['datadate'] = dt
    i_t1q = i_t1q.append(t_jd, sort = False)
    
    t_str
 = None

i_t1q['datadate_l1y'] = i_t1q['datadate'] - pd.to_timedelta('365 days')
i_t1q = i_t1q.merge(i_t1q[['ticker','datadate','jd_seg_cntQ']], 
                    left_on = ['ticker', 'datadate_l1y'],
                    right_on = ['ticker', 'datadate'], 
                    how = 'left', suffixes = ['', '_1y'])
i_t1q = i_t1q.drop(columns = ['datadate_l1y','datadate_1y'])

i_t1q['datadate_l1q'] = i_t1q['datadate'] - pd.to_timedelta('91 days')
i_t1q = i_t1q.merge(i_t1q[['ticker','datadate','jd_seg_cntQ']], 
                    left_on = ['ticker', 'datadate_l1q'],
                    right_on = ['ticker', 'datadate'], 
                    how = 'left', suffixes = ['', '_1q'])
i_t1q = i_t1q.drop(columns = ['datadate_l1q','datadate_1q'])


### MC

i_mc = yu.get_sql('''select ticker, datadate, mc from [CNDB].[dbo].[UNIVERSE_ALL_CN] 
                    where ticker in ('{0}') '''.format("','".join( i_sd_map['ticker'].str[:6].unique().tolist() )))
i_mc['datadate_1y'] = i_mc['datadate'] - pd.to_timedelta('365 days')
i_mc['datadate_1q'] = i_mc['datadate'] - pd.to_timedelta('91 days')


i_mc = i_mc.sort_values('datadate')

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1q', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1q'})

i_mc = pd.merge_asof(i_mc, i_mc[['datadate','ticker','mc']],
                     by = 'ticker', left_on = 'datadate_1y', right_on = 'datadate',
                     suffixes = ['','_merge'])
i_mc = i_mc.drop(columns = ['datadate_merge'])
i_mc = i_mc.rename(columns = {'mc_merge': 'mc_1y'})
i_mc = i_mc.drop(columns = ['datadate_1q', 'datadate_1y'])


c_sh = i_mc['ticker'].str[0].isin(['6'])
c_sz = i_mc['ticker'].str[0].isin(['0', '3'])
i_mc.loc[c_sz, 'ticker'] = i_mc.loc[c_sz, 'ticker'] + '.SZ'
i_mc.loc[c_sh, 'ticker'] = i_mc.loc[c_sh, 'ticker'] + '.SH'


### combine
icom = i_sd_map[i_sd_map['a50_300_flag']==1].merge(i_t1y, on = ['ticker', 'datadate'], how = 'left') ###??? here is the problem: i_t1y is 300, i_sd_map is hk uni 
icom = icom.merge(i_t1q, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_mc, on = ['ticker', 'datadate'], how = 'left')


### backtest

icom2 = icom.copy()


icom2['jd_df1y'] = icom2['jd_seg_cnt'] - icom2['jd_seg_cnt_1y']
icom2['jd_df1y_dv_mc'] = icom2['jd_df1y'].divide(icom2['mc_1y'])
icom2['jd_df_rk'] = icom2.groupby
('datadate')['jd_df1y'].apply(yu.uniformed_rank).values
icom2['jd_df_bk'] = icom2.groupby('datadate')['jd_df1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['jd_df1y_dv_mc_rk'] = icom2.groupby('datadate')['jd_df1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['jd_df1y_dv_mc_bk'] = icom2.groupby('datadate')['jd_df1y_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values


icom2['jd_df1q'] = icom2['jd_seg_cnt'] - icom2['jd_seg_cnt_1q']
icom2['jd_df1q_rk'] = icom2.groupby('datadate')['jd_df1q'].apply(yu.uniformed_rank).values
icom2['jd_df1q_bk'] = icom2.groupby('datadate')['jd_df1q'].apply(lambda x: yu.pdqcut(x,bins=10)).values


icom2['jd_yy'] = icom2['jd_seg_cnt'].divide(icom2['jd_seg_cnt_1y'])-1
icom2['jd_yy_rk'] = icom2.groupby('datadate')['jd_yy'].apply(yu.uniformed_rank).values
icom2['jd_yy_bk'] = icom2.groupby('datadate')['jd_yy'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['jd_yy_secrk'] = icom2.groupby(['datadate','GSECTOR'])['jd_yy'].apply(yu.uniformed_rank).values
icom2['jd_yy_secbk'] = icom2.groupby(['datadate','GSECTOR'])['jd_yy'].apply(lambda x: yu.pdqcut(x,bins=10)).values


icom2['jd_qq'] = icom2['jd_seg_cntQ'].divide(icom2['jd_seg_cntQ_1q'])-1
icom2['jd_qq_rk'] = icom2.groupby('datadate')['jd_qq'].apply(yu.uniformed_rank).values
icom2['jd_qq_bk'] = icom2.groupby('datadate')['jd_qq'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom2['jd_yqq'] = icom2['jd_seg_cntQ'].divide(icom2['jd_seg_cntQ_1y'])-1
icom2['jd_yqq_rk'] = icom2.groupby('datadate')['jd_yqq'].apply(yu.uniformed_rank).values
icom2['jd_yqq_bk'] = icom2.groupby('datadate')['jd_yqq'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom2['jd_yqq_secrk'] = icom2.groupby(['datadate','GSECTOR'])['jd_yqq'].apply(yu.uniformed_rank).values
icom2['jd_yqq_secbk'] = icom2.groupby(['datadate','GSECTOR'])['jd_yqq'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom2['jd_dfq1y'] = icom2['jd_seg_cntQ'] - icom2['jd_seg_cntQ_1y']
icom2['jd_dfq1y_dv_mc'] = icom2['jd_dfq1y'].divide(icom2['mc_1y'])
icom2['jd_dfq1y_dv_mc_rk'] = icom2.groupby('datadate')['jd_dfq1y_dv_mc'].apply(yu.uniformed_rank).values
icom2['jd_dfq1y_dv_mc_bk'] = icom2.groupby('datadate')['jd_dfq1y_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values


yu.create_cn_3x3(icom2, ['fuli_bk'], 'fuli_seg')
yu.create_cn_3x3(icom2, ['fuli_df_bk'], 'fuli_df')
yu.create_cn_3x3(icom2, ['fuli_yy_bk'], 'fuli_yy')
yu.create_cn_3x3(icom2, ['fuli_yy_secbk'], 'fuli_yy')

yu.create_cn_3x3(icom2, ['jd_df_bk'], 'jd_df')

yu.create_cn_3x3(icom2, [
'jd_yy_bk'], 'jd_yy')
yu.create_cn_3x3(icom2, ['jd_qq_bk'], 'jd_qq')
yu.create_cn_3x3(icom2, ['jd_yqq_bk'], 'jd_yqq')
yu.create_cn_3x3(icom2, ['jd_yqq_secbk'], 'jd_yqq')



o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['jd_yy_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jd_yy_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.75 / 1.04

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['jd_yy_secrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jd_yy_secrk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.75 / 0.9
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['jd_yy_secrk']>0.6)].\
            dropna(subset=['jd_yy_secrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jd_yy_secrk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.2 / 1.6

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['jd_qq_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jd_qq_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.44 / -1.04

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['jd_yqq_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jd_yqq_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.45 / 1.28

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['jd_yqq_secrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jd_yqq_secrk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.77 / 1.36
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['jd_yqq_secrk']>0.6)].\
            dropna(subset=['jd_yqq_secrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jd_yqq_secrk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.49 / 2.29

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['jd_df1q_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jd_df1q_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.14 / 0.19

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['jd_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jd_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', st
atic_data = i_sd) # 1.71 / 1.2

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['jd_df1y_dv_mc_rk']>0.6)].\
            dropna(subset=['jd_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jd_df1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.71 / 1.2


yu.create_cn_3x3(icom2, ['jd_dfq1y_dv_mc_bk'], 'jd_dfq1y_dv_mc')
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')].\
            dropna(subset=['jd_dfq1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jd_dfq1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.29 / 1.33
o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['jd_dfq1y_dv_mc_rk']>0.6)].\
            dropna(subset=['jd_dfq1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jd_dfq1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.35 / 2.55 if we know future 300 uni -> 1.53 / 0.8 if strictly 300 uni

for g in icom2['GSECTOR'].unique().tolist():
    print (g)
    o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2020-05-31')&(icom2['jd_dfq1y_dv_mc_rk']>0.6)&(icom2['GSECTOR']==g)].\
            dropna(subset=['jd_dfq1y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'jd_dfq1y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.35 / 2.55

