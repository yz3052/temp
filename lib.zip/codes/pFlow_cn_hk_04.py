﻿#$%^&* pFlow_cn_hk_04.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 21:27:30 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import gc
import os
import datetime

# this studies individual participants autocorr and pnl tstat



### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()



### trading calendar

i_cn_cal = yu.get_sql("select distinct datadate, tradedate_next from [CNDBPROD].[dbo].[Calendar_Dates_CN]")


### return

i_ret = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_trailing_ret.parquet',
                        columns = ['ticker','datadate','c2c','c2c_bret','twap1000_2c','twap1000_2c_bret'])


### so

i_so = yu.get_sql('''select datadate, ticker, EQY_FLOAT as so 
                  from cndbprod.dbo.universe_all_cn_gem3l 
                  where datadate >= '2016-01-01' ''')
c_sh = i_so['ticker'].str[0].isin(['6'])
c_sz = i_so['ticker'].str[0].isin(['0','3'])
i_so.loc[c_sh, 'ticker'] = i_so.loc[c_sh, 'ticker'] + '.SH'
i_so.loc[c_sz, 'ticker'] = i_so.loc[c_sz, 'ticker'] + '.SZ'



### c
i_c = yu.get_sql('''select s_info_windcode as ticker, trade_Dt as datadate, s_dq_close as c  
                 from wind_prod.dbo.AShareEODPrices''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format = '%Y%m%d')


### HK uni

i_uni = yu.get_sql('''select ticker, datadate from cndbprod.dbo.[UNIVERSE_HC]
                   where datadate >= '2016-06-29' ''')
c_sh = i_uni['ticker'].str[0].isin(['6'])
c_sz = i_uni['ticker'].str[0].isin(['0','3'])
i_uni.loc[c_sh, 'ticker'] = i_uni.loc[c_sh, 'ticker'] + '.SH'
i_uni.loc[c_sz, 'ticker'] = i_uni.loc[c_sz, 'ticker'] + '.SZ'
i_uni = i_uni.sort_values(['ticker','datadate'])





### Detailed HK anlaysis

i_h_bb_dd = yu.get_sql("select distinct s_holder_enddate from wind_prod.dbo.SHSCmechanismownership")
i_h_bb_dd['s_holder_enddate'] = pd.to_datetime(i_h_bb_dd['s_holder_enddate'], format='%Y%m%d')
i_h_bb_dd['weekday'] = i_h_bb_dd['s_holder_enddate'].dt.weekday+1
i_h_bb_dd = i_h_bb_dd[~i_h_bb_dd['weekday'].isin([6,7])]
i_h_bb_dd = i_h_bb_dd[i_h_bb_dd['s_holder_enddate']!='2021-10-13']

i_h_bb_tk = yu.get_sql('''select distinct s_info_windcode from wind_prod.dbo.SHSCmechanismownership
                          where (s_info_windcode like '%SH') or (s_info_windcode like '%SZ') ''')

i_h_bb_tk_name_map = yu.get_sql('''select distinct s_holde
r_num, s_holder_name from wind_prod.dbo.SHSCmechanismownership''')
i_h_bb_tk_name_map = i_h_bb_tk_name_map.drop_duplicates(subset = ['s_holder_num'], keep = 'first')





s_h_bb = []

for tk in sorted(i_h_bb_tk['s_info_windcode'].tolist()):
    print(tk, end = ',')
    
    # get raw data
    
    t_data = yu.get_sql('''select s_holder_enddate, s_holder_num, s_holder_name, s_holder_compid, s_holder_quantity as q
                        from wind_prod.dbo.SHSCmechanismownership 
                        where s_info_windcode = '{0}' 
                        '''.format(tk))
    t_ret = i_ret[i_ret['ticker']==tk]
    t_c = i_c[i_c['ticker']==tk]
    
    # fill s_holder_num, i.e. participant id
    
    c1 = t_data['s_holder_num'].isnull()
    t_data.loc[c1, 's_holder_num'] = t_data.loc[c1, 's_holder_compid'] 
    c1 = t_data['s_holder_num'].isnull()
    t_data.loc[c1, 's_holder_num'] = t_data.loc[c1, 's_holder_name'] 
    
    # date 
    
    t_data['datadate'] = pd.to_datetime(t_data['s_holder_enddate'],format='%Y%m%d')
    
    # aggregate holding to s_holder_num
    
    t_data = t_data.groupby(['datadate', 's_holder_num'])['q'].sum().reset_index()
    
    # fill nan values in holding (columns q)
    
    t_data_s2 = t_data[['datadate', 's_holder_num', 'q']]
    t_data_s2 = t_data_s2.pivot_table(index = 'datadate', columns = 's_holder_num', values = 'q')
    t_data_s2 = t_data_s2.fillna(0)
    t_data_s2 = t_data_s2.reset_index()
    t_data_s2 = t_data_s2.melt(id_vars='datadate', value_vars=[i for i in t_data_s2.columns.tolist() if i!='datadate'], var_name='s_holder_num', value_name='q')
    
    # delta q
    
    t_data_s2 = t_data_s2.sort_values(['s_holder_num', 'datadate']).reset_index(drop=True)
    t_data_s2['dq'] = t_data_s2.groupby('s_holder_num')['q'].apply(lambda x: x-x.shift())
    t_data_s2 = t_data_s2[t_data_s2['dq'].notnull()]    
    t_data_s2 = t_data_s2[['datadate', 's_holder_num', 'q', 'dq']]
    
    # merge ret
    
    t_data_s2 = t_data_s2.merge(i_cn_cal, on = 'datadate', how = 'left')    
    t_data_s2 = t_data_s2.merge(t_ret, left_on = 'tradedate_next', right_on = 'datadate', how = 'left', suffixes=['','_m'])
    t_data_s2 = t_data_s2.drop(columns = ['datadate_m', 'ticker'])
    t_data_s2 = t_data_s2.merge(t_c, on = ['datadate'], how = 'left')
    t_data_s2 = t_data_s2.drop(columns = ['ticker'])
    
    # pnl of delta q
    
    t_data_s2['pnl_c2c'] = t_data_s2['q'].multiply(t_data_s2['c']).multiply(t_data_s2['c2c']).fillna(0)
   
 t_data_s2['pnl_o2c'] = t_data_s2['q'].multiply(t_data_s2['c']).multiply(t_data_s2['twap1000_2c']).fillna(0)
    t_data_s2['pnl_c2cBret'] = t_data_s2['q'].multiply(t_data_s2['c']).multiply(t_data_s2['c2c_bret']).fillna(0)
    t_data_s2['pnl_o2cBret'] = t_data_s2['q'].multiply(t_data_s2['c']).multiply(t_data_s2['twap1000_2c_bret']).fillna(0)
    
    # hk-level daily summary 
    
    s_data_hk = t_data_s2.groupby(['datadate'])['q', 'dq'].sum().reset_index()
    s_data_hk = s_data_hk.sort_values('datadate')
    s_data_hk = s_data_hk.rename(columns={'q':'q_hk', 'dq':'dq_hk'})
    s_data_hk['dq_hk_p1d'] = s_data_hk['dq_hk'].shift(-1)
    s_data_hk['dq_hk_p2d'] = s_data_hk['dq_hk'].shift(-2)
    s_data_hk['dq_hk_p5d'] = s_data_hk['dq_hk'].shift(-5)
    s_data_hk = s_data_hk.drop(columns = ['q_hk', 'dq_hk'])
    
    # merge hk-level daily summary
    
    t_data_s3 = t_data_s2.merge(s_data_hk, on = 'datadate', how = 'left')
    t_data_s3 = t_data_s3.sort_values(['s_holder_num', 'datadate'])
    
    # rolling summary of participant performance
    
    t_data_s3 = t_data_s3.reset_index(drop = True)
    
    t_data_s3['corr_sample'] = t_data_s3.groupby('s_holder_num').rolling(65)['dq'].count().values
    
    def rollcorr(x, c1, c2):
        return pd.DataFrame(x[c1].rolling(65).corr(x[c2]))
    t_data_s3['corr_p1d_t1q'] = t_data_s3.groupby('s_holder_num')[['dq', 'dq_hk_p1d']].apply(lambda x: rollcorr(x,'dq', 'dq_hk_p1d'))
    t_data_s3['corr_p2d_t1q'] = t_data_s3.groupby('s_holder_num')[['dq', 'dq_hk_p2d']].apply(lambda x: rollcorr(x,'dq', 'dq_hk_p2d'))
    t_data_s3['corr_p5d_t1q'] = t_data_s3.groupby('s_holder_num')[['dq', 'dq_hk_p5d']].apply(lambda x: rollcorr(x,'dq', 'dq_hk_p5d'))
    
    t_data_s3['pnlT_c2cBret_t1q'] = t_data_s3.groupby('s_holder_num').rolling(65)['pnl_c2cBret'].apply(lambda x: x.mean()/x.std()*np.sqrt(len(x)) if x.std()!=0 else np.nan, raw=False).values
    t_data_s3['pnlT_o2cBret_t1q'] = t_data_s3.groupby('s_holder_num').rolling(65)['pnl_o2cBret'].apply(lambda x: x.mean()/x.std()*np.sqrt(len(x)) if x.std()!=0 else np.nan, raw=False).values
    
    # output
    t_data_s3['ticker'] = tk
    t_ret = None
    t_c = None
    t_data = None
    t_data_s2 = None
    gc.collect()
    
    s_h_bb.append(t_data_s3)

[i.to_parquet(r'S:\Data\China Data Hunt\cache\pWIND_strat_north_03\tk_'+i.ticker.values[0]+'.parquet') for i in s_h_bb]
s_h_bb_df = pd.concat(s_h_bb, axis = 0)
del s_h_bb
gc.collect()

d = r'S:\Data\China Data Hunt\cache\pWIND_strat_
north_03'
s_h_bb_df = pd.concat([pd.read_parquet(os.path.join(d, i)) for i in os.listdir(d)], axis = 0)




### Detailed HK anlaysis - get the flow and holding from brokers with strong performance

s_participant = s_h_bb_df.groupby(['datadate', 's_holder_num'])[['corr_p1d_t1q','corr_p2d_t1q','pnlT_o2cBret_t1q','pnlT_c2cBret_t1q','corr_sample']].mean().reset_index()
s_participant = s_participant.merge(i_h_bb_tk_name_map,on='s_holder_num',how='left')


s_h_bb_df_highCorr = s_h_bb_df[(s_h_bb_df['corr_p1d_t1q']>0.01)&(s_h_bb_df['corr_p2d_t1q']>0.01)\
                               &(s_h_bb_df['corr_sample']>60)]
s_h_bb_df_highCorr = s_h_bb_df_highCorr.groupby(['datadate', 'ticker'])['dq'].sum().reset_index()


s_h_bb_df_higherCorr = s_h_bb_df[(s_h_bb_df['corr_p1d_t1q']>0.10)&(s_h_bb_df['corr_p2d_t1q']>0.03)\
                               &(s_h_bb_df['corr_sample']>60)]
s_h_bb_df_higherCorr = s_h_bb_df_higherCorr.groupby(['datadate', 'ticker'])['dq'].sum().reset_index()

s_h_bb_df_highSharpe = s_h_bb_df[(s_h_bb_df['pnlT_c2cBret_t1q']>-0.5)&(s_h_bb_df['corr_sample']>60)]
s_h_bb_df_highSharpe = s_h_bb_df_highSharpe.groupby(['datadate', 'ticker'])['q'].sum().reset_index()





### Portfolio Sharpe by Participants

o_part = []

t_sd = i_sd[['ticker', 'datadate', 'FLOAT_l1d','BarrRet_CLIP_USD+1d']].sort_values('datadate')

for i, part in enumerate(i_h_bb_tk_name_map['s_holder_num'].dropna().unique().tolist()):
        
    # get data
    
    t_data = yu.get_sql('''select s_holder_enddate as datadate, s_info_windcode as ticker, 
                                  sum(s_holder_quantity) as q
                           from wind_prod.dbo.SHSCmechanismownership 
                           where s_holder_num = '{0}'
                           group by s_holder_enddate, s_info_windcode
                        '''.format(part))    
    t_data['datadate'] = pd.to_datetime(t_data['datadate'],format='%Y%m%d')
    t_data = t_data.sort_values('datadate')
    
    # daily position
    
    t_merge = pd.merge_asof(t_sd, t_data, by='ticker', on='datadate')
    t_merge['shares_dv_so'] = t_merge['q'].divide(t_merge['FLOAT_l1d'])
    t_merge['shares_dv_so'] = t_merge['shares_dv_so'].fillna(0)
    t_merge['shares_dv_so_rk'] = t_merge.groupby('datadate')['shares_dv_so'].apply(yu.uniformed_rank)
    t_merge['pnl'] = t_merge['shares_dv_so_rk'].multiply(t_merge['BarrRet_CLIP_USD+1d'])
    
    # summary
    
    s = t_merge.groupby('datadate').agg({'pnl': sum, 'ticker': 'nunique'}).reset
_index()
    s = s.rename(columns = {'ticker': 'ticker_cnt'})
    s['pnl'] = s['pnl'].replace(0, np.nan)
    s['sharpe_t1q'] = s.rolling(datetime.timedelta(days=91),on='datadate',min_periods=40)\
                      ['pnl'].apply(lambda x: x.mean()/x.std()*np.sqrt(x.count()),raw=False)
    s['ticker_cnt_t1q'] = s.rolling(datetime.timedelta(days=91),on='datadate',min_periods=40)\
                          ['ticker_cnt'].mean().values
    s['s_holder_num'] = part
    s = s.merge(i_h_bb_tk_name_map,on='s_holder_num',how='left')
    o_part.append(s)
    print(s['s_holder_name'].values[0], end = ' ')
    print(round(s['sharpe_t1q'].mean(),2))
    
    t_data, t_merge = None, None
    
    
o_part = pd.concat(o_part, axis=0)
o_part.to_parquet(r'S:\Data\China Data Hunt\cache\pWIND_strat_north_04_sharpe_by_broker.parquet')


o_part_s2 = o_part.copy()
o_part_s2 = o_part_s2[o_part_s2['sharpe_t1q'].notnull()]
o_part_s2 = o_part_s2.reset_index(drop=True)
o_part_s2 = o_part_s2.sort_values(['s_holder_num','datadate'])
o_part_s2['sharpe_t1q_t1q'] = o_part_s2.groupby('s_holder_num').rolling(datetime.timedelta(days=91),on='datadate',min_periods=20)['sharpe_t1q'].mean().values
o_part_s2['sharpe_t1q_t1q_rk'] = o_part_s2.groupby('datadate')['sharpe_t1q_t1q'].apply(yu.uniformed_rank)






# get data from sql according to the rank of brokers

o_spec_sgnl = []

for dt in i_h_bb_dd['s_holder_enddate'].sort_values():
    print(dt.strftime('%Y%m%d'), end=',')
    if dt >= pd.to_datetime('2021-12-31'):
        continue
    
    t_part_s2 = o_part_s2[o_part_s2['datadate']==dt]
    t_part_s2 = t_part_s2.sort_values('sharpe_t1q_t1q', ascending = False)
    part_high_rk = t_part_s2['s_holder_num'].tolist()[:5]
    
    t_data = yu.get_sql('''select s_holder_enddate as datadate, s_info_windcode as ticker, 
                           sum(case when s_holder_num in ('{0}') then s_holder_quantity else 0 end) as q_highRk,
                           sum(case when s_holder_num not in ('{0}') then s_holder_quantity else 0 end) as q_lowRk 
                        from wind_prod.dbo.SHSCmechanismownership 
                        where s_holder_enddate = '{1}'  
                              and ((s_info_windcode like '%SH') or (s_info_windcode like '%SZ'))
                        group by s_holder_enddate , s_info_windcode
                        '''.format("','".join(part_high_rk), dt.strftime('%Y%m%d')))
    t_data['datadate'] = pd.to_datetime(t_data['datadate'], format='%Y%m%d')

    t_c = 
i_c[i_c['datadate']==dt][['ticker','c']]
    t_so = i_so[i_so['datadate']==dt][['ticker', 'so']]
    
    t_merge = t_data.merge(t_c, on = 'ticker', how = 'left')
    t_merge = t_merge.merge(t_so, on = 'ticker', how = 'left')
    t_merge['q_highRk_dv_so_rk'] = yu.uniformed_rank(t_merge['q_highRk'].divide(t_merge['so']))
    t_merge['q_lowRk_dv_so_rk'] = yu.uniformed_rank(t_merge['q_lowRk'].divide(t_merge['so']))
    t_merge['q_highlow_rkdf'] = t_merge['q_highRk_dv_so_rk'] - t_merge['q_lowRk_dv_so_rk']
    t_merge['q_highlow_rkdf_rk'] = yu.uniformed_rank(t_merge['q_highlow_rkdf'])
    
    o_spec_sgnl.append(t_merge)
    
o_spec_sgnl = pd.concat(o_spec_sgnl, axis = 0)

o_spec_sgnl.to_parquet(r'S:\Data\China Data Hunt\cache\pWIND_strat_north_04_spec_sgnl.parquet')
    
    


### combine (high corr)



icomd = i_sd.merge(s_h_bb_df_highCorr, on = ['ticker', 'datadate'], how = 'left')
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']


icomd['dq_dv_so'] = icomd['dq'].divide(icomd['FLOAT_l1d'])
icomd['dq_dv_so_rk'] = icomd.groupby('datadate')['dq_dv_so'].apply(yu.uniformed_rank)
icomd['dq_dv_so_bk'] = icomd.groupby('datadate')['dq_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10))
icomd['dq_dv_so_40bk'] = icomd.groupby('datadate')['dq_dv_so'].apply(lambda x: yu.pdqcut(x,bins=40))
icomd['dq_dv_adv'] = icomd['dq'].divide(icomd['avgVadj'])
icomd['dq_dv_adv_bk'] = icomd.groupby('datadate')['dq_dv_adv'].apply(lambda x: yu.pdqcut(x,bins=10))
# yu.create_cn_3x3(icomd, ['dq_dv_so_bk'], 'dq_dv_so') # mono: -4 +8
# yu.create_cn_3x3(icomd, ['dq_dv_so_40bk'], 'dq_dv_so') # mono: -8 +10 
# the above results are much stronger than the buldge bracket flows, which were v-shaped
# yu.create_cn_3x3(icomd, ['dq_dv_adv_bk'], 'dq_dv_adv') #mono: -4 +6

icomd.loc[icomd['dq_dv_adv_bk']==9, 'test1'] = 1
#yu.create_cn_decay(icomd, 'test1')

icomd['sgnl_long_1'] = np.nan
icomd.loc[icomd['dq_dv_adv_bk']==9, 'sgnl_long_1'] = 1
icomd['sgnl_long_1'] = icomd.groupby('ticker')['sgnl_long_1'].ffill(limit = 20)


o_1 = yu.bt_cn_15(icomd[(icomd['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['dq_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'dq_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 6.56 / -16.54

o_1 = yu.bt_cn_15(icomd[(icomd['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['sgnl_long_1','BarrRet_CLIP_USD+1d']).drop_dupl
icates(subset=['ticker','datadate']),
            'sgnl_long_1','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.11 / 0.73


### combine (higher corr)


icomd = i_sd.merge(s_h_bb_df_higherCorr, on = ['ticker', 'datadate'], how = 'left')
icomd = icomd.sort_values(['ticker', 'datadate'])
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']

icomd['dq_dv_so'] = icomd['dq'].divide(icomd['FLOAT_l1d'])
icomd['dq_dv_so_rk'] = icomd.groupby('datadate')['dq_dv_so'].apply(yu.uniformed_rank)
icomd['dq_dv_so_20dslfrk'] = icomd.groupby('ticker').rolling(20)['dq_dv_so'].apply(lambda x: (x.rank()/x.count()).values[-1],raw=False).values
icomd['dq_dv_so_20dslfrk'] = (icomd['dq_dv_so_20dslfrk']-0.5)*2

icomd['dq_dv_so_orth'] = icomd.groupby('datadate')[COLS+['dq_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['dq_dv_so'], x[COLS])).values
icomd['dq_dv_so_bk'] = icomd.groupby('datadate')['dq_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10))
icomd['dq_dv_so_40bk'] = icomd.groupby('datadate')['dq_dv_so'].apply(lambda x: yu.pdqcut(x,bins=40))
icomd['dq_dv_so_orth_bk'] = icomd.groupby('datadate')['dq_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10))
icomd['dq_dv_so_orth_40bk'] = icomd.groupby('datadate')['dq_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=40))
icomd['dq_dv_so_t20d'] = icomd.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['dq_dv_so'].mean().values
icomd['dq_dv_so_t20d_40bk'] = icomd.groupby('datadate')['dq_dv_so_t20d'].apply(lambda x: yu.pdqcut(x,bins=40))
icomd['dq_dv_so_t20d_1d'] = icomd.groupby('ticker')['dq_dv_so_t20d'].shift()
icomd['dq_dv_so_t20d_1d_rk'] = icomd.groupby('datadate')['dq_dv_so_t20d_1d'].apply(yu.uniformed_rank)

icomd['test1'] = icomd['dq_dv_so_rk'] + icomd['dq_dv_so_20dslfrk']
icomd['test1_bk'] = icomd.groupby('datadate')['test1'].apply(lambda x: yu.pdqcut(x,bins=10))
yu.create_cn_3x3(icomd, ['test1_bk'], 'test1') # -1 -2 +6

icomd['test2'] = np.nan
icomd.loc[icomd['test1_bk']==9,'test2'] = 1
yu.create_cn_decay(icomd, 'test2')

icomd['test3'] = np.nan
icomd.loc[(icomd['dq_dv_so_20dslfrk']>0.8),'test3'] = 1
yu.create_cn_decay(icomd, 'test3')
icomd['test3'] = icomd.groupby('ticker')['test3'].ffill(limit=2)

yu.create_cn_3x3(icomd, ['dq_dv_so_bk'], 'dq_dv_so') # mono: -4 +8
yu.create_cn_3x3(icomd, ['dq_dv_so_40bk'], 'dq_dv_so') # mono: -9 +12
yu.create_cn_3x3(icomd, ['dq_dv_so_orth_bk'], 'dq_dv_so_orth') # mono: -4 +8
yu.create_cn_3x3(icomd, ['dq_dv_so_orth_40bk'], 'dq_dv_so_o
rth') # mono: -7 +10
yu.create_cn_3x3(icomd, ['dq_dv_so_t20d_40bk'], 'dq_dv_so_t20d') # not mono: 0 -6 +6 0


o_1 = yu.bt_cn_15(icomd[(icomd['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['test3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test3','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.14/-4.83





### combine (high sharpe from holding pnl)


icomd = i_sd.merge(s_h_bb_df_highSharpe, on = ['ticker', 'datadate'], how = 'left')
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']


icomd['q_dv_so'] = icomd['q'].divide(icomd['FLOAT_l1d'])
icomd['q_dv_so_rk'] = icomd.groupby('datadate')['q_dv_so'].apply(yu.uniformed_rank)
icomd['q_dv_so_bk'] = icomd.groupby('datadate')['q_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10))
icomd['q_dv_so_40bk'] = icomd.groupby('datadate')['q_dv_so'].apply(lambda x: yu.pdqcut(x,bins=40))
icomd['q_dv_adv'] = icomd['q'].divide(icomd['avgVadj'])
icomd['q_dv_adv_bk'] = icomd.groupby('datadate')['q_dv_adv'].apply(lambda x: yu.pdqcut(x,bins=10))
# yu.create_cn_3x3(icomd, ['q_dv_so_bk'], 'q_dv_so') # mono: -4 +8
# yu.create_cn_3x3(icomd, ['dq_dv_so_40bk'], 'dq_dv_so') # mono: -8 +10 
# the above results are much stronger than the buldge bracket flows, which were v-shaped
# yu.create_cn_3x3(icomd, ['dq_dv_adv_bk'], 'dq_dv_adv') #mono: -4 +6

icomd.loc[icomd['dq_dv_adv_bk']==9, 'test1'] = 1
#yu.create_cn_decay(icomd, 'test1')

icomd['sgnl_long_1'] = np.nan
icomd.loc[icomd['dq_dv_adv_bk']==9, 'sgnl_long_1'] = 1
icomd['sgnl_long_1'] = icomd.groupby('ticker')['sgnl_long_1'].ffill(limit = 20)


o_1 = yu.bt_cn_15(icomd[(icomd['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['dq_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'dq_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 6.56 / -16.54



### combine (high sharpe from ranked LS holding pnl)

icom = i_sd.merge(o_spec_sgnl, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['q_highlow_rkdf_bk'] = icom.groupby('datadate')['q_highlow_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10))
yu.create_cn_3x3(icom, ['q_highlow_rkdf_bk'], 'q_highlow_rkdf') # mono: -6 +5

icom['q_highlow_rkdf_sgnl'] = np.nan
icom.loc[icom['q_highlow_rkdf_rk']>0.9, 'q_highlow_rkdf_sgnl'] = 1
icom.loc[icom['q_highlow_rkdf_rk']<0.2, 'q_highlow_rkdf_sgnl'] = 0
icom['q_highlow_rkd
f_sgnl'] = icom.groupby('ticker')['q_highlow_rkdf_sgnl'].ffill(limit = 40)

yu.create_cn_decay(icom, 'q_highlow_rkdf_sgnl')

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['q_highlow_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'q_highlow_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2018-07-01','2020-12-31'))].\
            dropna(subset=['q_highlow_rkdf_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'q_highlow_rkdf_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) 

