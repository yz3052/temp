﻿#$%^&* pL2_cn_order_captureTWAP3s.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Apr 21 06:14:36 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime



#  This studies TWAP capture data



### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])



### get TWAP capture data

i_captwap = yu.get_q('''(get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sz_captureTWAP_3s),
                        (get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sz_captureTWAP_3s) ''')

i_captwap['code'] = i_captwap['code'].str.decode('utf8')
c_sh = i_captwap['code'].str[0].isin(['6'])
c_sz = i_captwap['code'].str[0].isin(['0','3'])
i_captwap.loc[c_sh, 'ticker'] = i_captwap.loc[c_sh, 'code'] + '.SH'
i_captwap.loc[c_sz, 'ticker'] = i_captwap.loc[c_sz, 'code'] + '.SZ'
i_captwap['datadate'] = pd.to_datetime(i_captwap['date'])
i_captwap = i_captwap.sort_values(['ticker', 'datadate'])
i_captwap = i_captwap[i_captwap['ticker'].notnull()]


### get TWAP capture data v2

i_captwap2 = yu.get_q('''(get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sh_captureTWAP_3s_v2),
                         (get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sz_captureTWAP_3s_v2) ''')

i_captwap2['code'] = i_captwap2['code'].str.decode('utf8')
c_sh = i_captwap2['code'].str[0].isin(['6'])
c_sz = i_captwap2['code'].str[0].isin(['0','3'])
i_captwap2.loc[c_sh, 'ticker'] = i_captwap2.loc[c_sh, 'code'] + '.SH'
i_captwap2.loc[c_sz, 'ticker'] = i_captwap2.loc[c_sz, 'code'] + '.SZ'
i_captwap2['datadate'] = pd.to_datetime(i_captwap2['date'])
i_captwap2 = i_captwap2.sort_values(['ticker', 'datadate'])
i_captwap2 = i_captwap2[i_captwap2['ticker'].notnull()]





### 

icom = i_sd.merge(i_captwap, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_captwap2, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']



### v2: find the max 1/3 seconds for each ticker, not over the entire market

icom['v2_top3s_x3_dv_tot'] = icom['cntV2_tot_top3s_x3'].divide(icom['cntV2_tot_x3'])
icom['v2_top3s_x3_dv_tot_bk'] = icom.groupby('datadate')['v2_top3s_x3_dv_tot'].apply(lambda x:yu.pdqcut(x,bins=10)).values
icom['v2_top3s_x3_dv_tot_orth'] = icom.groupby('datadate')[['v2_top3s_x3_dv_tot']+COLS].apply(lambda x: yu.o
rthogonalize_cn(x['v2_top3s_x3_dv_tot'], x[COLS])).values
icom['v2_top3s_x3_dv_tot_orth_bk'] = icom.groupby('datadate')['v2_top3s_x3_dv_tot_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['v2_m_avg_dv_tot'] = (icom['cntV2_tot_top3s_x3'] - icom['cntV2_tot_x3']/3).divide(icom['cntV2_tot_x3'])
icom['v2_m_avg_dv_tot_bk'] = icom.groupby('datadate')['v2_m_avg_dv_tot'].apply(lambda x:yu.pdqcut(x,bins=10)).values
icom['v2_m_avg_dv_min_dv_tot'] = (icom['cntV2_tot_top3s_x3'] - icom['cntV2_tot_x3']/3).divide(icom['cntV2_3s_periods']).divide(icom['cntV2_tot_x3'])
icom['v2_m_avg_dv_min_dv_tot_bk'] = icom.groupby('datadate')['v2_m_avg_dv_min_dv_tot'].apply(lambda x:yu.pdqcut(x,bins=10)).values

icom['v2_top3s_x3_s_dv_tot'] = icom['cntV2_tot_top3s_x3_strict'].divide(icom['cntV2_tot_x3'])
icom['v2_top3s_x3_s_dv_tot_bk'] = icom.groupby('datadate')['v2_top3s_x3_s_dv_tot'].apply(lambda x:yu.pdqcut(x,bins=10)).values
icom['v2_top3s_x3_s_dv_tot_s'] = icom['cntV2_tot_top3s_x3_strict'].divide(icom['cntV2_tot_x3_strict'])
icom['v2_top3s_x3_s_dv_tot_s_bk'] = icom.groupby('datadate')['v2_top3s_x3_s_dv_tot_s'].apply(lambda x:yu.pdqcut(x,bins=10)).values
icom['v2_top3s_x3_s_dv_tot'] = icom['cntV2_tot_top3s_x3_strict'].divide(icom['cntV2_tot_x3'])
icom['v2_top3s_x3_s_dv_tot_bk'] = icom.groupby('datadate')['v2_top3s_x3_s_dv_tot'].apply(lambda x:yu.pdqcut(x,bins=10)).values


yu.create_cn_3x3(icom, ['v2_top3s_x3_dv_tot_bk'], 'v2_top3s_x3_dv_tot') # mono: -7 +8 +7.5
yu.create_cn_3x3(icom, ['v2_top3s_x3_dv_tot_orth_bk'], 'v2_top3s_x3_dv_tot_orth') # mono: -9 +8.5 ###!!!
yu.create_cn_3x3(icom, ['v2_m_avg_dv_tot_bk'], 'v2_m_avg_dv_tot') # mono: -7 +8 +6.5
yu.create_cn_3x3(icom, ['v2_m_avg_dv_min_dv_tot_bk'], 'v2_m_avg_dv_min_dv_tot') # mono: -7 +7.5
yu.create_cn_3x3(icom, ['v2_top3s_x3_s_dv_tot_bk'], 'v2_top3s_x3_s_dv_tot') # mono: -7 +8 +6.5
yu.create_cn_3x3(icom, ['v2_top3s_x3_s_dv_tot_s_bk'], 'v2_top3s_x3_s_dv_tot_s') # not mono: -3.5 +4 +1
yu.create_cn_3x3(icom, ['v2_top3s_x3_s_dv_tot_bk'], 'v2_top3s_x3_s_dv_tot') # mono: -7 +8 +6.5


### v2: pnl 

icom['v2_top3s_x3_dv_tot'] = icom['cntV2_tot_top3s_x3'].divide(icom['cntV2_tot_x3'])
icom['v2_top3s_x3_dv_tot_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['v2_top3s_x3_dv_tot'].mean().values
icom['v2_top3s_x3_dv_tot_t20d_orth'] = icom.groupby('datadate')[['v2_top3s_x3_dv_tot_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['v2_top3s_x3_dv_tot_t20d'], x[COLS])).values
icom['v2_top3s_x3_dv_tot_t
20d_orth_bk'] = icom.groupby('datadate')['v2_top3s_x3_dv_tot_t20d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['v2_top3s_x3_dv_tot_t20d_orth_sgnl'] = icom.groupby('datadate')['v2_top3s_x3_dv_tot_t20d_orth'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icom, ['v2_top3s_x3_dv_tot_t20d_orth_bk'], 'v2_top3s_x3_dv_tot_t20d_orth') # 
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['v2_top3s_x3_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'v2_top3s_x3_dv_tot_t20d_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.48/3.0, 5e8 ###!!!




### (top x3 - bottom x3 ) / total, pm or am


icom['cnt_x3_pm_df_dv_tot_x3'] = (icom['cnt_tot_top3s_x3_pm'] - icom['cnt_tot_bot3s_x3_pm']).divide(icom['cnt_tot_x3_pm'])
icom['cnt_x3_pm_df_dv_tot_x3_bk'] = icom.groupby('datadate')['cnt_x3_pm_df_dv_tot_x3'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['cnt_x3_pm_df_dv_tot_x3_bk'], 'cnt_x3_pm_df_dv_tot_x3') # mono: -6.5 +7.5

icom['cnt_x3_am_df_dv_tot_x3'] = (icom['cnt_tot_top3s_x3_am'] - icom['cnt_tot_bot3s_x3_am']).divide(icom['cnt_tot_x3_am'])
icom['cnt_x3_am_df_dv_tot_x3_bk'] = icom.groupby('datadate')['cnt_x3_am_df_dv_tot_x3'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['cnt_x3_am_df_dv_tot_x3_bk'], 'cnt_x3_am_df_dv_tot_x3') # mono: -6.5 +7



## (bids top x3 - bids bottom x3 ) / total

icom['cnt_b_x3_df_dv_tot_x3'] = (icom['cnt_b_tot_top3s_x3'] - icom['cnt_b_tot_bot3s_x3']).divide(icom['cnt_b_tot_x3'])
icom['cnt_b_x3_df_dv_tot_x3_bk'] = icom.groupby('datadate')['cnt_b_x3_df_dv_tot_x3'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['cnt_b_x3_df_dv_tot_x3_bk'], 'cnt_b_x3_df_dv_tot_x3') # mono: -6 +7.5






## (top x3 - bottom x3 ) / total

icom['cnt_x3_df_dv_tot_x3'] = (icom['cnt_tot_top3s_x3'] - icom['cnt_tot_bot3s_x3']).divide(icom['cnt_tot_x3'])
icom['cnt_x3_df_dv_tot_x3_bk'] = icom.groupby('datadate')['cnt_x3_df_dv_tot_x3'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['cnt_x3_df_dv_tot'] = (icom['cnt_tot_top3s_x3'] - icom['cnt_tot_bot3s_x3']).divide(icom['cnt_tot'])
icom['cnt_x3_df_dv_tot_bk'] = icom.groupby('datadate')['cnt_x3_df_dv_tot'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['cnt_x3_df_dv_tot_x3_bk'], 'cnt_x3_df_dv_tot_x3') # mono: -7 +8
yu.create_cn_3x3(icom, ['cnt_x3_df_dv_tot_bk'], 'cnt_x3_df_dv_tot') # mono: -7 +8

icom['cnt_x3_df_dv_tot_
xNeg'] = np.nan
icom.loc[icom['cnt_x3_df_dv_tot_x3']>0,'cnt_x3_df_dv_tot_xNeg'] = icom.loc[icom['cnt_x3_df_dv_tot_x3']>0,'cnt_x3_df_dv_tot_x3']
icom['cnt_x3_df_dv_tot_xNeg_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['cnt_x3_df_dv_tot_xNeg'].mean().values
icom['cnt_x3_df_dv_tot_xNeg_t20d_sgnl'] = icom.groupby('datadate')['cnt_x3_df_dv_tot_xNeg_t20d'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cnt_x3_df_dv_tot_xNeg_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_x3_df_dv_tot_xNeg_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.43 / 2.77, 3.2e7




## (top - bottom) / total

icom['cnt_df_dv_tot'] = (icom['cnt_tot_top3s'] - icom['cnt_tot_bot3s']).divide(icom['cnt_tot'])
icom['cnt_df_dv_tot_bk'] = icom.groupby('datadate')['cnt_df_dv_tot'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['cnt_df_dv_tot_xNeg'] = np.nan
icom.loc[icom['cnt_df_dv_tot']>0,'cnt_df_dv_tot_xNeg'] = icom.loc[icom['cnt_df_dv_tot']>0,'cnt_df_dv_tot']
icom['cnt_df_dv_tot_xNeg_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['cnt_df_dv_tot_xNeg'].mean().values
icom['cnt_df_dv_tot_xNeg_t20d_sgnl'] = icom.groupby('datadate')['cnt_df_dv_tot_xNeg_t20d'].apply(yu.uniformed_rank).values
icom['cnt_df_dv_tot_xNeg_t20d_orth'] = icom.groupby('datadate')[['cnt_df_dv_tot_xNeg_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['cnt_df_dv_tot_xNeg_t20d'], x[COLS])).values
icom['cnt_df_dv_tot_xNeg_t20d_orth_bk'] = icom.groupby('datadate')['cnt_df_dv_tot_xNeg_t20d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_df_dv_tot_xNeg_t20d_orth_sgnl'] = icom.groupby('datadate')['cnt_df_dv_tot_xNeg_t20d_orth'].apply(yu.uniformed_rank).values
     
yu.create_cn_3x3(icom, ['cnt_df_dv_tot_bk'], 'cnt_df_dv_tot') # mono: -8 +8
yu.create_cn_3x3(icom, ['cnt_df_dv_tot_xNeg_t20d_orth_bk'], 'cnt_df_dv_tot_xNeg_t20d_orth') # mono: -9 +6


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cnt_df_dv_tot_xNeg_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_df_dv_tot_xNeg_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) 
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cnt_df_dv_tot_xNeg_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            
'cnt_df_dv_tot_xNeg_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.47 / 2.81, 3.2e7
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cnt_df_dv_tot_xNeg_t20d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_df_dv_tot_xNeg_t20d_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.62 / 2.77, 3.8e7


icom['cnt_b_df_dv_tot'] = (icom['cnt_b_tot_top3s'] - icom['cnt_b_tot_bot3s']).divide(icom['cnt_b_tot'])
icom['cnt_b_df_dv_tot_bk'] = icom.groupby('datadate')['cnt_b_df_dv_tot'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cnt_b_df_dv_tot_bk'], 'cnt_b_df_dv_tot') # mono: -6 +8

icom['cnt_s_df_dv_tot'] = (icom['cnt_s_tot_top3s'] - icom['cnt_s_tot_bot3s']).divide(icom['cnt_s_tot'])
icom['cnt_s_df_dv_tot_bk'] = icom.groupby('datadate')['cnt_s_df_dv_tot'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cnt_s_df_dv_tot_bk'], 'cnt_s_df_dv_tot') # mono: -4 +7

