﻿#$%^&* featurepool_cn_order_price_std_desc.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  5 16:48:33 2022

@author: thzhang
"""

import sys
import os
import pandas as pd
import numpy as np

import datetime

from sqlalchemy import create_engine
import urllib


# this generates 1-D descriptors 
# to be scheduled on crontab
# parquet file name is T-1d



#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------

source_path = '/export/dataprod/Feature_Pool_CN/q_order_price_std'
save_path = '/export/dataprod/Feature_Pool_CN/featurepool_desc_order_price_std'

conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))




#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------

q_dates = os.listdir(source_path)
desc_dates = os.listdir(save_path)
query_dates = list(set(q_dates).difference(set(desc_dates)))


#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------

i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()



#------------------------------------------------------------------------------
### calculate descriptors
#------------------------------------------------------------------------------

for f in query_dates:
    
    # get q query results
    
    i_q = pd.read_csv(os.path.join(source_path, f), sep = '|', )    
    i_q = i_q.rename(columns = {'code': 'Ticker', 'date': 'T-1d'})
    i_q['Ticker'] = i_q['Ticker'].astype(int).astype(str).str.zfill(6)
    i_q['T-1d'] = pd.to_datetime(i_q['T-1d'])
    
    # combine
    
    i_q = i_q.merge(i_cal, on = 'T-1d', how = 'left')
        
    i_q['order_p_dv_p_ask_var'] = i_q['order_p_dv_p_ask_var'].replace(np.inf,np.nan).replace(-np.inf, np.nan)
    i_q['order_p_dv_p_ask_var'] = i_q['order_p_dv_p_ask_var'].replace('0w', np.nan)
    i_q['order_p_dv_p_ask_v
ar'] = pd.to_numeric(i_q['order_p_dv_p_ask_var'])
    
    file_name = f.replace('.txt','.parquet')
    i_q[['Ticker', 'DataDate', 'T-1d', 'order_p_dv_p_ask_var']].to_parquet(os.path.join(save_path, file_name))
    
    os.system("chgrp summit_thzhang "+os.path.join(save_path, file_name)+";")
    os.system("chmod 770 "+os.path.join(save_path, file_name)+";")





