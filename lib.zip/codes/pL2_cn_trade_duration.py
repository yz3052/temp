﻿#$%^&* pL2_cn_trade_duration.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 24 08:14:07 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime



### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])


### get duration

i_tr_dur = yu.get_q('''(get `:/export/datadev/Data/SHSZ/TRADE_metrics/high_duration_trades_sh),(get `:/export/datadev/Data/SHSZ/TRADE_metrics/high_duration_trades_sz)''', port =5003)

i_tr_dur['code'] = i_tr_dur['code'].str.decode('utf8')
c_sh = i_tr_dur['code'].str[0].isin(['6'])
c_sz = i_tr_dur['code'].str[0].isin(['0','3'])
i_tr_dur.loc[c_sh, 'ticker'] = i_tr_dur.loc[c_sh, 'code'] + '.SH'
i_tr_dur.loc[c_sz, 'ticker'] = i_tr_dur.loc[c_sz, 'code'] + '.SZ'
i_tr_dur['datadate'] = pd.to_datetime(i_tr_dur['date'])


### combine


icom = i_sd.merge(i_tr_dur, on = ['ticker', 'datadate'], how = 'left')

icom['avg_dur_bk'] = icom.groupby('datadate')['avg_dur'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['avg_dur_bk'], 'avg_dur') # random

icom['d_dur2min_dv_pv'] = icom['d_dur2min'].divide(icom['PV_l1d'])
icom['d_dur2min_dv_pv_bk'] = icom.groupby('datadate')['d_dur2min_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['d_dur5min_dv_pv'] = icom['d_dur5min'].divide(icom['PV_l1d'])
icom['d_dur5min_dv_pv_bk'] = icom.groupby('datadate')['d_dur5min_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
cols = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']
icom['d_dur2min_dv_pv_orth'] = icom.groupby('datadate')[cols+['d_dur2min_dv_pv']].apply(lambda x: yu.orthogonalize_cn(x['d_dur2min_dv_pv'], x[cols])).values
icom['d_dur2min_dv_pv_orth_bk'] = icom.groupby('datadate')['d_dur2min_dv_pv_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['d_dur2min_dv_pv_bk'], 'd_dur2min_dv_pv') # 0 -1 +2.5
yu.create_cn_3x3(icom, ['d_dur5min_dv_pv_bk'], 'd_dur5min_dv_pv') # random
yu.create_cn_3x3(icom, ['d_dur2min_dv_pv_orth_bk'], 'd_dur2min_dv_pv_orth') # random


