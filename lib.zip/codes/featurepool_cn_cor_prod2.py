﻿#$%^&* featurepool_cn_cor_prod2.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  5 16:48:33 2022

@author: thzhang
"""

import sys
import os
import pandas as pd
import numpy as np

import datetime

from sqlalchemy import create_engine
import urllib


# this generates 1-D descriptors 
# to be scheduled on crontab
# parquet file name is T-1d

### SQL create 
# create table F001_COR_FORMAT (Ticker varchar(max), [T-1d] datetime, [DataDate] datetime, 
# pq_pct_corr_t20d float, pq_dpct_corr_t20d float)



#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------

source_path = '/export/dataprod2/CNL2/SHSZ/q_trade_pqcorr'

conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))




#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------


q_dates = os.listdir(source_path)
q_dates = [i.replace('.txt','') for i in q_dates]


existing_dates = pd.read_sql('''select distinct [T-1d] from CNDBDEV.dbo.F001_COR_FORMAT''', conn)
if len(existing_dates) > 0:
    existing_dates['T-1d'] = existing_dates['T-1d'].dt.strftime('%Y.%m.%d')
    existing_dates = existing_dates['T-1d'].tolist()
else: 
    existing_dates = []

query_dates = list(set(q_dates).difference(set(existing_dates)))




#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------

i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()



#------------------------------------------------------------------------------
### calculate descriptors
#------------------------------------------------------------------------------

query_dates.sort()
all_dates = os.listdir(source_path)
all_dates.sort()

for i in range(len(query_dates)):
    
    # date string
    
    t_1d = query_dates[i]
    t_20d = all_dates[max(all_dates.index(t_1d+'.txt')-19, 0)]        
    t_1d_str = 
t_1d.replace('.txt','').replace('.','')
    
    # q query results
    
    i_q_files = os.listdir(source_path)
    i_q_files = [i for i in i_q_files if t_20d<=i<=t_1d+'.txt']
    i_q = pd.concat([pd.read_csv(os.path.join(source_path, f), sep = '|', ) for f in i_q_files], axis=0)
    
    i_q = i_q.rename(columns = {'code': 'Ticker', 'date': 'T-1d'})
    i_q['Ticker'] = i_q['Ticker'].astype(int).astype(str).str.zfill(6)
    i_q['T-1d'] = pd.to_datetime(i_q['T-1d'])
    
    # calculate trailing 20d intraday pqcorr
    
    s20 = i_q.groupby('Ticker').agg({'p_sum': sum,'p2_sum': sum,
                                    'q_pct_sum': sum,'q_dpct_sum': sum, 
                                    'q_pct2_sum': sum,'q_dpct2_sum': sum,  
                                    'pq_pct_sum': sum,'pq_dpct_sum': sum, 
                                    'i_cnt': sum})
    s20['p_mean'] = s20['p_sum'].divide(s20['i_cnt'])
    s20['q_pct_mean'] = s20['q_pct_sum'].divide(s20['i_cnt'])
    
    s20['corr_nom'] = s20['pq_pct_sum'] - s20['p_sum'].multiply(s20['q_pct_mean']) - s20['q_pct_sum'].multiply(s20['p_mean']) + s20['p_sum'].multiply(s20['q_pct_sum']).divide(s20['i_cnt'])
    s20['corr_denom_p'] = np.sqrt(s20['p2_sum'] - s20['p_mean'].pow(2).multiply(s20['i_cnt'])*2 + s20['p_mean'].pow(2).multiply(s20['i_cnt']))
    s20['corr_denom_q_pct'] = np.sqrt(s20['q_pct2_sum'] - s20['q_pct_mean'].pow(2).multiply(s20['i_cnt'])*2 + s20['q_pct_mean'].pow(2).multiply(s20['i_cnt']))    
    s20['pq_pct_corr_t20d'] = s20['corr_nom'].divide(s20['corr_denom_p']).divide(s20['corr_denom_q_pct'])
    
    s20['q_dpct_mean'] = s20['q_dpct_sum'].divide(s20['i_cnt'])
    s20['corr_nom'] = s20['pq_dpct_sum'] - s20['p_sum'].multiply(s20['q_dpct_mean']) - s20['q_dpct_sum'].multiply(s20['p_mean']) + s20['p_sum'].multiply(s20['q_dpct_sum']).divide(s20['i_cnt'])
    s20['corr_denom_p'] = np.sqrt(s20['p2_sum'] - s20['p_mean'].pow(2).multiply(s20['i_cnt'])*2 + s20['p_mean'].pow(2).multiply(s20['i_cnt']))
    s20['corr_denom_q_pct'] = np.sqrt(s20['q_dpct2_sum'] - s20['q_dpct_mean'].pow(2).multiply(s20['i_cnt'])*2 + s20['q_dpct_mean'].pow(2).multiply(s20['i_cnt']))    
    s20['pq_dpct_corr_t20d'] = s20['corr_nom'].divide(s20['corr_denom_p']).divide(s20['corr_denom_q_pct'])
    
    s20 = s20.reset_index()
    s20['T-1d'] = pd.to_datetime(t_1d_str, format='%Y%m%d')
    s20 = s20[['Ticker', 'T-1d', 'pq_pct_corr_t20d','pq_dpct_corr_t20d']]   
    
    # combine
        
    icom = s20.merge(i_cal, on = ['T-
1d'], how = 'left')
    
    icom['pq_pct_corr_t20d'] = icom['pq_pct_corr_t20d'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
    icom['pq_dpct_corr_t20d'] = icom['pq_dpct_corr_t20d'].replace(np.inf,np.nan).replace(-np.inf,np.nan)
    icom[['Ticker', 'DataDate', 'T-1d', 'pq_pct_corr_t20d', 'pq_dpct_corr_t20d']].to_sql('F001_COR_FORMAT', 
                                                                                   index=False,
                                                                                   if_exists = 'append',
                                                                                   con = conn)

    


