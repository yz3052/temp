﻿#$%^&* pCorpAct_cn_dvd_frcst.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu May 19 10:34:28 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime


# this is trying to forecast dvd record dates in a matrix form.
# do not use this script. Use dvd_frcst instead.


### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])


### get c 

i_c = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                           s_dq_close as c, s_dq_adjclose / s_dq_adjpreclose - 1 
                    from wind_prod.dbo.ashareeodprices 
                    where trade_dt >='20150101' ''')
i_c.columns = ['ticker','datadate','c','rawret']
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format = '%Y%m%d')
i_c = i_c.sort_values(['ticker', 'datadate'])

i_c['rawret_p1d'] = i_c.groupby('ticker')['rawret'].shift(-1)
i_c['rawret_1d'] = i_c.groupby('ticker')['rawret'].shift()
i_c['rawret_ed3d'] = i_c['rawret_p1d'].add(i_c['rawret'],fill_value=0).add(i_c['rawret_1d'],fill_value=0)

i_c = i_c.sort_values('datadate')





### get dvd

dvd_frcst_1 = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_markit_dvd_frcst_pre20190427.parquet')
dvd_frcst_2 = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_market_dvd_frcst_20190427_20210430.parquet')
dvd_frcst = pd.concat([dvd_frcst_1, dvd_frcst_2], axis = 0)
dvd_frcst['datadate'] = pd.to_datetime(dvd_frcst['datadate'])
dvd_frcst['RecordDate'] = pd.to_datetime(dvd_frcst['RecordDate'])
dvd_frcst['AnnouncementDate'] = pd.to_datetime(dvd_frcst['AnnouncementDate'])
dvd_frcst = dvd_frcst.sort_values('datadate')

# status = next

dvd_n = dvd_frcst[dvd_frcst['DividendStatus']=='N']
dvd_n = pd.merge_asof(dvd_n, i_c[['ticker','datadate','c']], by = 'ticker', on = 'datadate')
dvd_n = dvd_n.merge(i_c[['ticker','datadate','rawret_ed3d']].rename(columns={'datadate':'AnnouncementDate'}),
                    on=['ticker','AnnouncementDate'],how='left')
dvd_n['dvd_unadjret_frst'] = dvd_n['UnadjustedGrossAmt'].divide(dvd_n['c'])
dvd_n['dvd_ret_frcst'] = dvd_n['AdjustedGrossAmt'].divide(dvd_n['c'])

dvd_n = dvd_n.sort_values(['ticker', 'datadate'])

c_long = ((dvd_n['AnnouncementDate'] - dvd_n['datadate']).dt.days<=14) \
         & (dvd_n['ADConfirmed']=='No')\
         & (dvd_n['dvd_ret_frcst']>0.02)
dvd_n['sgnl_long_bfAnn'] = np.nan
dvd_n.loc[c_long, 'sgnl_long_bfAnn'] = 1

dvd_n['d2r
ec'] = yu.get_tdate_cnt(dvd_n['datadate'],dvd_n['RecordDate'])

dvd_n['sgnl_prerec'] = np.nan
c_rec = (dvd_n['d2rec'] <= 10) \
        & (dvd_n['d2rec'] >= 2) \
        & (dvd_n['dvd_ret_frcst']>0.02) \
        & ((dvd_n['datadate']-dvd_n['AnnouncementDate']).dt.days>=1)
dvd_n.loc[c_rec, 'sgnl_prerec'] = 1

dvd_n['sgnl_prerec_v2'] = np.nan
c_rec = (dvd_n['d2rec'] <= 10) \
        & (dvd_n['d2rec'] >= 2) \
        & (dvd_n['dvd_ret_frcst']>0.02)\
        & (dvd_n['rawret_ed3d']>=0)\
        & ((dvd_n['datadate']-dvd_n['AnnouncementDate']).dt.days>=3)
dvd_n.loc[c_rec, 'sgnl_prerec_v2'] = 1





### combine

icom = i_sd.merge(dvd_n, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['sgnl_long_bfAnn'] = icom.groupby('ticker')['sgnl_long_bfAnn'].ffill(limit = 5)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31') ].\
            dropna(subset=['sgnl_long_bfAnn','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_long_bfAnn','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1.groupby('ticker')['pnl_ac'].sum().sort_values()
o_1[o_1.ticker=='600887.SH'].set_index('datadate')['pnl_ac'].cumsum().plot()


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31') ].\
            dropna(subset=['sgnl_prerec','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_prerec','BarrRet_CLIP_USD+1d', static_data = i_sd) # 


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31') ].\
            dropna(subset=['sgnl_prerec_v2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_prerec_v2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1.groupby('ticker')['pnl_ac'].sum().sort_values()
t1 = icom[icom.ticker == '600018.SH']

