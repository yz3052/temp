﻿#$%^&* pCNINFO_unlock.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 25 08:54:04 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

from yz.util import uniformed_rank, bt_cn, create_cn_3x3, get_sql, explore



# this uses cninfo's data


### get sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','MC_l1d','avgPVadj','avgVadj',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'volatility','spread','BarrRet_SRISK_USD+1d','csi300_flag']]
i_sd_map = i_sd_map.sort_values('datadate')


### get close price

i_c = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                 s_dq_adjclose as adjc 
                 from wind.dbo.ashareeodprices''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format = '%Y%m%d')
i_c = i_c.sort_values('datadate')

i_c_dd = i_c['datadate'].drop_duplicates()

### get longer-term adv

i_adv = pw.get_wind_adv()


### get adjf

i_adjf = yu.get_sql('''select trade_dt as datadate, s_info_windcode as ticker,
                    S_DQ_ADJFACTOR as adjf 
                    from wind.dbo.ashareeodprices''')
i_adjf['datadate'] = pd.to_datetime(i_adjf['datadate'], format = '%Y%m%d')
i_adjf = i_adjf.sort_values('datadate')


### get unlock data

i_act_unlock = pd.read_parquet(r'S:\Data\China Data Hunt\cache\cninfo_actual_unlock_date.parquet')
'''
ORGNAME	机构名称	
SECCODE	证券代码	
SECNAME	证券简称	
DECLAREDATE	公告日期	
F001V	股东名称	
F003D	实际解除限售日	date		
F004N	实际解除限售数量	decimal		单位：股
F005N	实际解除限售比例	decimal		单位：％；实际解除限售数量占总股本比例
F006V	限售原因	varchar		通过p_public0006可获取，总类编码为100
F007V	限售原因编码	varchar		
F008N	实际可流通数量	decimal		单位：股
F009N	序号	decimal		用于区分同一天存在同一股东多个解禁项目
'''


i_forecast_unlock_raw = pd.read_parquet(r'S:\Data\China Data Hunt\cache\cninfo_forecast_unlock_date.parquet')
'''
ORGNAME	机构名称			
SECCODE	证券代码			
SECNAME	证券简称			
DECLAREDATE	公告日期			
F001V	股东名称	varchar		
F002D	预计解除限售日期	date		
F003N	预计解除限售数量	decimal		单位：股
F005V	限售原因编码	varchar		
F006N	序号	decimal		序号 用于区分同一天存在同一股东多个受限股份流通上市
F004V	限售原因	varchar		通过p_public0006可获取，总类编码为100
'''
i_forecast_unlock_raw = i_forecast_unlock_raw[['F001V','F002D','F003N','F004V','ticker','release_date']]
i_forecast_unlock_raw = i_forecast_unlock_raw.\
                        rename(columns={'F002D':'frcst_date','F003N':'unlock_shares',
                                        'F004V':'unlock_reas
on','F001V':'shareholder'})
#!
#! i_forecast_unlock_raw = i_forecast_unlock_raw[i_forecast_unlock_raw['unlock_reason']=='承诺限售']
#!
i_forecast_unlock_raw['frcst_date'] = pd.to_datetime(i_forecast_unlock_raw['frcst_date'])
i_forecast_unlock_raw['release_date'] = pd.to_datetime(i_forecast_unlock_raw['release_date'])
i_forecast_unlock_raw = i_forecast_unlock_raw.rename(columns={'release_date': 'datadate'})

i_forecast_unlock = i_forecast_unlock_raw.groupby(['ticker','frcst_date','datadate'])['unlock_shares'].sum().reset_index()

i_forecast_unlock = i_forecast_unlock[(i_forecast_unlock['frcst_date']-i_forecast_unlock['datadate']).dt.days>3]

# the above or change to: exclude rows that appear in actual table 
# we only trade the forecast part; do not trade the official release part 
# or only select unlocks that represent a bigger chunk of SO

i_forecast_unlock = i_forecast_unlock.sort_values(['datadate'])
i_forecast_unlock = pd.merge_asof(i_forecast_unlock, i_adjf, by='ticker', on = 'datadate')
i_forecast_unlock = i_forecast_unlock.rename(columns = {'adjf':'adjf_at_disclosure'})
i_forecast_unlock['adjf_at_disclosure'] = i_forecast_unlock['adjf_at_disclosure'].fillna(1)


# get adjc upon issuance
i_forecast_unlock = i_forecast_unlock.sort_values('datadate')
i_forecast_unlock = pd.merge_asof(i_forecast_unlock, i_c, by = 'ticker', on ='datadate')
i_forecast_unlock = i_forecast_unlock.rename(columns = {'adjc': 'adjc_hist'})
i_forecast_unlock['adjhist'] = i_forecast_unlock['adjhist'].fillna(0.0001)


### loop to calculate metrics batch 1
# days 2 next unlock, ,n1 unlock, n2 unlock, time-weighted unlock amount 

o_sum = []

for dt in pd.date_range(start='2016-01-01', end='2021-12-31'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    t_c_recent = i_c[i_c['datadate']==i_c_dd[i_c_dd<=dt].max()].rename(columns = {'adjc':'adjc_recent'})
    t_c_recent = t_c_recent[['ticker','adjc_recent']]
    
    t_frcst_unlock = i_forecast_unlock[(i_forecast_unlock['datadate']<=dt) & (i_forecast_unlock['frcst_date']>dt+pd.to_timedelta('3 days'))]
    t_frcst_unlock = t_frcst_unlock.merge(t_c_recent, on = 'ticker', how = 'left')
    t_frcst_unlock = t_frcst_unlock.sort_values(['ticker','frcst_date'])
    t_frcst_unlock['datadate'] = dt
    t_frcst_unlock['w0p5'] = (t_frcst_unlock['frcst_date']-t_frcst_unlock['datadate']).dt.days.apply(lambda x: min(1,np.exp((10-x)/0.5)))
    t_frcst_unlock['w20'] = (t_frcst_unlock['frcst_date']-t_frcst_unlock['datadate']).dt.days.apply(lambda x: mi
n(1,np.exp((10-x)/20)))
    t_frcst_unlock['w5'] = (t_frcst_unlock['frcst_date']-t_frcst_unlock['datadate']).dt.days.apply(lambda x: min(1,np.exp((10-x)/5)))
    

    
    # get data for the next unlock 
    # days to the next unlock
    # unlock shares of the next unlock 
    t_frcst_unlock_n1 = t_frcst_unlock.groupby('ticker').head(1)
    t_frcst_unlock_n1['flag_n1'] = 1
    t_frcst_unlock_n1['days2n1'] = (t_frcst_unlock_n1['frcst_date']-t_frcst_unlock_n1['datadate']).dt.days
    t_frcst_unlock_n1['unlock_shares_n1'] = t_frcst_unlock_n1['unlock_shares']
    
    s_n1 = t_frcst_unlock_n1[['ticker','unlock_shares_n1','days2n1','adjc_recent','adjc_hist']]
    
    # get data for the 2nd next unlock 
    # days to the 2nd next unlock 
    # unlock shares of the 2nd next unlock 
    t_frcst_unlock_n2 = t_frcst_unlock.groupby('ticker').head(2)
    t_frcst_unlock_n2_cnt = t_frcst_unlock_n2.groupby('ticker')['frcst_date'].nunique().reset_index()
    t_frcst_unlock_n2_cnt = t_frcst_unlock_n2_cnt[t_frcst_unlock_n2_cnt['frcst_date']==2]
    t_frcst_unlock_n2 = t_frcst_unlock_n2[t_frcst_unlock_n2['ticker'].isin(t_frcst_unlock_n2_cnt['ticker'].tolist())]
    t_frcst_unlock_n2 = t_frcst_unlock_n2.drop_duplicates(subset='ticker', keep = 'last')
    t_frcst_unlock_n2['flag_n2'] = 1
    t_frcst_unlock_n2['days2n2'] = (t_frcst_unlock_n2['frcst_date']-t_frcst_unlock_n2['datadate']).dt.days
    t_frcst_unlock_n2['unlock_shares_n2'] = t_frcst_unlock_n2['unlock_shares']
    
    s_n2 = t_frcst_unlock_n2[['ticker','unlock_shares_n2','days2n2']]
    
    # days to all future unlock, decayed, then use it to weight unlock shares
    t_frcst_unlock['w5_x_shares'] = t_frcst_unlock['w5'].multiply(t_frcst_unlock['unlock_shares'])
    t_frcst_unlock['w20_x_shares'] = t_frcst_unlock['w20'].multiply(t_frcst_unlock['unlock_shares'])
    t_frcst_unlock['w0p5_x_shares'] = t_frcst_unlock['w0p5'].multiply(t_frcst_unlock['unlock_shares'])
    
    s_w5 = t_frcst_unlock[(t_frcst_unlock['frcst_date']-t_frcst_unlock['datadate']).dt.days<=30].\
            groupby('ticker')[['w5_x_shares','w5']].apply(lambda x: x['w5_x_shares'].sum()/x['w5'].sum()).reset_index()
    s_w5 = s_w5.rename(columns = {0: 'unlock_shares_tw5'})
    s_w20 = t_frcst_unlock.groupby('ticker')[['w20_x_shares','w20']].apply(lambda x: x['w20_x_shares'].sum()/x['w20'].sum()).reset_index()
    s_w20 = s_w20.rename(columns = {0: 'unlock_shares_tw20'})
    s_w0p5 = t_frcst_unlock.groupby('ticker')[['w0p5_x_shares','w0p5']].apply(l
ambda x: x['w0p5_x_shares'].sum()/x['w0p5'].sum()).reset_index()
    s_w0p5 = s_w0p5.rename(columns = {0: 'unlock_shares_tw0p5'})
    
    # output
    t_sum = s_n1.merge(s_n2, on = 'ticker', how = 'outer')
    t_sum = t_sum.merge(s_w5, on = 'ticker', how = 'outer')
    t_sum = t_sum.merge(s_w20, on = 'ticker', how = 'outer')
    t_sum = t_sum.merge(s_w0p5, on = 'ticker', how = 'outer')
    t_sum['datadate'] = dt
    o_sum.append(t_sum)
    
o_sum = pd.concat(o_sum, axis = 0)


### loop to calculate metrics batch 2
# corporate action adjusted, adv 

o_sum2 = []

for dt in pd.date_range(start='2016-01-01', end='2021-12-31'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    t_frcst_unlock = i_forecast_unlock[(i_forecast_unlock['datadate']<=dt) & (i_forecast_unlock['frcst_date']>dt+pd.to_timedelta('3 days'))]
    t_frcst_unlock = t_frcst_unlock.sort_values(['ticker','frcst_date'])
    t_frcst_unlock['datadate'] = dt
    
    t_adjf = i_adjf[i_adjf['datadate']==i_adjf.loc[i_adjf['datadate']<=dt, 'datadate'].max()]
    t_adjf = t_adjf[['ticker','adjf']]
    t_frcst_unlock = t_frcst_unlock.merge(t_adjf, on = 'ticker', how = 'left')
    t_frcst_unlock = t_frcst_unlock.rename(columns={'adjf': 'adjf_at_dd'})
    t_frcst_unlock['adjf_at_dd'] = t_frcst_unlock['adjf_at_dd'].fillna(1)
    t_frcst_unlock['unlock_shares'] = t_frcst_unlock['unlock_shares'].divide(t_frcst_unlock['adjf_at_disclosure']).multiply(t_frcst_unlock['adjf_at_dd'])
    
    t_adv = i_adv[i_adv['datadate']==i_adv.loc[i_adv['datadate']<=dt, 'datadate'].max()]
    t_adv = t_adv[['ticker','adv_t20d','adv_t65d','adv_t130d']]
    t_frcst_unlock = t_frcst_unlock.merge(t_adv, on = 'ticker', how = 'left')
    
    t_frcst_unlock['unlockv2_dv_a20dv'] = t_frcst_unlock['unlock_shares'].divide(t_frcst_unlock['adv_t20d'])
    t_frcst_unlock['unlockv2_dv_a65dv'] = t_frcst_unlock['unlock_shares'].divide(t_frcst_unlock['adv_t65d'])
    t_frcst_unlock['unlockv2_dv_a130dv'] = t_frcst_unlock['unlock_shares'].divide(t_frcst_unlock['adv_t130d'])
    
    t_frcst_unlock['days2unlock'] = (t_frcst_unlock['frcst_date']-t_frcst_unlock['datadate']).dt.days
    t_frcst_unlock['unlockv2_dv_a65dv_dv_d2unlock'] = t_frcst_unlock['unlockv2_dv_a65dv'].divide(t_frcst_unlock['days2unlock'])
    
    t_sum1 = t_frcst_unlock.groupby('ticker')['unlockv2_dv_a65dv_dv_d2unlock'].sum().reset_index()
    t_sum1['unlockv2_dv_a65dv_dv_d2unlock_sgnl'] = -t_sum1['unlockv2_dv_a65dv_dv_d2unlock']
    t_sum1.loc[t_sum1['unlockv2_dv_a65dv_dv_d2un
lock_sgnl']<-1, 'unlockv2_dv_a65dv_dv_d2unlock_sgnl'] = -1
    
    c65d = (t_frcst_unlock['days2unlock']<=60) & (t_frcst_unlock['unlockv2_dv_a65dv']>=65)
    t_frcst_unlock.loc[c65d, 'a65dv_sgnl'] = -1
    
    t_sum2 = t_frcst_unlock.groupby('ticker')['a65dv_sgnl'].sum().reset_index()
    t_sum2.loc[t_sum2['a65dv_sgnl']<-1, 'a65dv_sgnl'] = -1
    
    # output
    t_sum = t_sum1.merge(t_sum2, on = 'ticker', how = 'outer')
    t_sum['datadate'] = dt
    o_sum2.append(t_sum)
    
o_sum2 = pd.concat(o_sum2, axis = 0)

### get o_c_ret 

i_o_c_ret = pw.get_wind_mkt_data(col_list = ['ticker', 'datadate', 'adjret_o_c'])
i_o_c_ret = i_o_c_ret.sort_values(['ticker', 'datadate'])

i_o_c_ret['adjret_o_c_t20d'] = i_o_c_ret.groupby('ticker').rolling(20)['adjret_o_c'].sum().values





#-------------------------------------------------------------------------
### combine

icom = i_sd_map.merge(o_sum, on = ['datadate','ticker'], how = 'left')
icom = icom.merge(o_sum2, on = ['datadate','ticker'], how = 'left')
icom = icom.merge(i_o_c_ret, on = ['datadate','ticker'], how = 'left')
icom = icom.merge(i_adv, on = ['datadate','ticker'], how = 'left')

icom = icom.sort_values(['ticker','datadate'])


#-------------------------------------------------------------------------
### backtest


### n1 unlock

c1 = icom['days2n1'].between(3, 15)
icom['days2n1_sgnl'] = np.nan
icom.loc[c1, 'days2n1_sgnl'] = -1

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['days2n1_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'days2n1_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.14 / 0.53


### n1 n2 unlock, unlock/adv

icom['unlock1_dv_adv'] = icom['unlock_shares_n1'].divide(icom['adv_t130d'])
icom.loc[icom['unlock1_dv_adv'].abs()>1, 'unlock1_dv_adv'] = 1
icom['unlock2_dv_adv'] = icom['unlock_shares_n2'].divide(icom['adv_t130d'])
icom.loc[icom['unlock2_dv_adv'].abs()>1, 'unlock2_dv_adv'] = 1

c1 = icom['days2n1'].between(3, 60)
icom['unlock1_dv_v_sgnl'] = np.nan
icom.loc[c1, 'unlock1_dv_v_sgnl'] = - icom.loc[c1, 'unlock1_dv_adv']

c1 = icom['days2n2'].between(3, 60)
icom['unlock2_dv_v_sgnl'] = np.nan
icom.loc[c1, 'unlock2_dv_v_sgnl'] = - icom.loc[c1, 'unlock2_dv_adv']

icom['unlock12_dv_v_sgnl'] = icom[['unlock1_dv_v_sgnl','unlock2_dv_v_sgnl']].min(axis=1)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['unlock12_dv_v_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=[
'ticker','datadate']),
            'unlock12_dv_v_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.11 / 2.39, 12.5m ###!!!

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&((icom['adjc_recent'].divide(icom['adjc_hist'])>0.5)|icom['adjc_recent'].divide(icom['adjc_hist']).isnull())].\
            dropna(subset=['unlock12_dv_v_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'unlock12_dv_v_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.17 / 2.43

# this becomes 3.04 / 2.59, 10m if we only use 非公开发行限售 data, event no = 7035
# 0.54 / 0.25, 0.4m if 股权激励, event no = 7066
# 1.55 / 1.32, 3m if 发行限售, event np = 11148
# 0.21 / -0.01, if 高管限售, event np = 3792
# 0.07/-0.16, -0.2m if 承诺限售



### n1 unlock, unlock/adv

icom['unlock_dv_adv'] = icom['unlock_shares_n1'].divide(icom['adv_t130d']) # avgVadj
icom.loc[icom['unlock_dv_adv'].abs()>1, 'unlock_dv_adv'] = 1

c1 = icom['days2n1'].between(3, 15)
icom['days2n1_dv_v_sgnl'] = np.nan
icom.loc[c1, 'days2n1_dv_v_sgnl'] = - icom.loc[c1, 'unlock_dv_adv']

c1 = icom['days2n1'].between(3, 60)
icom['unlock_dv_v_sgnl2'] = np.nan
icom.loc[c1, 'unlock_dv_v_sgnl2'] = - icom.loc[c1, 'unlock_dv_adv']

icom['unlock_dv_v_sgnl3'] = np.sign(icom['unlock_dv_v_sgnl2'])

icom.loc[icom['unlock_dv_v_sgnl2']<0, 'flag_existing_sgnl'] = 1
icom['unlock_dv_v_sgnl4'] = icom.groupby('ticker')['unlock_dv_v_sgnl2'].ffill(limit = 40)
icom.loc[icom['flag_existing_sgnl']==1, 'unlock_dv_v_sgnl4'] = np.nan

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['days2n1_dv_v_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'days2n1_dv_v_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.53 / 1.21, 3m

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['unlock_dv_v_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'unlock_dv_v_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.09 / 2.36, 12.5m ###!!!

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['csi300_flag']==1)].\
            dropna(subset=['unlock_dv_v_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'unlock_dv_v_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.66 / 1.29

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['csi300_flag']==1)].\
            dropna(subset=['unlock_dv_v_sgnl4','BarrRet_CLIP_USD+1d']).drop_duplicate
s(subset=['ticker','datadate']),
            'unlock_dv_v_sgnl4','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.28 / -0.09 hold after unlock -> no alpha at all



### n1 unlock, unlock/(20 x adv) 

icom['unlock_dv_20adv'] = icom['unlock_shares_n1'].divide(icom['avgVadj']*20)
icom.loc[icom['unlock_dv_20adv'].abs()>1, 'unlock_dv_20adv'] = 1

c1 = icom['days2n1'].between(3, 60)
icom['days2n1_dv_20v_sgnl'] = np.nan
icom.loc[c1, 'days2n1_dv_20v_sgnl'] = - icom.loc[c1, 'unlock_dv_20adv']
icom.loc[c1, 'days2n1_dv_20v_sgnl2'] = - np.sign(icom.loc[c1, 'unlock_dv_20adv'])

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2021-12-31')].\
            dropna(subset=['days2n1_dv_20v_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'days2n1_dv_20v_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.74 / 2.19, 6m 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['csi300_flag']==1)].\
            dropna(subset=['days2n1_dv_20v_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'days2n1_dv_20v_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.24 / 0.84





### time-weighted unlock shares / adv

icom['tw5_dv_pv'] = icom['unlock_shares_tw5'].divide(icom['avgVadj'])
icom.loc[icom['tw5_dv_pv'].abs()>1, 'tw5_dv_pv'] = 1

icom['tw5_dv_pv_sgnl'] = np.nan
icom['tw5_dv_pv_sgnl'] = - icom['tw5_dv_pv']

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['tw5_dv_pv_sgnl']>0)].\
            dropna(subset=['tw5_dv_pv_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'tw5_dv_pv_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.27 / 0.67


icom['tw20_dv_pv'] = icom['unlock_shares_tw20'].divide(icom['avgVadj'])
icom.loc[icom['tw20_dv_pv'].abs()>1, 'tw20_dv_pv'] = 1

icom['tw20_dv_pv_sgnl'] = np.nan
icom['tw20_dv_pv_sgnl'] = - icom['tw20_dv_pv']

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['tw20_dv_pv_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'tw20_dv_pv_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # a bit worse 



icom['tw0p5_dv_pv'] = icom['unlock_shares_tw0p5'].divide(icom['avgVadj'])
icom.loc[icom['tw0p5_dv_pv'].abs()>1, 'tw0p5_dv_pv'] = 1

icom['tw0p5_dv_pv_sgnl'] = np.nan
icom['tw0p5_dv_pv_sgnl'] = - icom['tw0p5_dv_pv']

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['tw0p5_dv_pv_sgnl','BarrRet_CLIP_USD+1d']).drop
_duplicates(subset=['ticker','datadate']),
            'tw0p5_dv_pv_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.11 / 0.55


### n1 unlock; if n2 close, hold thru this period 

c1 = icom['days2n1'].between(3, 15)
c2 = ((icom['days2n1'].shift(1)>=3)|(icom['days2n1'].shift(2)>=3)|(icom['days2n1'].shift(3)>=3))&icom['days2n1'].isnull()&icom['days2n1'].between(3, 15)

icom['days2n1n2_sgnl'] = np.nan
icom.loc[c1, 'days2n1n2_sgnl'] = -1
icom.loc[c2, 'days2n1n2_sgnl'] = -1

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['days2n1n2_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'days2n1n2_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.14 / 0.53


### n1 unlock / adv + o2c 

icom['unlock_dv_adv'] = icom['unlock_shares_n1'].divide(icom['avgVadj'])
icom.loc[icom['unlock_dv_adv'].abs()>1, 'unlock_dv_adv'] = 1

icom['adjret_o_c_t20d_rk'] = icom.groupby('datadate')['adjret_o_c_t20d'].apply(yu.uniformed_rank).values
icom['adjret_o_c_t20d_rk_t10dmax'] = icom.groupby('ticker').rolling(10)['adjret_o_c_t20d_rk'].max().values

icom['unlock_dv_adv_o2c_sgnl'] = np.nan
c1 = (icom['adjret_o_c_t20d_rk_t10dmax']>0.6) & (icom['days2n1'].between(3, 15))
icom.loc[c1, 'unlock_dv_adv_o2c_sgnl'] = - icom.loc[c1, 'unlock_dv_adv']

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['unlock_dv_adv_o2c_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'unlock_dv_adv_o2c_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #2.34 / 1.35



### unlockv2_dv_a65dv_dv_d2unlock_sgnl

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['unlockv2_dv_a65dv_dv_d2unlock_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'unlockv2_dv_a65dv_dv_d2unlock_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.69 / 2.03, 7.5m


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['a65dv_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'a65dv_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.43 / 1.11




#-------------------------------------------------------------------------
### hold short positions 20-3 days before unlock

icom2 = icom.copy()
icom2.loc[icom2['d2unlock'].between(3,20), 'sgnl'] = -1

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d
']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 2.82 / 2.55

### hold short positions 20-3 days before unlock, HK uni

icom2 = icom.copy()
icom2 = icom2[icom2['isin_hk_uni']==1]
icom2.loc[icom2['d2unlock'].between(3,20), 'sgnl'] = -1

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 1.91 / 1.67

t1 = explore(icom2, 'sgnl')


### hold short positions 10-3 days before unlock

icom2 = icom.copy()
icom2.loc[icom2['d2unlock'].between(3,10), 'sgnl'] = -1

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 3.11 / 2.68



o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.9 / 0.76


o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31') & (icom2['a50_300_flag']==1)].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.97 / -0.13


### hold short positions 10-3 days before unlock, HK uni

icom2 = icom.copy()
icom2 = icom2[icom2['isin_hk_uni']==1]
icom2.loc[icom2['d2unlock'].between(3,10), 'sgnl'] = -1

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 2.5 / 2.13

### hold short positions 3 days before - 3 days after unlock, HK uni
icom2 = icom.copy()
icom2 = icom2[icom2['isin_hk_uni']==1]
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['has3'] = icom2.groupby('ticker').rolling(6)['d2unlock'].apply(lambda x: np.any(x==3), raw = True).values
icom2.loc[icom2['has3']==1, 'sgnl'] = -1

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) 
#prcs -0.73 / -1.02

t1 = icom2[icom2.ticker=='000008.SZ']

### hold short positions 3 days before - 27 days after unlock, HK uni
icom2 = icom.copy()
icom2 = icom2[icom2['isin_hk_uni']==1]
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['has3'] = icom2.groupby('ticker').rolling(30)['d2unlock'].apply(lambda x: np.any(x==3), raw = True).values
icom2.loc[icom2['has3']==1, 'sgnl'] = -1

o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs -1.0 / -1.1

