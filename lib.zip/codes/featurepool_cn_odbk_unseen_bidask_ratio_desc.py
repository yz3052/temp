﻿#$%^&* featurepool_cn_odbk_unseen_bidask_ratio_desc.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  5 16:48:33 2022

@author: thzhang
"""

import sys
import os
import pandas as pd
import numpy as np

import datetime

from sqlalchemy import create_engine
import urllib


# this generates 1-D descriptors 
# to be scheduled on crontab
# parquet file name is T-1d



#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------

source_path = '/export/dataprod/Feature_Pool_CN/q_odbk_unseen_size_ratio'
save_path = '/export/dataprod/Feature_Pool_CN/featurepool_desc_odbk_bidask_size_ratio'

conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))




#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------

q_dates = os.listdir(source_path)
desc_dates = os.listdir(save_path)
query_dates = list(set(q_dates).difference(set(desc_dates)))




#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------

i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()





#------------------------------------------------------------------------------
### calculate descriptors
#------------------------------------------------------------------------------

for f in query_dates:
    
    # date string
    
    t_1d_str = f.replace('.txt','').replace('.','')
    
    # universe
    
    i_dtk = pd.read_sql('''select datadate as [T-1d], ticker as Ticker
                        from cndbprod.dbo.universe_all_cn_gem3l 
                        with (nolock)
                        where datadate = '{0}'
                        '''.format(t_1d_str), conn)
    i_dtk = i_dtk.drop_duplicates(subset = ['T-1d', 'Ticker'], keep = 'last')
    
    # get q query results
    
    i_q = pd.read_csv(os.path.join(source_path, f), sep = '|', )    
    i_q =
 i_q.rename(columns = {'code': 'Ticker', 'date': 'T-1d'})
    i_q['Ticker'] = i_q['Ticker'].astype(int).astype(str).str.zfill(6)
    i_q['T-1d'] = pd.to_datetime(i_q['T-1d'])    
    
    # combine
    
    icom = i_dtk.merge(i_q, on = ['Ticker', 'T-1d'], how = 'left')
    icom = icom.merge(i_cal, on = ['T-1d'], how = 'left')
    icom['unseen_b_dv_s'] = icom['bid_v_gt10'] / icom['ask_v_gt10']
    icom['unseen_b_dv_s'] = icom['unseen_b_dv_s'].replace(np.inf, np.nan).replace(-np.inf, np.nan)
    icom['unseen_b_dv_s'] = icom['unseen_b_dv_s'].replace(0, np.nan)
      
        
    file_name = f.replace('.txt','.parquet')
    icom[['Ticker', 'DataDate', 'T-1d', 'unseen_b_dv_s']].to_parquet(os.path.join(save_path, file_name))
    
    os.system("chgrp summit_thzhang "+os.path.join(save_path, file_name)+";")
    os.system("chmod 770 "+os.path.join(save_path, file_name)+";")






