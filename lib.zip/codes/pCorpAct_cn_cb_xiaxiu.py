﻿#$%^&* pCorpAct_cn_cb_xiaxiu.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 18 15:31:37 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

#
# after xiaxiu announcement, cb price jumps up, mean(o2c return ) < 0, returns of subsequent days is also low, sample size ~ 150
# 



###  sd

i_sd = pw.get_ashare_t2000_sd()




### cb-stock ticker mapping 

i_cb = yu.get_sql('''select a.s_info_windcode as ticker_cb, a.ann_dt, a.cb_info_preplandate, a.s_info_compcode,
                  b.s_info_windcode as ticker 
 from wind.dbo.CCBondIssuance a
 left join (select * from wind.dbo.WindCustomCode where S_INFO_SECURITIESTYPES='A') b
 on a.s_info_compcode = b.s_info_compcode
''')

i_cb = i_cb[i_cb['ticker'].notnull() & i_cb['ticker_cb'].notnull()]
i_cb = i_cb[['ticker', 'ticker_cb']]



### get ann (xiaxiu)

cb_sh = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pCorpAct_cn_cb_etl_sse_announcement.parquet')
cb_sh['ticker'] = cb_sh['SECURITY_CODE'].str.strip() + '.SH'
cb_sh['datadate'] = pd.to_datetime(cb_sh['SSEDATE'].str.split('<br>').str[0])
cb_sh['title'] = cb_sh['TITLE']

cb_sh = cb_sh[['ticker','datadate','title']]

cb_sz = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pCorpAct_cn_cb_etl_szse_announcement.parquet')
cb_sz['ticker'] = cb_sz['secCode'].apply(lambda x: x[0]) + '.SZ'
cb_sz['datadate'] = pd.to_datetime(pd.to_datetime(cb_sz['publishTime']).dt.date)

cb_sz = cb_sz[['ticker','datadate','title']]


cb_ann = pd.concat([cb_sh, cb_sz], axis = 0)
cb_ann['flg_xiaxiu'] = np.nan
c1 = cb_ann['title'].str.contains('xiaxiu')
c2 = ~cb_ann['title'].str.contains('buxiangxiaxiu')
c3 = cb_ann['title'].str.contains('yi')
cb_ann.loc[c1 & c2 & c3, 'flg_xiaxiu'] = 1

cb_ann_xiaxiu = cb_ann[cb_ann['flg_xiaxiu']==1]


cb_ann_xiaxiu2 = cb_ann_xiaxiu.merge(i_cb, on = ['ticker'], how = 'left')
cb_ann_xiaxiu2 = cb_ann_xiaxiu2.sort_values(['ticker_cb', 'datadate'])




### get CB price

i_cbpx = yu.get_sql('''select s_info_windcode as ticker_cb, trade_dt as datadate_p1d,
                    s_dq_preclose as prec, s_dq_open as o, s_dq_close as c 
                    from wind.dbo.CBondEODPrices
                    where trade_dt >= '20170101' and s_info_windcode in ('{0}') '''.format( "','".join(i_cb['ticker_cb'].tolist()) ))
i_cbpx = i_cbpx.sort_values(['ticker_cb', 'datadate_p1d'])
i_cbpx['o2c_p1d'] = i_cbpx['c'] / i_cbpx['o'] - 1
i_cbpx['o2c_p2d'] = i_cbpx.groupby('ticker_cb')['o2c_p1d'].shift(-1)
i_cbpx['c2c_p
1d'] = i_cbpx['c'] / i_cbpx['prec'] - 1
i_cbpx['c2c_p2d'] = i_cbpx.groupby('ticker_cb')['c2c_p1d'].shift(-1)
i_cbpx['c2c_p3d'] = i_cbpx.groupby('ticker_cb')['c2c_p1d'].shift(-2)

i_cbpx['datadate_p1d'] = pd.to_datetime(i_cbpx['datadate_p1d'])

i_cbpx = i_cbpx.merge(i_cb, on = ['ticker_cb'], how = 'left')
i_cbpx = i_cbpx[['ticker_cb', 'ticker', 'datadate_p1d', 'o2c_p1d', 'c2c_p1d', 'c2c_p2d', 'c2c_p3d']]



### combine at cb level

t2 = cb_ann_xiaxiu2.merge(i_cbpx, left_on = ['ticker_cb', 'datadate'], right_on = ['ticker_cb', 'datadate_p1d'], how = 'left')







### combine

icom = i_sd.merge(cb_ann_xiaxiu2, on = ['datadate', 'ticker'], how = 'left')
icom = icom.merge(i_cbpx, on = ['ticker', 'datadate_p1d'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])


yu.create_cn_decay(icom, 'flg_xiaxiu') # 

icom.loc[icom['flg_xiaxiu']==1, 'o2c_p1d'].hist(bins=100)
icom.loc[icom['flg_xiaxiu']==1, 'o2c_p1d'].mean()
icom.loc[icom['flg_xiaxiu']==1, 'c2c_p1d'].hist(bins=100)
icom.loc[icom['flg_xiaxiu']==1, 'c2c_p1d'].mean()
icom.loc[icom['flg_xiaxiu']==1, 'c2c_p2d'].hist(bins=100)
icom.loc[icom['flg_xiaxiu']==1, 'c2c_p2d'].mean()






cb_ann_xiaxiu.loc[cb_ann_xiaxiu['ticker'].isin(i_sd['ticker'].unique().tolist()), 'test'] = 1

