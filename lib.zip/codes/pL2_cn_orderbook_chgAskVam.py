﻿#$%^&* pL2_cn_orderbook_chgAskVam.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Apr  5 18:41:54 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine


#  This studies price orderbook-quantity correlation


### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])



### get o2c return

i_o2c = yu.get_sql('''SELECT [datadate],[ticker],[close_1hr_vwap]/[open_1hr_vwap]-1 as o2c_ret FROM [CNDBPROD].[dbo].[TRTH_OPENCLOSE_CN]''')
c_sh = i_o2c['ticker'].str[0].isin(['6'])
c_sz = i_o2c['ticker'].str[0].isin(['0', '3'])
i_o2c.loc[c_sh, 'ticker'] = i_o2c.loc[c_sh, 'ticker'] + '.SH'
i_o2c.loc[c_sz, 'ticker'] = i_o2c.loc[c_sz, 'ticker'] + '.SZ'


### odbk metrics

i_odbk4 = yu.get_q("get `:/export/datadev/Data/SHSZ/ORDER_metrics/orderbook_metrics_batch1_04")

i_odbk4['code'] = i_odbk4['code'].str.decode('utf8')
c_sh = i_odbk4['code'].str[0].isin(['6'])
c_sz = i_odbk4['code'].str[0].isin(['0','3'])
i_odbk4.loc[c_sh, 'ticker'] = i_odbk4.loc[c_sh, 'code'] + '.SH'
i_odbk4.loc[c_sz, 'ticker'] = i_odbk4.loc[c_sz, 'code'] + '.SZ'
i_odbk4['datadate'] = pd.to_datetime(i_odbk4['date'])
i_odbk4 = i_odbk4.sort_values(['ticker', 'datadate'])

### odbk metrics #6

i_odbk6 = yu.get_q("get `:/export/datadev/Data/SHSZ/ORDER_metrics/orderbook_metrics_batch1_06")

i_odbk6['code'] = i_odbk6['code'].str.decode('utf8')
c_sh = i_odbk6['code'].str[0].isin(['6'])
c_sz = i_odbk6['code'].str[0].isin(['0','3'])
i_odbk6.loc[c_sh, 'ticker'] = i_odbk6.loc[c_sh, 'code'] + '.SH'
i_odbk6.loc[c_sz, 'ticker'] = i_odbk6.loc[c_sz, 'code'] + '.SZ'
i_odbk6['datadate'] = pd.to_datetime(i_odbk6['date'])
i_odbk6 = i_odbk6.sort_values(['ticker', 'datadate'])



### combine

icom = i_sd.merge(i_odbk4, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_odbk6, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_o2c, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL']
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']










### 20d std of mean askV
# this is not better than the "so" version below 

icom['ask_avgV_std_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ask_avgV'].std().values
icom['ask_avgV_std_t20d_bk'] = icom.groupby('d
atadate')['ask_avgV_std_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask_avgV_std_t20d_orth'] = icom.groupby('datadate')[COLS+['ask_avgV_std_t20d']].apply(lambda x: yu.orthogonalize_cn(x['ask_avgV_std_t20d'], x[COLS])).values
icom['ask_avgV_std_t20d_orth_bk'] = icom.groupby('datadate')['ask_avgV_std_t20d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['ask_avgV_std_t40d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['ask_avgV'].std().values
icom['ask_avgV_std_t40d_bk'] = icom.groupby('datadate')['ask_avgV_std_t40d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['ask_avgV_std_t60d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=84),on='datadate')['ask_avgV'].std().values
icom['ask_avgV_std_t60d_orth'] = icom.groupby('datadate')[COLS+['ask_avgV_std_t60d']].apply(lambda x: yu.orthogonalize_cn(x['ask_avgV_std_t60d'], x[COLS])).values
icom['ask_avgV_std_t60d_orth_sgnl'] = - icom.groupby('datadate')['ask_avgV_std_t60d_orth'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icom, ['ask_avgV_std_t20d_bk'], 'ask_avgV_std_t20d') # mono +2.5 -2
yu.create_cn_3x3(icom, ['ask_avgV_std_t40d_bk'], 'ask_avgV_std_t40d') # mono +2.5 -2.5
yu.create_cn_3x3(icom, ['ask_avgV_std_t20d_orth_bk'], 'ask_avgV_std_t20d_orth') # +2 -4

icom['ask_avgV_orth'] = icom.groupby('datadate')[COLS+['ask_avgV']].apply(lambda x: yu.orthogonalize_cn(x['ask_avgV'], x[COLS])).values
icom['ask_avgV_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ask_avgV_orth'].mean().values
icom['ask_avgV_orth_t20d_bk'] = icom.groupby('datadate')['ask_avgV_orth_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['ask_avgV_orth_t20d_bk'], 'ask_avgV_orth_t20d') # less mono: +2 +3 -3


### 20d std of mean askV vs SO
# rkdf between avgV and SO seems to be better

icom['ask_avgV_so'] = icom['ask_avgV'].divide(np.log(icom['FLOAT_l1d'])) # if not log, get a-shaped bar chart
icom['ask_avgV_so_std_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ask_avgV_so'].std().values
icom['ask_avgV_so_std_t20d_bk'] = icom.groupby('datadate')['ask_avgV_so_std_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['ask_avgV_so_std_t20d_bk'], 'ask_avgV_so_std_t20d') # mono: +2.5 -2.5

icom['ask_avgV_rk'] = icom.groupby('datadate')['ask_avgV'].apply(yu.uniformed_rank).values
icom['so_rk'] = icom.groupby('datadate')['FLOAT_l1d'].apply(yu.uniformed_ran
k).values
icom['ask_avgV_so_rkdf'] = icom['ask_avgV_rk'] - icom['so_rk']
icom['ask_avgV_so_rkdf_bk'] = icom.groupby('datadate')['ask_avgV_so_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['ask_avgV_so_rkdf_bk'] , 'ask_avgV_so_rkdf') # mono: +2 -7   



### anm_std

icom['anm_fday_df10s_std_bk'] = icom.groupby('datadate')['anm_fday_df10s_std'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['anm_fday_df10s_std_bk'], 'anm_fday_df10s_std') # mono: -4.5 +2.5

icom['anm_9093_df10s_std_bk'] = icom.groupby('datadate')['anm_9093_df10s_std'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['anm_9093_df10s_std_bk'], 'anm_9093_df10s_std') # mono: -2 +3

icom['anm_1415_df10s_std_bk'] = icom.groupby('datadate')['anm_1415_df10s_std'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['anm_1415_df10s_std_bk'], 'anm_1415_df10s_std') # random 

icom['anm_1415_df3600s_std_bk'] = icom.groupby('datadate')['anm_1415_df3600s_std'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['anm_1415_df3600s_std_bk'], 'anm_1415_df3600s_std') # random






### ask_std vs so 

icom['so_rk'] = icom.groupby('datadate')['FLOAT_l1d'].apply(yu.uniformed_rank).values
icom['ask_fday_df10s_std_rk'] = icom.groupby('datadate')['ask_fday_df10s_std'].apply(yu.uniformed_rank).values

icom['ask_fday_df10s_std_so_rkdf'] = icom['ask_fday_df10s_std_rk'] - icom['so_rk']
icom['ask_fday_df10s_std_so_rkdf_bk'] = icom.groupby('datadate')['ask_fday_df10s_std_so_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['ask_fday_df10s_std_so_rkdf_bk'], 'ask_fday_df10s_std_so_rkdf') # less mono: +1 +2 -4.5

icom['ask_1415_df10s_std_rk'] = icom.groupby('datadate')['ask_1415_df10s_std'].apply(yu.uniformed_rank).values
icom['ask_1415_df10s_std_so_rkdf'] = icom['ask_1415_df10s_std_rk'] - icom['so_rk']
icom['ask_1415_df10s_std_so_rkdf_bk'] = icom.groupby('datadate')['ask_1415_df10s_std_so_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask_1415_df10s_std_so_rkdf_orth'] = icom.groupby('datadate')[COLS+['ask_1415_df10s_std_so_rkdf']].apply(lambda x: yu.orthogonalize_cn(x['ask_1415_df10s_std_so_rkdf'], x[COLS])).values
icom['ask_1415_df10s_std_so_rkdf_orth_bk'] = icom.groupby('datadate')['ask_1415_df10s_std_so_rkdf_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['ask_1415_df10s_std_so_rkdf_bk'], 'ask_1415_df10s_std_so_rkdf') # mono: +3.8 -6.8
#yu.crea
te_cn_3x3(icom, ['ask_1415_df10s_std_so_rkdf_orth_bk'], 'ask_1415_df10s_std_so_rkdf_orth') # mono: +5 -9
###!!!

icom['ask_1415_df10s_std_dv_so'] = icom['ask_1415_df10s_std'].divide(icom['FLOAT_l1d'])
icom['ask_1415_df10s_std_dv_so_bk'] = icom.groupby('datadate')['ask_1415_df10s_std_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['ask_1415_df10s_std_dv_so_bk'], 'ask_1415_df10s_std_dv_so') # less mono: +2 -8.5

icom['ask_1415_df3600s_std_rk'] = icom.groupby('datadate')['ask_1415_df3600s_std'].apply(yu.uniformed_rank).values
icom['ask_1415_df3600s_std_so_rkdf'] = icom['ask_1415_df3600s_std_rk'] - icom['so_rk']
icom['ask_1415_df3600s_std_so_rkdf_bk'] = icom.groupby('datadate')['ask_1415_df3600s_std_so_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['ask_1415_df3600s_std_so_rkdf_bk'], 'ask_1415_df3600s_std_so_rkdf') # less mono: 1.5 -7.5



### ask_std vs so - PNL:

icom['so_rk'] = icom.groupby('datadate')['FLOAT_l1d'].apply(yu.uniformed_rank).values
icom['ask_1415_df10s_std_rk'] = icom.groupby('datadate')['ask_1415_df10s_std'].apply(yu.uniformed_rank).values
icom['ask_1415_df10s_std_so_rkdf'] = icom['ask_1415_df10s_std_rk'] - icom['so_rk']
icom['ask_1415_df10s_std_so_rkdf_sgnl'] = - icom.groupby('datadate')['ask_1415_df10s_std_so_rkdf'].apply(yu.uniformed_rank).values
icom['ask_1415_df10s_std_so_rkdf_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ask_1415_df10s_std_so_rkdf'].mean().values
icom['ask_1415_df10s_std_so_rkdf_t20d_sgnl'] = - icom.groupby('datadate')['ask_1415_df10s_std_so_rkdf_t20d'].apply(yu.uniformed_rank).values
icom['ask_1415_df10s_std_so_rkdf_orth'] = icom.groupby('datadate')[COLS+['ask_1415_df10s_std_so_rkdf']].apply(lambda x: yu.orthogonalize_cn(x['ask_1415_df10s_std_so_rkdf'], x[COLS])).values
icom['ask_1415_df10s_std_so_rkdf_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ask_1415_df10s_std_so_rkdf_orth'].mean().values
icom['ask_1415_df10s_std_so_rkdf_orth_t20d_sgnl'] = - icom.groupby('datadate')['ask_1415_df10s_std_so_rkdf_orth_t20d'].apply(yu.uniformed_rank).values
icom['ask_1415_df10s_std_so_rkdf_t20d_orth'] = icom.groupby('datadate')[COLS+['ask_1415_df10s_std_so_rkdf_t20d']].apply(lambda x: yu.orthogonalize_cn(x['ask_1415_df10s_std_so_rkdf_t20d'], x[COLS])).values
icom['ask_1415_df10s_std_so_rkdf_t20d_orth_sgnl'] = - icom.groupby('datadate')['ask_1415_df10s_std_so_rkdf_t20d_orth'].apply(yu.uniformed_
rank).values



o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ask_1415_df10s_std_so_rkdf_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_1415_df10s_std_so_rkdf_sgnl','BarrRet_CLIP_USD+1d', 
            static_data = i_sd) #
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ask_1415_df10s_std_so_rkdf_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_1415_df10s_std_so_rkdf_t20d_sgnl','BarrRet_CLIP_USD+1d', 
            static_data = i_sd) #2.38/1.35
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ask_1415_df10s_std_so_rkdf_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_1415_df10s_std_so_rkdf_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', 
            static_data = i_sd) #2.65/1.71
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ask_1415_df10s_std_so_rkdf_t20d_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_1415_df10s_std_so_rkdf_t20d_orth_sgnl','BarrRet_CLIP_USD+1d', 
            static_data = i_sd) #2.84/1.74 ###!!!





# to sql
icom['Ticker'] = icom['ticker'].str[:6]
icom['DataDate'] = icom['datadate']
param_engine = create_engine('mssql+pyodbc://summitsqldb_cndbdev') 
icom[['Ticker','DataDate','ask_1415_df10s_std_so_rkdf_t20d_orth_sgnl']].to_sql('F001_ODBK_stdChgAskV_pm_LS_MA', param_engine , index = False, if_exists = 'replace', chunksize = 10000)
icom[['Ticker','DataDate','ask_1415_df10s_std_so_rkdf_sgnl']].to_sql('F001_ODBK_stdChgAskV_pm_LS_1D', param_engine , index = False, if_exists = 'replace', chunksize = 10000)






### ask_std vs adv

icom['ask_fday_df10s_std_dv_v'] = icom['ask_fday_df10s_std'].divide(icom['V_l1d'])
icom['ask_fday_df10s_std_dv_v_bk'] = icom.groupby('datadate')['ask_fday_df10s_std_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['ask_fday_df10s_std_dv_v_bk'], 'ask_fday_df10s_std_dv_v') # less mono: -0.5 + 1.5



### ask_mean vs so

icom['so_rk'] = icom.groupby('datadate')['FLOAT_l1d'].apply(yu.uniformed_rank).values
icom['ask_9093_df10s_mean_rk'] = icom.groupby('datadate')['ask_9093_df10s_mean'].apply(yu.uniformed_rank).values
icom['ask_9093_df10s_mean_so_rkdf'] = icom['ask_9093_df10s_mean_rk'] - icom['so_rk']
icom['ask_9093_df10s_mean_so_rkdf_bk'] = icom.gr
oupby('datadate')['ask_9093_df10s_mean_so_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values


yu.create_cn_3x3(icom, ['ask_9093_df10s_mean_so_rkdf_bk'], 'ask_9093_df10s_mean_so_rkdf') #less mono: +2 -4/5







### anm mean 

icom['anm_fday_df10s_mean_bk'] = icom.groupby('datadate')['anm_fday_df10s_mean'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['anm_fday_df10s_mean_bk'], 'anm_fday_df10s_mean') # random 

### ask mean

icom['ask_fday_df10s_mean_bk'] = icom.groupby('datadate')['ask_fday_df10s_mean'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ask_fday_df10s_mean_bk'], 'ask_fday_df10s_mean') # mono: +2 -3

icom['ask_fday_df10s_mean_dv_so'] = icom['ask_fday_df10s_mean'].divide(icom['FLOAT_l1d'])
icom['ask_fday_df10s_mean_dv_so_bk'] = icom.groupby('datadate')['ask_fday_df10s_mean_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['ask_fday_df10s_mean_dv_so_bk'], 'ask_fday_df10s_mean_dv_so') # less mono: 0 2 -8















### std of change in ask volumes by market close

icom['ask_chgV_std_13001500_dv_so'] = icom['ask_chgV_std_13001500'].divide(icom['FLOAT_l1d'])
icom['ask_chgV_std_13001500_dv_so_orth'] = icom.groupby('datadate')[COLS+['ask_chgV_std_13001500_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['ask_chgV_std_13001500_dv_so'], x[COLS])).values
icom['ask_chgV_std_13001500_dv_so_orth_bk'] = icom.groupby('datadate')['ask_chgV_std_13001500_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['ask_chgV_std_13001500_dv_so_orth_bk'], 'ask_chgV_std_13001500_dv_so_orth') # mono 

icom['ask_chgV_std_14301500_bk'] = icom.groupby('datadate')['ask_chgV_std_14301500'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['ask_chgV_std_14301500_dv_so'] = icom['ask_chgV_std_14301500'].divide(icom['FLOAT_l1d'])
icom['ask_chgV_std_14301500_dv_so_bk']= icom.groupby('datadate')['ask_chgV_std_14301500_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask_chgV_std_14301500_dv_so_orth'] = icom.groupby('datadate')[COLS+['ask_chgV_std_14301500_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['ask_chgV_std_14301500_dv_so'], x[COLS])).values
icom['ask_chgV_std_14301500_dv_so_orth_bk'] = icom.groupby('datadate')['ask_chgV_std_14301500_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['ask_chgV_std_14301500_bk'], 'ask_chgV_std_14301500') # mono +8 -4
yu.create_cn_3x3(icom, ['ask_chgV_std_14301500_dv_so_bk'], 'ask_chgV_std_1430
1500_dv_so') # mono +3 -8
yu.create_cn_3x3(icom, ['ask_chgV_std_14301500_dv_so_orth_bk'], 'ask_chgV_std_14301500_dv_so_orth') # mono +5 -9

icom['ask_chgV_std_14301500_dv_so_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ask_chgV_std_14301500_dv_so_orth'].mean().values
icom['ask_chgV_std_14301500_dv_so_orth_t20d_sgnl'] = - icom.groupby('datadate')['ask_chgV_std_14301500_dv_so_orth_t20d'].apply(yu.uniformed_rank).values
icom['ask_chgV_std_14301500_dv_so_orth_sgnl'] = - icom.groupby('datadate')['ask_chgV_std_14301500_dv_so_orth'].apply(yu.uniformed_rank).values

icom['ask_chgV_std_13001500_dv_so_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ask_chgV_std_13001500_dv_so_orth'].mean().values
icom['ask_chgV_std_13001500_dv_so_orth_t20d_sgnl'] = - icom.groupby('datadate')['ask_chgV_std_13001500_dv_so_orth_t20d'].apply(yu.uniformed_rank).values
icom['ask_chgV_std_13001500_dv_so_orth_sgnl'] = - icom.groupby('datadate')['ask_chgV_std_13001500_dv_so_orth'].apply(yu.uniformed_rank).values


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ask_chgV_std_14301500_dv_so_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_chgV_std_14301500_dv_so_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.4/-8.8

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ask_chgV_std_14301500_dv_so_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_chgV_std_14301500_dv_s o_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.7 / 1.57 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ask_chgV_std_13001500_dv_so_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_chgV_std_13001500_dv_so_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.04/1.1





### std + o2c

icom['ask_chgV_std_14301500_dv_so'] = icom['ask_chgV_std_14301500'].divide(icom['FLOAT_l1d'])
icom['ask_chgV_std_14301500_dv_so_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=20),on='datadate')['ask_chgV_std_14301500_dv_so'].mean().values
icom['ask_chgV_std_14301500_dv_so_t20d_rk'] = icom.groupby('datadate')['ask_chgV_std_14301500_dv_so_t20d'].apply(yu.uniformed_rank).values

icom['o2c_ret_t20d'] = icom.groupby('ticker').rolling(datetime.timedel
ta(days=20),on='datadate')['o2c_ret'].mean().values
icom['o2c_ret_t20d_rk'] = icom.groupby('datadate')['o2c_ret_t20d'].apply(yu.uniformed_rank).values

icom['std_o2c_rkdf'] = - icom['ask_chgV_std_14301500_dv_so_t20d_rk'] - icom['o2c_ret_t20d_rk']
icom['std_o2c_rkdf_rk'] = icom.groupby('datadate')['std_o2c_rkdf'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['std_o2c_rkdf_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'std_o2c_rkdf_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #1.98/-1.19



### pm std - am std

icom['ask_chgV_std_14301500_dv_so'] = icom['ask_chgV_std_14301500'].divide(icom['FLOAT_l1d'])
icom['ask_chgV_std_14301500_dv_so_orth'] = icom.groupby('datadate')[COLS+['ask_chgV_std_14301500_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['ask_chgV_std_14301500_dv_so'], x[COLS])).values
icom['ask_chgV_std_14301500_dv_so_orth_rk'] = icom.groupby('datadate')['ask_chgV_std_14301500_dv_so_orth'].apply(yu.uniformed_rank).values
     

icom['ask_chgV_avg_ampmdf_dv_so'] = (icom['ask_chgV_avg_14301500'] - icom['ask_chgV_avg_900930']).abs().divide(icom['FLOAT_l1d'])
icom['ask_chgV_avg_ampmdf_dv_so_orth'] = icom.groupby('datadate')[COLS+['ask_chgV_avg_ampmdf_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['ask_chgV_avg_ampmdf_dv_so'], x[COLS])).values
icom['ask_chgV_avg_ampmdf_dv_so_orth_rk'] = icom.groupby('datadate')['ask_chgV_avg_ampmdf_dv_so_orth'].apply(yu.uniformed_rank).values

icom['test'] = icom['ask_chgV_std_14301500_dv_so_orth_rk'] + icom['ask_chgV_avg_ampmdf_dv_so_orth_rk']
icom['test_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=20),on='datadate')['test'].mean().values
icom['test_t20d_sgnl'] = -icom.groupby('datadate')['test_t20d'].apply(yu.uniformed_rank).values
icom['test_bk'] = icom.groupby('datadate')['test'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['test_orth'] = icom.groupby('datadate')[COLS+['test']].apply(lambda x: yu.orthogonalize_cn(x['test'], x[COLS])).values
icom['test_orth_bk'] = icom.groupby('datadate')['test_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['test_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=20),on='datadate')['test_orth'].mean().values
icom['test_orth_t20d_sgnl'] = -icom.groupby('datadate')['test_orth_t20d'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icom, ['ask_chgV_avg_ampmdf_dv_so_bk'], 'ask_chgV_avg_ampmdf_dv_so') #
yu.create_cn_3x3(icom
, ['test_bk'], 'test') # less mono: +1 +2 -8
yu.create_cn_3x3(icom, ['test_orth_bk'], 'test_orth') # 


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['test_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['test_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'test_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) 



### mean change in ask columes by market close

icom['ask_chgV_avg_14571500_dv_so'] = icom['ask_chgV_avg_14571500'].divide(icom['FLOAT_l1d'])
icom['ask_chgV_avg_14571500_dv_so_bk']= icom.groupby('datadate')['ask_chgV_avg_14571500_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask_chgV_avg_14571500_dv_so_orth'] = icom.groupby('datadate')[COLS+['ask_chgV_avg_14571500_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['ask_chgV_avg_14571500_dv_so'], x[COLS])).values
icom['ask_chgV_avg_14571500_dv_so_orth_bk'] = icom.groupby('datadate')['ask_chgV_avg_14571500_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['ask_chgV_avg_14571500_dv_so_bk'], 'ask_chgV_avg_14571500_dv_so') # A-shaped -4 +2 -5.5
#yu.create_cn_3x3(icom, ['ask_chgV_avg_14571500_dv_so_orth_bk'], 'ask_chgV_avg_14571500_dv_so_orth') # A-shaped -4 +2.5 -5.5


icom['net1_chgV_avg_14571500_dv_so'] = icom['net1_chgV_avg_14571500'].divide(icom['FLOAT_l1d'])
icom['net1_chgV_avg_14571500_dv_so_bk']= icom.groupby('datadate')['net1_chgV_avg_14571500_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['net1_chgV_avg_14571500_dv_so_orth'] = icom.groupby('datadate')[COLS+['net1_chgV_avg_14571500_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['net1_chgV_avg_14571500_dv_so'], x[COLS])).values
icom['net1_chgV_avg_14571500_dv_so_orth_bk'] = icom.groupby('datadate')['net1_chgV_avg_14571500_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['net1_chgV_avg_14571500_dv_so_bk'], 'net1_chgV_avg_14571500_dv_so') # A-shaped -3 +1.5 -3
#yu.create_cn_3x3(icom, ['net1_chgV_avg_14571500_dv_so_orth_bk'], 'net1_chgV_avg_14571500_dv_so_orth') # A-shaped -2.5 +1.5 -3


icom['net_chgV_avg_14571500_dv_so'] = icom['net_chgV_avg_14571500'].divide(icom['FLOAT_l1d'])
icom['net_chgV_avg_14571500_dv_so_bk']= icom.groupby('datadate')['net_chgV_avg_14571500_dv_s
o'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['net_chgV_avg_14571500_dv_so_orth'] = icom.groupby('datadate')[COLS+['net_chgV_avg_14571500_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['net_chgV_avg_14571500_dv_so'], x[COLS])).values
icom['net_chgV_avg_14571500_dv_so_orth_bk'] = icom.groupby('datadate')['net_chgV_avg_14571500_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['net_chgV_avg_14571500_dv_so_bk'], 'net_chgV_avg_14571500_dv_so') # A-shaped
#yu.create_cn_3x3(icom, ['net_chgV_avg_14571500_dv_so_orth_bk'], 'net_chgV_avg_14571500_dv_so_orth') # A-shaped -1 +2 -5.5


icom['net1_chgV_avg_900930_10s_dv_so'] = icom['net1_chgV_avg_900930_10s'].divide(icom['FLOAT_l1d'])
icom['net1_chgV_avg_900930_10s_dv_so_bk']= icom.groupby('datadate')['net1_chgV_avg_900930_10s_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['net1_chgV_avg_900930_10s_dv_so_orth'] = icom.groupby('datadate')[COLS+['net1_chgV_avg_900930_10s_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['net1_chgV_avg_900930_10s_dv_so'], x[COLS])).values
icom['net1_chgV_avg_900930_10s_dv_so_orth_bk'] = icom.groupby('datadate')['net1_chgV_avg_900930_10s_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['net1_chgV_avg_900930_10s_dv_so_bk'], 'net1_chgV_avg_900930_10s_dv_so') # mono -3 +1
#yu.create_cn_3x3(icom, ['net1_chgV_avg_900930_10s_dv_so_orth_bk'], 'net1_chgV_avg_900930_10s_dv_so_orth') # mono -3.5 +1.5


icom['net_chgV_avg_900930_10s_dv_so'] = icom['net_chgV_avg_900930_10s'].divide(icom['FLOAT_l1d'])
icom['net_chgV_avg_900930_10s_dv_so_bk']= icom.groupby('datadate')['net_chgV_avg_900930_10s_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['net_chgV_avg_900930_10s_dv_so_orth'] = icom.groupby('datadate')[COLS+['net_chgV_avg_900930_10s_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['net_chgV_avg_900930_10s_dv_so'], x[COLS])).values
icom['net_chgV_avg_900930_10s_dv_so_orth_bk'] = icom.groupby('datadate')['net_chgV_avg_900930_10s_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['net_chgV_avg_900930_10s_dv_so_bk'], 'net_chgV_avg_900930_10s_dv_so') # mono -6 +2.5
#yu.create_cn_3x3(icom, ['net_chgV_avg_900930_10s_dv_so_orth_bk'], 'net_chgV_avg_900930_10s_dv_so_orth') # mono  -6 +2


icom['ask1_chgV_avg_900930_10s_dv_so'] = icom['ask1_chgV_avg_900930_10s'].divide(icom['FLOAT_l1d'])
icom['ask1_chgV_avg_900930_10s_dv_so_bk']= icom.groupby('datadate')['ask1_chgV_avg_900930_10s_dv_so'].apply
(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask1_chgV_avg_900930_10s_dv_so_orth'] = icom.groupby('datadate')[COLS+['ask1_chgV_avg_900930_10s_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['ask1_chgV_avg_900930_10s_dv_so'], x[COLS])).values
icom['ask1_chgV_avg_900930_10s_dv_so_orth_bk'] = icom.groupby('datadate')['ask1_chgV_avg_900930_10s_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['ask1_chgV_avg_900930_10s_dv_so_bk'], 'ask1_chgV_avg_900930_10s_dv_so') # mono +2 -1.5
#yu.create_cn_3x3(icom, ['ask1_chgV_avg_900930_10s_dv_so_orth_bk'], 'ask1_chgV_avg_900930_10s_dv_so_orth') # mono  +2 -2


icom['ask_chgV_avg_900930_10s_dv_so'] = icom['ask_chgV_avg_900930_10s'].divide(icom['FLOAT_l1d'])
icom['ask_chgV_avg_900930_10s_dv_so_bk']= icom.groupby('datadate')['ask_chgV_avg_900930_10s_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask_chgV_avg_900930_10s_dv_so_orth'] = icom.groupby('datadate')[COLS+['ask_chgV_avg_900930_10s_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['ask_chgV_avg_900930_10s_dv_so'], x[COLS])).values
icom['ask_chgV_avg_900930_10s_dv_so_orth_bk'] = icom.groupby('datadate')['ask_chgV_avg_900930_10s_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['ask_chgV_avg_900930_10s_dv_so_bk'], 'ask_chgV_avg_900930_10s_dv_so') # mono +2 -5
#yu.create_cn_3x3(icom, ['ask_chgV_avg_900930_10s_dv_so_orth_bk'], 'ask_chgV_avg_900930_10s_dv_so_orth') # mono +3 -5 


icom['ask_chgV_avg_900920_dv_so'] = icom['ask_chgV_avg_900920'].divide(icom['FLOAT_l1d'])
icom['ask_chgV_avg_900920_dv_so_bk']= icom.groupby('datadate')['ask_chgV_avg_900920_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask_chgV_avg_900920_dv_so_orth'] = icom.groupby('datadate')[COLS+['ask_chgV_avg_900920_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['ask_chgV_avg_900920_dv_so'], x[COLS])).values
icom['ask_chgV_avg_900920_dv_so_orth_bk'] = icom.groupby('datadate')['ask_chgV_avg_900920_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['ask_chgV_avg_900920_dv_so_bk'], 'ask_chgV_avg_900920_dv_so') # mono +2 -6
#yu.create_cn_3x3(icom, ['ask_chgV_avg_900920_dv_so_orth_bk'], 'ask_chgV_avg_900920_dv_so_orth') # mono +2.5 -8

icom['ask_chgV_avg_920930_dv_so'] = icom['ask_chgV_avg_920930'].divide(icom['FLOAT_l1d'])
icom['ask_chgV_avg_920930_dv_so_bk']= icom.groupby('datadate')['ask_chgV_avg_920930_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask_chgV_avg_920930_dv_so_orth
'] = icom.groupby('datadate')[COLS+['ask_chgV_avg_920930_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['ask_chgV_avg_920930_dv_so'], x[COLS])).values
icom['ask_chgV_avg_920930_dv_so_orth_bk'] = icom.groupby('datadate')['ask_chgV_avg_920930_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['ask_chgV_avg_920930_dv_so_bk'], 'ask_chgV_avg_920930_dv_so') # mono less mono +1 +2 -4
#yu.create_cn_3x3(icom, ['ask_chgV_avg_920930_dv_so_orth_bk'], 'ask_chgV_avg_920930_dv_so_orth') # mono +2.5 -8


icom['ask_chgV_avg_900930_dv_so'] = icom['ask_chgV_avg_900930'].divide(icom['FLOAT_l1d'])
icom['ask_chgV_avg_900930_dv_so_bk']= icom.groupby('datadate')['ask_chgV_avg_900930_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask_chgV_avg_900930_dv_so_orth'] = icom.groupby('datadate')[COLS+['ask_chgV_avg_900930_dv_so']].apply(lambda x: yu.orthogonalize_cn(x['ask_chgV_avg_900930_dv_so'], x[COLS])).values
icom['ask_chgV_avg_900930_dv_so_orth_bk'] = icom.groupby('datadate')['ask_chgV_avg_900930_dv_so_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['ask_chgV_avg_900930_dv_so_bk'], 'ask_chgV_avg_900930_dv_so') # less mono +1 +3 -5.5
#yu.create_cn_3x3(icom, ['ask_chgV_avg_900930_dv_so_orth_bk'], 'ask_chgV_avg_900930_dv_so_orth') # mono +3 / -5 ###!!!


icom['ask_chgV_avg_900930_dv_v'] = icom['ask_chgV_avg_900930'].divide(icom['V_l1d'])
icom['ask_chgV_avg_900930_dv_v_bk']= icom.groupby('datadate')['ask_chgV_avg_900930_dv_v'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask_chgV_avg_900930_dv_v_orth'] = icom.groupby('datadate')[COLS+['ask_chgV_avg_900930_dv_v']].apply(lambda x: yu.orthogonalize_cn(x['ask_chgV_avg_900930_dv_v'], x[COLS])).values
icom['ask_chgV_avg_900930_dv_v_orth_bk'] = icom.groupby('datadate')['ask_chgV_avg_900930_dv_v_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['ask_chgV_avg_900930_dv_v_bk'], 'ask_chgV_avg_900930_dv_v') # mono: +1.5 -3
#yu.create_cn_3x3(icom, ['ask_chgV_avg_900930_dv_v_orth_bk'], 'ask_chgV_avg_900930_dv_v_orth') # mono: less mono +2.5 -1 0 -2

icom['ask_chgV_avg_900930_orth'] = icom.groupby('datadate')[COLS+['ask_chgV_avg_900930']].apply(lambda x: yu.orthogonalize_cn(x['ask_chgV_avg_900930'], x[COLS])).values
icom['ask_chgV_avg_900930_orth_bk'] = icom.groupby('datadate')['ask_chgV_avg_900930_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask_chgV_avg_900930_bk'] = icom.groupby('datadate')['ask_chgV_avg_900930'].apply(lambda x: y
u.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['ask_chgV_avg_900930_bk'], 'ask_chgV_avg_900930') # mono +3 -3
#yu.create_cn_3x3(icom, ['ask_chgV_avg_900930_orth_bk'], 'ask_chgV_avg_900930_orth') # mono +3 -4

icom['ask_chgV_avg_900930_orth_t10d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=14),on='datadate')['ask_chgV_avg_900930_orth'].mean().values
icom['ask_chgV_avg_900930_orth_t10d_sgnl'] = - icom.groupby('datadate')['ask_chgV_avg_900930_orth_t10d'].apply(yu.uniformed_rank).values
icom['ask_chgV_avg_900930_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ask_chgV_avg_900930_orth'].mean().values
icom['ask_chgV_avg_900930_orth_t20d_sgnl'] = - icom.groupby('datadate')['ask_chgV_avg_900930_orth_t20d'].apply(yu.uniformed_rank).values
icom['ask_chgV_avg_900930_orth_t40d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['ask_chgV_avg_900930_orth'].mean().values
icom['ask_chgV_avg_900930_orth_t40d_sgnl'] = - icom.groupby('datadate')['ask_chgV_avg_900930_orth_t40d'].apply(yu.uniformed_rank).values

icom['ask_chgV_avg_900930_dv_so_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ask_chgV_avg_900930_dv_so_orth'].mean().values
icom['ask_chgV_avg_900930_dv_so_orth_t20d_sgnl'] = - icom.groupby('datadate')['ask_chgV_avg_900930_dv_so_orth_t20d'].apply(yu.uniformed_rank).values
icom['ask_chgV_avg_900930_dv_so_orth_sgnl'] = - icom.groupby('datadate')['ask_chgV_avg_900930_dv_so_orth'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ask_chgV_avg_900930_orth_t10d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_chgV_avg_900930_orth_t10d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.22 / 1.04

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ask_chgV_avg_900930_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_chgV_avg_900930_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.2 / 1.5

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ask_chgV_avg_900930_orth_t40d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_chgV_avg_900930_orth_t40d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.99 /1.48

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-
12-31')].\
            dropna(subset=['ask_chgV_avg_900930_dv_so_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_chgV_avg_900930_dv_so_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.6 / 1.6 ###!!!
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['ask_chgV_avg_900930_dv_so_orth_t20d_sgnl']>0)].\
            dropna(subset=['ask_chgV_avg_900930_dv_so_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_chgV_avg_900930_dv_so_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.07 / 1.12



# to sql
icom['Ticker'] = icom['ticker'].str[:6]
icom['DataDate'] = icom['datadate']
param_engine = create_engine('mssql+pyodbc://summitsqldb_cndbdev') 
icom[['Ticker','DataDate','ask_chgV_avg_900930_dv_so_orth_t20d_sgnl']].to_sql('F001_ODBK_chgAskV_am_LS_MA', param_engine , index = False, if_exists = 'replace', chunksize = 10000)
icom[['Ticker','DataDate','ask_chgV_avg_900930_dv_so_orth_sgnl']].to_sql('F001_ODBK_chgAskV_am_LS_1D', param_engine , index = False, if_exists = 'replace', chunksize = 10000)

