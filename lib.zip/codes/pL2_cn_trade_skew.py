﻿#$%^&* pL2_cn_trade_skew.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon May 23 16:48:15 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime



### the idea is similar to what we have in pL2_cn_trade_Nmin, except it's based on sql FORMAT table



### i_sd

i_sd = pw.get_ashare_t2000_sd()



### get data v2

dates = yu.get_sql("SELECT distinct [datadate] from [CNDBPROD].[dbo].[TRADE_CN_KLINE]")

i_5min = []

for dt in dates['datadate']:
    print('.', end='')
    
    t_1min = yu.get_sql('''select Ticker, DataDate, trade_minutes, [open], prev_close, [close], v as q, pv as d
                           from [CNDBPROD].[dbo].[TRADE_CN_KLINE]
                           where datadate = '{0}' 
                           and (trade_minutes between 930 and 1500)
                           and trade_minutes!=1130
                           '''.format( dt.strftime('%Y-%m-%d') ))
    
    t_1min['hh5m'] = t_1min['trade_minutes'].apply(lambda x: 5*(x//5))
    t_1min = t_1min.sort_values(['DataDate', 'Ticker', 'hh5m'])
        
    t_5min = t_1min.groupby(['Ticker', 'DataDate', 'hh5m']).agg({'d':sum,'q':sum,'open':'first','close':'last'})
    t_5min = t_5min.reset_index()
    t_5min.columns = ['Ticker', 'DataDate', 'hh5m', 'd', 'q', 'first', 'last']
    t_5min['r_5min'] = t_5min['last'].divide(t_5min['first'])-1
    t_5min['r3_5min'] = t_5min['r_5min'].pow(3)
    t_5min['r2_5min'] = t_5min['r_5min'].pow(2)
    
    s_daily = t_5min[t_5min['hh5m'].between(1000,1500)].groupby(['Ticker','DataDate'])[['r2_5min','r3_5min']].sum()
    s_daily2 = t_5min[t_5min['hh5m'].between(1000,1500)].groupby(['Ticker','DataDate'])['hh5m'].count()
    
    s = s_daily.join(s_daily2, how = 'outer')
    s = s.reset_index()
    s = s.rename(columns = {'hh5m':'hh5m_cnt'})
    
    i_5min.append(s)
    
i_5min = pd.concat(i_5min, axis = 0)
c_sh = i_5min['Ticker'].str[0].isin(['6'])
c_sz = i_5min['Ticker'].str[0].isin(['0', '3'])
i_5min.loc[c_sh, 'ticker'] = i_5min.loc[c_sh, 'Ticker'] + '.SH'
i_5min.loc[c_sz, 'ticker'] = i_5min.loc[c_sz, 'Ticker'] + '.SZ'
i_5min = i_5min.rename(columns={'DataDate':'datadate'})


i_5min = i_5min.sort_values(['ticker', 'datadate'])
i_5min['skew_5min_10001500'] = i_5min['r3_5min'] / (i_5min['r2_5min']**1.5) * np.sqrt(i_5min['hh5m_cnt'])
i_5min['skew_5min_10001500_t20d'] = i_5min.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate',min_periods=10)['skew_5min_10001500']
.mean().values




### get data

dates = yu.get_sql("SELECT distinct [datadate] from CNDBDEV.dbo.F001_SKEW_FORMAT ")

i_5min_v2 = []

for dt in dates['datadate']:
    print('.', end='')
    
    t_5min = yu.get_sql('''SELECT ticker,datadate,sum_r2_5min,sum_r3_5min,cnt_notnull_5min,r_5min_std,sum_r2_5min_10001500,sum_r3_5min_10001500,cnt_notnull_5min_10001500 
                        from CNDBDEV.dbo.F001_SKEW_FORMAT where datadate='{0}'
                         '''.format(dt.strftime('%Y-%m-%d')))

    c_sh = t_5min['ticker'].str[0].isin(['6'])
    c_sz = t_5min['ticker'].str[0].isin(['0', '3'])
    t_5min.loc[c_sh, 'ticker'] = t_5min.loc[c_sh, 'ticker'] + '.SH'
    t_5min.loc[c_sz, 'ticker'] = t_5min.loc[c_sz, 'ticker'] + '.SZ'
    t_5min = t_5min.sort_values(['ticker', 'datadate'])
       
    t_5min['skew_5min_10001500'] = t_5min['sum_r3_5min_10001500'] / (t_5min['sum_r2_5min_10001500']**1.5) * np.sqrt(t_5min['cnt_notnull_5min_10001500'])
    
    i_5min_v2.append(t_5min)

i_nmin = pd.concat(i_5min_v2, axis = 0)
i_nmin = i_nmin.sort_values(['ticker', 'datadate'])

i_nmin['skew_5min_10001500_t40d'] = i_nmin.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['skew_5min_10001500'].mean().values







### combine - n min

icomskew = i_sd.merge(i_nmin, on = ['ticker','datadate'], how = 'left')
icomskew = icomskew.sort_values(['ticker','datadate'])

icomskew['skew_5min_10001500_t40d_sgnl'] = -icomskew.groupby('datadate')['skew_5min_10001500_t40d'].apply(yu.uniformed_rank).values
icomskew['skew_5min_10001500_sgnl'] = -icomskew.groupby('datadate')['skew_5min_10001500'].apply(yu.uniformed_rank).values


o_1 = yu.bt_cn_15(icomskew[(icomskew['datadate']<='2020-12-31')].\
            dropna(subset=['skew_5min_10001500_t40d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'skew_5min_10001500_t40d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.35 / 1.15 ###!!!

o_1 = yu.bt_cn_15(icomskew[(icomskew['datadate']<='2020-12-31')].\
            dropna(subset=['skew_5min_10001500_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'skew_5min_10001500_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.82 / -20.26












### combine  - 5 min


icomskew = i_sd.merge(i_5min, on = ['ticker','datadate'], how = 'left')
icomskew = icomskew.sort_values(['ticker','datadate'])

### naive

cols_f = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LE
VERAGE', 'LIQUIDTY', 'SIZENL']
icom_ind = pd.get_dummies(icomskew['GIND'])
icomskew = pd.concat([icomskew, icom_ind], axis = 1)
cols_i = icom_ind.columns.tolist()
icomskew['ones'] = 1

icomskew['skew_5min_10001500_orth'] = icomskew.groupby('datadate')[['ones', 'skew_5min_10001500']+cols_i+cols_f].apply(lambda x: yu.orthogonalize_cn_v3(x['skew_5min_10001500'], x[cols_f], x[cols_i], x['ones'], normal_y = True)).values
icomskew['skew_5min_10001500_t20d_orth'] = icomskew.groupby('datadate')[['ones', 'skew_5min_10001500_t20d']+cols_i+cols_f].apply(lambda x: yu.orthogonalize_cn_v3(x['skew_5min_10001500_t20d'], x[cols_f], x[cols_i], x['ones'], normal_y = True)).values

icomskew['skew_5min_10001500_bk'] = icomskew.groupby('datadate')['skew_5min_10001500'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomskew['skew_5min_10001500_t20d_bk'] = icomskew.groupby('datadate')['skew_5min_10001500_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomskew['skew_5min_10001500_orth_bk'] = icomskew.groupby('datadate')['skew_5min_10001500_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icomskew['skew_5min_10001500_t20d_orth_bk'] = icomskew.groupby('datadate')['skew_5min_10001500_t20d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icomskew = icomskew.drop(columns = 'Ticker')
yu.create_cn_3x3(icomskew, ['skew_5min_10001500_bk'], 'skew_5min_10001500') # 0 +2.8 -8
yu.create_cn_3x3(icomskew, ['skew_5min_10001500_t20d_bk'], 'skew_5min_10001500_t20d') # +3 +3.7 -11.5
yu.create_cn_3x3(icomskew, ['skew_5min_10001500_orth_bk'], 'skew_5min_10001500_orth') # +1 +3.8 -7.4
yu.create_cn_3x3(icomskew, ['skew_5min_10001500_t20d_orth_bk'], 'skew_5min_10001500_t20d_orth') # +5.2 / -10.3





# old

icomskew['skew_5min_10001500_t40d_sgnl'] = -icomskew.groupby('datadate')['skew_5min_10001500_t40d'].apply(yu.uniformed_rank).values
icomskew['skew_5min_10001500_sgnl'] = -icomskew.groupby('datadate')['skew_5min_10001500'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icomskew[(icomskew['datadate']<='2020-12-31')].\
            dropna(subset=['skew_5min_10001500_t40d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'skew_5min_10001500_t40d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.39/1.17 verified



