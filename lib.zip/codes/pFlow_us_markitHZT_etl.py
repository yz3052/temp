﻿#$%^&* pFlow_us_markitHZT_etl.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 22 20:44:33 2022

@author: thzhang
"""


import pandas as pd

import os
import gc


### get file directory (10pm)

files_10pm = []
for yyyy in ['2019', '2020', '2021', '2022']:
    parent_folder = os.path.join('/dat/mdwarehouse/public/Markit/2713/Data_Insights_v1', yyyy)
    for r,p,fs in os.walk(parent_folder):
        for f in fs:
            if 'Security_Activity_10pm' in f:
                print('.',end='')
                files_10pm.append([r, f, os.path.join(r, f), f[f.index('_3pm') + 6:][:8]])
files_10pm = pd.DataFrame(files_10pm, columns = ['r', 'f', 'p', 'datadate']) 
files_10pm = files_10pm[~files_10pm['datadate'].str.contains('-')]
files_10pm['datadate'] = pd.to_datetime(files_10pm['datadate'], format = '%Y%m%d')




### get file directory (noon)

files_12pm = []
for yyyy in ['2019', '2020', '2021', '2022']:
    parent_folder = os.path.join('/dat/mdwarehouse/public/Markit/2713/Data_Insights_v1', yyyy)
    for r,p,fs in os.walk(parent_folder):
        for f in fs:
            if 'Security_Activity_12pm' in f:
                print('.',end='')
                files_12pm.append([r, f, os.path.join(r, f), f[f.index('_12pm') + 6:][:8]])
files_12pm = pd.DataFrame(files_12pm, columns = ['r', 'f', 'p', 'datadate']) 
files_12pm = files_12pm[~files_12pm['datadate'].str.contains('-')]
files_12pm['datadate'] = pd.to_datetime(files_12pm['datadate'], format = '%Y%m%d')


### get all 10 pm data


o_data_10pm = []

for i, r in files_10pm.iterrows():
    
    print('.', end='')
    t_data = pd.read_csv(r['p'])    
    t_data['datadate'] = r['datadate']
    
    cols = [i for i in t_data.columns.tolist() if 'Internalization' in i or 'Squared Sum' in i or 'DoD' in i]
    t_data = t_data.drop(columns = cols)    
    
    o_data_10pm.append(t_data)
    
    t_data = None
    gc.collect()
    
o_data_10pm = pd.concat(o_data_10pm, axis = 0)

o_data_10pm.to_parquet('/dat/summit_capital/TZ/Markit - Hazeltree/cache/pFlow_us_markit_etl_selected_10pm_data.parquet')




### get all 12 pm data


o_data_12pm = []

for i, r in files_12pm.iterrows():
    
    print('.', end='')
    t_data = pd.read_csv(r['p'])    
    t_data['datadate'] = r['datadate']
    
    cols = [i for i in t_data.columns.tolist() if 'Internalization' in i or 'Squared Sum' in i or 'DoD' in i]
    t_data = t_data.drop(columns = cols)    
    
    o_data_12pm.append(t_data)
    
    t_data = None
    gc.collect()
    
o_d
ata_12pm = pd.concat(o_data_12pm, axis = 0)

o_data_12pm.to_parquet('/dat/summit_capital/TZ/Markit - Hazeltree/cache/pFlow_us_markit_etl_selected_12pm_data.parquet')

