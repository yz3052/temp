﻿#$%^&* pDataYes_recruit_04.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 24 13:23:24 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import zipfile
import csv

import jieba


# this study comparable job posts 
# their salary changes
# their salary changes among undergrad and above
# a prototype for good job / bad job identification



### get ind

i_ind = yu.get_sql('''select datadate, ticker, gsector, ggrop, gind, gsubind 
                   FROM [CNDB].[dbo].[UNIVERSE_ALL_CN]
                   where datadate >= '2016-01-01' ''')
c_sh = i_ind['ticker'].str[0].isin(['6'])
c_sz = i_ind['ticker'].str[0].isin(['3','0'])
i_ind.loc[c_sh, 'ticker'] = i_ind.loc[c_sh, 'ticker'] + '.SH'
i_ind.loc[c_sz, 'ticker'] = i_ind.loc[c_sz, 'ticker'] + '.SZ'


### get sd
i_sd = pw.get_ashare_hk_sd_v2()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','a50_300_flag','a50_flag']]

i_sd_map_300 =i_sd_map[i_sd_map['a50_300_flag']==1]
i_sd_datadate_sr = i_sd_map_300['datadate'].drop_duplicates()
i_sd_map_50  = i_sd_map[i_sd_map['a50_flag']==1]


#------------------------------------------------------------------------------
### identify comparable jobs

i_p = os.listdir(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet')

i_raw = pd.DataFrame()
for p in i_p[:-1]:
    print(p)
    t_data = pd.read_parquet(os.path.join(r'S:\Data\China Data Hunt\Datayes\recruitment\parquet', p))
    t_data = t_data[t_data.source == '51job'] ###!!!
    t_data = t_data[t_data['ticker_symbol'].notnull()]
    t_data = t_data[t_data['ticker_symbol'].str.contains('\d{6}')]
    t_data['datadate'] = pd.to_datetime(pd.to_datetime(t_data['created_at']).dt.date)
    t_data['publish_date'] = pd.to_datetime(pd.to_datetime(t_data['published_at']).dt.date)

    c_sh = t_data['ticker_symbol'].str[0].isin(['6'])
    c_sz = t_data['ticker_symbol'].str[0].isin(['0', '3'])
    t_data.loc[c_sh, 'ticker'] = t_data.loc[c_sh, 'ticker_symbol'] + '.SH'
    t_data.loc[c_sz, 'ticker'] = t_data.loc[c_sz, 'ticker_symbol'] + '.SZ'
    
    t_data = t_data.drop_duplicates(subset = ['ticker_symbol', 'title', 'company_info_id', 'working_address', 
                                              'publish_date','data
date'], keep = 'last') ###!!! dedup    
    
    t_data['educational_requirement'] = t_data['educational_requirement'].fillna('')
    c1 = (t_data['educational_requirement']=='') | t_data['educational_requirement'].str.contains('限') | t_data['educational_requirement'].str.contains('小学')
    t_data.loc[c1, 'edu'] = 1
    c2 = t_data['educational_requirement'].str.contains('初中')
    t_data.loc[c2, 'edu'] = 2
    c3 = t_data['educational_requirement'].str.contains('中.*技') | t_data['educational_requirement'].str.contains('中.*专')
    t_data.loc[c3, 'edu'] = 3
    c4 = t_data['educational_requirement'].str.contains('高中')
    t_data.loc[c4, 'edu'] = 4
    c5 = t_data['educational_requirement'].str.contains('大专')
    t_data.loc[c5, 'edu'] = 5
    c6 = t_data['educational_requirement'].str.contains('本科|学士')
    t_data.loc[c6, 'edu'] = 6
    c7 = t_data['educational_requirement'].str.contains('硕士|MBA')
    t_data.loc[c7, 'edu'] = 7
    c8 = t_data['educational_requirement'].str.upper().str.contains('博士|PHD')
    t_data.loc[c8, 'edu'] = 8
    t_data.loc[t_data['edu'].isnull(), 'edu'] = 1
    
    
    #t_data = t_data[t_data['edu']>=6]###!!!
    
    c_0 = t_data['working_experience'].isnull()
    t_data.loc[c_0, 'working_experience'] = ''
    c_0 = t_data['working_experience'].notnull()
    t_data.loc[c_0, 'working_experience'] = t_data.loc[c_0, 'working_experience'].str.replace(' ','')
    c_n = t_data['working_experience'].str.contains('^\d+年')
    t_data.loc[c_n, 'exp'] = t_data.loc[c_n, 'working_experience'].str.extract('(\d+)年').astype(int).values
    c_n = t_data['working_experience'].str.contains('\d+-\d+年')
    t_data.loc[c_n, 'exp'] = t_data.loc[c_n, 'working_experience'].str.extract('(\d+)-\d+年').astype(int).values
    c_0 = t_data['working_experience'].str.contains('无|应届|不限|1年以下|一年以下|在读')
    t_data.loc[c_0, 'exp'] = 0
    t_data.loc[t_data['working_experience']=='', 'exp'] = 0
    c_1 = t_data['working_experience'].str.contains('一年经验')
    t_data.loc[c_1, 'exp'] = 1
    
    
    t_data.loc[t_data['exp']<=2, 'exp_desc'] = 'r1'
    t_data.loc[t_data['exp'].between(3,4), 'exp_desc'] = 'r2'
    t_data.loc[t_data['exp'].between(5,7), 'exp_desc'] = 'r3'
    t_data.loc[t_data['exp'].between(8,9), 'exp_desc'] = 'r4'
    t_data.loc[t_data['exp']>=10, 'exp_desc'] = 'r5'
    
    
    
    t_data['title3'] = t_data['title'].str.replace('\(.*\)','').str.replace('（.*）','').\
                     str.replace('\[.*\]','').str.replace('\【.*\】','').\
                   
