﻿#$%^&* scraper_comein_02.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Jul  1 09:24:03 2021

@author: thzhang
"""

import pandas as pd
import os
import datetime

from yz.util import get_sql



# This script backfills historical comein events


### gets data

i_txt_files = os.listdir(r'S:\Data\China Data Hunt\comein_txt')

lst_id = []
lst_txt = []
for f in i_txt_files:
    lst_id.append(f.split('.')[0])
    try:
        lst_txt.append(open(os.path.join(r'S:\Data\China Data Hunt\comein_txt', f), encoding='utf8').read())
    except:
        lst_txt.append(open(os.path.join(r'S:\Data\China Data Hunt\comein_txt', f), encoding='gbk').read())

i_data = pd.DataFrame({'id': lst_id, 'txt': lst_txt})


i_event = pd.read_csv(r"S:\Data\China Data Hunt\comein.csv")
i_event['id'] = i_event['id'].astype(str)
i_event = i_event.merge(i_data, on = ['id'], how = 'left')

i_event['start_time_utc'] = pd.to_datetime(i_event['stime'], unit='ms')
i_event['start_time_cn'] = i_event['start_time_utc'].dt.tz_localize('UTC').dt.tz_convert('Asia/Shanghai').dt.tz_localize(None)
i_event = i_event.drop(columns = ['start_time'])
i_event['scraper_ts_est'] = datetime.datetime.today()
i_event['scraper_ts_cn'] = i_event['scraper_ts_est'].dt.tz_localize('US/Eastern').dt.tz_convert('Asia/Shanghai').dt.tz_localize(None)



### check what is available on SQL

i_sql = get_sql('''select * from cndb.dbo.[comein_events] ''')

i_event = i_event[~i_event['id'].isin(i_sql['id'].tolist())]

from sqlalchemy import create_engine
engine = create_engine('mssql+pyodbc://summitsqldb_cndb')

i_event.to_sql('comein_events', index = False, if_exists = 'append',
               con = engine)

