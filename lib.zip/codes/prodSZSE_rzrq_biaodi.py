﻿#$%^&* prodSZSE_rzrq_biaodi.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 20 14:05:57 2022

@author: thzhang
"""


import requests

import pandas as pd
import numpy as np
import os

import random
import urllib
import time
import datetime

import pyodbc
from sqlalchemy import create_engine


# https://www.szse.cn/disclosure/margin/object/index.html
# T+0 biaodi information is available T+0 at ~8 am BJ. 




#---- get proxy  

proxies = {'http':'http://svc_pm_summit_dev:Feng_001!@proxy.mlp.com:3128',
           'https':'https://svc_pm_summit_dev:Feng_001!@proxy.mlp.com:3128'}



#---- now    
    
NOW = pd.to_datetime(datetime.datetime.today()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)

NOW_YYYYdMMdDD = NOW.strftime('%Y-%m-%d')


#---- make sure today is a tdate

conn = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=CNDBPROD;UID=svc_fg_dbo;PWD=1eDecejiqu39;TDS_Version=8.0;')

sql = '''
select min(TradeDate_next) as prev_tdate
from CNDBPROD.dbo.Calendar_Dates_CN
where TradeDate_next >= '{0}'
'''.format(NOW_YYYYdMMdDD)
NEXTTDATE = pd.read_sql(sql,conn)
NEXTTDATE = NEXTTDATE['prev_tdate'].dt.strftime('%Y%m%d').values[0]

if NEXTTDATE != NOW.strftime('%Y%m%d'):
    exit()






try:
    rand = str(random.random())
    obj_proxy = urllib.request.ProxyHandler(proxies)
    opener = urllib.request.build_opener(obj_proxy)
    opener.addheaders = [('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9')]
    opener.addheaders = [('Accept-Encoding', 'gzip, deflate')]
    opener.addheaders = [('Accept-Language', 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7')]
    opener.addheaders = [('Connection', 'keep-alive')]
    opener.addheaders = [('Host', 'www.szse.cn')]
    opener.addheaders = [('Referer', 'http://www.szse.cn/disclosure/margin/object/index.html')]
    opener.addheaders = [('Upgrade-Insecure-Requests', '1')]
    opener.addheaders = [('User-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36')]
    urllib.request.install_opener(opener)
    
    urllib.request.urlretrieve('http://www.szse.cn/api/report/ShowReport?SHOWTYPE=xlsx&CATALOGID=1834_xxpl&txtDate='+NOW_YYYYdMMdDD+'&tab1PAGENO=1&random='+rand+'&TABKEY=tab1', 
                               os.path.join('/export/datadev/Data/Scrapers/rzrq_sz','rzrq_biaodi_'+NOW_YYYYdMMdD
D+'.xls'))

except FileNotFoundError:
    raise Exception('File not found on SZSE website.')
    
except BaseException: 
    
    time.sleep(5)
    rand = str(random.random())
    obj_proxy = urllib.request.ProxyHandler(proxies)
    opener = urllib.request.build_opener(obj_proxy)
    opener.addheaders = [('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9')]
    opener.addheaders = [('Accept-Encoding', 'gzip, deflate')]
    opener.addheaders = [('Accept-Language', 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7')]
    opener.addheaders = [('Connection', 'keep-alive')]
    opener.addheaders = [('Host', 'www.szse.cn')]
    opener.addheaders = [('Referer', 'http://www.szse.cn/disclosure/margin/object/index.html')]
    opener.addheaders = [('Upgrade-Insecure-Requests', '1')]
    opener.addheaders = [('User-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36')]
    urllib.request.install_opener(opener)
    
    urllib.request.urlretrieve('http://www.szse.cn/api/report/ShowReport?SHOWTYPE=xlsx&CATALOGID=1834_xxpl&txtDate='+NOW_YYYYdMMdDD+'&tab1PAGENO=1&random='+rand+'&TABKEY=tab1', 
                               os.path.join('/export/datadev/Data/Scrapers/rzrq_sz','rzrq_biaodi_'+NOW_YYYYdMMdDD+'.xls'))
    


    
#---- read file 

i_df = pd.read_excel('/export/datadev/Data/Scrapers/rzrq_sz/rzrq_biaodi_'+NOW_YYYYdMMdDD+'.xls')
i_df = i_df.rename(columns = {'证券代码':'Ticker', '融资标的':'rongzi_biaodi', '融券标的':'rongquan_biaodi', 
                              '当日可融资':'dangri_ke_rongzi', '当日可融券':'dangri_ke_rongquan', 
                              '融券卖出价格限制':'rongquan_maichu_jiage_xianzhi', '涨跌幅限制':'zhangdiefu_xianzhi'})
i_df['Ticker'] = i_df['Ticker'].astype(int).astype(str).str.zfill(6)
i_df['DataDate'] = pd.to_datetime(NOW_YYYYdMMdDD, format='%Y-%m-%d')
i_df['scraper_ts_cn'] = NOW

i_df = i_df[['Ticker', 'DataDate', 'scraper_ts_cn', 'rongzi_biaodi', 'rongquan_biaodi',
       'dangri_ke_rongzi', 'dangri_ke_rongquan', 'rongquan_maichu_jiage_xianzhi', 'zhangdiefu_xianzhi']]



#---- send to sql, if there is no duplicates

sql_maxdd = pd.read_sql('''select max(DataDate) as max_dd from [CNDBDEV].dbo.szse_rzrq_biaodi''', conn)
sql_maxdd = sql_maxdd['max_dd'].dt.strftime('%Y-%m-%d').values[0]


if sql_maxdd < NOW_YYYYdMMdDD:
    engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={
FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
    i_df.to_sql('szse_rzrq_biaodi', con=engine, if_exists = 'append', index = False)




#------------------------------------------------------------------------------
# create sql table
#------------------------------------------------------------------------------

# create table szse_rzrq_biaodi (Ticker varchar(20), DataDate datetime, scraper_ts_cn datetime, rongzi_biaodi varchar(20), 
#                                rongquan_biaodi varchar(20), dangri_ke_rongzi varchar(20), dangri_ke_rongquan varchar(20), 
#                                rongquan_maichu_jiage_xianzhi varchar(20), zhangdiefu_xianzhi varchar(100))






#------------------------------------------------------------------------------
# bkfil
#------------------------------------------------------------------------------


# i_files = [i for i in os.listdir('/export/datadev/Data/Scrapers/rzrq_sz')]

# o_sz = []

# for i in i_files:
    
#     print (i, end=',')
#     i_df = pd.read_excel('/export/datadev/Data/Scrapers/rzrq_sz/'+i)
#     i_df = i_df.rename(columns = {'证券代码':'Ticker', '融资标的':'rongzi_biaodi', '融券标的':'rongquan_biaodi', 
#                                   '当日可融资':'dangri_ke_rongzi', '当日可融券':'dangri_ke_rongquan', 
#                                   '融券卖出价格限制':'rongquan_maichu_jiage_xianzhi', '涨跌幅限制':'zhangdiefu_xianzhi'})
#     i_df['Ticker'] = i_df['Ticker'].astype(int).astype(str).str.zfill(6)
#     i_df['DataDate'] = pd.to_datetime(i.replace('.xls','').replace('rzrq_biaodi_',''), format='%Y-%m-%d')
#     i_df['scraper_ts_cn'] = NOW
    
#     if 'zhangdiefu_xianzhi' not in i_df.columns.tolist():
#         i_df['zhangdiefu_xianzhi'] = np.nan
    
#     i_df = i_df[['Ticker', 'DataDate', 'scraper_ts_cn', 'rongzi_biaodi', 'rongquan_biaodi',
#            'dangri_ke_rongzi', 'dangri_ke_rongquan', 'rongquan_maichu_jiage_xianzhi', 'zhangdiefu_xianzhi']]
    
#     o_sz.append(i_df)
    
# o_sz = pd.concat(o_sz, axis = 0)
# o_sz.to_csv('/dat/summit_capital/TZ/tmp/sz.csv', index = False, header = False, sep = '|')
# freebcp [CNDBDEV].[dbo].szse_rzrq_biaodi in /dat/summit_capital/TZ/tmp/sz.csv -S summitsqldb -U svc_tz_dbo -P 1wutRe2tidripri -c -t '|'




