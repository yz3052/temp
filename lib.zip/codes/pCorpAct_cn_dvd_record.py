﻿#$%^&* pCorpAct_cn_dvd_record.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat May 14 10:32:02 2022

@author: thzhang
"""




import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime



### With bbg pit data, pre-cost curve is very good 3+ sharpe. We need a daily code to verify it further. 



### sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])


### close

i_c = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                           s_dq_close as c
                    from wind_prod.dbo.ashareeodprices 
                    where trade_dt >= '20150101' ''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format = '%Y%m%d')


### o2c

i_o_c_ret = pw.get_wind_mkt_data(col_list = ['ticker', 'datadate', 'adjret_o_c'])
i_o_c_ret = i_o_c_ret.sort_values(['ticker', 'datadate'])
i_o_c_ret['adjret_o_c_t20d'] = i_o_c_ret.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['adjret_o_c'].sum().values
i_o_c_ret['adjret_o_c_t40d'] = i_o_c_ret.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['adjret_o_c'].sum().values



### get shareholder meeting

i_meet_v1 = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_meet_v1.parquet')
i_meet_v2 = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_meet_v2.parquet')
i_meet = pd.concat([i_meet_v1, i_meet_v2], axis = 0)

i_meet = i_meet[i_meet['CP_MEET_TYP']=='1']
i_meet = i_meet[['ticker','datadate','eff_dt']]
i_meet = i_meet[~i_meet['eff_dt'].str.contains('N.A.', regex=False)]
i_meet['eff_dt'] = pd.to_datetime(i_meet['eff_dt'], format='%Y%m%d')
i_meet = i_meet[i_meet['datadate']<=i_meet['eff_dt']]
i_meet = i_meet.rename(columns={'eff_dt':'meeting_dt'})
i_meet = i_meet[['ticker','meeting_dt']]
i_meet = i_meet.sort_values(['ticker', 'meeting_dt']) # for inspection purpose
i_meet = i_meet.drop_duplicates()

c_sh = i_meet['ticker'].str[0].isin(['6'])
c_sz = i_meet['ticker'].str[0].isin(['0', '3'])
i_meet.loc[c_sh, 'ticker'] = i_meet.loc[c_sh, 'ticker'] + '.SH'
i_meet.loc[c_sz, 'ticker'] = i_meet.loc[c_sz, 'ticker'] + '.SZ'
i_meet = i_meet[i_meet['ticker'].str.contains('SH|SZ')]
i_meet['datadate'] = i_meet['meeting_dt']
i_meet = i_meet.sort_values('meeting_dt')



### get wind's dividend schedules

i_windtime = yu.get_sql('''select s_info_windcode as ticker, report_period, 
                                  eqy_record_dt, s_div_smtgdate, dvd_ann_dt 
 
                          from wind.dbo.AShareDividend 
                           where S_DIV_PROGRESS = '3' 
                           order by s_info_windcode, report_period''')
for c in ['report_period', 'eqy_record_dt', 's_div_smtgdate', 'dvd_ann_dt']:
    i_windtime[c] = i_windtime[c].fillna('NA')
    i_windtime[c] = pd.to_datetime(i_windtime[c], format = '%Y%m%d', errors= 'coerce')
i_windtime['yq'] = i_windtime['report_period'].apply(lambda x: x.year*10 + x.quarter)
i_windtime['q'] = i_windtime['report_period'].dt.quarter

i_windtime['record_m_meet'] = (i_windtime['eqy_record_dt']-i_windtime['s_div_smtgdate']).dt.days
i_windtime['ann_m_meet'] = (i_windtime['dvd_ann_dt']-i_windtime['s_div_smtgdate']).dt.days

i_est_meet_ann_period = []
for dt in pd.date_range(start = '2016-01-01', end = '2021-12-31'):
    print('.',end='')
    t_windtime = i_windtime[i_windtime['dvd_ann_dt']<=dt]
    s_windtime = t_windtime.groupby(['ticker', 'q'])['ann_m_meet'].last().reset_index()
    s_windtime = s_windtime.pivot_table(index = 'ticker', columns = 'q', values = 'ann_m_meet')
    s_windtime = s_windtime.rename(columns={1: 'ann_m_meet_1q', 2: 'ann_m_meet_2q',
                                            3: 'ann_m_meet_3q', 4: 'ann_m_meet_4q'})
    
    t_windtime.groupby('ticker')['report_period']
    
    s_windtime['datadate'] = dt
    s_windtime = s_windtime.reset_index()
    i_est_meet_ann_period.append(s_windtime)
i_est_meet_ann_period = pd.concat(i_est_meet_ann_period, axis = 0)



### get bbgbo dividend data

i_cash_v1 = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_cash_v1.parquet')
i_cash_v2 = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_cash_v2.parquet')
i_cash = pd.concat([i_cash_v1, i_cash_v2], axis = 0)
c_sh = i_cash['ticker'].str[0].isin(['6'])
c_sz = i_cash['ticker'].str[0].isin(['0', '3'])
i_cash.loc[c_sh, 'ticker'] = i_cash.loc[c_sh, 'ticker'] + '.SH'
i_cash.loc[c_sz, 'ticker'] = i_cash.loc[c_sz, 'ticker'] + '.SZ'
i_cash = i_cash[i_cash['ticker'].str.contains('SH|SZ')]

i_cash = i_cash[['ticker', 'datadate', 'CP_GROSS_AMT','CP_RECORD_DT']]
i_cash = i_cash.dropna()
i_cash = i_cash[(i_cash['CP_RECORD_DT'].str.strip()!='N.A.')&(i_cash['CP_GROSS_AMT'].str.strip()!='N.A.')]
i_cash['CP_RECORD_DT'] = pd.to_datetime(i_cash['CP_RECORD_DT'], format = '%Y%m%d')
i_cash['CP_GROSS_AMT'] = pd.to_numeric(i_cash['CP_GROSS_AMT'])
i_cash = i_cash[i_cash['datadate']<=i_cash['CP_RECORD_DT']]
i_cash['flg_has_cash'] = 1
i_cash =
 i_cash.rename(columns = {'CP_RECORD_DT':'CP_RECORD_DT_cash'})
i_cash = i_cash.sort_values('datadate')

#
i_test = pd.merge_asof(i_cash, i_meet, by='ticker', on = 'datadate')
i_test['recod_m_meet'] = (i_test['CP_RECORD_DT_cash']-i_test['meeting_dt']).dt.days
t1 = i_test.groupby('ticker')['recod_m_meet'].apply(lambda x: x.mean()/x.std() if x.std()!=0 else np.nan)
i_test['record_day'] = i_test['CP_RECORD_DT_cash'].dt.strftime('%j').astype('int')
t2 = i_test.groupby('ticker')['record_day'].apply(lambda x: x.max()-x.min())
#


i_stock_v1 = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_stock_v1.parquet')
i_stock_v2 = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_dvd_etl_stock_v2.parquet')
i_stock = pd.concat([i_stock_v1, i_stock_v2], axis = 0)
c_sh = i_stock['ticker'].str[0].isin(['6'])
c_sz = i_stock['ticker'].str[0].isin(['0', '3'])
i_stock.loc[c_sh, 'ticker'] = i_stock.loc[c_sh, 'ticker'] + '.SH'
i_stock.loc[c_sz, 'ticker'] = i_stock.loc[c_sz, 'ticker'] + '.SZ'
i_stock = i_stock[i_stock['ticker'].str.contains('SH|SZ')]
i_stock = i_stock[['ticker', 'datadate', 'CP_AMT','CP_RECORD_DT']]
i_stock = i_stock.dropna()
i_stock = i_stock[(i_stock['CP_RECORD_DT'].str.strip()!='N.A.')&(i_stock['CP_AMT'].str.strip()!='N.A.')]
i_stock['CP_RECORD_DT'] = pd.to_datetime(i_stock['CP_RECORD_DT'], format = '%Y%m%d')
i_stock['CP_AMT'] = pd.to_numeric(i_stock['CP_AMT']) / 100
i_stock = i_stock[i_stock['datadate']<=i_stock['CP_RECORD_DT']]
i_stock['flg_has_shares'] = 1
i_stock = i_stock.rename(columns = {'CP_RECORD_DT':'CP_RECORD_DT_stock'})
i_stock = i_stock.sort_values('datadate')



### combine

icom = i_sd.merge(i_c, on = ['ticker', 'datadate'], how = 'left')
icom = pd.merge_asof(icom, i_cash, by = 'ticker', on = 'datadate',tolerance = pd.to_timedelta('120 days'))
icom = pd.merge_asof(icom, i_stock, by = 'ticker', on = 'datadate',tolerance = pd.to_timedelta('120 days'))
icom = icom.merge(i_est_meet_ann_period, on = ['ticker', 'datadate'], how = 'left')
icom = pd.merge_asof(icom, i_meet, by = 'ticker', on = 'datadate')
icom = icom.merge(i_o_c_ret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])
icom = icom.reset_index(drop = True)
icom['row_id'] = icom.index.values

icom['adjret_o_c_t40d_rk'] = icom.groupby('datadate')['adjret_o_c_t40d'].apply(yu.uniformed_rank).values
icom['SRISK_rk'] = icom.groupby('datadate')['SRISK'].apply(yu.uniformed_rank).values

icom['cash_ret'] = icom['CP_GROSS_AMT'].divide
(icom['c'])
icom['days2red'] = (icom['CP_RECORD_DT_cash'] - icom['datadate']).dt.days

icom['flg_meeting_untraded'] = np.nan
icom.loc[(icom['meeting_dt']!=icom['meeting_dt'].shift())|(icom['ticker']!=icom['ticker'].shift()),
         'flg_meeting_untraded'] = 1
icom.loc[(icom['days2red']<0) & (icom['days2red'].shift()>=0),'flg_meeting_untraded'] = 0
icom.loc[icom.groupby('ticker')['row_id'].first().tolist(), 'flg_meeting_untraded'] = 0
icom['flg_meeting_untraded'] = icom.groupby(['ticker','meeting_dt'])['flg_meeting_untraded'].ffill()






icom['flg_cash_record_avail'] = np.nan
c1 = (icom['flg_has_cash']==1) & (icom['CP_RECORD_DT_cash']>icom['datadate']) \
     & (icom['days2red']<=10) & (icom['days2red'] >= 2)
icom.loc[c1, 'flg_cash_record_avail'] = 1

icom['flg_highcash_record_avail'] = np.nan
c1 = (icom['flg_has_cash']==1) & (icom['CP_RECORD_DT_cash']>icom['datadate']) \
     & (icom['days2red']<=10) & (icom['days2red'] >= 2) & (icom['cash_ret']>0.01) 
icom.loc[c1, 'flg_highcash_record_avail'] = 1

# make sure we get out before and not on record date
# if we can predict ann_dt, we get much better results
# these do not matter: srisk, c2c_rk, c2c>2
icom['flg_highcash_record_avail'] = icom.groupby('ticker')['flg_highcash_record_avail'].bfill(limit =5)




o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['flg_cash_record_avail','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_cash_record_avail','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.01 / -1.05

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['flg_highcash_record_avail','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_highcash_record_avail','BarrRet_CLIP_USD+1d', static_data = i_sd) 
# 0.5% ret: 2.57 / -0.13
# 1% ret: 3.41 / 0.84
# 2% ret: 3.13 /0.98
# 3% ret: 3.2 / 1.24
# 1% ret, o2c 1/4: 1.57/-0.32
# 1% ret, o2c 4/4: 3.3/0.78

icom['ann_m_meet_4q_gt0'] = icom['ann_m_meet_4q'].apply(lambda x: max(0, x-7))
icom['frcst_entry_dt'] = icom['meeting_dt']+pd.to_timedelta(icom['ann_m_meet_4q_gt0'],'d')


icom['flg_highcash_record_avail2'] = np.nan
c1 = (icom['flg_has_cash']==1) & (icom['CP_RECORD_DT_cash']>icom['datadate']) \
     & (icom['days2red']<=10) & (icom['days2red'] >= 2) & (icom['cash_ret']>0.01) 
icom.loc[c1, 'flg_highcash_record_avail2'] = 1

icom['flg_highcash_record_avail2'] = icom.groupby('ticker')['flg_highcash_record_avail2'].bfill(limit=
5)



o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['flg_highcash_record_avail2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'flg_highcash_record_avail2','BarrRet_CLIP_USD+1d', static_data = i_sd)


t1 = icom[icom['ticker']=='600028.SH']
o_1.loc[o_1.ticker=='000001.SZ', 'pnl_ac'].cumsum().plot()
o_1.groupby('ticker')['pnl_ac'].sum().sort_values()

