﻿#$%^&* pTA_cn_mm_2.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 28 13:51:15 2023

@author: thzhang
"""


import pandas as pd
import numpy as np

import util as yu
import os
import datetime

# this studies market making orders, in another style
# not working at all



### get sd

i_sd = yu.get_sd_cn_1800()


### get retail sentiment

#i_retail = yu.get_sql('select * FROM [CNDBPROD].[dbo].[SMTCN_CHILDALPHA_F002_GB_LS]')




### q

i_q = yu.get_q('''(get `:/export/datadev/Data/SHSZ/ORDER_metrics/orderbook_metrics_batch11_mm_sh),
                  (get `:/export/datadev/Data/SHSZ/ORDER_metrics/orderbook_metrics_batch11_mm_sz)''')
i_q['code'] = i_q['code'].str.decode('utf8')
i_q = i_q.rename(columns = {'date':'T-1d', 'code':'Ticker'})


### combine

icom = i_sd.merge(i_q, on = ['Ticker', 'T-1d'], how = 'left')
#icom = icom.merge(i_retail, on = ['Ticker','DataDate'], how = 'left')
icom = icom.sort_values(['Ticker', 'DataDate'])
icom = icom[icom['DataDate'].dt.year.isin([2017, 2018, 2019, 2020])]

icom['ones'] = 1
cols_i = [c for c in i_sd.columns.tolist() if c[:2]=='wd']
if len(cols_i) == 0:
    icom = pd.concat([icom, pd.get_dummies(icom['GIND'])], axis = 1)
    cols_i = icom['GIND'].dropna().unique().tolist()
if len(cols_i) == 0:
    cols_i = ['AIRLINES', 'AUTOCOMP', 'BANKS   ', 'BIOTECH ', 'CAPGOODS', 'CHEMICAL',
       'COMMSVCS', 'COMMUNIC', 'COMPUTER', 'CONSDUR ', 'CONSTPP ', 'CONSVCS ',
       'DIVFINAN', 'DIVMETAL', 'ENERGY  ', 'FOODPRD ', 'FOODRETL', 'HEALTH  ',
       'HSHLDPRD', 'INSURAN ', 'INTERNET', 'MEDIA   ', 'OILEXPL ', 'OILGAS  ',
       'PHARMAC ', 'PRECMETL', 'REALEST ', 'RETAIL  ', 'SEMICOND', 'SOFTWARE',
       'STEEL   ', 'TELECOM ', 'TRANSPRT', 'UTILITY ']
cols_f = ['BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'DIVYILD', 
          'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']



'''
'Ticker', 'od_mmcnt', 'odB_mmcnt', 'odA_mmcnt', 'od_fill_mmcnt',
       'odB_fill_mmcnt', 'odA_fill_mmcnt', 'smallod_mmcnt', 'smallodB_mmcnt',
       'smallodA_mmcnt', 'smallod_fill_mmcnt', 'smallodB_fill_mmcnt',
       'smallodA_fill_mmcnt', 'od_mmv', 'odB_mmv', 'odA_mmv', 'od_fill_mmv',
       'odB_fill_mmv', 'odA_fill_mmv', 'od_totcnt', 'odB_totcnt', 'odA_totcnt',
       'T-1d']
'''


### vanilla

icom['small_dv_tot'] = icom['smallod_mmcnt'] / icom['od_totcnt']
icom['smallA_dv_tot'] = icom['smallodA_mmcnt'] / icom['odA_totcnt']
icom['smallB_dv_totB'] = icom['smallodB_mmcnt'] / icom['odB_totcnt']

icom['smallB_f
ill_cntpct'] = icom['smallodB_fill_mmcnt'] / icom['smallodB_mmcnt']
icom['smallA_fill_cntpct'] = icom['smallodA_fill_mmcnt'] / icom['smallodA_mmcnt']

icom['odB_fill_vpct'] = icom['odB_fill_mmv'] / icom['odB_mmv']
icom['odA_fill_vpct'] = icom['odA_fill_mmv'] / icom['odA_mmv']

for c in ['small_dv_tot','smallB_dv_totB','smallB_fill_cntpct','smallA_fill_cntpct',
          'odB_fill_vpct','odA_fill_vpct','small_dv_tot']:
    icom[c+'_bk'] = icom.groupby('DataDate')[c].apply(lambda x: yu.pdqcut(x,bins=10)).values
    yu.create_cn_3x3_linux(icom, [c+'_bk'], c)

for c in ['small_dv_tot','smallB_dv_totB','smallB_fill_cntpct','smallA_fill_cntpct',
          'odB_fill_vpct','odA_fill_vpct','small_dv_tot']:
    icom[c+'_20d'] = icom.groupby('Ticker').rolling(20)[c].mean().values
    icom[c+'_20d_bk'] = icom.groupby('DataDate')[c+'_20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
    icom[c+'_20d_orth'] = icom.groupby('DataDate')[cols_i + cols_f + [c+'_20d', 'ones']].apply(lambda x: yu.orthogonalize_cn_v3(x[c+'_20d'], x[cols_f], x[cols_i], x['ones'])).values
    icom[c+'_20d_orth_bk'] = icom.groupby('DataDate')[c+'_20d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
    yu.create_cn_3x3_linux(icom, [c+'_20d_bk'], c+'_20d')
    yu.create_cn_3x3_linux(icom, [c+'_20d_orth_bk'], c+'_20d')
    
    
### rk diff with retail sentiment
# not working

icom['mm_dv_tot'] = icom['odB_mmcnt'] / icom['odB_totcnt']
icom['mm_dv_tot_20d'] = icom.groupby('Ticker').rolling(20)['mm_dv_tot'].mean().values
icom['mm_dv_tot_20d_rk'] = icom.groupby('DataDate')['mm_dv_tot_20d'].apply(yu.uniformed_rank)
icom['mm_dv_tot_20d_bk'] = icom.groupby('DataDate')['mm_dv_tot_20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['alpha_rk'] = icom.groupby('DataDate')['alpha'].apply(yu.uniformed_rank)

icom['mm_retail_rkdiff'] = icom['mm_dv_tot_20d_rk'] - icom['alpha_rk']
icom['mm_retail_rkdiff_bk'] = icom.groupby('DataDate')['mm_retail_rkdiff'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3_linux(icom, ['mm_dv_tot_20d_bk'], 'mm_dv_tot_20d')
yu.create_cn_3x3_linux(icom, ['mm_retail_rkdiff_bk'], 'mm_retail_rkdiff')


### mm orders: all - small 
# not working

icom['inst_dv_tot'] = (icom['od_mmcnt'] - icom['smallod_mmcnt']) / icom['od_totcnt']
icom['instA_dv_tot'] = (icom['odA_mmcnt'] - icom['smallodA_mmcnt']) / icom['odA_totcnt']
icom['instB_dv_tot'] = (icom['odB_mmcnt'] - icom['smallodB_mmcnt']) / icom['odB_totcnt']

icom['inst_dv_tot_20d'] = icom.groupby('Ticker').rolling(20)['in
st_dv_tot'].mean().values
icom['inst_dv_tot_20d_bk'] = icom.groupby('DataDate')['inst_dv_tot_20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['instB_dv_tot_20d'] = icom.groupby('Ticker').rolling(20)['instB_dv_tot'].mean().values
icom['instB_dv_tot_20d_bk'] = icom.groupby('DataDate')['instB_dv_tot_20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3_linux(icom, ['inst_dv_tot_20d_bk'], 'inst_dv_tot_20d')
yu.create_cn_3x3_linux(icom, ['instB_dv_tot_20d_bk'], 'instB_dv_tot_20d')
