﻿#$%^&* pDataYes_guba_raw_final.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Nov  5 10:24:10 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime


### sd


i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d',
                 'isin_hk_uni','csi300_flag',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d',
                 'EARNYILD','GROWTH']]

i_sd_map_300 =i_sd_map[i_sd_map['csi300_flag']==1]
i_sd_datadate_sr = i_sd_map_300['datadate'].drop_duplicates()


### trading day flag

i_tdate = yu.get_sql("select distinct tradedate_next as FileDate FROM [CNDBPROD].[dbo].[calendar_dates_cn]")
i_tdate['flag_tdate'] = 1


### a share universe (ticker, tdate)
i_a_uni = yu.get_sql("select ticker, datadate FROM [CNDBPROD].[dbo].[UNIVERSE_ALL_CN]")
c_sh = i_a_uni['ticker'].str[0].isin(['6'])
c_sz = i_a_uni['ticker'].str[0].isin(['0', '3'])
i_a_uni.loc[c_sh, 'ticker'] = i_a_uni.loc[c_sh, 'ticker']  + '.SH'
i_a_uni.loc[c_sz, 'ticker'] = i_a_uni.loc[c_sz, 'ticker']  + '.SZ'

i_a_uni2 = []
for dt in pd.date_range(start='2015-01-01',end='2020-12-31').tolist():
    t_a_uni2 = i_a_uni[i_a_uni['datadate']==i_a_uni['datadate'][i_a_uni['datadate']<=dt].max()]
    t_a_uni2['datadate'] = dt
    i_a_uni2.append(t_a_uni2)
i_a_uni2 = pd.concat(i_a_uni2, axis=0)


### barra factors

i_factor = pw.get_barra_factors(date_start='2015-06-01', date_end='2019-05-01')

c_sh = i_factor['code'].str[0].isin(['6'])
c_sz = i_factor['code'].str[0].isin(['0','3'])
i_factor.loc[c_sh, 'ticker'] = i_factor.loc[c_sh, 'code'] + '.SH'
i_factor.loc[c_sz, 'ticker'] = i_factor.loc[c_sz, 'code'] + '.SZ'
i_factor = i_factor.drop(columns = ['code'])



### xq data

i_xq = []
for dt in pd.date_range(start='2015-04-02', end = '2020-01-01').strftime('%Y-%m-%d').tolist():
    print(dt, end='')
    
    t_xq = yu.get_sql('''select FileDate, symbol, postType,
               count(id) as xq_cnt, 
               count(case when datepart(hour, created_at) between 9 and 14 then id else NULL end) as xq_cnt0914, 
               count(case when len(text)<100 then id else NULL end) as xq_cntShort, 
               sum(reply_count) as xq_reply,
               sum(case when len(text)<100 then reply_count else 0 end) as xq_replyShort 
  
             from [CNDBPROD].[dbo].[DATAYES_xueqiu_raw] 
               where filedate = '{0}' 
               group by filedate, symbol, postType '''.format(dt))
    i_xq.append(t_xq)
i_xq = pd.concat(i_xq, axis = 0) # 45min

i_xq.to_parquet(r'S:\Data\China Data Hunt\cache\pDataYes_guba_raw_2_xqSQL.parquet') ###!!!
i_xq = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pDataYes_guba_raw_2_xqSQL.parquet') ###!!!

i_xq['postType'] = i_xq['postType'].fillna('NULL')

i_xq = i_xq.merge(i_tdate, on = ['FileDate'], how = 'left')
c_is_tdate = i_xq['flag_tdate'] ==  1
i_xq.loc[c_is_tdate, 'xq_cnt_tdate'] = i_xq.loc[c_is_tdate, 'xq_cnt']
i_xq['xq_cnt_tdate'] = pd.to_numeric(i_xq['xq_cnt_tdate'])
i_xq.loc[c_is_tdate, 'xq_cntShort_tdate'] = i_xq.loc[c_is_tdate, 'xq_cntShort']
i_xq['xq_cntShort_tdate'] = pd.to_numeric(i_xq['xq_cntShort_tdate'])

i_xq['datadate'] = i_xq['FileDate'] #+ pd.to_timedelta('1 day')
i_xq['symbol'] = i_xq['symbol'].str[-6:]
c_sh = i_xq['symbol'].str[0].isin(['6'])
c_sz = i_xq['symbol'].str[0].isin(['0', '3'])
i_xq.loc[c_sh, 'ticker'] = i_xq.loc[c_sh, 'symbol']  + '.SH'
i_xq.loc[c_sz, 'ticker'] = i_xq.loc[c_sz, 'symbol']  + '.SZ'
i_xq = i_xq.drop(columns = ['FileDate','symbol'])


# count (from organic post types)

i_xq_cntOrg = i_xq.pivot_table(index=['datadate','ticker'], columns='postType', values='xq_cnt_tdate')
i_xq_cntOrg = i_xq_cntOrg.reset_index()
i_xq_cntOrg['xq_cntOrg'] = i_xq_cntOrg[['雪球','Android','iPhone','Android客户端','NULL','iPhone客户端','iPad','iPad客户端']].sum(axis = 1 ,skipna = True)

i_xq_cntOrg = i_a_uni.merge(i_xq_cntOrg, on = ['datadate','ticker'], how = 'left')
i_xq_cntOrg = i_xq_cntOrg.fillna(0)

i_xq_cntOrg = i_xq_cntOrg.sort_values(['ticker', 'datadate'])
i_xq_cntOrg['xq_cntOrg_t20d'] = i_xq_cntOrg.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate',min_periods=15)['xq_cntOrg'].sum().values

i_xq_cntOrg = i_xq_cntOrg[['ticker','datadate','xq_cntOrg','xq_cntOrg_t20d']]


# count of short posts (from organic post types)

i_xq_cntOrgShort = i_xq.pivot_table(index=['datadate','ticker'], columns='postType', values='xq_cntShort_tdate')
i_xq_cntOrgShort = i_xq_cntOrgShort.reset_index()
i_xq_cntOrgShort['xq_cntOrgShort'] = i_xq_cntOrgShort[['雪球','Android','iPhone','Android客户端','NULL','iPhone客户端','iPad','iPad客户端']].sum(axis = 1 ,skipna = True)

i_xq_cntOrgShort = i_a_uni.merge(i_xq_cntOrgShort, on = ['datadate','ticker'], how = 'left')
i_xq_cntOrgShort = i_xq_cntOrgShort.fillna(0)

i_xq_cntOrgShort = i_xq_cntOrgShort
.sort_values(['ticker', 'datadate'])
i_xq_cntOrgShort['xq_cntOrgShort_t20d'] = i_xq_cntOrgShort.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate',min_periods=15)['xq_cntOrgShort'].sum().values

i_xq_cntOrgShort = i_xq_cntOrgShort[['ticker','datadate','xq_cntOrgShort', 'xq_cntOrgShort_t20d']]

# reply of short posts 

i_xq_reply = i_xq.pivot_table(index=['datadate','ticker'], columns='postType', values='xq_replyShort')
i_xq_reply = i_xq_reply.reset_index()
i_xq_reply['xq_replyOrgShort'] = i_xq_reply[['雪球','Android','iPhone','Android客户端','NULL','iPhone客户端','iPad','iPad客户端']].sum(axis = 1 ,skipna = True)

i_xq_reply = i_a_uni.merge(i_xq_reply, on = ['datadate','ticker'], how = 'left')
i_xq_reply = i_xq_reply.fillna(0)

i_xq_reply = i_xq_reply.sort_values(['ticker', 'datadate'])
i_xq_reply['xq_replyOrgShort_t20d'] = i_xq_reply.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate',min_periods=15)['xq_replyOrgShort'].sum().values

i_xq_reply = i_xq_reply[['ticker','datadate','xq_replyOrgShort','xq_replyOrgShort_t20d']]
    



### guba data 

i_guba = []
for dt in pd.date_range(start='2015-04-02', end = '2020-01-01').strftime('%Y-%m-%d').tolist():
    print(dt, end='')
    
    t_guba = yu.get_sql('''select FileDate, baname, 
               count(postid) as cnt, count(distinct postid) as nunqiue,
               sum(case when DATEPART(HOUR, publishtime)*100+DATEPART(MINUTE, publishtime) between 930 and 1500 then 1 else 0 end) as cnt_0930_1500,
               count(case when DATEPART(HOUR, publishtime)*100+DATEPART(MINUTE, publishtime) between 1000 and 1500 then 1 else 0 end) as cnt_1000_1500 
               from [CNDBRPOD].[dbo].[DATAYES_GUBA_RAW] 
               where filedate = '{0}'
               group by filedate, baname '''.format(dt))
    i_guba.append(t_guba)
i_guba = pd.concat(i_guba, axis = 0) # 45min
   

i_guba.to_parquet(r'S:\Data\China Data Hunt\cache\pDataYes_guba_raw_2_gubaSQL.parquet') ###!!!
i_guba = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pDataYes_guba_raw_2_gubaSQL.parquet') ###!!!

i_guba = i_guba.merge(i_tdate, on = ['FileDate'], how = 'left')
c_is_tdate = i_guba['flag_tdate'] ==  1
i_guba.loc[c_is_tdate, 'cnt_tdate'] = i_guba.loc[c_is_tdate, 'cnt']

i_guba['datadate'] = i_guba['FileDate'] #+ pd.to_timedelta('1 day')
i_guba['baname'] = i_guba['baname'].astype(str).str.zfill(6)
c_sh = i_guba['baname'].str[0].isin(['6'])
c_sz = i_guba['baname'].str[0].isin(['0', '3'])
i_guba.loc[c_sh, 'ticker'] = i_guba.
loc[c_sh, 'baname']  + '.SH'
i_guba.loc[c_sz, 'ticker'] = i_guba.loc[c_sz, 'baname']  + '.SZ'
i_guba = i_guba.drop(columns = ['baname'])

i_guba = i_a_uni2[i_a_uni2['datadate'].between('2015-04-12','2019-12-31')].\
    merge(i_guba, on = ['ticker', 'datadate'], how = 'left')

i_guba = i_guba.sort_values(['ticker', 'datadate'])
i_guba['cnt_x0_t20d'] = i_guba.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate',min_periods=10)['cnt'].sum().values
i_guba['cnt_x0_t20d_allbk'] = i_guba.groupby('datadate')['cnt_x0_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
i_guba['cnt_x0_t20d_allrk'] = i_guba.groupby('datadate')['cnt_x0_t20d'].apply(yu.uniformed_rank).values

i_guba['cnt_x0_tdate_t20d'] = i_guba.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate',min_periods=10)['cnt_tdate'].sum().values
i_guba['cnt_x0_tdate_t20d_allrk'] = i_guba.groupby('datadate')['cnt_x0_tdate_t20d'].apply(yu.uniformed_rank).values
i_guba['cnt_x0_tdate_t20d_allbk'] = i_guba.groupby('datadate')['cnt_x0_tdate_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

i_guba['cnt_w0'] = i_guba['cnt'].fillna(0)
i_guba['cnt_w0_t20d'] = i_guba.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate',min_periods=10)['cnt_w0'].sum().values
i_guba['cnt_w0_t20d_allbk'] = i_guba.groupby('datadate')['cnt_w0_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
i_guba['cnt_w0_t20d_allrk'] = i_guba.groupby('datadate')['cnt_w0_t20d'].apply(yu.uniformed_rank).values

i_guba['cnt_w0_tdate'] = i_guba['cnt_tdate']
i_guba.loc[i_guba['cnt_tdate'].isnull() & i_guba['flag_tdate']==1, 'cnt_w0_tdate'] = 0
i_guba['cnt_w0_tdate_t20d'] = i_guba.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate',min_periods=10)['cnt_w0_tdate'].sum().values
i_guba['cnt_w0_tdate_t20d_allrk'] = i_guba.groupby('datadate')['cnt_w0_tdate_t20d'].apply(yu.uniformed_rank).values
i_guba['cnt_w0_tdate_t20d_allbk'] = i_guba.groupby('datadate')['cnt_w0_tdate_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values


# time series 
i_guba = i_guba.sort_values(['ticker', 'datadate'])
i_guba['cnt_w0_tdate_t1y_mean_1d'] = i_guba.groupby('ticker').rolling(datetime.timedelta(days=365),on='datadate',min_periods=126)['cnt_w0_tdate'].mean().shift().values
i_guba['cnt_w0_tdate_t1y_mean_1d'] = i_guba['cnt_w0_tdate_t1y_mean_1d'].replace(0, np.nan)
i_guba['cnt_w0_tdate_t1y_std_1d'] = i_guba.groupby('ticker').rolling(datetime.timedelta(days=365),on='datadate',min_periods=126)['cnt_w0_tdate'].std().shift().valu
es
i_guba['cnt_w0_tdate_t1y_std_1d'] = i_guba['cnt_w0_tdate_t1y_mean_1d'].replace(0, np.nan)

i_guba['cnt_w0_tdate_z'] = (i_guba['cnt'] - i_guba['cnt_w0_tdate_t1y_mean_1d']).divide(i_guba['cnt_w0_tdate_t1y_std_1d'])






# orthogonalize (do not work)

#i_guba = i_guba.merge(i_factor, on = ['ticker','datadate'], how = 'left')
#i_guba = i_guba.sort_values(['datadate','ticker']).reset_index(drop = True)
#cols_factor = ['bf_LIQUIDTY', 'bf_LEVERAGE', 'bf_BTOP',
#       'bf_GROWTH', 'bf_EARNYILD', 'bf_SIZE', 'bf_MOMENTUM', 'bf_SRISK',
#       'bf_SPREAD', 'bf_AVGPVADJ', 'bf_RESVOL', 'bf_TURNOVER', 'G_45', 'G_20',
#       'G_25', 'G_35', 'G_15', 'G_55', 'G_30', 'G_40', 'G_60', 'G_10', 'G_50']
#i_guba['cnt_w0_tdate_t20d_orth'] = i_guba.groupby('datadate')[cols_factor+['cnt_w0_tdate_t20d']].apply(lambda x: pd.Series(yu.ols_residual(x[cols_factor].values, x['cnt_w0_tdate_t20d'].values, intercept=False),index=x.index).to_frame()).values
#i_guba['cnt_x0_tdate_t20d_orth'] = i_guba.groupby('datadate')[cols_factor+['cnt_x0_tdate_t20d']].apply(lambda x: pd.Series(yu.ols_residual(x[cols_factor].values, x['cnt_x0_tdate_t20d'].values, intercept=False),index=x.index).to_frame()).values
#i_guba['cnt_w0_t20d_orth'] = i_guba.groupby('datadate')[cols_factor+['cnt_w0_t20d']].apply(lambda x: pd.Series(yu.ols_residual(x[cols_factor].values, x['cnt_w0_t20d'].values, intercept=False),index=x.index).to_frame()).values
#i_guba['cnt_x0_t20d_orth'] = i_guba.groupby('datadate')[cols_factor+['cnt_x0_t20d']].apply(lambda x: pd.Series(yu.ols_residual(x[cols_factor].values, x['cnt_x0_t20d'].values, intercept=False),index=x.index).to_frame()).values



### hotness
# pHotness_01

i_bi = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pHotness_01_bi.parquet')

i_bi = i_bi.sort_values(['ticker', 'datadate'])
i_bi['turnover_t20d'] = i_bi.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['turnover'].mean().values


### o2c return

i_o_c_ret = pw.get_wind_mkt_data(col_list = ['ticker', 'datadate', 'adjret_o_c'])
i_o_c_ret = i_o_c_ret.sort_values(['ticker', 'datadate'])

i_o_c_ret['adjret_o_c_t10d'] = i_o_c_ret.groupby('ticker').rolling(datetime.timedelta(days=14), on = 'datadate', min_periods=7)['adjret_o_c'].sum().values
i_o_c_ret['adjret_o_c_t20d'] = i_o_c_ret.groupby('ticker').rolling(datetime.timedelta(days=28), on = 'datadate', min_periods=10)['adjret_o_c'].sum().values
i_o_c_ret['adjret_o_c_t20d_allrk'] = i_o_c_ret.groupby('datadate')['adjret_o_c_t20d'].apply(yu.uniformed_ra
nk).values
i_o_c_ret['adjret_o_c_t40d'] = i_o_c_ret.groupby('ticker').rolling(datetime.timedelta(days=56), on = 'datadate', min_periods=28)['adjret_o_c'].sum().values
i_o_c_ret['adjret_o_c_t63d'] = i_o_c_ret.groupby('ticker').rolling(datetime.timedelta(days=91), on = 'datadate', min_periods=45)['adjret_o_c'].sum().values


### special situation

i_ss = pw.get_special_situation()


### rating

i_rating = yu.get_sql('''select s_info_windcode as ticker, ann_dt as datadate,
                      S_EST_SCORERATING_INST as rating, S_EST_PRESCORERATING_INST as rating_prev,
                      S_EST_HIGHPRICE_INST as tp 
                      from wind.dbo.asharestockrating 
                      where S_EST_REPORT_TYPE = '806004002' or S_EST_REPORT_TYPE = '260001000' ''')

i_rating['rating_prev'] = i_rating['rating_prev'].fillna(6)
i_rating['datadate'] = pd.to_datetime(i_rating['datadate'])
i_rating = i_rating.sort_values(['ticker', 'datadate'])

i_rating.loc[i_rating['rating']<i_rating['rating_prev'], 'flag_updngrade'] = 1
i_rating.loc[i_rating['rating']>i_rating['rating_prev'], 'flag_updngrade'] = -1
i_rating['flag_updngrade'] = i_rating['flag_updngrade'].fillna(0)



i_rating_sum = []
for dt in pd.date_range(start = '2016-01-01', end = '2019-12-31').tolist():
    print(dt.strftime('%Y%m%d'),end=',')
    t_rating = i_rating[(i_rating['datadate']<=dt)&(i_rating['datadate']>=dt-pd.to_timedelta('91 days'))]
    
    t_rating_sum = t_rating.groupby('ticker')['rating'].agg(['mean','min']).reset_index()
    t_rating_sum = t_rating_sum.rename(columns={'mean':'rating_mean','min':'rating_min'})
    
    t_rating_sum2 = t_rating.groupby('ticker')['flag_updngrade'].sum().reset_index()
    
    t_sum = t_rating_sum.merge(t_rating_sum2, on = ['ticker'], how = 'outer')
    t_sum['datadate'] = dt
    i_rating_sum.append(t_sum)
i_rating_sum = pd.concat(i_rating_sum, axis=0)


#------------------------------------------------------------------------------
### combine


icom = i_sd.merge(i_guba, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_bi, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_o_c_ret, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_ss, on = ['ticker', 'datadate'], how = 'left')

#icom = icom.merge(i_rating_sum, on = ['ticker','datadate'], how = 'left')

icom = icom.merge(i_xq_cntOrg, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(i_xq_cntOrgShort, on = ['ticker','datadate'], how = 'left')
icom = icom.m
erge(i_xq_reply, on = ['ticker','datadate'], how = 'left')



icom = icom.sort_values(['ticker', 'datadate'])
icom['adjret_o_c_t20d_rk'] = icom.groupby('datadate')['adjret_o_c_t20d'].apply(yu.uniformed_rank).values
icom['earn_rk'] = icom.groupby('datadate')['EARNYILD'].apply(yu.uniformed_rank).values
icom['growth_rk'] = icom.groupby('datadate')['GROWTH'].apply(yu.uniformed_rank).values

icom['cnt_x0_t20d_bk'] = icom.groupby('datadate')['cnt_x0_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_x0_t20d_rk'] = icom.groupby('datadate')['cnt_x0_t20d'].apply(yu.uniformed_rank).values

icom['cnt_x0_tdate_t20d_bk'] = icom.groupby('datadate')['cnt_x0_tdate_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_x0_tdate_t20d_rk'] = icom.groupby('datadate')['cnt_x0_tdate_t20d'].apply(yu.uniformed_rank).values

icom['cnt_w0_t20d_bk'] = icom.groupby('datadate')['cnt_w0_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_w0_t20d_rk'] = icom.groupby('datadate')['cnt_w0_t20d'].apply(yu.uniformed_rank).values

icom['cnt_w0_tdate_t20d_bk'] = icom.groupby('datadate')['cnt_w0_tdate_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_w0_tdate_t20d_rk'] = icom.groupby('datadate')['cnt_w0_tdate_t20d'].apply(yu.uniformed_rank).values

icom['1_r2_t1m_rk'] = icom.groupby('datadate')['1_r2_t1m'].apply(yu.uniformed_rank).values
icom['1_r2_t1m_v2_rk'] = icom.groupby('datadate')['1_r2_t1m_v2'].apply(yu.uniformed_rank).values
icom['1_r2_t1m_t126d'] = icom.groupby('ticker').rolling(126)['1_r2_t1m'].mean().values
icom['1_r2_t1m_t126d_rk'] = icom.groupby('datadate')['1_r2_t1m_t126d'].apply(yu.uniformed_rank).values






# simple guba cnt

icom['long_sgnl'] = - icom['cnt_x0_t20d_rk']


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['long_sgnl']>0)].\
            dropna(subset=['long_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'long_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.84/1.96, 1.9bp/d

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['long_sgnl']>0)&(icom['rating_min']==1)].\
            dropna(subset=['long_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'long_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.77/2.01, 2.46bp/d 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['long_sgnl']>0)].\
            dropna(subset=['long_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate
']),
            'long_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.84/2.04, 2.69bp/d  ###!!!

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['long_sgnl']<0)].\
            dropna(subset=['long_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'long_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.83 / 1.82, 0.9bp/d

icom['long_sgnl2'] = - icom['cnt_w0_t20d_rk']
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['long_sgnl2']>0)].\
            dropna(subset=['long_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'long_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.48 / 1.66, 1.73 bp/d


icom['long_sgnl3'] = - icom['cnt_tdate_t20d_rk']
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['long_sgnl3']>0)].\
            dropna(subset=['long_sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'long_sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.92 / 2.05, 2.04bp/d
# use v2: 
# use v2p1: 2.92 / 2.05
# use v2p2: 3.01 / 2.19
# use v2p3: 2.92 / 2.05



### |------

#------------------------------------------------------------------------------
### Xueqiu


# xq cnt (short posts, from organic types)

icom['xq_cntOrgShort_t20d'] = icom['xq_cntOrgShort_t20d'].replace(0, np.nan)
icom['xq_cntOrgShort_t20d_rk'] = icom.groupby('datadate')['xq_cntOrgShort_t20d'].apply(yu.uniformed_rank).values
icom['cxq_cntOrgShort_t20d_bk'] = icom.groupby('datadate')['xq_cntOrgShort_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['cxq_cntOrgShort_t20d_bk'], 'xq_cntOrgShort_t20d')

icom['xq_cntOrgShort_t20d_sgnl'] = - icom['xq_cntOrgShort_t20d_rk']
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['xq_cntOrgShort_t20d_sgnl']>0)].\
            dropna(subset=['xq_cntOrgShort_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'xq_cntOrgShort_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.47/0.82, 0.76bp/d


# xq replies + cnt (short posts, from organic types)

icom['xq_2OrgShort_t20d'] = icom['xq_cntOrgShort_t20d'].add(icom['xq_replyOrgShort_t20d'], fill_value=0)
icom['xq_2OrgShort_t20d'] = icom['xq_2OrgShort_t20d'].replace(0, np.nan)

icom['xq_2OrgShort_t20d_rk'] = icom.groupby('datadate')['xq_2OrgShort_t20d'].apply(yu.uniformed_rank).values
icom['xq_2OrgShort_t20d_bk'] = icom.groupby('datadate')['xq_
2OrgShort_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['xq_2OrgShort_t20d_sgnl'] = - icom['xq_2OrgShort_t20d_rk']

yu.create_cn_3x3(icom, ['xq_2OrgShort_t20d_bk'], 'xq_2OrgShort_t20d')

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['xq_2OrgShort_t20d_sgnl']>0)].\
            dropna(subset=['xq_2OrgShort_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'xq_2OrgShort_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.21/0.58, 0.54bp/d


# xq replies

icom['xq_replyOrgShort_t20d'] = icom['xq_replyOrgShort_t20d'].replace(0, np.nan)
icom['xq_replyOrgShort_t20d_rk'] = icom.groupby('datadate')['xq_replyOrgShort_t20d'].apply(yu.uniformed_rank).values
icom['xq_replyOrgShort_t20d_bk'] = icom.groupby('datadate')['xq_replyOrgShort_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['xq_replyOrgShort_t20d_bk'], 'xq_replyOrgShort_t20d') # not better 


# (xq cnt) and (xq cnt/ PV)

icom['xq_cntOrg_t20d'] = icom['xq_cntOrg_t20d'].replace(0, np.nan)
icom['xq_cntOrg_t20d_rk'] = icom.groupby('datadate')['xq_cntOrg_t20d'].apply(yu.uniformed_rank).values
icom['xq_cntOrg_t20d_bk'] = icom.groupby('datadate')['xq_cntOrg_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['xq_cntOrg_t20d_dv_pv'] = icom['xq_cntOrg_t20d'].divide(icom['avgPVadj'])
icom['xq_cntOrg_t20d_dv_pv_rk'] = icom.groupby('datadate')['xq_cntOrg_t20d_dv_pv'].apply(yu.uniformed_rank).values
icom['xq_cntOrg_t20d_dv_pv_bk'] = icom.groupby('datadate')['xq_cntOrg_t20d_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values


yu.create_cn_3x3(icom, ['xq_cntOrg_t20d_bk'], 'xq_cntOrg_t20d') # mono
yu.create_cn_3x3(icom, ['xq_cntOrg_t20d_dv_pv_bk'], 'xq_cntOrg_t20d_dv_pv') # random

icom['xq_cntOrg_t20d_rk_sgnl'] = - icom['xq_cntOrg_t20d_rk']

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['xq_cntOrg_t20d_rk_sgnl']>0)].\
            dropna(subset=['xq_cntOrg_t20d_rk_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'xq_cntOrg_t20d_rk_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.43/0.92, 0.88bp/d ###!!!


#------------------------------------------------------------------------------
### Guba


# cnt 

icom['cnt_x0_t20d_rk'] = icom.groupby('datadate')['cnt_x0_t20d'].apply(yu.uniformed_rank).values
icom['cnt_x0_t20d_bk'] = icom.groupby('datadate')['cnt_x0_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['cnt_x0_t20d_bk'],
 'cnt_x0_t20d')

icom['cnt_x0_t20d_sgnl'] = - icom['cnt_x0_t20d_rk']
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['cnt_x0_t20d_sgnl']>0)].\
            dropna(subset=['cnt_x0_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_x0_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.84/1.97, 1.96bp/d

icom['xq_cntOrg_t20d_rk'] = icom.groupby('datadate')['xq_cntOrg_t20d'].apply(yu.uniformed_rank).values
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['cnt_x0_t20d_sgnl']>0)&(icom['xq_cntOrg_t20d_rk']<0.8)].\
            dropna(subset=['cnt_x0_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_x0_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.96/2.08, 2.14bp/d



# very high rank (cnt)

icom['guba_xq_sgnl1'] = np.nan
c1 = (icom['cnt_x0_t20d_rk']>0.95)# & (icom['cntX_x0_t20d_rk']>0.95) 
icom.loc[c1, 'guba_xq_sgnl1'] = -1
icom['guba_xq_sgnl1'] = icom.groupby('ticker')['guba_xq_sgnl1'].ffill(limit=5)
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['guba_xq_sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'guba_xq_sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # n2.13/1.7,4.6bp/d, 86b edge
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['a50_300_flag']==1)].\
            dropna(subset=['guba_xq_sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'guba_xq_sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # not working



### guba cnt and 02c return and 1-r2

cs = (icom['flag_lmt']==1) | (icom['flag_suspension']==1) | (icom['flag_st']==1) | (icom['days_since_ipo']<=180)
cs2 = (icom['flag_lmt_t1w']==1) | (icom['flag_suspension_t1w']==1) | (icom['flag_st']==1) | (icom['days_since_ipo']<=180)

icom['guba_o2c_s_sgnl'] = np.nan
c1 = (icom['adjret_o_c_t20d_rk']>0.8) & (icom['cnt_x0_tdate_t20d_rk']>0) & (icom['1_r2_t1m_rk']>0)
icom.loc[c1, 'guba_o2c_s_sgnl'] = -1
c2 = (icom['adjret_o_c_t20d_rk']<-0.8) | (icom['cnt_x0_tdate_t20d_rk']<-0.8) | (icom['1_r2_t1m_rk']<-0.8)
icom.loc[c2, 'guba_o2c_s_sgnl'] = 0
icom['guba_o2c_s_sgnl'] = icom.groupby('ticker')['guba_o2c_s_sgnl'].ffill(limit=20)
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['guba_o2c_s_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'guba_o2c_s_sgnl',
'BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 3.32 / 2.31 / 3.29bp/d, edge 54bp


icom['guba_o2c_l_sgnl'] = np.nan
c1 = (icom['adjret_o_c_t20d_rk']<-0.8) & (icom['cnt_x0_tdate_t20d_rk']<0) & (icom['1_r2_t1m_rk']<0) 
icom.loc[c1, 'guba_o2c_l_sgnl'] = 1
c2 = (icom['adjret_o_c_t20d_rk']>0.8) | (icom['cnt_x0_tdate_t20d_rk']>0.8) | (icom['1_r2_t1m_rk']>0.8)
icom.loc[c2, 'guba_o2c_l_sgnl'] = 0
icom['guba_o2c_l_sgnl'] = icom.groupby('ticker')['guba_o2c_l_sgnl'].ffill(limit=60)
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['guba_o2c_l_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'guba_o2c_l_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.91 / 1.97, 2.59bp/d, egde 46bp 



icom['guba_o2c_l_sgnl'] = np.nan ###!!!
c1 = (icom['adjret_o_c_t20d_rk']<-0.8) & (icom['cnt_x0_tdate_t20d_rk']<0) & (icom['1_r2_t1m_v2_rk']<0) 
icom.loc[c1, 'guba_o2c_l_sgnl'] = 1
c2 = (icom['adjret_o_c_t20d_rk']>0.8) | (icom['cnt_x0_tdate_t20d_rk']>0.8) | (icom['1_r2_t1m_v2_rk']>0.8)
icom.loc[c2, 'guba_o2c_l_sgnl'] = 0
icom['guba_o2c_l_sgnl'] = icom.groupby('ticker')['guba_o2c_l_sgnl'].ffill(limit=60)
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['guba_o2c_l_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'guba_o2c_l_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.91 / 1.97, 2.59bp/d, egde 46bp 


icom['guba_o2c_l_sgnl'] = np.nan ###!!!
c1 = (icom['adjret_o_c_t20d_rk']<-0.8) & (icom['cnt_x0_tdate_t20d_rk']<0) 
icom.loc[c1, 'guba_o2c_l_sgnl'] = 1
c2 = (icom['adjret_o_c_t20d_rk']>0.8) | (icom['cnt_x0_tdate_t20d_rk']>0.8) 
icom.loc[c2, 'guba_o2c_l_sgnl'] = 0
icom['guba_o2c_l_sgnl'] = icom.groupby('ticker')['guba_o2c_l_sgnl'].ffill(limit=60)
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['guba_o2c_l_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'guba_o2c_l_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.91 / 1.97, 2.59bp/d, egde 46bp 




# guba cnt time series zscore

c1 = (icom['cnt_w0_tdate_z']>3) & (icom['adjret_o_c_t20d_rk']>0.5)
icom['z_sgnl'] = np.nan
icom.loc[c1, 'z_sgnl'] = -1
icom['z_sgnl'] = icom.groupby('ticker')['z_sgnl'].ffill(limit=20)

yu.create_cn_decay(icom, 'z_sgnl')

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['z_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=[
'ticker','datadate']),
            'z_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['a50_300_flag']==1)].\
            dropna(subset=['z_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'z_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 



c1 = (icom['cnt_w0_tdate_z']<-0.9) & (icom['adjret_o_c_t20d_rk']>0.5)
icom['z_sgnl2'] = np.nan
icom.loc[c1, 'z_sgnl2'] = 1
icom['z_sgnl2'] = icom.groupby('ticker')['z_sgnl2'].ffill(limit=20)

yu.create_cn_decay(icom, 'z_sgnl2')
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['z_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'z_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # not working 



# guba cnt / pv
icom['cnt_x0_t20d_dv_pv'] = icom['cnt_x0_t20d'].divide(icom['avgPVadj'])
icom['cnt_x0_t20d_dv_pv_bk'] = icom.groupby('datadate')['cnt_x0_t20d_dv_pv'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_x0_t20d_dv_pv_rk'] = icom.groupby('datadate')['cnt_x0_t20d_dv_pv'].apply(yu.uniformed_rank).values

icom['cnt_dv_pv_sgnl'] = - icom['cnt_x0_t20d_dv_pv_rk']


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['cnt_dv_pv_sgnl']>0)].\
            dropna(subset=['cnt_dv_pv_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_dv_pv_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.38/1.3

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['cnt_dv_pv_sgnl']<0)].\
            dropna(subset=['cnt_dv_pv_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_dv_pv_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.33/1.57


# rkdf guba and turnover
icom['turnover_t20d_rk'] = icom.groupby('datadate')['turnover_t20d'].apply(yu.uniformed_rank).values
icom['turnover_t20d_bk'] = icom.groupby('datadate')['turnover_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['1_r2_t1m_rk'] = icom.groupby('datadate')['1_r2_t1m'].apply(yu.uniformed_rank).values
icom['one_r2_t1m_bk'] = icom.groupby('datadate')['1_r2_t1m'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['cnt_x0_turnover_t20d_rkdf'] = icom['cnt_x0_t20d_rk'] - icom['turnover_t20d_rk']
icom['cnt_x0_turnover_t20d_rkdf_rk'] = icom.groupby('datadate')['cnt_x0_turnover_t20d_rkdf'].apply(yu.uniformed_rank).values
icom['cnt_x0_turnover_t20d_rkdf_bk'] = icom.grou
pby('datadate')['cnt_x0_turnover_t20d_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['cnt_x0_turnover_t20d_rksum'] = icom['cnt_x0_t20d_rk'] + icom['turnover_t20d_rk']
icom['cnt_x0_turnover_t20d_rksum_bk'] = icom.groupby('datadate')['cnt_x0_turnover_t20d_rksum'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['cnt_x0_1_r2_t20d_rksum'] = icom['cnt_x0_t20d_rk'] + icom['1_r2_t1m_rk']
icom['cnt_x0_1_r2_t20d_rksum_bk'] = icom.groupby('datadate')['cnt_x0_1_r2_t20d_rksum'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cnt_x0_1_r2_t20d_rksum_rk'] = icom.groupby('datadate')['cnt_x0_1_r2_t20d_rksum'].apply(yu.uniformed_rank).values



yu.create_cn_3x3(icom, ['cnt_x0_t20d_bk'], 'cnt_x0_t20d')
yu.create_cn_3x3(icom, ['cnt_tdate_t20d_bk'], 'cnt_tdate_t20d')

yu.create_cn_3x3(icom, ['cnt_x0_t20d_dv_pv_bk'], 'cnt_x0_t20d_dv_pv')

yu.create_cn_3x3(icom, ['cnt_t20d_bk'], 'cnt_t20d')
yu.create_cn_3x3(icom, ['cnt_0930_1500_t20d_bk'], 'cnt_0930_1500_t20d')
yu.create_cn_3x3(icom, ['cnt_1000_1500_t20d_bk'], 'cnt_1000_1500_t20d')

yu.create_cn_3x3(icom, ['cnt_0930_1500_tdate_t20d_bk'], 'cnt_0930_1500_tdate_t20d')
yu.create_cn_3x3(icom, ['cnt_1000_1500_tdate_t20d_bk'], 'cnt_1000_1500_tdate_t20d')
yu.create_cn_3x3(icom, ['cnt_tdate_t20d_allbk'], 'cnt_tdate_t20d')

yu.create_cn_3x3(icom, ['cnt_x0_turnover_t20d_rkdf_bk'], 'cnt_x0_turnover_t20d_rkdf')
yu.create_cn_3x3(icom, ['cnt_x0_1_r2_t20d_rksum_bk'], 'cnt_x0_1_r2_t20d_rksum')

yu.create_cn_3x3(icom, ['one_r2_t1m_bk'], '1_r2_t1m')
yu.create_cn_3x3(icom, ['turnover_t20d_bk'], 'turnover_t20d')





# simple rank of 1_r2


icom['1_r2_sgnl'] = - icom['1_r2_t1m_rk']

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['1_r2_sgnl']>0)].\
            dropna(subset=['1_r2_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            '1_r2_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 1.97 / -2.03

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['1_r2_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            '1_r2_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.41 / -1.65


# extreme guba count and top 1_r2

icom['lTurn_lGuba_sgnl'] = np.nan
icom.loc[(icom['cnt_x0_t20d_rk']<-0.8)&(icom['1_r2_t1m_rk']<0), 'lTurn_lGuba_sgnl'] = 1
icom['lTurn_lGuba_sgnl'] = icom.groupby('ticker')['lTurn_lGuba_sgnl'].ffill(limit=20)

icom['hTurn_hGuba_sgnl'] = np.nan
icom.loc[(icom['cnt_x0_t20d_rk']>0.8)&(icom['1_r2_t1m_
rk']>0.8), 'hTurn_hGuba_sgnl'] = -1
icom['hTurn_hGuba_sgnl'] = icom.groupby('ticker')['hTurn_hGuba_sgnl'].ffill(limit=40)

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['lTurn_lGuba_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'lTurn_lGuba_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) #

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['hTurn_hGuba_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'hTurn_hGuba_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 1.97/1.47, 2.06bp/d


# combine guba and 1_r2

icom['cnt_x0_1_r2_t20d_sgnl'] = - icom['cnt_x0_1_r2_t20d_rksum_rk']

icom['cnt_x0_1_r2_t20d_sgnl2'] = np.nan
c1 = icom['cnt_x0_1_r2_t20d_rksum_rk'].abs()>0.8
icom.loc[c1, 'cnt_x0_1_r2_t20d_sgnl2'] = icom.loc[c1, 'cnt_x0_1_r2_t20d_sgnl']
icom['cnt_x0_1_r2_t20d_sgnl2'] = icom.groupby('ticker')['cnt_x0_1_r2_t20d_sgnl2'].ffill(limit=10)


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['cnt_x0_1_r2_t20d_sgnl']>0)].\
            dropna(subset=['cnt_x0_1_r2_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_x0_1_r2_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 3.3/0.15,0.14bp/d

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['cnt_x0_1_r2_t20d_sgnl']<0)].\
            dropna(subset=['cnt_x0_1_r2_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_x0_1_r2_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 3.2/0.45, 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['cnt_x0_1_r2_t20d_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_x0_1_r2_t20d_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.57 / 1.01, 0.85bp/d






icom['topLong_sgnl'] = np.nan
icom.loc[icom['cnt_x0_t20d_rk']>0, 'topLong_sgnl'] = 1
icom['topLong_sgnl'] = icom.groupby('ticker')['topLong_sgnl'].ffill(limit=20).values

icom['ls_sgnl'] = np.nan
icom['ls_sgnl'] = - icom['cnt_x0_t20d_rk']



o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['ls_sgnl']>0)].\
            dropna(subset=['ls_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ls_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-
01')].\
            dropna(subset=['cnt_x0_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_x0_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['cnt_x0_t20d_rk']>0)].\
            dropna(subset=['cnt_x0_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cnt_x0_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 


#------------------------------------------------------------------------------



df_gbs = []
for dt in pd.date_range(start='2015-04-02', end = '2020-01-01').strftime('%Y-%m-%d').tolist():
    
    preday = (pd.to_datetime(dt) - pd.to_timedelta('90 days')).strftime('%Y-%m-%d')
    
    # =============================================================================
    #     
    # =============================================================================

    df_des = i_guba[ (i_guba['FileDate'] <= dt) & (i_guba['FileDate'] >= preday) ]
    
    df_num = df_des.groupby('ticker')['datadate'].count()
    df_num = df_num[ df_num >= 20 ]

    df_des = df_des[ df_des['ticker'].isin(df_num.index.tolist()) ]
    df_des = df_des.sort_values('datadate')

    df_des = df_des.groupby('ticker').tail(20)
    df_des = df_des.groupby('ticker')['cnt'].sum()
    df_des = df_des.reset_index()

    # =============================================================================
    # 
    # =============================================================================

    df_des['datadate'] = dt
    df_des = df_des[['datadate','ticker','cnt']]
    
    df_gbs.append(df_des)
    print(dt,end='')

df_gbs = pd.concat(df_gbs)
df_gbs['datadate'] = pd.to_datetime(df_gbs['datadate'])

icomgf = i_sd_map.merge(df_gbs, on = ['datadate','ticker'], how = 'left')
icomgf = icomgf.sort_values(['ticker', 'datadate'])
icomgf['cnt_bk'] = icomgf.groupby('ticker')['cnt'].apply(lambda x: yu.pdqcut(x,bins=5)).values
icomgf['cnt_rk'] = icomgf.groupby('ticker')['cnt'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icomgf, ['cnt_bk'], 'cnt')



icomgf['ls_sgnl'] = np.nan
icomgf['ls_sgnl'] = - icomgf['cnt_rk']

o_1 = yu.bt_cn_15(icomgf[(icomgf['datadate']<='2020-01-01')&(icomgf['ls_sgnl']>0)].\
            dropna(subset=['ls_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ls_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 4.75 / 2.38, 1.8bp/d

