﻿#$%^&* pShortQuota_wr_hk_prod.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 16 14:26:10 2022

@author: thzhang
"""


import pWIND_util as pw
import yz.util as yu

import pandas as pd
import numpy as np

import datetime

import matplotlib.pyplot as plt


# source: \\ad\dfs\botraders\alltraders\China_Avail





#------------------------------------------------------------------------------
### bt  
#------------------------------------------------------------------------------


def bt_wr(df, str_col_date, str_col_sgnl, str_col_ret):
    # this tests long-only equal-weighted signals
    
    CAPITAL = 1e6
    LMT=2e5
    
    # calculate pstD
    
    df_daily_signals = df.groupby(str_col_date)[str_col_sgnl].sum().reset_index()
    df_daily_signals.columns = [str_col_date, 'daily_sgnl_cnt']
    df = df.merge(df_daily_signals, on=str_col_date, how='left')
    
    df['pstD'] = CAPITAL / df['daily_sgnl_cnt'] * df[str_col_sgnl]
    df.loc[df['pstD']>LMT,'pstD'] = LMT
    
    #
    
    s = df.sort_values(str_col_date)
    s = s.reset_index(drop=True)
    
    spos = s.pivot_table(index='ticker',columns=[str_col_date], values='pstD')
    spos = spos.fillna(0)
    spos = spos.unstack()
    spos = spos.reset_index()
    spos = spos.rename(columns={0:'pos'})
    spos = spos.sort_values(['ticker',str_col_date])
    spos['pos_pre'] = spos.groupby(['ticker'])['pos'].shift(1)
    spos = spos.fillna(0)
    spos = spos[ ~((spos['pos']==0) & (spos['pos_pre']==0))   ]
    spos['trdd'] = spos['pos'] - spos['pos_pre']
    spos['abstrdd'] = abs(spos['trdd'])
    spos['gmv'] = abs(spos['pos'])
        
    c_b = spos['trdd']>=0
    spos.loc[c_b, 'cost'] = spos.loc[c_b, 'abstrdd'] * (0.00025+0.00002)
    c_s = spos['trdd']<0
    spos.loc[c_s, 'cost'] = spos.loc[c_s, 'abstrdd'] * (0.001+0.00025+0.00002)
    
    spos = spos.merge(df[['ticker', str_col_date, str_col_ret]], on = ['ticker', str_col_date], how = 'left')
    spos['pnl_bc'] = spos['pos'] * spos[str_col_ret] 
    spos['pnl_ac'] = spos['pnl_bc'] - spos['cost']    
    
    ret = spos.groupby(str_col_date)['pnl_bc','pnl_ac'].sum()
    ret = ret.reset_index()
    ret = ret.dropna()
    ret['cumpnl_bc'] = ret['pnl_bc'].cumsum()
    ret['cumpnl_ac'] = ret['pnl_ac'].cumsum()
        
    sr_pnl_bc = np.round(ret['pnl_bc'].mean() / ret['pnl_bc'].std() * np.sqrt(252),2)
    sr_pnl_ac = np.round(ret['pnl_ac'].mean() / ret['pnl_ac'].std() * np.sqrt(252),2)

    mean_ret_bc = np.round( (spos['pnl_bc'].sum() / spos['gm
v'].sum())*1e4,2)
    mean_ret_ac = np.round( (spos['pnl_ac'].sum() / spos['gmv'].sum())*1e4,2)
    
    ept = np.round( (spos['pnl_bc'].sum() / spos['abstrdd'].sum())*1e4,2)
    
    ret = ret.set_index(str_col_date)
    
    # plot
    
    fig1 = plt.figure(figsize=(20,4))
    ax1 = fig1.add_subplot(121)
    ax1.plot(ret['cumpnl_bc'])
    ax1.plot(ret['cumpnl_ac'])

    ax1.grid()
    ax1.set_ylabel('PNL', fontsize = 16)
    ax1.set_xlabel('Date',fontsize = 16)
    
    ax1.text(0.01, 0.87, 'Annualized Sharpe: ' + str(sr_pnl_bc) + '(bc), ' +  str(sr_pnl_ac) + ' (ac) ', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.81, 'Daily Return on GMV: ' + str(mean_ret_bc) + ' bps (bc), ' + str(mean_ret_ac) + ' bps (ac)', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    ax1.text(0.01, 0.75, 'Edge Per Trade: ' + str(ept) + ' bps', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    spos_gmvret = spos.groupby(str_col_date)[['pnl_ac','gmv']].sum()
    spos_gmvret_number = spos_gmvret['pnl_ac'].sum() / spos_gmvret[spos_gmvret['gmv']>0]['gmv'].mean() / len(spos_gmvret) * 252
    spos_gmvret_number = round(spos_gmvret_number*100,2)
    ax1.text(0.01, 0.57, 'GMV Ret: ' + str(spos_gmvret_number) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax1.transAxes, color = 'r', fontsize = 10 )
    
    
    gmvlong = spos[ spos['pos'] > 0].groupby(str_col_date)['gmv'].sum()
    gmvlong = gmvlong.reset_index()
    gmvlong.columns = [str_col_date,'long']
    gmvlong = gmvlong.set_index(str_col_date)
    gmvshort = spos[ spos['pos'] < 0].groupby(str_col_date)['gmv'].sum()
    gmvshort = gmvshort.reset_index()
    gmvshort.columns = [str_col_date,'short']
    gmvshort = gmvshort.set_index(str_col_date)
    
    ax2 = fig1.add_subplot(122)
    gmv = pd.concat([gmvlong,gmvshort],axis=1)
    ax2.plot(gmv)
    
    ax2.grid()
    ax2.set_ylabel('GMV', fontsize = 16)
    ax2.set_xlabel('Date',fontsize = 16)
    
    totgmv = spos.groupby(str_col_date)['gmv'].sum().mean()    
    to = np.round(spos['abstrdd'].sum() / spos['gmv'].sum() * 100)
    
    ax2.text(0.01, 0.93, 'Avg Long Size: ' + str(np.round(gmvlong['long'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fo
ntsize = 10 )
    ax2.text(0.01, 0.87, 'Avg Short Size: ' + str(np.round(gmvshort['short'].mean()/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.81, 'Total Size: ' + str(np.round(totgmv/1e6)) +' $MM', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    ax2.text(0.01, 0.75, 'Turnover: ' + str(to) +'%', verticalalignment ='bottom', horizontalalignment = 'left', transform = ax2.transAxes, color = 'r', fontsize = 10 )
    
    
    
    return spos



### o2o return

i_o2o = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate_p1d,
                 s_dq_adjopen as o
                 from wind_prod.dbo.ashareeodprices
                 where trade_dt >= '20180101' ''')
i_o2o['datadate_p1d'] = pd.to_datetime(i_o2o['datadate_p1d'], format = '%Y%m%d')
i_o2o = i_o2o.sort_values(['ticker', 'datadate_p1d']).reset_index(drop=True)
i_o2o['o_1d'] = i_o2o.groupby('ticker')['o'].shift()
i_o2o['o2oret'] = i_o2o['o'] / i_o2o['o_1d'] - 1
i_o2o['o2oret+0d'] = i_o2o.groupby('ticker')['o2oret'].shift(-1)
i_o2o['o2oret+01d'] = i_o2o['o2oret+0d'] + i_o2o.groupby('ticker')['o2oret'].shift(-2)
i_o2o['o2oret+02d'] = i_o2o['o2oret+0d'] + i_o2o.groupby('ticker')['o2oret'].shift(-3)
i_o2o['o2oret+03d'] = i_o2o['o2oret+0d'] + i_o2o.groupby('ticker')['o2oret'].shift(-4)
i_o2o['o2oret+04d'] = i_o2o['o2oret+0d'] + i_o2o.groupby('ticker')['o2oret'].shift(-5)
i_o2o['o2oret-1d'] = i_o2o['o2oret']
i_o2o = i_o2o[['ticker', 'datadate_p1d', 'o2oret+01d','o2oret+04d','o2oret+0d', 'o2oret-1d']]


### PV

i_pv = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                 s_dq_amount*1000 as amt 
                 from wind_prod.dbo.ashareeodprices
                 where trade_dt >= '2018-01-01' 
                 order by s_info_windcode, trade_dt ''')
i_pv['datadate'] = pd.to_datetime(i_pv['datadate'], format = '%Y%m%d')
i_pv['avgPV'] = i_pv.groupby('ticker').rolling(20)['amt'].mean().values
i_pv = i_pv.sort_values('datadate')




### pastret



i_o2c = yu.get_sql('''select a.ticker, a.datadate, a.open_1hr_vwap as o ,
                          b.px_close as c
                      from [CNDBPROD].[dbo].[TRTH_OPENCLOSE_CN] a
                      inner join 
                      [CNDBPROD].[dbo].[UNIVERSE_T2000_CN_GEM3L] b
                      on a.ticker = b.ticker and a.datadate = b.datad
ate
                      where a.datadate >= '20180101' and b.datadate >= '20180101'                      
                      ''')
c_sh = i_o2c['ticker'].str[0].isin(['6'])
c_sz = i_o2c['ticker'].str[0].isin(['0','3'])
i_o2c.loc[c_sh, 'ticker'] = i_o2c.loc[c_sh, 'ticker'] + '.SH'
i_o2c.loc[c_sz, 'ticker'] = i_o2c.loc[c_sz, 'ticker'] + '.SZ'
i_o2c['o2c'] = i_o2c['c'] / i_o2c['o'] - 1

i_o2c = i_o2c.sort_values(['ticker', 'datadate'])
i_o2c['o2c_ma20d'] = i_o2c.groupby('ticker')\
                     .rolling(datetime.timedelta(days=28),on='datadate',min_periods=10)\
                     ['o2c'].mean().values



### c

i_c = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                 s_dq_close as c, s_dq_adjclose / s_dq_adjpreclose - 1 as c2c
                 from wind_prod.dbo.ashareeodprices
                 where trade_dt >= '20180101' ''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format = '%Y%m%d')
i_c = i_c.sort_values(['ticker', 'datadate'])
i_c['c_max1y'] = i_c.groupby('ticker').rolling(252)['c'].max().values
i_c['c_min1y'] = i_c.groupby('ticker').rolling(252)['c'].min().values
i_c['c_hlidx'] = (i_c['c'] - i_c['c_min1y']) / (i_c['c_max1y'] - i_c['c_min1y'])
i_c = i_c.sort_values('datadate')

    

### index constituents

i_300500 = yu.get_sql('''select ticker, datadate, cn_index 
                      FROM [CNDBPROD].[dbo].[UNIVERSE_T3000_CN_GEM3L] 
                      where datadate >= '20180101' ''')
c_sh = i_300500['ticker'].str[0].isin(['6'])
c_sz = i_300500['ticker'].str[0].isin(['0','3'])
i_300500.loc[c_sh, 'ticker'] = i_300500.loc[c_sh, 'ticker'] + '.SH'
i_300500.loc[c_sz, 'ticker'] = i_300500.loc[c_sz, 'ticker'] + '.SZ'




### tdate mapping

i_td = yu.get_sql( '''
                select distinct TradeDate_next as datadate_p1d
                from CNDBPROD.dbo.Calendar_Dates_CN
                where TradeDate_next >= '20180101' 
                order by TradeDate_next
                ''')
i_td['datadate'] = i_td['datadate_p1d'].shift()






### ETB gs

i_etb_gs = yu.get_sql('''select datadate as datadate_p1d, ric, avail_amount_gs, rate_gs                    
                   from [CNDBPROD].[dbo].[MLP_CN_ETBList_ABC_RIC] 
                   ''')
i_etb_gs['ticker_6d'] = i_etb_gs['ric'].str[:6]
i_etb_gs.loc[i_etb_gs['ric'].str[-2:].isin(['SS', 'SZ']), 'mkt'] = 'onshore'
i_etb_gs.loc[i_etb_gs['ric'].str[-2:].isin(['SH', 'ZK']), 'mkt'] = 'offshore'

i_etb_gs = i_etb_gs.groupby(['ticker_6d','mkt','datad
ate_p1d'])['avail_amount_gs'].sum().reset_index()
i_etb_gs = i_etb_gs.pivot_table(index=['ticker_6d', 'datadate_p1d'], columns = 'mkt', values = 'avail_amount_gs')
i_etb_gs = i_etb_gs.rename(columns={'offshore':'gs_off_shares', 'onshore':'gs_on_shares'})
i_etb_gs = i_etb_gs.reset_index()

c_sh = i_etb_gs['ticker_6d'].str[0].isin(['6'])
c_sz = i_etb_gs['ticker_6d'].str[0].isin(['0','3'])
i_etb_gs.loc[c_sh, 'ticker'] = i_etb_gs.loc[c_sh, 'ticker_6d'] + '.SH'
i_etb_gs.loc[c_sz, 'ticker'] = i_etb_gs.loc[c_sz, 'ticker_6d'] + '.SZ'
i_etb_gs = i_etb_gs[i_etb_gs['ticker'].notnull()]

# merge other data into ETB

i_etb_gs = i_etb_gs.sort_values('datadate_p1d')
i_etb_gs = pd.merge_asof(i_etb_gs, i_pv[['ticker', 'datadate', 'avgPV']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_gs = i_etb_gs.drop(columns = 'datadate')
i_etb_gs = pd.merge_asof(i_etb_gs, i_c[['ticker', 'datadate', 'c']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_gs = i_etb_gs.drop(columns = 'datadate')


i_etb_gs['gs_off_rmb'] = i_etb_gs['gs_off_shares']  * i_etb_gs['c'] 
i_etb_gs['gs_off_rmb'] = i_etb_gs['gs_off_rmb'].fillna(0)
i_etb_gs['gs_off_rmb_1d'] = i_etb_gs.groupby('ticker')['gs_off_rmb'].shift(1)
i_etb_gs['gs_off_rmb_2d'] = i_etb_gs.groupby('ticker')['gs_off_rmb'].shift(2)
i_etb_gs['gs_off_rmb_3d'] = i_etb_gs.groupby('ticker')['gs_off_rmb'].shift(3)
i_etb_gs['gs_off_rmb_4d'] = i_etb_gs.groupby('ticker')['gs_off_rmb'].shift(4)
i_etb_gs['gs_off_rmb_5d'] = i_etb_gs.groupby('ticker')['gs_off_rmb'].shift(5)

# calculate flags

i_etb_gs = i_etb_gs.sort_values(['ticker', 'datadate_p1d'])

i_etb_gs['flg_gs_appear3'] = np.nan
c1 = (i_etb_gs['gs_off_rmb_1d'] == 0) & (i_etb_gs['gs_off_rmb_2d'] == 0) \
     & (i_etb_gs['gs_off_rmb_3d'] == 0) & (i_etb_gs['gs_off_rmb_4d'] == 0) \
     & (i_etb_gs['gs_off_rmb_5d'] == 0)
i_etb_gs.loc[((i_etb_gs['gs_off_rmb'] / i_etb_gs['avgPV'] > 0.05) | (i_etb_gs['gs_off_rmb']>5e6)) & c1, 'flg_gs_appear3'] = 1
             

i_etb_gs = i_etb_gs[['ticker','datadate_p1d','flg_gs_appear3']]





### ETB ms

i_etb_ms = yu.get_sql('''select datadate as datadate_p1d, ric, avail_amount_ms, rate_ms                    
                   from [CNDBPROD].[dbo].[MLP_CN_ETBList_ABC_RIC] 
                   ''')
i_etb_ms['ticker_6d'] = i_etb_ms['ri
c'].str[:6]
i_etb_ms.loc[i_etb_ms['ric'].str[-2:].isin(['SS', 'SZ']), 'mkt'] = 'onshore'
i_etb_ms.loc[i_etb_ms['ric'].str[-2:].isin(['SH', 'ZK']), 'mkt'] = 'offshore'

i_etb_ms = i_etb_ms.groupby(['ticker_6d','mkt','datadate_p1d'])['avail_amount_ms'].sum().reset_index()
i_etb_ms = i_etb_ms.pivot_table(index=['ticker_6d', 'datadate_p1d'], columns = 'mkt', values = 'avail_amount_ms')
i_etb_ms = i_etb_ms.rename(columns={'offshore':'ms_off_shares', 'onshore':'ms_on_shares'})
i_etb_ms = i_etb_ms.reset_index()

c_sh = i_etb_ms['ticker_6d'].str[0].isin(['6'])
c_sz = i_etb_ms['ticker_6d'].str[0].isin(['0','3'])
i_etb_ms.loc[c_sh, 'ticker'] = i_etb_ms.loc[c_sh, 'ticker_6d'] + '.SH'
i_etb_ms.loc[c_sz, 'ticker'] = i_etb_ms.loc[c_sz, 'ticker_6d'] + '.SZ'

# merge other data into ETB

i_etb_ms = i_etb_ms.sort_values('datadate_p1d')
i_etb_ms = pd.merge_asof(i_etb_ms, i_pv[['ticker', 'datadate', 'avgPV']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_ms = i_etb_ms.drop(columns = 'datadate')
i_etb_ms = pd.merge_asof(i_etb_ms, i_c[['ticker', 'datadate', 'c']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_ms = i_etb_ms.drop(columns = 'datadate')

i_etb_ms['ms_off_rmb'] = i_etb_ms['ms_off_shares']  * i_etb_ms['c'] 
i_etb_ms['ms_off_rmb'] = i_etb_ms['ms_off_rmb'].fillna(0)


# calculate flags

i_etb_ms = i_etb_ms.sort_values(['ticker', 'datadate_p1d'])

i_etb_ms['flg_ms_appear3'] = np.nan
c1 = (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(1) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(2) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(3) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(4) == 0) \
     & (i_etb_ms.groupby('ticker')['ms_off_rmb'].shift(5) == 0)
i_etb_ms.loc[((i_etb_ms['ms_off_rmb'] / i_etb_ms['avgPV'] > 0.05) | (i_etb_ms['ms_off_rmb']>5e6)) & c1, 'flg_ms_appear3'] = 1

i_etb_ms = i_etb_ms[['ticker','datadate_p1d','flg_ms_appear3']]






### ETB jpm

i_etb_jpm = yu.get_sql('''select datadate as datadate_p1d, ric, avail_amount_jpm, rate_jpm                    
                   from [CNDBPROD].[dbo].[MLP_CN_ETBList_ABC_RIC] 
                   ''')
i_etb_jpm['ticker_6d'] = i_etb_jpm['ric'].str[:6]
i_etb_jpm.loc[i_etb_jpm['ric'].str[-2:].isin(['SS', 'SZ']), 'mkt'] = 'onshore'
i
_etb_jpm.loc[i_etb_jpm['ric'].str[-2:].isin(['SH', 'ZK']), 'mkt'] = 'offshore'

i_etb_jpm = i_etb_jpm.groupby(['ticker_6d','mkt','datadate_p1d'])['avail_amount_jpm'].sum().reset_index()
i_etb_jpm = i_etb_jpm.pivot_table(index=['ticker_6d', 'datadate_p1d'], columns = 'mkt', values = 'avail_amount_jpm')
i_etb_jpm = i_etb_jpm.rename(columns={'offshore':'jpm_off_shares', 'onshore':'jpm_on_shares'})
i_etb_jpm = i_etb_jpm.reset_index()

c_sh = i_etb_jpm['ticker_6d'].str[0].isin(['6'])
c_sz = i_etb_jpm['ticker_6d'].str[0].isin(['0','3'])
i_etb_jpm.loc[c_sh, 'ticker'] = i_etb_jpm.loc[c_sh, 'ticker_6d'] + '.SH'
i_etb_jpm.loc[c_sz, 'ticker'] = i_etb_jpm.loc[c_sz, 'ticker_6d'] + '.SZ'

# merge other data into ETB

i_etb_jpm = i_etb_jpm.sort_values('datadate_p1d')
i_etb_jpm = pd.merge_asof(i_etb_jpm, i_pv[['ticker', 'datadate', 'avgPV']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_jpm = i_etb_jpm.drop(columns = 'datadate')
i_etb_jpm = pd.merge_asof(i_etb_jpm, i_c[['ticker', 'datadate', 'c']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_jpm = i_etb_jpm.drop(columns = 'datadate')

i_etb_jpm['jpm_off_rmb'] = i_etb_jpm['jpm_off_shares']  * i_etb_jpm['c'] 
i_etb_jpm['jpm_off_rmb'] = i_etb_jpm['jpm_off_rmb'].fillna(0)


# calculate flags

i_etb_jpm = i_etb_jpm.sort_values(['ticker', 'datadate_p1d'])
i_etb_jpm['flg_jpm_appear3'] = np.nan
c1 = (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(1) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(2) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(3) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(4) == 0) \
     & (i_etb_jpm.groupby('ticker')['jpm_off_rmb'].shift(5) == 0)
i_etb_jpm.loc[((i_etb_jpm['jpm_off_rmb'] / i_etb_jpm['avgPV'] > 0.05) | (i_etb_jpm['jpm_off_rmb']>5e6)) & c1, 'flg_jpm_appear3'] = 1


i_etb_jpm = i_etb_jpm[['ticker','datadate_p1d','flg_jpm_appear3']]




### ETB baml

i_etb_baml = yu.get_sql('''select datadate as datadate_p1d, ric, avail_amount_baml, rate_baml                    
                   from [CNDBPROD].[dbo].[MLP_CN_ETBList_ABC_RIC] 
                   ''')
i_etb_baml['ticker_6d'] = i_etb_baml['ric'].str[:6]
i_etb_baml.loc[i_etb_baml['ric'].str[-2:].isin(['SS', 'SZ']), 'mkt'] = 'onshore'
i_etb_baml.loc[i_etb_b
aml['ric'].str[-2:].isin(['SH', 'ZK']), 'mkt'] = 'offshore'

i_etb_baml = i_etb_baml.groupby(['ticker_6d','mkt','datadate_p1d'])['avail_amount_baml'].sum().reset_index()
i_etb_baml = i_etb_baml.pivot_table(index=['ticker_6d', 'datadate_p1d'], columns = 'mkt', values = 'avail_amount_baml')
i_etb_baml = i_etb_baml.rename(columns={'offshore':'baml_off_shares', 'onshore':'baml_on_shares'})
i_etb_baml = i_etb_baml.reset_index()

c_sh = i_etb_baml['ticker_6d'].str[0].isin(['6'])
c_sz = i_etb_baml['ticker_6d'].str[0].isin(['0','3'])
i_etb_baml.loc[c_sh, 'ticker'] = i_etb_baml.loc[c_sh, 'ticker_6d'] + '.SH'
i_etb_baml.loc[c_sz, 'ticker'] = i_etb_baml.loc[c_sz, 'ticker_6d'] + '.SZ'

# merge other data into ETB

i_etb_baml = i_etb_baml.sort_values('datadate_p1d')
i_etb_baml = pd.merge_asof(i_etb_baml, i_pv[['ticker', 'datadate', 'avgPV']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_baml = i_etb_baml.drop(columns = 'datadate')
i_etb_baml = pd.merge_asof(i_etb_baml, i_c[['ticker', 'datadate', 'c']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_baml = i_etb_baml.drop(columns = 'datadate')

i_etb_baml['baml_off_rmb'] = i_etb_baml['baml_off_shares']  * i_etb_baml['c'] 
i_etb_baml['baml_off_rmb'] = i_etb_baml['baml_off_rmb'].fillna(0)


# calculate flags

i_etb_baml = i_etb_baml.sort_values(['ticker', 'datadate_p1d'])
i_etb_baml['flg_baml_appear3'] = np.nan
c1 = (i_etb_baml.groupby('ticker')['baml_off_rmb'].shift(1) == 0) \
     & (i_etb_baml.groupby('ticker')['baml_off_rmb'].shift(2) == 0) \
     & (i_etb_baml.groupby('ticker')['baml_off_rmb'].shift(3) == 0) \
     & (i_etb_baml.groupby('ticker')['baml_off_rmb'].shift(4) == 0) \
     & (i_etb_baml.groupby('ticker')['baml_off_rmb'].shift(5) == 0)
i_etb_baml.loc[((i_etb_baml['baml_off_rmb'] / i_etb_baml['avgPV'] > 0.05) | (i_etb_baml['baml_off_rmb']>5e6)) & c1, 'flg_baml_appear3'] = 1


i_etb_baml = i_etb_baml[['ticker','datadate_p1d','flg_baml_appear3']]





### ETB ubs

i_etb_ubs = yu.get_sql('''select datadate as datadate_p1d, ric, avail_amount_ubs, rate_ubs                    
                   from [CNDBPROD].[dbo].[MLP_CN_ETBList_ABC_RIC] 
                   ''')
i_etb_ubs['ticker_6d'] = i_etb_ubs['ric'].str[:6]
i_etb_ubs.loc[i_etb_ubs['ric'].str[-2:].isin(['SS', 'SZ']), 'mkt']
 = 'onshore'
i_etb_ubs.loc[i_etb_ubs['ric'].str[-2:].isin(['SH', 'ZK']), 'mkt'] = 'offshore'

i_etb_ubs = i_etb_ubs.groupby(['ticker_6d','mkt','datadate_p1d'])['avail_amount_ubs'].sum().reset_index()
i_etb_ubs = i_etb_ubs.pivot_table(index=['ticker_6d', 'datadate_p1d'], columns = 'mkt', values = 'avail_amount_ubs')
i_etb_ubs = i_etb_ubs.rename(columns={'offshore':'ubs_off_shares', 'onshore':'ubs_on_shares'})
i_etb_ubs = i_etb_ubs.reset_index()

c_sh = i_etb_ubs['ticker_6d'].str[0].isin(['6'])
c_sz = i_etb_ubs['ticker_6d'].str[0].isin(['0','3'])
i_etb_ubs.loc[c_sh, 'ticker'] = i_etb_ubs.loc[c_sh, 'ticker_6d'] + '.SH'
i_etb_ubs.loc[c_sz, 'ticker'] = i_etb_ubs.loc[c_sz, 'ticker_6d'] + '.SZ'

# merge other data into ETB

i_etb_ubs = i_etb_ubs.sort_values('datadate_p1d')
i_etb_ubs = pd.merge_asof(i_etb_ubs, i_pv[['ticker', 'datadate', 'avgPV']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_ubs = i_etb_ubs.drop(columns = 'datadate')
i_etb_ubs = pd.merge_asof(i_etb_ubs, i_c[['ticker', 'datadate', 'c']], 
                         by='ticker', left_on='datadate_p1d', right_on='datadate', 
                         allow_exact_matches = False, suffixes=['','_m'])
i_etb_ubs = i_etb_ubs.drop(columns = 'datadate')

i_etb_ubs['ubs_off_rmb'] = i_etb_ubs['ubs_off_shares']  * i_etb_ubs['c'] 
i_etb_ubs['ubs_off_rmb'] = i_etb_ubs['ubs_off_rmb'].fillna(0)


# calculate flags

i_etb_ubs = i_etb_ubs.sort_values(['ticker', 'datadate_p1d'])
i_etb_ubs['flg_ubs_appear3'] = np.nan
c1 = (i_etb_ubs.groupby('ticker')['ubs_off_rmb'].shift(1) == 0) \
     & (i_etb_ubs.groupby('ticker')['ubs_off_rmb'].shift(2) == 0) \
     & (i_etb_ubs.groupby('ticker')['ubs_off_rmb'].shift(3) == 0) \
     & (i_etb_ubs.groupby('ticker')['ubs_off_rmb'].shift(4) == 0) \
     & (i_etb_ubs.groupby('ticker')['ubs_off_rmb'].shift(5) == 0)
i_etb_ubs.loc[((i_etb_ubs['ubs_off_rmb'] / i_etb_ubs['avgPV'] > 0.05) | (i_etb_ubs['ubs_off_rmb']>5e6)) & c1, 'flg_ubs_appear3'] = 1


i_etb_ubs = i_etb_ubs[['ticker','datadate_p1d','flg_ubs_appear3']]




#------------------------------------------------------------------------------
### combine
#------------------------------------------------------------------------------



icom = i_etb_gs.merge(i_o2o,  on = ['datadate_p1d','ticker'], how='left')
icom = icom.merge(i_etb_ms,  on = ['datadate_p1d','ticker'], how='left')
icom = icom.merge(i_etb_jpm,  on = ['d
atadate_p1d','ticker'], how='left')
icom = icom.merge(i_etb_baml,  on = ['datadate_p1d','ticker'], how='left')
icom = icom.merge(i_etb_ubs,  on = ['datadate_p1d','ticker'], how='left')


icom = icom.merge(i_td, on = 'datadate_p1d', how = 'left')
icom = icom.merge(i_c[['ticker', 'datadate', 'c_hlidx']],  on = ['datadate','ticker'], how='left')
icom = icom.merge(i_300500, on = ['ticker', 'datadate'], how = 'left')
icom['cn_index'] = icom['cn_index'].replace('NaN', np.nan)
icom = icom.merge(i_o2c, on = ['ticker', 'datadate'], how = 'left')

icom = icom.sort_values(['ticker', 'datadate_p1d'])


icom['sgnl_pulse_gs'] = np.nan
icom.loc[(icom['flg_gs_appear3']==1)&(icom['o2c_ma20d']<0)&(icom['c_hlidx']>0.5)&(icom['o2c']<0), 'sgnl_pulse_gs'] = 1
o_1 = bt_wr(icom[icom.cn_index.notnull()], 'datadate_p1d', 'sgnl_pulse_gs', 'o2oret+0d') #4.04 / 3.24 ###!!!

icom['sgnl_pulse_gs'] = np.nan
icom.loc[(icom['flg_gs_appear3']==1)&(icom['o2c_ma20d']<-0.005), 'sgnl_pulse_gs'] = 1
o_1 = bt_wr(icom[icom.cn_index.notnull()], 'datadate_p1d', 'sgnl_pulse_gs', 'o2oret+0d') 
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_pulse_gs', 'o2oret+0d') 

icom['sgnl_pulse_ms'] = np.nan
icom.loc[(icom['flg_ms_appear3']==1)&(icom['o2c_ma20d']<0)&(icom['c_hlidx']>0.5)&(icom['o2c']<0), 'sgnl_pulse_ms'] = 1
o_1 = bt_wr(icom[icom.cn_index.notnull()], 'datadate_p1d', 'sgnl_pulse_ms', 'o2oret+0d') 

icom['sgnl_pulse_ms'] = np.nan
icom.loc[(icom['flg_ms_appear3']==1)&(icom['o2c_ma20d']<-0.005), 'sgnl_pulse_ms'] = 1
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_pulse_ms', 'o2oret+0d') 

icom['sgnl_pulse_jpm'] = np.nan
icom.loc[(icom['flg_jpm_appear3']==1)&(icom['o2c_ma20d']<0)&(icom['c_hlidx']>0.5)&(icom['o2c']<0), 'sgnl_pulse_jpm'] = 1
o_1 = bt_wr(icom[icom.cn_index.notnull()], 'datadate_p1d', 'sgnl_pulse_jpm', 'o2oret+0d') 

icom['sgnl_pulse_jpm'] = np.nan
icom.loc[(icom['flg_jpm_appear3']==1)&(icom['o2c_ma20d']<-0.005), 'sgnl_pulse_jpm'] = 1
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_pulse_jpm', 'o2oret+0d') 

icom['sgnl_pulse_baml'] = np.nan
icom.loc[(icom['flg_baml_appear3']==1)&(icom['o2c_ma20d']<-0.002), 'sgnl_pulse_baml'] = 1
o_1 = bt_wr(icom[icom.cn_index.notnull()], 'datadate_p1d', 'sgnl_pulse_baml', 'o2oret+0d') # negative

icom['sgnl_pulse_baml'] = np.nan
icom.loc[(icom['flg_baml_appear3']==1)&(icom['o2c_ma20d']<-0.005), 'sgnl_pulse_baml'] = 1
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_pulse_baml', 'o2oret+0d')

icom['sgnl_pulse_ubs'] = np.nan
icom.loc[(icom['flg_ubs_appear3']==1)&(icom['o2c_ma20d']<-0.002),
 'sgnl_pulse_ubs'] = 1
o_1 = bt_wr(icom[icom.cn_index.notnull()], 'datadate_p1d', 'sgnl_pulse_ubs', 'o2oret+0d') # negative

icom['sgnl_pulse_ubs'] = np.nan
icom.loc[(icom['flg_ubs_appear3']==1)&(icom['o2c_ma20d']<-0.005), 'sgnl_pulse_ubs'] = 1
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_pulse_ubs', 'o2oret+0d') 

icom['sgnl_pulse_all'] = icom[['sgnl_pulse_gs','sgnl_pulse_ms','sgnl_pulse_jpm']].sum(axis=1, skipna=True)
icom.loc[icom['sgnl_pulse_all']>1,'sgnl_pulse_all'] = 1
o_1 = bt_wr(icom[icom.cn_index.notnull()], 'datadate_p1d', 'sgnl_pulse_all', 'o2oret+0d') 
o_1 = bt_wr(icom, 'datadate_p1d', 'sgnl_pulse_all', 'o2oret+0d') # 2.61 / 1.8





