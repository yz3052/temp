﻿#$%^&* pFlow_cn_hk_02.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 16 08:24:06 2021

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import os
import datetime


# this studies shortable shares (from mlp + wind)
# this studies rate at the bottom


### sd 

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['ticker', 'datadate'])
i_sd['V_t30d'] = i_sd.groupby('ticker').rolling(30)['V_l1d'].mean().values

i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d','V_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d','a50_300_flag','a50_flag','csi300_flag']]

i_sd_map_300 =i_sd_map[i_sd_map['csi300_flag']==1]



### 
i_h = yu.get_sql('''
           select a.s_info_windcode as ticker, a.trade_dt as datadate,
           a.s_quantity as held_shares, a.s_ratio as pct_ofComp,
           b.s_dq_close as c 
           from wind.dbo.SHSCChannelholdings a 
           left join wind.dbo.AShareEODPrices b
           on a.s_info_windcode=b.s_info_windcode and a.trade_dt=b.trade_dt
           where a.s_info_windcode not like '%HK'
           ''')
i_h['datadate'] = pd.to_datetime(i_h['datadate'], format='%Y%m%d')
i_h = i_h.sort_values(['ticker','datadate'])
i_h['c'] = i_h.groupby('ticker')['c'].ffill()

i_h['pct_ofComp_1d'] = i_h.groupby('ticker')['pct_ofComp'].shift()
i_h['pct_ofComp_df'] = i_h['pct_ofComp'] - i_h['pct_ofComp_1d']
i_h['pct_ofComp_df_allrk'] = i_h.groupby('datadate')['pct_ofComp_df'].apply(yu.uniformed_rank).values

i_h['pct_ofComp_20d'] = i_h.groupby('ticker')['pct_ofComp'].shift(20)
i_h['pct_ofComp_df20d'] = i_h['pct_ofComp'] - i_h['pct_ofComp_20d']
i_h['pct_ofComp_df20d_ma20'] = i_h.groupby('ticker').rolling(20)['pct_ofComp_df20d'].mean().values
i_h['pct_ofComp_df20d_ma10'] = i_h.groupby('ticker').rolling(10)['pct_ofComp_df20d'].mean().values
i_h['pct_ofComp_df20d_ma5'] = i_h.groupby('ticker').rolling(5)['pct_ofComp_df20d'].mean().values

i_h['pct_ofComp_60d'] = i_h.groupby('ticker')['pct_ofComp'].shift(60)
i_h['pct_ofComp_df60d'] = i_h['pct_ofComp'] - i_h['pct_ofComp_60d']
i_h['pct_ofComp_df60d_ma20'] = i_h.groupby('ticker').rolling(20)['pct_ofComp_df60d'].mean().values
i_h['pct_ofComp_df60d_ma10'] = i_h.groupby('ticker').rolling(10)['pct_ofComp_df60d'].mean().values
i_h['pct_ofComp_df60
d_ma5'] = i_h.groupby('ticker').rolling(5)['pct_ofComp_df60d'].mean().values


i_h['pct_ofComp_df1d'] = i_h['pct_ofComp'] - i_h['pct_ofComp_1d']

i_h['held_shares_1d'] = i_h.groupby('ticker')['held_shares'].shift()
i_h['held_shares_df'] = i_h['held_shares'] - i_h['held_shares_1d']

i_h['heldDollar'] = i_h['held_shares'].multiply(i_h['c'])
i_h['pct_within_HKall'] = i_h.groupby('datadate')['heldDollar'].apply(lambda x: x/x.sum())

i_h['est_float_so'] = i_h['held_shares'].divide(i_h['pct_ofComp'])*100

### rate

i_rate = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pWIND_util_prepare_shortable_limit.parquet')


### ETB

i_etb = yu.get_sql('''select * from CNDB.dbo.CN_ETBList_ABC''')
i_etb = i_etb.rename(columns = {'Ticker':'ticker', 'DataDate':'datadate_p1d','Avail_Amount_sum':'etb_ss'})

c_sh = i_etb['ticker'].str[0].isin(['6'])
c_sz = i_etb['ticker'].str[0].isin(['0', '3'])
i_etb.loc[c_sh, 'ticker'] = i_etb.loc[c_sh, 'ticker'] + '.SH'
i_etb.loc[c_sz, 'ticker'] = i_etb.loc[c_sz, 'ticker'] + '.SZ'

i_etb = i_etb.sort_values(['ticker', 'datadate_p1d'])
i_etb['etb_ss_t5d'] = i_etb.groupby('ticker').rolling(5)['etb_ss'].mean().values
i_etb['etb_ss_t10d'] = i_etb.groupby('ticker').rolling(10)['etb_ss'].mean().values

i_etb['etb_ss_std_t5d'] = i_etb.groupby('ticker').rolling(5)['etb_ss'].std().values
i_etb['etb_ss_std_t10d'] = i_etb.groupby('ticker').rolling(10)['etb_ss'].std().values

i_etb['etb_ss_df5d'] = i_etb.groupby('ticker')['etb_ss'].apply(lambda x: x-x.shift(5)).values
i_etb['etb_ss_df20d'] = i_etb.groupby('ticker')['etb_ss'].apply(lambda x: x-x.shift(20)).values


### short sell amount

i_ss = yu.get_sql('''
select S_INFO_WINDCODE as ticker, trade_dt as datadate, 
SHORT_SELL_STOCKS_MAX as north_ss_max, SHORT_SELL_STOCKS_BALANCE as north_ss 
 from wind.dbo.SHSCShortselling
''')
i_ss['datadate'] = pd.to_datetime(i_ss['datadate'], format= '%Y%m%d')
i_ss = i_ss.sort_values(['ticker','datadate'])

i_ss['north_ss_t5d'] = i_ss.groupby('ticker').rolling(5)['north_ss'].mean().values
i_ss['north_ss_t10d'] = i_ss.groupby('ticker').rolling(10)['north_ss'].mean().values

i_ss['north_ss_std_t5d'] = i_ss.groupby('ticker').rolling(5)['north_ss'].std().values
i_ss['north_ss_std_t10d'] = i_ss.groupby('ticker').rolling(10)['north_ss'].std().values

i_ss['north_ss_df5d'] = i_ss.groupby('ticker')['north_ss'].apply(lambda x: x-x.shift(5)).values
i_ss['north_ss_df20d'] = i_ss.groupby('ticker')['north_ss'].apply(lambda x: x-x.shift(20)).values


### indicative shortable amou
nt

i_indicative = pw.get_shortable_amount()
i_indicative = i_indicative.rename(columns={'shortable_shares':'mlp_ss', 'shortable_mc_rmb':'mlp_smc', 'shortable_shares_topPB':'mlpTop_ss'})
i_indicative = i_indicative.sort_values(['ticker','datadate'])
i_indicative['mlp_ss_t5d'] = i_indicative.groupby('ticker').rolling(5)['mlp_ss'].mean().values
i_indicative['mlp_ss_t10d'] = i_indicative.groupby('ticker').rolling(10)['mlp_ss'].mean().values

i_indicative['mlpTop_ss_t5d'] = i_indicative.groupby('ticker').rolling(5)['mlpTop_ss'].mean().values
i_indicative['mlpTop_ss_t10d'] = i_indicative.groupby('ticker').rolling(10)['mlpTop_ss'].mean().values

i_indicative['mlp_ss_std_t5d'] = i_indicative.groupby('ticker').rolling(5)['mlp_ss'].std().values
i_indicative['mlp_ss_std_t10d'] = i_indicative.groupby('ticker').rolling(10)['mlp_ss'].std().values

i_indicative['mlp_ss_df5d'] = i_indicative.groupby('ticker')['mlp_ss'].apply(lambda x: x-x.shift(5)).values
i_indicative['mlp_ss_df20d'] = i_indicative.groupby('ticker')['mlp_ss'].apply(lambda x: x-x.shift(20)).values



### |------
### combine

icom = i_sd.merge(i_ss, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_etb, on = ['ticker', 'datadate_p1d'], how = 'left')
icom = icom.merge(i_h, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_indicative, on = ['ticker', 'datadate'], how = 'left')


icom = icom.sort_values(['ticker', 'datadate'])




### north_ss / SO


icom['north_ss_dv_so'] = icom['north_ss'].divide(icom['est_float_so'])
icom['north_ss_dv_so_rk'] = icom.groupby('datadate')['north_ss_dv_so'].apply(yu.uniformed_rank).values
icom['north_ss_dv_so_bk'] = icom.groupby('datadate')['north_ss_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['north_ss_dv_so_5bk'] = icom.groupby('datadate')['north_ss_dv_so'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom, ['north_ss_dv_so_bk'], 'north_ss_dv_so') # -6 +3 +1
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['north_ss_dv_so_rk']>0)].\
            dropna(subset=['north_ss_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'north_ss_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.99/2.48, 1.98bp/d, 1.2e7


icom['north_ss_t5d_dv_so'] = icom['north_ss_t5d'].divide(icom['est_float_so'])
icom['north_ss_t5d_dv_so_rk'] = icom.groupby('datadate')['north_ss_t5d_dv_so'].apply(yu.uniformed_rank).values
icom['north_ss_t5d_dv_so_bk'] = icom.groupby('datadate')['north_
ss_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['north_ss_t5d_dv_so_5bk'] = icom.groupby('datadate')['north_ss_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom, ['north_ss_t5d_dv_so_bk'], 'north_ss_t5d_dv_so') # -5 +3 +1
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['north_ss_t5d_dv_so_rk']>0)].\
            dropna(subset=['north_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'north_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.89/2.52, 2.01bp/d, 1.2e7



### mlp_ss / SO


icom['mlp_ss_dv_so'] = icom['mlp_ss'].divide(icom['est_float_so'])
icom['mlp_ss_dv_so_rk'] = icom.groupby('datadate')['mlp_ss_dv_so'].apply(yu.uniformed_rank).values
icom['mlp_ss_dv_so_bk'] = icom.groupby('datadate')['mlp_ss_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['mlp_ss_dv_so_5bk'] = icom.groupby('datadate')['mlp_ss_dv_so'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom, ['mlp_ss_dv_so_bk'], 'mlp_ss_dv_so') # -7 +5 +3
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mlp_ss_dv_so_rk']>0)].\
            dropna(subset=['mlp_ss_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mlp_ss_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 4.28/1.88,1.46bp/d, 0.5e7


icom['mlp_ss_t5d_dv_so'] = icom['mlp_ss_t5d'].divide(icom['est_float_so'])
icom['mlp_ss_t5d_dv_so_rk'] = icom.groupby('datadate')['mlp_ss_t5d_dv_so'].apply(yu.uniformed_rank).values
icom['mlp_ss_t5d_dv_so_bk'] = icom.groupby('datadate')['mlp_ss_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['mlp_ss_t5d_dv_so_5bk'] = icom.groupby('datadate')['mlp_ss_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom, ['mlp_ss_t5d_dv_so_bk'], 'mlp_ss_t5d_dv_so') # -5 +3 +1
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mlp_ss_t5d_dv_so_rk']>0)].\
            dropna(subset=['mlp_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mlp_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.86/2.52, 1.97bp/d, 0.7e7


# gs + ms

icom['mlpTop_ss_t5d_dv_so'] = icom['mlpTop_ss_t5d'].divide(icom['est_float_so'])
icom['mlpTop_ss_t5d_dv_so_rk'] = icom.groupby('datadate')['mlpTop_ss_t5d_dv_so'].apply(yu.uniformed_rank).values
icom['mlpTop_ss_t5d_dv_so_bk'] = icom.groupby('datadate')['mlpTop_ss_t5d_dv_so'].a
pply(lambda x: yu.pdqcut(x,bins=10)).values
icom['mlpTop_ss_t5d_dv_so_5bk'] = icom.groupby('datadate')['mlpTop_ss_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom, ['mlpTop_ss_t5d_dv_so_bk'], 'mlpTop_ss_t5d_dv_so') # -5 +6 +4
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mlpTop_ss_t5d_dv_so_rk']>0)].\
            dropna(subset=['mlpTop_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mlpTop_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs  4.1 / 2.51, 1.99bp/s, 0.6e7






### max(mlp_ss, north_ss) / SO

icom['max_ss_t5d'] = icom[['mlp_ss_t5d','north_ss_t5d']].max(axis=1)
icom['max_ss_t5d_dv_so'] = icom['max_ss_t5d'].divide(icom['est_float_so'])
icom['max_ss_t5d_dv_so_rk'] = icom.groupby('datadate')['max_ss_t5d_dv_so'].apply(yu.uniformed_rank).values
icom['max_ss_t5d_dv_so_bk'] = icom.groupby('datadate')['max_ss_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['max_ss_t5d_dv_so_5bk'] = icom.groupby('datadate')['max_ss_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom, ['max_ss_t5d_dv_so_bk'], 'max_ss_t5d_dv_so')
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['max_ss_t5d_dv_so_rk']>0)].\
            dropna(subset=['max_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'max_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.51/2.8, 2.15bp/d, 1.5e7 ###!!!


### max(etb_ss, north_ss) / SO

icom['maxETB_ss_t5d'] = icom[['etb_ss_t5d','north_ss_t5d']].max(axis=1)
icom['maxETB_ss_t5d_dv_so'] = icom['maxETB_ss_t5d'].divide(icom['est_float_so'])
icom['maxETB_ss_t5d_dv_so_rk'] = icom.groupby('datadate')['maxETB_ss_t5d_dv_so'].apply(yu.uniformed_rank).values
icom['maxETB_ss_t5d_dv_so_bk'] = icom.groupby('datadate')['maxETB_ss_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['maxETB_ss_t5d_dv_so_5bk'] = icom.groupby('datadate')['maxETB_ss_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom, ['maxETB_ss_t5d_dv_so_bk'], 'maxETB_ss_t5d_dv_so')
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['maxETB_ss_t5d_dv_so_rk']>0)].\
            dropna(subset=['maxETB_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'maxETB_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.58/2.92, 2.44bp/d, 1.5e7 ###!!!




### max(mlpTopPB_ss
, north_ss) / SO

icom['maxTop_ss_t5d'] = icom[['mlpTop_ss_t5d','north_ss_t5d']].max(axis=1)
icom['maxTop_ss_t5d_dv_so'] = icom['maxTop_ss_t5d'].divide(icom['est_float_so'])
icom['maxTop_ss_t5d_dv_so_rk'] = icom.groupby('datadate')['maxTop_ss_t5d_dv_so'].apply(yu.uniformed_rank).values
icom['maxTop_ss_t5d_dv_so_bk'] = icom.groupby('datadate')['maxTop_ss_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['maxTop_ss_t5d_dv_so_5bk'] = icom.groupby('datadate')['maxTop_ss_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom, ['maxTop_ss_t5d_dv_so_bk'], 'maxTop_ss_t5d_dv_so')
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['maxTop_ss_t5d_dv_so_rk']>0)].\
            dropna(subset=['maxTop_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'maxTop_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.51/2.8, 2.15bp/d, 1.5e7 ###!!!




### (mlp_ss - north_ss) / SO

icom['ss_mlp_m_north_t5d'] = icom['mlp_ss_t5d'] - icom['north_ss_t5d']
icom['ss_mlp_m_north_t5d_dv_so'] = icom['ss_mlp_m_north_t5d'].divide(icom['est_float_so'])
icom['ss_mlp_m_north_t5d_dv_so_rk'] = icom.groupby('datadate')['ss_mlp_m_north_t5d_dv_so'].apply(yu.uniformed_rank).values
icom['ss_mlp_m_north_t5d_dv_so_bk'] = icom.groupby('datadate')['ss_mlp_m_north_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ss_mlp_m_north_t5d_dv_so_5bk'] = icom.groupby('datadate')['ss_mlp_m_north_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom, ['ss_mlp_m_north_t5d_dv_so_bk'], 'ss_mlp_m_north_t5d_dv_so')
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['ss_mlp_m_north_t5d_dv_so_rk']>0)].\
            dropna(subset=['ss_mlp_m_north_t5d_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ss_mlp_m_north_t5d_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.2/2.18, 2.14bp/d, 0.5e7



### mlp df & sd


icom['mlp_ss_df5d_dv_so'] = icom['mlp_ss_df5d'].divide(icom['est_float_so'])
icom['mlp_ss_df5d_dv_so_abs'] = icom['mlp_ss_df5d_dv_so'].abs()
icom['mlp_ss_df5d_dv_so_bk'] = icom.groupby('datadate')['mlp_ss_df5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=20)).values
icom['mlp_ss_df5d_dv_so_abs_bk'] = icom.groupby('datadate')['mlp_ss_df5d_dv_so_abs'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['mlp_ss_df5d_dv_so_abs_rk'] = icom.groupby('datadate')['mlp_ss_df5d_dv_so_abs'].apply(yu.uniformed_rank).values


yu.create_cn_3x3(icom, ['mlp_ss_df5d_dv_so_abs_bk'], 'mlp_ss_df5d_dv_so_abs') # -4,+4
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mlp_ss_df5d_dv_so_abs_rk']>0)].\
            dropna(subset=['mlp_ss_df5d_dv_so_abs_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mlp_ss_df5d_dv_so_abs_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 4.44 / -2.99


icom['mlp_ss_std_t5d_dv_so'] = icom['mlp_ss_std_t5d'].divide(icom['est_float_so'])
icom['mlp_ss_std_t10d_dv_so'] = icom['mlp_ss_std_t10d'].divide(icom['est_float_so'])
icom['mlp_ss_std_t5d_dv_so_rk'] = icom.groupby('datadate')['mlp_ss_std_t5d_dv_so'].apply(yu.uniformed_rank).values
icom['mlp_ss_std_t10d_dv_so_rk'] = icom.groupby('datadate')['mlp_ss_std_t10d_dv_so'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mlp_ss_std_t5d_dv_so_rk']>0)].\
            dropna(subset=['mlp_ss_std_t5d_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mlp_ss_std_t5d_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 4.34/-0.63
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['mlp_ss_std_t10d_dv_so_rk']>0)].\
            dropna(subset=['mlp_ss_std_t10d_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'mlp_ss_std_t10d_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 4.16/1.63


### north df & sd

icom['north_ss_df5d_dv_so'] = icom['north_ss_df5d'].divide(icom['est_float_so'])
icom['north_ss_df5d_dv_so_abs'] = icom['north_ss_df5d_dv_so'].abs()
icom['north_ss_df5d_dv_so_bk'] = icom.groupby('datadate')['north_ss_df5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=20)).values
icom['north_ss_df5d_dv_so_abs_bk'] = icom.groupby('datadate')['north_ss_df5d_dv_so_abs'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['north_ss_df5d_dv_so_abs_rk'] = icom.groupby('datadate')['north_ss_df5d_dv_so_abs'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icom, ['north_ss_df5d_dv_so_abs_bk'], 'north_ss_df5d_dv_so_abs') # -3, +3
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['north_ss_df5d_dv_so_abs_rk']>0)].\
            dropna(subset=['north_ss_df5d_dv_so_abs_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'north_ss_df5d_dv_so_abs_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.36/ -3.5


icom['north_ss_std_t5d_dv_so'] = icom['north_ss_std_t5d'].divide(icom['est_float
_so'])
icom['north_ss_std_t10d_dv_so'] = icom['north_ss_std_t10d'].divide(icom['est_float_so'])
icom['north_ss_std_t5d_dv_so_rk'] = icom.groupby('datadate')['north_ss_std_t5d_dv_so'].apply(yu.uniformed_rank).values
icom['north_ss_std_t10d_dv_so_rk'] = icom.groupby('datadate')['north_ss_std_t10d_dv_so'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['north_ss_std_t5d_dv_so_rk']>0)].\
            dropna(subset=['north_ss_std_t5d_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'north_ss_std_t5d_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.41 / -0.81
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['north_ss_std_t10d_dv_so_rk']>0)].\
            dropna(subset=['north_ss_std_t10d_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'north_ss_std_t10d_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.51 / 0.52





### std ( max(mlp_ss, north_ss) / SO )

icom['max_ss'] = icom[['mlp_ss','north_ss']].max(axis=1)
icom['max_ss_std_t5d'] = icom.groupby('ticker').rolling(5)['max_ss'].std().values
icom['max_ss_std_t5d_dv_so'] = icom['max_ss_std_t5d'].divide(icom['est_float_so'])
icom['max_ss_std_t5d_dv_so_rk'] = icom.groupby('datadate')['max_ss_std_t5d_dv_so'].apply(yu.uniformed_rank).values
icom['max_ss_std_t5d_dv_so_bk'] = icom.groupby('datadate')['max_ss_std_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['max_ss_std_t5d_dv_so_5bk'] = icom.groupby('datadate')['max_ss_std_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom, ['max_ss_std_t5d_dv_so_bk'], 'max_ss_std_t5d_dv_so') # mono: -6.7, +4.5
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['max_ss_std_t5d_dv_so_rk']>0)].\
            dropna(subset=['max_ss_std_t5d_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'max_ss_std_t5d_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 4.01/0.39


icom['max_ss_std_t20d'] = icom.groupby('ticker').rolling(20)['max_ss'].std().values
icom['max_ss_std_t20d_dv_so'] = icom['max_ss_std_t20d'].divide(icom['est_float_so'])
icom['max_ss_std_t20d_dv_so_rk'] = icom.groupby('datadate')['max_ss_std_t20d_dv_so'].apply(yu.uniformed_rank).values
icom['max_ss_std_t20d_dv_so_bk'] = icom.groupby('datadate')['max_ss_std_t20d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['max_ss_std_t20d_dv_so_5bk'] = icom.gr
oupby('datadate')['max_ss_std_t20d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=5)).values

yu.create_cn_3x3(icom, ['max_ss_std_t20d_dv_so_bk'], 'max_ss_std_t20d_dv_so')
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['max_ss_std_t20d_dv_so_rk']>0)].\
            dropna(subset=['max_ss_std_t20d_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'max_ss_std_t20d_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.9 / 1.94, 1.66bp/d, 1e7






### combine std and ss

icom['max_ss'] = icom[['mlp_ss','north_ss']].max(axis=1)
icom['max_ss_std_t20d'] = icom.groupby('ticker').rolling(20)['max_ss'].std().values
icom['max_ss_std_t20d_dv_so'] = icom['max_ss_std_t20d'].divide(icom['est_float_so'])
icom['max_ss_std_t20d_dv_so_rk'] = icom.groupby('datadate')['max_ss_std_t20d_dv_so'].apply(yu.uniformed_rank).values
icom['max_ss_std_t20d_dv_so_01rk'] = icom.groupby('datadate')['max_ss_std_t20d_dv_so'].apply(lambda x: x.rank()/x.count()).values

icom['max_ss_t5d'] = icom[['mlp_ss_t5d','north_ss_t5d']].max(axis=1)
icom['max_ss_t5d_dv_so'] = icom['max_ss_t5d'].divide(icom['est_float_so'])
icom['max_ss_t5d_dv_so_rk'] = icom.groupby('datadate')['max_ss_t5d_dv_so'].apply(yu.uniformed_rank).values
icom['max_ss_t5d_dv_so_5bk'] = icom.groupby('datadate')['max_ss_t5d_dv_so'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom['max_ss_p_std'] = icom['max_ss_std_t20d_dv_so_rk'] + icom['max_ss_t5d_dv_so_rk']
icom['max_ss_p_std_rk'] = icom.groupby('datadate')['max_ss_p_std'].apply(yu.uniformed_rank).values
icom['max_ss_p_std_bk'] = icom.groupby('datadate')['max_ss_p_std'].apply(lambda x: yu.pdqcut(x,bins=10)).values


yu.create_cn_3x3(icom[icom['max_ss_std_t20d_dv_so_rk']<-0.5], ['max_ss_t5d_dv_so_5bk'], 'max_ss_t5d_dv_so')
yu.create_cn_3x3(icom[icom['max_ss_std_t20d_dv_so_rk']<-0.5], ['max_ss_t5d_dv_so_5bk'], 'max_ss_t5d_dv_so')
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['max_ss_p_std_rk']>0)].\
            dropna(subset=['max_ss_p_std_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'max_ss_p_std_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.26/2.45, 2.07bp/d
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['max_ss_t5d_dv_so_rk']>0)&(icom['max_ss_std_t20d_dv_so_rk']>-0.9)].\
            dropna(subset=['max_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'max_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d'
, static_data = i_sd) #prcs 3.3/2.53, 2.04, 1.25e7
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['max_ss_t5d_dv_so_rk']>0)].\
            dropna(subset=['max_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'max_ss_t5d_dv_so_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.51/2.8, 2.15bp/d,1.5e7



icom['max_ss_x_std'] = icom['max_ss_std_t20d_dv_so_rk'].multiply(icom['max_ss_t5d_dv_so_rk'])
icom['max_ss_x_std_rk'] = icom.groupby('datadate')['max_ss_x_std'].apply(yu.uniformed_rank).values
icom['max_ss_x_std_bk'] = icom.groupby('datadate')['max_ss_x_std'].apply(lambda x: yu.pdqcut(x,bins=10)).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['max_ss_x_std_rk']>0)].\
            dropna(subset=['max_ss_x_std_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'max_ss_x_std_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.18/-0.11


icom['max_ss_x_01std'] = icom['max_ss_std_t20d_dv_so_01rk'].multiply(icom['max_ss_t5d_dv_so_rk'])
icom['max_ss_x_01std_rk'] = icom.groupby('datadate')['max_ss_x_01std'].apply(yu.uniformed_rank).values
icom['max_ss_x_01std_bk'] = icom.groupby('datadate')['max_ss_x_01std'].apply(lambda x: yu.pdqcut(x,bins=10)).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['max_ss_x_01std_rk']>0)].\
            dropna(subset=['max_ss_x_01std_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'max_ss_x_01std_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.24/2.47, 2.07bp/d, 1.25e7




### rate

icom['wrate_rk'] = icom.groupby('datadate')['wRate'].apply(yu.uniformed_rank).values
icom['wrate_bk'] = icom.groupby('datadate')['wRate'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['wrate_bk'], 'wRate') # +1 +2 -3


icom['minrate_rk'] = icom.groupby('datadate')['Rate_min'].apply(yu.uniformed_rank).values
icom['minrate_bk'] = icom.groupby('datadate')['Rate_min'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['minrate_bk'], 'Rate_min') # +1 +3 -2


icom['minrate_df5d'] = icom.groupby('ticker')['Rate_min'].apply(lambda x: x-x.shift(5)).values
icom['minrate_df5d_bk'] = icom.groupby('datadate')['minrate_df5d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['minrate_df5d_bk'], 'minrate_df5d') # +2 +4 -1

icom['minrate_df20d'] = icom.groupby('ticker')['Rate_min'].apply(lambda x: x-x.shift(20)).values
i
com['minrate_df20d_bk'] = icom.groupby('datadate')['minrate_df20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['minrate_df20d_rk'] = icom.groupby('datadate')['minrate_df20d'].apply(yu.uniformed_rank).values
icom['minrate_df20d_sgnl'] = - icom['minrate_df20d_rk']
c1 = icom['minrate_df20d_sgnl'].abs()>0.8
icom.loc[c1, 'minrate_df20d_extrm_sgnl'] = icom.loc[c1, 'minrate_df20d_sgnl']
icom['minrate_df20d_extrm_sgnl'] = icom.groupby('datadate')['minrate_df20d_extrm_sgnl'].ffill(limit=10)
yu.create_cn_3x3(icom, ['minrate_df20d_bk'], 'minrate_df20d') # +2 +5 -3

icom['wrate_df5d'] = icom.groupby('ticker')['wRate'].apply(lambda x: x-x.shift(5)).values
icom['wrate_df5d_bk'] = icom.groupby('datadate')['wrate_df5d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['wrate_df5d_bk'], 'wrate_df5d') # random

icom['wrate_df20d'] = icom.groupby('ticker')['wRate'].apply(lambda x: x-x.shift(20)).values
icom['wrate_df20d_bk'] = icom.groupby('datadate')['wrate_df20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['wrate_df20d_bk'], 'wrate_df20d') # random

icom['maxrate_df20d'] = icom.groupby('ticker')['Rate_max'].apply(lambda x: x-x.shift(20)).values
icom['maxrate_df20d_bk'] = icom.groupby('datadate')['maxrate_df20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['maxrate_df20d_bk'], 'maxrate_df20d') # random

icom['wrate_t20d'] = icom.groupby('ticker').rolling(20)['wRate'].mean().values
icom['wrate_t60d'] = icom.groupby('ticker').rolling(60)['wRate'].mean().values
icom['wrate_t20d_dv_t60d'] = icom['wrate_t20d'].divide(icom['wrate_t60d'])
icom['wrate_t20d_dv_t60d_rk'] = icom.groupby('datadate')['wrate_t20d_dv_t60d'].apply(yu.uniformed_rank).values
icom['wrate_t20d_dv_t60d_bk'] = icom.groupby('datadate')['wrate_t20d_dv_t60d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['wrate_t20d_dv_t60d_bk'], 'wrate_t20d_dv_t60d') # random


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')].\
            dropna(subset=['minrate_df20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'minrate_df20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2019-12-31')&(icom['minrate_df20d_sgnl']>0)].\
            dropna(subset=['minrate_df20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'minrate_df20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 2.34/-6.29




