﻿#$%^&* pSandalWood_cn_ecom_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 21 12:15:44 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu


### sd 

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])


#------------------------------------------------------------------------------
### consumer credit card 
#------------------------------------------------------------------------------



i_consumer_tx = pd.read_csv(r'Z:\164947\DATA-13470\Consumer_Transaction_New\SWA_File55468_China_Payment_All_In_Payment_and_POS_Company_Daily_Data_Up_To_31_Jul_2022_20221107.csv', encoding='latin')
i_consumer_tx = i_consumer_tx[i_consumer_tx['Ticker'].notnull() & i_consumer_tx['Ticker'].fillna('').str.contains(' CH ')]
i_consumer_tx['ticker'] = i_consumer_tx['Ticker'].str[:6]
c_sh = i_consumer_tx['ticker'].str[0].isin(['6'])
c_sz = i_consumer_tx['ticker'].str[0].isin(['0','3'])
i_consumer_tx.loc[c_sh, 'ticker'] = i_consumer_tx.loc[c_sh, 'ticker'] + '.SH'
i_consumer_tx.loc[c_sz, 'ticker'] = i_consumer_tx.loc[c_sz, 'ticker'] + '.SZ'

i_consumer_tx['End Date'] = pd.to_datetime(i_consumer_tx['End Date'])


# TMALL - daily trailing 1y value
o_tx_t1y = []
for dt in pd.date_range(start='2019-07-01', end = '2021-12-31'):
    print(dt.strftime('%Y%m%d'),end=',')
    
    t_tx = i_consumer_tx[i_consumer_tx['End Date'].le(dt-pd.to_timedelta('7 days')) \
                      & i_consumer_tx['End Date'].ge(dt-pd.to_timedelta('372 days'))]
            
    # trailing 1y stats
    s_tx_t1y = t_tx.groupby('ticker')['Value'].sum().reset_index()
    s_tx_t1y.columns = ['ticker', 'value_tx_t1y']
    s_tx_t1y['datadate'] = dt
    
    o_tx_t1y.append(s_tx_t1y)
o_tx_t1y = pd.concat(o_tx_t1y, axis = 0)


o_tx_t1y['datadate_1y'] = o_tx_t1y['datadate'] - pd.to_timedelta('365 days')
o_tx_t1y = o_tx_t1y.merge(o_tx_t1y[['datadate', 'ticker', 'value_tx_t1y']]\
                                .rename(columns={'datadate':'datadate_1y'}),
                                on = ['datadate_1y', 'ticker'], how = 'left', suffixes=['','_1y'])
o_tx_t1y['value_tx_yoy'] = o_tx_t1y['value_tx_t1y'] / o_tx_t1y['value_tx_t1y_1y']

o_tx_t1y['datadate_1q'] = o_tx_t1y['datadate'] - pd.to_timedelta('91 days')
o_tx_t1y = o_tx_t1y.merge(o_tx_t1y[['datadate', 'ticker', 'value_tx_t1y']]\
                                .rename(columns={'datadate':'datadate_1q'}),
                                on = ['datadate_1q', 'ticker'], how = '
left', suffixes=['','_1q'])
o_tx_t1y['value_tx_qoq'] = o_tx_t1y['value_tx_t1y'] / o_tx_t1y['value_tx_t1y_1q']

# backtest

icom = i_sd.merge(o_tx_t1y, on = ['ticker', 'datadate'], how = 'left')

icom['value_tx_yoy_rk'] = icom.groupby('datadate')['value_tx_yoy'].apply(yu.uniformed_rank)
icom['value_tx_qoq_rk'] = icom.groupby('datadate')['value_tx_qoq'].apply(yu.uniformed_rank)

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2020-01-01','2021-12-30')].\
        dropna(subset=['value_tx_yoy_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
        'value_tx_yoy_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)  # -0.41 / -0.49 / -1.03

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2020-01-01','2021-12-30')].\
        dropna(subset=['value_tx_qoq_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
        'value_tx_qoq_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.35 / 0.19 / -0.41







#------------------------------------------------------------------------------
### TMALL 
#------------------------------------------------------------------------------


i_tmall = pd.read_csv(r"Z:\164947\DATA-13471\E_Commerce\Tmall\SWA_File55469_Tmall_All_In_Ecommerce_Company_Weekly_Data_Up_To_31_Jul_2022_20221107.csv", encoding='latin')
i_tmall = i_tmall[i_tmall['Ticker'].notnull() & i_tmall['Ticker'].fillna('').str.contains(' CH ')]
i_tmall['ticker'] = i_tmall['Ticker'].str[:6]
c_sh = i_tmall['ticker'].str[0].isin(['6'])
c_sz = i_tmall['ticker'].str[0].isin(['0','3'])
i_tmall.loc[c_sh, 'ticker'] = i_tmall.loc[c_sh, 'ticker'] + '.SH'
i_tmall.loc[c_sz, 'ticker'] = i_tmall.loc[c_sz, 'ticker'] + '.SZ'

i_tmall.loc[i_tmall['Datetag']=='1-7', 'DatetagCode'] = 0
i_tmall.loc[i_tmall['Datetag']=='8-14', 'DatetagCode'] = 25
i_tmall.loc[i_tmall['Datetag']=='15-21', 'DatetagCode'] = 50
i_tmall.loc[i_tmall['Datetag']=='22-MonthEnd', 'DatetagCode'] = 75
i_tmall['PeriodCode'] = i_tmall['Year Month'] * 100 + i_tmall['DatetagCode']

i_tmall['End Date'] = pd.to_datetime(i_tmall['End Date'])



# TMALL - daily trailing 1y value



o_tmall_t1y = []
for dt in pd.date_range(start='2019-07-01', end = '2021-12-31'):
    print(dt.strftime('%Y%m%d'),end=',')
    
    t_tmall = i_tmall[i_tmall['End Date'].le(dt-pd.to_timedelta('7 days')) \
                      & i_tmall['End Date'].ge(dt-pd.to_timedelta('30 days'))]
        
    # trailing 1y data
    s_tmall_minmax_period = t_tmall.groupby('ticker')['PeriodCode'].max().reset_index()
    s_tm
all_minmax_period['PeriodCodeMin'] = s_tmall_minmax_period['PeriodCode']-10000+25     
    t_tmall = t_tmall.merge(s_tmall_minmax_period[['ticker','PeriodCodeMin']], on = 'ticker', how = 'left')
    t_tmall = t_tmall[t_tmall['PeriodCode']>=t_tmall['PeriodCodeMin']]
    
    # trailing 1y stats
    s_tmall_t1y = t_tmall.groupby('ticker')['Value'].sum().reset_index()
    s_tmall_t1y.columns = ['ticker', 'value_tmall_t1y']
    s_tmall_t1y['datadate'] = dt
    
    o_tmall_t1y.append(s_tmall_t1y)
o_tmall_t1y = pd.concat(o_tmall_t1y, axis = 0)


o_tmall_t1y['datadate_1y'] = o_tmall_t1y['datadate'] - pd.to_timedelta('365 days')
o_tmall_t1y = o_tmall_t1y.merge(o_tmall_t1y[['datadate', 'ticker', 'value_tmall_t1y']]\
                                .rename(columns={'datadate':'datadate_1y'}),
                                on = ['datadate_1y', 'ticker'], how = 'left', suffixes=['','_1y'])
o_tmall_t1y['value_tmall_yoy'] = o_tmall_t1y['value_tmall_t1y'] / o_tmall_t1y['value_tmall_t1y_1y']

o_tmall_t1y['datadate_1q'] = o_tmall_t1y['datadate'] - pd.to_timedelta('91 days')
o_tmall_t1y = o_tmall_t1y.merge(o_tmall_t1y[['datadate', 'ticker', 'value_tmall_t1y']]\
                                .rename(columns={'datadate':'datadate_1q'}),
                                on = ['datadate_1q', 'ticker'], how = 'left', suffixes=['','_1q'])
o_tmall_t1y['value_tmall_qoq'] = o_tmall_t1y['value_tmall_t1y'] / o_tmall_t1y['value_tmall_t1y_1q']

# backtest

icom = i_sd.merge(o_tmall_t1y, on = ['ticker', 'datadate'], how = 'left')

icom['value_tmall_yoy_rk'] = icom.groupby('datadate')['value_tmall_yoy'].apply(yu.uniformed_rank)
icom['value_tmall_qoq_rk'] = icom.groupby('datadate')['value_tmall_qoq'].apply(yu.uniformed_rank)

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2020-01-01','2021-12-30')].\
        dropna(subset=['value_tmall_yoy_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
        'value_tmall_yoy_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)  # 1.5 / 0.42 / -0.51, peak 2021.07

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2020-01-01','2021-12-30')].\
        dropna(subset=['value_tmall_qoq_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
        'value_tmall_qoq_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 0.25 / 0.53 / 1.43, peak 2021.01



#------------------------------------------------------------------------------
### Taobao
#-----------------------------------------------------------------------------
-


i_taobao = pd.read_csv(r"Z:\164947\DATA-13471\E_Commerce\Taobao\SWA_File55474_Taobao_All_In_Ecommerce_Company_Monthly_Data_Up_To_31_Jul_2022_20221107.csv", encoding='latin')

i_taobao = i_taobao[i_taobao['Ticker'].notnull() & i_taobao['Ticker'].fillna('').str.contains(' CH ')]
i_taobao['ticker'] = i_taobao['Ticker'].str[:6]
c_sh = i_taobao['ticker'].str[0].isin(['6'])
c_sz = i_taobao['ticker'].str[0].isin(['0','3'])
i_taobao.loc[c_sh, 'ticker'] = i_taobao.loc[c_sh, 'ticker'] + '.SH'
i_taobao.loc[c_sz, 'ticker'] = i_taobao.loc[c_sz, 'ticker'] + '.SZ'

i_taobao['End Date'] = pd.to_datetime(i_taobao['End Date'])



# TMALL - daily trailing 1y value



o_taobao_t1y = []
for dt in pd.date_range(start='2019-07-01', end = '2021-12-31'):
    print(dt.strftime('%Y%m%d'),end=',')
    
    t_taobao = i_taobao[i_taobao['End Date'].le(dt-pd.to_timedelta('7 days')) \
                      & i_taobao['End Date'].ge(dt-pd.to_timedelta('42 days'))]
        
    # trailing 1y data
    s_taobao_minmax_period = t_taobao.groupby('ticker')['Year Month'].max().reset_index()
    s_taobao_minmax_period['Year Month Min'] = s_taobao_minmax_period['Year Month']-100
    t_taobao = t_taobao.merge(s_taobao_minmax_period[['ticker','Year Month Min']], on = 'ticker', how = 'left')
    t_taobao = t_taobao[t_taobao['Year Month']>t_taobao['Year Month Min']]
    
    # trailing 1y stats
    s_taobao_t1y = t_taobao.groupby('ticker')['Value'].sum().reset_index()
    s_taobao_t1y.columns = ['ticker', 'value_taobao_t1y']
    s_taobao_t1y['datadate'] = dt
    
    o_taobao_t1y.append(s_taobao_t1y)
o_taobao_t1y = pd.concat(o_taobao_t1y, axis = 0)


o_taobao_t1y['datadate_1y'] = o_taobao_t1y['datadate'] - pd.to_timedelta('365 days')
o_taobao_t1y = o_taobao_t1y.merge(o_taobao_t1y[['datadate', 'ticker', 'value_taobao_t1y']]\
                                .rename(columns={'datadate':'datadate_1y'}),
                                on = ['datadate_1y', 'ticker'], how = 'left', suffixes=['','_1y'])
o_taobao_t1y['value_taobao_yoy'] = o_taobao_t1y['value_taobao_t1y'] / o_taobao_t1y['value_taobao_t1y_1y']

o_taobao_t1y['datadate_1q'] = o_taobao_t1y['datadate'] - pd.to_timedelta('91 days')
o_taobao_t1y = o_taobao_t1y.merge(o_taobao_t1y[['datadate', 'ticker', 'value_taobao_t1y']]\
                                .rename(columns={'datadate':'datadate_1q'}),
                                on = ['datadate_1q', 'ticker'], how = 'left', suffixes=['','_1q'])
o_taobao_t1y['value_taobao_qoq'] = o_taobao_t1y['va
lue_taobao_t1y'] / o_taobao_t1y['value_taobao_t1y_1q']

# backtest

icom = i_sd.merge(o_taobao_t1y, on = ['ticker', 'datadate'], how = 'left')

icom['value_taobao_yoy_rk'] = icom.groupby('datadate')['value_taobao_yoy'].apply(yu.uniformed_rank)
icom['value_taobao_qoq_rk'] = icom.groupby('datadate')['value_taobao_qoq'].apply(yu.uniformed_rank)

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2020-01-01','2021-12-30')].\
        dropna(subset=['value_taobao_yoy_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
        'value_taobao_yoy_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)  # 1.1 / 0.88 /0.19

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2020-01-01','2021-12-30')].\
        dropna(subset=['value_taobao_qoq_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
        'value_taobao_qoq_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # -0.65 / -1.15 / -2.17




#------------------------------------------------------------------------------
### JD
#------------------------------------------------------------------------------


i_jd = pd.read_csv(r"Z:\164947\DATA-13471\E_Commerce\JD\SWA_File55470_JD_All_In_Ecommerce_Company_Weekly_Data_Up_To_31_Jul_2022_20221107.csv", encoding='latin')
i_jd = i_jd[i_jd['Ticker'].notnull() & i_jd['Ticker'].fillna('').str.contains(' CH ')]
i_jd['ticker'] = i_jd['Ticker'].str[:6]
c_sh = i_jd['ticker'].str[0].isin(['6'])
c_sz = i_jd['ticker'].str[0].isin(['0','3'])
i_jd.loc[c_sh, 'ticker'] = i_jd.loc[c_sh, 'ticker'] + '.SH'
i_jd.loc[c_sz, 'ticker'] = i_jd.loc[c_sz, 'ticker'] + '.SZ'

i_jd.loc[i_jd['Datetag']=='1-7', 'DatetagCode'] = 0
i_jd.loc[i_jd['Datetag']=='8-14', 'DatetagCode'] = 25
i_jd.loc[i_jd['Datetag']=='15-21', 'DatetagCode'] = 50
i_jd.loc[i_jd['Datetag']=='22-MonthEnd', 'DatetagCode'] = 75
i_jd['PeriodCode'] = i_jd['Year Month'] * 100 + i_jd['DatetagCode']

i_jd['End Date'] = pd.to_datetime(i_jd['End Date'])



# TMALL - daily trailing 1y value



o_jd_t1y = []
for dt in pd.date_range(start='2018-07-01', end = '2021-12-31'):
    print(dt.strftime('%Y%m%d'),end=',')
    
    t_jd = i_jd[i_jd['End Date'].le(dt-pd.to_timedelta('7 days')) \
                      & i_jd['End Date'].ge(dt-pd.to_timedelta('30 days'))]
        
    # trailing 1y data
    s_jd_minmax_period = t_jd.groupby('ticker')['PeriodCode'].max().reset_index()
    s_jd_minmax_period['PeriodCodeMin'] = s_jd_minmax_period['PeriodCode']-10000+25     
    t_jd = t_jd.merge(s_jd_minmax_period[['ticker','P
eriodCodeMin']], on = 'ticker', how = 'left')
    t_jd = t_jd[t_jd['PeriodCode']>=t_jd['PeriodCodeMin']]
    
    # trailing 1y stats
    s_jd_t1y = t_jd.groupby('ticker')['Value'].sum().reset_index()
    s_jd_t1y.columns = ['ticker', 'value_jd_t1y']
    s_jd_t1y['datadate'] = dt
    
    o_jd_t1y.append(s_jd_t1y)
o_jd_t1y = pd.concat(o_jd_t1y, axis = 0)


o_jd_t1y['datadate_1y'] = o_jd_t1y['datadate'] - pd.to_timedelta('365 days')
o_jd_t1y = o_jd_t1y.merge(o_jd_t1y[['datadate', 'ticker', 'value_jd_t1y']]\
                                .rename(columns={'datadate':'datadate_1y'}),
                                on = ['datadate_1y', 'ticker'], how = 'left', suffixes=['','_1y'])
o_jd_t1y['value_jd_yoy'] = o_jd_t1y['value_jd_t1y'] / o_jd_t1y['value_jd_t1y_1y']

o_jd_t1y['datadate_1q'] = o_jd_t1y['datadate'] - pd.to_timedelta('91 days')
o_jd_t1y = o_jd_t1y.merge(o_jd_t1y[['datadate', 'ticker', 'value_jd_t1y']]\
                                .rename(columns={'datadate':'datadate_1q'}),
                                on = ['datadate_1q', 'ticker'], how = 'left', suffixes=['','_1q'])
o_jd_t1y['value_jd_qoq'] = o_jd_t1y['value_jd_t1y'] / o_jd_t1y['value_jd_t1y_1q']

# backtest

icom = i_sd.merge(o_jd_t1y, on = ['ticker', 'datadate'], how = 'left')

icom['value_jd_yoy_rk'] = icom.groupby('datadate')['value_jd_yoy'].apply(yu.uniformed_rank)
icom['value_jd_qoq_rk'] = icom.groupby('datadate')['value_jd_qoq'].apply(yu.uniformed_rank)
icom['value_jd_yoy_indrk'] = icom.groupby(['datadate','GIND'])['value_jd_yoy'].apply(yu.uniformed_rank)

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2019-01-01','2021-12-30')].\
        dropna(subset=['value_jd_yoy_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
        'value_jd_yoy_rk','BarrRet_CLIP_USD+1d', static_data = i_sd)  # 2.0 / 1.52 / 0.17, peak = 2021.07

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2019-01-01','2021-12-30')].\
        dropna(subset=['value_jd_yoy_indrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
        'value_jd_yoy_indrk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.05 / 0.45 / -0.45




#------------------------------------------------------------------------------
### JD (mkt share)
#------------------------------------------------------------------------------


i_jd = pd.read_csv(r"Z:\164947\DATA-13471\E_Commerce\JD\SWA_File55470_JD_All_In_Ecommerce_Company_Weekly_Data_Up_To_31_Jul_2022_20221107.csv", encoding='latin')

i_jd.loc[i_jd[
'Ticker'].isnull(), 'Ticker'] = i_jd.loc[i_jd['Ticker'].isnull(), 'Company']

i_jd.loc[i_jd['Datetag']=='1-7', 'DatetagCode'] = 0
i_jd.loc[i_jd['Datetag']=='8-14', 'DatetagCode'] = 25
i_jd.loc[i_jd['Datetag']=='15-21', 'DatetagCode'] = 50
i_jd.loc[i_jd['Datetag']=='22-MonthEnd', 'DatetagCode'] = 75
i_jd['PeriodCode'] = i_jd['Year Month'] * 100 + i_jd['DatetagCode']

i_jd['End Date'] = pd.to_datetime(i_jd['End Date'])


# trailing 1y mkt share


o_jd_mktshr_t1y = []
for dt in pd.date_range(start='2018-07-01', end = '2021-12-31'):
    print(dt.strftime('%Y%m%d'),end=',')
    
    t_jd = i_jd[i_jd['End Date'].le(dt-pd.to_timedelta('7 days')) \
                      & i_jd['End Date'].ge(dt-pd.to_timedelta('30 days'))]
        
    # trailing 1y data
    s_jd_minmax_period = t_jd.groupby('Ticker')['PeriodCode'].max().reset_index()
    s_jd_minmax_period['PeriodCodeMin'] = s_jd_minmax_period['PeriodCode']-10000+25     
    t_jd = t_jd.merge(s_jd_minmax_period[['Ticker','PeriodCodeMin']], on = 'Ticker', how = 'left')
    t_jd = t_jd[t_jd['PeriodCode']>=t_jd['PeriodCodeMin']]
    
    # trailing 1y stats
    
    t_jd['value_dv_tot'] = t_jd['Value'] / t_jd['Value'].sum() 
    
    s_jd_t1y = t_jd.groupby('Ticker')['value_dv_tot'].sum().reset_index()
    s_jd_t1y.columns = ['Ticker', 'mktshr_jd_t1y']
    s_jd_t1y['datadate'] = dt
    
    o_jd_mktshr_t1y.append(s_jd_t1y)
o_jd_mktshr_t1y = pd.concat(o_jd_mktshr_t1y, axis = 0)


o_jd_mktshr_t1y['datadate_1y'] = o_jd_mktshr_t1y['datadate'] - pd.to_timedelta('365 days')
o_jd_mktshr_t1y = o_jd_mktshr_t1y.merge(o_jd_mktshr_t1y[['datadate', 'Ticker', 'mktshr_jd_t1y']]\
                                .rename(columns={'datadate':'datadate_1y'}),
                                on = ['datadate_1y', 'Ticker'], how = 'left', suffixes=['','_1y'])
o_jd_mktshr_t1y['mktshr_jd_df1y'] = o_jd_mktshr_t1y['mktshr_jd_t1y'] - o_jd_mktshr_t1y['mktshr_jd_t1y_1y']
o_jd_mktshr_t1y['mktshr_jd_yoy'] = o_jd_mktshr_t1y['mktshr_jd_t1y'] / o_jd_mktshr_t1y['mktshr_jd_t1y_1y'] - 1
o_jd_mktshr_t1y['mktshr_jd_df1y_allrk'] = o_jd_mktshr_t1y.groupby('datadate')['mktshr_jd_df1y'].apply(yu.uniformed_rank)
o_jd_mktshr_t1y['mktshr_jd_yoy_allrk'] = o_jd_mktshr_t1y.groupby('datadate')['mktshr_jd_yoy'].apply(yu.uniformed_rank)

c1 = o_jd_mktshr_t1y['Ticker'].str.contains('\d{6} CH EQUITY')
o_jd_mktshr_t1y.loc[c1, 'ticker'] = o_jd_mktshr_t1y.loc[c1, 'Ticker'].str[:6]
c_sh = o_jd_mktshr_t1y['ticker'].str[0].isin(['6'])
c_sz = o_jd_mktshr_t1y['ticker'].str[0].i
sin(['0','3'])
o_jd_mktshr_t1y.loc[c_sh, 'ticker'] = o_jd_mktshr_t1y.loc[c_sh, 'ticker'] + '.SH'
o_jd_mktshr_t1y.loc[c_sz, 'ticker'] = o_jd_mktshr_t1y.loc[c_sz, 'ticker'] + '.SZ'


# backtest

icom = i_sd.merge(o_jd_mktshr_t1y, on = ['ticker', 'datadate'], how = 'left')

icom['mktshr_jd_df1y_unirk'] = icom.groupby('datadate')['mktshr_jd_df1y'].apply(yu.uniformed_rank)
icom['mktshr_jd_yoy_unirk'] = icom.groupby('datadate')['mktshr_jd_yoy'].apply(yu.uniformed_rank)

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2019-01-01','2021-12-30')].\
        dropna(subset=['mktshr_jd_df1y_unirk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
        'mktshr_jd_df1y_unirk','BarrRet_CLIP_USD+1d', static_data = i_sd)  # 1.78 / 1.27 / 0.38

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2019-01-01','2021-12-30')].\
        dropna(subset=['mktshr_jd_yoy_unirk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
        'mktshr_jd_yoy_unirk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2 / 1.52 / 0.7

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2019-01-01','2021-12-30')].\
        dropna(subset=['mktshr_jd_df1y_allrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
        'mktshr_jd_df1y_allrk','BarrRet_CLIP_USD+1d', static_data = i_sd)   # 1.6 / 1.14/ 0.39

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2019-01-01','2021-12-30')].\
        dropna(subset=['mktshr_jd_yoy_allrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
        'mktshr_jd_yoy_allrk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.94 / 1.5 / 0.86


