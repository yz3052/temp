﻿#$%^&* tr_05.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat May  9 16:06:10 2020
@author: tomyi
"""
import os
import inspect
from yz import get_sql, print_progress

import pandas as pd
import numpy as np
from numba import njit, jit
from datetime import date, datetime


import pickle

import matplotlib.pyplot as plt


class Backtest(object):
    
    def __init__(self, mkt_data_type, signals, str_from_ymd, str_to_ymd, bar_cache):
        
        #----------------------------------------------------------------------
        # Format
        #----------------------------------------------------------------------
        # mkt_data_type ['raw','beta','barra','hedged']
        # str_from_ymd, str_to_ymd 'YYYY-MM-DD'
        
        print (str(datetime.now()) + ' - __init__ starts.')
        
        #----------------------------------------------------------------------
        # dates and ticker
        #----------------------------------------------------------------------        
        
        # cdates
        if isinstance(str_from_ymd, str) & isinstance(str_to_ymd, str) &\
                        (len(str_from_ymd)==10) & (len(str_to_ymd)==10) &\
                        ('-' in str_from_ymd) & ('-' in str_to_ymd):
            self.cdates = pd.date_range(start=str_from_ymd, end=str_to_ymd).tolist()
        elif str_from_ymd == '' or str_from_ymd is None or str_to_ymd == '' or str_to_ymd is None:
            self.cdates = pd.date_range(start='2010-06-01', end='2019-11-10').tolist()
        else:
            raise Exception('Date format incorrect.')
        print ('cdates', end = ' ')
                
        # tk uni
        self.tk = ['ISRG','EW','NVRO','ABMD','PODD','NVCR','CDNA','DXCM','EXAS','XENT','GKOS','TCMD','TNDM','UTHR']
        SPY = pd.read_csv(r"N:\projects\backtester\PRODUCTION\SPX.csv")
        self.tk = SPY['Ticker'].str.split(' ').str[0].tolist()
        
        print ('tk', end = ' ')
        #----------------------------------------------------------------------
        # market data
        #----------------------------------------------------------------------        
        
        # market data: cc, co
        if 'beta' in mkt_data_type.lower():
            pass
        
        elif 'raw' in mkt_data_type.lower():
            self.pv_cc_ret = self.ret_raw_c_c()
            self.pv_co_ret = self.ret_raw_c_o()
            
        elif 'barra' in mkt_data_type.lower():
            self.pv_cc_ret = self.ret_barra_c_c()
   
         self.pv_co_ret = self.ret_barra_c_o()
        
        elif 'hedged' in mkt_data_type.lower():
            pass
            
        self.pv_cc_ret = self.pv_cc_ret.reindex(index = self.cdates)
        self.pv_co_ret = self.pv_co_ret.reindex(index = self.cdates)
        print ('ret', end = ' ')
        
        # market data: volume
        self.pv_vD = self.vD()
        
        if self.pv_vD.columns.tolist() != self.pv_cc_ret.columns.tolist():
            raise Exception('Volume columns different from ret columns.')
        
        print('v', end = ' ')
        #----------------------------------------------------------------------
        # first bar
        #----------------------------------------------------------------------        

        if bar_cache is None or bar_cache == '':
            self.first_bar = 30
        elif not isinstance(bar_cache, int):
            raise Exception('bar_cache must be an int.')
        else:
            self.first_bar = bar_cache

        #----------------------------------------------------------------------
        # signals
        #----------------------------------------------------------------------

        if isinstance(signals, pd.DataFrame):
            self.pv_signals = signals
        elif isinstance(signals, str):
            self.pv_signals = pd.read_parquet(signals)
        else:
            raise Exception('Signal type error.')
            
        if 'score' in '@'.join(signals.columns.tolist()):
            t_date_col = [i for i in self.pv_signals.columns.tolist() if 'date' in i.lower()][0]
            t_tk_col = [i for i in self.pv_signals.columns.tolist() if 'ticker' in i.lower()][0]
            t_score_col = [i for i in self.pv_signals.columns.tolist() if 'score' in i.lower()][0]
            self.pv_signals = self.pv_signals.pivot_table(index = t_date_col, columns = t_tk_col, values = t_score_col)
        else:
            pass
        
        self.pv_signals = self.pv_signals.reindex(index = self.cdates, columns = self.tk)
        print('signals', end = ' ')
        #----------------------------------------------------------------------
        # business days to earnings
        #----------------------------------------------------------------------
        
        #self.pv_bd2e = self.ed_bd_2_earning()
        print('bd2e', end = ' ')
        #----------------------------------------------------------------------
        # other metrics
        #---------------------------------
-------------------------------------
                    
        #----------------------------------------------------------------------
        # strategy
        #----------------------------------------------------------------------


        # strat variables        
        self.pv_pstD_bo = self.h_create_zero_pv()
        self.pv_pstD_bc = self.h_create_zero_pv()
        self.pv_pstS_bo = self.h_create_zero_pv()
        self.pv_pstS_bc = self.h_create_zero_pv()
        
        self.pv_ordD_unfilled = self.h_create_zero_pv()
        
        self.pv_ordD_bo = self.h_create_zero_pv()
        self.pv_ordD_bc = self.h_create_zero_pv()
        self.pv_ordS_bo = self.h_create_zero_pv()
        self.pv_ordS_bc = self.h_create_zero_pv()
        self.pv_ordPct_bo = self.h_create_zero_pv()
        self.pv_ordPct_bc = self.h_create_zero_pv()
        
        self.pv_pnlD = self.h_create_zero_pv()
        
        self.pv_barsheld_since_pst_open = self.h_create_zero_pv() - 1
        self.pv_tbarsheld_since_pst_open = self.h_create_zero_pv() - 1
        
        self.pv_tbar_unfilled_ord = self.h_create_zero_pv() - 1
        
        self.pv_curr_pst_pnlD = self.h_create_zero_pv()
        
        self.vc_vD_quota = self.h_create_zero_vc()
        self.vc_ones = self.h_create_zero_vc() + 1
        
        # state matrix
        self.dic_state = {}
        
        #----------------------------------------------------------------------
        # reporting
        #----------------------------------------------------------------------  
        
        # reporting
        self.dic_report = {}
        
        print (str(datetime.now()) + ' - Initiation done.')
        
    def h_create_zero_pv(self):
        t0 = np.zeros([len(self.cdates),len(self.tk)])
        return pd.DataFrame(t0, index = self.cdates, columns = self.tk)
    def h_create_zero_vc(self):
        t0 = np.zeros(len(self.tk))
        return t0
    
    def ret_barra_c_c(self):
        if os.path.exists(r"S:\Infrastructure\backtester\PRODUCTION\ret_barra_c_c.parquet"):
            ibarra_pivot = pd.read_parquet(r"S:\Infrastructure\backtester\PRODUCTION\ret_barra_c_c.parquet", columns = self.tk)
        else:
            ibarra = get_sql("select datadate, Ticker, ret_barra_omega_adj from [BackTest].[dbo].[BARRA_Ret_Daily] where Ticker in {0}".\
                             format(str(tuple(self.tk)) if len(self.tk)>1 else "('"+self.tk[0]+"')") )
            ibarra_pivot = ibarra.pivot_table(index
='datadate', columns = 'Ticker', values = 'ret_barra_omega_adj')
        ibarra_pivot = ibarra_pivot.reindex(index = self.cdates).reindex(columns = self.tk)
        return ibarra_pivot
    
    def ret_barra_c_o(self):
        ibarra_c_c = self.ret_barra_c_c()
        i_raw_overnight = self.ret_raw_overnight()
        i_barra_c_o = np.subtract(ibarra_c_c, i_raw_overnight)
        return i_barra_c_o
    
    def ret_raw_overnight(self):
        if os.path.exists(r'S:\Infrastructure\backtester\PRODUCTION\ret_raw_overnight.parqeut'):
            iovernight_pivot = pd.read_parquet(r'S:\Infrastructure\backtester\PRODUCTION\ret_raw_overnight.parqeut', columns = self.tk)
        else:
            iovernight = get_sql('''select datadate, Ticker, (PX_OPEN - PX_YEST_CLOSE)/PX_YEST_CLOSE  as overnight_ret 
                                     FROM [BackTest].[dbo].[BBG_MktData_Hist] where Ticker in {0}'''.\
                                     format(str(tuple(self.tk)) if len(self.tk)>1 else "('"+self.tk[0]+"')") )
            iovernight_pivot = iovernight.pivot_table(index='datadate', columns = 'Ticker', values = 'overnight_ret')
        iovernight_pivot = iovernight_pivot.reindex(index = self.cdates).reindex(columns = self.tk)
        return iovernight_pivot
    
    def ret_raw_c_c(self):
        if os.path.exists(r'S:\Infrastructure\backtester\PRODUCTION\ret_raw_c_c.parqeut'):
            i_ret_raw_c_c = pd.read_parquet(r'S:\Infrastructure\backtester\PRODUCTION\ret_raw_c_c.parqeut', columns = self.tk)
        else:
            i_ret_raw_c_c = get_sql('''select datadate, Ticker, PX_LAST/PX_YEST_CLOSE - 1 as ret_raw_c_c 
                                        FROM [BackTest].[dbo].[BBG_MktData_Hist] where Ticker in {0}'''.\
                                        format(str(tuple(self.tk)) if len(self.tk)>1 else "('"+self.tk[0]+"')") )
            i_ret_raw_c_c = i_ret_raw_c_c.pivot_table(index='datadate', columns = 'Ticker', values = 'ret_raw_c_c')
        i_ret_raw_c_c = i_ret_raw_c_c.reindex(index = self.cdates).reindex(columns = self.tk)
        return i_ret_raw_c_c
    
    def ret_raw_c_o(self):
        if os.path.exists(r'S:\Infrastructure\backtester\PRODUCTION\ret_raw_c_o.parqeut'):
            i_ret_raw_c_o = pd.read_parquet(r'S:\Infrastructure\backtester\PRODUCTION\ret_raw_c_o.parqeut', columns = self.tk)
        else:
            i_ret_raw_c_o = get_sql('''select datadate, Ticker, PX_CLOSE/PX_open - 1 as ret_raw_c_o 
                                   
     FROM [BackTest].[dbo].[BBG_MktData_Hist] where Ticker in {0}'''.\
                                        format(str(tuple(self.tk)) if len(self.tk)>1 else "('"+self.tk[0]+"')") )
            i_ret_raw_c_o = i_ret_raw_c_o.pivot_table(index='datadate', columns = 'Ticker', values = 'ret_raw_c_o')
        i_ret_raw_c_o = i_ret_raw_c_o.reindex(index = self.cdates).reindex(columns = self.tk)
        return i_ret_raw_c_o
    
    def vD(self):
        if os.path.exists(r'S:\Infrastructure\backtester\PRODUCTION\vD.parqeut'):
            i_vD = pd.read_parquet(r'S:\Infrastructure\backtester\PRODUCTION\vD.parqeut', columns = self.tk)
        else:
            i_vD = get_sql('''select datadate, ticker, PX_LOW*PX_VOLUME as vD 
                           FROM [BackTest].[dbo].[BBG_MktData_Hist] where ticker in {0}'''.\
                           format(str(tuple(self.tk)) if len(self.tk)>1 else "('"+self.tk[0]+"')") )
            i_vD = i_vD.pivot_table(index='datadate', columns = 'ticker', values = 'vD')
        i_vD = i_vD.reindex(index = self.cdates).reindex(columns = self.tk)
        return i_vD
    
    def ed_bd_2_earning(self):
        wh = get_sql('''
                     select datadate, stock_symbol, [next_ed_quarter], [fiscal_year],
                     case when time_of_day = 'After Market' then next_ed + 1 else next_ed end as first_earning_impact 
                     FROM [BackTest].[dbo].[WSH_ED_SNAP] 
                     where stock_symbol in {0} 
                     '''.format(str(tuple(self.tk)) if len(self.tk)>1 else "('"+self.tk[0]+"')") )
        wh = wh.drop_duplicates(subset = ['datadate','stock_symbol'],keep = 'first')
        wh = wh.pivot_table(index = 'datadate', columns = 'stock_symbol', values = 'first_earning_impact', aggfunc=lambda x: x )
        wh = wh.reindex(index = self.cdates).reindex(columns = self.tk)
        wh = wh.fillna(method = 'ffill')
        wh = wh.fillna(date(1908,8,8))
        
        wh_bd2e = pd.DataFrame(index = self.cdates, columns = self.tk)
        for col in wh_bd2e.columns:
            wh_bd2e[col] = np.busday_count(wh.index.values.astype('datetime64[D]'), wh[col].values.astype('datetime64[D]'))
        
        wh_bd2e = np.where(wh_bd2e<-10000,np.nan,wh_bd2e)
        # == 1 means the next trading day will be the first day impacted by earnings.
        # Hence to get out right before earning, make sure wh_bd2e == 2
        
        return wh_bd2e
        
    def rpt_sharpe(self, daily_pnl_sr):
       
 return daily_pnl_sr.mean()/daily_pnl_sr.std()
    
    def rpt_plot(self, cum_pnl_sr, tdates_sr):
        fig, ax = plt.subplots(constrained_layout=True)
        ax.plot(tdates_sr, cum_pnl_sr)
    
    # ----- loop over strat -----

    def start(self, strat_f, *params):
        
        self.strat_func = strat_f
        self.params = params
        
        for num, (ts, row) in zip(np.arange(len(self.pv_cc_ret)), self.pv_cc_ret.iterrows()):
            
            # skip over the first few bars
            if num < self.first_bar:
                continue
            
            # carry on unfilled order from the previous bar
            self.pv_ordD_unfilled.iloc[num,:] = self.pv_ordD_unfilled.iloc[num-1,:]            
            
            # carry on pst from the previous bar
            self.pv_pstD_bo.iloc[num,:] = self.pv_pstD_bc.iloc[num-1,:]
            
            # setup vD quota before filling orders            
            self.vc_vD_quota = np.nan_to_num(self.pv_vD.iloc[num,:]) * 0.02
            
            # fill ord @ bo
            #     update pst @ bo: yerterday bc pst + unfilled order + new ord             
            t_ord_bo = self.pv_ordD_bo.iloc[num-1,:]+self.pv_ordD_unfilled.iloc[num-1,:]
            t_abs_ord_bo = np.abs(t_ord_bo)
            t_allowed_abs_ord_bo = np.minimum(t_abs_ord_bo, self.vc_vD_quota)
            t_allowed_ord_bo = np.multiply(t_allowed_abs_ord_bo,np.sign(t_ord_bo))
            
            self.pv_pstD_bo.iloc[num,:] = self.pv_pstD_bo.iloc[num,:] + t_allowed_ord_bo
            
            #     update unfilled orders after market open
            self.pv_ordD_unfilled.iloc[num,:] = t_ord_bo - t_allowed_ord_bo
            
            # update vD quota after bo ord
            self.vc_vD_quota = self.vc_vD_quota - t_allowed_abs_ord_bo

            # fill ord @ bc
            #     updte pst @ bc: today bo pst + unfilled order + new ord
            t_ord_bc = self.pv_ordD_bc.iloc[num-1,:]+self.pv_ordD_unfilled.iloc[num,:]
            t_abs_ord_bc = np.abs(t_ord_bc)
            t_allowed_abs_ord_bc = np.minimum(t_abs_ord_bc, self.vc_vD_quota)
            t_allowed_ord_bc = np.multiply(t_allowed_abs_ord_bc,np.sign(t_ord_bc))            
            
            self.pv_pstD_bc.iloc[num,:] = self.pv_pstD_bo.iloc[num,:] + t_allowed_ord_bc
            
            #     update unfilled orders after mc
            self.pv_ordD_unfilled.iloc[num,:] = t_ord_bc - t_allowed_ord_bc
            
            # 
update vD quota after bo ord
            self.vc_vD_quota = self.vc_vD_quota - t_allowed_ord_bc
            
            # calc pnl for the pst opened @ bo
            self.pv_pnlD.iloc[num,:] = self.pv_pnlD.iloc[num,:] +\
                np.multiply(self.pv_pstD_bo.iloc[num,:] - self.pv_pstD_bc.iloc[num-1,:],\
                            self.pv_co_ret.iloc[num,:])
                                            
            
            # calc pnl for the pst from yesterday
            self.pv_pnlD.iloc[num,:] = self.pv_pnlD.iloc[num,:] +\
                np.multiply(self.pv_pstD_bc.iloc[num-1,:], self.pv_cc_ret.iloc[num,:])
            
            # new or held pst / update curr pst pnl
            cond_new_or_held_pst = (self.pv_pstD_bc.iloc[num,:]!=0)
            self.pv_curr_pst_pnlD.values[num, cond_new_or_held_pst ] = \
                                        self.pv_curr_pst_pnlD.values[num-1, cond_new_or_held_pst] +\
                                        self.pv_pnlD.values[num, cond_new_or_held_pst ]
            
            # closed pst / clear curr pst pnl
            cond_closed_pst = (self.pv_pstD_bc.iloc[num-1,:]!=0) & (self.pv_pstD_bc.iloc[num,:]==0)
            self.pv_curr_pst_pnlD.values[num, cond_closed_pst] = 0
            
            self.pv_curr_pst_pnlD = self.pv_curr_pst_pnlD.fillna(0)
            
            # no. of calendar bars since holding pst
            cond_new_pst = (self.pv_pstD_bc.iloc[num,:]!=0) & (self.pv_pstD_bc.iloc[num-1,:]== 0)
            cond_new_pst = cond_new_pst  | \
                        (np.multiply(self.pv_pstD_bc.iloc[num,:], self.pv_pstD_bc.iloc[num-1,:])<0)
            self.pv_barsheld_since_pst_open.values[num, cond_new_pst]  = 1
            
            cond_existing_pst = (np.multiply(self.pv_pstD_bc.iloc[num,:], self.pv_pstD_bc.iloc[num-1,:])>0)
            self.pv_barsheld_since_pst_open.values[num, cond_existing_pst] = \
                                        self.pv_barsheld_since_pst_open.values[num, cond_existing_pst] +1
            
            # no. of trading bars since holding pst
            self.pv_tbarsheld_since_pst_open.values[num, cond_new_pst] = 1
            
            cond_existing_pst_and_v_notnan = cond_existing_pst & (~np.isnan(self.pv_vD.iloc[num,:]))
            cond_existing_pst_and_v_isnan = cond_existing_pst & (np.isnan(self.pv_vD.iloc[num,:]))
            self.pv_tbarsheld_since_pst_open.values[num, cond_existing_pst_and_v_notnan ] = \
                self.pv_tbarsh
eld_since_pst_open.values[num-1, cond_existing_pst_and_v_notnan] + 1
            self.pv_tbarsheld_since_pst_open.values[num, cond_existing_pst_and_v_isnan ] = \
                self.pv_tbarsheld_since_pst_open.values[num-1, cond_existing_pst_and_v_isnan]
            
            # no. of trading bars with unfilled ord
            # it shows the EXTRA number of bars taken to fill an order  (e.g. 3 means it takes 1 + 3 days to fill a position)
            cond_new_unfilled_ord1 = (self.pv_ordD_unfilled.iloc[num-1,:] == 0) & (self.pv_ordD_unfilled.iloc[num,:] != 0)
            cond_new_unfilled_ord2 = (np.multiply(self.pv_ordD_unfilled.iloc[num-1,:], self.pv_ordD_unfilled.iloc[num,:]) < 0)
            self.pv_tbar_unfilled_ord.values[num, (cond_new_unfilled_ord1) | (cond_new_unfilled_ord2) ] = 1
            
            cond_existing_unfilled_ord = np.multiply(self.pv_ordD_unfilled.iloc[num-1,:], self.pv_ordD_unfilled.iloc[num,:]) > 0
            self.pv_tbar_unfilled_ord.values[num, cond_existing_unfilled_ord] = self.pv_tbar_unfilled_ord.values[num-1, cond_existing_unfilled_ord] + 1
                                                                                
            
            
            # strategy
            
            self.strat_func(self, num)
            
            # print progress
            print_progress(num, len(self.cdates))
    
    def reporting(self):
        
        # get rid of weekends and holidays (where vD is nan)
        self.pv_pnlD_present = self.pv_pnlD.loc[pd.notnull(self.pv_vD).any(axis = 1),:]
        self.pv_pnlD_present = self.pv_pnlD_present.fillna(0)
        
        # strat source code
        #self.dic_report['sourcecode'] = inspect.getsource(self.strat_func)
        self.dic_report['params'] = locals()
        
        # pnl
        self.dic_report['pnl_tk'] = self.pv_pnlD_present
        self.dic_report['pnl_ptf'] = self.pv_pnlD_present.sum(axis = 1)
        
        self.dic_report['cumpnl_tk'] = self.pv_pnlD_present.cumsum(axis = 0)
        self.dic_report['cumpnl_ptf'] = self.pv_pnlD_present.cumsum(axis = 0).sum(axis = 1)
        
        # pst
        self.dic_report['pst_bo'] = self.pv_pstD_bo
        self.dic_report['pst_bc'] = self.pv_pstD_bc
        
        # sharpe
        self.dic_report['sharpe_tk'] = self.pv_pnlD_present.mean(axis = 0) / self.pv_pnlD_present.std(axis = 0) * np.sqrt(250)
        self.dic_report['sharpe_ptf'] = self.pv_pnlD_present.sum(axis = 1).mean(axis = 0) / self.pv_pnlD_pres
ent.sum(axis = 1).std(axis = 0) * np.sqrt(250)
        
        # plot
        self.dic_report['cumpnl_ptf'].plot()
        
        # print key results
        print(self.dic_report['sharpe_ptf'])
        
        # save results as bz'ed pickles
        #pickle.dump(self.dic_report,open(r'C:\Users\tomyi\Desktop\Sync\1. Trading\7. Backtest and Trading Platform\syncere\log'))
        
        return self.dic_report
