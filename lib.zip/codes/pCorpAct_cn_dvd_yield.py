﻿#$%^&* pCorpAct_cn_dvd_yield.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 13 10:28:12 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime



### sd 

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])

i_sd_dd = i_sd['datadate'].drop_duplicates()


### sd stable shortable 

i_sd_ss = pw.get_china_ss_sd()



### c and adj
i_c = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                           s_dq_close as c, s_dq_adjfactor as adj 
                    from wind_prod.dbo.ashareeodprices''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format='%Y%m%d')
i_c = i_c.sort_values('datadate')


### ed

i_ed = yu.get_sql('''select datadate, ticker, ped, next_ed FROM [CNDBPROD].[dbo].[CNINFO_ED_SNAP]''')

c_sh = i_ed['ticker'].str[0].isin(['6'])
c_sz = i_ed['ticker'].str[0].isin(['0','3'])
i_ed.loc[c_sh, 'ticker'] = i_ed.loc[c_sh, 'ticker'] + '.SH'
i_ed.loc[c_sz, 'ticker'] = i_ed.loc[c_sz, 'ticker'] + '.SZ'





### dvd wind

i_wind_dvd = yu.get_sql('''select s_info_windcode as ticker, s_div_prelandate as datadate, 
                        dvd_ann_dt, eqy_record_dt as record_date, ex_dt,  
                            cash_dvd_per_sh_pre_tax, report_period
                            from wind.dbo.AshareDividend  ''')
for c in ['datadate','dvd_ann_dt','record_date','ex_dt']:
    i_wind_dvd[c] = i_wind_dvd[c].fillna('NA')
    i_wind_dvd[c] = pd.to_datetime(i_wind_dvd[c], format = '%Y%m%d', errors = 'coerce')

i_wind_dvd = i_wind_dvd.dropna()
i_wind_dvd = i_wind_dvd[i_wind_dvd['cash_dvd_per_sh_pre_tax']>0]

i_wind_dvd = i_wind_dvd.merge(i_c[['ticker','datadate','adj','c']],on=['ticker','datadate'],how='left')
i_wind_dvd = i_wind_dvd.rename(columns={'adj':'adj_on_ann', 'c':'c_on_ann'})
i_wind_dvd['adj_on_ann'] = i_wind_dvd['adj_on_ann'].fillna(1)

i_wind_dvd = i_wind_dvd.sort_values(['ticker','datadate'])




### dvd frcst

i_dvd = yu.get_sql('''select report_id, stock_code as ticker,create_date,
                             report_year*10 + report_quarter as report_period, 
                             report_type, reliability, organ_id, entrytime,
                             forecast_dps as frcst_dps, current_price
                      FROM [SUNTIME_PROD].[dbo].[rpt_forecast_stk]
                      where forecast_dps is not null ''')

c_sh = i_dvd['ticker'].str[0].isin(['6'])
c_sz = i_dvd['ticker'].str[0].isin(['0','3'])

i_dvd.loc[c_sh, 'ticker'] = i_dvd.loc[c_sh, 'ticker'] + '.SH'
i_dvd.loc[c_sz, 'ticker'] = i_dvd.loc[c_sz, 'ticker'] + '.SZ'
    
i_dvd['create_date'] = pd.to_datetime(i_dvd['create_date'])
i_dvd['datadate'] = pd.to_datetime((i_dvd['entrytime'] - pd.to_timedelta('4 hours')).dt.date)

i_dvd = i_dvd.sort_values('create_date')
i_dvd = pd.merge_asof(i_dvd, i_c[['ticker','datadate','adj']].rename(columns={'datadate':'create_date','adj':'adj_on_create'}),
                      by='ticker', on='create_date')

i_dvd = i_dvd.sort_values(['ticker','organ_id','report_id','report_period'])



### loop
# dvd frcst from suntime

o_dvd = []
for dt in i_sd_dd:
    print(dt.strftime('%Y%m%d'), end=',')
    
    # get universe
    t_uni = i_sd[i_sd.datadate==dt][['ticker']]
        
    # get c
    t_c = i_c[i_c.datadate==dt][['ticker','c','adj']]
        
    # get dividend frcst
    t_dvd = i_dvd[(i_dvd['datadate']<=dt) & (i_dvd['create_date']>=dt-pd.to_timedelta('182 days'))]
    t_dvd = t_dvd.drop_duplicates(subset=['ticker','organ_id','report_id'], keep = 'first') # earliest report_period
    t_dvd = t_dvd.sort_values(['ticker','organ_id','create_date'])
    t_dvd = t_dvd.drop_duplicates(subset=['ticker','organ_id'], keep = 'last') # latest report
    t_dvd['frcst_dps_adj'] = t_dvd['frcst_dps'].multiply(t_dvd['adj_on_create'])
        
    s_dvd = t_dvd.groupby('ticker')['frcst_dps_adj'].mean().reset_index()
    
    # select stocks in annoucement - ex range
    t_wind_dvd = i_wind_dvd[(i_wind_dvd['datadate']<=dt)&(i_wind_dvd['record_date']>=dt)]
    t_wind_dvd = t_wind_dvd.rename(columns={'datadate':'proposal_date'})
    t_wind_dvd['actual_dps_adj'] = t_wind_dvd['cash_dvd_per_sh_pre_tax'].multiply(t_wind_dvd['adj_on_ann'])
    t_wind_dvd = t_wind_dvd[['ticker','actual_dps_adj','proposal_date','dvd_ann_dt','record_date']]
    
    # combine 
    tcom = t_uni.merge(t_wind_dvd, on = 'ticker', how = 'outer')
    tcom = tcom.merge(s_dvd, on = 'ticker', how = 'outer')
    tcom = tcom.merge(t_c, on = 'ticker', how = 'left')
    
    # tag date type 
    tcom.loc[tcom['dvd_ann_dt']>dt, 'identifier'] = 'P'
    tcom.loc[tcom['dvd_ann_dt']<=dt, 'identifier'] = 'A'
    tcom.loc[tcom['dvd_ann_dt'].isnull(), 'identifier'] = 'E'
    
    # calculate combined dvd yield
    tcom['com_divyild'] = tcom['actual_dps_adj'].divide(tcom['c']).divide(tcom['adj'])
    c1 = tcom['com_divyild'].isnull()
    tcom.loc[c1, 'com_divyild'] = tcom.loc[c1, 'frcst_dps_adj'].divide(tcom.loc[c1, 'c']).divi
de(tcom.loc[c1,'adj'])
    tcom['com_divyild'] = tcom['com_divyild'].replace(0, np.nan)
    
    # output
    tcom['datadate'] = dt
    o_dvd.append(tcom)
o_dvd = pd.concat(o_dvd, axis=0)

o_dvd['com_divyild_bk'] = o_dvd.groupby('datadate')['com_divyild'].apply(lambda x: yu.pdqcut(x,bins=10)).values



### loop
# dvd frcst from past dvd


o_dvd2 = []
for dt in i_sd_dd:
    print(dt.strftime('%Y%m%d'), end=',')
    
    # get universe
    t_uni = i_sd[i_sd.datadate==dt][['ticker']]
        
    # get c
    t_c = i_c[i_c.datadate==dt][['ticker','c','adj']]
        
    # get dividend frcst from actual history
    t_wind_past_dvd = i_wind_dvd[(i_wind_dvd['ex_dt']<dt)&(i_wind_dvd['ex_dt']>dt-pd.to_timedelta('540 days'))]
    t_wind_past_dvd = t_wind_past_dvd.sort_values(['ticker','datadate'])
    t_wind_past_dvd = t_wind_past_dvd.drop_duplicates(subset=['ticker'], keep='last')
    t_wind_past_dvd['frcst_dps_adj'] = t_wind_past_dvd['cash_dvd_per_sh_pre_tax'].multiply(t_wind_past_dvd['adj_on_ann'])
    t_wind_past_dvd['divyild_on_ann'] = t_wind_past_dvd['cash_dvd_per_sh_pre_tax'].divide(t_wind_past_dvd['c_on_ann'])
    dvd_frcst_dps = t_wind_past_dvd[['ticker','frcst_dps_adj','divyild_on_ann']]
    
    # get most recent exdate
    t_past_exdate = t_wind_past_dvd[['ticker','ex_dt']]
    t_past_exdate.columns = ['ticker', 'ex_dt_l1y']
    
    # get next annual ed
    t_ed = i_ed[i_ed.datadate==dt]
    t_ed = t_ed[t_ed['ped'].dt.quarter==4]
    t_ed = t_ed[['ticker', 'next_ed']]
    t_ed.columns = ['ticker', 'next_q4_ed']    
    
    # select stocks in proposal - record range
    t_wind_dvd = i_wind_dvd[(i_wind_dvd['datadate']<=dt)&(i_wind_dvd['record_date']>=dt)]
    t_wind_dvd = t_wind_dvd.rename(columns={'datadate':'proposal_date'})
    t_wind_dvd['actual_dps_adj'] = t_wind_dvd['cash_dvd_per_sh_pre_tax'].multiply(t_wind_dvd['adj_on_ann'])
    t_wind_dvd = t_wind_dvd[['ticker','actual_dps_adj','proposal_date','dvd_ann_dt','record_date']]
    
    # combine 
    tcom = t_uni.merge(t_wind_dvd, on = 'ticker', how = 'left')
    tcom = tcom.merge(dvd_frcst_dps, on = 'ticker', how = 'left')
    tcom = tcom.merge(t_c, on = 'ticker', how = 'left')
    tcom = tcom.merge(t_past_exdate, on = 'ticker', how = 'left')
    tcom = tcom.merge(t_ed, on = 'ticker', how = 'left')    
    
    
    # tag date type 
    tcom.loc[tcom['dvd_ann_dt']>dt, 'identifier'] = 'P'
    tcom.loc[tcom['dvd_ann_dt']<=dt, 'identifier'] = 'A'
    tcom.loc[tcom['dvd_ann_dt'].isnull(), 'identifier']
 = 'E'
    
    # tag periods
    tcom['days_s_ex'] = (dt - tcom['ex_dt_l1y']).dt.days
    tcom['days_2_annual'] = (tcom['next_q4_ed'] - dt).dt.days
    
    # calculate combined dvd yield
    tcom['com_divyild'] = tcom['actual_dps_adj'].divide(tcom['c']).divide(tcom['adj'])
    c1 = tcom['com_divyild'].isnull()
    tcom.loc[c1, 'com_divyild'] = tcom.loc[c1, 'frcst_dps_adj'].divide(tcom.loc[c1, 'c']).divide(tcom.loc[c1,'adj'])
    tcom['com_divyild'] = tcom['com_divyild'].replace(0, np.nan)
    
    # output
    tcom['datadate'] = dt
    o_dvd2.append(tcom)
o_dvd2 = pd.concat(o_dvd2, axis=0)

o_dvd2['com_divyild_bk'] = o_dvd2.groupby('datadate')['com_divyild'].apply(lambda x: yu.pdqcut(x,bins=10)).values
o_dvd2['com_divyild_rk'] = o_dvd2.groupby('datadate')['com_divyild'].apply(yu.uniformed_rank)






### combine 

#icom = i_sd.merge(o_dvd, on = ['ticker', 'datadate'], how = 'left')
icom = i_sd.merge(o_dvd2, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

yu.create_cn_3x3(icom[icom['identifier']=='P'], ['com_divyild_bk'], 'com_divyild')
yu.create_cn_3x3(icom[icom['identifier']=='A'], ['com_divyild_bk'], 'com_divyild')
yu.create_cn_3x3(icom[icom['identifier']=='E'], ['com_divyild_bk'], 'com_divyild')

yu.create_cn_3x3(icom, ['com_divyild_bk'], 'com_divyild')
yu.create_cn_3x3(icom[icom['identifier'].isin(['P','A'])], ['com_divyild_bk'], 'com_divyild')
yu.create_cn_3x3(icom[icom['identifier']=='A'], ['com_divyild_bk'], 'com_divyild')
yu.create_cn_3x3(icom[(icom['identifier']=='A')&(icom['com_divyild']>=0.02)], ['com_divyild_bk'], 'com_divyild')

yu.create_cn_3x3(icom[icom['days_s_ex']>=14], ['com_divyild_bk'], 'com_divyild')



# E P A

icom['com_divyild_rk_e'] = np.nan
c1 = icom['identifier'] == 'E'
icom.loc[c1, 'com_divyild_rk_e'] = icom.loc[c1, 'com_divyild_rk']

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
            dropna(subset=['com_divyild_rk_e','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'com_divyild_rk_e','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))&(icom['com_divyild_rk_e']>0)].\
            dropna(subset=['com_divyild_rk_e','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'com_divyild_rk_e','BarrRet_CLIP_USD+1d', static_data = i_sd) # 



icom['com_divyild_rk_p'] = np.nan
c1 = icom['identifier'] == 'P'
icom.loc[c1, 'c
om_divyild_rk_p'] = icom.loc[c1, 'com_divyild_rk']

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31')) & (icom['com_divyild_rk_p']>0)].\
            dropna(subset=['com_divyild_rk_p','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'com_divyild_rk_p','BarrRet_CLIP_USD+1d', static_data = i_sd) # 



# E in different periods


icom['com_divyild_rk_e_l'] = np.nan
c1 = (icom['identifier'] == 'E') & (icom['com_divyild_rk']>0)
icom.loc[c1, 'com_divyild_rk_e_l'] = icom.loc[c1, 'com_divyild_rk']

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))].\
      dropna(subset=['com_divyild_rk_e_l','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
      'com_divyild_rk_e_l','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))&(icom['days_s_ex']<=20)].\
      dropna(subset=['com_divyild_rk_e_l','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
      'com_divyild_rk_e_l','BarrRet_CLIP_USD+1d', static_data = i_sd) # 

o_1 = yu.bt_cn_15(icom[(icom['datadate'].between('2017-01-01','2022-12-31'))&(icom['days_2_annual']<=20)].\
      dropna(subset=['com_divyild_rk_e_l','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
      'com_divyild_rk_e_l','BarrRet_CLIP_USD+1d', static_data = i_sd) # 




