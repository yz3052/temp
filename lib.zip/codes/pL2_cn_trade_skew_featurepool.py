﻿#$%^&* pL2_cn_trade_skew_featurepool.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 29 15:16:45 2022

@author: thzhang
"""



import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine




### get background data

i_dtk = yu.get_date_ticker_mapping()


i_gem3l = yu.get_sql('''select ticker, datadate, 
                     [SRISK],[BETA],[MOMENTUM],[SIZE],[EARNYILD],[RESVOL],[GROWTH],[DIVYILD]
                     ,[BTOP],[LEVERAGE],[LIQUIDTY],[SIZENL],[AIRLINES],[AUTOCOMP],[BANKS]
                     ,[BIOTECH],[CAPGOODS],[CHEMICAL],[COMMSVCS],[COMMUNIC],[COMPUTER],[CONSDUR]
                     ,[CONSTPP],[CONSVCS],[DIVFINAN],[DIVMETAL],[ENERGY],[FOODPRD],[FOODRETL]
                     ,[HEALTH],[HSHLDPRD],[INSURAN],[INTERNET],[MEDIA],[OILEXPL],[OILGAS]
                     ,[PHARMAC],[PRECMETL],[REALEST],[RETAIL],[SEMICOND],[SOFTWARE],[STEEL]
                     ,[TELECOM],[TRANSPRT],[UTILITY] from cndbprod.dbo.[UNIVERSE_ALL_CN_GEM3L] with (nolock)''')
c_sh = i_gem3l['ticker'].str[0].isin(['6'])
c_sz = i_gem3l['ticker'].str[0].isin(['0','3'])
i_gem3l.loc[c_sh, 'ticker'] = i_gem3l.loc[c_sh, 'ticker'] + '.SH'
i_gem3l.loc[c_sz, 'ticker'] = i_gem3l.loc[c_sz, 'ticker'] + '.SZ'



### get 5 min trade data

dates = yu.get_sql("SELECT distinct [datadate] from [CNDBPROD].[dbo].[TRADE_CN_KLINE]")

i_5min = []

for dt in dates['datadate']:
    print('.', end='')
    
    t_1min = yu.get_sql('''select Ticker, DataDate, trade_minutes, [open], prev_close, [close], v as q, pv as d
                           from [CNDBPROD].[dbo].[TRADE_CN_KLINE]
                           where datadate = '{0}' 
                           and (trade_minutes between 930 and 1500)
                           and trade_minutes!=1130
                           '''.format( dt.strftime('%Y-%m-%d') ))
    
    t_1min['hh5m'] = t_1min['trade_minutes'].apply(lambda x: 5*(x//5))
    t_1min = t_1min.sort_values(['DataDate', 'Ticker', 'hh5m'])
        
    t_5min = t_1min.groupby(['Ticker', 'DataDate', 'hh5m']).agg({'d':sum,'q':sum,'open':'first','close':'last'})
    t_5min = t_5min.reset_index()
    t_5min.columns = ['Ticker', 'DataDate', 'hh5m', 'd', 'q', 'first', 'last']
    t_5min['r_5min'] = t_5min['last'].divide(t_5min['first'])-1
    t_5min['r3_5min'] = t_5min['r_5min'].pow(3)
    t_5min['r2_5min'] = t_5min['r_5min'].pow(2)
    
    s_daily = t_5min[t_5min['hh5m'].between(1000,1500)].groupby(['Ticke
r','DataDate'])[['r2_5min','r3_5min']].sum()
    s_daily2 = t_5min[t_5min['hh5m'].between(1000,1500)].groupby(['Ticker','DataDate'])['hh5m'].count()
    
    s = s_daily.join(s_daily2, how = 'outer')
    s = s.reset_index()
    s = s.rename(columns = {'hh5m':'hh5m_cnt'})
    
    i_5min.append(s)
    
i_5min = pd.concat(i_5min, axis = 0)
c_sh = i_5min['Ticker'].str[0].isin(['6'])
c_sz = i_5min['Ticker'].str[0].isin(['0', '3'])
i_5min.loc[c_sh, 'ticker'] = i_5min.loc[c_sh, 'Ticker'] + '.SH'
i_5min.loc[c_sz, 'ticker'] = i_5min.loc[c_sz, 'Ticker'] + '.SZ'
i_5min = i_5min.rename(columns={'DataDate':'datadate'})


i_5min = i_5min.sort_values(['ticker', 'datadate'])
i_5min['skew_5min_10001500'] = i_5min['r3_5min'] / (i_5min['r2_5min']**1.5) * np.sqrt(i_5min['hh5m_cnt'])
i_5min['skew_5min_10001500_t20d'] = i_5min.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate',min_periods=10)['skew_5min_10001500'].mean().values




### combine


icom = i_dtk.merge(i_5min, on = ['ticker','datadate'], how = 'left')
icom = icom.merge(i_gem3l, on = ['ticker','datadate'], how = 'left')
icom = icom.sort_values(['ticker','datadate'])

cols_f = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL']
cols_i = ['AIRLINES','AUTOCOMP','BANKS','BIOTECH','CAPGOODS','CHEMICAL','COMMSVCS','COMMUNIC','COMPUTER','CONSDUR','CONSTPP','CONSVCS','DIVFINAN','DIVMETAL','ENERGY','FOODPRD','FOODRETL','HEALTH','HSHLDPRD','INSURAN','INTERNET','MEDIA','OILEXPL','OILGAS','PHARMAC','PRECMETL','REALEST','RETAIL','SEMICOND','SOFTWARE','STEEL','TELECOM','TRANSPRT','UTILITY']
icom['ones'] = 1

icom['skew_5min_10001500_orth'] = icom.groupby('datadate')[['ones', 'skew_5min_10001500']+cols_i+cols_f].apply(lambda x: yu.orthogonalize_cn_v3(x['skew_5min_10001500'], x[cols_f], x[cols_i], x['ones'], normal_y = True)).values
icom['skew_5min_10001500_t20d_orth'] = icom.groupby('datadate')[['ones', 'skew_5min_10001500_t20d']+cols_i+cols_f].apply(lambda x: yu.orthogonalize_cn_v3(x['skew_5min_10001500_t20d'], x[cols_f], x[cols_i], x['ones'], normal_y = True)).values


icom = icom.reset_index(drop = True)
icom = icom[['ticker', 'datadate', 'skew_5min_10001500_orth', 'skew_5min_10001500_t20d_orth']]
icom = icom.set_index(['ticker', 'datadate'])
icom.to_parquet(r'S:\TZ\backtester\feature_pool\l2_trade_skew.parquet')




