﻿#$%^&* pCNINFO_unlock2.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 25 08:54:04 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

from yz.util import uniformed_rank,  bt_cn_15, create_cn_3x3, get_sql, explore

# this script should use WIND data
# we don't have wind data yet; need to 


### get sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['ticker', 'datadate'])



### get close price

i_c = get_sql('''select s_info_windcode as ticker, trade_dt as datadate,
                 s_dq_adjclose as adjc 
                 from wind.dbo.ashareeodprices''')
i_c['datadate'] = pd.to_datetime(i_c['datadate'], format = '%Y%m%d')
i_c = i_c.sort_values('datadate')

i_c_dd = i_c['datadate'].drop_duplicates()



### get longer-term adv

i_adv = pw.get_wind_adv()



### get adjf

i_adjf = get_sql('''select trade_dt as datadate, s_info_windcode as ticker,
                    S_DQ_ADJFACTOR as adjf 
                    from wind.dbo.ashareeodprices''')
i_adjf['datadate'] = pd.to_datetime(i_adjf['datadate'], format = '%Y%m%d')
i_adjf = i_adjf.sort_values('datadate')





### get WIND unlock data


i_seo = get_sql('''select s_info_windcode as ticker, s_fellow_price as issue_price, s_fellow_amount as issue_shares, 
                S_FELLOW_INSTLISTDATE as inst_unlock_date, S_FELLOW_LISTDATE as retail_unlock_date, 
                ann_dt as datadate
                from wind.dbo.AShareSEO''') # 增发

i_seo['unlock_date'] = i_seo['inst_unlock_date']
i_seo.loc[i_seo['unlock_date'].isnull(), 'unlock_date'] = i_seo.loc[i_seo['unlock_date'].isnull(), 'retail_unlock_date']
i_seo = i_seo[i_seo['unlock_date'].notnull()]
i_seo['unlock_date'] = pd.to_datetime(i_seo['unlock_date'], format = '%Y%m%d')

i_seo['datadate'] = pd.to_datetime(i_seo['datadate'], format = '%Y%m%d')

i_seo = i_seo.merge(i_adjf,on=['ticker','datadate'], how = 'left')
i_seo = i_seo.rename(columns={'adjf':'adjf_at_disclosure'})



i_offcial_ann = get_sql('''select s_info_windcode as ticker, ann_dt as official_ann_dt 
                        from wind.dbo.AShareFreeFloatCalendar''') #限售股流通日历
i_offcial_ann['official_ann_dt'] = pd.to_datetime(i_offcial_ann['official_ann_dt'], format = '%Y%m%d')



### loop to calculate metrics batch 1



o_sum = []

for dt in pd.date_range(start='2016-01-01', end='2020-12-31'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    t_c_recent = i_c[i_c['datadate']==i_c_dd[i_c_dd<=dt].max()].ren
ame(columns = {'adjc':'adjc_recent'})
    t_c_recent = t_c_recent[['ticker','adjc_recent']]
    
    t_frcst_unlock = i_seo[(i_seo['datadate']<=dt) & (i_seo['unlock_date']>dt+pd.to_timedelta('3 days'))]
    t_frcst_unlock = t_frcst_unlock.merge(t_c_recent, on = 'ticker', how = 'left')
    t_frcst_unlock = t_frcst_unlock.sort_values(['ticker','unlock_date'])
    t_frcst_unlock['datadate'] = dt
    
    
    # get data for the next unlock 
    # days to the next unlock
    # unlock shares of the next unlock 
    t_frcst_unlock_n1 = t_frcst_unlock.groupby('ticker').head(1)
    t_frcst_unlock_n1['flag_n1'] = 1
    t_frcst_unlock_n1['days2n1'] = (t_frcst_unlock_n1['unlock_date']-t_frcst_unlock_n1['datadate']).dt.days
    t_frcst_unlock_n1['unlock_shares_n1'] = t_frcst_unlock_n1['issue_shares']
    
    s_n1 = t_frcst_unlock_n1[['ticker','unlock_shares_n1','days2n1','adjc_recent']]
    
    # get data for the 2nd next unlock 
    # days to the 2nd next unlock 
    # unlock shares of the 2nd next unlock 
    t_frcst_unlock_n2 = t_frcst_unlock.groupby('ticker').head(2)
    t_frcst_unlock_n2_cnt = t_frcst_unlock_n2.groupby('ticker')['unlock_date'].nunique().reset_index()
    t_frcst_unlock_n2_cnt = t_frcst_unlock_n2_cnt[t_frcst_unlock_n2_cnt['unlock_date']==2]
    t_frcst_unlock_n2 = t_frcst_unlock_n2[t_frcst_unlock_n2['ticker'].isin(t_frcst_unlock_n2_cnt['ticker'].tolist())]
    t_frcst_unlock_n2 = t_frcst_unlock_n2.drop_duplicates(subset='ticker', keep = 'last')
    t_frcst_unlock_n2['flag_n2'] = 1
    t_frcst_unlock_n2['days2n2'] = (t_frcst_unlock_n2['unlock_date']-t_frcst_unlock_n2['datadate']).dt.days
    t_frcst_unlock_n2['unlock_shares_n2'] = t_frcst_unlock_n2['issue_shares']
    
    s_n2 = t_frcst_unlock_n2[['ticker','unlock_shares_n2','days2n2']]
    
    # output
    t_sum = s_n1.merge(s_n2, on = 'ticker', how = 'outer')
    t_sum['datadate'] = dt
    o_sum.append(t_sum)
    
o_sum = pd.concat(o_sum, axis = 0)





#-------------------------------------------------------------------------
### combine

icom = i_sd.merge(o_sum, on = ['datadate','ticker'], how = 'left')
icom = icom.merge(i_adv, on = ['datadate','ticker'], how = 'left')

icom = icom.sort_values(['ticker','datadate'])




### n1 unlock, unlock/adv

icom['unlock_dv_adv'] = icom['unlock_shares_n1'].divide(icom['adv_t130d'])*10000 # avgVadj
icom.loc[icom['unlock_dv_adv'].abs()>1, 'unlock_dv_adv'] = 1

c1 = icom['days2n1'].between(3, 15)
icom['days2n1_dv_v_sgnl'] = np.nan
icom.loc[c1, 'days2n1_dv
_v_sgnl'] = - icom.loc[c1, 'unlock_dv_adv']

c1 = icom['days2n1'].between(3, 60)
icom['unlock_dv_v_sgnl2'] = np.nan
icom.loc[c1, 'unlock_dv_v_sgnl2'] = - icom.loc[c1, 'unlock_dv_adv']

icom['unlock_dv_v_sgnl3'] = np.sign(icom['unlock_dv_v_sgnl2'])

icom.loc[icom['unlock_dv_v_sgnl2']<0, 'flag_existing_sgnl'] = 1
icom['unlock_dv_v_sgnl4'] = icom.groupby('ticker')['unlock_dv_v_sgnl2'].ffill(limit = 40)
icom.loc[icom['flag_existing_sgnl']==1, 'unlock_dv_v_sgnl4'] = np.nan

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['days2n1_dv_v_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'days2n1_dv_v_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['unlock_dv_v_sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'unlock_dv_v_sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.31 / 1.93
