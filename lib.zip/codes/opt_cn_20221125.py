﻿#$%^&* opt_cn_20221125.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 26 10:23:12 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import os
import datetime

import util as yu
import opt_cn_lib as opt

# input: a signal
# output: PNL of optimized portfoliko


### get alpha

i_sd = yu.get_sd_cn_1800()



root = '/export/dataprod/Feature_Pool_CN'
i_files = os.listdir(root)
i_files = [i for i in i_files if 'smtprod_enrich_' in i]

i_feature = [pd.concat([pd.read_parquet(root+'/'+f+'/'+d) for d in os.listdir(root+'/'+f)], axis=0)
             for f in i_files]


i_all = pd.DataFrame(columns = ['Ticker', 'DataDate', 'T-1d'])
for ft in i_feature:
    cols_drop = [c for c in ft.columns.tolist() if ('_t5d' in c) or ('_t10d' in c) or ('_t40d' in c) or ('_t60d' in c)]
    ft =ft.drop(columns = cols_drop)
    i_all = i_all.merge(ft, on = ['Ticker', 'DataDate', 'T-1d'], how = 'outer')
i_feature = None

icom = i_all.merge(i_sd, on = ['T-1d', 'Ticker','DataDate'], how = 'inner')
icom = icom.sort_values(['Ticker', 'DataDate'])


cols = ['shsz_t1d_orthgem3l_sgnl',
       'shsz_t20d_orthgem3l_sgnl', 'st_t1d_orthgem3l_sgnl',
       'st_t20d_orthgem3l_sgnl', 'canc_t1d_orthgem3l_sgnl',
       'canc_t20d_orthgem3l_sgnl', 'd3s_t1d_orthgem3l_sgnl',
       'd3s_t20d_orthgem3l_sgnl', 'enft_sgnl', 'enugdg_sgnl', 'gb_sgnl',
       'jm_sgnl', 'd60s_t1d_orthgem3l_sgnl', 'd60s_t20d_orthgem3l_sgnl',
       'nb_sgnl', 'cav_t1d_orthgem3l_sgnl', 'cav_t20d_orthgem3l_sgnl',
       'lt_t1d_orthgem3l_sgnl', 'lt_t20d_orthgem3l_sgnl',
       'act_t1d_orthgem3l_sgnl', 'act_t20d_orthgem3l_sgnl',
       'bar_t1d_orthgem3l_sgnl', 'bar_t20d_orthgem3l_sgnl',
       'd2m_t1d_orthgem3l_sgnl', 'd2m_t20d_orthgem3l_sgnl',
       'pvar_t1d_orthgem3l_sgnl', 'pvar_t20d_orthgem3l_sgnl']
icom['yhat'] = icom[cols].mean(axis=1)
icom['yhat_t10d'] = icom.groupby('Ticker').rolling(datetime.timedelta(days=14),on='DataDate',min_periods=1)['yhat'].mean().values 

icom['alpha'] = icom.groupby('DataDate')['yhat_t10d'].apply(yu.uniformed_rank)

opt.serchopt(50e6, 0.5, 0.3, True, True, '20190101', '20211231', icom , False)
opt.serchopt(50e6, 0.5, 0.3, True, True, '20220101', '20221001', icom , False)



