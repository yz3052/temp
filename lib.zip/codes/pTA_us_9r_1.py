﻿#$%^&* pTA_us_9r_1.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat Jul 31 08:27:17 2021

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import ta

### get sd

i_sd = yu.get_sd(column_type = 'backtest',extra_column_lst=['MC_l1d']) #T-1d -> datadate
i_sd = i_sd.sort_values(['ticker','datadate'])
i_sd['bret_px'] = i_sd.groupby('ticker')['BarrRet_SRISK-1d'].cumsum()

i_bret = i_sd[['ticker', 'datadate', 'bret_px']]

### get mkt data
i_eod = yu.get_mkt_data()

i_eod = i_eod.rename(columns={'c':'c_adj','h':'h_adj','l':'l_adj','o':'o_adj'})
i_eod = i_eod[['ticker','datadate','c_adj','h_adj','l_adj','o_adj']]



### calculate 9r for bret
icom = i_bret.merge(i_eod, on = ['ticker', 'datadate'], how = 'inner')

c_dn_89 = ((icom['l_adj']<icom['l_adj'].shift(2))&(icom['l_adj']<icom['l_adj'].shift(3)))|\
              ((icom['l_adj'].shift()<icom['l_adj'].shift(2))&(icom['l_adj'].shift()<icom['l_adj'].shift(3)))
c_dn_89_2 = ((icom['bret_px']<icom['bret_px'].shift(2))&(icom['bret_px']<icom['bret_px'].shift(3)))|\
            ((icom['bret_px'].shift()<icom['bret_px'].shift(2))&(icom['bret_px'].shift()<icom['bret_px'].shift(3)))
c_dn_89_3 = (icom['c_adj']-icom['l_adj'])>0.25*(icom['o_adj']-icom['c_adj']).abs()
c_dn_6 = icom['bret_px'].shift(3)<icom['bret_px'].shift(7)
c_dn_12 = (icom['bret_px'].shift(7)<icom['bret_px'].shift(11))&(icom['bret_px'].shift(8)<icom['bret_px'].shift(12))
icom.loc[c_dn_89 & c_dn_89_2 & c_dn_89_3 & c_dn_6 & c_dn_12, '9r_bret'] = -1

c_up_89 = ((icom['h_adj']>icom['h_adj'].shift(2))&(icom['h_adj']>icom['h_adj'].shift(3)))|\
          ((icom['h_adj'].shift()>icom['h_adj'].shift(2))&(icom['h_adj'].shift()>icom['h_adj'].shift(3)))
c_up_89_2 = ((icom['bret_px']>icom['bret_px'].shift(2))&(icom['bret_px']>icom['bret_px'].shift(3)))|\
            ((icom['bret_px'].shift()>icom['bret_px'].shift(2))&(icom['bret_px'].shift()>icom['bret_px'].shift(3)))
c_up_89_3 = (-icom['c_adj']+icom['h_adj'])>0.25*(icom['o_adj']-icom['c_adj']).abs()
c_up_6 = icom['bret_px'].shift(3)>icom['bret_px'].shift(7)
c_up_12 = (icom['bret_px'].shift(7)>icom['bret_px'].shift(11))&(icom['bret_px'].shift(8)>icom['bret_px'].shift(12))
icom.loc[c_up_89 & c_up_89_2 & c_up_89_3 & c_up_6 & c_up_12, '9r_bret'] = 1

### calculate 9r for OHLC
c_dn_89 = ((icom['l_adj']<icom['l_adj'].shift(2))&(icom['l_adj']<icom['l_adj'].shift(3)))|\
              ((icom['l_adj'].shift()<icom['l_adj'].shift(2))&(icom['l_adj'].shift()<icom['l_adj'
].shift(3)))
c_dn_6 = icom['c_adj'].shift(3)<icom['c_adj'].shift(7)
c_dn_12 = (icom['c_adj'].shift(7)<icom['c_adj'].shift(11))&(icom['c_adj'].shift(8)<icom['c_adj'].shift(12))
icom.loc[c_dn_89 & c_dn_6 & c_dn_12, '9r'] = -1

c_up_89 = ((icom['h_adj']>icom['h_adj'].shift(2))&(icom['h_adj']>icom['h_adj'].shift(3)))|\
          ((icom['h_adj'].shift()>icom['h_adj'].shift(2))&(icom['h_adj'].shift()>icom['h_adj'].shift(3)))
c_up_6 = icom['c_adj'].shift(3)>icom['c_adj'].shift(7)
c_up_12 = (icom['c_adj'].shift(7)>icom['c_adj'].shift(11))&(icom['c_adj'].shift(8)>icom['c_adj'].shift(12))
icom.loc[c_up_89 & c_up_6 & c_up_12, '9r'] = 1    


### use long kdj to filter entry
icom['rsi_d_l'] = icom.groupby('ticker')['bret_px'].apply(lambda x: ta.momentum.stochrsi_d(x, window = 60, smooth1 = 10, smooth2 = 5)).values

### use short kdj to decide exit
icom['rsi_d_s'] = icom.groupby('ticker')['bret_px'].apply(lambda x: ta.momentum.stochrsi_d(x, window = 15, smooth1 = 5, smooth2 = 5)).values


### combine
icom = icom.merge(i_sd, on = ['ticker', 'datadate'], how = 'inner')




#---------------------------------------
### backtest

### plain
# holding 2 days isthe best

icom2 = icom.copy()
icom2['_9r_bret'] = - icom2['9r_bret']
icom2['holding'] = icom2.groupby('ticker')['_9r_bret'].ffill(10).values
icom2['holding2'] = icom2.groupby('ticker')['_9r_bret'].ffill(20).values
icom2['holding3'] = icom2.groupby('ticker')['_9r_bret'].ffill(30).values
icom2['holding4'] = icom2.groupby('ticker')['_9r_bret'].ffill(5).values
icom2['holding5'] = icom2.groupby('ticker')['_9r_bret'].ffill(2).values
icom2['holding6'] = icom2.groupby('ticker')['_9r_bret'].ffill(1).values

o_1 = yu.bt(icom2[(icom2['datadate']<='2019-12-31') ].\
            dropna(subset=['holding','BarrRet_SRISK+1d']).drop_duplicates(subset=['ticker','datadate']),
            'holding','BarrRet_SRISK+1d', sgnl_before_3pm = False, static_data = i_sd) #prcs 0.59 / -0.15



o_1 = yu.bt(icom2[(icom2['datadate']<='2019-12-31') ].\
            dropna(subset=['holding5','BarrRet_SRISK+1d']).drop_duplicates(subset=['ticker','datadate']),
            'holding5','BarrRet_SRISK+1d', sgnl_before_3pm = False, static_data = i_sd) #prcs 0.72 / -0.59


o_1 = yu.bt(icom2[(icom2['datadate']<='2019-12-31') ].\
            dropna(subset=['holding2','BarrRet_SRISK+1d']).drop_duplicates(subset=['ticker','datadate']),
            'holding2','BarrRet_SRISK+1d', sgnl_before_3pm = False, static_data = i_sd) #prcs 0.73 / 0.02


