﻿#$%^&* pWIND_strat_collateral.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 26 08:14:29 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

# 股权质押比例


### get sd

i_sd = pw.get_ashare_hk_sd_v2()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','volatility','spread','BarrRet_SRISK_USD+1d','FX_LAST']]

### get collateral

i_pledge = yu.get_sql('''select * from wind.dbo.ASharePledgeproportion''')

i_pledge = i_pledge.rename(columns={'S_INFO_WINDCODE': 'ticker', 'S_ENDDATE': 'datadate'})
i_pledge['datadate'] = pd.to_datetime(i_pledge['datadate'], format = '%Y%m%d')
i_pledge = i_pledge.merge(i_sd_map[['ticker','datadate','GIND']],on=['ticker','datadate'],how='left')
#i_pledge['S_PLEDGE_RATIO'].hist()

i_pledge['pledge_rk'] = i_pledge.groupby('datadate')['S_PLEDGE_RATIO'].apply(yu.uniformed_rank).values
i_pledge['pledge_indrk'] = i_pledge.groupby(['datadate','GIND'])['S_PLEDGE_RATIO'].apply(yu.uniformed_rank).values

### combine
icom = i_sd_map.merge(i_pledge, on = ['ticker', 'datadate'], how = 'left')


### high pledge

icom2 = icom.copy()
icom2.loc[icom2['pledge_rk']>0.8, 'sgnl'] = -1

o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs  -0.96 / -2.18

### low pledge 
icom2 = icom.copy()
icom2.loc[icom2['pledge_rk']<-0.8, 'sgnl'] = 1

o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs  -0.96 / -2.18


### pledge - ind-rk

icom2 = icom.copy()
icom2.loc[icom2['pledge_rk']<-0.8, 'sgnl'] = 1

o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31')].\
            dropna(subset=['pledge_indrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'pledge_indrk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs  -0.96 / -2.18

