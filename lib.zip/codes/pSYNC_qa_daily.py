﻿#$%^&* pSYNC_qa_daily.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May  2 14:40:01 2023

@author: thzhang
"""



import pandas as pd
import os
import util as yu


root = '/dat/summit_capital/TZ/PROD_FEATURES/'

folders = os.listdir(root)

o_table = []

for fd in folders:
    
    i_files = os.listdir(root + fd)    
    max_file = max(i_files)    
    t_data = pd.read_parquet(root + fd + '/' + max_file)    
    t_data_feat = t_data.drop(columns = [i for i in t_data.columns.tolist() if i in ['Ticker', 'T-1d', 'DataDate']])
    
    o_table.append({'name': fd.replace('featurepool_cn_desc_', ''),
                    'most recent': max_file,
                    'shape': str(t_data.shape[0])+'x'+str(t_data.shape[1]),
                    'notnan cnt': t_data_feat.notnull().any(axis=1).sum() })
    
o_table = pd.DataFrame(o_table)
print(o_table)



# checked: featurepool_cn_desc_corpact_unlock



# check column names
# root = '/dat/summit_capital/TZ/PROD_FEATURES/'
# root = '/dat/summit_capital/TZ/PROD_FEATURES_ENRICH/1p8K_inspection/'
# folders = os.listdir(root)
# o_table = []
# for fd in folders:
#     i_files = os.listdir(root + fd)
#     max_file = max(i_files)
#     print(pd.read_parquet(root + fd+'/'+max_file).columns)
