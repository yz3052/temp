﻿#$%^&* ml_cn_xgboost_20221110a.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 14 16:57:14 2022

@author: fgao
"""

import pandas as pd
import numpy as np
import datetime

import os
import gc
import sys

from sqlalchemy import create_engine
import urllib


#import ML_multi_class.learn_w_xgboost as learn_w_xgboost
import ML.learn_w_xgboost as learn_w_xgboost
from featurepool_enrich_lib import rerank

# =============================================================================
# 
# =============================================================================


year = int(sys.argv[3])
month = int(sys.argv[4])

ddl_str = (datetime.datetime(year, month, 1) + datetime.timedelta(days=40)).strftime('%Y-%m-%d')
ddl_str_2y6m = (datetime.datetime(year, month, 1) - datetime.timedelta(days=876)).strftime('%Y-%m-%d')


conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))





# =============================================================================
### get universe
# =============================================================================


df_cd = pd.read_sql('''
                    select distinct TradeDate_next as DataDate
                    from CNDBPROD.dbo.Calendar_Dates_CN
                    where TradeDate_next >= '2015-01-01' and TradeDate_next<= '{0}'
                    '''.format(ddl_str),conn)
df_cd = df_cd.sort_values('DataDate')
df_cd = df_cd.reset_index(drop=True)
df_cd['T-1d'] = df_cd['DataDate'].shift(1)
df_cd['DataDate_p1d'] = df_cd['DataDate'].shift(-1)
df_cd = df_cd.dropna()



df_universe_all = pd.read_sql('''
                        select DataDate as [T-1d], Ticker, avgPVadj_USD as avgPVadj, spread, 
                        cccny_vol_21d as [cc_vol_21d], SRISK
                        from CNDBPROD.dbo.universe_all_cn_gem3l 
                        where DataDate <= '{0}'
                        and DataDate >= '{1}'
                        '''.format(ddl_str, ddl_str_2y6m), conn)
df_universe_all = df_universe_all.drop_duplicates(subset=['Ticker','T-1d'],keep='last')
df_universe_1800 = pd.read_sql('''
                        select DataDate as [T-1d], Ticker 
                        from CNDBPROD.dbo.universe_csi1800
                        where DataDate <= '{0}'
                        and DataDate >= '{1}'
                        '''.format(ddl_s
tr, ddl_str_2y6m), conn)                        
df_universe_1800 = df_universe_1800.drop_duplicates(subset=['Ticker','T-1d'],keep='last')
df_universe = df_universe_1800.merge(df_universe_all, on = ['T-1d', 'Ticker'], how = 'left')
df_universe_all = None
df_universe_1800 = None
                        

               
df_ret_20d = pd.read_sql('''select  DataDate, Ticker, BarrRet_CLIP1d, BarrRet_CLIP20d
                         from CNDBPROD.dbo.BARRA_GEM3L_YRRET_CSI1800
                         where DataDate <= '{0}' 
                         and DataDate >= '{1}' 
                         '''.format(ddl_str, ddl_str_2y6m), conn)


                
df_universe = pd.merge(df_universe, df_cd, on=['T-1d'], how='inner')
df_universe = pd.merge(df_universe, df_ret_20d, on=['DataDate','Ticker'], how='left')
df_universe = df_universe.reset_index(drop=True)
df_cd = None
df_ret = None
gc.collect()


df_universe['BarrRet_CLIP20d_category'] = np.nan
df_universe.loc[df_universe['BarrRet_CLIP20d']<-0.02,'BarrRet_CLIP20d_category'] = 0
df_universe.loc[df_universe['BarrRet_CLIP20d'].between(-0.02,+0.02),'BarrRet_CLIP20d_category'] = 1
df_universe.loc[df_universe['BarrRet_CLIP20d']>0.02, 'BarrRet_CLIP20d_category'] = 2




# =============================================================================
### get features
# =============================================================================


root = '/export/dataprod/Feature_Pool_CN'
i_folders = os.listdir(root)
i_folders = [i for i in i_folders if i[:19]=='featurepool_enrich_']
i_folders = [i for i in i_folders if not 'odbk' in i]


i_feature = []
for fd in i_folders:
    print(fd)
    t_feature = pd.concat([pd.read_parquet(os.path.join(root, fd, i)) for i in os.listdir(os.path.join(root, fd))], axis=0)
    t_feature = t_feature.drop_duplicates(subset=['Ticker','T-1d','DataDate'], keep='last')
    t_feature = t_feature[t_feature['DataDate'].le(ddl_str) & t_feature['DataDate'].ge(ddl_str_2y6m)]
    i_feature.append(t_feature)
    t_feature = None


i_all = pd.DataFrame(columns = ['Ticker', 'DataDate', 'T-1d'])
for ft in i_feature:
    i_all = i_all.merge(ft, on = ['Ticker', 'DataDate', 'T-1d'], how = 'outer')


i_all = i_all.merge(df_universe, on = ['T-1d', 'Ticker','DataDate'], how = 'inner')
i_all['clip'] = i_all['avgPVadj'].apply(lambda r: min([r*0.01,1e6]))
i_all['wts'] = i_all['clip']
i_all= i_all.dropna(subset = ['wts'])



i_feature = None
gc.collect()


# ====================================================
=========================
### calendar
# =============================================================================


df_cd = pd.read_sql('''
                    select distinct TradeDate_next as DataDate
                    from CNDBPROD.dbo.Calendar_Dates_CN
                    ''',conn)
df_cd = df_cd.sort_values('DataDate')
df_cd = df_cd.reset_index(drop=True)
df_calendars = df_cd['DataDate'].tolist()


# =============================================================================
### configs
# =============================================================================

config_feature = i_all.columns.tolist()
config_feature = [i for i in config_feature if i.endswith('sgnl')]

config_mono = {i:1 for i in config_feature}


configs = {
         'data_name': 'df_data',
         'universe_name': 'df_universe',
         'wts_type': 'clip',
         'feature_tables': [],
         'universe_table_name': 'UNIVERSE_T1800_CN_GEM3L',
         'ret_table_name': 'BARRA_GEM3L_YRRET',
         'startdate': '20160101',
         'enddate': '20221231',
         'used_ret_col': 'BarrRet_CLIP20d',
         'fold': 10,
         'purged_days': 22,
         'rolling_days': 252,
         'features': config_feature, 
         'monotone_features': config_mono,
         'metric_method': 'rscore', #'nll' for reg:logistic, 'rscore' for reg:sqaurederror
         'loss_function': 'reg:squarederror', #'reg:logistic','reg:squarederror'
         'eta_min': 0.01,
         'eta_max': 0.2,
         'gamma_min': 0,
         'gamma_max': 1000,
         'md_min': 2,
         'md_max': 12,
         'mcw_min': 1 ,
         'mcw_max': 1000,
         'subsample_min': 0.5,
         'subsample_max': 1,
         'colsample_bytree_min': 0.5,
         'colsample_bytree_max': 1,
         'colsample_bylevel_min': 0.5,
         'colsample_bylevel_max': 1,
         'colsample_bynode_min': 0.5,
         'colsample_bynode_max': 1,
         'lambda_min': 0,
         'lambda_max': 1000,
         'alpha_min': 0,
         'alpha_max': 1000,
         'esr': 100,
         'n_trials': 20,
         'tot_waittime': 600,
         'grow_policy': 'depthwise',
         'learning_method':'gbtree',
         'missing_data':'NaN',
         'importance_type': 'gain'
         }

 




# =============================================================================
# 
# =============================================================================

save_path = '/dat/summit_capital/TZ/backtester/xg/test_enrich_'+'20221110a/'

if not os.path.exists(save_path):
    os.mkdir(save_path)

date_windows = df_cd[['DataDate']]
date_windows['year'] = date_windows['DataDate'].apply(lambda r: r.year)
date_windows['month'] = date_windows['DataDate'].apply(lambda r: r.month)

alphadates = date_windows[ (date_windows['year'] == year) & (date_windows['month'] == month) ]
alphadates = alphadates['DataDate'].tolist()
alphadates.sort()

learn_w_xgboost.get_daily_alpha(i_all, df_universe, df_calendars, alphadates, configs, save_path)


# for f in os.listdir(save_path):
#     if f.endswith('.json'):
#         os.remove(os.path.join(save_path, f))


### cmd
for year in [2020]:
    for month in range(1,13):
        cmd = 'python /dat/summit_capital/TZ/codes/ml_cn_xgboost_20221110a.py '
        cmd = cmd + ' skip skip ' + str(year) + ' ' + str(month) + ' &'
        print(cmd, end = ' ')




