﻿#$%^&* pDataBurn_cn_1.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 07:27:42 2022

@author: thzhang
"""




import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw

import datetime

import os


# There is some alpha, but this only covers 20~30 on an average day




### sd 

i_sd = pw.get_ashare_t2000_sd()
i_sd = i_sd.sort_values(['datadate'])


### data burn monthly

i_db = pd.read_excel(r"S:\TZ\China Data Hunt\databurn\Test data of Databurning month- blg  ticker 2017-2022.3.xlsx", sheet_name = 'Data')

i_db['ticker'] = i_db['stock_code'].str.split(':').str[0]
c_sh = i_db['ticker'].str[0].isin(['6'])
c_sz = i_db['ticker'].str[0].isin(['0','3'])
i_db.loc[c_sh, 'ticker'] = i_db.loc[c_sh, 'ticker'] + '.SH'
i_db.loc[c_sz, 'ticker'] = i_db.loc[c_sz, 'ticker'] + '.SZ'

i_db['datadate'] = pd.to_datetime(i_db['update_date'], format='%m/%d/%Y')
i_db = i_db.sort_values(['ticker', 'datadate'])
i_db['sales_t3m'] = i_db.groupby('ticker').rolling(3)['sale_amount'].mean().values
i_db['sales_t3m_yoy'] = i_db['sales_t3m'] / i_db.groupby('ticker')['sales_t3m'].shift(12)
i_db['sales_t1m_yoy'] = i_db['sale_amount'] / i_db.groupby('ticker')['sale_amount'].shift(12)
i_db = i_db.sort_values('datadate')


### data burn weekly

i_dbw = pd.read_excel(r'Z:\125311\DATA-13521\China_ecommerce_consumer_brand_tracker\Test data of Databurning week 2018.11-2022.6.xlsx',
                      sheet_name = '数据')
i_dbw = i_dbw[i_dbw['stock_code'].str[-2:]!='HK']


### combine

icom = pd.merge_asof(i_sd, i_db, by='ticker', on = 'datadate', tolerance = pd.to_timedelta('30 days'))
icom = icom.sort_values(['ticker', 'datadate'])

icom['sales_t3m_yoy_bk'] = icom.groupby('datadate')['sales_t3m_yoy'].apply(lambda x: yu.pdqcut(x,bins=10)).values
#yu.create_cn_3x3(icom, ['sales_t3m_yoy_bk'], 'sales_t3m_yoy') # 0 -4 +7.3

icom['sgnl_t3m_yoy'] = np.nan
icom.loc[icom['sales_t3m_yoy_bk']==9, 'sgnl_t3m_yoy'] = 1
o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2017-01-01','2021-06-30')].\
            dropna(subset=['sgnl_t3m_yoy','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_t3m_yoy','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.78 / 1.67



icom['sales_t1m_yoy_bk'] = icom.groupby('datadate')['sales_t1m_yoy'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['sales_t1m_yoy_bk'], 'sales_t1m_yoy') # close to mono: -4 +4.7


icom['sgnl_t1m_yoy'] = np.nan
icom.loc[icom['sales_t1m_yoy_bk']==9, 'sgnl_t1m_yoy
'] = 1
o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2017-01-01','2021-06-30')].\
            dropna(subset=['sgnl_t1m_yoy','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_t1m_yoy','BarrRet_CLIP_USD+1d', static_data = i_sd) # 
