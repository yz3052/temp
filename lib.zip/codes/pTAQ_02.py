﻿#$%^&* pTAQ_02.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  9 12:16:37 2020

@author: thzhang
"""

from yz import get_sql, get_sql_prod, tic, toc
import pandas as pd

import datetime
datetime.date.today().year%100


# this script generates the daily bid ask spread by stocks and datadate

# daily spread

o_data = pd.DataFrame()

for i in range(10,21):
    print (i)
    tic()
    
    t_data = get_sql_prod('''select Datadate, Ticker, avg((ask-bid)/(ask+bid)*2) 
                            from TAQ_NBBO_{0} 
                            where hour >= 10 and hour*100+min <= 1600 and ask >= bid
                            and bid>0 and ask>0
                            group by Datadate, Ticker'''\
                            .format( str(i) ))
    
    o_data = o_data.append(t_data, sort = False)
    toc()
    
o_data.columns = ['Datadate', 'Ticker', 'Spread']
o_data.to_csv(r'S:/Data/TAQ/daily_bidask_spead.csv', index = False)

#o_data = pd.read_csv(r'S:/Data/TAQ/daily_bidask_spead.csv')

# 30-day spread MA

o_data = o_data.sort_values(['Ticker','Datadate'])
o_data['Spread_30d'] = o_data.groupby('Ticker')['Spread'].rolling(30).mean().values

o_data[['Datadate','Ticker','Spread_30d']].to_csv(r'S:/Data/TAQ/daily_bidask_spead_30d.csv', index = False)


'''
create table TAQ_SPREAD_DAILY (
DataDate datetime,
Ticker varchar(50),
Spread float)

bcp [TZDBPROD].[dbo].[TAQ_SPREAD_DAILY] in "S:\Data\TAQ\daily_bidask_spead.csv" -c -t  , -S summitsqldb -U AD\thzhang -T -F 2 

create table TAQ_SPREAD_30d (
DataDate datetime,
Ticker varchar(50),
Spread float)

bcp [TZDBPROD].[dbo].[TAQ_SPREAD_30d] in "S:\Data\TAQ\daily_bidask_spead_30d.csv" -c -t  , -S summitsqldb -U AD\thzhang -T -F 2 

'''

# in order to check correlation, test correlation between taq spread and static data spread
i_sd = get_sql("select ticker, datadate, spread from [BackTest].[dbo].Static_Data_Daily")
i_tk = i_sd['ticker'].unique().tolist()
i_taq = get_sql_prod('''select ticker, datadate, spread as spread_taq 
                        from  [TZDBPROD].[dbo].[TAQ_SPREAD_DAILY] 
                        where ticker in ('{0}') '''.format("','".join(i_tk)))
i1 = i_taq.merge(i_sd, on = ['ticker', 'datadate'], how = 'inner')

# negative spread
i1[i1['spread_taq']<0]

i_sd['spread'][i_sd['spread']<0.005].hist()
i1['spread_taq'][i1['spread_taq']<0.005].hist()

# distro of spread and spread_taq

i1['spread_taq'][i1['spread_taq']<0.1].hist(bins = 100)
i1['spread'][i1['spread']<0.1].hist(bins = 100)


# c
orr between static spread and taq spread 
i1[['spread','spread_taq']].corr()

i_tk_corr = i1.groupby('ticker')[['spread','spread_taq']].apply(lambda x: x.corr().iloc[0,1])
i_tk_corr.hist(bins=100)

# corr between MA(static spread) and MA(taq spread )
i1 = i1.sort_values(['ticker','datadate'])
i1['spread_taq_ma'] = i1.groupby('ticker')['spread_taq'].rolling(60).mean().values
i2 = i1.dropna(subset=['spread_taq_ma','spread'])
i2[['spread','spread_taq_ma']].corr()


i_tk_corr2 = i2.groupby('ticker')[['spread','spread_taq_ma']].apply(lambda x: x.corr().iloc[0,1])
i_tk_corr2.hist(bins=100)

# check ticker with very low corr
i_nvtr = i1[i1.ticker=='NVTR']
i_nvtr[['spread','spread_taq']].plot()

