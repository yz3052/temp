﻿#$%^&* pL2_cn_orderbook_03.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  4 10:43:27 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine


#  This studies price orderbook-quantity correlation


### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])



### order book metrics

i_odbk3 = yu.get_q("get `:/export/datadev/Data/SHSZ/ORDER_metrics/orderbook_metrics_batch1_03")

i_odbk3['code'] = i_odbk3['code'].str.decode('utf8')
c_sh = i_odbk3['code'].str[0].isin(['6'])
c_sz = i_odbk3['code'].str[0].isin(['0','3'])
i_odbk3.loc[c_sh, 'ticker'] = i_odbk3.loc[c_sh, 'code'] + '.SH'
i_odbk3.loc[c_sz, 'ticker'] = i_odbk3.loc[c_sz, 'code'] + '.SZ'
i_odbk3['datadate'] = pd.to_datetime(i_odbk3['date'])
i_odbk3 = i_odbk3.sort_values(['ticker', 'datadate'])


### combine


icom = i_sd.merge(i_odbk3, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])
COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']


cs = ['bid_avgV_5m_corr_withP', 'bid_chgV_5m_corr_withP', 'ask_avgV_5m_corr_withP', 
      'ask_chgV_5m_corr_withP', 'ba_avgV_5m_corr_withP', 'ba_absChgV_5m_corr_withP',
      'ba_netChgV_5m_corr_withP']
for c in cs:
    icom[c+'_10001500_bk'] = icom.groupby('datadate')[c+'_10001500'].apply(lambda x: yu.pdqcut(x,bins=10)).values
    yu.create_cn_3x3(icom, [c+'_10001500_bk'], c+'_10001500')
    
icom['baratio_5m_corr_withP_10001500'] = icom.groupby('datadate')['baratio_5m_corr_withP_10001500'].apply(yu.uniformed_rank).values
icom['baratio_5m_corr_withP_10001500_bk'] = icom.groupby('datadate')['baratio_5m_corr_withP_10001500'].apply(lambda x: yu.pdqcut(x,bins=10)).values
# yu.create_cn_3x3(icom, ['baratio_5m_corr_withP_10001500_bk'], 'baratio_5m_corr_withP_10001500') # random

    
icom['ask_avgV_5m_corr_withP_10001500_orth'] = icom.groupby('datadate')[['ask_avgV_5m_corr_withP_10001500']+COLS].apply(lambda x: yu.orthogonalize_cn(x['ask_avgV_5m_corr_withP_10001500'], x[COLS])).values
icom['ask_avgV_5m_corr_withP_10001500_orth_bk'] = icom.groupby('datadate')['ask_avgV_5m_corr_withP_10001500_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ask_avgV_5m_corr_withP_10001500_orth_sgnl'] = - icom.groupby('datadate')['ask_avgV_5m_corr_withP_10001500_orth'].apply(yu.uniformed_rank).values
icom['ask_avgV_5m_corr_withP
_10001500_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ask_avgV_5m_corr_withP_10001500_orth'].mean().values
icom['ask_avgV_5m_corr_withP_10001500_orth_t20d_sgnl'] = - icom.groupby('datadate')['ask_avgV_5m_corr_withP_10001500_orth_t20d'].apply(yu.uniformed_rank).values
# yu.create_cn_3x3(icom, ['ask_avgV_5m_corr_withP_10001500_orth_bk'], 'ask_avgV_5m_corr_withP_10001500_orth')
# +2 -5

icom['ba_avgV_5m_corr_withP_10001500_orth'] = icom.groupby('datadate')[['ba_avgV_5m_corr_withP_10001500']+COLS].apply(lambda x: yu.orthogonalize_cn(x['ba_avgV_5m_corr_withP_10001500'], x[COLS])).values
icom['ba_avgV_5m_corr_withP_10001500_orth_bk'] = icom.groupby('datadate')['ba_avgV_5m_corr_withP_10001500_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['ba_avgV_5m_corr_withP_10001500_orth_sgnl'] = - icom.groupby('datadate')['ba_avgV_5m_corr_withP_10001500_orth'].apply(yu.uniformed_rank).values
icom['ba_avgV_5m_corr_withP_10001500_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['ba_avgV_5m_corr_withP_10001500_orth'].mean().values
icom['ba_avgV_5m_corr_withP_10001500_orth_t20d_sgnl'] = - icom.groupby('datadate')['ba_avgV_5m_corr_withP_10001500_orth_t20d'].apply(yu.uniformed_rank).values
# yu.create_cn_3x3(icom, ['ba_avgV_5m_corr_withP_10001500_orth_bk'], 'ba_avgV_5m_corr_withP_10001500_orth')



o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ask_avgV_5m_corr_withP_10001500_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_avgV_5m_corr_withP_10001500_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd)
# 1.84 / -19.35

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ask_avgV_5m_corr_withP_10001500_orth_t20d_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ask_avgV_5m_corr_withP_10001500_orth_t20d_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd)
# 1.52 / -2.11

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['ba_avgV_5m_corr_withP_10001500_orth_sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'ba_avgV_5m_corr_withP_10001500_orth_sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd)
# 1.34 / -20


