﻿#$%^&* pL2_cn_trod_vwap_afterHighV.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Apr 28 11:04:35 2022

@author: thzhang
"""




import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime



#  This studies TWAP capture data



### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])




### get VWAP capture data 

i_capvwap = yu.get_q('''get `:/export/datadev/Data/SHSZ/TROD_metrics/i_trod_vwap_metrics''')

i_capvwap['code'] = i_capvwap['code'].str.decode('utf8')
c_sh = i_capvwap['code'].str[0].isin(['6'])
c_sz = i_capvwap['code'].str[0].isin(['0','3'])
i_capvwap.loc[c_sh, 'ticker'] = i_capvwap.loc[c_sh, 'code'] + '.SH'
i_capvwap.loc[c_sz, 'ticker'] = i_capvwap.loc[c_sz, 'code'] + '.SZ'
i_capvwap['datadate'] = pd.to_datetime(i_capvwap['date'])
i_capvwap = i_capvwap.sort_values(['ticker', 'datadate'])
i_capvwap = i_capvwap[i_capvwap['ticker'].notnull()]



### combine

icom = i_sd.merge(i_capvwap, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']

'top20m_pv_pct', 'top20m_orderB_dollar_pct',
   'top20m_orderB_volume_pctSelf', 'top20m_order_dollar_pct',
   'top20m_order_volume_pctSelf', 'top20m_order_cnt_pctSelf',
   'bot20m_pv_pct', 'bot20m_orderB_dollar_pct',
   'bot20m_orderB_volume_pctSelf', 'bot20m_order_dollar_pct',
   'bot20m_order_volume_pctSelf', 'bot20m_order_cnt_pctSelf'


### rkdf between high-traded-v and sebsequent orders

icom['top20m_pv_pct_rk'] = icom.groupby('datadate')['top20m_pv_pct'].apply(yu.uniformed_rank)
icom['top20m_order_dollar_pct_rk'] = icom.groupby('datadate')['top20m_order_dollar_pct'].apply(yu.uniformed_rank)
icom['top20m_trodf_rkdf'] = icom['top20m_order_dollar_pct_rk'] - icom['top20m_pv_pct_rk']
icom['top20m_trodf_rkdf_bk'] = icom.groupby('datadate')['top20m_trodf_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['top20m_trodf_rkdf_orth'] = icom.groupby('datadate')[['top20m_trodf_rkdf']+COLS].apply(lambda x: yu.orthogonalize_cn(x['top20m_trodf_rkdf'], x[COLS])).values
icom['top20m_trodf_rkdf_orth_bk'] = icom.groupby('datadate')['top20m_trodf_rkdf_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['top20m_trodf_rkdf_bk'], 'top20m_trodf_rkdf') # v-shaped: +2 -2 +1
yu.create_cn_3x3(icom, ['top20m_trodf_rkdf_orth_bk'], 'top20m_trodf_rkdf_orth') # less mono: +1.
5 -2 -1


### orders after high-v minutes

icom['top20m_order_volume_pctSelf_bk'] = icom.groupby('datadate')['top20m_order_volume_pctSelf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['top20m_orderB_volume_pctSelf_bk'] = icom.groupby('datadate')['top20m_orderB_volume_pctSelf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['top20m_order_volume_pctSelf_orth'] = icom.groupby('datadate')[['top20m_order_volume_pctSelf']+COLS].apply(lambda x: yu.orthogonalize_cn(x['top20m_order_volume_pctSelf'], x[COLS])).values
icom['top20m_order_volume_pctSelf_orth_bk'] = icom.groupby('datadate')['top20m_order_volume_pctSelf_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['top20m_orderB_volume_pctSelf_orth'] = icom.groupby('datadate')[['top20m_orderB_volume_pctSelf']+COLS].apply(lambda x: yu.orthogonalize_cn(x['top20m_orderB_volume_pctSelf'], x[COLS])).values
icom['top20m_orderB_volume_pctSelf_orth_bk'] = icom.groupby('datadate')['top20m_orderB_volume_pctSelf_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['top20m_order_cnt_pctSelf_orth'] = icom.groupby('datadate')[['top20m_order_cnt_pctSelf']+COLS].apply(lambda x: yu.orthogonalize_cn(x['top20m_order_cnt_pctSelf'], x[COLS])).values
icom['top20m_order_cnt_pctSelf_orth_bk'] = icom.groupby('datadate')['top20m_order_cnt_pctSelf_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values


#yu.create_cn_3x3(icom, ['top20m_order_volume_pct_bk'], 'top20m_order_volume_pct') # mono: +3 -2.5
yu.create_cn_3x3(icom, ['top20m_orderB_volume_pctSelf_bk'], 'top20m_orderB_volume_pctSelf') # less mono: +2 +3 -2
yu.create_cn_3x3(icom, ['top20m_order_volume_pctSelf_orth_bk'], 'top20m_order_volume_pctSelf_orth') # less mono: +2 +2.5 -5.5
#yu.create_cn_3x3(icom, ['top20m_orderB_volume_pctSelf_orth_bk'], 'top20m_orderB_volume_pctSelf_orth') # less mono: +1 +3 -5
yu.create_cn_3x3(icom, ['top20m_order_cnt_pctSelf_orth_bk'], 'top20m_order_cnt_pctSelf_orth') # less mono: +1 +2 -7


### order diff between high-v and low-v minutes

icom['topbot20m_order_volume_pctSelf'] = icom['top20m_order_volume_pctSelf'] - icom['bot20m_order_volume_pctSelf']
icom['topbot20m_order_volume_pctSelf_bk'] = icom.groupby('datadate')['topbot20m_order_volume_pctSelf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['topbot20m_order_volume_pctSelf_orth'] = icom.groupby('datadate')[['topbot20m_order_volume_pctSelf']+COLS].apply(lambda x: yu.orthogonalize_cn(x['topbot20m_order_volume_pctSelf'], x[COLS])).values
icom['topbot20m_order_volume_pctSelf_orth_bk'] 
= icom.groupby('datadate')['topbot20m_order_volume_pctSelf_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

#yu.create_cn_3x3(icom, ['topbot20m_order_volume_pctSelf_bk'], 'topbot20m_order_volume_pctSelf') # mono +2 -3
#yu.create_cn_3x3(icom, ['topbot20m_order_volume_pctSelf_orth_bk'], 'topbot20m_order_volume_pctSelf_orth') # mono +2 -6


icom['topbot20m_order_dollar_pct'] = icom['top20m_order_dollar_pct'] - icom['bot20m_order_dollar_pct']
icom['topbot20m_order_dollar_pct_bk'] = icom.groupby('datadate')['topbot20m_order_dollar_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['topbot20m_order_dollar_pct_orth'] = icom.groupby('datadate')[['topbot20m_order_dollar_pct']+COLS].apply(lambda x: yu.orthogonalize_cn(x['topbot20m_order_dollar_pct'], x[COLS])).values
icom['topbot20m_order_dollar_pct_orth_bk'] = icom.groupby('datadate')['topbot20m_order_dollar_pct_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

#yu.create_cn_3x3(icom, ['topbot20m_order_dollar_pct_bk'], 'topbot20m_order_dollar_pct') # less mono +1 +2 -6
#yu.create_cn_3x3(icom, ['topbot20m_order_dollar_pct_orth_bk'], 'topbot20m_order_dollar_pct_orth') # mono +2 -6

icom['topbot20m_order_cnt_pctSelf'] = icom['top20m_order_cnt_pctSelf'] - icom['bot20m_order_cnt_pctSelf']
icom['topbot20m_order_cnt_pctSelf_bk'] = icom.groupby('datadate')['topbot20m_order_cnt_pctSelf'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['topbot20m_order_cnt_pctSelf_orth'] = icom.groupby('datadate')[['topbot20m_order_cnt_pctSelf']+COLS].apply(lambda x: yu.orthogonalize_cn(x['topbot20m_order_cnt_pctSelf'], x[COLS])).values
icom['topbot20m_order_cnt_pctSelf_orth_bk'] = icom.groupby('datadate')['topbot20m_order_cnt_pctSelf_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['topbot20m_order_cnt_pctSelf_bk'], 'topbot20m_order_cnt_pctSelf') # less mono: 2 -3.5
yu.create_cn_3x3(icom, ['topbot20m_order_cnt_pctSelf_orth_bk'], 'topbot20m_order_cnt_pctSelf_orth') # mono: 2 -8
