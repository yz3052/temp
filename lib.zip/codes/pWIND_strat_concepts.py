﻿#$%^&* pWIND_strat_concepts.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 26 09:00:54 2021

@author: thzhang
"""


import pWIND_util as pw
from pWIND_util import get_china_sd

import pandas as pd
import numpy as np
import datetime

from yz.util import get_sql, bt_cn, bt_cn_15, bt_cn_2, uniformed_rank, create_cn_3x3, ols_beta, explore, pdqcut
import yz.util as yu


# sd

i_sd = pw.get_ashare_hk_sd_v2()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','volatility','spread','BarrRet_SRISK_USD+1d','FX_LAST']]


### get hk sd
i_sd_hk = pw.get_ashare_hk_sd()
i_sd_hk = i_sd_hk[['ticker', 'datadate', 'BarrRet_CLIP+1d']]
i_sd_hk = i_sd_hk.rename(columns={'BarrRet_CLIP+1d':'hk_BarrRet_CLIP+1d'})

# concept data

i_con = pw.get_wind_concept()

o_con_cnt = pd.DataFrame()
for  d in pd.date_range(start = '2013-01-01', end = i_con['entry_dt'].max()):
    print(d, end=',')
    c_within_range = (i_con['entry_dt']<=d)&(i_con['remove_dt']>=d)
    c_after_entry = (i_con['entry_dt']<=d)&(i_con['remove_dt'].isnull())
    t_con = i_con[c_within_range | c_after_entry]
    t_con_grp = t_con.groupby('ticker')['WIND_SEC_CODE'].nunique().reset_index()
    t_con_grp = t_con_grp.rename(columns = {'WIND_SEC_CODE': 'concept_cnt'})
    t_con_grp['datadate'] = d
    o_con_cnt = o_con_cnt.append(t_con_grp, ignore_index = True)

# concept data (filtered)

i_con_fltr = pw.get_wind_concept(filtering=True)

o_con_cnt_fltr = pd.DataFrame()
for  d in pd.date_range(start = '2013-01-01', end = i_con_fltr['entry_dt'].max()):
    print(d, end=',')
    c_within_range = (i_con_fltr['entry_dt']<=d)&(i_con_fltr['remove_dt']>=d)
    c_after_entry = (i_con_fltr['entry_dt']<=d)&(i_con_fltr['remove_dt'].isnull())
    t_con = i_con_fltr[c_within_range | c_after_entry]
    t_con_grp = t_con.groupby('ticker')['WIND_SEC_CODE'].nunique().reset_index()
    t_con_grp = t_con_grp.rename(columns = {'WIND_SEC_CODE': 'concept_cnt'})
    t_con_grp['datadate'] = d
    o_con_cnt_fltr = o_con_cnt_fltr.append(t_con_grp, ignore_index = True)



# index weight

i_wt = pw.get_index_weight()

# combine

icom = i_sd_map.merge(o_con_cnt, on = ['ticker', 'datadate'], how = 'left')
#icom = i_sd_map.merge(o_con_cnt_fltr, on = ['ticker', 'datadate'], how = 'left', suffixes=['','_f'])
icom = icom.merge(i_wt, on = ['ticker', 'datadate'], how = 'left')


icom['SIZE_bk'] = icom.groupby('datadate')['MC_l1d'].apply(lambda x: pd.qcut(x,q=5,labels=range(5))).values

#icom = icom.merge(i_sd_map, on = ['ticker', 'datadate'], how = 'left')

#------------------------------------------------------------------------------
### backtest


### simple [-1,+1] rank
icom2 = icom.copy()
icom2['concept_cnt_rk'] = icom2.groupby('datadate')['concept_cnt'].apply(lambda x: uniformed_rank(x)).values




# rmb
o_1 = bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
            dropna(subset=['concept_cnt_rk','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 3.04

# rmb, l
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['concept_cnt_rk']>0)].\
            dropna(subset=['concept_cnt_rk','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 4.04

# rmb, l
o_1 = bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')&(icom2['concept_cnt_rk']>0)&(icom2['isin_hk_uni']==1)].\
            dropna(subset=['concept_cnt_rk','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 


# rmb, l, using hk bret
o_1 = bt_cn_15(icom2[(icom2['datadate']<='2019-12-31')&(icom2['concept_cnt_rk']>0)&(icom2['isin_hk_uni']==1)].\
            dropna(subset=['concept_cnt_rk','hk_BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','hk_BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 




# rmb, l, old fx-adj return
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['concept_cnt_rk']>0.0)].\
            dropna(subset=['concept_cnt_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.57 

# rmb, s
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['concept_cnt_rk']<0)].\
            dropna(subset=['concept_cnt_rk','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 1.94 

# rmb, hk uni, l
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['isin_hk_uni']==1)&(icom2['concept_cnt_rk']>0)].\
            dropna(subset=['concept_cnt_rk'
,'BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 2.68 / 2.49

# raw rmb, hi uni, l
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['isin_hk_uni']==1)&(icom2['concept_cnt_rk']>0)].\
            dropna(subset=['concept_cnt_rk','RawRet+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','RawRet+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.06 / -0.05


# usd, hk uni, l
o_1 = bt_cn_2(icom2[(icom2['datadate']<='2019-12-31')&(icom2['isin_hk_uni']==1)&(icom2['concept_cnt_rk']>0)].\
            dropna(subset=['concept_cnt_rk','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd, 
            test_short_limit=True) #prcs 2.1 / 1.7


o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31')&(icom2['concept_cnt_rk']>0)].\
            dropna(subset=['concept_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.59 / 2.96

o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31')&(icom2['concept_cnt_rk']>0)&(icom2['isin_hk_uni']==1)].\
            dropna(subset=['concept_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.57 / 2.93


o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2019-12-31')&(icom2['datadate']>='2019-01-01')&(icom2['concept_cnt_rk']>0)&(icom2['isin_hk_uni']==1)].\
            dropna(subset=['concept_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 3.57 / 2.93



# usd, hk uni, l, rk > 0.5
o_1 = bt_cn_2(icom2[(icom2['datadate']<='2019-12-31')&(icom2['isin_hk_uni']==1)&(icom2['concept_cnt_rk']>0.5)].\
            dropna(subset=['concept_cnt_rk','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd, test_short_limit=True) #prcs 2.01 / 1.65

# usd, hk uni, l, rk / 2
icom2['concept_cnt_rk_v2'] = icom2['concept_cnt_rk']/2
o_1 = bt_cn_2(icom2[(icom2['datadate']<='2019-12-31')&(icom2['isin_hk_uni']==1)&(icom2['concept_cnt_rk']>0)].\
            dropna(subset=['concept_cnt_rk_v2','
BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk_v2','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd, test_short_limit=True) #prcs 2.1 / 1.73



### simple [-1,+1] rank + PV   --> not working
icom2 = icom.copy()
icom2['concept_cnt_rk'] = icom2.groupby('datadate')['concept_cnt'].apply(lambda x: uniformed_rank(x)).values
icom2 = icom2.merge(i_sd[['ticker','datadate','PV_l1d']],on=['ticker','datadate'],how='left')
icom2['pv_rk'] = icom2.groupby('datadate')['PV_l1d'].apply(lambda x: uniformed_rank(x)).values

# usd, hk uni, l, high pv  
o_1 = bt_cn_2(icom2[(icom2['datadate']<='2019-12-31')&(icom2['isin_hk_uni']==1)&(icom2['concept_cnt_rk']>0)&(icom2['pv_rk']>-0.5)].\
            dropna(subset=['concept_cnt_rk','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd, 
            test_short_limit=True) #prcs 1.75 / 1.35





### simple [-1,+1] rank + past return

icom2 = icom.copy()
icom2['concept_cnt_rk'] = icom2.groupby('datadate')['concept_cnt'].apply(lambda x: uniformed_rank(x)).values
icom2['concept_cnt_bk'] = icom2.groupby('datadate')['concept_cnt'].apply(lambda x: pdqcut(x,bins=10)).values
icom2 = icom2.sort_values(['ticker','datadate'])
icom2['bret_t250d'] = icom2.groupby('ticker').rolling(250)['BarrRet_CLIP_USD-1d'].mean().values
icom2['bret_t250d_rk'] = icom2.groupby('datadate')['bret_t250d'].apply(lambda x: uniformed_rank(x)).values
icom2['bret_t250d_bk'] = icom2.groupby('datadate')['bret_t250d'].apply(lambda x: pdqcut(x,bins=10,labels=range(10))).values

c_large_value = (icom2['concept_cnt_rk'] > 0.8)
icom2.loc[c_large_value, 'sgnl'] = icom2.loc[c_large_value, 'concept_cnt_rk']
icom2['sgnl'] = icom2.groupby('ticker')['sgnl'].ffill(limit = 63)

c_large_value_low_ret = (icom2['concept_cnt_rk'] > 0.8) & (icom2['bret_t250d_rk']<-0.5)
icom2.loc[c_large_value_low_ret, 'sgnl2'] = icom2.loc[c_large_value_low_ret, 'concept_cnt_rk']
icom2['sgnl2'] = icom2.groupby('ticker')['sgnl2'].ffill(limit = 63)

# low past return
o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2020-12-31')&(icom2['isin_hk_uni']==1)&(icom2['concept_cnt_rk']>0)&(icom2['bret_t250d_rk']<0)].\
            dropna(subset=['concept_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd ) #prcs -0.39/-1.48

# high past return
o_1 = yu.bt_cn_16(icom2[
(icom2['datadate']<='2020-12-31')&(icom2['isin_hk_uni']==1)&(icom2['concept_cnt_rk']>0)&(icom2['bret_t250d_rk']>0)].\
            dropna(subset=['concept_cnt_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','BarrRet_CLIP_USD+1d', static_data = i_sd ) #prcs 2.05/1.01

# pulse
o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2020-12-31')&(icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd ) #prcs 1.33 / 1.05

o_1 = yu.bt_cn_16(icom2[(icom2['datadate']<='2020-12-31')&(icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd ) #prcs -0.17 / 0.32




### simple [-1,+1] rank within 50, 300 and 500 universe

icom2 = icom.copy()
icom2 = icom2[icom2['hedgeable']==1]
icom2['concept_cnt_rk'] = icom2.groupby('datadate')['concept_cnt'].apply(lambda x: uniformed_rank(x)).values

o_1 = bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
            dropna(subset=['concept_cnt_rk','BarrRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','BarrRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 2.96 (recent years bad))



### simple [-1,+1] rank within 50, 300 and 500 universe, plus long only positions for tickers out side of 800 universe

icom2 = icom.copy()
icom2['concept_cnt_rk'] = icom2.groupby('datadate')['concept_cnt'].apply(lambda x: uniformed_rank(x)).values
icom2.loc[(icom2['concept_cnt_rk']<0)&(icom2['hedgeable']!=1), 'concept_cnt_rk'] = np.nan

o_1 = bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
            dropna(subset=['concept_cnt_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 0.67






### simple rank within sectors

icom2 = icom.copy()
icom2['concept_cnt_rk'] = icom2.groupby(['datadate','GSECTOR'])['concept_cnt'].apply(lambda x: uniformed_rank(x)).values

o_1 = bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
            dropna(subset=['concept_cnt_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 3.32

# short position only -> short position represents 70% of
 the profit
o_1 = bt_cn(icom2[(icom2['datadate']<='2019-12-31')&(icom2['concept_cnt_rk']<0)].\
            dropna(subset=['concept_cnt_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 1.82

### sector-adj ranks for 300 tickers

icom2 = icom.copy()
icom2 = icom2[icom2['is_300']==1]
icom2['concept_cnt_rk'] = icom2.groupby(['datadate','GSECTOR'])['concept_cnt'].apply(lambda x: uniformed_rank(x)).values

o_1 = bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
            dropna(subset=['concept_cnt_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 2.29 (recent years slightly decayed)


### sector-adj ranks for 300 + 500 tickers

icom2 = icom.copy()
icom2 = icom2[(icom2['is_300']==1) | (icom2['is_500']==1)]
icom2['concept_cnt_rk'] = icom2.groupby(['datadate','GSECTOR'])['concept_cnt'].apply(lambda x: uniformed_rank(x)).values

o_1 = bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
            dropna(subset=['concept_cnt_rk','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'concept_cnt_rk','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd) #prcs 2.94 (recent years not good)



### sector-adj ranks for 300 tickers, weights = index weight

icom2 = icom.copy()
icom2 = icom2[icom2['is_300']==1]
icom2['concept_cnt_rk'] = icom2.groupby(['datadate','GSECTOR'])['concept_cnt'].apply(lambda x: uniformed_rank(x)).values

icom2.loc[icom2['concept_cnt_rk']>0,'sgnl'] = icom2.loc[icom2['concept_cnt_rk']>0,'wt300'] * 300*1000000
icom2.loc[icom2['concept_cnt_rk']<0,'sgnl'] = icom2.loc[icom2['concept_cnt_rk']<0,'wt300'] * 300*1000000*(-1)

o_1 = bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd, pst_type = 'dollar') #prcs 1.92

### sector-adj ranks for 500 tickers, weights = index weight

icom2 = icom.copy()
icom2 = icom2[icom2['is_500']==1]
icom2['concept_cnt_rk'] = icom2.groupby(['datadate','GSECTOR'])['concept_cnt'].apply(lambda x: uniformed_rank(x)).values

icom2.loc[icom2['concept_cnt_rk']>0,'sgnl'] = icom2.loc[icom2['concept_cnt_rk']>0,'wt500'] * 300*1000000
icom2.loc[icom2['concept_cnt_rk']<0,'sgnl'] = icom2.loc[icom2['concept_cnt_rk']<0,'wt500']
 * 300*1000000*(-1)

o_1 = bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd, pst_type = 'dollar') #prcs 1.9 but recent years flat




### sector-adj ranks for 300+500 tickers, weights = index weight

icom2 = icom.copy()
icom2 = icom2[(icom2['is_300']==1) | (icom2['is_500']==1)]
icom2['concept_cnt_rk'] = icom2.groupby(['datadate','GSECTOR'])['concept_cnt'].apply(lambda x: uniformed_rank(x)).values

icom2.loc[icom2['concept_cnt_rk']>0,'sgnl'] = icom2.loc[icom2['concept_cnt_rk']>0,'wt300'] * 300*1000000
icom2.loc[icom2['concept_cnt_rk']<0,'sgnl'] = icom2.loc[icom2['concept_cnt_rk']<0,'wt300'] * 300*1000000*(-1)

o_1 = bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd, pst_type = 'dollar') #prcs 0.83

### sector+size-adj concept ranks for 300+500 tickers, weights = index weight

icom2 = icom.copy()
icom2 = icom2[(icom2['is_300']==1) | (icom2['is_500']==1)]
icom2['concept_cnt_rk'] = icom2.groupby(['datadate','GSECTOR','SIZE_bk'])['concept_cnt'].apply(lambda x: uniformed_rank(x)).values

c_300w_l = (icom2['concept_cnt_rk']>0) & (icom2['is_300']==1)
c_300w_s = (icom2['concept_cnt_rk']<0) & (icom2['is_300']==1)
icom2.loc[c_300w_l,'sgnl'] = icom2.loc[c_300w_l,'wt300'] * 300*1000000
icom2.loc[c_300w_s,'sgnl'] = icom2.loc[c_300w_s,'wt300'] * 300*1000000*(-1)
c_500w_l = (icom2['concept_cnt_rk']>0) & (icom2['is_500']==1)
c_500w_s = (icom2['concept_cnt_rk']<0) & (icom2['is_500']==1)
icom2.loc[c_500w_l,'sgnl'] = icom2.loc[c_500w_l,'wt500'] * 500*1000000
icom2.loc[c_500w_s,'sgnl'] = icom2.loc[c_500w_s,'wt500'] * 500*1000000*(-1)


o_1 = bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd, pst_type = 'dollar') #prcs 2.54 / 1.77 (recent yr flat)


### sector+size-adj OLS residual concept ranks for 300+500 tickers, weights = index weight


icom2 = icom.copy()
icom2 = icom2[(icom2['is_300']==1) | (icom2['is_500']==1)]
icom2['concept_cnt_rk'] = icom2.groupby(['datadate','GSECTOR','SIZE_bk'])['concept_cnt'].apply(lambda x: uniformed_rank(x)).values

c_300w_l = (icom2
['concept_cnt_rk']>0) & (icom2['is_300']==1)
c_300w_s = (icom2['concept_cnt_rk']<0) & (icom2['is_300']==1)
icom2.loc[c_300w_l,'sgnl'] = icom2.loc[c_300w_l,'wt300'] * 300*1000000
icom2.loc[c_300w_s,'sgnl'] = icom2.loc[c_300w_s,'wt300'] * 300*1000000*(-1)
c_500w_l = (icom2['concept_cnt_rk']>0) & (icom2['is_500']==1)
c_500w_s = (icom2['concept_cnt_rk']<0) & (icom2['is_500']==1)
icom2.loc[c_500w_l,'sgnl'] = icom2.loc[c_500w_l,'wt500'] * 500*1000000
icom2.loc[c_500w_s,'sgnl'] = icom2.loc[c_500w_s,'wt500'] * 500*1000000*(-1)


o_1 = bt_cn(icom2[icom2['datadate']<='2019-12-31'].\
            dropna(subset=['sgnl','fxRet_CLIP+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','fxRet_CLIP+1d', sgnl_before_3pm=False, static_data = i_sd, pst_type = 'dollar') #prcs 2.54 / 1.77 (recent yr flat)





### bucket on size (too many long pst, too little short positions at the moment)

### growth of concepts

### rank within sectors and mc buckets
### get news concept




