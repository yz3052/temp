﻿#$%^&* pL2_cn_orderbook_sellrelax.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 21 15:31:41 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime

from sqlalchemy import create_engine

# yes there are some alphas here


### sd

i_sd_2k = pw.get_ashare_t2000_sd()
i_sd_2k = i_sd_2k.sort_values(['datadate'])


### get flg of ever <-8%

i_flg_m8 = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate, 
                      s_dq_adjlow / S_DQ_ADJPRECLOSE - 1 as l_dv_c 
                      from wind_prod.dbo.ashareeodprices''')

i_flg_m8['datadate'] = pd.to_datetime(i_flg_m8['datadate'], format = '%Y%m%d')
i_flg_m8['flg_nearLmtDn'] = np.nan
i_flg_m8.loc[i_flg_m8['l_dv_c']<-0.09, 'flg_nearLmtDn'] = 1


### get order book

i_odbk_thickness = yu.get_q("get `:/export/datadev/Data/SHSZ/ORDER_metrics/orderbook_metrics_batch1_07", port=5006)


i_odbk_thickness['code'] = i_odbk_thickness['code'].str.decode('utf8')
c_sh = i_odbk_thickness['code'].str[0].isin(['6'])
c_sz = i_odbk_thickness['code'].str[0].isin(['0','3'])
i_odbk_thickness.loc[c_sh, 'ticker'] = i_odbk_thickness.loc[c_sh, 'code'] + '.SH'
i_odbk_thickness.loc[c_sz, 'ticker'] = i_odbk_thickness.loc[c_sz, 'code'] + '.SZ'
i_odbk_thickness['datadate'] = pd.to_datetime(i_odbk_thickness['date'])
i_odbk_thickness = i_odbk_thickness.sort_values(['ticker', 'datadate'])

i_odbk_thickness['ab12avg'] = i_odbk_thickness['ask_12_v_avg'] / i_odbk_thickness['bid_12_v_avg']
i_odbk_thickness['ab12med'] = i_odbk_thickness['ask_12_v_med'] / i_odbk_thickness['bid_12_v_med']
i_odbk_thickness['abtotavg'] = i_odbk_thickness['ask_tot_v_avg'] / i_odbk_thickness['bid_tot_v_avg']
i_odbk_thickness['abtotmed'] = i_odbk_thickness['ask_tot_v_med'] / i_odbk_thickness['bid_tot_v_med']

i_odbk_thickness['abx12avg'] = (i_odbk_thickness['ask_tot_v_avg']-i_odbk_thickness['ask_12_v_avg']) / (i_odbk_thickness['bid_tot_v_avg'] - i_odbk_thickness['bid_12_v_avg'])
i_odbk_thickness['abx12med'] = (i_odbk_thickness['ask_tot_v_med']-i_odbk_thickness['ask_12_v_med']) / (i_odbk_thickness['bid_tot_v_med'] - i_odbk_thickness['bid_12_v_med'])

i_odbk_thickness['abx1pctavg'] = (i_odbk_thickness['ask_tot_v_avg']-i_odbk_thickness['ask_1pct_v_avg']) / (i_odbk_thickness['bid_tot_v_avg'] - i_odbk_thickness['bid_1pct_v_avg'])
i_odbk_thickness['abx1pctmed'] = (i_odbk_thickness['ask_tot_v_med']-i_odbk_thickness['ask_1pct_v_med']) / (i_odbk_thickness['bid_tot_v_med']
 - i_odbk_thickness['bid_1pct_v_med'])




### combine 

icom = i_sd_2k.merge(i_odbk_thickness, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_flg_m8, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom['bret_rk'] = icom.groupby('datadate')['BarrRet_CLIP_USD-1d'].apply(yu.uniformed_rank)

icom['ab12avg_s2'] = icom['ab12avg']
icom['ab12med_s2'] = icom['ab12med']
icom['abtotavg_s2'] = icom['abtotavg']
icom['abtotmed_s2'] = icom['abtotmed']
icom['abx12avg_s2'] = icom['abx12avg']
icom['abx12med_s2'] = icom['abx12med']
icom['abx1pctavg_s2'] = icom['abx1pctavg']
icom['abx1pctmed_s2'] = icom['abx1pctmed']


c1 = icom['flg_nearLmtDn'] == 1
icom.loc[c1, 'ab12avg_s2'] = np.nan
icom.loc[c1, 'ab12med_s2'] = np.nan
icom.loc[c1, 'abtotavg_s2'] = np.nan
icom.loc[c1, 'abtotmed_s2'] = np.nan
icom.loc[c1, 'abx12avg_s2'] = np.nan
icom.loc[c1, 'abx12med_s2'] = np.nan
icom.loc[c1, 'abx1pctavg_s2'] = np.nan
icom.loc[c1, 'abx1pctmed_s2'] = np.nan

icom['ab12avg_s2_rk'] = icom.groupby('datadate')['ab12avg_s2'].apply(yu.uniformed_rank)
icom['ab12med_s2_rk'] = icom.groupby('datadate')['ab12med_s2'].apply(yu.uniformed_rank)
icom['abtotavg_s2_rk'] = icom.groupby('datadate')['abtotavg_s2'].apply(yu.uniformed_rank)
icom['abtotmed_s2_rk'] = icom.groupby('datadate')['abtotmed_s2'].apply(yu.uniformed_rank)
icom['abx12avg_s2_rk'] = icom.groupby('datadate')['abx12avg_s2'].apply(yu.uniformed_rank)
icom['abx12med_s2_rk'] = icom.groupby('datadate')['abx12med_s2'].apply(yu.uniformed_rank)
icom['abx1pctavg_s2_rk'] = icom.groupby('datadate')['abx1pctavg_s2'].apply(yu.uniformed_rank)
icom['abx1pctmed_s2_rk'] = icom.groupby('datadate')['abx1pctmed_s2'].apply(yu.uniformed_rank)

for c in ['ab12avg_s2_rk','ab12med_s2_rk','abtotavg_s2_rk','abtotmed_s2_rk','abx12avg_s2_rk','abx12med_s2_rk','abx1pctavg_s2_rk','abx1pctmed_s2_rk']:
    for i in range(1,5):
        icom[c+'_'+str(i)+'d'] = icom.groupby('ticker')[c].shift(i)



### bar charts

icom['ab12med_s2_bk'] = icom.groupby('datadate')['ab12med_s2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['ab12med_s2_bk'], 'ab12med_s2') # mono: -1.5 +2.3
icom['ab12avg_s2_bk'] = icom.groupby('datadate')['ab12avg_s2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['ab12avg_s2_bk'], 'ab12avg_s2') # random
icom['abtotmed_s2_bk'] = icom.groupby('datadate')['abtotmed_s2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['abtotmed_s2_bk'], 'abto
tmed_s2') # mono: +2.2 -6.4
icom['abtotavg_s2_bk'] = icom.groupby('datadate')['abtotavg_s2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['abtotavg_s2_bk'], 'abtotavg_s2') # mono: +3.5 / -7
icom['abx12avg_s2_bk'] = icom.groupby('datadate')['abx12avg_s2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['abx12avg_s2_bk'], 'abx12avg_s2') # mono: +3 -7
icom['abx12med_s2_bk'] = icom.groupby('datadate')['abx12med_s2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['abx12med_s2_bk'], 'abx12med_s2') # mono: +2.6 / -7
icom['abx1pctavg_s2_bk'] = icom.groupby('datadate')['abx1pctavg_s2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['abx1pctavg_s2_bk'], 'abx1pctavg_s2') # mono: +4 -6 ###!!!
icom['abx1pctmed_s2_bk'] = icom.groupby('datadate')['abx1pctmed_s2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['abx1pctmed_s2_bk'], 'abx1pctmed_s2') # mono: +3.25 -6


icom['abtotavg_s2_rk'] = icom.groupby('datadate')['abtotavg_s2'].apply(yu.uniformed_rank)
icom['ab12avg_s2_rk'] = icom.groupby('datadate')['ab12avg_s2'].apply(yu.uniformed_rank)
icom['tot12_rkdf'] = icom['ab12avg_s2_rk'] - icom['abtotavg_s2_rk']
icom['tot12_rkdf_bk'] = icom.groupby('datadate')['tot12_rkdf'].apply(lambda x: yu.pdqcut(x,bins=20)).values
yu.create_cn_3x3(icom, ['tot12_rkdf_bk'], 'tot12_rkdf') # mono: -4 +3



icom['flg_sellrelax1'] = np.nan
c1 = icom['ab12med_s2_rk_1d'].lt(-.8) & icom['ab12med_s2_rk_2d'].lt(-.8) & icom['ab12med_s2_rk_3d'].lt(-.8) &\
     icom['ab12med_s2_rk_4d'].lt(-.8) & icom['ab12med_s2_rk'].gt(-0.2)
icom.loc[c1, 'flg_sellrelax1'] = 1
yu.create_cn_decay(icom, 'flg_sellrelax1') # -ve ret over hte next 30 days, low t though


icom['flg_sellrelax2'] = np.nan
c1 = icom['ab12med_s2_rk_1d'].gt(.8) & icom['ab12med_s2_rk_2d'].gt(.8) & icom['ab12med_s2_rk_3d'].gt(.8) &\
     icom['ab12med_s2_rk_4d'].gt(.8) & icom['ab12med_s2_rk'].lt(0.2)
icom.loc[c1, 'flg_sellrelax2'] = 1
yu.create_cn_decay(icom, 'flg_sellrelax2') # +ve ret over the next 10 days, t around 2 - 3

icom['sgnl_sellrelax2'] = icom.groupby('ticker')['flg_sellrelax2'].ffill(limit=7)
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_sellrelax2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_sellrelax2','BarrRet_CLIP_USD+1d', static_data = i_sd_2k) # 0.63 / 0

icom['flg_sellrelax3'] = np.nan
c1 = icom['abtotavg_s2_rk_1d'].lt(-.8) & icom[
'abtotavg_s2_rk_2d'].lt(-.8) & icom['abtotavg_s2_rk_3d'].lt(-.8) &\
     icom['abtotavg_s2_rk_4d'].lt(-.8) & icom['abtotavg_s2_rk'].gt(-0.2)
icom.loc[c1, 'flg_sellrelax3'] = 1
yu.create_cn_decay(icom, 'flg_sellrelax3') # random

icom['flg_sellrelax4'] = np.nan
c1 = icom['abtotmed_s2_rk_1d'].lt(-.8) & icom['abtotmed_s2_rk_2d'].lt(-.8) & icom['abtotmed_s2_rk_3d'].lt(-.8) &\
     icom['abtotmed_s2_rk_4d'].lt(-.8) & icom['abtotmed_s2_rk'].gt(-0.2)
icom.loc[c1, 'flg_sellrelax4'] = 1
yu.create_cn_decay(icom, 'flg_sellrelax4') # random

icom['flg_sellrelax5'] = np.nan
c1 = icom['abtotavg_s2_rk_1d'].gt(.8) & icom['abtotavg_s2_rk_2d'].gt(.8) & icom['abtotavg_s2_rk_3d'].gt(.8) &\
     icom['abtotavg_s2_rk_4d'].gt(.8) & icom['abtotavg_s2_rk'].lt(0.2)
icom.loc[c1, 'flg_sellrelax5'] = 1
yu.create_cn_decay(icom, 'flg_sellrelax5') # random



icom['flg_buy_vs_suppress'] = np.nan
c1 = icom['ab12med_s2_rk'].between(0.6, 0.8) & icom['bret_rk'].gt(0.6)
icom.loc[c1, 'flg_buy_vs_suppress'] = 1
yu.create_cn_decay(icom, 'flg_buy_vs_suppress') # reversal first, then +ve ret over the 100 days, low t

icom['flg_buy_vs_suppress2'] = np.nan
c1 = icom['ab12med_s2_rk'].between(0.6, 1) & icom['bret_rk'].gt(0.6)
icom.loc[c1, 'flg_buy_vs_suppress2'] = 1
yu.create_cn_decay(icom, 'flg_buy_vs_suppress2') # reversal first, then +ve ret over the 100 days, low t







icom['t'] = icom['ab12avg_s2_rk'] - icom['bret_rk']
icom['t_bk'] = icom.groupby('datadate')['t'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['t_bk'], 't') # less mono: -3.4 + 5.4 +3.4

icom['flg_t'] = np.nan
icom.loc[icom['t_bk']==9, 'flg_t'] = 1
yu.create_cn_decay(icom, 'flg_t')  

icom['sgnl_t']  = icom.groupby('ticker')['flg_t'].ffill(limit=60)
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['sgnl_t','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_t','BarrRet_CLIP_USD+1d', static_data = i_sd_2k) # low return


icom['t_t20d'] = icom.groupby('ticker').rolling(20)['t'].mean().values
icom['t_t20d_bk']  = icom.groupby('datadate')['t_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['t_t20d_bk'], 't_t20d') # -5 +3




