﻿#$%^&* ml_cn_lgbm_20221213_aws.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 14 16:57:14 2022

@author: fgao
"""

import pandas as pd
import numpy as np
import datetime

import os
import gc
import sys



sys.path.append('/dat/scripts/THZHANG')
import learn_w_lightgbm


# =============================================================================
# 
# =============================================================================


year = int(sys.argv[1])
month = int(sys.argv[2])
nthread = int(sys.argv[3])






# =============================================================================
### get universe
# =============================================================================



df_universe = pd.read_parquet('/dat/data/THZHANG/df_universe.parquet')

str_ym = str(year*100+month)
str_ym_3y = str((year-3)*100+month)
df_universe = df_universe[df_universe['DataDate'].dt.strftime('%Y%m').le(str_ym)\
                          &df_universe['DataDate'].dt.strftime('%Y%m').ge(str_ym_3y)]


# =============================================================================
### get features
# =============================================================================

i_all = pd.read_parquet('/dat/data/THZHANG/featurepool_800.parquet')
cols = [i for i in i_all.columns.tolist() if i not in ['Ticker', 'DataDate']]
i_all = df_universe.merge(i_all, on = ['Ticker','DataDate'], how = 'inner',suffixes=['','_m'])
i_all['clip'] = i_all['avgPVadj'].apply(lambda r: min([r*0.01,1e6]))
i_all['wts'] = i_all['clip']
i_all= i_all.dropna(subset = ['wts'])

i_all['F008_ERNFT'] = pd.to_numeric(i_all['F008_ERNFT'])
i_all['F008_ERNUG'] = pd.to_numeric(i_all['F008_ERNUG'])


# =============================================================================
### calendar
# =============================================================================

df_cd = pd.read_parquet('/dat/data/THZHANG/df_cd.parquet')
df_calendars = df_cd['DataDate'].tolist()



# =============================================================================
### configs
# =============================================================================

config_feature = cols

monotone_features = [1] * len(config_feature)


configs = {
         'wts_type': 'clip',
         'ret_table_name': 'BARRA_GEM3L_YRRET',
         'startdate': '20160101',
         'enddate': '20221231',
         'used_ret_col': 'BarrRet_CLIP1d',
         'fold': 10,
         'purged_days': 22,
         'rolling_da
ys': 252,
         'features': config_feature, 
         'monotone_features': monotone_features,
         'metric_method': 'logistic', # rscore fore regression, logistic for logistic
         'loss_function': 'binary', # regression (msqr), binary (logistic)
         'eta_min': 0.01,
         'eta_max': 0.2,
         'gamma_min': 0,
         'gamma_max': 1000,
         'md_min': 2,
         'md_max': 12,
         'mcw_min': 1 ,
         'mcw_max': 1000,
         'subsample_min': 0.5,
         'subsample_max': 1,
         'colsample_bytree_min': 0.5,
         'colsample_bytree_max': 1,
         'colsample_bylevel_min': 0.5,
         'colsample_bylevel_max': 1,
         'colsample_bynode_min': 0.5,
         'colsample_bynode_max': 1,
         'lambda_min': 0,
         'lambda_max': 1000,
         'alpha_min': 0,
         'alpha_max': 1000,
         'esr': 100,
         'n_trials': 20,
         'tot_waittime': 600,
         'grow_policy': 'depthwise',
         'learning_method':'gbtree',
         'missing_data':'NaN',
         'importance_type': 'gain',
         'lookback_method': 'rolling',  #or 'expanded'
         'interaction_features':[],
         'num_leaves_min': 2,
         'num_leaves_max': 12
         }




# =============================================================================
# 
# =============================================================================


save_path2 = os.path.join('/dat/results/THZHANG', 'test_20221213_lgbm/')
if not os.path.exists(save_path2):
    os.mkdir(save_path2)

date_windows = df_cd[['DataDate']]
date_windows['year'] = date_windows['DataDate'].apply(lambda r: r.year)
date_windows['month'] = date_windows['DataDate'].apply(lambda r: r.month)

alphadates = date_windows[ (date_windows['year'] == year) & (date_windows['month'] == month) ]
alphadates = alphadates['DataDate'].tolist()
alphadates.sort()

learn_w_lightgbm.get_daily_alpha(i_all, df_universe, df_calendars, alphadates, configs, save_path2)




# scp /dat/summit_capital/TZ/codes/learn_w_lightgbm.py root@10.223.218.253:/dat/scripts/THZHANG/
# scp /dat/summit_capital/TZ/codes/ml_cn_lgbm_20221213_aws.py root@10.223.218.253:/dat/scripts/THZHANG/
