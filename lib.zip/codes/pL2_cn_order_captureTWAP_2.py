﻿#$%^&* pL2_cn_order_captureTWAP_2.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 15 16:45:28 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import datetime



#  This studies TWAP capture data



### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])



### get TWAP capture data

i_captwap = yu.get_q('''(get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sz_captureTWAP),
                        (get `:/export/datadev/Data/SHSZ/ORDER_metrics/i_od_metrics_sz_captureTWAP) ''')

i_captwap['code'] = i_captwap['code'].str.decode('utf8')
c_sh = i_captwap['code'].str[0].isin(['6'])
c_sz = i_captwap['code'].str[0].isin(['0','3'])
i_captwap.loc[c_sh, 'ticker'] = i_captwap.loc[c_sh, 'code'] + '.SH'
i_captwap.loc[c_sz, 'ticker'] = i_captwap.loc[c_sz, 'code'] + '.SZ'
i_captwap['datadate'] = pd.to_datetime(i_captwap['date'])
i_captwap = i_captwap.sort_values(['ticker', 'datadate'])
i_captwap = i_captwap[i_captwap['ticker'].notnull()]



### get trod metrics

i_trod = yu.get_q('''(get `:/export/datadev/Data/SHSZ/TROD_metrics/i_trod_metrics_sh_captureTWAP),
                     (get `:/export/datadev/Data/SHSZ/TROD_metrics/i_trod_metrics_sz_captureTWAP) ''')

i_trod['code'] = i_trod['code'].str.decode('utf8')
c_sh = i_trod['code'].str[0].isin(['6'])
c_sz = i_trod['code'].str[0].isin(['0','3'])
i_trod.loc[c_sh, 'ticker'] = i_trod.loc[c_sh, 'code'] + '.SH'
i_trod.loc[c_sz, 'ticker'] = i_trod.loc[c_sz, 'code'] + '.SZ'
i_trod['datadate'] = pd.to_datetime(i_trod['date'])
i_trod = i_trod.sort_values(['ticker', 'datadate'])
i_trod = i_trod[i_trod['ticker'].notnull()]




### combine

icom = i_sd.merge(i_captwap, on = ['ticker', 'datadate'], how = 'left')
icom = icom.merge(i_trod, on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

COLS = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD', 'RESVOL', 'GROWTH', 'BTOP', 'LEVERAGE', 'LIQUIDTY']


### trd cnt lt2s / total od cnt:
# trade isn't better 

icom['cntSumTrod_lt2s_dv_gt2s'] = icom['cntSumTrod_b_trd_lt2s'].divide(icom['cntSum_gt2s'])
icom['cntSumTrod_lt2s_dv_gt2s_bk'] = icom.groupby('datadate')['cntSumTrod_lt2s_dv_gt2s'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cntSumTrod_lt2s_dv_gt2s_bk'], 'cntSumTrod_lt2s_dv_gt2s') # -1 -5 +6.5


icom['cntSumTrod_lt2s_dv_gt2s'] = icom['cntSumTrod_b_trd_lt2s'].divide(icom['cntSum_b_gt2s'])
icom['b_av
gdf'] = (icom['cntAvg_b_overSec_lt2s'] - icom['cntAvg_b_overSec_gt2s']).divide(icom['cntSum_b_lt2s']+icom['cntSum_b_gt2s'])

icom['cntSumTrod_ratio_xNeg'] = np.nan
c1 = icom['b_avgdf']>0
icom.loc[c1, 'cntSumTrod_ratio_xNeg'] = icom.loc[c1, 'cntSumTrod_lt2s_dv_gt2s']
icom['cntSumTrod_ratio_xNeg_bk'] = icom.groupby('datadate')['cntSumTrod_ratio_xNeg'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cntSumTrod_ratio_xNeg_rk'] = icom.groupby('datadate')['cntSumTrod_ratio_xNeg'].apply(yu.uniformed_rank).values
yu.create_cn_3x3(icom, ['cntSumTrod_ratio_xNeg_bk'], 'cntSumTrod_ratio_xNeg') # -6 -7 +7

icom['cntSumTrod_ratio_xNeg_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['cntSumTrod_ratio_xNeg'].sum().values
icom['cntSumTrod_ratio_xNeg_t20d_orth'] = icom.groupby('datadate')[['cntSumTrod_ratio_xNeg_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['cntSumTrod_ratio_xNeg_t20d'], x[COLS])).values
icom['cntSumTrod_ratio_xNeg_t20d_orth_rk'] = icom.groupby('datadate')['cntSumTrod_ratio_xNeg_t20d_orth'].apply(yu.uniformed_rank).values

icom['cntSumTrod_ratio_xNeg_t40d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['cntSumTrod_ratio_xNeg'].sum().values
icom['cntSumTrod_ratio_xNeg_t40d_orth'] = icom.groupby('datadate')[['cntSumTrod_ratio_xNeg_t40d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['cntSumTrod_ratio_xNeg_t40d'], x[COLS])).values
icom['cntSumTrod_ratio_xNeg_t40d_orth_rk'] = icom.groupby('datadate')['cntSumTrod_ratio_xNeg_t40d_orth'].apply(yu.uniformed_rank).values


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cntSumTrod_ratio_xNeg_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cntSumTrod_ratio_xNeg_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.38/-11

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cntSumTrod_ratio_xNeg_t20d_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cntSumTrod_ratio_xNeg_t20d_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.82 /1.97, 2.0e7

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['cntSumTrod_ratio_xNeg_t40d_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'cntSumTrod_ratio_xNeg_t40d_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.37 / 2.17, 2.1e7


### od cnt lt2s / total od cnt: 

icom['cntSum_
lt2s_dv_gt2s'] = icom['cntSum_lt2s'].divide(icom['cntSum_gt2s'])
icom['cntSum_lt2s_dv_gt2s_bk'] = icom.groupby('datadate')['cntSum_lt2s_dv_gt2s'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cntSum_lt2s_dv_gt2s_bk'], 
                 'cntSum_lt2s_dv_gt2s') # close to mono: -8 +6 +4

icom['cntAvg_overSec_lt2s_dv_gt2s'] = icom['cntAvg_overSec_lt2s'].divide(icom['cntAvg_overSec_gt2s'])
icom['cntAvg_overSec_lt2s_dv_gt2s_bk'] = icom.groupby('datadate')['cntAvg_overSec_lt2s_dv_gt2s'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cntAvg_overSec_lt2s_dv_gt2s_bk'], 
                 'cntAvg_overSec_lt2s_dv_gt2s') # close to mono: -8 +6 +4


### od cnt lt2s / total od cnt: buy 
# focusing on buy orders is the correct direction
# denominator should also be buy-order focused 

icom['cntSum_b_lt2s_dv_gt2s'] = icom['cntSum_b_lt2s'].divide(icom['cntSum_b_gt2s'])
icom['cntSum_b_lt2s_dv_gt2s_bk'] = icom.groupby('datadate')['cntSum_b_lt2s_dv_gt2s'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cntSum_b_lt2s_dv_gt2s_bk'], 
                 'cntSum_b_lt2s_dv_gt2s') # mono: -5.5 +7.5

icom['cntAvg_b_overSec_lt2s_dv_gt2s'] = icom['cntAvg_b_overSec_lt2s'].divide(icom['cntAvg_b_overSec_gt2s'])
icom['cntAvg_b_overSec_lt2s_dv_gt2s_bk'] = icom.groupby('datadate')['cntAvg_b_overSec_lt2s_dv_gt2s'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cntAvg_b_overSec_lt2s_dv_gt2s_bk'], 
                 'cntAvg_b_overSec_lt2s_dv_gt2s') # mono: -5.5 +7.5

icom['cntAvg_b_overSec_lt2s_dv_bs_gt2s'] = icom['cntAvg_b_overSec_lt2s'].divide(icom['cntAvg_b_overSec_gt2s']+icom['cntAvg_s_overSec_gt2s'])
icom['cntAvg_b_overSec_lt2s_dv_bs_gt2s_bk'] = icom.groupby('datadate')['cntAvg_b_overSec_lt2s_dv_bs_gt2s'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cntAvg_b_overSec_lt2s_dv_bs_gt2s_bk'], 
                 'cntAvg_b_overSec_lt2s_dv_bs_gt2s') # less mono: -1 -5 +8


### od cnt lt2s / total od cnt: near mktOC
# signals from mid-of-the-day is a bit better than mktOC
 
icom['cntSum_b_lt2s_dv_gt2s_mktOC'] = icom['cntSum_b_lt2s_mktOC'].divide(icom['cntSum_b_gt2s_mktOC'])
icom['cntSum_b_lt2s_dv_gt2s_mktOC_bk'] = icom.groupby('datadate')['cntSum_b_lt2s_dv_gt2s_mktOC'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cntSum_b_lt2s_dv_gt2s_mktOC_bk'], 
                 'cntSum_b_lt2s_dv_gt2s_mktOC') # less mono: -1.5 -4 +6.5

icom['cntSum_b_lt2s_dv_gt2s_mktOC2'] = icom[
'cntSum_b_lt2s_mktOC'].divide(icom['cntSum_b_gt2s'])
icom['cntSum_b_lt2s_dv_gt2s_mktOC2_bk'] = icom.groupby('datadate')['cntSum_b_lt2s_dv_gt2s_mktOC2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cntSum_b_lt2s_dv_gt2s_mktOC2_bk'], 
                 'cntSum_b_lt2s_dv_gt2s_mktOC2') # mono: -2 +3.5

icom['cntSum_b_lt2s_dv_gt2s_mktMid'] = (icom['cntSum_b_lt2s']-icom['cntSum_b_lt2s_mktOC']).divide(icom['cntSum_b_gt2s']-icom['cntSum_b_gt2s_mktOC'])
icom['cntSum_b_lt2s_dv_gt2s_mktMid_bk'] = icom.groupby('datadate')['cntSum_b_lt2s_dv_gt2s_mktMid'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cntSum_b_lt2s_dv_gt2s_mktMid_bk'], 
                 'cntSum_b_lt2s_dv_gt2s_mktMid') # less mono: -2.5 -4.5 +7

icom['cntSum_b_lt2s_dv_gt2s_mktMid2'] = (icom['cntSum_b_lt2s']-icom['cntSum_b_lt2s_mktOC']).divide(icom['cntSum_b_gt2s'])
icom['cntSum_b_lt2s_dv_gt2s_mktMid2_bk'] = icom.groupby('datadate')['cntSum_b_lt2s_dv_gt2s_mktMid2'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cntSum_b_lt2s_dv_gt2s_mktMid2_bk'], 
                 'cntSum_b_lt2s_dv_gt2s_mktMid2') # mono: -5 +7




### od cnt lt2s - gt2s: Buy
# lt2 - gt2, excluding negative data points, is a good technique 

icom['cntAvg_b_lt2s_dv_gt2s'] = (icom['cntAvg_b_overSec_lt2s'] - icom['cntAvg_b_overSec_gt2s']).divide(icom['cntSum_b_lt2s']+icom['cntSum_b_gt2s'])
icom['cntAvg_b_lt2s_dv_gt2s_bk'] = icom.groupby('datadate')['cntAvg_b_lt2s_dv_gt2s'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cntAvg_b_lt2s_dv_gt2s_bk'], 'cntAvg_b_lt2s_dv_gt2s') # mono: -5.5 +7.5

icom['cntAvg_b_lt2s_dv_gt2s_xNeg'] = np.nan
c1 = icom['cntAvg_b_lt2s_dv_gt2s']>0
icom.loc[c1, 'cntAvg_b_lt2s_dv_gt2s_xNeg'] = icom.loc[c1, 'cntAvg_b_lt2s_dv_gt2s']
icom['cntAvg_b_lt2s_dv_gt2s_xNeg_bk'] = icom.groupby('datadate')['cntAvg_b_lt2s_dv_gt2s_xNeg'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cntAvg_b_lt2s_dv_gt2s_xNeg_bk'], 'cntAvg_b_lt2s_dv_gt2s_xNeg') # mono: -7.5 +8

icom['cntAvg_b_lt2s_dv_gt2s_winsor0'] = np.nan
c1 = icom['cntAvg_b_lt2s_dv_gt2s']>0
icom.loc[c1, 'cntAvg_b_lt2s_dv_gt2s_winsor0'] = icom.loc[c1, 'cntAvg_b_lt2s_dv_gt2s']
icom.loc[~c1, 'cntAvg_b_lt2s_dv_gt2s_winsor0'] = 0
icom['cntAvg_b_lt2s_dv_gt2s_winsor0_bk'] = icom.groupby('datadate')['cntAvg_b_lt2s_dv_gt2s_winsor0'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['cntAvg_b_lt2s_dv_gt2s_winsor0_bk'], 'cntAvg_b_lt2s_dv_gt2s_winsor0') # less m
ono: 0 -6 +8



### zscore
# zscore is not better

icom['z'] = (icom['cntAvg_overSec_lt2s']-icom['cntAvg_overSec_gt2s']).divide(icom['cntStd_overSec_gt2s'])
icom['z_bk'] = icom.groupby('datadate')['z'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['z_bk'], 'z') # mono: -6 +4 +3

icom['z_b'] = (icom['cntAvg_b_overSec_lt2s']-icom['cntAvg_b_overSec_gt2s']).divide(icom['cntStd_b_overSec_gt2s'])
icom['z_b_bk'] = icom.groupby('datadate')['z_b'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['z_b_bk'], 'z_b') # mono: -6.5 +5.5, but monotonicity worse than cnt-based metrics

icom['z_b_mktMid'] = (icom['cntAvg_b_overSec_lt2s']-icom['cntAvg_b_overSec_lt2s_mktOC']-icom['cntAvg_b_overSec_gt2s']+icom['cntAvg_b_overSec_gt2s_mktOC']).divide(icom['cntStd_b_overSec_gt2s']*2-icom['cntStd_b_overSec_gt2s_mktOC'])
icom['z_b_mktMid_bk'] = icom.groupby('datadate')['z_b_mktMid'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['z_b_mktMid_bk'], 'z_b_mktMid') # mono: -5.5 +5



### trailing of od cnt lt2s / total od cnt: buy 
# 20d is better than 60d
# taking ln no big differnce because b_ratio looks like a skewed normal 

icom['b_ratio'] = icom['cntSum_b_lt2s'].divide(icom['cntSum_b_gt2s']+icom['cntSum_b_lt2s'])
icom['b_ratio_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['b_ratio'].mean().values
icom['b_ratio_t20d_rk'] = icom.groupby('datadate')['b_ratio_t20d'].apply(yu.uniformed_rank).values
icom['b_ratio_t60d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=84),on='datadate')['b_ratio'].mean().values
icom['b_ratio_t60d_rk'] = icom.groupby('datadate')['b_ratio_t60d'].apply(yu.uniformed_rank).values
icom['b_ratioLn'] = np.log(icom['b_ratio'])
icom['b_ratioLn'] = icom['b_ratioLn'].replace(-np.inf, np.nan).replace(np.inf, np.nan)
icom['b_ratioLn_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['b_ratioLn'].mean().values
icom['b_ratioLn_t20d_rk'] = icom.groupby('datadate')['b_ratioLn_t20d'].apply(yu.uniformed_rank).values
icom['b_ratioLn_t60d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=84),on='datadate')['b_ratioLn'].mean().values
icom['b_ratioLn_t60d_rk'] = icom.groupby('datadate')['b_ratioLn_t60d'].apply(yu.uniformed_rank).values

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['b_ratio_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'b_ratio
_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.1/2.72, 2.6e7

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['b_ratio_t60d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'b_ratio_t60d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 2.96/2.26, 2.25e7

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['b_ratioLn_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'b_ratioLn_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.05/2.65, 2.6e7

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['b_ratioLn_t60d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'b_ratioLn_t60d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.02/2.31, 2.3e7



### trailing of od cnt lt2s - od cnt gt2s
# 20d better, sum better than avg when trailing

icom['cntAvg_b_lt2s_m_gt2s'] = (icom['cntAvg_b_overSec_lt2s'] - icom['cntAvg_b_overSec_gt2s']).divide(icom['cntSum_b_lt2s']+icom['cntSum_b_gt2s'])

icom['cntAvg_b_lt2s_m_gt2s_xNeg'] = np.nan
c1 = icom['cntAvg_b_lt2s_m_gt2s']>0
icom.loc[c1, 'cntAvg_b_lt2s_m_gt2s_xNeg'] = icom.loc[c1, 'cntAvg_b_lt2s_m_gt2s']


icom['cntAvg_b_lt2s_m_gt2s_xNeg_t20davg'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['cntAvg_b_lt2s_m_gt2s_xNeg'].mean().values
icom['cntAvg_b_lt2s_m_gt2s_xNeg_t20davg_bk'] = icom.groupby('datadate')['cntAvg_b_lt2s_m_gt2s_xNeg_t20davg'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cntAvg_b_lt2s_m_gt2s_xNeg_t20dsum'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['cntAvg_b_lt2s_m_gt2s_xNeg'].sum().values
icom['cntAvg_b_lt2s_m_gt2s_xNeg_t20dsum_bk'] = icom.groupby('datadate')['cntAvg_b_lt2s_m_gt2s_xNeg_t20dsum'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cntAvg_b_lt2s_m_gt2s_xNeg_t60davg'] = icom.groupby('ticker').rolling(datetime.timedelta(days=84),on='datadate')['cntAvg_b_lt2s_m_gt2s_xNeg'].mean().values
icom['cntAvg_b_lt2s_m_gt2s_xNeg_t60davg_bk'] = icom.groupby('datadate')['cntAvg_b_lt2s_m_gt2s_xNeg_t60davg'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['cntAvg_b_lt2s_m_gt2s_xNeg_t60dsum'] = icom.groupby('ticker').rolling(datetime.timedelta(days=84),on='datadate')['cntAvg_b_lt2s_m_gt2s_xNeg'].sum().values
icom['cntAvg_b_lt2s_m_gt2s_xNeg_t60dsum_bk'] = icom.groupby('datadate')['cntAvg_b_lt2s_m_gt2s_xNeg_t60dsum']
.apply(lambda x: yu.pdqcut(x,bins=10)).values

yu.create_cn_3x3(icom, ['cntAvg_b_lt2s_m_gt2s_xNeg_t20davg_bk'], 'cntAvg_b_lt2s_m_gt2s_xNeg_t20davg') # -8.5 +4
yu.create_cn_3x3(icom, ['cntAvg_b_lt2s_m_gt2s_xNeg_t20dsum_bk'], 'cntAvg_b_lt2s_m_gt2s_xNeg_t20dsum') # -8.5 +4.5
yu.create_cn_3x3(icom, ['cntAvg_b_lt2s_m_gt2s_xNeg_t60davg_bk'], 'cntAvg_b_lt2s_m_gt2s_xNeg_t60davg') # -3.5 +3.8
yu.create_cn_3x3(icom, ['cntAvg_b_lt2s_m_gt2s_xNeg_t60dsum_bk'], 'cntAvg_b_lt2s_m_gt2s_xNeg_t60dsum') # -5 +3




### orth of od cnt lt2s / total od cnt: buy 

icom['b_ratio'] = icom['cntSum_b_lt2s'].divide(icom['cntSum_b_gt2s']+icom['cntSum_b_lt2s'])
icom['b_ratio_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['b_ratio'].mean().values
icom['b_ratio_t20d_orth'] = icom.groupby('datadate')[['b_ratio_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['b_ratio_t20d'], x[COLS])).values
icom['b_ratio_t20d_orth_bk'] = icom.groupby('datadate')['b_ratio_t20d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['b_ratio_t20d_orth_rk'] = icom.groupby('datadate')['b_ratio_t20d_orth'].apply(yu.uniformed_rank).values
icom['b_ratio_t60d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=84),on='datadate')['b_ratio'].mean().values
icom['b_ratio_t60d_orth'] = icom.groupby('datadate')[['b_ratio_t60d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['b_ratio_t60d'], x[COLS])).values
icom['b_ratio_t60d_orth_rk'] = icom.groupby('datadate')['b_ratio_t60d_orth'].apply(yu.uniformed_rank).values
icom['b_ratio_orth'] = icom.groupby('datadate')[['b_ratio']+COLS].apply(lambda x: yu.orthogonalize_cn(x['b_ratio'], x[COLS])).values
icom['b_ratio_orth_bk'] = icom.groupby('datadate')['b_ratio_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['b_ratio_orth_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['b_ratio_orth'].mean().values
icom['b_ratio_orth_t20d_bk'] = icom.groupby('datadate')['b_ratio_orth_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['b_ratio_orth_t20d_rk'] = icom.groupby('datadate')['b_ratio_orth_t20d'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icom, ['b_ratio_orth_t20d_bk'], 'b_ratio_orth_t20d') # mono: -7 +5.5
yu.create_cn_3x3(icom, ['b_ratio_t20d_orth_bk'], 'b_ratio_t20d_orth') # mono: -9 +6.5
yu.create_cn_3x3(icom, ['b_ratio_orth_bk'], 'b_ratio_orth') # mono: -4 +9

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['b_ratio_t20d_orth_rk','BarrRet_CLIP_US
D+1d']).drop_duplicates(subset=['ticker','datadate']),
            'b_ratio_t20d_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.55/2.96, 3.1e7 
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['b_ratio_t60d_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'b_ratio_t60d_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.05/2.18, 2.5e7
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['b_ratio_orth_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'b_ratio_orth_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.8/2.14, 2.2e7



icom['b_ratioLn'] = np.log(icom['b_ratio'])
icom['b_ratioLn'] = icom['b_ratioLn'].replace(-np.inf, np.nan).replace(np.inf, np.nan)
icom['b_ratioLn_orth'] = icom.groupby('datadate')[['b_ratioLn']+COLS].apply(lambda x: yu.orthogonalize_cn(x['b_ratioLn'], x[COLS])).values
icom['b_ratioLn_orth_bk'] = icom.groupby('datadate')['b_ratioLn_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['b_ratioLn_orth_bk'], 'b_ratioLn_orth') # mono: -4 +9



### orth of od cnt lt2s - od cnt gt2s
# yes this alpha is the best 
# sum and avg in 20d trailing window no material difference 


icom['b_avgdf'] = (icom['cntAvg_b_overSec_lt2s'] - icom['cntAvg_b_overSec_gt2s']).divide(icom['cntSum_b_lt2s']+icom['cntSum_b_gt2s'])

icom['b_avgdf_xNeg'] = np.nan
c1 = icom['b_avgdf']>0
icom.loc[c1, 'b_avgdf_xNeg'] = icom.loc[c1, 'b_avgdf']



icom['b_avgdf_xNeg_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['b_avgdf_xNeg'].sum().values
icom['b_avgdf_xNeg_t20d_bk'] = icom.groupby('datadate')['b_avgdf_xNeg_t20d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['b_avgdf_xNeg_t20d_rk'] = icom.groupby('datadate')['b_avgdf_xNeg_t20d'].apply(yu.uniformed_rank).values

icom['b_avgdf_xNeg_t20d_orth'] = icom.groupby('datadate')[['b_avgdf_xNeg_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['b_avgdf_xNeg_t20d'], x[COLS])).values
icom['b_avgdf_xNeg_t20d_orth_rk'] = icom.groupby('datadate')['b_avgdf_xNeg_t20d_orth'].apply(yu.uniformed_rank).values
icom['b_avgdf_xNeg_t20d_orth_bk'] = icom.groupby('datadate')['b_avgdf_xNeg_t20d_orth'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['b_avgdf_xNeg_t40d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=56),on='datadate')['b_avgdf_xNeg'].sum().values
icom['b_avgdf_xNeg_t40d_bk'] = icom.gr
oupby('datadate')['b_avgdf_xNeg_t40d'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['b_avgdf_xNeg_t40d_rk'] = icom.groupby('datadate')['b_avgdf_xNeg_t40d'].apply(yu.uniformed_rank).values

icom['b_avgdf_xNeg_t40d_orth'] = icom.groupby('datadate')[['b_avgdf_xNeg_t40d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['b_avgdf_xNeg_t40d'], x[COLS])).values
icom['b_avgdf_xNeg_t40d_orth_rk'] = icom.groupby('datadate')['b_avgdf_xNeg_t40d_orth'].apply(yu.uniformed_rank).values

icom['b_avgdf_xNeg_ln'] = np.log(icom['b_avgdf_xNeg'])
icom['b_avgdf_xNeg_ln_t20d'] = icom.groupby('ticker').rolling(datetime.timedelta(days=28),on='datadate')['b_avgdf_xNeg_ln'].mean().values
icom['b_avgdf_xNeg_ln_t20d_orth'] = icom.groupby('datadate')[['b_avgdf_xNeg_ln_t20d']+COLS].apply(lambda x: yu.orthogonalize_cn(x['b_avgdf_xNeg_ln_t20d'], x[COLS])).values
icom['b_avgdf_xNeg_ln_t20d_orth_rk'] = icom.groupby('datadate')['b_avgdf_xNeg_ln_t20d_orth'].apply(yu.uniformed_rank).values


yu.create_cn_3x3(icom, ['b_avgdf_xNeg_t20d_orth_bk'], 'b_avgdf_xNeg_t20d_orth') # mono: -10 +6.5
yu.create_cn_3x3(icom, ['b_avgdf_xNeg_t20d_bk'], 'b_avgdf_xNeg_t20d') # mono: -8 +4
yu.create_cn_3x3(icom, ['b_avgdf_xNeg_t40d_bk'], 'b_avgdf_xNeg_t40d') # mono: -4.8 +4.5

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['b_avgdf_xNeg_t20d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'b_avgdf_xNeg_t20d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.09/2.8, 2.9e7
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['b_avgdf_xNeg_t40d_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'b_avgdf_xNeg_t40d_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.34/2.5, 2.5e7



o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['b_avgdf_xNeg_t20d_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'b_avgdf_xNeg_t20d_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.9/3.38, 4e7 ###!!!
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['b_avgdf_xNeg_t20d_orth_rk']>0)].\
            dropna(subset=['b_avgdf_xNeg_t20d_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'b_avgdf_xNeg_t20d_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.86 / 2.46, 1.5e7
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')&(icom['ticker'].str.contains('SZ
'))].\
            dropna(subset=['b_avgdf_xNeg_t20d_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'b_avgdf_xNeg_t20d_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.84/3.29
o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['b_avgdf_xNeg_t20d_orth_rk','RawRet_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'b_avgdf_xNeg_t20d_orth_rk','RawRet_USD+1d', static_data = i_sd) # 2.71 / 1.96

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['b_avgdf_xNeg_t40d_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'b_avgdf_xNeg_t40d_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 3.85/2.83, 3.2e7

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-12-31')].\
            dropna(subset=['b_avgdf_xNeg_ln_t20d_orth_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'b_avgdf_xNeg_ln_t20d_orth_rk','BarrRet_CLIP_USD+1d', static_data = i_sd) # 4.56/2.94, 3.6e7
