﻿#$%^&* pCorpAct_cn_buyback_etl.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu Jun  9 20:53:16 2022

@author: thzhang
"""




import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import os
import gzip
import datetime
import zipfile




### get bbgbo buyback v2 (2019 onwards)


std_cols = ['ticker', 'ID_BB_COMPANY', 'ID_BB_SECURITY', 'RCODE', 'ACTION_ID', 
            'CAX_Mnemonic', 'Flag', 'CompanyName', 'SecIDType', 'SecID', 'Currency', 
            'MarketSectorDesc', 'BBG_unique_id','ann_dt','eff_dt','amd_dt',
            'BBG_global_id', 'BBG_global_company_id', 'BBG_sec_id_desc', 
            'feed_source', 'nfields']


fs_v2 = []
for yr in [i for i in os.listdir(r'Z:\BloombergBackOffice\CorpActionsV2\Asia') if len(i)==4]:
    dir_yr = os.path.join(r'Z:\BloombergBackOffice\CorpActionsV2\Asia', yr)
    for r,p,fs in os.walk(dir_yr):
        for f in fs:
            if ('equityAsia2CorporateActionsV2.cax.' in f ) and f.endswith('.gz'):
                fs_v2.append([r, f, os.path.join(r, f), 'afterMkt', os.path.getmtime(os.path.join(r, f))])
            if ('premarketEquityAsia2CorporateActionsV2.cax.' in f ) and f.endswith('.gz'):
                fs_v2.append([r, f, os.path.join(r, f), 'preMkt', os.path.getmtime(os.path.join(r, f))])
fs_v2 = pd.DataFrame(fs_v2, columns = ['r', 'f', 'p', 'type', 'mtime_est'])
fs_v2['date'] = fs_v2['p'].str.extract('(\d{8})')
fs_v2['date'] = pd.to_datetime(fs_v2['date'], format = '%Y%m%d')
fs_v2['mtime_est'] = pd.to_datetime(fs_v2['mtime_est'], unit='s')
fs_v2['mtime_cn'] = fs_v2['mtime_est'].dt.tz_localize('US/Eastern').dt.tz_convert('Asia/Shanghai').dt.tz_localize(None)


i_buyback_v2 = []
for i, r in fs_v2.iterrows():
    print('.', end='')
    t_data = gzip.open(r['p'],"r").read().decode('utf8')
    t_data = t_data.split('\n')
    t_data = t_data[ t_data.index('START-OF-DATA')+1 : t_data.index('END-OF-DATA') ]
    t_data = [l for l in t_data if not ((l.split('|')[-2]=='300')&(l.count('|')==4)) ]
    t_data = [l for l in t_data if 'CH Equity' in l.split('|')[0]]
    for l in t_data:
        l_list = l.split('|')[:-1]
        l_dict = {i2: i1 for i1, i2 in zip(l_list[:21], std_cols)}
        l_dict['datadate'] = pd.to_datetime(r['f'][-11:-3], format='%Y%m%d')
        l_dict['mtime_cn'] = r['mtime_cn']
        l_list_others = l_list[21:]
        if len(l_list_others)%2!=0:
            raise Exception()
        l_others_dict = {l_list_others[n*2]:l_list_others[n*2+1] for n in range(l
en(l_list_others)//2)}
        l_dict.update(l_others_dict)
        if l_dict['CAX_Mnemonic']=='STOCK_BUY':
            i_buyback_v2.append(l_dict)
        
i_buyback_v2 = pd.DataFrame(i_buyback_v2)

i_buyback_v2.to_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_buyback_etl_v2.parquet')

i_buyback_v2 = pd.read_parquet(r'S:\Data\China Data Hunt\cache\pCorpAct_cn_buyback_etl_v2.parquet')






###  get bbgbo equity DVD thru 2019.08.12
# v1 doesn't have buyback type (secondary market / tender)


fs_v1 = []
for yr in ['2013','2014','2015','2016','2017','2018','2019']:
    dir_yr = os.path.join(r'Z:\BloombergBackOffice\Equity\Asia', yr)
    for r,p,fs in os.walk(dir_yr):
        for f in fs:
            if ('equity_asia2.cax.' in f ) and f.endswith('.gz'):
                fs_v1.append([r, f, os.path.join(r, f), 'v1'])
fs_v1 = pd.DataFrame(fs_v1, columns = ['r', 'f', 'p', 'type'])
fs_v1['date'] = fs_v1['p'].str.extract('(\d{8})')
fs_v1['date'] = pd.to_datetime(fs_v1['date'], format = '%Y%m%d')
fs_v1 = fs_v1[fs_v1['date']<='2019-08-12']


i_buyback_v1 = []
for i, r in fs_v1.iterrows():
    print('.', end='')
    t_data = gzip.open(r['p'],"r").read().decode('utf8')
    t_data = t_data.split('\n')
    t_data = t_data[ t_data.index('START-OF-DATA')+1 : t_data.index('END-OF-DATA') ]
    t_data = [l for l in t_data if not ((l.split('|')[-2]=='300')&(l.count('|')==4)) ]
    t_data = [l for l in t_data if 'CH Equity' in l.split('|')[0]]
    for l in t_data:
        l_list = l.split('|')[:-1]
        l_dict = {i2: i1 for i1, i2 in zip(l_list[:21], std_cols)}
        l_dict['datadate'] = pd.to_datetime(r['f'][-11:-3], format='%Y%m%d')
        l_list_others = l_list[21:]
        if len(l_list_others)%2!=0:
            raise Exception()
        l_others_dict = {l_list_others[n*2]:l_list_others[n*2+1] for n in range(len(l_list_others)//2)}
        l_dict.update(l_others_dict)
        if l_dict['CAX_Mnemonic']=='STOCK_BUY':
            i_buyback_v1.append(l_dict)

i_buyback_v1 = pd.DataFrame(i_buyback_v1)

