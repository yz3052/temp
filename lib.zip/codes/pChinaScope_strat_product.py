﻿#$%^&* pChinaScope_strat_product.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat Nov 27 20:12:29 2021

@author: thzhang
"""


import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw


### get china scope


i_product = pd.read_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\product.parquet',
                            columns = ['productCode','chineseName','newsId','relevance','emotionDetail'])
i_product = i_product.drop_duplicates()


i_company = pd.read_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\company.parquet',
                            columns = ['stockCode','newsId'])
i_company = i_company[i_company['stockCode'].str.contains('\d{6}') &\
                      i_company['stockCode'].str.contains('S[HZ]') &\
                      i_company['stockCode'].str[0].isin(['0','3','6']) ]
i_company['ticker'] = i_company['stockCode'].str.split('_').str[0]+'.'+i_company['stockCode'].str.split('_').str[1]
i_company = i_company.drop(columns=['stockCode'])
i_company = i_company.drop_duplicates(subset = ['ticker','newsId'])


i_info = pd.read_parquet(r'S:\Data\China Data Hunt\ChinaScope\cache\info.parquet',
                         columns = ['newsId','newsTs','newsTitle_cn','newsSummary'])
i_info = i_info.drop_duplicates()


i_news_com = i_company.merge(i_info, on = ['newsId'], how = 'left')
i_news_com = i_news_com.merge(i_product, on = ['newsId'], how = 'left')
i_news_com = i_news_com[i_news_com['productCode'].notnull()]
i_news_com['datadate'] = pd.to_datetime(pd.to_datetime(i_news_com['newsTs']).dt.date)+pd.to_timedelta('1 day')

i_news_com = i_news_com[i_news_com['relevance']>=0.4] ###!!!


### generate daily metrics based on china scope

o_cs_metrics = []

for dt in pd.date_range(start = '2016-01-01', end = '2020-12-31'):
    print(dt.strftime('%Y%m%d'), end = ' ')
    
    t_news_com = i_news_com[(i_news_com['datadate']<=dt)]
    
    tall_prd_cnt = t_news_com.groupby('ticker')['productCode'].nunique().reset_index()
    tall_prd_cnt = tall_prd_cnt.rename(columns={'productCode':'prd_cnt_tall'})
    
    t1y_prd_cnt = t_news_com[t_news_com['datadate']>dt-pd.to_timedelta('365 days')].groupby('ticker')['productCode'].nunique().reset_index()
    t1y_prd_cnt = t1y_prd_cnt.rename(columns={'productCode':'prd_cnt_t1y'})
    
    t2y_prd_cnt = t_news_com[t_news_com['datadate']>dt-pd.to_timedelta('730 days')].groupby('ticker')['productCode'].nunique().reset_index()
    t2y_prd_cnt = t2y_prd_cnt.rename(columns={'productCode':'
prd_cnt_t2y'})
    
    t_cs_metric = tall_prd_cnt.merge(t2y_prd_cnt, on = 'ticker', how = 'outer')
    t_cs_metric = t_cs_metric.merge(t1y_prd_cnt, on = 'ticker', how = 'outer')
    t_cs_metric['datadate'] = dt
    
    o_cs_metrics.append(t_cs_metric)
    
o_cs_metrics = pd.concat(o_cs_metrics, axis = 0)



### get sd

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d',
                 'isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d',
                 'a50_300_flag','a50_flag','csi300_flag',
                 'EARNYILD','GROWTH']]


### combine

    
icom = i_sd_map.merge(o_cs_metrics, on = ['ticker','datadate'], how = 'left')
icom['prd_cnt_t1y'] = icom['prd_cnt_t1y'].replace(0, np.nan)
icom['prd_cnt_t2y'] = icom['prd_cnt_t2y'].replace(0, np.nan)
icom['prd_cnt_tall'] = icom['prd_cnt_tall'].replace(0,np.nan)

icom['GROWTH_5bk'] = icom.groupby('datadate')['GROWTH'].apply(lambda x: yu.pdqcut(x,bins=5)).values

icom['prdAll_rk'] = icom.groupby('datadate')['prd_cnt_tall'].apply(yu.uniformed_rank).values
icom['prdAll_bk'] = icom.groupby('datadate')['prd_cnt_tall'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['prdAll_secbk'] = icom.groupby(['datadate','GSECTOR'])['prd_cnt_tall'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['prdAll_secrk'] = icom.groupby(['datadate','GSECTOR'])['prd_cnt_tall'].apply(yu.uniformed_rank).values

icom['prdAll_dv_mc'] = icom['prd_cnt_tall'].divide(icom['MC_l1d'])
icom['prdAll_dv_mc_bk'] = icom.groupby('datadate')['prdAll_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['prdAll_dv_mc_rk'] = icom.groupby('datadate')['prdAll_dv_mc'].apply(yu.uniformed_rank).values

icom['prd2y_rk'] = icom.groupby('datadate')['prd_cnt_t2y'].apply(yu.uniformed_rank).values
icom['prd2y_bk'] = icom.groupby('datadate')['prd_cnt_t2y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['prd2y_secbk'] = icom.groupby(['datadate','GSECTOR'])['prd_cnt_t2y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['prd2y_secrk'] = icom.groupby(['datadate','GSECTOR'])['prd_cnt_t2y'].apply(yu.uniformed_rank).values
icom['prd2y_gindbk'] = icom.groupby(['datadate','GIND'])['prd_cnt_t2y'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['prd2y_grthbk'] = icom.groupby(['datadate','GROWTH_5bk'])['prd_cnt_t2y'].apply(lambda x: yu.pdqcut
(x,bins=10)).values

icom['prd1y_rk'] = icom.groupby('datadate')['prd_cnt_t1y'].apply(yu.uniformed_rank).values
icom['prd1y_bk'] = icom.groupby('datadate')['prd_cnt_t1y'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['prd_all_2y_rkdf'] = icom['prd2y_rk'] - icom['prdAll_rk']
icom['prd_all_2y_rkdf_rk'] = icom.groupby('datadate')['prd_all_2y_rkdf'].apply(yu.uniformed_rank).values
icom['prd_all_2y_rkdf_bk'] = icom.groupby('datadate')['prd_all_2y_rkdf'].apply(lambda x: yu.pdqcut(x,bins=10)).values

icom['prd_cnt_t1y_dv_mc'] = icom['prd_cnt_t1y'].divide(icom['MC_l1d'])
icom['prd_cnt_t1y_dv_mc_bk'] = icom.groupby('datadate')['prd_cnt_t1y_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['prd_cnt_t1y_dv_mc_secbk'] = icom.groupby(['datadate','GSECTOR'])['prd_cnt_t1y_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['prd_cnt_t1y_dv_mc_rk'] = icom.groupby('datadate')['prd_cnt_t1y_dv_mc'].apply(yu.uniformed_rank).values

icom['prd_cnt_t2y_dv_mc'] = icom['prd_cnt_t2y'].divide(icom['MC_l1d'])
icom['prd_cnt_t2y_dv_mc_bk'] = icom.groupby('datadate')['prd_cnt_t2y_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['prd_cnt_t2y_dv_mc_secbk'] = icom.groupby(['datadate','GSECTOR'])['prd_cnt_t2y_dv_mc'].apply(lambda x: yu.pdqcut(x,bins=10)).values
icom['prd_cnt_t2y_dv_mc_rk'] = icom.groupby('datadate')['prd_cnt_t2y_dv_mc'].apply(yu.uniformed_rank).values

yu.create_cn_3x3(icom, ['prdAll_bk'], 'prd_cnt_tall')
yu.create_cn_3x3(icom, ['prdAll_secbk'], 'prd_cnt_tall') 
yu.create_cn_3x3(icom, ['prdAll_dv_mc_bk'], 'prdAll_dv_mc') # not better
yu.create_cn_3x3(icom, ['prd1y_bk'], 'prd_cnt_t1y')
yu.create_cn_3x3(icom, ['prd2y_bk'], 'prd_cnt_t2y')
yu.create_cn_3x3(icom, ['prd2y_secbk'], 'prd_cnt_t2y') # this is better
yu.create_cn_3x3(icom, ['prd2y_gindbk'], 'prd_cnt_t2y') # not better
yu.create_cn_3x3(icom, ['prd2y_grthbk'], 'prd_cnt_t2y') # not better
yu.create_cn_3x3(icom, ['prd_cnt_t2y_dv_mc_bk'], 'prd_cnt_t2y_dv_mc') # this is better
yu.create_cn_3x3(icom, ['prd_cnt_t2y_dv_mc_secbk'], 'prd_cnt_t2y_dv_mc') # not better
yu.create_cn_3x3(icom, ['prd_cnt_t1y_dv_mc_bk'], 'prd_cnt_t1y_dv_mc')
yu.create_cn_3x3(icom, ['prd_all_2y_rkdf_bk'], 'prd_all_2y_rkdf') # random


o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')].\
            dropna(subset=['prdAll_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'prdAll_rk','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 2.27/1.65, 0.7bp/d, if no limit on relevance, 



o_1 =
 yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['prd_cnt_t2y_dv_mc_rk']>0)].\
            dropna(subset=['prd_cnt_t2y_dv_mc_rk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'prd_cnt_t2y_dv_mc_rk','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 1.47/0.65, 0.41bp/d

o_1 = yu.bt_cn_15(icom[(icom['datadate']<='2020-01-01')&(icom['prd2y_secrk']>0)].\
            dropna(subset=['prd2y_secrk','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'prd2y_secrk','BarrRet_CLIP_USD+1d', static_data = i_sd_map) # 
