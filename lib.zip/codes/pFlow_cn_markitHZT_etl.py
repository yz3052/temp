﻿#$%^&* pFlow_cn_markitHZT_etl.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 23 11:48:22 2022

@author: thzhang
"""

import pandas as pd

import os
import gc

# this runs quicker on linux


### get file directory

files_3pm = []
for yyyy in ['2019', '2020', '2021', '2022']:
    parent_folder = os.path.join('/dat/mdwarehouse/public/Markit/2713/Data_Insights_v1', yyyy)
    for r,p,fs in os.walk(parent_folder):
        for f in fs:
            if 'Security_Activity_3pm' in f:
                print('.',end='')
                files_3pm.append([r, f, os.path.join(r, f), f[f.index('_3pm') + 5:][:8]])
files_3pm = pd.DataFrame(files_3pm, columns = ['r', 'f', 'p', 'datadate']) 
files_3pm['datadate'] = pd.to_datetime(files_3pm['datadate'], format = '%Y%m%d')



### get HK data - Long/Short Fund Count

o_data_hk = []

for i, r in files_3pm.iterrows():
    
    print('.', end='')
    t_data = pd.read_csv(r['p'], 
                         usecols = ['Position Date', 'Strategy', 'Ticker', 'Long Fund Count', 'Short Fund Count'])
    
    t_data['datadate'] = r['datadate']
    o_data_hk.append(t_data)
    
    t_data = None
    gc.collect()
    
o_data_hk = pd.concat(o_data_hk, axis = 0)

o_data_hk.to_parquet('/dat/summit_capital/Data/China Data Hunt/cache/pFlow_cn_markit_etl_hk_ls_fund_cnt.parquet')


### get AShare data - Long/Short Fund Count

o_data_cn = []

for i, r in files_3pm.iterrows():
    
    t_data = pd.read_csv(r['p'], 
                         usecols = ['Position Date', 'Strategy', 'Ticker', 'Long Fund Count', 'Short Fund Count'])
    
    t_data_cn = t_data[t_data['Ticker'].str[-3:].isin([' CH', ' C1', ' C2'])]
    t_data_cn['datadate'] = r['datadate']
    o_data_cn.append(t_data_cn)
    
    t_data = None
    t_data_cn = None
    gc.collect()
    
o_data_cn = pd.concat(o_data_cn, axis = 0)

o_data_cn.to_parquet('/dat/summit_capital/Data/China Data Hunt/cache/pFlow_cn_markit_etl_cn_ls_fund_cnt.parquet')




