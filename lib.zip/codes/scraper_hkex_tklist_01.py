﻿#$%^&* scraper_hkex_tklist_01.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 23 10:55:05 2021

@author: thzhang
"""

import requests
r = requests.get('https://www.hkex.com.hk/-/media/HKEX-Market/Mutual-Market/Stock-Connect/Eligible-Stocks/View-All-Eligible-Securities_xls/Change_of_SSE_Securities_Lists.xls?la=en').content
r.decode('utf-8')

import io
import pandas as pd


t1 = pd.read_excel(io.StringIO(r.decode('latin-1')), encoding = 'latin1')



r_b_n_s = requests.get('https://www.hkex.com.hk/-/media/HKEX-Market/Mutual-Market/Stock-Connect/Eligible-Stocks/View-All-Eligible-Securities/SSE_Securities.xls?la=en', proxies = proxies)
i_b_n_s = pd.read_excel(BytesIO(r_b_n_s.content), names=['no','stock_code','ccass','stock_name','nominal_value'])

