﻿#$%^&* pCorpAct_cn_cb_premium.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 19 09:37:04 2022

@author: thzhang
"""



import pandas as pd
import numpy as nnp

import pWIND_util as pw
import yz.util as yu


# very negative premium is usually cased by big rally in stocks
# to arbitrage negative premium, we need to long CB, then short stock.
# yes there is some negative alpha in stocks, but only 3 bp. 





### sd


i_sd = pw.get_ashare_t2000_sd()




### cb-stock ticker mapping 

i_cb = yu.get_sql('''select a.s_info_windcode as ticker_cb, a.ann_dt, a.cb_info_preplandate, a.s_info_compcode,
                  b.s_info_windcode as ticker 
 from wind.dbo.CCBondIssuance a
 left join (select * from wind.dbo.WindCustomCode where S_INFO_SECURITIESTYPES='A') b
 on a.s_info_compcode = b.s_info_compcode
''')

i_cb = i_cb[i_cb['ticker'].notnull() & i_cb['ticker_cb'].notnull()]
i_cb = i_cb[['ticker', 'ticker_cb']]



### conversion premium 

i_premium = yu.get_sql('''select trade_Dt as datadate, s_info_windcode as ticker_cb, cb_anal_convpremiumratio
                       from wind.dbo.CCBondValuation''')
i_premium['datadate'] = pd.to_datetime(i_premium['datadate'], format = '%Y%m%d')

i_premium = i_premium.merge(i_cb, on = 'ticker_cb', how = 'left')



### combine

icom = i_sd.merge(i_premium,  on = ['ticker', 'datadate'], how = 'left')
icom = icom.sort_values(['ticker', 'datadate'])

icom.groupby('datadate')['cb_anal_convpremiumratio'].count().plot()

icom['cb_anal_convpremiumratio_bk'] = icom.groupby('datadate')['cb_anal_convpremiumratio'].apply(lambda x: yu.pdqcut(x, bins=10)).values

yu.create_cn_3x3(icom, ['cb_anal_convpremiumratio_bk'], 'cb_anal_convpremiumratio')
yu.create_cn_3x3(icom, ['cb_anal_convpremiumratio_bk'], 'cb_anal_convpremiumratio', col_ret = 'BarrRet_CLIP_USD+3d')
yu.create_cn_3x3(icom, ['cb_anal_convpremiumratio_bk'], 'cb_anal_convpremiumratio', col_ret = 'BarrRet_CLIP_USD-1d')











