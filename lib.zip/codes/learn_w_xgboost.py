﻿#$%^&* learn_w_xgboost.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 13 10:49:22 2023

@author: fgao
"""

import xgboost as xgb
import pandas as pd
import numpy as np
from typing import Tuple
import optuna
from optuna.samplers import TPESampler
import json
from threading import Thread
import os

# =============================================================================
# 
# =============================================================================


def RscoreMetric(predt: np.ndarray, dtrain: xgb.DMatrix) -> Tuple[str,float]:

    y = dtrain.get_label()
    w = dtrain.get_weight()
    msqe = np.multiply(np.power((predt - y), 2), w)
    mmu = np.multiply(np.power((y - np.mean(y)), 2), w)
    rsquare = 1 - np.sum(msqe) / np.sum(mmu)
    rscore = max([-1,np.sign(rsquare)*np.sqrt(abs(rsquare))])

    return 'rscore', -rscore


def NegLogLoss(predt: np.ndarray, dtrain: xgb.DMatrix) -> Tuple[str,float]:

    y = dtrain.get_label()
    w = dtrain.get_weight()

    nll = np.zeros(len(y))

    condition = (predt > 0.5) & (y==1)
    nll[condition] = np.log(predt[condition])
    condition = (predt < 0.5) & (y==0)
    nll[condition] = np.log(1-predt[condition])

    nll = np.sum(np.multiply(w,nll)) / np.sum(w)

    return 'nll', -nll


def PurgedKFold(df_trains,df_calendars,purged_days,fold,cv_rows):

    rows_windows = df_trains.groupby('DataDate')['Ticker'].count()
    rows_windows = dict(rows_windows)

    dates_windows = df_trains[['DataDate']].drop_duplicates()
    dates_windows = dates_windows.sort_values('DataDate',ascending=False)
    dates_windows = dates_windows['DataDate'].tolist()
    dates_max = max(dates_windows)

    l = 0
    c = 1
    cv_dates = []
    for dd in dates_windows:
        if c <= fold:
            l = l + len(df_trains[ df_trains['DataDate'] == dd ])
            if l < cv_rows:
                cv_dates.append([dd,c])
            else:
                l = 0
                c = c + 1

    cv_dates = pd.DataFrame(cv_dates,columns=['DataDate','cv_fold'])

    train_dates = []
    for f in range(1,fold+1):
        cvd_min = cv_dates[ cv_dates['cv_fold'] == f ]['DataDate'].min()
        cvd_max = cv_dates[ cv_dates['cv_fold'] == f ]['DataDate'].max()
        if f == 1:
            traind_max = df_calendars[df_calendars.index(cvd_min)-purged_days-1]
            l = 0
            for tt in [ x for x in dates_windows if x <= traind_max ]:
                    l = l + rows_windows[tt]
                    if 
l < cv_rows*(fold-1):
                        train_dates.append([tt,f])
        else:
            traind_min = df_calendars[df_calendars.index(cvd_max)+purged_days+1]
            traind_max = df_calendars[df_calendars.index(cvd_min)-purged_days-1]
            l = 0
            for tt in [ x for x in dates_windows if ((x >= traind_min) & (x <= dates_max)) | ((x <= traind_max)) ]:
                    l = l + rows_windows[tt]
                    if l < cv_rows*(fold-1):
                        train_dates.append([tt,f])

    train_dates = pd.DataFrame(train_dates,columns=['DataDate','train_fold'])

    return cv_dates, train_dates

def metric_rscore(cv_data_sub):

    cv_data_sub['msqe'] = cv_data_sub['wts'] * ((cv_data_sub['yhat'] - cv_data_sub['y'])**2)
    cv_data_sub['mmu'] = cv_data_sub['wts'] * ((cv_data_sub['y'] - (cv_data_sub['y'].mean()))**2)
    rsquare_cv = 1 - (cv_data_sub['msqe'].sum() / cv_data_sub['mmu'].sum())
    rscore = max( [-1,np.sign(rsquare_cv) * np.sqrt(abs(rsquare_cv))] )

    return rscore

def metric_nll(cv_data_sub):

    cv_data_sub['nll'] = 0
    condition = (cv_data_sub['yhat'] > 0.5) & (cv_data_sub['y'] == 1)
    cv_data_sub.loc[condition,'nll'] = np.log(cv_data_sub.loc[condition,'yhat'])
    condition = (cv_data_sub['yhat'] < 0.5) & (cv_data_sub['y'] == 0)
    cv_data_sub.loc[condition,'nll'] = np.log(1 - cv_data_sub.loc[condition,'yhat'])
    cv_data_sub['nll'] = cv_data_sub['nll'] * cv_data_sub['wts']
    nll =  cv_data_sub['nll'].sum() / cv_data_sub['wts'].sum()

    return nll

def objective(trial, dtrain_item, deval_item, dcv_item, configs, foldid, metric_values):
 
    nthread = configs['nthread']
    monotone_features = configs['monotone_features']
    interaction_features = configs['interaction_features']
    metric_method = configs['metric_method']
    eta_min = configs['eta_min']
    eta_max = configs['eta_max']
    gamma_min = configs['gamma_min']
    gamma_max = configs['gamma_max']
    md_min = configs['md_min']
    md_max = configs['md_max']
    mcw_min = configs['mcw_min']
    mcw_max = configs['mcw_max']
    maxbin_min = configs['maxbin_min']
    maxbin_max = configs['maxbin_max']
    subsample_min = configs['subsample_min']
    subsample_max = configs['subsample_max']
    lambda_min = configs['lambda_min']
    lambda_max = configs['lambda_max']
    alpha_min = configs['alpha_min']
    alpha_max = configs['alpha_max']
    esr = configs['esr']
    loss_function = configs['loss_function']
    grow_policy = confi
gs['grow_policy']
    learning_method = configs['learning_method']
    missing_data = configs['missing_data']
    if missing_data == 'NaN':
        missing_data = np.NaN
    else:
        missing_data = 0
    
    if learning_method == 'gbtree':
        params = {
                'learning_rate': trial.suggest_float('learning_rate', eta_min, eta_max),
                'gamma': trial.suggest_int('gamma', gamma_min, gamma_max),
                'max_depth': trial.suggest_int("max_depth", md_min, md_max),
                'min_child_weight': trial.suggest_int('min_child_weight', mcw_min, mcw_max),
                'max_delta_step': 0,
                'max_bin': trial.suggest_int("max_bin", maxbin_min, maxbin_max),
                'subsample': trial.suggest_float('subsample', subsample_min, subsample_max),
                'sampling_method': 'uniform',
                'colsample_bytree': 1,
                'colsample_bylevel': 1,
                'colsample_bynode': 1,
                'reg_lambda': trial.suggest_int("reg_lambda", lambda_min, lambda_max),
                'reg_alpha': trial.suggest_int("reg_alpha", alpha_min, alpha_max),
                'tree_method': 'gpu_hist',
                'monotone_constraints': monotone_features,
                'interaction_constraints': interaction_features,
                'objective': loss_function,
                'grow_policy': grow_policy,
                'seed': 123,
                'disable_default_eval_metric': 1,
                'nthread': nthread,
                'booster': 'gbtree',
                'gpu_id': {0:0, 1:1, 2:2, 3:3, 4:0, 5:1, 6:2, 7:3, 8:1, 9:2}[foldid-1],
                }
        
    '''    
    if loss_function == 'reg:squarederror':    
        if not os.path.exists('/home/ec2-user/SageMaker/TZ/test_gpu_final_model.json'):
            bst = xgb.train(params, dtrain_item, num_boost_round=1000, custom_metric=RscoreMetric, 
                            evals=[(dtrain_item,'dtrain'),(deval_item,'deval')], 
                            early_stopping_rounds=esr,verbose_eval=40)
        else:
            bst = xgb.train(params, dtrain_item, num_boost_round=1000, custom_metric=RscoreMetric, 
                            evals=[(dtrain_item,'dtrain'),(deval_item,'deval')], 
                            early_stopping_rounds=esr,verbose_eval=40,xgb_model='/home/ec2-user/SageMaker/TZ/test_gpu_final_model.json')
        bst.save_model('/home/ec2-user/SageMaker/TZ/test_gpu_final_model.json')
        
    if loss
_function == 'reg:logistic':
        if not os.path.exists('/home/ec2-user/SageMaker/TZ/test_gpu_final_model.json'):
            bst = xgb.train(params, dtrain_item, num_boost_round=1000, custom_metric=NegLogLoss, 
                            evals=[(dtrain_item,'dtrain'),(deval_item,'deval')], 
                            early_stopping_rounds=esr,verbose_eval=40)
        else:
            bst = xgb.train(params, dtrain_item, num_boost_round=1000, custom_metric=NegLogLoss, 
                            evals=[(dtrain_item,'dtrain'),(deval_item,'deval')], 
                            early_stopping_rounds=esr,verbose_eval=40,xgb_model='/home/ec2-user/SageMaker/TZ/test_gpu_final_model.json')
        bst.save_model('/home/ec2-user/SageMaker/TZ/test_gpu_final_model.json')
    '''
    
    if loss_function == 'reg:squarederror':    
        bst = xgb.train(params, dtrain_item, num_boost_round=1000, custom_metric=RscoreMetric, 
                            evals=[(dtrain_item,'dtrain'),(deval_item,'deval')], 
                            early_stopping_rounds=esr,verbose_eval=40)
        
    if loss_function == 'reg:logistic':
        bst = xgb.train(params, dtrain_item, num_boost_round=1000, custom_metric=NegLogLoss, 
                            evals=[(dtrain_item,'dtrain'),(deval_item,'deval')], 
                            early_stopping_rounds=esr,verbose_eval=40)
    
    output_df = pd.DataFrame({'yhat': bst.predict(dcv_item),
                              'y': deval_item.get_label(),
                              'wts': deval_item.get_weight()})
    
    if metric_method == 'rscore':
        metric = metric_rscore(output_df)
    if metric_method == 'nll':
        metric = metric_nll(output_df)

    metric_values[foldid-1] = metric

    
def get_kfold_data(df_data_train, df_calendars, configs):

    used_ret_col = configs['used_ret_col']
    fold = configs['fold']
    purged_days = configs['purged_days']
    missing_data = configs['missing_data']
    if missing_data == 'NaN':
        missing_data = np.NaN
    else:
        missing_data = 0
    
    df_data_train = df_data_train.reset_index(drop=True)
    df_data_train['y'] = df_data_train[used_ret_col]
    df_data_train = df_data_train[ np.isfinite(df_data_train['y']) ]
    df_data_train = df_data_train.reset_index(drop=True)

    cv_rows = int(len(df_data_train) / fold)
    cv_dates, train_dates = PurgedKFold(df_data_train,df_calendars,purged_days,fold,cv_rows)

    dtrain_lst = []
    deval_lst = []
    
dcv_lst = []
        
    for i in range(8):
        
        train_dates_sub = train_dates[ train_dates['train_fold'] == i+1 ]
        train_dates_sub = train_dates_sub['DataDate'].tolist()

        cv_dates_sub = cv_dates[ cv_dates['cv_fold'] == i+1 ]
        cv_dates_sub = cv_dates_sub['DataDate'].tolist()

        dtrain = xgb.DMatrix(df_data_train[df_data_train['DataDate'].isin(train_dates_sub)][configs['features']],
                             label=df_data_train[df_data_train['DataDate'].isin(train_dates_sub)][['y']],
                             missing=missing_data,
                             weight=df_data_train[df_data_train['DataDate'].isin(train_dates_sub)][['wts']])    
        dtrain_lst.append(dtrain)
    
        cv_data_sub = df_data_train[df_data_train['DataDate'].isin(cv_dates_sub)]
        cv_data_sub = cv_data_sub.reset_index(drop=True)

        deval = xgb.DMatrix(cv_data_sub[configs['features']],
                            label=cv_data_sub[['y']],
                            missing=missing_data,
                            weight=cv_data_sub[['wts']])
        dcv = xgb.DMatrix(cv_data_sub[configs['features']],
                          missing=missing_data,
                          weight=cv_data_sub[['wts']])
        deval_lst.append(deval)
        dcv_lst.append(dcv)
    
    dtrain, deval, dcv = None, None, None    
    return dtrain_lst, deval_lst, dcv_lst

    
def get_best_params(dtrain_lst, deval_lst, dcv_lst, configs, objective):

    n_trials = configs['n_trials']
    tot_waittime = configs['tot_waittime']

    def objective_cv(trial, dtrain_lst=dtrain_lst, deval_lst=deval_lst, dcv_lst=dcv_lst):
        
        threads = [None] * 8
        metric_values = [None] * 8

        for foldid in range(1,5):
            threads[foldid-1] = Thread(target=objective, args=(trial, dtrain_lst[foldid-1], deval_lst[foldid-1], dcv_lst[foldid-1], configs, foldid, metric_values))
            threads[foldid-1].start()
        for foldid in range(1,5):
            threads[foldid-1].join()

        for foldid in range(5,9):
            threads[foldid-1] = Thread(target=objective, args=(trial, dtrain_lst[foldid-1], deval_lst[foldid-1], dcv_lst[foldid-1], configs, foldid, metric_values))
            threads[foldid-1].start()
        for foldid in range(5,9):
            threads[foldid-1].join()

        return np.mean(metric_values)

    sampler = TPESampler(seed=10)

    study = optuna.create_study(sampler=sampler, direction='maximize')

    study.optimize(objective_cv, n_trials=n_trials, timeout=tot_waittime, n_jobs=configs.get('n_jobs', 1))
    trial = study.best_trial

    return trial.value, trial.params

def get_best_model(dtrain_item, deval_item, configs, best_params, foldid, save_path):

    nthread = configs['nthread']
    monotone_features = configs['monotone_features']
    interaction_features = configs['interaction_features']
    esr = configs['esr']
    loss_function = configs['loss_function']
    grow_policy = configs['grow_policy']
    learning_method = configs['learning_method']
    missing_data = configs['missing_data']
    if missing_data == 'NaN':
        missing_data = np.NaN
    else:
        missing_data = 0

    if learning_method == 'gbtree':
        params = {
                'eta': best_params['learning_rate'],
                'gamma': best_params['gamma'],
                'max_depth': best_params['max_depth'],
                'min_child_weight': best_params['min_child_weight'],
                'max_delta_step': 0,
                'max_bin': best_params['max_bin'],
                'subsample': best_params['subsample'],
                'sampling_method': 'uniform',
                'colsample_bytree': 1,
                'colsample_bylevel': 1,
                'colsample_bynode': 1,
                'lambda': best_params['reg_lambda'],
                'alpha': best_params['reg_alpha'],
                'tree_method': 'gpu_hist',
                'monotone_constraints': monotone_features,
                'interaction_constraints': interaction_features,
                'objective': loss_function,
                'grow_policy': grow_policy,
                'disable_default_eval_metric': 1,
                'seed': 123,
                'nthread': nthread,
                'booster': 'gbtree',
                'gpu_id': {0:0, 1:1, 2:2, 3:3, 4:0, 5:1, 6:2, 7:3, 8:1, 9:2}[foldid-1],
                }

    if loss_function == 'reg:squarederror':
        best_model = xgb.train(params, dtrain_item, num_boost_round=1000, custom_metric=RscoreMetric, evals=[(dtrain_item,'dtrain'),(deval_item,'deval')], early_stopping_rounds=esr,verbose_eval=40)
    if loss_function == 'reg:logistic':
        best_model = xgb.train(params, dtrain_item, num_boost_round=1000, custom_metric=NegLogLoss, evals=[(dtrain_item,'dtrain'),(deval_item,'deval')], early_stopping_rounds=esr,verbose_eval=40)

    best_model.save_model(save_path + 'bestmodels_2018/' + 'bestmodel' + str(foldid) + '.json')

    
def run_b
est_model(dtrain_lst, deval_lst, configs, best_params, save_path):
    
    threads = [None] * 8
    #best_models = [None] * 8

    for foldid in range(1,5):
        threads[foldid-1] = Thread(target=get_best_model, args=(dtrain_lst[foldid-1], deval_lst[foldid-1], configs, best_params, foldid, save_path))
        threads[foldid-1].start()
    for foldid in range(1,5):
        threads[foldid-1].join()

    for foldid in range(5,9):
        threads[foldid-1] = Thread(target=get_best_model, args=(dtrain_lst[foldid-1], deval_lst[foldid-1], configs, best_params, foldid, save_path))
        threads[foldid-1].start()
    for thid in range(5,9):
        threads[foldid-1].join()
    

def get_daily_alpha(df_data, df_calendars, alphadates, configs, save_path):

    purged_days = configs['purged_days']
    features = configs['features']
    wts_type = configs['wts_type']
    lookback_method = configs['lookback_method']
    fold = configs['fold']
    missing_data = configs['missing_data']
    if missing_data == 'NaN':
        missing_data = np.NaN
    else:
        missing_data = 0

    if lookback_method == 'rolling':
        rolling_days = configs['rolling_days']
        startdate = df_calendars[ df_calendars.index(alphadates[0]) - purged_days - rolling_days ]
    if lookback_method == 'expanded':
        startdate = df_data['DataDate'].min()

    enddate = df_calendars[ df_calendars.index(alphadates[0]) - purged_days - 1 ]

    df_data_train = df_data[ (df_data['DataDate'] >= startdate) & (df_data['DataDate'] <= enddate)  ]
    df_data_train = df_data_train.reset_index(drop=True)

    if wts_type == 'clip':
        df_data_train['wts'] = df_data_train['clip']
    elif wts_type == 'srisk':
        df_data_train['wts'] = 1 / df_data_train['SRISK']
    else:
        df_data_train['wts'] = 1e6
        
    dtrain_lst, deval_lst, dcv_lst = get_kfold_data(df_data_train, df_calendars, configs)
    best_value, best_params = get_best_params(dtrain_lst, deval_lst, dcv_lst, configs, objective)
    with open(save_path + 'bestparams_2018/' + 'bestpar.json','w') as f:
        best_params['rscore'] = best_value
        json.dump(best_params,f)
    #with open('/home/ec2-user/SageMaker/TZ/bestparams_2021/bestpar.json','r') as f:
    #    best_params = json.load(f)
    
    run_best_model(dtrain_lst, deval_lst, configs, best_params, save_path)

    
    
    '''
    for dd in range(0,len(alphadates)):
        alphadate = alphadates[dd]
        alphadatestr = str(int(alphadate.year*1
0000 + alphadate.month*100 + alphadate.day))

        df_des = df_data[ df_data['DataDate'] == alphadate ]
        df_des = df_des.reset_index(drop=True)
        X_test = df_des[features]
        tickers = df_des[['Ticker']]
        dtest = xgb.DMatrix(X_test,missing=missing_data)

        yhats = []
        #fscores = []
        for j in range(1,fold+1):
            #best_model = best_models[j]
            best_model = xgb.Booster()
            best_model.load_model(save_path + 'bestmodels_2022/' + 'bestmodel' + str(j) + '.json')
            yhat = best_model.predict(dtest)
            yhats.append(yhat)
            #fscore = best_model.get_score(importance_type=importance_type)
            #fscore = pd.DataFrame.from_dict(fscore,orient='index',columns=['fscore'])
            #fscores.append(fscore)
            #best_model.save_model(save_path + alphadatestr + '_model' + str(j) + '.json')

        yhats = np.mean(yhats,axis=0)
        #fscores = pd.concat(fscores,axis=1,sort=False)
        #fscores = fscores.mean(axis=1)
        #fscores = fscores.reset_index()
        #fscores.columns = ['feature','fscore']
        #fscores.to_csv(save_path + alphadatestr + '_fscore.txt',index=False,sep='|')

        df_des = pd.DataFrame(yhats,columns=['yhat'])
        df_des['Ticker'] = tickers
        df_des['DataDate'] = alphadate
        df_des = df_des[['DataDate','Ticker','yhat']]

        with open(save_path + 'bestparams_2022/' + 'bestpar.json','w') as f:
            best_params['rscore'] = best_value
            json.dump(best_params,f)

        df_des.to_csv(save_path + 'alphas_2023/' + alphadatestr + '_alpha.txt',index=False,sep='|')
    '''

