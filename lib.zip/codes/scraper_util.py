﻿#$%^&* scraper_util.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 16 14:10:03 2021

@author: thzhang
"""

import requests
import sys
import time


proxies = {'http':'http://proxy.mlp.com:3128','https':'https://proxy.mlp.com:3128'} 
proxies = {'http':'http://thzhang:Citadel.......@proxy.mlp.com:3128','https':'https://thzhang:Citadel.......@proxy.mlp.com:3128'} 


COOKIES = ''
headers = {
    'Accept': 'application/json, text/plain, */*',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'zh-CN,zh;q=0.9',
    'Cache-Control': 'no-cache',
    'Cookie': COOKIES,
    'DNT': '1',
    'Host': 'index.baidu.com',
    'Pragma': 'no-cache',
    'Proxy-Connection': 'keep-alive',
    'Referer': 'http://index.baidu.com/v2/main/index.html',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.90 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
}


url = 'http://index.baidu.com/Interface/ptbk?uniqid={}'
resp = requests.get(url, headers=headers, proxies=proxies, verify = False)
if resp.status_code != 200:
    print('获取uniqid失败')
    sys.exit(1)
return resp.json().get('data')



headers_cninfo = {
    'Accept': '*/*',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-US,en;q=0.9',
    'Cookie': 'JSESSIONID=04ACE78CBD702E7B63897C233462CA52; routeId=.uc2; _sp_ses.2141=*; _sp_id.2141=27ec0f3a-e808-4c6b-8e5d-3ca747db3d1d.1613677774.16.1618601306.1618596722.4f19f9e6-39b4-42fd-aa7b-66c952bb714e',
    'Content-Length': '107',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Host': 'www.cninfo.com.cn',
    'Origin': 'http://www.cninfo.com.cn',
    'Proxy-Connection': 'keep-alive',
    'Referer': 'http://www.cninfo.com.cn/new/commonUrl?url=data/yypl',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
}
url_cninfo = 'http://www.cninfo.com.cn/new/information/getPrbookInfo?sectionTime=2021-03-31&firstTime=&lastTime=&market=szsh&stockCode=&orderClos=&isDesc=&pagesize=20&pagenum=1'
resp = requests.get(url_cninfo, headers=headers_cninfo, proxies=proxies, verify = False)


resp = requests.get(url, headers=headers, proxies=proxies, verify = False)

http://apidata.chinaz.com/CallAPI/BaiduIndex?key=申请的key&keyword=站长

#---------------------------------------------
#


# Here are all of our headers
headers_cninfo = {
    '
Accept': '*/*',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-US,en;q=0.9',
    'Cookie': 'JSESSIONID=04ACE78CBD702E7B63897C233462CA52; routeId=.uc2; _sp_ses.2141=*; _sp_id.2141=27ec0f3a-e808-4c6b-8e5d-3ca747db3d1d.1613677774.16.1618601306.1618596722.4f19f9e6-39b4-42fd-aa7b-66c952bb714e',
    'Content-Length': '107',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Host': 'www.cninfo.com.cn',
    'Origin': 'http://www.cninfo.com.cn',
    'Proxy-Connection': 'keep-alive',
    'Referer': 'http://www.cninfo.com.cn/new/commonUrl?url=data/yypl',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
}

# Here is the form data
data = {
    'sectionTime':'2021-03-31',
    'firstTime':'',
    'lastTime':'2021-02-10',
    'market':'szsh',
    'stockCode':'000004',
    'orderClos':'',
    'isDesc':'',
    'pagesize':'20',
    'pagenum':'1'
}

url = "http://www.cninfo.com.cn/new/information/getPrbookInfo"
response = requests.post(url, data=data, headers=headers_cninfo, proxies=proxies, verify = False)
i_json = response.json()
i_df = pd.DataFrame(i_json['prbookinfos'])




###-------

# beautiful soup

from bs4 import BeautifulSoup
soup = BeautifulSoup(html_doc, 'html.parser')

def parse_and_upload(tr_html, data_type):
    # data_type ['m','w','d']
    o_m = pd.DataFrame()
    for i in range(1, len(t_m_records)):
        t_m_record = t_m_records[i].find_all('td')
        o_m = o_m.append({'title': t_m_record[0].find('a').text,
                          'hotness': float(t_m_record[1].img['width']),
                          'grade': t_m_record[2].text,
                          'author': t_m_record[3].text.strip().replace(' ， ',','),
                          'report_pubdate': re.sub('\s*，\s*', ',', t_m_record[4].text)
                          }, ignore_index = True)
        o_m['insert_ts_et'] = pd.Timestamp.now()
        o_m['timeframe'] = data_type
    o_m.to_parquet(os.path.join(r'S:\Data\China Data Hunt\Hibor\parq',
                                datetime.datetime.now().strftime('%Y%m%d')+'_'+data_type+'.parquet'),
                  allow_truncated_timestamps= True)
    

###-------
# pickle

with open(os.path.join(r'S:\Data\China Data Hunt\comein', str(i)+'.pickle'), 'wb') as handle:
    pickle.dump(i_data, handle, protocol = pickle.HIGHEST_PROTOCOL)
    
    
### email
    
rt win32com.clie
nt

outlook = win32com.client.Dispatch('outlook.application') # connect to outlook
mapi = outlook.GetNamespace("MAPI") 
    
inbox = mapi.GetDefaultFolder(6) # access inbox
# doc: https://docs.microsoft.com/en-us/office/vba/api/outlook.oldefaultfolders

china_folder = inbox.Folders['China broker'] # access the "China broker" folder under inbox

msg = china_folder.Items # get all emails
msg = msg.Restrict("[SenderEmailAddress] = 'Sherman.Guo@us.htisec.com'") # filter emails

# for each email ...
# https://docs.microsoft.com/en-us/dotnet/api/microsoft.office.interop.outlook.mailitem?redirectedfrom=MSDN&view=outlook-pia#properties_
for m in msg:
    str(m.sender)
    str(m.subject)
    str(m.body)
    str(m.creationtime)
    str(m.htmlbody) # event data is structured in a MS-Office-like table object (MsoNormal)



#------------------------

### Selenium
    
from seleniumwire import webdriver as webdriver2
from selenium.webdriver.support import expected_conditions as EC

options = {'proxy': {'http': 'http://thzhang:Citadel190430!@proxy.mlp.com:3128', 
                     'https': 'https://thzhang:Citadel190430!@proxy.mlp.com:3128'}}
proxies = {'http': 'http://thzhang:Citadel190430!@proxy.mlp.com:3128', 
          'https': 'https://thzhang:Citadel190430!@proxy.mlp.com:3128'}

options = Options()
options.binary_location = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

CHROMEOPTIONS = webdriver2.ChromeOptions()
CHROMEOPTIONS.add_experimental_option("prefs", {"download.default_directory":"/home/ubuntu/Downloads/rrc_temp",
                                                "download.prompt_for_download": False,
                                                "download.directory_upgrade": True,
                                                "safebrowsing.enabled": True})
#CHROMEOPTIONS.add_argument('headless')
CHROMEOPTIONS.add_argument('--proxy-server=%s' % 'http://thzhang:Citadel190430!@proxy.mlp.com:3128')
CHROME_PATH=r"N:\python_scripts\chromedriver.exe"
CAPABILITIES={'chromeOptions':{'useAutomationExtension': False}}


driver2 = webdriver2.Chrome(CHROME_PATH, seleniumwire_options=options, desired_capabilities=CAPABILITIES, options=CHROMEOPTIONS)



element = WebDriverWait(driver, 90).until(
        EC.presence_of_element_located((By.XPATH , '//div[@class="roadShow_previewDivEdit"]'))
    )
