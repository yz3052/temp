﻿#$%^&* pWIND_strat_savings_1.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Aug  3 09:47:50 2021

@author: thzhang
"""

import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu



### get mc 

i_mc = yu.get_sql('''select s_info_windcode as ticker, trade_dt as datadate, s_val_mv, s_dq_mv,
                  NET_ASSETS_TODAY as asset from wind.dbo.AShareEODDerivativeIndicator
                  where trade_dt > '20160101' ''')

i_mc['datadate'] = pd.to_datetime(i_mc['datadate'], format = '%Y%m%d')



### get sd
i_sd = pw.get_ashare_hk_sd_v3()
i_sd_map = i_sd[['ticker','datadate','GSECTOR','GGROP','GIND','GSUBIND','MC_l1d',
                 'BarrRet_CLIP_USD-1d','BarrRet_CLIP_USD+0d','BarrRet_CLIP_USD+1d','RawRet_USD+1d','isin_hk_uni',
                 'avgPVadj','avgPVadj_USD','volatility','spread','BarrRet_SRISK_USD+1d',
                 'Avail_Amount_sum', 'wRate']]

### get asset management product data

i_am = yu.get_sql('''select * from wind.dbo.AShareCorporateFinance''')


# 有少数是外币的理财，先忽略了
# 如果subscription date为null，认作是长期的理财
c_nn = i_am['S_SUBSCRIPTION_DATE'].notnull()
i_am.loc[c_nn, 'S_SUBSCRIPTION_DATE'] = pd.to_datetime(i_am.loc[c_nn, 'S_SUBSCRIPTION_DATE'], format = '%Y%m%d')
i_am['S_SUBSCRIPTION_DATE'] = i_am['S_SUBSCRIPTION_DATE'].fillna(pd.NaT)
i_am['S_SUBSCRIPTION_DATE'] = pd.to_datetime(i_am['S_SUBSCRIPTION_DATE'])
c_nn = i_am['S_INCOMESTARTDATE'].notnull()
i_am.loc[c_nn, 'S_INCOMESTARTDATE'] = pd.to_datetime(i_am.loc[c_nn, 'S_INCOMESTARTDATE'], format = '%Y%m%d')
i_am['S_INCOMESTARTDATE'] = i_am['S_INCOMESTARTDATE'].fillna(pd.NaT)
i_am['S_INCOMESTARTDATE'] = pd.to_datetime(i_am['S_INCOMESTARTDATE'])
c_nn = i_am['S_INCOMEENDDATE'].notnull()
i_am.loc[c_nn, 'S_INCOMEENDDATE'] = pd.to_datetime(i_am.loc[c_nn, 'S_INCOMEENDDATE'], format = '%Y%m%d')
i_am['S_INCOMEENDDATE'] = i_am['S_INCOMEENDDATE'].fillna(pd.NaT)
i_am['S_INCOMEENDDATE'] = pd.to_datetime(i_am['S_INCOMEENDDATE'])
i_am['ANN_DATE'] = pd.to_datetime(i_am['ANN_DATE'], format = '%Y%m%d')

# fill start date
c1 = i_am['S_SUBSCRIPTION_DATE'].notnull()
i_am.loc[c1, 'start_date'] = i_am.loc[c1, 'S_SUBSCRIPTION_DATE']
c2 = i_am['start_date'].isnull() & i_am['S_INCOMESTARTDATE'].notnull()
i_am.loc[c2, 'start_date'] = i_am.loc[c2, 'S_INCOMESTARTDATE']
c3 = i_am['start_date'].isnull()
i_am.loc[c3, 'start_date'] = i_am.loc[c3, 'ANN_DATE']


# fill end date
c1 = i_am['S_INCOMEENDDATE'].isnull() & i_am['S_COMMISSION'].isnull()
i_am.loc[c1, 'end_date'] = pd.to_datetime('
2030-12-31')
c2 = i_am['end_date'].isnull() & i_am['S_INCOMEENDDATE'].notnull()
i_am.loc[c2, 'end_date'] = i_am.loc[c2, 'S_INCOMEENDDATE']

c_day = i_am['S_COMMISSION'].notnull() & i_am['S_COMMISSION'].str.contains('天')
i_am.loc[c_day, 'S_COMMISSION_days'] = i_am.loc[c_day, 'S_COMMISSION'].str.extract('(\d+)天').astype(float).values
c_day = i_am['S_COMMISSION'].notnull() & i_am['S_COMMISSION'].str.contains('月')
i_am.loc[c_day, 'S_COMMISSION_days'] = i_am.loc[c_day, 'S_COMMISSION'].str.extract('(\d+)').astype(float).values*31
c_day = i_am['S_COMMISSION'].notnull() & i_am['S_COMMISSION'].str.contains('年')
i_am.loc[c_day, 'S_COMMISSION_days'] = (i_am.loc[c_day, 'S_COMMISSION'].str.extract('(\d+)').astype(float)*365).astype(int).values

c3 = i_am['end_date'].isnull()
i_am.loc[c3, 'end_date'] = i_am.loc[c3, 'start_date'] + i_am.loc[c3, 'S_COMMISSION_days'].apply(lambda x: pd.to_timedelta(str(x)+' days'))



### get total $ per datadate

o_amt = pd.DataFrame()

for dt in i_sd['datadate'].unique():
    
    print(pd.to_datetime(dt).strftime('%Y%m%d'), end=',')
    
    t_am = i_am[(i_am['end_date']>=dt)&(i_am['start_date']<=dt)&(i_am['ANN_DATE']<=dt)]
    
    t_am_grp = t_am.groupby('S_INFO_WINDCODE')['S_SUBSCRIPTION_AMOUNT'].sum().reset_index()
    t_am_grp['datadate'] = dt
    t_am_grp = t_am_grp.rename(columns={'S_INFO_WINDCODE':'ticker','S_SUBSCRIPTION_AMOUNT':'amt'})
    
    o_amt = o_amt.append(t_am_grp, sort = False)

### rank amt across a share 

i_agg = i_mc.merge(o_amt, on = ['ticker', 'datadate'], how = 'left')
i_agg['amt'] = i_agg['amt'].fillna(0)
i_agg['amt_dv_mc'] = i_agg['amt'].divide(i_agg['s_val_mv'])
i_agg['amt_dv_mc_rk'] = i_agg.groupby('datadate')['amt_dv_mc'].apply(yu.uniformed_rank).values
i_agg['amt_dv_mc2'] = i_agg['amt'].divide(i_agg['s_dq_mv'])
i_agg['amt_dv_mc2_rk'] = i_agg.groupby('datadate')['amt_dv_mc2'].apply(yu.uniformed_rank).values
i_agg['amt_dv_asset'] = i_agg['amt'].divide(i_agg['asset'])
i_agg['amt_dv_asset_rk'] = i_agg.groupby('datadate')['amt_dv_asset'].apply(yu.uniformed_rank).values


### combine
    
icom = i_sd_map.merge(i_agg, on = ['ticker', 'datadate'], how = 'left')


#----------------------------------------


### amt / mc 

icom2 = icom.copy()

icom2['sgnl'] = -icom2['amt_dv_mc_rk']

c1 = icom2['amt_dv_mc_rk']>0.8
icom2.loc[c1, 'sgnl1'] = - icom2.loc[c1, 'amt_dv_mc_rk']

c1 = icom2['amt_dv_mc_rk']<0
icom2.loc[c1, 'sgnl2'] = - icom2.loc[c1, 'amt_dv_mc_rk']

c1 = icom2['amt_dv_mc_rk']>0
icom2.loc[c1, 'sgnl3'] = - ic
om2.loc[c1, 'amt_dv_mc_rk']

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31') & (icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.99 / 0.17

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31') & (icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 1.55 / 1.12

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31') & (icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.98 / 0.01

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31') & (icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 095 / 0.46



### amt / asset 

icom2 = icom.copy()

icom2['sgnl'] = -icom2['amt_dv_asset_rk']

c1 = icom2['amt_dv_asset_rk']>0.8
icom2.loc[c1, 'sgnl1'] = - icom2.loc[c1, 'amt_dv_asset_rk']

c1 = icom2['amt_dv_asset_rk']<0
icom2.loc[c1, 'sgnl2'] = - icom2.loc[c1, 'amt_dv_asset_rk']

c1 = icom2['amt_dv_asset_rk']>0
icom2.loc[c1, 'sgnl3'] = - icom2.loc[c1, 'amt_dv_asset_rk']

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31') & (icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.93 / 0.12

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31') & (icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.51 / 0.2

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31') & (icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl2','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl2','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.98 / 0.01

o_1 = yu.bt_cn_15(icom2[(icom2['datadate']<='2019-12-31') & (icom2['isin_hk_uni']==1)].\
            dropna(subset=['sgnl3','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['
ticker','datadate']),
            'sgnl3','BarrRet_CLIP_USD+1d', static_data = i_sd) #prcs 0.78 / 0.33
