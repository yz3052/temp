﻿#$%^&* featurepool_cn_corpact_unlock_prod2.py #$%^&*
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  7 17:08:04 2022

@author: thzhang
"""


import pandas as pd
import numpy as np

import os

import datetime

from sqlalchemy import create_engine
import urllib
import pyodbc


# to be scheduled on crontab am


# create table F009_UNLK_FORMAT (DataDate datetime, Ticker varchar(max), descriptor float)



#------------------------------------------------------------------------------
### params
#------------------------------------------------------------------------------


save_path = '/export/dataprod/Feature_Pool_CN/featurepool_desc_corpact_unlock'

conn = create_engine('mssql+pyodbc:///?odbc_connect=%s' % (urllib.parse.quote_plus('DRIVER={FreeTDS};SERVER=summitsqldb;''PORT=1433;UID=svc_tz_dbo;database=CNDBDEV;PWD=1wutRe2tidripri;''TDS_Version=8.0;')))
conn_wind = pyodbc.connect('DRIVER={FreeTDS};SERVER=summitsqldb;PORT=1433;DATABASE=WIND_PROD;UID=svc_wind_dbo;PWD=DusONA3Habredl;TDS_Version=8.0;')

today = pd.to_datetime(datetime.datetime.now()).tz_localize('US/Eastern').tz_convert('Asia/Shanghai').tz_localize(None)
today = pd.to_datetime(today.date())
today_str = today.strftime('%Y%m%d')








#------------------------------------------------------------------------------
### get dates to query
#------------------------------------------------------------------------------


dates_to_query = pd.date_range(start='2017-01-01',end=today.strftime('%Y-%m-%d'))
dates_to_query = set(dates_to_query.strftime('%Y-%m-%d').tolist())

existing_dates = pd.read_sql('''select distinct DataDate from CNDBDEV.dbo.F009_UNLK_FORMAT''', conn)
if len(existing_dates) > 0:
    existing_dates['DataDate'] = existing_dates['DataDate'].dt.strftime('%Y-%m-%d')
    existing_dates = set(existing_dates['DataDate'].tolist())
else: 
    existing_dates = {}

query_dates = list(dates_to_query.difference(existing_dates))




#------------------------------------------------------------------------------
### get unlock historical data 
# this is a one-time scrape from Sina.
#------------------------------------------------------------------------------


o_unlock = pd.read_parquet('/dat/summit_capital/PROD/TZ/pCorpAct_cn_unlock_sina_backfill.parquet')

o_unlock.columns = ['Ticker','name','unlock_date','unlock_10kshares','unlock_100mrmb','batch','datadate','page','scraper_ts_cn']
o_unlock['Ticker'] = o_unlock['Ticker'].astype(str).str.zfill(6)
o_unlock['unlock_date'] = p
d.to_datetime(o_unlock['unlock_date'])
o_unlock['datadate'] = pd.to_datetime(o_unlock['datadate'])
o_unlock = o_unlock.assign(unlock_shares = o_unlock['unlock_10kshares'] * 10000)



#------------------------------------------------------------------------------
### get unlock production data (daily scraper)
# this comes from a daily scraper process.
#------------------------------------------------------------------------------


i_files = os.listdir('/dat/summit_capital/PROD/TZ/sina_unlock')
i_ul_daily = pd.concat(pd.read_parquet('/dat/summit_capital/PROD/TZ/sina_unlock/'+f) for f in i_files)

i_ul_daily['Ticker'] = i_ul_daily['ticker'].astype(int).astype(str).str.zfill(6)
i_ul_daily = i_ul_daily.drop(columns=['ticker'])

i_ul_daily['unlock_date'] = pd.to_datetime(i_ul_daily['unlock_date'])
i_ul_daily['unlock_shares'] = i_ul_daily['unlock_10kshares'] * 10000






#------------------------------------------------------------------------------
### get calendar
#------------------------------------------------------------------------------

i_cal = pd.read_sql('''select distinct tradedate_next as [T-1d]
                    from cndbprod.dbo.[Calendar_Dates_CN] 
                    with (nolock)
                    order by tradedate_next''', conn)
i_cal['DataDate'] = i_cal['T-1d'].shift(-1)
i_cal = i_cal.dropna()



#------------------------------------------------------------------------------
### generate descriptors
#------------------------------------------------------------------------------


for i in query_dates:
    
    ### get date strings
    
    t_1d_str = i_cal.loc[i_cal['DataDate']<=i, 'T-1d'].max().strftime('%Y-%m-%d')
    t_182d_str = (pd.to_datetime(i) - pd.to_timedelta('182 days')).strftime('%Y-%m-%d')
    
    ### unlock data
    
    
    if pd.to_datetime(t_1d_str) <= pd.to_datetime('2022-09-24'):
        t_unlock = o_unlock[(o_unlock['datadate']<=t_1d_str) & (o_unlock['unlock_date']>pd.to_datetime(t_1d_str)+pd.to_timedelta('3 days'))]
    else:
        t_unlock = i_ul_daily[pd.to_datetime(i_ul_daily['scraper_ts_cn'].dt.date)==t_1d_str]
        t_unlock = t_unlock[t_unlock['unlock_date']>pd.to_datetime(t_1d_str)+pd.to_timedelta('3 days')]
    
    
    # get data for the next unlock 
    # days to the next unlock
    # unlock shares of the next unlock 
    t_unlock = t_unlock.sort_values(['Ticker','unlock_date'])
    t_unlock['datadate'] = pd.to_datetime(t_1d_str)
    t_unlock_n1 = t_unlock.groupby('Ticker').head(1)
    t_unlock_n1 =
 t_unlock_n1.assign(flag_n1 = 1)
    t_unlock_n1 = t_unlock_n1.assign(days2n1 = (t_unlock_n1['unlock_date']-t_unlock_n1['datadate']).dt.days)
    t_unlock_n1 = t_unlock_n1.assign(unlock_shares_n1 = t_unlock_n1['unlock_shares'])
    
    s_n1 = t_unlock_n1[['Ticker','unlock_shares_n1','days2n1']]
    
    # get data for the 2nd next unlock 
    # days to the 2nd next unlock 
    # unlock shares of the 2nd next unlock 
    t_unlock_n2 = t_unlock.groupby('Ticker').head(2)
    t_unlock_n2_cnt = t_unlock_n2.groupby('Ticker')['unlock_date'].nunique().reset_index()
    t_unlock_n2_cnt = t_unlock_n2_cnt[t_unlock_n2_cnt['unlock_date']==2]
    t_unlock_n2 = t_unlock_n2[t_unlock_n2['Ticker'].isin(t_unlock_n2['Ticker'].tolist())]
    t_unlock_n2 = t_unlock_n2.drop_duplicates(subset='Ticker', keep = 'last')
    t_unlock_n2['flag_n2'] = 1
    t_unlock_n2['days2n2'] = (t_unlock_n2['unlock_date']-t_unlock_n2['datadate']).dt.days
    t_unlock_n2 = t_unlock_n2.assign(unlock_shares_n2 = t_unlock_n2['unlock_shares'])
    
    s_n2 = t_unlock_n2[['Ticker','unlock_shares_n2','days2n2']]

    # output summary stats: days to the next 2 unlocks
    t_sum = s_n1.merge(s_n2, on = 'Ticker', how = 'outer')
    t_sum['T-1d'] = pd.to_datetime(t_1d_str)
    t_sum = t_sum[['Ticker', 'unlock_shares_n2','days2n2', 'unlock_shares_n1','days2n1']]
    
    
    ### get long term adv 
    
    i_adv = pd.read_sql('''select s_info_windcode as Ticker,
                              avg(S_DQ_VOLUME * 100) as adv_t130d
                   from wind_prod.dbo.ashareeodprices 
                   where trade_dt <= '{0}' and trade_dt >= '{1}'
                   group by s_info_windcode  
                   '''.format(t_1d_str, t_182d_str), conn_wind)
    i_adv['Ticker'] = i_adv['Ticker'].str[:6]
    i_adv = i_adv[['Ticker', 'adv_t130d']]
    
    
    ### combine                  

    icom = t_sum.merge(i_adv, on = 'Ticker', how = 'left')
    
    ### calc descriptor
    
    icom = icom.assign(unlock1_dv_adv = icom['unlock_shares_n1'].divide(icom['adv_t130d']))
    icom.loc[icom['unlock1_dv_adv'].abs()>1, 'unlock1_dv_adv'] = 1
    icom = icom.assign(unlock2_dv_adv = icom['unlock_shares_n2'].divide(icom['adv_t130d']))
    icom.loc[icom['unlock2_dv_adv'].abs()>1, 'unlock2_dv_adv'] = 1
    
    c1 = icom['days2n1'].between(3, 60)
    icom['unlock1_dv_v_sgnl'] = np.nan
    icom.loc[c1, 'unlock1_dv_v_sgnl'] = - icom.loc[c1, 'unlock1_dv_adv']
    
    c1 = icom['days2n2'].between(3, 60)
    icom['unlock2_dv_v
_sgnl'] = np.nan
    icom.loc[c1, 'unlock2_dv_v_sgnl'] = - icom.loc[c1, 'unlock2_dv_adv']
    
    icom['unlock12_dv_v_sgnl'] = icom[['unlock1_dv_v_sgnl','unlock2_dv_v_sgnl']].min(axis=1)
    #icom['unlock12_dv_v_sgnl'] = icom['unlock12_dv_v_sgnl'].fillna(0)
    icom = icom.dropna(subset = ['unlock12_dv_v_sgnl'])
    
    icom = icom.assign(descriptor = icom['unlock12_dv_v_sgnl'])
    icom = icom.assign(DataDate = pd.to_datetime(i))
        
    ### output
    if len(icom) > 0:
        icom[['DataDate', 'Ticker', 'descriptor']].to_sql('F009_UNLK_FORMAT',if_exists='append',index=False,con=conn)
    
    
    
    



