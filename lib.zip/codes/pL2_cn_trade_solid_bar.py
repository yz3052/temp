﻿#$%^&* pL2_cn_trade_solid_bar.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Thu May  5 19:18:49 2022

@author: thzhang
"""






import pandas as pd
import numpy as np

import pWIND_util as pw
import yz.util as yu

import gc
import datetime



#  This studies TWAP capture data



### sd china

i_sd = pw.get_ashare_hk_sd_v2(version='2p1')
i_sd = i_sd.sort_values(['datadate'])




### Get and analyze data

i_dates = yu.get_sql("select distinct datadate from cndbprod.dbo.trade_cn_kline")


o_data = []

for dt in i_dates['datadate']:
    print(dt.strftime('%Y%m%d')[2:], end=' ')
    
    t_data = yu.get_sql('''select datadate, 
                                  ticker, 
                                  trade_minutes - trade_minutes % 5 as hh5m, 
                                  sum(pv) as pv, 
                                  max([high]) as h, 
                                  min([low]) as l, 
                                  min(trade_minutes*100000000+[open]) as o, 
                                  max(trade_minutes*100000000+[close]) as c 
                           from cndbprod.dbo.trade_cn_kline 
                           where datadate = '{0}'
                           group by datadate, ticker, trade_minutes - trade_minutes % 5  
                           '''.format( dt.strftime('%Y-%m-%d') ))
    t_data['o'] = t_data['o'] - np.floor(t_data['o']/10000)*10000
    t_data['c'] = t_data['c'] - np.floor(t_data['c']/10000)*10000
    
    t_hh5m_sum = t_data.groupby('hh5m')['pv'].sum().reset_index()
    t_hh5m_sum.columns = ['hh5m', 'pv_hh5m_sum']
    t_data = t_data.merge(t_hh5m_sum, on = 'hh5m', how = 'left')
    t_data['pv_pct'] = t_data['pv'].divide(t_data['pv_hh5m_sum'])
    
    t_data['flag_solid'] = 0
    c1 = (t_data['h']/t_data['l']>1.0025) & ((t_data['c'] - t_data['o']).divide(t_data['h'] - t_data['l']) > 0.9)
    c2 = (t_data['h']/t_data['l']>1.0025) & ((t_data['o'] - t_data['c']).divide(t_data['h'] - t_data['l']) > 0.9)
    t_data.loc[c1, 'flag_solid'] = 1
    t_data.loc[c2, 'flag_solid'] = -1
    
    s1 = t_data.groupby(['datadate','ticker','flag_solid'])['pv_pct','pv'].sum().reset_index()
    s1.columns = ['datadate','ticker','flag_solid', 'pv_pct_sum', 'pv_sum']
    
    t_daily_pct_sum = t_data.groupby('ticker')['pv_pct', 'pv'].sum().reset_index()
    t_daily_pct_sum.columns = ['ticker', 'pv_pct_daily_sum_lvlTk', 'pv_daily_sum_lvlTk']
    s1 = s1.merge(t_daily_pct_sum, on = 'ticker', how = 'left')
    
    o_data.append(s1)    

    t_data = None
    t_hh5m_sum = None

o_data = pd.concat(o_data, axis = 0)
c_sh = o_data['ticker'].str[0].isin(['6'])
c_sz = o_data['ticker'].str[0].isin(['0','3'])
o_data.loc[c_sh, 'ticker'] = o_data.loc[c_sh, 'ticker'] + '.SH'
o_data.loc[c_sz, 'ticker'] = o_data.loc[c_sz, 'ticker'] + '.SZ'

o_data_pv = o_data.pivot_table(index = ['datadate','ticker','pv_pct_daily_sum_lvlTk', 'pv_daily_sum_lvlTk'],columns = 'flag_solid',values=['pv_pct_sum', 'pv_sum'])
o_data_pv.columns = ['pv_pct_sum_m1','pv_pct_sum_0','pv_pct_sum_p1','pv_sum_m1','pv_sum_0','pv_sum_p1']
o_data_pv = o_data_pv.reset_index()
o_data_pv = o_data_pv.fillna(0)
    
### combine

icom = i_sd.merge(o_data_pv, on = ['datadate', 'ticker'], how = 'left')


# flag = 1: solid bull bar 
icom['pv_pct_sum_p1_pct'] = icom['pv_pct_sum_p1'].divide(icom['pv_pct_daily_sum_lvlTk'])
icom['pv_pct_sum_p1_pct_bk'] = icom.groupby('datadate')['pv_pct_sum_p1_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['pv_pct_sum_p1_pct_bk'], 'pv_pct_sum_p1_pct') # less mono: 0 1.0 -2.5

icom['pv_pct_sum_m1_pct'] = icom['pv_pct_sum_m1'].divide(icom['pv_pct_daily_sum_lvlTk'])
icom['pv_pct_sum_m1_pct_bk'] = icom.groupby('datadate')['pv_pct_sum_m1_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['pv_pct_sum_m1_pct_bk'], 'pv_pct_sum_m1_pct') # less mono: random



icom['pv_pct_sum_net_pct'] = (icom['pv_pct_sum_p1']-icom['pv_pct_sum_m1']).divide(icom['pv_pct_daily_sum_lvlTk'])
icom['pv_pct_sum_net_pct_bk'] = icom.groupby('datadate')['pv_pct_sum_net_pct'].apply(lambda x: yu.pdqcut(x,bins=10)).values
yu.create_cn_3x3(icom, ['pv_pct_sum_net_pct_bk'], 'pv_pct_sum_net_pct') # random 

