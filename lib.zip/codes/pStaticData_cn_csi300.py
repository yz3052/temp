﻿#$%^&* pStaticData_cn_csi300.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sat Jun 25 19:26:29 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu

# this is not done yet 
# this generates 2 versions: csi 300 and intersection of 300 + SS


### get ss universe

i_ss = yu.get_sql('''select datadate, ticker from cndbprod.dbo.universe_stable_shortable
                  where cn_index = 'CSI300' ''')



### get barra factors

i_barra = yu.get_sql('''select * FROM [CNDBPROD].[dbo].[UNIVERSE_T2000_CN_GEM3L] where datadate>= '2016-01-01' ''')
i_barra = i_barra.rename(columns={'Ticker':'ticker', 'DataDate':'datadate'})

i_barra = i_barra.sort_values(['ticker', 'datadate'])
i_barra['RawRet_USD-1d'] = i_barra.groupby('ticker')['AdjRet_USD'].shift()
i_barra = i_barra.rename(columns = {'AdjRet_USD':'RawRet_USD+0d'})
i_barra = i_barra.rename(columns = {'gk_vol_63d':'volatility'})

i_barra['clip'] = i_barra['avgPVadj_USD']*0.01
i_barra.loc[i_barra['clip']>1e6, 'clip'] = 1e6


reg_cols = ['SRISK', 'BETA', 'MOMENTUM', 'SIZE', 'EARNYILD',
           'RESVOL', 'GROWTH', 'DIVYILD', 'BTOP', 'LEVERAGE', 'LIQUIDTY', 'SIZENL',
           'AIRLINES', 'AUTOCOMP', 'BANKS', 'BIOTECH', 'CAPGOODS', 'CHEMICAL',
           'COMMSVCS', 'COMMUNIC', 'COMPUTER', 'CONSDUR', 'CONSTPP', 'CONSVCS',
           'DIVFINAN', 'DIVMETAL', 'ENERGY', 'FOODPRD', 'FOODRETL', 'HEALTH',
           'HSHLDPRD', 'INSURAN', 'INTERNET', 'MEDIA', 'OILEXPL', 'OILGAS',
           'PHARMAC', 'PRECMETL', 'REALEST', 'RETAIL', 'SEMICOND', 'SOFTWARE',
           'STEEL', 'TELECOM', 'TRANSPRT', 'UTILITY']



### get CSI300 universe

i_csi300 = yu.get_sql('''select Date_Of_Portfolio as datadate, database_symbol as ticker 
                      FROM [CNDBPROD].[dbo].[CSI_300_CONS] ''')
i_csi300['ticker'] = i_csi300['ticker'].str[1:]



### calculate residual return

icom = i_barra.merge(i_csi300, on = ['ticker','datadate'], how='inner')

ocom = []
for dt in icom['datadate'].drop_duplicates():
    print('.', end='')
    
    tcom = icom[icom['datadate']==dt]
    
    try:
        regr2 = LinearRegression(fit_intercept=False)
        regr2.fit(tcom[reg_cols].values, tcom['RawRet_USD-1d'].values, tcom['clip'].values)
        tcom.loc[:,'BarrRet_CLIP_USD+0d'] = tcom['RawRet_USD-1d'].values - regr2.predict(tcom[reg_cols].values)
        
        ocom.append(tcom)
        tcom = None
        del regr2
        
    except:
        print('_',end='')

ocom = pd.concat(ocom, axis=0)



### out
put 
ocom = ocom.sort_values(['ticker', 'datadate'])
ocom['BarrRet_CLIP_USD+1d'] = ocom.groupby('ticker')['BarrRet_CLIP_USD+0d'].shift(-1)

c_sh = ocom['ticker'].str[0].isin(['6'])
c_sz = ocom['ticker'].str[0].isin(['0','3'])
ocom.loc[c_sh, 'ticker'] = ocom.loc[c_sh, 'ticker'] + '.SH'
ocom.loc[c_sz, 'ticker'] = ocom.loc[c_sz, 'ticker'] + '.SZ'

ocom.to_parquet(r'S:\Data\China Data Hunt\cache\pStaticData_cn_csi300.parquet')


