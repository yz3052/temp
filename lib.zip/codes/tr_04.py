﻿#$%^&* tr_04.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 19 22:16:28 2020

@author: thzhang
"""

import pandas as pd
import numpy as np

from yz import get_sql, tic, toc 
from yz.util import pickle_bz_dump, pickle_bz_load

from datetime import datetime

import os
import inspect
import matplotlib.pyplot as plt


    
    

class Backtest(object):
    

    
    def __init__(self, event_signals_df, strat_func,  
                 str_from_yyyymmdd, str_to_yyyymmdd, pv_mkt_data = None,
                 min_abs_zscore=0.5, days_bf_earning=9, holding_days=8
                 ):
        
        ### ---init uni and param ---
        
        # ticker uni 
        
        self.tk = ['ABMD', 'ADPT', 'AGN', 'ATRC', 'AVDR', 'BMY', 'CDNA', 'CORT', 'DXCM', 'GKOS', 'INGN', 'ISRG', 'ITMR', 'MASI', 'MNK', 'NVRO', 'PODD', 'RMD', 'SILK', 'TCMD', 'TFX', 'TNDM', 'VAR', 'VCYT', 'CSII', 'EW', 'IRTC', 'NVCR', 'OXFD', 'VAPO', 'ELGX', 'CERS', 'AXNX', 'NTUS', 'ZBH', 'ARAY', 'INSP', 'NUVA', 'SIBN']
        self.tk.remove('OXFD')
        self.tk.remove('ITMR')
        self.tk.remove('MNK')
        self.tk.remove('SIBN')
        self.tk.remove('NTUS')
        self.tk = ['ISRG','EW','NVRO','ABMD','PODD','NVCR','CDNA','DXCM','EXAS','XENT','GKOS','TCMD','TNDM','UTHR']

        
        # tdates uni
        
        bbg_tdate = get_sql("select distinct datadate from [BackTest].[dbo].[BBG_MktData_Hist] order by datadate")
        self.tdates = bbg_tdate[(bbg_tdate.datadate >= datetime.strptime(str_from_yyyymmdd,'%Y%m%d')) &
                                (bbg_tdate.datadate <= datetime.strptime(str_to_yyyymmdd,  '%Y%m%d')) ].reset_index(drop = True)
        
        self.sy, self.sm, self.sd = self.tdates.datadate[self.tdates.datadate.index.min()].year, self.tdates.datadate[self.tdates.datadate.index.min()].month, self.tdates.datadate[self.tdates.datadate.index.min()].day
        self.ey, self.em, self.ed = self.tdates.datadate[self.tdates.datadate.index.max()].year, self.tdates.datadate[self.tdates.datadate.index.max()].month, self.tdates.datadate[self.tdates.datadate.index.max()].day
        
        # param
        
        self.min_abs_zscore = abs(min_abs_zscore)
        self.days_bf_earning = days_bf_earning
        self.holding_days = holding_days
        
        self.params = locals()
        
        # strategy variables
        
        self.strat_func = strat_func
        
        self.pv_ret = None # market data
        self.pv_ret_c_o = None
        
        sel
f.pv_alpha = self.helper_create_empty_tdate_tk_matrix() # external signals
        
        self.pv_mkt_data = pv_mkt_data
        self.pv_earnings_date = self.helper_create_empty_tdate_tk_matrix()
        
        #self.event_signals_df = event_signals_df
        if event_signals_df is not None:
            self.EventSignals = event_signals_df.copy()
        else:
            self.EventSignals = EventSignals(self.tk).i3() # external signal 
    
        self.pv_pstD_mo = self.helper_create_empty_tdate_tk_matrix()
        self.pv_pstD_mc = self.helper_create_empty_tdate_tk_matrix()
        self.pv_pstS = self.helper_create_empty_tdate_tk_matrix()
        self.pv_ordD_mo = self.helper_create_empty_tdate_tk_matrix() # dollar order at next market open
        self.pv_ordD_mc = self.helper_create_empty_tdate_tk_matrix()
        self.pv_ordS = self.helper_create_empty_tdate_tk_matrix()
        
        self.pv_pnlD = self.helper_create_empty_tdate_tk_matrix()
        
        self.vc_curr_pnlD = self.helper_create_empty_tdate_tk_vector()
        
        self.state_dict = {} # state dict
        
        # reporting
        
        self.o_report_dict = {}
        
    ### --- helper functions ---
    
    def pv_tdate_tk_f(self, event_signals_df):
        
        o1 = pd.DataFrame(columns = ['tdate']+self.tk)
        
        o1['tdate'] = self.tdates.datadate 
    
        for index, row in event_signals_df.iterrows():
            
            t_loc = None
            
            try:
                # locate the dates
                if row.sourceDate.hour<=13:
                    t_loc = np.where(self.tdates.datadate>= row.sourceDate)[0][0]-self.days_bf_earning 
                    # broadcast factor scores
                    o1.loc[t_loc:t_loc+self.holding_days,row.Ticker] = row.zscore
                
                elif row.sourceDate.hour>13:
                    t_loc = np.where(self.tdates.datadate>  row.sourceDate)[0][0]-self.days_bf_earning+1
                    # broadcast factor scores
                    o1.loc[t_loc:t_loc+self.holding_days,row.Ticker] = row.zscore
                
            except IndexError:
                pass
    
        return o1    
    
    # pre-process the alpha signals from excel
    def helper_tdate_tk_general(self, tdate_tk_discrete_score_df):
        
        # initiate output variable
        o1 = self.helper_create_empty_tdate_tk_matrix()
        
        # find the columns
        t_date_col = [i for i in t
date_tk_discrete_score_df.columns.tolist() if 'date' in i.lower()][0]
        t_tk_col = [i for i in tdate_tk_discrete_score_df.columns.tolist() if 'ticker' in i.lower()][0]
        t_score_col = [i for i in tdate_tk_discrete_score_df.columns.tolist() if 'score' in i.lower()][0]
        
        # find the next earning date as of the datadate        
        wh = get_sql('''
                     select datadate, stock_symbol, [next_ed_quarter], [fiscal_year],
                     case when time_of_day = 'After Market' then next_ed + 1 else next_ed end as first_earning_impact 
                     FROM [BackTest].[dbo].[WSH_ED_SNAP] 
                     where stock_symbol in {0} 
                     '''.format(str(tuple(self.tk)) if len(self.tk)>1 else "('"+self.tk[0]+"')") )
        wh = wh.drop_duplicates(subset = ['datadate','stock_symbol'],keep = 'first')
        
        wh_latest_update = wh.groupby(['stock_symbol','fiscal_year','next_ed_quarter'])['datadate'].max().reset_index()
        wh_latest_update = wh_latest_update.merge(wh, on = ['stock_symbol','fiscal_year','next_ed_quarter','datadate'], how = 'left')
        wh_latest_update = wh_latest_update.drop(columns = ['datadate'])
        
        wh = wh.merge(wh_latest_update, on =  ['stock_symbol','fiscal_year','next_ed_quarter'], suffixes = ['_old',''] )
        
        # merge
        tdate_tk_discrete_score_df['datadate'] = pd.to_datetime(tdate_tk_discrete_score_df['datadate'])
        tdate_tk_discrete_score_df = tdate_tk_discrete_score_df.merge(wh, left_on = ['ticker','datadate'], 
                                                                      right_on =['stock_symbol','datadate'], 
                                                                      how = 'left' )
        tdate_tk_discrete_score_df = tdate_tk_discrete_score_df[pd.notnull(tdate_tk_discrete_score_df.stock_symbol)]

        
        # fill in the data into a pivot table
        for index, row in tdate_tk_discrete_score_df.iterrows():
            
            t_loc = None
            t_loc_e_minus_x = None
            t_loc_datadate = None
            
            try:                
                # locate the dates
                t_loc_e_minus_x = np.where(self.tdates.datadate >= pd.to_datetime(row['first_earning_impact']))[0][0]-self.days_bf_earning 
                t_loc_datadate = np.where(self.tdates.datadate >= pd.to_datetime(row[t_date_col]))[0][0]
                t_loc = max(t_loc_e_minus_x, t_loc_datadat
e)
                # broadcast factor scores
                t_zscore = row[t_score_col]
                if abs(t_zscore) > self.min_abs_zscore:
                    if t_zscore > 3:
                        t_zscore = 3
                    elif t_zscore < -3:
                        t_zscore = -3
                else:
                    t_zscore = 0
                o1.loc[t_loc, row[t_tk_col]] = t_zscore
            except IndexError:
                pass
            
            try: # 1 for first earning impact date
                t_loc_e = np.where(self.tdates.datadate >= pd.to_datetime(row['first_earning_impact']))[0][0]
                self.pv_earnings_date.loc[t_loc_e, row[t_tk_col]] = 1
            except IndexError:
                pass
                
        # only keep signals in the ticker universe
        o1 = o1[self.tk]
        return o1
    
    def helper_create_empty_tdate_tk_matrix(self):
        t0 = np.zeros([len(self.tdates.datadate), len(self.tk)])
        t1 = pd.DataFrame(t0, columns = self.tk)
        t1 = t1[self.tk]
        return t1
    
    def helper_create_empty_tdate_tk_vector(self):
        t0 = np.zeros(len(self.tk))
        return t0
    
#    def helper_days2earnings(self):
#        wh = get_sql("select ")
    
    def ret_barra_c_c(self):
        ibarra = get_sql("select datadate, Ticker, ret_barra_omega_adj from [BackTest].[dbo].[BARRA_Ret_Daily] where Ticker in {0}".format(str(tuple(self.tk))))
        ibarra_pivot = ibarra.pivot_table(index='datadate', columns = 'Ticker', values = 'ret_barra_omega_adj').reset_index()
        ibarra_pivot = ibarra_pivot[(ibarra_pivot.datadate>=datetime(self.sy,self.sm,self.sd))&(ibarra_pivot.datadate<=datetime(self.ey,self.em,self.ed))]
        ibarra_pivot = ibarra_pivot.reset_index(drop = True)
        ibarra_pivot = ibarra_pivot[self.tk]
        return ibarra_pivot
    
    def ret_overnight(self):
        iovernight = get_sql("select datadate, Ticker, (PX_OPEN - PX_YEST_CLOSE)/PX_YEST_CLOSE  as overnight_ret FROM [BackTest].[dbo].[BBG_MktData_Hist] where Ticker in {0}".format(str(tuple(self.tk))))
        iovernight_pivot = iovernight.pivot_table(index='datadate', columns = 'Ticker', values = 'overnight_ret').reset_index()
        iovernight_pivot = iovernight_pivot[(iovernight_pivot.datadate>=datetime(self.sy,self.sm,self.sd))&(iovernight_pivot.datadate<=datetime(self.ey,self.em,self.ed))]
        iovernight_pivot = iovernight_pivot[self.tk]
        return iovernight_pivot
   
     
    def rpt_sharpe(self, daily_pnl_sr):
        return daily_pnl_sr.mean()/daily_pnl_sr.std()
    
    def rpt_plot(self, cum_pnl_sr, tdates_sr):
        fig, ax = plt.subplots(constrained_layout=True)
        ax.plot(tdates_sr, cum_pnl_sr)
    
    
        
    ### --- loop over strat ---
    def main(self):
        
        
        # standardizes event_signals_df
        self.pv_alpha = self.helper_tdate_tk_general(self.EventSignals).reset_index(drop = True).fillna(0)
        
        # standardizes close-toclose barra return
        self.pv_ret = self.ret_barra_c_c()
        
        # standardize intrday barra return
        self.pv_ret_c_o = np.subtract(self.pv_ret.loc[:,:], self.ret_overnight().loc[:,:])
        

        for num, row in self.pv_ret.iterrows():
            
            # skipover rows
            if num < 30:
                continue
            
            # carry on pst fro yesterday
            self.pv_pstD_mo.loc[num, :] = self.pv_pstD_mc.loc[num-1, :] 
            
            
            # fill ord @ mo:
            #   also update pst @ mo: yesterday mc pst + new pst
            self.pv_pstD_mo.loc[num, :] = self.pv_ordD_mo.loc[num-1,:] + self.pv_pstD_mc.loc[num-1,:]
            
            
            # fill ord @ mc:
            #   also update pst @ mc: today mo pst + new pst
            
            self.pv_pstD_mc.loc[num,:] = self.pv_ordD_mc.loc[num-1,:] + self.pv_pstD_mo.loc[num,:]
            
            # calculate pnl of the pst opened @ mo
            
            self.pv_pnlD.loc[num,:] = self.pv_pnlD.loc[num,:] + np.multiply(self.pv_pstD_mo.loc[num,:] \
                                    - self.pv_pstD_mc.loc[num-1,:], self.pv_ret_c_o.loc[num,:])
            
            # clculate pnl of the pst from yesterday
            
            self.pv_pnlD.loc[num,:] = self.pv_pnlD.loc[num,:] + np.multiply(self.pv_pstD_mc.loc[num-1,:], self.pv_ret.loc[num,:])
            
            # review if there has been new pst / closed pst, and update curr pst pnl
            cond_new_pst = (self.pv_pstD_mc.loc[num-1, :]==0) & (self.pv_pstD_mc.loc[num, :]!=0)
            self.vc_curr_pnlD[cond_new_pst] = self.vc_curr_pnlD[cond_new_pst] + self.pv_pnlD.loc[num,cond_new_pst].values           
            cond_pst_closed = (self.pv_pstD_mc.loc[num-1, :]!=0) & (self.pv_pstD_mc.loc[num, :]==0)
            self.vc_curr_pnlD[cond_pst_closed] = 0
            cond_pst_held = (self.pv_pstD_mc.loc[num-1, :]!=0) & (self.pv_pstD_m
c.loc[num, :]!=0)
            self.vc_curr_pnlD[cond_pst_held] = self.vc_curr_pnlD[cond_pst_held] + self.pv_pnlD.loc[num,cond_pst_held].values
            
            self.vc_curr_pnlD = np.nan_to_num(self.vc_curr_pnlD)
            
            # strategy
            self.strat_func(self, num)



    
    ### --- reporting ---
    def reporting(self):        
        
        # prepare pnl matrix
        
        self.pv_pnlD = self.pv_pnlD.fillna(0)
        
        
        # add index
        self.pv_pnlD.index = self.tdates.datadate
        self.pv_pstD_mc.index = self.tdates.datadate
        self.pv_pstD_mo.index = self.tdates.datadate
        
        
        # o_report_dict to be pickled
        
        
        self.o_report_dict['sourcecode'] = inspect.getsource(self.strat_func)
        self.o_report_dict['params'] = self.params
        
        self.o_report_dict['pnl_tk'] = self.pv_pnlD
        self.o_report_dict['pnl_ptf'] = self.pv_pnlD.sum(axis = 1)
        
        self.o_report_dict['cumpnl_tk'] = self.pv_pnlD.cumsum(axis = 0)
        self.o_report_dict['cumpnl_ptf'] = self.pv_pnlD.cumsum(axis = 0).sum(axis = 1)
        
        self.o_report_dict['pst_mc'] = self.pv_pstD_mc
        self.o_report_dict['pst_mo'] = self.pv_pstD_mo
        
        self.o_report_dict['sharpe_tk'] = self.pv_pnlD.mean(axis = 0) / self.pv_pnlD.std(axis = 0) * np.sqrt(250)
        self.o_report_dict['sharpe_ptf'] = self.pv_pnlD.sum(axis=1).mean(axis=0) / self.pv_pnlD.sum(axis=1).std(axis=0) * np.sqrt(250)
        
        # plot ABMD        
        fig_tk, ax_tk = plt.subplots(constrained_layout=True)
        ax_tk.plot(self.tdates.datadate, self.o_report_dict['cumpnl_tk'].ABMD)
        
        
        # plot ptf cum pnl
        fig, ax = plt.subplots(constrained_layout=True)
        ax.plot(self.tdates.datadate, self.o_report_dict['cumpnl_ptf'])
        
        # print 
        print('ABMD sharpe: ' + str(self.o_report_dict['sharpe_tk'].ABMD) )
        print('ptf sharpe: ' + str(self.o_report_dict['sharpe_ptf']) )
        
        o_pickle = self.o_report_dict.copy()
        pickle_bz_dump(os.path.join(r'S:\Data\CHC_research\Backtest Results', 
                                 datetime.now().strftime('%Y%m%d_%H%M_') +\
                                 's_'+str(round(self.o_report_dict['sharpe_ptf'],2)) +\
                                 '_p_{:.2e}'.format(self.o_report_dict['cumpnl_ptf'].tolist()[-1]).replace('+','') +\
                                 '_
u_'+str(len(self.tk))+'.p'), o_pickle)
        
        return self.o_report_dict
    

# hold the position for a fixed number of days
def strat_200419(self, num):

    # figure out the pst whose last day will be tmr, hence send order to close pst
    
    cond_close_pst = np.array(np.ones(len(self.tk)),dtype = bool)
    for i in range(self.holding_days-1):
        cond_close_pst = cond_close_pst & (self.pv_pstD_mc.loc[num-i,:]!=0) # all the past x days have pst
        
    # holding period will end by mc of the next trading day hence send order
    pass
    
    
    # calculate ord @ mo t+1
    self.pv_ordD_mo.loc[num,:] = np.multiply(self.pv_alpha.loc[num, :], 2e6)
    
    # calculate ord @ mc t+1
    self.pv_ordD_mc.loc[num,:] = np.multiply(cond_close_pst, - self.pv_pstD_mc.loc[num,:])

# hold the position and exit right before earnings
def strat_200430(self, num):
    
    cond_close_pst = np.array(np.ones(len(self.tk)),dtype = bool)
    for i in range(self.holding_days-1):
        cond_close_pst = cond_close_pst & (self.pv_pstD_mc.loc[num-i,:]!=0) # all the past x days have pst
        
    # exit before earnings anyways
    try:
        cond_close_pst[self.pv_earnings_date.loc[num+2,:]==1] = 1 # earnings coming, close anyways
    except KeyError:
        pass

    # calculate ord @ mo t+1
    self.pv_ordD_mo.loc[num,:] = np.multiply(self.pv_alpha.loc[num, :], 2e6)
    # calculate ord @ mc t+1
    self.pv_ordD_mc.loc[num,:] = np.multiply(cond_close_pst, - self.pv_pstD_mc.loc[num,:])    


# hold the position and only exit before earnings if we make money
def strat_200430c(self, num):
    
    if num == 30:
        self.state_dict['debug'] = self.helper_create_empty_tdate_tk_matrix()
    
    self.state_dict['debug'].loc[num,:]  = self.vc_curr_pnlD
    
    # initiate cond
    cond_close_pst = np.array(np.zeros(len(self.tk)),dtype = bool)
    
    # if making money, exit position before earnings    
    try:
        cond_close_pst[(self.pv_earnings_date.loc[num+2,:]==1) & (self.vc_curr_pnlD > 0)] = 1
    except KeyError:
        pass
    
    # if not making money exit position after earnings
    try:
        cond_close_pst[(self.pv_earnings_date.loc[num+2,:]==1) & (self.vc_curr_pnlD <= 0)] = 0
    except KeyError:
        pass
    
    # exit 1 day after earnings anyways
    cond_close_pst[self.pv_earnings_date.loc[num,:]==1] = 1 # 1 day past earnings, close anyways

    # calculate ord @ mo t+1
    self.pv_ordD_mo.loc[num,:] = np.multiply(self.pv_
alpha.loc[num, :], 2e6)
    # calculate ord @ mc t+1
    self.pv_ordD_mc.loc[num,:] = np.multiply(cond_close_pst, - self.pv_pstD_mc.loc[num,:])    

#bt = Backtest(event_signals_df=None,strat_func = strat_200419,str_from_yyyymmdd='20140901', str_to_yyyymmdd='20190630',days_bf_earning=9, holding_days=12) #i3()
bt = Backtest(event_signals_df= i5, strat_func = strat_200430c,str_from_yyyymmdd='20140901', str_to_yyyymmdd='20190630',days_bf_earning=25, holding_days=28) #i3()
bt.main()
result = bt.reporting()



#result['cumpnl_tk']['EW'].plot()
#result['cumpnl_tk'].plot()
