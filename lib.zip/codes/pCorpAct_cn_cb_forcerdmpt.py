﻿#$%^&* pCorpAct_cn_cb_forcerdmpt.py #$%^&*
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 18 15:31:37 2022

@author: thzhang
"""

import pandas as pd
import numpy as np

import yz.util as yu
import pWIND_util as pw



# yes there is strong short-side alpha here




###  sd

i_sd = pw.get_ashare_t2000_sd()




### cb-stock ticker mapping 

i_cb = yu.get_sql('''select a.s_info_windcode as ticker_cb, a.ann_dt, a.cb_info_preplandate, a.s_info_compcode,
                  b.s_info_windcode as ticker 
 from wind.dbo.CCBondIssuance a
 left join (select * from wind.dbo.WindCustomCode where S_INFO_SECURITIESTYPES='A') b
 on a.s_info_compcode = b.s_info_compcode
''')

i_cb = i_cb[i_cb['ticker'].notnull() & i_cb['ticker_cb'].notnull()]
i_cb = i_cb[['ticker', 'ticker_cb']]



### get ann (force rdmpt)

cb_sh = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pCorpAct_cn_cb_etl_sse_announcement.parquet')
cb_sh['ticker'] = cb_sh['SECURITY_CODE'].str.strip() + '.SH'
cb_sh['datadate'] = pd.to_datetime(cb_sh['SSEDATE'].str.split('<br>').str[0])
cb_sh['title'] = cb_sh['TITLE']

cb_sh = cb_sh[['ticker','datadate','title']]

cb_sz = pd.read_parquet(r'S:\TZ\China Data Hunt\cache\pCorpAct_cn_cb_etl_szse_announcement.parquet')
cb_sz['ticker'] = cb_sz['secCode'].apply(lambda x: x[0]) + '.SZ'
cb_sz['datadate'] = pd.to_datetime(pd.to_datetime(cb_sz['publishTime']).dt.date)

cb_sz = cb_sz[['ticker','datadate','title']]


cb_ann = pd.concat([cb_sh, cb_sz], axis = 0)
cb_ann = cb_ann.sort_values(['ticker', 'datadate'])
cb_ann = cb_ann[cb_ann['datadate']>='2016-01-01']

cb_ann_rdmpt = cb_ann[cb_ann.title.str.contains('赎') & (~cb_ann.title.str.contains('不'))]
cb_ann_rdmpt = cb_ann_rdmpt[cb_ann_rdmpt.title.str.contains('次')]
cb_ann_rdmpt['flg_rdmpt'] = 1



cb_ann_stop = cb_ann[cb_ann.title.str.contains('转债') & (cb_ann.title.str.contains('停止交易'))]
cb_ann_stop['flg_cb_stop'] = 1
cb_ann_stop = cb_ann_stop.rename(columns={'title':'title_stop'})
cb_ann_stop = cb_ann_stop[['ticker', 'datadate', 'flg_cb_stop', 'title_stop']]

cb_ann_stop = cb_ann_stop.sort_values(['ticker', 'datadate'])
cb_ann_stop = cb_ann_stop.drop_duplicates(subset=['ticker'], keep = 'last')



### combine

icom = i_sd.merge(cb_ann_rdmpt, on = ['datadate', 'ticker'], how = 'left')
icom = icom.merge(cb_ann_stop, on = ['datadate', 'ticker'], how = 'left')

icom = icom.sort_values(['ticker', 'datadate'])


yu.create_cn_decay(icom, 'flg_rdmpt') # 




icom['sgnl1'] = np.nan
icom.loc[icom['flg_rdmpt']==1, 'sgnl1'] = -1


o_1 = yu.bt_
cn_15(icom[icom['datadate'].between('2020-01-01', '2022-12-31') ].\
            dropna(subset=['sgnl1','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl1','BarrRet_CLIP_USD+1d', static_data = i_sd) # 1.99 / 0.74 / 0.44


# check losers here ... any mis-coding?


### the period after forced redemption / zhai1 pai2
# very short term alpha: >2 sharpe if hold ~2 days
# long term 6m alpha: sharpe around 1. Stock goes beyond what those companies anticipated

yu.create_cn_decay(icom, 'flg_cb_stop') # 

icom['sgnl_stop'] = np.nan
icom.loc[icom['flg_cb_stop']==1, 'sgnl_stop'] = 1
icom['sgnl_stop'] = icom.groupby('ticker')['sgnl_stop'] .ffill(limit=60)


o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2020-01-01', '2022-12-31') ].\
            dropna(subset=['sgnl_stop','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_stop','BarrRet_CLIP_USD+1d', static_data = i_sd)

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2020-01-01', '2022-12-31') ].\
            dropna(subset=['sgnl_stop','RawRet_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_stop','RawRet_USD+1d', static_data = i_sd)




### the period before forced redemption / zhai1 pai2
# around ~1 sharpe before last "stop trading" notice date 

icom['sgnl_bfr_rdmpt'] = np.nan
icom['flg_cb_stop_f1d'] = icom.groupby('ticker')['flg_cb_stop'].shift(-1)
icom.loc[icom['flg_cb_stop_f1d']==1, 'sgnl_bfr_rdmpt'] = -1
icom['sgnl_bfr_rdmpt']  = icom.groupby('ticker')['sgnl_bfr_rdmpt'].bfill(limit=10)

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2020-01-01', '2022-12-31') ].\
            dropna(subset=['sgnl_bfr_rdmpt','BarrRet_CLIP_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_bfr_rdmpt','BarrRet_CLIP_USD+1d', static_data = i_sd)

o_1 = yu.bt_cn_15(icom[icom['datadate'].between('2020-01-01', '2022-12-31') ].\
            dropna(subset=['sgnl_bfr_rdmpt','RawRet_USD+1d']).drop_duplicates(subset=['ticker','datadate']),
            'sgnl_bfr_rdmpt','RawRet_USD+1d', static_data = i_sd)



